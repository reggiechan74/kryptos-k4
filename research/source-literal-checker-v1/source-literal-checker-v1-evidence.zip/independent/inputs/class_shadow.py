POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
class POOL:pass
