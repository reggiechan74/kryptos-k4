POOL={'north':[c for c in (b'EA','AE')]}
