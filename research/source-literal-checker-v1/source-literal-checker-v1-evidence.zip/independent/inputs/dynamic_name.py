PAIR=('EA','AE')
POOL={'north':[c for c in PAIR]}
