POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
del POOL['north']
