POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
def POOL():pass
