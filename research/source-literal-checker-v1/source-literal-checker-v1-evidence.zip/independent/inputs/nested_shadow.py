POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
def f():
 POOL=0
