POOL={'north':[c for c in (f'EA','AE')]}
