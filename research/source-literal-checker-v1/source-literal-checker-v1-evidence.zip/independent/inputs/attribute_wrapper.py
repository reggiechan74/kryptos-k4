POOL={'north':builtins.tuple(c for c in ('EA','AE'))}
