if True:
 POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
