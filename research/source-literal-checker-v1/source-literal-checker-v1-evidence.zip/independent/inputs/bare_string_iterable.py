POOL={'north':[c for c in 'EAAE']}
