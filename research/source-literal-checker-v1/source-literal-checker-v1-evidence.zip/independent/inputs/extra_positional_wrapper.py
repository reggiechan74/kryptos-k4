POOL={'north':tuple((c for c in ('EA','AE')),1)}
