POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
POOL.update({'north': 0})
