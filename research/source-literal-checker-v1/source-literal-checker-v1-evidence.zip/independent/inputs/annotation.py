POOL:dict={'north':[c for c in ('EA','AE')]}
