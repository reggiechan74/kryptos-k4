POOL,OTHER=({'north':[c for c in ('EA','AE')]},0)
