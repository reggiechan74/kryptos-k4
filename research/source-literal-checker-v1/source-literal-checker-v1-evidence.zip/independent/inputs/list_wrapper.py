POOL={'north':list(c for c in ('EA','AE'))}
