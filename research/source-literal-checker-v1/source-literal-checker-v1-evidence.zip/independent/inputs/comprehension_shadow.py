POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
x=[0 for POOL in []]
