POOL={'north':[c for c in ('AE','EA')]}
