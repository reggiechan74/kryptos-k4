POOL={**other,'north':[c for c in ('EA','AE')]}
