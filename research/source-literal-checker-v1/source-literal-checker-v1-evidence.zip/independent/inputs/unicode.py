POOL={'north':[c for c in ('é','雪','🙂')]}
