POOL={other:0,'north':[c for c in ('EA','AE')]}
