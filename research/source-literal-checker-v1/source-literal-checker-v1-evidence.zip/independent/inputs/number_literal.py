POOL={'north':[c for c in ('EA',12)]}
