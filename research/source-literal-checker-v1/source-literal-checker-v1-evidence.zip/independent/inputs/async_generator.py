POOL={'north':[c async for c in ('EA','AE')]}
