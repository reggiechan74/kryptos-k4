POOL={'north':[c for c in ('EA','EA')]}
