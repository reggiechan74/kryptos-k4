POOL={'north':[c for c in ('EA',True)]}
