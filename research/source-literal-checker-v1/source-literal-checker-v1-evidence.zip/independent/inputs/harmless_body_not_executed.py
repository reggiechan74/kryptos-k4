POOL={'north':[__import__('pathlib').Path('/workspace/shared/k4-source-literal-audit/SHOULD_NOT_EXIST').write_text('bad') for c in ('EA','AE')]}
