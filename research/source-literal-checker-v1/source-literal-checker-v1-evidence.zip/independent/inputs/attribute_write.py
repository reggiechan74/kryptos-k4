POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
POOL.x=1
