POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
match x:
 case {'x':POOL}:pass
