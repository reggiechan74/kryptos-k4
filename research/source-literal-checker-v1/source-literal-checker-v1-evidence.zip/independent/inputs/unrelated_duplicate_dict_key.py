POOL={'other':1,'other':2,'north':[c for c in ('EA','AE')]}
