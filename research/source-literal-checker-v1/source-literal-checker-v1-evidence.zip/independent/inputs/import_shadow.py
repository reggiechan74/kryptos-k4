POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
import x as POOL
