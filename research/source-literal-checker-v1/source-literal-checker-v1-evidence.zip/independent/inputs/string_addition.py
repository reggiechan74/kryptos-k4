POOL={'north':[c for c in ('E'+'A','AE')]}
