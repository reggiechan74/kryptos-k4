tuple=lambda *x:0
POOL={'north':tuple(c for c in ('EA','AE'))}
