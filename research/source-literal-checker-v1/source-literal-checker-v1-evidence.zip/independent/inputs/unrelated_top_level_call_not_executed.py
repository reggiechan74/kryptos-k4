raise RuntimeError('must not execute')
POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
