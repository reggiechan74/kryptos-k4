POOL={'north':tuple((c for c in ('EA','AE')),x=1)}
