POOL={'north':[c for c in ('EA','AE') for d in (1,)]}
