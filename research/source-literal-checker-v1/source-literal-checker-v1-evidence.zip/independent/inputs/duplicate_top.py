POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
