POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
POOL['north'][0]=1
