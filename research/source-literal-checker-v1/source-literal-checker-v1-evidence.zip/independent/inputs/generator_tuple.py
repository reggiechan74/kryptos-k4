POOL={'north':tuple(ord(c) for c in ['EA','AE'])}
