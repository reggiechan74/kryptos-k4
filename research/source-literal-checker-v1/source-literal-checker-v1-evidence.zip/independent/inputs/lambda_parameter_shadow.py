POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
f=lambda POOL:0
