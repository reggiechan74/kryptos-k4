POOL={3:0,'north':[c for c in ('EA','AE')]}
