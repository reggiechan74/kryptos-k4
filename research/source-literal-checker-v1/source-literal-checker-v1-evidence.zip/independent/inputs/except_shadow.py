POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
try:pass
except Exception as POOL:pass
