POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
from x import POOL
