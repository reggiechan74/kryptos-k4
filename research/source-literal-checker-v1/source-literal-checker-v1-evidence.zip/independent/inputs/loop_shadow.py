POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
for POOL in []:pass
