POOL={'north':[c for c in ('EA','AE')],'north':[d for d in ('EA','AE')]}
