POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
with obj as POOL:pass
