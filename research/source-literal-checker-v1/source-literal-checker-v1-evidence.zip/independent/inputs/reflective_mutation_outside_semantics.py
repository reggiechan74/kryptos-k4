POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
globals()['POOL']=0
