POOL={'south':[c for c in ('EA','AE')]}
