POOL = {'north': [ord(c) for c in ('EA', 'AE')]}
alias=POOL
alias['north']=0
