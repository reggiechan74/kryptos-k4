import sys,json,time,io,resource,hashlib
from pathlib import Path
from unittest import mock
from contextlib import redirect_stdout
sys.path.insert(0,'/workspace/shared/k4-source-literal-checker')
import literal_check as tool
root=Path(__file__).parent;b=(root/'inputs/basic_listcomp.py').read_bytes();req=json.loads((root/'inputs/basic_listcomp.json').read_text());results=[];t=time.monotonic();c=time.process_time()
for error in [MemoryError,RecursionError]:
 with mock.patch.object(tool.ast,'parse',side_effect=error):out=tool.verify(b,req)
 assert out=={'status':'FAIL','reason':'PARSE_FAILURE'};results.append(dict(case='parser_'+error.__name__,output=out))
with mock.patch.object(resource,'setrlimit',side_effect=ValueError('injected unsupported limit')):
 out=io.StringIO()
 with redirect_stdout(out):rc=tool.main()
 r=json.loads(out.getvalue());assert r=={'status':'FAIL','reason':'INPUT_FAILURE'} and rc==2;results.append(dict(case='resource_setup_failure',output=r,returncode=rc))
# Keep real process limits intact in this library driver; static CLI has already
# applied its true POSIX limits on all84fixture processes.
with mock.patch.object(resource,'setrlimit'),mock.patch.object(sys,'argv',['tool',str(root/'inputs/basic_listcomp.json'),str(root/'inputs/NOT_PRESENT.py')]):
 out=io.StringIO()
 with redirect_stdout(out):rc=tool.main()
 r=json.loads(out.getvalue());assert r=={'status':'FAIL','reason':'INPUT_FAILURE'} and rc==2;results.append(dict(case='missing_source',output=r,returncode=rc))
report=dict(status='PASS',fresh_blind=False,results=results,wall_seconds=time.monotonic()-t,cpu_seconds=time.process_time()-c,max_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,plan_sha256=hashlib.sha256((root/'RESOURCE-SUPPLEMENT-PLAN.md').read_bytes()).hexdigest());(root/'RESOURCE-SUPPLEMENT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
