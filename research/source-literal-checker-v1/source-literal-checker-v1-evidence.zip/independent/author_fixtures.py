import json,base64,hashlib
from pathlib import Path
root=Path(__file__).parent
cases=[]
base="POOL = {'north': [ord(c) for c in ('EA', 'AE')]}\n"
def add(id,source=base,status='PASS',expected=['EA','AE'],**extra):
 cases.append(dict(id=id,source_b64=base64.b64encode(source.encode() if isinstance(source,str) else source).decode(),assignment='POOL',key='north',expected=expected,expected_status=status,**extra))
add('basic_listcomp')
add('generator_tuple',"POOL={'north':tuple(ord(c) for c in ['EA','AE'])}\n")
add('harmless_body_not_executed',"POOL={'north':[__import__('pathlib').Path('/workspace/shared/k4-source-literal-audit/SHOULD_NOT_EXIST').write_text('bad') for c in ('EA','AE')]}\n")
add('unrelated_top_level_call_not_executed',"raise RuntimeError('must not execute')\n"+base)
add('tuple_shadow_outside_semantics',"tuple=lambda *x:0\nPOOL={'north':tuple(c for c in ('EA','AE'))}\n")
add('later_method_mutation_outside_semantics',base+"POOL.update({'north': 0})\n")
add('alias_mutation_outside_semantics',base+"alias=POOL\nalias['north']=0\n")
add('reflective_mutation_outside_semantics',base+"globals()['POOL']=0\n")
add('unrelated_duplicate_dict_key',"POOL={'other':1,'other':2,'north':[c for c in ('EA','AE')]}\n")
add('unicode',"POOL={'north':[c for c in ('é','雪','🙂')]}\n",expected=['é','雪','🙂'])
add('empty_sequence',"POOL={'north':[c for c in ()]}\n",expected=[])
add('max_items',"POOL={'north':[c for c in "+repr(tuple('a' for _ in range(256)))+"]}\n",expected=['a']*256)
add('max_string',"POOL={'north':[c for c in "+repr(('a'*256,))+ "]}\n",expected=['a'*256])
add('concatenated_string_literal',"POOL={'north':[c for c in ('E' 'A','AE')]}\n")
for id,source in {
'wrong_pair':"POOL={'north':[c for c in ('EA','EA')]}\n",
'wrong_order':"POOL={'north':[c for c in ('AE','EA')]}\n",
'number_literal':"POOL={'north':[c for c in ('EA',12)]}\n",
'bytes_literal':"POOL={'north':[c for c in (b'EA','AE')]}\n",
'bool_literal':"POOL={'north':[c for c in ('EA',True)]}\n",
'joined_string':"POOL={'north':[c for c in (f'EA','AE')]}\n",
'string_addition':"POOL={'north':[c for c in ('E'+'A','AE')]}\n",
'dynamic_name':"PAIR=('EA','AE')\nPOOL={'north':[c for c in PAIR]}\n",
'dynamic_call':"POOL={'north':[c for c in make_pair()]}\n",
'star_iterable':"POOL={'north':[c for c in (*('EA',),'AE')]}\n",
'nested_literal':"POOL={'north':[c for c in (('EA',),'AE')]}\n",
'set_iterable':"POOL={'north':[c for c in {'EA','AE'}]}\n",
'bare_string_iterable':"POOL={'north':[c for c in 'EAAE']}\n",
'dict_unpack':"POOL={**other,'north':[c for c in ('EA','AE')]}\n",
'dynamic_key_elsewhere':"POOL={other:0,'north':[c for c in ('EA','AE')]}\n",
'nonstring_key_elsewhere':"POOL={3:0,'north':[c for c in ('EA','AE')]}\n",
'duplicate_selected_key':"POOL={'north':[c for c in ('EA','AE')],'north':[d for d in ('EA','AE')]}\n",
'missing_key':"POOL={'south':[c for c in ('EA','AE')]}\n",
'filtered_generator':"POOL={'north':[c for c in ('EA','AE') if True]}\n",
'multiple_generators':"POOL={'north':[c for c in ('EA','AE') for d in (1,)]}\n",
'async_generator':"POOL={'north':[c async for c in ('EA','AE')]}\n",
'bare_generator':"POOL={'north':(c for c in ('EA','AE'))}\n",
'set_comp':"POOL={'north':{c for c in ('EA','AE')}}\n",
'list_wrapper':"POOL={'north':list(c for c in ('EA','AE'))}\n",
'attribute_wrapper':"POOL={'north':builtins.tuple(c for c in ('EA','AE'))}\n",
'keyword_wrapper':"POOL={'north':tuple((c for c in ('EA','AE')),x=1)}\n",
'extra_positional_wrapper':"POOL={'north':tuple((c for c in ('EA','AE')),1)}\n",
'annotation':"POOL:dict={'north':[c for c in ('EA','AE')]}\n",
'chained_assignment':"OTHER=POOL={'north':[c for c in ('EA','AE')]}\n",
'unpacking_assignment':"POOL,OTHER=({'north':[c for c in ('EA','AE')]},0)\n",
'conditional_only':"if True:\n "+base,
'nested_only':"def f():\n "+base,
'duplicate_top':base+base,
'nested_shadow':base+"def f():\n POOL=0\n",
'parameter_shadow':base+"def f(POOL):pass\n",
'kwonly_parameter_shadow':base+"def f(*,POOL):pass\n",
'lambda_parameter_shadow':base+"f=lambda POOL:0\n",
'loop_shadow':base+"for POOL in []:pass\n",
'with_shadow':base+"with obj as POOL:pass\n",
'except_shadow':base+"try:pass\nexcept Exception as POOL:pass\n",
'import_shadow':base+"import x as POOL\n",
'importfrom_shadow':base+"from x import POOL\n",
'function_shadow':base+"def POOL():pass\n",
'class_shadow':base+"class POOL:pass\n",
'walrus_shadow':base+"x=(POOL:=1)\n",
'comprehension_shadow':base+"x=[0 for POOL in []]\n",
'match_shadow':base+"match x:\n case {'x':POOL}:pass\n",
'augassign':base+"POOL+=[]\n",
'del_name':base+"del POOL\n",
'subscript_write':base+"POOL['north']=1\n",
'attribute_write':base+"POOL.x=1\n",
'nested_subscript_write':base+"POOL['north'][0]=1\n",
'del_subscript':base+"del POOL['north']\n",
'syntax':"POOL = (\n",
'non_utf8':b'\xff\xfe',
'utf8_bom':b'\xef\xbb\xbf'+base.encode(),
'oversize_source':base+'#'+('x'*262145),
'overdeep_ast':base+'x='+('['*90)+'0'+(']'*90)+'\n',
'parser_depth':base+'x='+('['*300)+'0'+(']'*300)+'\n',
'overnodes':base+'x='+repr([0]*21000)+'\n',
'over_items':"POOL={'north':[c for c in "+repr(tuple('a' for _ in range(257)))+"]}\n",
'over_string':"POOL={'north':[c for c in "+repr(('a'*257,))+"]}\n",
}.items():add(id,source,'FAIL')
add('hash_mismatch',status='FAIL',hash_override='0'*64)
add('empty_provenance',status='FAIL',provenance='')
add('expected_wrong_type',status='FAIL',expected='EA')
add('expected_number_item',status='FAIL',expected=['EA',1])
add('expected_overlong_request',status='FAIL',expected=['x'*65537])
(root/'fixtures.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
(root/'PLAN.md').write_text('''# Independent fresh adversarial plan\n\nRead only SPEC.md before authoring fixtures. No production source/development tests inspected. Expected PASS/FAIL frozen in fixtures.json; request field mapping will be adapted only after production CLI schema inspection. No outcome-dependent fixture changes. Every FAIL must fail closed; every PASS must extract exact sequence. Body/top-level side-effect sentinels must not execute. Supplement duplicate-JSON and malformed-JSON CLI requests after mapping; these are expected FAIL. Global AST limits are checked by fixtures; POSIX process CPU/address-space limits inspected without unsafe load. Distinguish lexical-only PASS from semantic safety: tuple shadowing, .update(), alias/global mutations intentionally PASS according to SPEC. Actual EA/AE pair is covered by basic and wrong-pair fixtures. This validates literal reproduction only, not provenance authenticity/whole-program meaning.\n''')
manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in root.iterdir() if f.is_file()};(root/'FROZEN-FIXTURES.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(cases),hashlib.sha256((root/'FROZEN-FIXTURES.json').read_bytes()).hexdigest())
