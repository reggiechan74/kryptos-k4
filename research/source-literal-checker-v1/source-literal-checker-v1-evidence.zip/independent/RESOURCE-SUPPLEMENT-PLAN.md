# Post-inspection failure-path supplement

Not part of fresh blind84cases. Inject parser MemoryError and RecursionError through unittest.mock in a trusted local test process; expect FAIL/PARSE_FAILURE. Inject POSIX setrlimit ValueError; expect CLI FAIL/INPUT_FAILURE (no PASS). Try explicit missing source path; expect FAIL/INPUT_FAILURE. No real memory/CPU exhaustion is forced, no external source is executed. This tests handling paths, not the operating system's ability to kill runaway workloads. Freeze this plan before executing supplement.
