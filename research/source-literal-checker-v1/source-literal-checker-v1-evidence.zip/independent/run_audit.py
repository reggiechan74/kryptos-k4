import json,base64,hashlib,subprocess,time,resource
from pathlib import Path
root=Path(__file__).parent;tool=Path('/workspace/shared/k4-source-literal-checker');start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
frozen=json.loads((root/'FROZEN-FIXTURES.json').read_text());assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in frozen.items())
prod=json.loads((tool/'FREEZE.json').read_text());assert all(hashlib.sha256((tool/k).read_bytes()).hexdigest()==v for k,v in prod['files'].items())
cases=json.loads((root/'fixtures.json').read_text());results=[]
(root/'inputs').mkdir(exist_ok=True)
for c in cases:
 source=base64.b64decode(c['source_b64']);sp=root/'inputs'/(c['id']+'.py');sp.write_bytes(source)
 req=dict(sha256=c.get('hash_override',hashlib.sha256(source).hexdigest()),provenance=c.get('provenance','independent synthetic fixture; not historical provenance'),assignment=c['assignment'],key=c['key'],expected=c['expected'])
 rp=root/'inputs'/(c['id']+'.json');rp.write_text(json.dumps(req,ensure_ascii=False))
 p=subprocess.run(['python3',str(tool/'literal_check.py'),str(rp),str(sp)],capture_output=True,timeout=5)
 try:output=json.loads(p.stdout)
 except Exception:output={'status':'NO_JSON','stdout_hex':p.stdout.hex()}
 checks={'status':output.get('status')==c['expected_status'],'returncode':p.returncode==(0 if c['expected_status']=='PASS' else 2)}
 if c['expected_status']=='PASS':checks.update(value=output.get('actual')==c['expected'],hash=output.get('source_sha256')==hashlib.sha256(source).hexdigest(),provenance=output.get('provenance_supplied')==req['provenance'],limitation='not validated' in output.get('limitation',''))
 results.append(dict(id=c['id'],expected_status=c['expected_status'],output=output,returncode=p.returncode,stderr=p.stderr.decode(errors='replace'),checks=checks))
# Preregistered malformed and duplicate JSON CLI supplements, using frozen basic source.
sp=root/'inputs/basic_listcomp.py'
for name,raw in [('duplicate_json',b'{"sha256":"x","sha256":"y"}'),('malformed_json',b'{'),('invalid_json_utf8',b'\xff')]:
 rp=root/'inputs'/(name+'.json');rp.write_bytes(raw);p=subprocess.run(['python3',str(tool/'literal_check.py'),str(rp),str(sp)],capture_output=True,timeout=5)
 out=json.loads(p.stdout);results.append(dict(id=name,expected_status='FAIL',output=out,returncode=p.returncode,checks={'status':out.get('status')=='FAIL','returncode':p.returncode==2}))
# Independent byte-offset location validation for frozen basic fixture.
a=results[0]['output'];src=sp.read_text();expected_locs={'assignment_location':{'lineno':1,'col_offset':0,'end_lineno':1,'end_col_offset':len(src.rstrip('\n').encode())},'key_location':{'lineno':1,'col_offset':src.index("'north'"),'end_lineno':1,'end_col_offset':src.index("'north'")+7},'iterable_location':{'lineno':1,'col_offset':src.index("('EA'"),'end_lineno':1,'end_col_offset':src.index("('EA'")+len("('EA', 'AE')")}}
locations={k:a.get(k)==v for k,v in expected_locs.items()}
after=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'status':'PASS' if all(all(x['checks'].values()) for x in results) and all(locations.values()) and not (root/'SHOULD_NOT_EXIST').exists() else 'FAIL','fixture_freeze_sha256':hashlib.sha256((root/'FROZEN-FIXTURES.json').read_bytes()).hexdigest(),'production_freeze_sha256':hashlib.sha256((tool/'FREEZE.json').read_bytes()).hexdigest(),'cases':len(results),'false_accepts':[x['id'] for x in results if x['expected_status']=='FAIL' and x['output'].get('status')=='PASS'],'false_rejects':[x['id'] for x in results if x['expected_status']=='PASS' and x['output'].get('status')!='PASS'],'failed_checks':[x for x in results if not all(x['checks'].values())],'basic_exact_location_checks':locations,'side_effect_sentinel_absent':not(root/'SHOULD_NOT_EXIST').exists(),'wall_seconds':time.monotonic()-start,'child_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'max_child_rss_bytes':after.ru_maxrss*1024,'results':results}
(root/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'}))
