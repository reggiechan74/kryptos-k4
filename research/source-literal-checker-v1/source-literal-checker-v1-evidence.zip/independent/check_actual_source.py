import json,hashlib,subprocess,time,resource
from pathlib import Path
root=Path(__file__).parent; source=Path('/workspace/shared/k4-route-source-audit/zeye-mech.py');b=source.read_bytes();h=hashlib.sha256(b).hexdigest();assert h=='1243ff870bcdd93e9712624b7837b9999dd80c00bcc3308b1514665f50e2516c'
# Independent direct textual review confirms these exact source lines.
lines=b.decode().splitlines();assert all("('LQ','OU','EA','IE')" in lines[i] for i in (37,38))
t=time.monotonic();u=resource.getrusage(resource.RUSAGE_CHILDREN);out=[]
for key in ('shifts_ST','shifts_KA'):
 for pair in ('EA','AE'):
  request=dict(sha256=h,provenance='https://github.com/zeyeteam-debug/kryptos-k4-eliminations/blob/00696f393c861db2dcfaf3adfef29823c601cf7a/scripts/mech.py',assignment='ERRnums',key=key,expected=['LQ','OU',pair,'IE']);p=root/'inputs'/f'actual_{key}_{pair}.json';p.write_text(json.dumps(request));r=subprocess.run(['python3','/workspace/shared/k4-source-literal-checker/literal_check.py',str(p),str(source)],capture_output=True,timeout=5);result=json.loads(r.stdout);expected='PASS' if pair=='EA' else 'FAIL';assert result['status']==expected;out.append(dict(request=request,result=result,returncode=r.returncode))
v=resource.getrusage(resource.RUSAGE_CHILDREN);report=dict(status='PASS',scope='Supplement, not fresh blind data; pinned source read as data only',cases=4,results=out,wall_seconds=time.monotonic()-t,child_cpu_seconds=v.ru_utime+v.ru_stime-u.ru_utime-u.ru_stime,max_child_rss_bytes=v.ru_maxrss*1024);(root/'ACTUAL-SOURCE-SUPPLEMENT.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='results'})
