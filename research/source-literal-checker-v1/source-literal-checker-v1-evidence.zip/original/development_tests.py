import hashlib,json,unittest
from pathlib import Path
from literal_check import verify

BASE="ERRnums={'shifts_ST':tuple((ord(b)-ord(a))%26 for a,b in ('LQ','OU','EA','IE'))}\n"
def request(source,expected=None):return {'sha256':hashlib.sha256(source).hexdigest(),'provenance':'synthetic-v1','assignment':'ERRnums','key':'shifts_ST','expected':expected or ['LQ','OU','EA','IE']}
class Tests(unittest.TestCase):
 def test_exact(self):
  b=BASE.encode();self.assertEqual(verify(b,request(b))['status'],'PASS')
 def test_wrong_expected(self):
  b=BASE.encode();self.assertEqual(verify(b,request(b,['LQ','OU','AE','IE']))['reason'],'VALUE_MISMATCH')
 def test_wrong_source(self):
  b=BASE.replace("'EA'","'AE'").encode();self.assertEqual(verify(b,request(b))['reason'],'VALUE_MISMATCH')
 def test_hash(self):
  b=BASE.encode();r=request(b);r['sha256']='0'*64;self.assertEqual(verify(b,r)['reason'],'HASH_MISMATCH')
 def test_dynamic_iterable(self):
  b=BASE.replace("('LQ','OU','EA','IE')","steps").encode();self.assertEqual(verify(b,request(b))['reason'],'NONLITERAL_ITERABLE')
 def test_duplicate_key(self):
  b=BASE.replace("}\n",",'shifts_ST':[] }\n").encode();self.assertEqual(verify(b,request(b))['reason'],'KEY_MISSING_OR_DUPLICATE')
 def test_duplicate_binding(self):
  b=(BASE+'ERRnums={}\n').encode();self.assertEqual(verify(b,request(b))['reason'],'ASSIGNMENT_MISSING_OR_DUPLICATE')
 def test_no_execution(self):
  b=("raise RuntimeError('must never execute')\n"+BASE).encode();self.assertEqual(verify(b,request(b))['status'],'PASS')
 def test_unsupported_call(self):
  b=BASE.replace('tuple(','evil(').encode();self.assertEqual(verify(b,request(b))['reason'],'UNSUPPORTED_COMPREHENSION')
 def test_mutation(self):
  b=(BASE+"ERRnums['x']=3\n").encode();self.assertEqual(verify(b,request(b))['reason'],'AMBIGUOUS_BINDING')
 def test_literal_list_comprehension(self):
  b=b"ERRnums={'shifts_ST':[x for x in ['LQ','OU','EA','IE']]}";self.assertEqual(verify(b,request(b))['status'],'PASS')
if __name__=='__main__':unittest.main()
