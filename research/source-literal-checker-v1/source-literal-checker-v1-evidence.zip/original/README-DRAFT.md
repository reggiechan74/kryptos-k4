# Pinned-source literal checks

**Validation pending independent adversarial review. Do not treat development tests as admission.**

This small read-only utility catches transcription mistakes when copying one declared literal from Python source. It does not execute that source, interpret a cipher, establish runtime values, or prove novelty. The motivating error was copying E→A as A→E in an external research program's fixed step list.

Runtime: Python3.10+ on POSIX for CLI resource limits. No third-party dependencies.

Create a JSON request containing exactly `sha256`, `provenance`, `assignment`, `key`, and `expected`. Supply the independently pinned source checksum rather than a hash chosen to make an edited source pass. `provenance` is recorded as supplied, not authenticated. Then:

```
python3 literal_check.py request.json pinned-source.py
```

Exit0 means the selected structural literal exactly matches the expected sequence. Exit2/failure means do not proceed on this receipt. The strict selector supports only the shapes in SPEC.md; it is intentionally not a general Python evaluator. Callers should supply bounded ordinary files and preserve requests/results with source pins. Source-derived comprehension bodies, imported alphabets, reflective or alias mutations, and runtime control flow still require human/source review. A PASS must not be labelled semantic equivalence or complete prior-domain validation.

The source stays private unless its license permits redistribution. Public evidence can retain its URL, pin, checksum, source locations, own request/output and own parser tests without redistributing the external file.

Development evidence:11 synthetic unit tests and the actual original source's two selected tuples (correctEA accepted; wrongAE rejected). This is a useful regression, not an independent holdout. FREEZE.json fixes the utility/spec/dev evidence before separately authored adversarial validation. Failed cases, corrections, new freezes and fresh validation must be retained rather than editing the original evidence.
