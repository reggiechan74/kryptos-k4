"""Static source-domain inspection only; no imported/executed external code or target data.

Reads only the literal LORE assignment in pinned novel/linkey.py and rebuilds
the documented deduplicate-key-then-AZ alphabet rule. No K4 constraints.
"""
import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'private-sources' / 'novel__linkey.py'
tree = ast.parse(SOURCE.read_text())
lore = None
for node in tree.body:
    if isinstance(node, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id == 'LORE' for t in node.targets
    ):
        assert isinstance(node.value, ast.Call)
        assert isinstance(node.value.func, ast.Attribute)
        assert node.value.func.attr == 'split'
        lore = ast.literal_eval(node.value.func.value).split()
assert lore is not None
seen, retained = set(), []
for word in [''] + lore:
    alpha = ''.join(dict.fromkeys(word + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'))
    for reverse in (False, True):
        a = alpha[::-1] if reverse else alpha
        if a not in seen:
            seen.add(a)
            if not reverse:
                retained.append((word or 'AZ', a))
affine = []
for label, alpha in retained:
    ranks = [alpha.index(chr(65 + i)) for i in range(26)]
    u = (ranks[1] - ranks[0]) % 26
    if all(ranks[i] == (ranks[0] + u*i) % 26 for i in range(26)):
        affine.append({'label': label, 'rank_slope': u, 'rank_offset': ranks[0]})
print(json.dumps({'alphabet_count': len(retained), 'affine_rank_maps': affine}, indent=2))
