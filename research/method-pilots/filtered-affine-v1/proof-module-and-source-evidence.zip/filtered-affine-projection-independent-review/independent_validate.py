#!/usr/bin/env python3
"""Independent, bounded toy audit; does not read cryptanalytic data or edit producer files."""
import ast
import hashlib
import itertools
import json
from pathlib import Path
import random
import resource
import time

resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
start = time.process_time()
source = Path('/workspace/shared/filtered-affine-projection/verify.py')
# Load only reviewed function definitions: no producer experiment side effects.
parsed = ast.parse(source.read_text())
ns = {}
exec(compile(ast.Module(body=[n for n in parsed.body if isinstance(n, ast.FunctionDef)], type_ignores=[]), str(source), 'exec'), ns)

def accepts(equations, point, q):
    return all(sum(row[j] * point[j] for j in range(len(point))) % q == row[-1] % q for row in equations)

def points_for(equations, n, q):
    return frozenset(p for p in itertools.product(range(q), repeat=n) if accepts(equations, p, q))

def scalar(row, point, q):
    return sum(row[j] * point[j] for j in range(len(point))) % q

def all_affine_sets(n, q):
    points = frozenset(itertools.product(range(q), repeat=n))
    hyperplanes = [list(row) + [t] for row in itertools.product(range(q), repeat=n) if any(row) for t in range(q)]
    seen = {points: []}
    todo = [points]
    while todo:
        old = todo.pop()
        for h in hyperplanes:
            new = frozenset(p for p in old if accepts([h], p, q))
            if new not in seen:
                seen[new] = seen[old] + [h]
                todo.append(new)
    return seen

counts = {'cases': 0, 'witnesses': 0, 'guard_checks': 0}

def check(base, forbidden, c, n, q, known_points=None):
    if known_points is None:
        surviving = {p for p in points_for(base, n, q) if all(not accepts(w, p, q) for w in forbidden)}
    else:
        surviving = known_points
    exact = [sum(scalar(c, p, q) == t for p in surviving) for t in range(q)]
    got = ns['count_ie'](base, forbidden, c, n, q)
    assert got == exact, ('IE', base, forbidden, c, q, got, exact)
    image = {t for t in range(q) if exact[t]}
    if len(forbidden) < q:
        assert ns['image_small'](base, forbidden, c, n, q) == image
        for t in range(q):
            witness = ns['witness_small'](base, forbidden, c, t, n, q)
            assert (witness is not None) == (t in image)
            if witness is not None:
                assert tuple(witness) in surviving and scalar(c, witness, q) == t
                counts['witnesses'] += 1
    else:
        for name, args in [('image_small', (base, forbidden, c, n, q)), ('witness_small', (base, forbidden, c, 0, n, q))]:
            try:
                ns[name](*args)
            except ValueError:
                counts['guard_checks'] += 1
            else:
                raise AssertionError(('missing guard', name, q))
    counts['cases'] += 1

coverage = {}
for n, q, max_r in [(3, 2, 1), (2, 3, 2)]:
    affine = all_affine_sets(n, q)
    entries = list(affine.items())
    before = counts['cases']
    for V, base in entries:
        for r in range(max_r + 1):
            for selected in itertools.combinations_with_replacement(entries, r):
                forbidden = [rows for _, rows in selected]
                surviving = set(V)
                for W, _ in selected:
                    surviving.difference_update(W)
                for c in itertools.product(range(q), repeat=n):
                    check(base, forbidden, c, n, q, surviving)
    coverage[f'exhaustive_F{q}_{n}'] = {'affine_sets': len(entries), 'cases': counts['cases'] - before, 'max_r': max_r, 'all_bases': True, 'all_scalar_rows': True}

# Nontrivial translated two-dimensional embeddings in ambient dimension four.
# x2 = x0 + x1 + 1, x3 = 2*x0 + x1 + 1.
before = counts['cases']
for q in (2, 3, 5, 13):
    base = [[-1,-1,1,0,1],[-2,-1,0,1,1]]
    # Higher ambient-rank predicates can have restricted rank one, zero, or two.
    options = [[], [[0,0,0,0,1]], base, [[1,0,0,0,1]], [[1,0,0,0,1]] + base,
               [[1,0,0,0,1],[0,1,0,0,0]], [[0,0,1,0,0]], [[0,0,0,1,1]],
               [[1,0,0,0,0],[1,0,0,0,1]]]
    for r in range(min(q, 3)):
        for chosen in itertools.combinations_with_replacement(options, r):
            for c in ([1,0,0,0], [0,0,1,0], [0,0,0,1], [-1,-1,1,0], [0,0,0,0]):
                check(base, list(chosen), c, 4, q)
coverage['translated_embedded_Fq4'] = counts['cases'] - before

# Arbitrary-r inclusion-exclusion: beyond the small-union boundary, duplicates,
# inconsistent systems, crossing cuts, translated base, and zero scalar maps.
rng = random.Random(731092)
before = counts['cases']
for q in (2, 3, 5):
    for r in (q, q+1, q+2):
        for rep in range(20):
            def eqs():
                return [[rng.randrange(q) for _ in range(3)] for _ in range(rng.randrange(4))]
            base = eqs()
            forbidden = [eqs() for _ in range(r)]
            if rep % 3 == 0:
                forbidden[-1] = forbidden[0]
            check(base, forbidden, [rng.randrange(q), rng.randrange(q)], 2, q)
coverage['arbitrary_r_IE'] = counts['cases'] - before

# Guard at q=13 (producer's q=13 boundary branch enumerates without calling API).
for forbidden in ([[[1,0,t]] for t in range(13)], [[[1,0,0],[0,1,t]] for t in range(13)]):
    for name, args in [('image_small', ([], forbidden, [1,0], 2, 13)), ('witness_small', ([], forbidden, [1,0], 0, 2, 13))]:
        try:
            ns[name](*args)
        except ValueError:
            counts['guard_checks'] += 1
        else:
            raise AssertionError(('missing guard', name, 13))

# Document prototype boundary: no explicit primality or dimension validation.
unsupported = {
    'composite_q4_not_rejected': sorted(ns['image_small']([], [], [1], 1, 4)),
    'malformed_scalar_length_not_rejected': sorted(ns['image_small']([], [], [1,99], 1, 3)),
}
result = {'status': 'PASS_WITH_INTEGRATION_GATES', 'producer_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'coverage': coverage, **counts,
          'unsupported_input_observations': unsupported,
          'cpu_seconds': time.process_time() - start, 'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          'limits': {'cpu_seconds': 60, 'address_space_mib': 512},
          'scope': 'fresh independent finite affine toys; no K4 data, old holdouts, remote writes, or producer edits'}
print(json.dumps(result, indent=2))
