#!/usr/bin/env python3
"""Fresh toy prototype; prime fields only, no cryptanalytic data."""
import itertools as it, random, json, time, resource
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
START=time.process_time()
def dot(a,b,q): return sum(x*y for x,y in zip(a,b))%q
def solve(rows,n,q):
    a=[[v%q for v in row] for row in rows]; piv=[]; k=0
    for j in range(n):
        h=next((h for h in range(k,len(a)) if a[h][j]),None)
        if h is None: continue
        a[k],a[h]=a[h],a[k]; inv=pow(a[k][j],-1,q)
        a[k]=[(v*inv)%q for v in a[k]]
        for h in range(len(a)):
            if h!=k:
                c=a[h][j]; a[h]=[(u-c*v)%q for u,v in zip(a[h],a[k])]
        piv.append(j); k+=1
    if any(not any(row[:n]) and row[n] for row in a): return None
    b=[0]*n
    for h,j in enumerate(piv): b[j]=a[h][n]
    basis=[]
    for j in range(n):
        if j not in piv:
            v=[0]*n; v[j]=1
            for h,p in enumerate(piv): v[p]=-a[h][j]%q
            basis.append(v)
    return b,basis

def restrict(rows,space,q):
    b,N=space
    return [[dot(row[:-1],v,q) for v in N]+[(row[-1]-dot(row[:-1],b,q))%q] for row in rows]
def contains(rows,space,q):
    return all(not any(row) for row in restrict(rows,space,q))
def val(c,x,q): return dot(c,x,q)
def satisfies(rows,x,q): return all(dot(row[:-1],x,q)==row[-1]%q for row in rows)
def image_small(base, forbidden, c,n,q):
    if len(forbidden)>=q: raise ValueError('small-union condition violated')
    V=solve(base,n,q)
    if V is None or any(contains(w,V,q) for w in forbidden): return set()
    b,N=V; h=[dot(c,v,q) for v in N]; c0=dot(c,b,q)
    if not any(h): return {c0}
    removed=set()
    for w in forbidden:
        rw=restrict(w,V,q); D=solve(rw,len(N),q)
        if D is None: continue
        a,K=D
        # Nonempty proper codimension-one cut with kernel equal to ker(h).
        if len(K)==len(N)-1 and all(dot(h,v,q)==0 for v in K):
            removed.add((c0+dot(h,a,q))%q)
    return set(range(q))-removed

def witness_small(base,forbidden,c,t,n,q):
    if len(forbidden)>=q: raise ValueError('small-union condition violated')
    V=solve(base+[list(c)+[t]],n,q)
    if V is None or any(contains(w,V,q) for w in forbidden): return None
    b,N=V; d=len(N); rows=[restrict(w,V,q) for w in forbidden]; chosen=[]
    for j in range(d):
        bad=[]
        for u in range(q):
            # Slice in free z variables with prefix fixed; remaining basis is standard.
            a=chosen+[u]+[0]*(d-j-1)
            K=[[int(k==h) for k in range(d)] for h in range(j+1,d)]
            if any(contains(w,(a,K),q) for w in rows): bad.append(u)
        assert len(bad)<=len(forbidden)
        chosen.append(next(u for u in range(q) if u not in bad))
    x=[(b[k]+sum(chosen[j]*N[j][k] for j in range(d)))%q for k in range(n)]
    assert satisfies(base,x,q) and dot(c,x,q)==t and all(not satisfies(w,x,q) for w in forbidden)
    return x

def count_ie(base, forbidden,c,n,q):
    counts=[0]*q
    for mask in range(1<<len(forbidden)):
        rows=base+[row for j,w in enumerate(forbidden) if mask>>j&1 for row in w]
        V=solve(rows,n,q)
        if V is None: continue
        b,N=V; sign=(-1)**mask.bit_count(); d=len(N)
        if any(dot(c,v,q) for v in N):
            for t in range(q): counts[t]+=sign*q**(d-1)
        else: counts[dot(c,b,q)]+=sign*q**d
    assert all(v>=0 for v in counts)
    return counts

def check(base,forbidden,c,n,q):
    counts=[0]*q
    for x in it.product(range(q),repeat=n):
        if satisfies(base,x,q) and all(not satisfies(w,x,q) for w in forbidden): counts[dot(c,x,q)]+=1
    assert count_ie(base,forbidden,c,n,q)==counts
    expected={t for t,k in enumerate(counts) if k}
    witnesses=0
    if len(forbidden)<q:
        assert image_small(base,forbidden,c,n,q)==expected
        for t in range(q):
            w=witness_small(base,forbidden,c,t,n,q)
            assert (w is not None)==(t in expected)
            witnesses+=w is not None
    else:
        try: image_small(base,forbidden,c,n,q)
        except ValueError: pass
        else: raise AssertionError('guard omitted')
    return witnesses

rng=random.Random(947321); total=0; witnesses=0; breakdown={}
for q in (2,3,5,13):
    for n in range(4):
        for repeat in range(75):
            def rr(): return [rng.randrange(q) for _ in range(n+1)]
            base=[rr() for _ in range(rng.randrange(n+2))]
            r=rng.randrange(min(q+1,5))
            forbidden=[[rr() for _ in range(rng.randrange(n+2))] for _ in range(r)]
            c=[rng.randrange(q) for _ in range(n)]
            witnesses+=check(base,forbidden,c,n,q); total+=1
            breakdown[str(q)]=breakdown.get(str(q),0)+1
# Exhaust every distinct affine subset (plus empty) of F3^2, all pairs, all ell.
q=3;n=2;points=list(it.product(range(q),repeat=n)); candidates={}
for rows in [[]]+[[list(a)+[t]] for a in points for t in range(q)]+[[[1,0,x],[0,1,y]] for x,y in points]:
    key=tuple(x for x in points if satisfies(rows,x,q)); candidates.setdefault(key,rows)
sets=list(candidates.values()); exhaustive=0
for w1,w2 in it.combinations_with_replacement(sets,2):
    for c in points:
        witnesses+=check([], [w1,w2],c,n,q); total+=1;exhaustive+=1
# Adversaries: q lines cover V; q points cover one fiber, no set contains it.
adversaries=[]
for q in (2,3,5,13):
    for forbidden in ([[[1,0,t]] for t in range(q)], [[[1,0,0],[0,1,t]] for t in range(q)]):
        if q==13: # Avoid exponential IE here: exact enumeration fallback.
            allowed=[x for x in it.product(range(q),repeat=2) if all(not satisfies(w,x,q) for w in forbidden)]
            actual=sorted({x[0] for x in allowed})
            assert actual in ([],list(range(1,q)))
        else:
            witnesses+=check([],forbidden,[1,0],2,q);total+=1
            actual=[t for t,k in enumerate(count_ie([],forbidden,[1,0],2,q)) if k]
        adversaries.append({'q':q,'forbidden_count':len(forbidden),'image':actual})
# r=q-1 sharp bound: remove q-1 parallel fibers, singleton remains.
for q in (2,3,5,13):
    forbidden=[[[1,0,t]] for t in range(q-1)]
    assert image_small([],forbidden,[1,0],2,q)=={q-1}
    assert witness_small([],forbidden,[1,0],q-1,2,q) is not None
    witnesses+=1
result={'status':'PASS','random_cases':1200,'random_by_prime':breakdown,'distinct_affine_sets_F3_2_including_empty':len(sets),'exhaustive_pair_projection_cases':exhaustive,'crosschecked_cases_total':total,'verified_witnesses':witnesses,'boundary_adversaries':adversaries,'sharp_bound_cases':4,'cpu_seconds':time.process_time()-START,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limits':{'cpu_seconds':90,'address_space_mib':512},'scope':'fresh general affine toys only; prime-field implementation; no target data'}
print(json.dumps(result,indent=2))
