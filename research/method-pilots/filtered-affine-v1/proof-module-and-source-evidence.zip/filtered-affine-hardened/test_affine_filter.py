import itertools as it,json,random,resource,time
from affine_filter import project_filtered_affine as project,Budget,CertificateError,solve,Meter
resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
start=time.process_time();cases=0;witnesses=0;invalid=0;budgets=0;routes={}
def check(q,n,base,forbidden,scalars):
    global cases,witnesses
    def sat(rows,x):return all(sum(row[j]*x[j] for j in range(n))%q==row[-1] for row in rows)
    pts=[x for x in it.product(range(q),repeat=n) if sat(base,x) and not any(sat(w,x) for w in forbidden)]
    expected=[sorted({sum(c[j]*x[j] for j in range(n))%q for x in pts}) for c in scalars]
    r=project(q,n,base,forbidden,scalars)
    if r['status']!=('EXACT' if pts else 'EMPTY') or r['masks']!=expected:raise RuntimeError((q,n,base,forbidden,scalars,r,expected))
    routes[r['route']]=routes.get(r['route'],0)+1
    if pts:
        if tuple(r['feasibility_witness']) not in pts:raise RuntimeError('feasibility')
        for c,mask,ws in zip(scalars,r['masks'],r['witnesses']):
            if sorted(ws)!=mask:raise RuntimeError('witness coverage')
            for t,x in ws.items():
                if tuple(x) not in pts or sum(c[j]*x[j] for j in range(n))%q!=t:raise RuntimeError('witness')
                witnesses+=1
    cases+=1
rng=random.Random(718293)
for q in (2,3,5,13):
    for n in range(4):
        for _ in range(30):
            rr=lambda:[rng.randrange(q) for _ in range(n+1)]
            base=[rr() for _ in range(rng.randrange(n+2))]
            forbidden=[[rr() for _ in range(rng.randrange(n+2))] for _ in range(rng.randrange(5))]
            scalars=[[rng.randrange(q) for _ in range(n)] for _ in range(3)]
            check(q,n,base,forbidden,scalars)
# Every affine subset of F2^2, all bases, all pairs, ALL scalar maps.
q=2;n=2;pts=list(it.product(range(q),repeat=n));sets={}
sat=lambda rows,x:all(sum(row[j]*x[j] for j in range(n))%q==row[-1] for row in rows)
for rows in [[]]+[[list(a)+[t]] for a in pts for t in range(q)]+[[[1,0,x],[0,1,y]] for x,y in pts]:sets.setdefault(tuple(x for x in pts if sat(rows,x)),rows)
for base in sets.values():
    for pair in it.combinations_with_replacement(sets.values(),2):check(2,2,base,pair,pts)
# Explicit translated/embedded systems and restricted rank defects.
for q in (2,3,5,13):
    base=[[q-1,q-1,1,0,1],[q-1,(-2)%q,0,1,1]]
    for forbs in ([],[base],[base,base],[[[1,0,0,0,1]]],[[[0,0,0,0,1]]],[[[1,0,0,0,t]] for t in range(min(q,5))]):
        check(q,4,base,forbs,[[1,0,0,0],[0,0,1,0],[0,0,0,0]])
    check(q,0,[],[],[[]]);check(q,0,[],[[]],[[]]);check(q,0,[[1]],[],[[]]);check(q,1,[],[],[])
    check(q,2,[],[[[1,0,0],[0,1,t]] for t in range(min(q,5))],[[1,0],[0,1]])
# malformed values must raise before output; bool is not a field integer.
valid=[3,1,[],[],[[1]]]
mutations=[(0,4),(0,1),(0,True),(0,3.0),(0,65523),(1,-1),(1,True),(1,65),(2,[[0]]),(2,[[0,3]]),(2,[[0,-1]]),(2,[[0,False]]),(2,[[0,0.0]]),(3,[None]),(4,[[1,99]]),(4,[[True]]),(4,[[3]]),(4,(x for x in [])),(2,{'x':1})]
for j,x in mutations:
    args=valid[:];args[j]=x
    try:project(*args)
    except ValueError:invalid+=1
    else:raise RuntimeError('invalid accepted')
for b in (Budget(max_work=True),Budget(max_seconds=float('nan')),Budget(max_seconds=float('inf')),Budget(max_terms=-1)):
    try:project(*valid,budget=b)
    except ValueError:invalid+=1
    else:raise RuntimeError('budget invalid accepted')
# Distinguish preflight exhaustion, runtime exhaustion and successful exactness.
for b in (Budget(max_work=0),Budget(max_solves=0),Budget(max_seconds=0),Budget(max_work=25),Budget(max_solves=2),Budget(max_terms=1)):
    r=project(3,2,[],[[[1,0,t]] for t in range(3)],[[0,1]],b)
    if r['status']!='INCOMPLETE' or r['masks'] is not None or r['evidence'] is not None:raise RuntimeError(('budget',b,r))
    budgets+=1
# Counting preflight: enough solves/subsets but not q*2^r accumulation.
r=project(13,1,[],[[[0,1]]]*13,[[1]],Budget(max_work=10000))
if r['status']!='INCOMPLETE' or r['reason']!='count preflight':raise RuntimeError(r)
budgets+=1
# Runtime fallback witness exhaustion after main IE completes, not false EXACT.
r=project(2,1,[],[[[0,1]],[[0,1]]],[[1]],Budget(max_solves=5))
if r['status']!='INCOMPLETE' or r['masks'] is not None:raise RuntimeError(r)
budgets+=1
print(json.dumps({'status':'PASS','cases':cases,'returned_witnesses_checked':witnesses,'malformed_rejections':invalid,'budget_checks':budgets,'routes':routes,'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'optimized_python':not __debug__},indent=2))
