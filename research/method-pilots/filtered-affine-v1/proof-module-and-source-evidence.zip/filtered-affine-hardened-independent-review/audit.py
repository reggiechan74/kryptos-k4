import copy, hashlib, importlib.util, itertools as it, json, random, resource, sys, time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
source=Path('/workspace/shared/filtered-affine-hardened/affine_filter.py')
spec=importlib.util.spec_from_file_location('audit_target',source);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
started=time.process_time();counts={'valid_cases':0,'witnesses':0,'elimination_certificates':0,'malformed_rejections':0,'budget_checks':0,'tamper_rejections':0};routes={}
def req(ok,msg='audit mismatch'):
    if not ok:raise RuntimeError(msg)
def dot(c,x,q):return sum(c[j]*x[j] for j in range(len(x)))%q
def sat(rows,x,q):return all(dot(row[:-1],x,q)==row[-1] for row in rows)
def affine(n,q):
    points=frozenset(it.product(range(q),repeat=n));seen={points:[]};todo=[points]
    planes=[list(row)+[t] for row in it.product(range(q),repeat=n) if any(row) for t in range(q)]
    while todo:
        old=todo.pop()
        for row in planes:
            new=frozenset(x for x in old if sat([row],x,q))
            if new not in seen:seen[new]=seen[old]+[row];todo.append(new)
    return seen

def replay(rows,n,q,cert):
    """Independent completeness verifier: never invokes producer linear algebra."""
    counts['elimination_certificates']+=1
    a=[list(row) for row in rows]
    for op in cert['operations']:
        req(op[0] in ('swap','scale','add'),'operation kind')
        req(type(op[1]) is int and 0<=op[1]<len(a),'operation row')
        if op[0]=='swap':
            req(len(op)==3 and type(op[2]) is int and 0<=op[2]<len(a),'swap')
            a[op[1]],a[op[2]]=a[op[2]],a[op[1]]
        elif op[0]=='scale':
            req(len(op)==3 and type(op[2]) is int and 0<op[2]<q,'scale')
            a[op[1]]=[x*op[2]%q for x in a[op[1]]]
        else:
            req(len(op)==4 and type(op[2]) is int and 0<=op[2]<len(a) and op[1]!=op[2],'add row')
            req(type(op[3]) is int and 0<=op[3]<q,'add coefficient')
            a[op[1]]=[(x+op[3]*y)%q for x,y in zip(a[op[1]],a[op[2]])]
    req(a==cert['rref'],'replayed RREF')
    piv=cert['pivots'];req(piv==sorted(set(piv)) and all(type(j) is int and 0<=j<n for j in piv),'pivots')
    req(len(piv)<=len(a),'rank')
    for i,p in enumerate(piv):
        req(a[i][p]==1 and not any(a[i][:p]),'leading pivot')
        req(all(a[h][p]==int(h==i) for h in range(len(a))),'reduced pivot')
    req(all(not any(row[:n]) for row in a[len(piv):]),'residual rank')
    if any(not any(row[:n]) and row[n] for row in a):return None
    free=[j for j in range(n) if j not in piv];b=[0]*n
    for i,p in enumerate(piv):b[p]=a[i][n]
    N=[]
    for f in free:
        v=[0]*n;v[f]=1
        for i,p in enumerate(piv):v[p]=-a[i][f]%q
        N.append(v)
    req(sat(rows,b,q),'particular')
    req(all(dot(row[:n],v,q)==0 for row in rows for v in N),'kernel')
    return b,N

def verify(q,n,base,forbidden,scalars,result):
    req(result['version']==mod.VERSION,'version')
    identity=hashlib.sha256(json.dumps([mod.VERSION,q,n,base,forbidden,scalars],separators=(',',':')).encode()).hexdigest()
    req(result['instance_sha256']==identity,'identity')
    route='small-union' if len(forbidden)<q else 'inclusion-exclusion';req(result['route']==route,'route')
    if result['status']=='INCOMPLETE':
        req(result['masks'] is None and result['witnesses'] is None and result['evidence'] is None,'incomplete leak');return
    req(result['status'] in ('EXACT','EMPTY'),'status')
    e=result['evidence'];req(e['q']==q and e['r']==len(forbidden),'evidence guard')
    V=replay(base,n,q,e['base']);queries=list(scalars)+[[0]*n]
    empty=V is None;expected=None
    if V is not None and route=='small-union':
        a,N=V;cuts=[];req(len(e['cuts'])<=len(forbidden),'extra cuts')
        for i,cut in enumerate(e['cuts']):
            reduced=[[dot(row[:-1],v,q) for v in N]+[(row[-1]-dot(row[:-1],a,q))%q] for row in forbidden[i]]
            req([list(row) for row in cut['restricted']]==reduced,'restriction')
            D=replay(reduced,len(N),q,cut['solve']);cuts.append(D)
            if D is not None and len(D[1])==len(N):empty=True
        if not empty:
            req(len(cuts)==len(forbidden),'missing cut')
            req(len(e['projections'])==len(queries),'projection coverage');expected=[]
            for c,pr in zip(queries,e['projections']):
                h=[dot(c,v,q) for v in N];offset=dot(c,a,q);req(pr['h']==h and pr['offset']==offset,'scalar restriction')
                removed=[]
                if any(h):
                    pivot=next(i for i,v in enumerate(h) if v)
                    for i,D in enumerate(cuts):
                        if D is None:continue
                        p,K=D
                        if len(K)==len(N)-1 and all(dot(h,v,q)==0 for v in K):
                            t=(offset+dot(h,p,q))%q;rows=e['cuts'][i]['restricted'];u=[row[pivot]*pow(h[pivot],-1,q)%q for row in rows]
                            req(any(u),'normal')
                            req(all(row[j]==u[k]*h[j]%q for k,row in enumerate(rows) for j in range(len(h))),'normal identity')
                            req(all(row[-1]==u[k]*(t-offset)%q for k,row in enumerate(rows)),'offset identity')
                            removed.append({'cut':i,'value':t,'multipliers':u})
                req(pr['removed']==removed,'complete removed list')
                expected.append([t for t in range(q) if t not in {x['value'] for x in removed}] if any(h) else [offset])
    elif V is not None:
        req(len(e['terms'])==1<<len(forbidden),'subset coverage');total=0;cs=[[0]*q for c in queries]
        for mask,entry in enumerate(e['terms']):
            req(entry['subset']==mask,'subset identity')
            rows=list(base)+[row for j,w in enumerate(forbidden) if mask>>j&1 for row in w]
            S=replay(rows,n,q,entry['solve']);req(entry['empty']==(S is None),'subset emptiness')
            if S is None:continue
            a,N=S;d=len(N);sign=-1 if mask.bit_count()%2 else 1;total+=sign*q**d;projections=[]
            for j,c in enumerate(queries):
                if any(dot(c,v,q) for v in N):
                    for t in range(q):cs[j][t]+=sign*q**(d-1)
                    projections.append({'full':True,'dimension':d})
                else:
                    t=dot(c,a,q);cs[j][t]+=sign*q**d;projections.append({'value':t,'dimension':d})
            req(entry['projections']==projections,'subset scalar classification')
        req(e['counts']==cs and e['total']==total,'complete inclusion-exclusion')
        req(total>=0 and all(v>=0 for row in cs for v in row),'negative counts');empty=total==0
        expected=[[t for t,v in enumerate(row) if v] for row in cs]
    req((result['status']=='EMPTY')==empty,'empty claim')
    if empty:
        req(result['masks']==[[] for c in scalars] and result['witnesses']==[{} for c in scalars],'empty result');return
    req(result['masks']==expected[:-1],'complete masks');req(expected[-1]==[0],'probe')
    req(len(result['witnesses'])==len(scalars),'witness coverage')
    for c,mask,ws in zip(scalars,result['masks'],result['witnesses']):
        req(sorted(ws)==mask,'witness keys')
        for t,x in ws.items():
            req(len(x)==n and all(type(v) is int and 0<=v<q for v in x),'witness domain')
            req(sat(base,x,q) and all(not sat(w,x,q) for w in forbidden) and dot(c,x,q)==t,'witness');counts['witnesses']+=1
    x=result['feasibility_witness'];req(len(x)==n and sat(base,x,q) and all(not sat(w,x,q) for w in forbidden),'feasibility')

def check(q,n,base,forbidden,scalars,known=None):
    if known is None:known={x for x in it.product(range(q),repeat=n) if sat(base,x,q) and all(not sat(w,x,q) for w in forbidden)}
    r=mod.project_filtered_affine(q,n,base,forbidden,scalars)
    expected=[sorted({dot(c,x,q) for x in known}) for c in scalars]
    req(r['status']==('EXACT' if known else 'EMPTY') and r['masks']==expected,'oracle')
    verify(q,n,base,forbidden,scalars,r);counts['valid_cases']+=1;routes[r['route']]=routes.get(r['route'],0)+1
    return r

coverage={}
for q,n,max_r in [(2,3,1),(3,2,2)]:
    entries=list(affine(n,q).items());before=counts['valid_cases'];scalars=[list(c) for c in it.product(range(q),repeat=n)]
    for V,base in entries:
        for r in range(max_r+1):
            for choice in it.combinations_with_replacement(entries,r):
                forbidden=[w for _,w in choice];survivors=set(V)
                for W,_ in choice:survivors.difference_update(W)
                check(q,n,base,forbidden,scalars,survivors)
    coverage[f'all_affine_F{q}_{n}']=counts['valid_cases']-before
# Independent fallback cases, including every F2^2 base and pair of cuts.
entries=list(affine(2,2).items());before=counts['valid_cases']
for V,base in entries:
    for choice in it.combinations_with_replacement(entries,2):
        survivors=set(V)
        for W,_ in choice:survivors.difference_update(W)
        check(2,2,base,[w for _,w in choice],[[0,0],[1,0],[0,1],[1,1]],survivors)
coverage['all_affine_F2_2_IE']=counts['valid_cases']-before
rng=random.Random(561048);before=counts['valid_cases']
for q in (2,3,5,13):
    for n in range(4):
        for _ in range(20):
            eq=lambda:[[rng.randrange(q) for _ in range(n+1)] for _ in range(rng.randrange(n+2))]
            check(q,n,eq(),[eq() for _ in range(rng.randrange(6))],[[rng.randrange(q) for _ in range(n)] for _ in range(3)])
    check(q,2,[],[[[1,0,t]] for t in range(q)],[[1,0],[0,1]])
    if q<13:check(q,2,[],[[[1,0,0],[0,1,t]] for t in range(q)],[[1,0],[0,1]])
    check(q,0,[],[],[]);check(q,0,[],[[]],[]);check(q,0,[[1]],[],[])
coverage['seeded_and_edges']=counts['valid_cases']-before
# Expanded malformed domains. Inputs stay bounded.
valid=[3,1,[],[],[[1]]]
mutations=[(0,x) for x in (0,1,-2,4,9,65522,65523,True,False,3.0,None,'3')]+[(1,x) for x in (-1,65,True,1.0,None)]+[(2,x) for x in ([[0]],[[0,0,0]],[[0,-1]],[[0,3]],[[0,True]],[[0,0.0]],None,{},[[]])]+[(3,x) for x in ([None],[[[0]]],{},[[]]*257)]+[(4,x) for x in ([[1,99]],[[True]],[[3]],[[0.0]],[[0]]*257,{})]
for j,x in mutations:
    args=valid[:];args[j]=x
    try:mod.project_filtered_affine(*args)
    except ValueError:counts['malformed_rejections']+=1
    else:raise RuntimeError(('accepted malformed',j,x))
for b in (None,{},mod.Budget(max_work=True),mod.Budget(max_solves=1.0),mod.Budget(max_terms=-1),mod.Budget(max_work=10**12+1),mod.Budget(max_seconds=float('nan')),mod.Budget(max_seconds=float('inf')),mod.Budget(max_seconds=-1),mod.Budget(max_seconds=True)):
    try:mod.project_filtered_affine(*valid,budget=b)
    except ValueError:counts['malformed_rejections']+=1
    else:raise RuntimeError('accepted bad budget')
# Sweep bounded budgets. Any successful claim must carry complete evidence.
args=(2,2,[],[[[0,0,1]],[[1,0,0]]],[[1,0],[0,1]])
for field,values in [('max_work',(0,1,10,100,500,1000,2000,10000)),('max_solves',range(30)),('max_terms',range(33)),('max_seconds',(0,))]:
    for value in values:
        b=mod.Budget(**{field:value});r=mod.project_filtered_affine(*args,budget=b);verify(*args,r)
        req(r['resources']['work']<=b.max_work and r['resources']['solves']<=b.max_solves and r['resources']['terms']<=b.max_terms,'budget exceeded');counts['budget_checks']+=1
# Per-call IE count preflight and huge-but-valid forbidden count must fail closed.
for args,b in [((13,1,[],[[[0,1]]]*13,[[1]]),mod.Budget(max_work=10000)),((2,0,[],[[1]]*256,[[]]),mod.Budget())]:
    # Each forbidden must be a system (list of rows).
    if len(args[3])==256:args=(2,0,[],[[[1]]]*256,[[]])
    r=mod.project_filtered_affine(*args,budget=b);req(r['status']=='INCOMPLETE','preflight');verify(*args,r);counts['budget_checks']+=1
# Independent evidence verifier rejects missing, altered, or partial claims.
small_args=(3,2,[],[[[1,0,0]]],[[1,0],[0,1]])
ie_args=(2,2,[],[[[1,0,0]],[[0,0,1]]],[[0,1]])
small=mod.project_filtered_affine(*small_args);big=mod.project_filtered_affine(*ie_args)
mutants=[]
r=copy.deepcopy(small);r['evidence']['cuts']=[];mutants.append((small_args,r))
r=copy.deepcopy(small);r['masks'][0]=[0,1,2];mutants.append((small_args,r))
r=copy.deepcopy(small);r['evidence']['projections'][0]['removed']=[];mutants.append((small_args,r))
r=copy.deepcopy(small);r['evidence']['cuts'][0]['solve']['operations'].append(('scale',0,0));mutants.append((small_args,r))
r=copy.deepcopy(big);r['evidence']['terms'].pop();mutants.append((ie_args,r))
r=copy.deepcopy(big);r['evidence']['counts'][0][0]+=1;mutants.append((ie_args,r))
r=copy.deepcopy(big);r['evidence']['terms'][0]['solve']['pivots']=[0];mutants.append((ie_args,r))
r=copy.deepcopy(big);r['instance_sha256']='0'*64;mutants.append((ie_args,r))
for args,r in mutants:
    try:verify(*args,r)
    except (RuntimeError,IndexError,KeyError):counts['tamper_rejections']+=1
    else:raise RuntimeError('forged certificate accepted')
result={'status':'PASS','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'optimized_python':not __debug__,'coverage':coverage,**counts,'routes':routes,'cpu_seconds':time.process_time()-started,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limits':{'cpu_seconds':90,'address_space_mib':512},'scope':'fresh generic affine toys and independent evidence replay only; no canonical compiler, target, holdout, or producer edits'}
print(json.dumps(result,indent=2))
