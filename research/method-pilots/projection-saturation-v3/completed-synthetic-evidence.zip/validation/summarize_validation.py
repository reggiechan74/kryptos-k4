"""Descriptive reporting only, after frozen scientific analysis has passed."""
import collections, hashlib, json, pathlib, statistics
P=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-validation')
O=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-results')
I=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-input')
C=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-custody')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=read(P/'frozen-analysis.json');gate=read(P/'RELEASE-GATE.json')
assert a['status']=='PASS' and a['cases']==40 and a['outputs_verified']==480
assert gate['status']=='PASS_RELEASE_AUTHORIZED'
assert a['truth_sha256']==sha(C/'secret-truth.json')==gate['truth_sha256']
truth={x['id']:x for x in read(C/'secret-truth.json')['cases']}
def distribution(vals):
    vals=sorted(vals)
    def quantile(q):
        x=(len(vals)-1)*q;lo=int(x);hi=min(lo+1,len(vals)-1)
        return vals[lo]+(vals[hi]-vals[lo])*(x-lo)
    return {'n':len(vals),'min':vals[0],'q25':quantile(.25),'median':quantile(.5),'q75':quantile(.75),'max':vals[-1]}
summaries={};details=[];phases={};statuses={};resource_peaks={};hidden=[]
groups=['ALL','IN_FAMILY_PLANTED','CONTRADICTION_CONTROLS','DEPENDENT_TWINS']+sorted({r['stratum'] for r in a['paired']})+[f'ordinary-weight-{i}' for i in range(4)]
def included(r,g):
    return (g=='ALL' or g==r['stratum'] or g=='IN_FAMILY_PLANTED' and r['stratum'] not in ('contradiction','misspecified') or g=='CONTRADICTION_CONTROLS' and r['stratum']=='contradiction' or g=='DEPENDENT_TWINS' and r['dependent_twin'] or g.startswith('ordinary-weight-') and r['id'].startswith('ordinary-w'+g[-1]+'-') and not r['dependent_twin'])
for m in ('crt','parity'):
    for group in groups:
        rr=[r for r in a['paired'] if r['method']==m and included(r,group)]
        key=m+'/'+group;summaries[key]={'cases':len(rr),'costs':{}}
        for metric in ('charged_child_cpu','charged_stage_cpu','checked_cpu','kernel_cpu'):
            off=[r['arms']['0']['median_'+metric] for r in rr];on=[r['arms']['1']['median_'+metric] for r in rr]
            delta=[y-x for x,y in zip(off,on)]
            ratios=[100*(y/x-1) for x,y in zip(off,on) if x>0]
            summaries[key]['costs'][metric]={'sum_off_case_medians':sum(off),'sum_on_case_medians':sum(on),
                'aggregate_percent_change':100*(sum(on)/sum(off)-1) if sum(off)>0 else None,
                'wins':sum(d<0 for d in delta),'ties':sum(d==0 for d in delta),'losses':sum(d>0 for d in delta),
                'paired_delta_seconds':distribution(delta),'paired_percent_change':distribution(ratios) if ratios else None}
        for on in (0,1):
            arm=f'{key}/{on}';counter=collections.Counter();phase=collections.defaultdict(float);peaks=[]
            for r in rr:
                counter.update(r['arms'][str(on)]['statuses'])
                peaks.append(r['arms'][str(on)]['peak_rss_kib'])
                for k,v in r['arms'][str(on)]['median_phase_cpu'].items():phase[k]+=v
            statuses[arm]={'total_runs':3*len(rr),'run_counts':dict(counter),'case_counts':{k:v/3 for k,v in counter.items()},'run_rates':{k:v/(3*len(rr)) for k,v in counter.items()}}
            phases[arm]=dict(phase);resource_peaks[arm]=max(peaks)
for idx,ref in enumerate(a['oracle']):
    label=truth[ref['id']];r=ref['result'];unknown=[i for i in range(91) if str(i+6) not in label['instance']['observed']]
    excluded=[];wrong_forced=[]
    if label['truth'] is not None:
        for j in unknown:
            if not r['masks'][j]>>label['truth'][j]&1:
                rec={'position_zero_based':j+6,'truth':label['truth'][j],'allowed_values':[v for v in range(26) if r['masks'][j]>>v&1]}
                excluded.append(rec)
                if r['masks'][j].bit_count()==1:wrong_forced.append(rec)
    hidden.append({'id':ref['id'],'stratum':label['stratum'],'source_id':label.get('source_id'),'feasible':r['feasible'],
        'unknown_positions':len(unknown),'forced_unknown':sum(r['masks'][j].bit_count()==1 for j in unknown),
        'hidden_truth_outside_masks':excluded,'wrong_forced':wrong_forced,'truth_present':label['truth'] is not None,
        'marginal_cardinality_counts':dict(collections.Counter(x.bit_count() for x in r['masks']))})
for idx,item in enumerate(read(I/'solver-input.json')['cases']):
    for m in ('crt','parity'):
        for on in (0,1):
            raw=[read(O/f'{idx:02d}-{m}-{on}-{rep}.resource.json') for rep in range(3)]
            rs=[read(O/f'{idx:02d}-{m}-{on}-{rep}.json')['result'] for rep in range(3)]
            assert len({x['status'] for x in rs})==1
            details.append({'id':item['id'],'method':m,'saturation':bool(on),'status':rs[0]['status'],
                'charged_child_cpu':distribution([x['child_cpu_seconds'] for x in raw]),
                'charged_stage_cpu':distribution([x['child_cpu_seconds']+x['parent_cpu_seconds'] for x in raw]),
                'checked_cpu':distribution([x['fully_checked_cpu'] for x in rs]),
                'support_counts':[x['stats']['supports'] for x in rs],
                'child_peak_rss_kib':max(x['child_peak_rss_kib'] for x in raw),
                'supervisor_peak_rss_kib':max(x['parent_peak_rss_kib'] for x in raw)})
report={'status':'PASS_DESCRIPTIVE_REPORT','frozen_analysis_sha256':sha(P/'frozen-analysis.json'),
    'quantiles':'Linear interpolation at q*(n-1); descriptive only; correlated twins not independent observations.',
    'summaries':summaries,'statuses':statuses,'sum_case_median_phase_cpu':phases,
    'peak_solver_rss_kib':resource_peaks,'per_arm_repeat_spread':details,'exact_hidden_truth_results':hidden,
    'warnings':['Receipt child and child+supervisor CPU are primary; checked/kernel/phase metrics exclude some process overhead.',
    'All timing distributions are descriptive paired case medians with only three repetitions, not confidence intervals.',
    'Mixture deliberately includes alias and contradiction strata. No universal speedup, recovery gain, model membership, joint relation, or K4 target admission follows.',
    'Near-clock-granularity measurements and small paired differences are not robust standalone speedup evidence.',
    'Twins share solver inputs with source cases; exclude from independent in-family metrics.']}
with (P/'descriptive-results.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
lines=['# Fresh synthetic projection-saturation v3 holdout — validated',
'',f"**Correctness PASS:** all {a['outputs_verified']} outputs matched the independent complete maximal-support oracle; {a['witnesses_verified']:,} original-coordinate per-value witnesses and {a['certificates_verified']} certificates verified.",
'','Exactly one fresh 256-bit draw, 40 fixed cases and 480 interleaved runs (four arms, three repetitions). This is a synthetic conditional-model test, not a K4 run. Original sources were frozen before drawing; truth was released only after independently checking all output/resource and post-run seals. Custody was operational on a shared filesystem, not access-control blindness.',
'','## Primary charged timing','',
'Sums of paired case-median CPU seconds, not median speedups. Child costs include interpreter startup/import and final output serialization/write; stage costs additionally include the bounded supervisor. Wins count strictly lower on-cost and do not establish statistical significance.','',
'| Method / stratum | Cases | Child off → on (s) | Stage off → on (s) | Stage wins / losses / ties | Stage change |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for m in ('crt','parity'):
    for g in ['ALL','IN_FAMILY_PLANTED','ordinary','constant','periodic','binary','even','zero-law','contradiction','misspecified']:
        r=summaries[m+'/'+g];ch=r['costs']['charged_child_cpu'];st=r['costs']['charged_stage_cpu']
        lines.append(f"| {m} / {g} | {r['cases']} | {ch['sum_off_case_medians']:.6f} → {ch['sum_on_case_medians']:.6f} | {st['sum_off_case_medians']:.6f} → {st['sum_on_case_medians']:.6f} | {st['wins']} / {st['losses']} / {st['ties']} | {st['aggregate_percent_change']:+.2f}% |")
lines+=['','## Status rates','', '| Method | Saturation arm | Enumerated | Saturated | Dense UNSAT |', '| --- | --- | ---: | ---: | ---: |']
for m in ('crt','parity'):
    for on in (0,1):
        s=statuses[f'{m}/ALL/{on}'];ct=s['run_counts']
        lines.append(f"| {m} | {'on' if on else 'off'} | {ct.get('ENUMERATED',0)}/120 | {ct.get('SATURATED',0)}/120 | {ct.get('DENSE_UNSAT',0)}/120 |")
lines+=['','Each case has three deterministic-status repetitions. Detailed rates by stratum, all paired distributions, component totals, support counts, process RSS and three-repeat spreads are in `descriptive-results.json` and the frozen analysis. No failed/capped stage was dropped.','',
'## Regression distribution','', 'Paired **on minus off** charged-stage CPU across case medians; negative is faster. Percent distributions retain small-baseline sensitivity.','',
'| Method / group | Min (s) | Q25 (s) | Median (s) | Q75 (s) | Max (s) | Median change | Worst change |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for m in ('crt','parity'):
    for g in ('ALL','IN_FAMILY_PLANTED','ordinary'):
        x=summaries[m+'/'+g]['costs']['charged_stage_cpu'];d=x['paired_delta_seconds'];pc=x['paired_percent_change']
        lines.append(f"| {m} / {g} | {d['min']:+.6f} | {d['q25']:+.6f} | {d['median']:+.6f} | {d['q75']:+.6f} | {d['max']:+.6f} | {pc['median']:+.2f}% | {pc['max']:+.2f}% |")
lines+=['','## Conditional correctness and dependent twins','']
family=[x for x in hidden if x['stratum'] not in ('contradiction','misspecified')]
lines.append(f"The {len(family)} in-family planted cases had {sum(len(x['wrong_forced']) for x in family)} wrong forced unknowns and {sum(len(x['hidden_truth_outside_masks']) for x in family)} hidden truths outside the exact masks. Four contradiction controls were correctly infeasible. The four dependent twins change a hidden response without changing solver input; they are not independent recovery evidence.")
lines+=['','| Dependent twin | Source case | Forced unknowns | Wrong forced unknowns | Hidden truth excluded by mask |','| --- | --- | ---: | ---: | ---: |']
for x in hidden:
    if x['stratum']=='misspecified':lines.append(f"| {x['id']} | {x['source_id']} | {x['forced_unknown']} | {len(x['wrong_forced'])} | {len(x['hidden_truth_outside_masks'])} |")
lines+=['','Wrong positions/true values/allowed values are retained in the JSON. Exact conditional marginals do not certify the true model, uniqueness of the law, Cartesian joint compatibility, or unmodeled positions 0–5.','',
'## Interpretation','',
'Retain saturation as an **optional, default-off tactic**, not a universal optimization or a recovery improvement. Describe benefits only for the measured strata and retain all overhead regressions. Aggregate numbers come from a deliberately structured mixture, not a representative workload estimate. Three repeats and small clock-quantized differences do not establish robust per-case speedups. This result does not admit a K4 target run or standalone-repository novelty claim.','',
'## Reproduction and custody','',
'`PROPOSED-FREEZE-MANIFEST.json` SHA256 `cdc5c7db8df5775817798653daa82f756a7dbdc7e41058884abd7e7e53b65b41`; `ANALYSIS-MANIFEST.json` SHA256 `4dea59eddf446019f8130cb3d8c66f2dff95e42dc33e8391d03d89fcd778be06`. Source, solver input, schedule, custody commitment, all raw results/receipts, release gate and frozen analysis are retained. No redraw, auto-resume or method correction occurred. See `RESOURCE-ACCOUNTING.json` for inclusive CPU accounting without descendant double-counting.']
with (P/'REPORT.md').open('x') as f:f.write('\n'.join(lines)+'\n')
print(json.dumps({'status':report['status'],'summaries':{m:summaries[m+'/ALL']['costs']['charged_stage_cpu'] for m in ('crt','parity')},'twin_errors':[{k:x[k] for k in ('id','forced_unknown','wrong_forced')} for x in hidden if x['stratum']=='misspecified']}))
