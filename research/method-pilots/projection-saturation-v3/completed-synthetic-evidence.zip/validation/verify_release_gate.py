"""Independent pre-release gate: verifies sealed files without opening truth."""
import datetime, hashlib, json, math, pathlib
ROOT=pathlib.Path('/workspace/shared/projection-saturation-v3')
INP=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-input')
OUT=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-results')
CUST=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-custody')
HERE=pathlib.Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
commit=read(CUST/'CUSTODY-COMMITMENT.json')
assert sha(CUST/'CUSTODY-COMMITMENT.json')=='6703abcbdbdb7d56d61cd874458744fa053c88a8026f963f894dda36f7fbb361'
for name,pin in commit['source_manifests'].items():
    assert sha(ROOT/name)==pin
    for rel,h in read(ROOT/name)['sources'].items(): assert sha(ROOT/rel)==h
assert sha(INP/'solver-input.json')==commit['solver_input_sha256']
assert sha(INP/'schedule.json')==sha(OUT/'schedule.json')==commit['schedule_sha256']
p=read(OUT/'progress.json');post=read(OUT/'post-run-integrity.json')
assert p['status']=='COMPLETE' and p['planned']==480 and len(p['completed'])==480
assert p['accounting_complete'] is True and p['in_flight'] is None and p['outstanding_cpu_reserve']==0
assert p['cpu_cap']==2000 and p['next_reservation']==62
assert p['input_sha256']==post['input_sha256']==commit['solver_input_sha256']
assert p['manifest_sha256']==post['manifest_sha256']==commit['source_manifests']['PROPOSED-FREEZE-MANIFEST.json']
assert post['sources']==read(ROOT/'PROPOSED-FREEZE-MANIFEST.json')['sources']
jobs=read(INP/'schedule.json')
assert len(jobs)==480 and len({tuple(j) for j in jobs})==480
actual=0.0;peak=0;verified=[]
for job,record in zip(jobs,p['completed']):
    i,m,on,r=job;name=f'{i:02d}-{m}-{on}-{r}'
    assert record['name']==name and record['status']=='OUTPUT_SEALED' and record['returncode']==0
    assert sha(OUT/(name+'.json'))==record['output_sha256']
    assert sha(OUT/(name+'.resource.json'))==record['resource_sha256']
    rr=read(OUT/(name+'.resource.json'))
    assert rr['exit_code']==0 and rr['wall_timeout'] is False and rr['parent_death_guard'] is True
    assert rr['limits']=={'cpu_seconds_per_process':30,'address_space_bytes_per_process':268435456,'wall_seconds':60}
    assert all(type(rr[k]) in (int,float) and math.isfinite(rr[k]) and rr[k]>=0 for k in ('child_cpu_seconds','parent_cpu_seconds','wall_seconds'))
    assert actual+62<=2000
    actual+=rr['child_cpu_seconds']+rr['parent_cpu_seconds']
    peak=max(peak,rr['child_peak_rss_kib'],rr['parent_peak_rss_kib'])
    verified.append({'name':name,'output_sha256':record['output_sha256'],'resource_sha256':record['resource_sha256']})
assert abs(actual-p['inclusive_inner_cpu_actual_known'])<1e-6
outer=read(INP/'holdout-outer.resource.json')
assert outer['exit_code']==0 and outer['wall_timeout'] is False and outer['parent_death_guard'] is True
assert outer['limits']=={'cpu_seconds_per_process':602,'address_space_bytes_per_process':536870912,'wall_seconds':3600}
assert outer['child_cpu_seconds']+1e-5>=actual
report={'status':'PASS_RELEASE_AUTHORIZED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'outputs_verified':len(verified),'verified_records':verified,
    'input_sha256':commit['solver_input_sha256'],'truth_sha256':commit['secret_truth_sha256'],
    'schedule_sha256':commit['schedule_sha256'],'source_manifests':commit['source_manifests'],
    'stage_inclusive_cpu_seconds':actual,'outer_inclusive_cpu_seconds':outer['child_cpu_seconds']+outer['parent_cpu_seconds'],
    'outer_resource_sha256':sha(INP/'holdout-outer.resource.json'),'peak_stage_process_rss_kib':peak,
    'progress_sha256':sha(OUT/'progress.json'),'post_run_integrity_sha256':sha(OUT/'post-run-integrity.json'),
    'truth_was_opened_by_gate':False,'custody':'Operational, not access-control blindness; seed/truth not delivered to runner before this gate.'}
with (HERE/'RELEASE-GATE.json').open('x') as f: json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:report[k] for k in ('status','outputs_verified','stage_inclusive_cpu_seconds','outer_inclusive_cpu_seconds','peak_stage_process_rss_kib')}))
