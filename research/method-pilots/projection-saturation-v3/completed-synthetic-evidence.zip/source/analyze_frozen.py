"""Frozen exact-output and paired-cost analysis, run only after output sealing/release."""
import argparse,hashlib,itertools,json,statistics,sys,time,math
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('optimized Python disables required checks')
sys.path.insert(0,str(Path(__file__).resolve().parent/'independent'))
from verifier import materialize,instance_hash,verify,read_witness,dot
from full_oracle import oracle

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check_seal(input_path,root):
    progress=json.loads((root/'progress.json').read_text())
    if progress.get('status')!='COMPLETE' or progress.get('planned')!=480 or len(progress.get('completed',[]))!=480 or not progress.get('accounting_complete') or progress.get('in_flight') is not None:raise ValueError('holdout outputs are not completely sealed')
    if progress['input_sha256']!=sha(input_path):raise ValueError('input seal mismatch')
    expected={f'{i:02d}-{m}-{on}-{rep}' for i in range(40) for m in ('crt','parity') for on in (0,1) for rep in range(3)}
    if {x['name'] for x in progress['completed']}!=expected:raise ValueError('sealed job identities mismatch')
    for x in progress['completed']:
        if x['status']!='OUTPUT_SEALED' or x['returncode']!=0 or sha(root/(x['name']+'.json'))!=x['output_sha256'] or sha(root/(x['name']+'.resource.json'))!=x['resource_sha256']:raise ValueError('output/resource seal mismatch')
    post=json.loads((root/'post-run-integrity.json').read_text())
    source_root=Path(__file__).resolve().parent;manifest=source_root/'PROPOSED-FREEZE-MANIFEST.json'
    if post['input_sha256']!=progress['input_sha256'] or post['manifest_sha256']!=progress['manifest_sha256'] or sha(manifest)!=progress['manifest_sha256']:raise ValueError('post-run source/input seal mismatch')
    pins=json.loads(manifest.read_text())['sources']
    if pins!=post['sources'] or any(sha(source_root/k)!=v for k,v in pins.items()):raise ValueError('frozen sources changed')
    return progress

def analyze(inputs,truth,root,expected_cases):
    if sys.flags.optimize:raise RuntimeError('optimized Python disables required checks')
    if set(inputs)!={'cases'} or len(inputs['cases'])!=expected_cases:raise ValueError('solver input case count/shape')
    if len({c['id'] for c in inputs['cases']})!=expected_cases:raise ValueError('duplicate solver IDs')
    secret={c['id']:c for c in truth['cases']}
    if len(truth['cases'])!=expected_cases or len(secret)!=expected_cases:raise ValueError('truth case count/duplicates')
    paired=[];outputs=[];nw=nc=0;refs=[];resource_total=0.;saturation_counts={}
    for i,item in enumerate(inputs['cases']):
        if set(item)!={'id','instance'}:raise ValueError('solver input contains secret/extra data')
        c=item['instance'];a,b,rows,n,s=materialize(c);label=secret[item['id']]
        if c.get('requested',list(range(6,97)))!=list(range(6,97)) or sorted(map(int,c['observed']))!=list(range(21,34))+list(range(63,74)):raise ValueError('analysis requires frozen production coordinates')
        if label['instance']!=c:raise ValueError('truth instance mismatch')
        t=time.process_time();ref=oracle(c);refs.append({'id':item['id'],'instance_hash':instance_hash(c),'result':ref,'cpu_seconds':time.process_time()-t})
        unknown=[j for j,k in enumerate(c.get('requested',list(range(6,97)))) if str(k) not in c['observed']]
        forced=[j for j in unknown if ref['masks'][j].bit_count()==1]
        wrong=None if label['truth'] is None else sum(not (ref['masks'][j]>>label['truth'][j]&1) for j in forced)
        for method in ('crt','parity'):
            arms={}
            for on in (0,1):
                runs=[]
                for rep in range(3):
                    path=root/f'{i:02d}-{method}-{on}-{rep}.json';d=json.loads(path.read_text());r=d['result']
                    assert d['id']==item['id'] and d['method']==method and type(d['saturation']) is bool and d['saturation']==bool(on)
                    assert r['status'] in ('ENUMERATED','SATURATED','DENSE_UNSAT')
                    assert r['feasible']==ref['feasible'] and r['masks']==ref['masks']
                    assert len(r['masks'])==len(rows)==len(r['witnesses'])
                    assert (r['certificate'] is not None)==(r['status'] in ('SATURATED','DENSE_UNSAT'))
                    if r['certificate'] is not None:
                        assert r['certificate']['status']==r['status'];verify(c,r['certificate']);nc+=1
                    for row,mask,wits in zip(rows,r['masks'],r['witnesses']):
                        assert set(wits)=={str(v) for v in range(26) if mask>>v&1}
                        for val,w in wits.items():assert dot(row,read_witness(w,n,s,a,b))==int(val);nw+=1
                    receipt=json.loads(path.with_name(path.stem+'.resource.json').read_text());assert receipt['exit_code']==0 and not receipt['wall_timeout']
                    assert receipt['limits']=={'cpu_seconds_per_process':30,'address_space_bytes_per_process':268435456,'wall_seconds':60} and receipt['parent_death_guard'] is True
                    def nonnegative(x):return type(x) in (int,float) and math.isfinite(x) and x>=0
                    assert all(nonnegative(receipt[k]) for k in ('child_cpu_seconds','parent_cpu_seconds','wall_seconds'))
                    assert all(nonnegative(r[k]) for k in ('fully_checked_cpu','kernel_cpu','primary_check_cpu')) and all(nonnegative(x) for x in r['timing'].values())
                    assert r['fully_checked_cpu']<=receipt['child_cpu_seconds']+1e-6
                    resource_total+=receipt['child_cpu_seconds']+receipt['parent_cpu_seconds']
                    statuskey=f"{method}/{on}/{label['stratum']}/{r['status']}";saturation_counts[statuskey]=saturation_counts.get(statuskey,0)+1
                    d['charged_child_cpu']=receipt['child_cpu_seconds'];d['charged_stage_cpu']=receipt['child_cpu_seconds']+receipt['parent_cpu_seconds']
                    runs.append(d);outputs.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
                arms[str(on)]={'median_charged_child_cpu':statistics.median(x['charged_child_cpu'] for x in runs),'median_charged_stage_cpu':statistics.median(x['charged_stage_cpu'] for x in runs),'median_checked_cpu':statistics.median(x['result']['fully_checked_cpu'] for x in runs),'median_kernel_cpu':statistics.median(x['result']['kernel_cpu'] for x in runs),'min_checked_cpu':min(x['result']['fully_checked_cpu'] for x in runs),'max_checked_cpu':max(x['result']['fully_checked_cpu'] for x in runs),'median_phase_cpu':{k:statistics.median(x['result']['timing'][k] for x in runs) for k in runs[0]['result']['timing']},'peak_rss_kib':max(x['rss_kib'] for x in runs),'statuses':[x['result']['status'] for x in runs],'supports':[x['result']['stats']['supports'] for x in runs]}
            paired.append({'id':item['id'],'stratum':label['stratum'],'method':method,'arms':arms,'forced_unknown':len(forced),'wrong_forced':wrong,'dependent_twin':label['stratum']=='misspecified'})
    aggregate={}
    for method in ('crt','parity'):
        for stratum in ['ALL']+sorted({r['stratum'] for r in paired}):
            rr=[r for r in paired if r['method']==method and (stratum=='ALL' or r['stratum']==stratum)]
            aggregate[method+'/'+stratum]={'cases':len(rr),'sum_off_case_medians':sum(r['arms']['0']['median_checked_cpu'] for r in rr),'sum_on_case_medians':sum(r['arms']['1']['median_checked_cpu'] for r in rr),'wins':sum(r['arms']['1']['median_checked_cpu']<r['arms']['0']['median_checked_cpu'] for r in rr),'sum_off_charged_child_case_medians':sum(r['arms']['0']['median_charged_child_cpu'] for r in rr),'sum_on_charged_child_case_medians':sum(r['arms']['1']['median_charged_child_cpu'] for r in rr),'sum_off_charged_stage_case_medians':sum(r['arms']['0']['median_charged_stage_cpu'] for r in rr),'sum_on_charged_stage_case_medians':sum(r['arms']['1']['median_charged_stage_cpu'] for r in rr),'charged_stage_wins':sum(r['arms']['1']['median_charged_stage_cpu']<r['arms']['0']['median_charged_stage_cpu'] for r in rr)}
    return {'status':'PASS','cases':expected_cases,'outputs_verified':len(outputs),'witnesses_verified':nw,'certificates_verified':nc,'paired':paired,'aggregate':aggregate,'stage_inclusive_resource_cpu':resource_total,'status_counts_by_arm_stratum':saturation_counts,'oracle':refs,'output_pins':outputs,'limits':'Exact conditional scalar marginals only; twins dependent; no target admission or universal performance claim.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--truth',required=True);p.add_argument('--results',required=True);p.add_argument('--expected-cases',type=int,required=True);p.add_argument('--output',required=True);p.add_argument('--disclosed-development',action='store_true');p.add_argument('--analysis-manifest-sha256');p.add_argument('--truth-sha256');p.add_argument('--source-manifest-sha256');args=p.parse_args()
    if args.expected_cases==40:
        if args.disclosed_development:raise ValueError('holdout cannot use development bypass')
        if sha(Path(__file__).resolve().parent/'PROPOSED-FREEZE-MANIFEST.json')!=args.source_manifest_sha256:raise ValueError('externally supplied source manifest seal mismatch')
        check_seal(args.input,Path(args.results))
        manifest=Path(__file__).resolve().parent/'ANALYSIS-MANIFEST.json'
        if sha(manifest)!=args.analysis_manifest_sha256:raise ValueError('analysis manifest seal mismatch')
        pins=json.loads(manifest.read_text())['sources']
        if set(pins)!={'analyze_frozen.py','independent/full_oracle.py','independent/verifier.py','bounded_checked.py'} or any(sha(manifest.parent/k)!=v for k,v in pins.items()):raise ValueError('analysis source changed')
        if sha(args.truth)!=args.truth_sha256:raise ValueError('custodian truth seal mismatch')
    elif args.expected_cases!=15 or not args.disclosed_development:raise ValueError('only frozen40-case holdout or explicit15-case disclosed control supported')
    result=analyze(json.loads(Path(args.input).read_text()),json.loads(Path(args.truth).read_text()),Path(args.results),args.expected_cases)
    result['input_sha256']=hashlib.sha256(Path(args.input).read_bytes()).hexdigest();result['truth_sha256']=hashlib.sha256(Path(args.truth).read_bytes()).hexdigest()
    Path(args.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','cases','outputs_verified','witnesses_verified','certificates_verified')}))
