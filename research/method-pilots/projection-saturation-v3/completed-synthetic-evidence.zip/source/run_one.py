import json,sys,time,resource
from solver import solve
from verifier import verify
if sys.flags.optimize:raise RuntimeError('optimized Python disables required checks')
case=json.load(open(sys.argv[1]))['cases'][int(sys.argv[2])]
t=time.process_time();res=solve(case['instance'],sys.argv[3],bool(int(sys.argv[4])))
if res['certificate']:
    q=time.process_time();verify(case['instance'],res['certificate']);res['timing']['certificate_verification']=time.process_time()-q
# Check primary witnesses, including exhaustive cases not covered by saturation cert.
q=time.process_time()
from solver import unpack
a,b,rows,n,s=unpack(case['instance'])
assert len(res['masks'])==len(rows)==len(res['witnesses'])
assert res['status'] in ('ENUMERATED','SATURATED','DENSE_UNSAT','INCOMPLETE')
assert (res['certificate'] is not None)==(res['status'] in ('SATURATED','DENSE_UNSAT'))
if res['certificate'] is not None:assert res['certificate']['status']==res['status']
if res['status']=='SATURATED':assert res['feasible'] is True
if res['status']=='DENSE_UNSAT':assert res['feasible'] is False
if not res['feasible']:assert not any(res['masks']) and not any(res['witnesses'])
for i,(mask,coverage) in enumerate(zip(res['masks'],res['witnesses'])):
    assert set(map(int,coverage))=={v for v in range(26) if mask>>v&1}
    for value,w in coverage.items():
        assert len(w)<=s and len({j for j,v in w})==len(w)
        assert all(0<=j<n and 0<v<26 for j,v in w)
        assert all(sum(row[j]*v for j,v in w)%26==z%26 for row,z in zip(a,b))
        assert sum(rows[i][j]*v for j,v in w)%26==int(value)
res['primary_check_cpu']=time.process_time()-q
q=time.process_time();encoded=json.dumps(res,sort_keys=True,separators=(',',':'));res['timing']['serialization']=time.process_time()-q
res['fully_checked_cpu']=time.process_time()-t
# Above serialization is one full scientific payload pass. Final timing-envelope write is outside metric.
json.dump({'id':case['id'],'method':sys.argv[3],'saturation':bool(int(sys.argv[4])),'result':res,'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},open(sys.argv[5],'w'))
