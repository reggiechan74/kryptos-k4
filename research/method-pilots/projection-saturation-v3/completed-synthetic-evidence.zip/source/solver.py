"""Exact synthetic modular marginals; deterministic maximal supports, no target data."""
import hashlib,json,time,sys
from itertools import combinations
from base_v2 import features,field_solve,images,crt,lift,GROUP,REPS,dot
SCHEMA='projection-saturation-v3'
def digest(obj): return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def unpack(case):
    def require(ok,message):
        if not ok:raise ValueError(message)
    def residue(x):return type(x)==int and 0<=x<26
    def index(x,n):return type(x)==int and 0<=x<n
    require(type(case)==dict,'instance object required')
    if 'ciphertext' in case:
        require(set(case)<=set(('ciphertext','observed','requested','modulus','budget')),'unsupported production fields')
        require(type(case.get('modulus',26))==int and case.get('modulus',26)==26,'modulus')
        require(type(case.get('budget',3))==int and case.get('budget',3)==3,'production budget')
        c=case['ciphertext'];require(type(c)==list and len(c)==97 and all(map(residue,c)),'ciphertext')
        raw=case.get('observed');require(type(raw)==dict and bool(raw),'observations required')
        require(all(type(k)==str and k.isascii() and k.isdecimal() and str(int(k))==k and 6<=int(k)<97 and residue(v) for k,v in raw.items()),'observations')
        obs={int(k):v for k,v in raw.items()}
        rows=[features([c[i-j] for j in range(1,7)]) for i in range(6,97)]
        inds=sorted(obs);requested=case.get('requested',list(range(6,97)))
        require(type(requested)==list and all(type(i)==int and 6<=i<97 for i in requested) and len(requested)==len(set(requested)),'requested coordinates')
        return [rows[i-6] for i in inds],[obs[i] for i in inds],[rows[i-6] for i in requested],31,3
    require(set(case)<=set(('matrix','rhs','outputs','n','columns','budget','modulus','requested')),'unsupported generic fields')
    a,b,r=case.get('matrix'),case.get('rhs'),case.get('outputs');n=case.get('n',case.get('columns'));s=case.get('budget')
    require(type(case.get('modulus'))==int and case['modulus']==26,'modulus')
    require(type(n)==int and 0<=n<=10000 and type(s)==int and 0<=s<=n,'dimension/budget')
    require('columns' not in case or type(case['columns'])==int and case['columns']==n,'columns mismatch')
    require(type(a)==list and type(b)==list and type(r)==list and len(a)==len(b),'arrays')
    require(all(type(row)==list and len(row)==n and all(map(residue,row)) for row in a+r) and all(map(residue,b)),'matrix/rhs')
    requested=case.get('requested',list(range(len(r))))
    require(type(requested)==list and all(index(i,len(r)) for i in requested) and len(requested)==len(set(requested)),'requested coordinates')
    return a,b,[r[i] for i in requested],n,s

def dense_field(a,b,outputs,n,p):
    """Elimination carries row identities; FULL remains sound without a null proof."""
    m=len(a); rr=[[v%p for v in row]+[b[i]%p] for i,row in enumerate(a)]
    ident=[[int(i==j) for j in range(m)] for i in range(m)]; piv=[]; k=0
    for j in range(n):
        t=next((i for i in range(k,m) if rr[i][j]),None)
        if t is None: continue
        rr[k],rr[t]=rr[t],rr[k];ident[k],ident[t]=ident[t],ident[k]
        inv=pow(rr[k][j],-1,p);rr[k]=[v*inv%p for v in rr[k]];ident[k]=[v*inv%p for v in ident[k]]
        for i in range(m):
            if i!=k and rr[i][j]:
                z=rr[i][j];rr[i]=[(v-z*w)%p for v,w in zip(rr[i],rr[k])];ident[i]=[(v-z*w)%p for v,w in zip(ident[i],ident[k])]
        piv.append(j);k+=1
    for i,row in enumerate(rr):
        if not any(row[:n]) and row[n]: return None,ident[i]
    out=[]
    for row in outputs:
        rem=[v%p for v in row]; lam=[0]*m
        for i,j in enumerate(piv):
            z=rem[j]
            if z:
                rem=[(v-z*w)%p for v,w in zip(rem,rr[i][:n])];lam=[(v+z*w)%p for v,w in zip(lam,ident[i])]
        out.append({'kind':'FULL'} if any(rem) else {'kind':'FIXED','value':dot(lam,b,p),'lambda':lam})
    return out,None

def upper_bounds(a,b,rows,n):
    fs={}
    for p in (2,13):
        tags,contradiction=dense_field(a,b,rows,n,p)
        if contradiction is not None:return None,None,{'field':p,'contradiction':contradiction}
        fs[str(p)]=tags
    upper=[]; masks=[]
    for i in range(len(rows)):
        tags={p:fs[p][i] for p in ('2','13')};upper.append(tags)
        vals={p:range(int(p)) if tags[p]['kind']=='FULL' else [tags[p]['value']] for p in tags}
        masks.append(sum(1<<crt(x,y) for x in vals['13'] for y in vals['2']))
    return masks,upper,None

def solve(case,method='crt',saturation=False,max_pieces=None,loose_upper=False):
    if sys.flags.optimize:raise RuntimeError('optimized Python disables required checks')
    start=time.process_time(); a,b,rows,n,sparsity=unpack(case)
    if method not in ('crt','parity') or type(saturation)!=bool or type(loose_upper)!=bool:raise ValueError('invalid method/options')
    if max_pieces is not None and (type(max_pieces)!=int or max_pieces<0):raise ValueError('invalid piece cap')
    timing={k:0. for k in ('upper','traversal','witness','certificate_generation','certificate_verification','serialization')}
    masks=[0]*len(rows);cover=[{} for _ in rows];ws=[];lookup={};feasibility=None
    stats={'supports':0,'field_solves':0,'pieces':0,'parity_matches':0}
    cert=None;up=None;tags=None
    if saturation:
        t=time.process_time();up,tags,unsat=upper_bounds(a,b,rows,n)
        if loose_upper and unsat is None:
            up=[(1<<26)-1]*len(rows);tags=[{'2':{'kind':'FULL'},'13':{'kind':'FULL'}} for _ in rows]
        timing['upper']=time.process_time()-t
        if unsat is not None:
            t=time.process_time();cert={'schema':SCHEMA,'instance_hash':digest(case),'status':'DENSE_UNSAT',**unsat}
            timing['certificate_generation']=time.process_time()-t
            return {'status':'DENSE_UNSAT','feasible':False,'masks':masks,'witnesses':cover,'certificate':cert,'timing':timing,'stats':stats,'kernel_cpu':time.process_time()-start}
    def witness(w):
        nonlocal feasibility
        t=time.process_time(); key=tuple((j,v) for j,v in w)
        if key not in lookup:
            assert len(w)<=sparsity and len({j for j,v in w})==len(w)
            assert all(0<=j<n and 0<v<26 for j,v in w)
            assert all(sum(row[j]*v for j,v in w)%26==z%26 for row,z in zip(a,b))
            wi=len(ws);lookup[key]=wi;ws.append(w)
            # Each independently validated original vector contributes every requested row.
            for i,row in enumerate(rows):
                z=sum(row[j]*v for j,v in w)%26
                if not masks[i]>>z&1: masks[i]|=1<<z;cover[i][str(z)]=wi
            if feasibility is None: feasibility=wi
        timing['witness']+=time.process_time()-t
    def emit(s,alpha,parity,beta):
        t=time.process_time()
        w=lift(s,alpha,beta) if beta is not None else [[j,crt(x,y)] for j,x,y in zip(s,alpha,parity) if crt(x,y)]
        timing['witness']+=time.process_time()-t
        witness(w)
    def add(s,q13,q2=None,beta=None,pred=None):
        # Empty request set still needs an actual sparse feasibility witness.
        if not rows:
            alpha=q13[0]; parity=q2[0] if q2 is not None else None
            emit(s,alpha,parity,beta)
            return
        for i,row in enumerate(rows):
            r=[row[j] for j in s];im13=images(q13,r,13)
            im2=images(q2,r,2) if q2 is not None else {pred[i]:None}
            for u,alpha in im13.items():
                for v,parity in im2.items():
                    z=crt(u,v)
                    if not masks[i]>>z&1:
                        emit(s,alpha,parity,beta)
    def saturated(): return saturation and feasibility is not None and masks==up
    # Padding with a zero row handles unobserved generic toy systems.
    aa=a or [[0]*n];bb=b or [0]
    supports=list(combinations(range(n),sparsity));state='ENUMERATED'; t=time.process_time();w0=timing['witness']
    def cap():return max_pieces is not None and stats['supports']>=max_pieces
    if method=='crt':
        for s in supports:
            if cap():state='INCOMPLETE';break
            stats['supports']+=1; mat=[[r[j] for j in s] for r in aa]
            stats['field_solves']+=1;q2=field_solve(mat,bb,2)
            if q2 is None:continue
            stats['field_solves']+=1;q13=field_solve(mat,bb,13)
            if q13 is None:continue
            stats['pieces']+=1;add(s,q13,q2=q2)
            if saturated():state='SATURATED';break
    elif method=='parity':
        assert n==31 and sparsity==3 and 'ciphertext' in case
        synd=[sum((r[REPS[g]]%2)<<i for i,r in enumerate(a)) for g in range(25)]
        wanted=sum((v%2)<<i for i,v in enumerate(b));matching=[]
        for k in range(4):
            for beta in combinations(range(25),k):
                z=0
                for g in beta:z^=synd[g]
                if z==wanted:matching.append(beta)
        stats['parity_matches']=len(matching);index={}
        for s in supports:
            gs=sorted(set(GROUP[j] for j in s))
            for k in range(len(gs)+1):
                for key in combinations(gs,k):index.setdefault(key,[]).append(s)
        cache={};seen=set();stop=False
        for beta in matching:
            pred=[sum(r[REPS[g]] for g in beta)%2 for r in rows]
            for s in index.get(beta,[]):
                if cap():state='INCOMPLETE';stop=True;break
                stats['supports']+=1
                if s not in cache:
                    stats['field_solves']+=1;cache[s]=field_solve([[r[j] for j in s] for r in a],b,13)
                q=cache[s]
                if q is None:continue
                key=(s,tuple(pred))
                if key in seen:continue
                seen.add(key);stats['pieces']+=1;add(s,q,beta=beta,pred=pred)
                if saturated():state='SATURATED';stop=True;break
            if stop:break
    else:raise ValueError(method)
    timing['traversal']=time.process_time()-t-(timing['witness']-w0)
    if state=='SATURATED':
        t=time.process_time();cert={'schema':SCHEMA,'instance_hash':digest(case),'status':state,'upper':tags,'witnesses':ws,'coverage':cover,'feasibility':feasibility};timing['certificate_generation']=time.process_time()-t
    # Both arms expose identical per-value original-vector witnesses, not just references.
    t=time.process_time();primary=[{z:ws[k] for z,k in row.items()} for row in cover];timing['witness']+=time.process_time()-t
    return {'status':state,'feasible':feasibility is not None,'masks':masks,'witnesses':primary,'certificate':cert,'upper_masks':up,'timing':timing,'stats':stats,'kernel_cpu':time.process_time()-start}
