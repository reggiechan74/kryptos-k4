# Projection saturation for exact sparse modular marginal decoding

2026-10-31 — DESIGN ONLY. No target data or held-out matrices were accessed. No frozen result, remote repository, or existing implementation was changed. This note builds on the public parity-first design, not raw validation examples. No benchmark was run. Independent proof review is required before selecting an implementation.

## Decision

**Recommend a small, separately frozen development increment, enabled symmetrically for both maximal-support CRT and parity-first.** This is an output-contract optimization: exact marginal masks and supporting sparse witnesses can be certified without enumerating all laws. It changes neither model nor attainable predictions. It may remove ambiguity-case traversal, but may add overhead when dense upper bounds are loose. There is no measured performance claim here.

The sandwich proof is elementary and not new mathematics. Locally, arbitrary-valued projection saturation extends the previously documented dense-singleton shortcut; the useful engineering contribution is a cheap independent certificate for a modular sparse decoder. No claim that this application is globally novel is justified by the limited source pass below.

## 1. Mathematical contract

Let R=Z/26Z, A be the observed-row feature matrix, b the observed mask response C−P, and a_j the feature row for requested coordinate j. The fixed production dictionary has 31 columns: constant, six lag values, six squares, fifteen pair products, and three **full-Z26** equality indicators. Evaluate indicators before reducing modulo either prime. Let s=3 and

    F = {θ∈R^31 : Aθ=b, ||θ||₀≤3},
    D = {θ∈R^31 : Aθ=b}.

Any additional genuine model constraint must be explicitly part of F. D may drop it, never impose an unjustified restriction. Define exact sparse response marginal M_j={a_jθ:θ∈F}. Plaintext masks are obtained bijectively by v↦C_j−v. Requested coordinates J, observed coordinates, feature order, seed/history conventions and all model restrictions must be fixed in the instance manifest. No prediction is implied outside J or outside the 91 modeled rows.

Maintain lower sets L_j consisting only of response values achieved by verified members of F. Compute sound upper sets U_j containing {a_jθ:θ∈D}; exact dense marginals are the preferred tight implementation, but are not logically necessary. Since F⊆D,

    L_j ⊆ M_j ⊆ U_j.

**Termination theorem.** If F has a verified witness and L_j=U_j for every j∈J, every returned mask is exact. Proof: the two inclusions force equality separately at each coordinate. The witness condition handles J=∅ and prevents describing an empty feasible relation as a positive result. For nonempty J, valid nonempty lower coverage already supplies a witness.

This theorem establishes no coefficient uniqueness, global function uniqueness, model membership, joint Cartesian product of marginals, or complete enumeration/count of laws. It can establish a unique requested response vector if all masks are singleton and feasibility is verified; that still is not a unique law.

### Empty and incomplete cases

- If D is empty, F is empty: return COMPLETE_MODEL_REJECTION with a contradiction certificate.
- If D is nonempty but no sparse witness has yet been found, return neither feasibility nor rejection. Sparse emptiness requires completed exclusion of every allowed support or another independently checkable exclusion proof.
- When a complete sparse enumerator finishes, its union is exact even if L≠U. Dense bounds can remain strictly larger forever.
- On a resource cap, return INCOMPLETE with verified lower masks and sound upper masks, not exact masks. Record already certified individual coordinates separately. A lower singleton is not a forced value.
- An interruption after certificate material is generated but before verification is not a verified completion. A separately completed verifier can subsequently establish completion from that material without finishing search.

## 2. Dense upper masks and compact proofs

Solve the unrestricted system independently over F₂ and F₁₃. For a consistent field system its affine scalar image is either a singleton or the full field. If a_j is in the row span of A, obtain λ with λA=a_j; the response is λb. Otherwise a null vector n satisfies An=0 and a_jn≠0, and affine movement spans the field. CRT recombination gives dense masks of sizes 1, 2, 13 or 26. Zero divisors are handled by the field split, not division in Z26.

**Minimal verification certificate (sufficient, not necessarily a proof of dense exactness):**

1. Canonical instance/model manifest and cryptographic hashes of exact A, b, all a_j, C_j if reporting plaintext, J, column order, modulus, budget and constraints. Hashes bind content; they do not prove matrix construction. The verifier must recompute the feature matrix from supplied synthetic contexts or receive those inputs from the trusted caller.
2. For each field and coordinate either `FULL`, or `FIXED(d,λ)` satisfying λA=a_j and λb=d modulo p. FULL is a trivial sound upper bound and needs no nullspace completeness claim. CRT the two field upper sets to reconstruct U_j.
3. A deduplicated list of original 31-coordinate modular sparse witnesses, each with at most three nonzero entries, satisfying Aθ=b and all genuine constraints. References map every (j,v∈U_j) to a witness producing v. One witness can cover one value at every coordinate. Require a feasibility witness even if J is empty.
4. Status `SATURATED_EXACT_MARGINALS`, certificate schema/version and feature-construction version. The verifier reconstructs masks, checks every witness and every coverage entry, and rejects missing, extra, malformed or inconsistent values.

For |J|=91, at most 91×26=2366 witness references are necessary; when J includes all 24 observed rows, their singleton projections tighten the bound to 24+67×26=1766. Deduplication can substantially reduce actual vectors. Each vector can be stored as up to three (feature index, residue) pairs. Do not omit witnesses simply because an affine solver says coverage exists; materialize them or provide a separately verified constructive affine representation.

The verifier does not need the support-search trace, skipped-support list, search ordering, dense nullspace basis, or algorithm timing. FULL tags may be too loose to saturate, but cannot create an incorrect proof. An optional exact-dense certificate can add a particular solution per field plus a null vector for each FULL row; these establish attainability without a full kernel basis. A sparse witness already supplies dense feasibility. For dense UNSAT, supply one field and y such that yA=0 but yb≠0. Verify these identities directly. Exhaustive sparse UNSAT with dense feasible needs a different certificate, e.g. a checked field contradiction on every maximal support; it cannot use saturation.

## 3. Integration pseudocode

```
validate immutable model/instance manifest
D2, D13 = solve_dense_fields(A,b)                 # timed in both methods
if either inconsistent:
    emit and independently verify contradiction; return COMPLETE_MODEL_REJECTION
U, upper_proof = dense_coordinate_upper_bounds(D2,D13,J)
L[j] = empty; witnesses = {}; feasible = false
for piece in exact_sparse_enumerator(instance):  # CRT or parity-first
    if cap reached: return INCOMPLETE(L,U,verified certificates so far)
    if piece inconsistent: continue
    for (j,v) in piece.exact_coordinate_images(J) not yet in L:
        θ = construct_original_sparse_witness(piece,j,v)
        verify θ satisfies the WHOLE sparse model and a_jθ=v
        # A single θ contributes at all requested coordinates, not just j.
        for k in J: insert a_kθ into L[k], remembering witness reference
        feasible = true
    if J is empty and not feasible:
        construct/verify any member of this nonempty piece; feasible = true
    assert every L[j] subset U[j]                 # otherwise implementation error
    if feasible and every L[j] == U[j]:
        emit complete certificate; independently verify; return SATURATED_EXACT_MARGINALS
# Enumeration exhaustion must itself be established, not inferred from an interrupted iterator.
if not feasible: return COMPLETE_MODEL_REJECTION with exclusion evidence
return ENUMERATED_EXACT_MARGINALS(L,witnesses)    # U may still be strictly larger
```

An exact affine piece may insert its full coordinate images without initially materializing all witnesses for speed, but that is trusted internal state only. Completion still requires materializing and checking all missing witnesses before final certification; charge that cost to the solver. A cap during materialization cannot silently downgrade the certificate obligation.

CRT baseline: use common original support containers |S|=3, permitting zeros. Solve both fields on the same S; combine per-coordinate images **within that piece**, and construct one CRT coefficient vector on S for every claimed value. Parity-first: retain its exact compatible beta/container relation; lift alpha and beta to an original modular vector with the proved minimum-support construction, then check the original vector. Checking only separate field sparsities is insufficient.

Neither method must continue tracking global laws once its requested masks are certified, because that is not this workload's contract. Both must have identical requested coordinates, witness obligations, preprocessing/cache-accounting and cap semantics.

## 4. Fresh toy algebraic examples and failure cases

These are small illustrative matrices, not generated cipher traces or benchmark cases.

**A. Early multivalued completion; joint trap.** R=Z26, two columns, no observations, s=1, requested outputs θ₁ and θ₂. Sparse solutions are the two coordinate axes. The dense upper mask is all26 at each output. Visiting the two one-column pieces supplies all required marginal witnesses and certifies both full masks. Yet (1,1) is impossible under s=1. This proves why marginal completion is weaker than full projected-relation enumeration.

**B. Dense feasible but sparse empty.** A=I₂, b=(1,1), s=1. The dense solution exists, but it needs two nonzero coefficients. Dense singleton masks do not authorize a positive return before a sparse witness. Conversely b=(1,0) supplies a sparse witness and singleton completion is valid.

**C. Strict upper bound and unsafe cross-support CRT.** A=(1,1), b=1, s=1, output θ₁. The sparse solutions are (1,0) and (0,1), hence M={0,1}. Dense solutions (t,1−t) give U=R. Saturation never occurs, despite sparse feasibility. Worse, independently unioning sparse field marginals gives {0,1} in both fields; CRT then fabricates 13 and14. A valid **dense upper** may contain these, but a claimed sparse lower may not. CRT must respect one admissible support/piece or be followed by actual original-model witness validation.

**C2. Fieldwise sparsity is not modular sparsity.** With s=1, A=(13,14), b=1, each field has a one-column solution, but a modular solution must use both columns: 13θ₁ is needed for parity and14θ₂ for the nonzero mod13 response. This is not sparse feasible at s=1. At the actual budget3, A=I₄ padded with27 zero columns and b=(1,1,1,1) is another explicit dense-feasible/sparse-infeasible instance.

**D. Marginal certified, law not unique.** No observations, s=1, one output identically zero, two coefficients. One zero witness saturates U={0}; many laws remain. An empty requested set similarly says nothing unless a feasibility witness is explicitly required.

**E. Incorrect hidden restriction.** No observations, one coefficient θ∈R, s=1, output θ. True mask is R. If the supposed dense relaxation silently restricts θ to even values, witnessed coverage of all even residues falsely looks saturated. Upper bounds must relax the stated model, not introduce assumed key parity, natural-language filters, preferred supports, or inferred plaintext clues.

**F. Cap misuse.** In example C, after only (0,1) is seen, L={0}. Returning a forced zero is false because (1,0) remains. Reporting L={0}, U=R, INCOMPLETE is correct.

**G. Mixed CRT widths.** One coefficient with observed equation 2θ=0 mod26, output θ, s=1. Solutions {0,13}; mod2 image is full and mod13 image is singleton0. Both witnesses are needed. Assuming every non-singleton modular image is all26 is wrong (although an all26 upper remains safe but less useful).

Other traps: mutable/reused instance caches, wrong zero/nonzero support accounting for residues13 and2, interpreting bitmask length as cardinality, comparing plaintext lower masks against response upper masks, missing coordinate indices, unsigned shift overflow, duplicated feature indices in sparse witnesses (normalize residues and combine indices before counting original-coordinate nonzeros), and calling one requested subset complete for all outputs. Model misspecification can still yield wrong conditional forced values; this optimization does not address it.

## 5. Relationship to primary literature

- Cousot and Cousot's [abstract-interpretation framework](https://www.di.ens.fr/~cousot/AI/) supplies the general discipline of sound abstraction. Here the product of scalar value sets is a nonrelational abstraction of a solution relation; dense relaxation gives a computable overapproximation and actual sparse witnesses an underapproximation. Equality makes the abstraction exact for this output contract. We do not need fixpoint iteration or widening, and this elementary sandwich argument is not a new abstract-interpretation theorem.
- [On Enumerating Short Projected Models](https://arxiv.org/abs/2110.12924) and [Disjoint Projected Enumeration for SAT and SMT without Blocking Clauses](https://arxiv.org/abs/2410.18707) study enumeration after projection and avoidance of irrelevant assignments. Our obligation is weaker: separate one-coordinate projections, not the jointly projected relation. Thus stopping after coordinate coverage cannot replace their general projected enumeration; example A exposes the difference.
- Marques-Silva, Janota and Lynce, [On Computing Backbones of Propositional Theories](https://sat.inesc-id.pt/~mikolas/ecai10.pdf), study literals true in every model, including enumeration and iterative satisfiability approaches. Our dense-singleton case is a finite-domain forced-value analogue. General saturation also certifies multivalued masks; it remains established existential-witness versus universal-exclusion reasoning, not a novel backbone principle.
- Donoho and Elad, [Optimally sparse representation in general dictionaries](https://pmc.ncbi.nlm.nih.gov/articles/PMC153464/), concern sparse representations and conditions for uniqueness/recovery in real/complex dictionaries. Those analytic guarantees cannot be transplanted into Z26. Our method certifies coordinate functionals of all feasible sparse laws rather than selecting a unique coefficient vector.
- Luo et al., [Some New Characters on the Wire-Tap Channel of Type II](https://comlab.ecs.syr.edu/private/wiretap/Luo1.pdf), introduces two-code relative weight/profile concepts. These underpin the earlier distinction between coefficient ambiguity and output-changing kernel differences. Projection saturation is instance-specific witness coverage, not a new relative weight invariant or uniform sparse identifiability guarantee.

Sources inspected2026-10-31. This targeted comparison found no reason to label the sandwich lemma itself novel. It does not establish absence of the exact modular engineering combination elsewhere. The local increment is explicit arbitrary-valued stopping and a small auditable certificate beyond the already documented singleton shortcut.

## 6. Development, independent review and untouched holdout plan

1. **Proof review first.** A reviewer independent of this note checks theorem, field upper certificates, original-vector support validity, cap/emptiness handling and every toy example. No algorithm-selection claim before that review. A later implementation requires separate code review; this document is not code approval.
2. Create a separate experimental implementation, not edits to either frozen version. Share only the explicitly reviewed saturation wrapper/certificate format where appropriate; retain independent baseline algebra and an independent verifier. No prior raw holdout is read or reused.
3. Fresh development tests: exhaust tiny ring dictionaries; test field widths1/2/13/26, rank deficiency, inconsistent fields, sparse-infeasible/dense-feasible cases, zero output rows, no requested rows, trace aliases, full-equality toggles and nonunits. Mutation tests must reject wrong λ, altered input hashes, dense solutions masquerading as sparse witnesses, omitted values, corrupted support indices, wrong requested sets and invalid cross-support CRT combinations. Compare exact marginal sets with independent brute force on tiny systems.
4. Full31-feature synthetic development tests compare unsaturated versus saturated versions of **both** maximal-support CRT and parity-first with identical masks+per-value-witness obligations. Keep deterministic support order initially; do not add a learned ordering or adaptive selector in the same increment. Measure dense solve, mask projection, sparse traversal, witness construction, serialization and independent verification separately and end-to-end. Track pieces visited, first witness, marginal coverage progression and whether completion used saturation or exhaustion.
5. Freeze algorithms, certificate schema, generators, caps, ordering, analysis and code hashes before a separate custodian draws fresh holdout seeds. Stratify in advance by ordinary parity weights, repeated contexts/aliases, mixed field ranks, sparse contradictions and misspecified twins. Include arbitrary toy matrices only as correctness controls, separately from realizable cipher-context cases. Do not condition sample inclusion on runtime wins or successful saturation.
6. Four paired arms: CRT and parity-first, each saturation off/on. Randomized interleaved repetitions, same CPU/memory ceilings and same output obligations. Compare paired per-case medians and aggregate charged end-to-end costs; disclose memory and overhead losses. Do not reuse v2 timings as a statistical control or claim a recovery gain when all exact masks are equal. Report saturation rates and wins by prespecified strata, not just an overall percentage.
7. Independent auditor checks hashes, holdout custody, every output and coverage certificate, and a complete reference enumeration for every held-out case. Dense-feasible sparse-UNSAT requires full reference exclusion. Preserve all failures and capped outputs; never treat incompleteness as rejection. Admission to any target remains a separate decision.

**Practical recommendation:** worth a bounded development test because the dense system is only24×31 and the certificate is small, but its actual cost must be measured. Dense bounds with too many unavailable sparse values prevent early completion; an exact method must then traverse the original search plus overhead. Reject this increment on unfavorable paired end-to-end evidence, or retain it only as an explicitly measured option—not an unvalidated automatic default. Do not conflate conventional rigorous engineering with inventing a new mathematical theory.

## Independent review outcome

Independent mathematical and full-document pseudocode review **PASS**, recorded in INDEPENDENT-REVIEW.md. The reviewer checked the all-singleton and empty-requested-set paths, exhaustion versus interrupted iterators, CRT/common-support safeguards, original-coordinate witness requirements and fresh algebraic examples. This is not executable code approval; independent implementation review remains required.
