"""Proposed custodian-only driver. No holdout inputs are created by this program."""
import argparse,hashlib,json,os,random,subprocess,sys,resource,ctypes,signal
from pathlib import Path

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--input-sha256',required=True);p.add_argument('--source-manifest',required=True);p.add_argument('--manifest-sha256',required=True);p.add_argument('--out',required=True);args=p.parse_args()
    root=Path(__file__).resolve().parent;os.chdir(root)
    if not __debug__:raise ValueError('assertions must remain enabled')
    if resource.getrlimit(resource.RLIMIT_CPU)!=(602,603) or resource.getrlimit(resource.RLIMIT_AS)!=(512*1024**2,512*1024**2):raise ValueError('driver requires approved bounded root limits')
    death=ctypes.c_int()
    if ctypes.CDLL(None).prctl(2,ctypes.byref(death),0,0,0)!=0 or death.value!=signal.SIGKILL:raise ValueError('driver requires parent-death guard')
    if sha(args.source_manifest)!=args.manifest_sha256:raise ValueError('manifest seal mismatch')
    pins=json.loads(Path(args.source_manifest).read_text())
    required={'solver.py','base_v2.py','verifier.py','bounded_checked.py','run_one.py','holdout_driver.py','proposed_holdout_generator.py','PROPOSED-HOLDOUT-PROTOCOL.md'}
    if set(pins)!= {'sources'} or set(pins['sources'])!=required:raise ValueError('required source manifest set mismatch')
    for name,h in pins['sources'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('nonlocal source pin')
        if sha(name)!=h:raise ValueError('source pin mismatch: '+name)
    if sha(args.input)!=args.input_sha256:raise ValueError('input seal mismatch')
    data=json.loads(Path(args.input).read_text())
    if set(data)!={'cases'} or len(data['cases'])!=40:raise ValueError('requires40 sealed solver-only cases')
    if any(set(c)!={'id','instance'} for c in data['cases']):raise ValueError('truth/extra metadata must remain outside solver input')
    dest=Path(args.out);dest.mkdir(parents=True,exist_ok=False)
    jobs=[(i,m,on,r) for i in range(40) for m in ('crt','parity') for on in (0,1) for r in range(3)]
    random.Random(202610311934).shuffle(jobs)
    (dest/'schedule.json').write_text(json.dumps(jobs))
    actual=0.;done=[];state='INCOMPLETE';in_flight=None
    def save(reason):
        payload={'status':state,'reason':reason,'completed':done,'planned':480,'inclusive_inner_cpu_actual_known':actual,'in_flight':in_flight,'outstanding_cpu_reserve':62 if in_flight else 0,'accounting_complete':in_flight is None,'cpu_cap':2000,'next_reservation':62,'input_sha256':args.input_sha256,'manifest_sha256':args.manifest_sha256}
        tmp=dest/'progress.tmp'
        with tmp.open('w') as out:
            out.write(json.dumps(payload,indent=2)+'\n');out.flush();os.fsync(out.fileno())
        os.replace(tmp,dest/'progress.json')
        fd=os.open(dest,os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    save('not started')
    for i,m,on,r in jobs:
        if actual+62>2000:save('aggregate CPU reserve unavailable');break
        name=f'{i:02d}-{m}-{on}-{r}';receipt=dest/(name+'.resource.json');output=dest/(name+'.json')
        cmd=[sys.executable,'bounded_checked.py',str(receipt),'30','256','60',sys.executable,'run_one.py',args.input,str(i),m,str(on),str(output)]
        in_flight={'name':name,'reserved_cpu':62};save('stage starting; reserve committed')
        result=subprocess.run(cmd,env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid())})
        if not receipt.exists():
            done.append({'name':name,'status':'INCOMPLETE','reason':'stage receipt absent','returncode':result.returncode})
            save('stage receipt absent');break
        rr=json.loads(receipt.read_text());actual+=rr['child_cpu_seconds']+rr['parent_cpu_seconds'];in_flight=None
        failed=bool(result.returncode) or not output.exists()
        done.append({'name':name,'status':'INCOMPLETE' if failed else 'OUTPUT_SEALED','returncode':result.returncode,'resource_sha256':sha(receipt),'output_sha256':sha(output) if output.exists() else None})
        if failed:save('stage failure or missing output retained');break
        save('running')
    else:
        if sha(args.input)!=args.input_sha256 or sha(args.source_manifest)!=args.manifest_sha256 or any(sha(name)!=h for name,h in pins['sources'].items()):
            save('post-run seal mismatch')
        else:state='COMPLETE';save('all480 outputs sealed; pre/post seals match')
    observed={}
    for name in pins['sources']:
        observed[name]=sha(name) if Path(name).exists() else None
    post={'sources':observed,'input_sha256':sha(args.input) if Path(args.input).exists() else None,'manifest_sha256':sha(args.source_manifest) if Path(args.source_manifest).exists() else None}
    (dest/'post-run-integrity.json').write_text(json.dumps(post,indent=2)+'\n')
    if post['sources']!=pins['sources'] or post['input_sha256']!=args.input_sha256 or post['manifest_sha256']!=args.manifest_sha256:
        state='INCOMPLETE';save('post-run seal mismatch')
    if state!='COMPLETE':return 2
    return 0
if __name__=='__main__':sys.exit(main())
