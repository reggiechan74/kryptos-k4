"""Independent direct-identity certificate checker; no producer imports/algebra.

Accepts exact scalar response marginals, not a joint relation or model membership.
All sparse vectors use original coordinates, canonical distinct nonzero entries.
"""
import hashlib
import itertools
import json

SCHEMA = 'projection-saturation-v3'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def integer(x, lo, hi):
    return type(x) is int and lo <= x <= hi

def vector(x, n, p):
    return type(x) is list and len(x) == n and all(integer(v, 0, p-1) for v in x)

def instance_hash(instance):
    return hashlib.sha256(json.dumps(instance, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()).hexdigest()

def materialize(instance):
    require(type(instance) is dict, 'instance object required')
    if 'ciphertext' in instance:
        require(set(instance) <= {'ciphertext','observed','requested','modulus','budget'}, 'unsupported production instance field')
        require(type(instance.get('modulus',26)) is int and instance.get('modulus',26) == 26 and type(instance.get('budget',3)) is int and instance.get('budget',3) == 3, 'production model changed')
        c = instance['ciphertext']
        require(vector(c,97,26), 'ciphertext must be 97 canonical residues')
        rows = []
        for i in range(6,97):
            lag = [c[i-j] for j in range(1,7)]
            row = [1] + lag + [(v*v)%26 for v in lag]
            for j in range(6):
                for k in range(j+1,6):
                    row.append(lag[j]*lag[k]%26)
            row.extend(int(lag[j] == lag[j+1]) for j in (0,2,4))
            rows.append(row)
        obs = instance.get('observed')
        require(type(obs) is dict and bool(obs), 'nonempty production observed object required')
        inds = []
        for key, value in obs.items():
            require(type(key) is str and key.isascii() and key.isdecimal() and str(int(key)) == key, 'observed indices must be canonical string integers')
            index = int(key)
            require(integer(index,6,96) and integer(value,0,25), 'invalid observation')
            inds.append(index)
        inds.sort()
        a = [rows[i-6] for i in inds]
        b = [obs[str(i)] for i in inds]
        requested = instance.get('requested', list(range(6,97)))
        require(type(requested) is list and all(integer(i,6,96) for i in requested) and len(set(requested)) == len(requested), 'invalid requested coordinates')
        return a,b,[rows[i-6] for i in requested],31,3
    require(set(instance) <= {'matrix','rhs','outputs','n','columns','budget','modulus','requested'}, 'unsupported generic instance field')
    require(type(instance.get('modulus')) is int and instance.get('modulus') == 26, 'generic modulus must be 26')
    a,b,outputs = instance.get('matrix'),instance.get('rhs'),instance.get('outputs')
    require(type(a) is list and type(b) is list and type(outputs) is list, 'generic arrays required')
    available = a + outputs
    n = len(available[0]) if available and type(available[0]) is list else instance.get('columns',instance.get('n'))
    require(integer(n,0,10000), 'invalid column count')
    require('columns' not in instance or (type(instance['columns']) is int and instance['columns'] == n), 'column count mismatch')
    require('n' not in instance or (type(instance['n']) is int and instance['n'] == n), 'n mismatch')
    require(all(vector(r,n,26) for r in available) and vector(b,len(a),26), 'invalid matrix or RHS')
    s = instance.get('budget')
    require(integer(s,0,n), 'invalid sparsity budget')
    requested = instance.get('requested',list(range(len(outputs))))
    require(type(requested) is list and all(integer(i,0,len(outputs)-1) for i in requested) and len(set(requested)) == len(requested), 'invalid requested coordinates')
    return a,b,[outputs[i] for i in requested],n,s

def dot(a,b,p=26):
    return sum(x*y for x,y in zip(a,b))%p

def read_witness(w,n,s,a,b):
    require(type(w) is list and len(w)<=s, 'sparse witness exceeds budget')
    full = [0]*n
    last = -1
    for pair in w:
        require(type(pair) is list and len(pair)==2, 'invalid sparse entry')
        j,v = pair
        require(integer(j,0,n-1) and j>last and integer(v,1,25), 'noncanonical sparse witness')
        full[j] = v
        last = j
    require(all(dot(r,full)==v for r,v in zip(a,b)), 'witness violates observation')
    return full

def verify(instance, cert):
    a,b,rows,n,s = materialize(instance)
    require(type(cert) is dict and cert.get('schema') == SCHEMA, 'invalid certificate schema')
    require(cert.get('instance_hash') == instance_hash(instance), 'instance hash mismatch')
    status = cert.get('status')
    common = {'schema','instance_hash','status'}
    if status == 'DENSE_UNSAT':
        require(set(cert) == common | {'field','contradiction'}, 'invalid contradiction certificate fields')
        p,y = cert['field'],cert['contradiction']
        require(type(p) is int and p in (2,13), 'invalid contradiction field')
        require(vector(y,len(a),p), 'invalid contradiction vector')
        require(all(sum(y[i]*a[i][j] for i in range(len(a)))%p == 0 for j in range(n)), 'contradiction does not annihilate matrix')
        require(sum(t*v for t,v in zip(y,b))%p != 0, 'contradiction does not separate RHS')
        return True
    require(status == 'SATURATED', 'certificate cannot certify exhaustion or incompleteness')
    require(set(cert) == common | {'upper','witnesses','coverage','feasibility'}, 'invalid saturation certificate fields')
    upper, ws, coverage = cert['upper'],cert['witnesses'],cert['coverage']
    require(type(upper) is list and len(upper)==len(rows), 'upper shape')
    require(type(coverage) is list and len(coverage)==len(rows), 'coverage shape')
    require(type(ws) is list and len(ws)>0, 'feasibility witness missing')
    parsed = [read_witness(w,n,s,a,b) for w in ws]
    require(len({tuple(w) for w in parsed}) == len(parsed), 'duplicate witness')
    require(integer(cert['feasibility'],0,len(ws)-1), 'invalid feasibility witness reference')
    for row, ub, cover in zip(rows,upper,coverage):
        require(type(ub) is dict and set(ub)=={'2','13'}, 'field upper shape')
        allowed = {}
        for p in (2,13):
            proof = ub[str(p)]
            require(type(proof) is dict, 'upper proof object')
            if proof.get('kind') == 'FULL':
                require(set(proof)=={'kind'}, 'FULL shape')
                allowed[p] = set(range(p))
            else:
                require(proof.get('kind') == 'FIXED' and set(proof)=={'kind','value','lambda'}, 'FIXED shape')
                d,y = proof['value'],proof['lambda']
                require(integer(d,0,p-1) and vector(y,len(a),p), 'FIXED scalar/vector')
                require(all(sum(y[i]*a[i][j] for i in range(len(a)))%p == row[j]%p for j in range(n)), 'row-span identity fails')
                require(sum(t*v for t,v in zip(y,b))%p == d, 'fixed response identity fails')
                allowed[p] = {d}
        vals = {v for v in range(26) if v%2 in allowed[2] and v%13 in allowed[13]}
        require(type(cover) is dict and set(cover)=={str(v) for v in vals}, 'missing or extra coverage values')
        for key,wi in cover.items():
            require(integer(wi,0,len(parsed)-1), 'coverage witness reference')
            require(dot(row,parsed[wi])==int(key), 'witness does not cover value')
    return True

def brute_force(instance):
    """Tiny-only exhaustive original-ring oracle; no field solver or CRT split."""
    a,b,rows,n,s = materialize(instance)
    require(n<=6 and s<=3, 'tiny oracle bounds exceeded')
    masks = [0]*len(rows)
    witnesses = [{} for _ in rows]
    feasible = False
    checked = 0
    for k in range(s+1):
        for inds in itertools.combinations(range(n),k):
            for vals in itertools.product(range(1,26),repeat=k):
                checked += 1
                w=[0]*n
                for i,v in zip(inds,vals):
                    w[i]=v
                if not all(dot(r,w)==v for r,v in zip(a,b)):
                    continue
                feasible = True
                sparse = [[i,w[i]] for i in inds]
                for j,row in enumerate(rows):
                    v=dot(row,w)
                    masks[j] |= 1<<v
                    witnesses[j].setdefault(str(v),sparse)
    return {'feasible':feasible,'masks':masks,'witnesses':witnesses,'checked':checked}
