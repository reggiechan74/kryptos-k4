"""Independent complete support oracle. F2 solutions enumerated literally (8);
F13 scalar images computed by forward equation insertion/reduction. No producer imports.
"""
import itertools,json,time,sys
from pathlib import Path
from verifier import materialize,instance_hash

def insert_equations(a,b):
    basis={}
    for row,rhs in zip(a,b):
        v=[x%13 for x in row];d=rhs%13
        for k in sorted(basis):
            r,z=basis[k];f=v[k]
            for j in range(k,3):v[j]=(v[j]-f*r[j])%13
            d=(d-f*z)%13
        if not any(v):
            if d:return None
            continue
        k=next(j for j,x in enumerate(v) if x)
        inv=pow(v[k],11,13)
        basis[k]=([x*inv%13 for x in v],d*inv%13)
    return basis

def projection(basis,row):
    v=[x%13 for x in row];d=0
    for k in sorted(basis):
        r,z=basis[k];f=v[k]
        for j in range(k,3):v[j]=(v[j]-f*r[j])%13
        d=(d+f*z)%13
    return range(13) if any(v) else (d,)

def oracle(instance):
    a,b,rows,n,s=materialize(instance)
    assert 3<=n<=31 and s==3
    masks=[0]*len(rows);feasible=False;support_count=0;pieces=0
    columns=[sum((r[j]%2)<<i for i,r in enumerate(a)) for j in range(n)]
    wanted=sum((v%2)<<i for i,v in enumerate(b))
    for support in itertools.combinations(range(n),3):
        support_count+=1
        parities=[]
        for bits in itertools.product((0,1),repeat=3):
            syndrome=0
            for j,x in zip(support,bits):
                if x:syndrome^=columns[j]
            if syndrome==wanted:parities.append(bits)
        if not parities:continue
        small=[[r[j] for j in support] for r in a]
        basis=insert_equations(small,b)
        if basis is None:continue
        feasible=True;pieces+=1
        for i,row in enumerate(rows):
            if masks[i]==(1<<26)-1:continue
            r=[row[j] for j in support]
            vals13=projection(basis,r)
            vals2={sum(x*y for x,y in zip(r,bits))%2 for bits in parities}
            for x in vals13:
                for y in vals2:
                    # Find lift by checking the only two residues with this mod13 value.
                    z=x if x%2==y else x+13
                    masks[i]|=1<<z
    return dict(feasible=feasible,masks=masks,supports=support_count,feasible_pieces=pieces)

if __name__=='__main__':
    source=Path(sys.argv[1]);cases=json.loads(source.read_text())['cases']; results=[]
    for item in cases:
        t=time.process_time();result=oracle(item['instance'])
        results.append(dict(id=item['id'],instance_hash=instance_hash(item['instance']),result=result,cpu_seconds=time.process_time()-t))
        print(item['id'],results[-1]['cpu_seconds'],flush=True)
    Path('full-oracle-results.json').write_text(json.dumps({'status':'COMPLETE','classification':'fresh disclosed synthetic development','results':results},indent=2)+'\n')
