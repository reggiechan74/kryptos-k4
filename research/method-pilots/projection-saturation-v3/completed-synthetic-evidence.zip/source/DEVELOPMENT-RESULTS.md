# Projection-saturation v3: disclosed synthetic development

**Correctness PASS on this development cohort; optional optimization, not a general speedup.** No fresh holdout or K4 target has been run. The exact model and conditional outputs are unchanged. The independent report is [independent/INDEPENDENT-REVIEW.md](independent/INDEPENDENT-REVIEW.md).

## Fixed comparison and observed outcome

The initial r0, hardened r1 and corrected-phase r2 each used the same15 disclosed synthetic cases × four arms × three interleaved repetitions =180 completed outputs (540 executed total, not540 independent cases). The table below is final r2; r0/r1 are preserved in development-history. This rerun is not fresh-blind evidence. Both deterministic maximal-support CRT and grouped parity-first were tested with saturation off/on. Every output had the same primary obligations: response marginal masks and one original-coordinate sparse witness for every advertised value. On additionally paid for sound dense upper bounds, compact completion proof, proof verification and serialization. It could stop only when actual sparse witness coverage matched every requested upper bound. All180 masks/feasibility matched an independently implemented complete4495-support oracle;16,488 per-value sparse witnesses and30 completion certificates checked.

| Method | Sum of off case-median fully checked CPU | Sum of on case-median fully checked CPU | On faster | Saturated | Dense rejection |
| --- | ---: | ---: | ---: | ---: | ---: |
| Maximal-support CRT |6.373353145s|2.474060254s|8/15|4/15|1/15|
| Grouped parity-first |3.785108132s|1.451664590s|7/15|4/15|1/15|

Charged process costs include startup, final whole-output serialization/write and (in the second pair) the bounded supervisor:

| Method | Child CPU off → on (sum of medians) | Child+supervisor CPU off → on | Charged-stage wins |
| --- | ---: | ---: | ---: |
| CRT |6.836820s →2.916616s|7.220924s →3.276185s|7/15|
| Parity |4.227080s →1.892156s|4.609144s →2.289918s|8/15|

The charged-stage aggregate reductions are54.6% and50.3% **on this deliberately alias-rich development mixture**, not universal performance estimates. These receipt-derived paired costs, not internal checked CPU alone, are the primary end-to-end performance comparison.

These are **sums of paired case medians**, not median speedups or universally representative workload times. The four saturated cases are a constant trace, periodic trace, all-zero alias trace, and the constant trace's deliberately misspecified twin. They complete after one support. Ordinary/binary/even cases mostly cannot saturate and pay dense-bound overhead; many regress. The twin is dependent, not an independent success. Do not advertise the roughly61–62% aggregate CPU reduction without this composition warning. Full per-case/component results are in development_summary.json.

The known misspecified twins demonstrate unchanged limitations: a conditional singleton can be wrong for a hidden true response outside the assumed family. No law uniqueness, model membership, Cartesian product of marginal choices, or first-six-letter recovery is certified. Equality indicators use full modulo26 lag equality before field reduction.

## Independent controls

-40 tiny systems×off/on against exhaustive original-ring vectors; widths1/2/13/26, empty requested set, dense-feasible sparse-infeasible, nonunits and cross-support CRT traps.
-19 malformed certificates plus6 production context/hash/equality mutations rejected.
-Eight additional26³ tiny vector sets validate the independent full-support oracle.
-Finite support caps remain INCOMPLETE; deliberately loose upper bounds can fail to saturate yet exhaustive completion remains correct.
-No broad archived-target suite or prior heldout data was used.

## Timing and resource integrity

Initial r0 top-level receipt:57.544828CPU seconds; hardened r1:60.981121CPU seconds, each inclusive of descendants. Their inner55.923447 and59.359096seconds are **not added again**. R2 adds54.272592CPU seconds (inner52.988606 not added). Total main development172.798541CPU seconds. Independent component controls/oracle/audit, including retained repeats and final revalidations:16.842148CPU seconds (initial subtotal11.915070). Separate summary and fresh launcher controls have their own receipts. All computations remained within the prescribed conservative CPU/memory envelope. Peak solver memory and every phase appear per output. Tiny timings sometimes quantize to zero/near4ms in this environment; do not interpret standalone near-zero speedup ratios.

The initial r0 instrumentation put dense-UNSAT certificate assembly/hash cost in total kernel/fully-checked CPU but omitted its separate certificate_generation bucket. R1 corrects that bucket and hardens producer/verifier input validation. R2 also places actual modular vector construction in the witness timing bucket rather than traversal and includes optimized-interpreter fail-closed guards; no search/model/ordering changed. Original results and pins are retained. A premature r1 summary invocation correctly rejected partial repeat counts, produced no summary, and its failed resource receipt remains in development-history. A complete summary was produced after180outputs. The runner then serializes the whole output a second time when writing the final JSON, outside internal fully_checked_cpu. Interpreter startup/import, second serialization and final write are covered by receipt-derived child/stage CPU. Therefore use paired receipt costs for charged end-to-end comparisons; internal checked timings remain a diagnostic metric, not total process cost.

## Decision and next gate

Retain as a promising **optional** exact-output tactic for repeated/alias contexts, not a default justified by this alias-heavy development mix. The separate full implementation/protocol audit passed; its29.997699CPU seconds are separate from component checks. See full-audit/REPORT.md. Freeze source/protocol/generator/verifier after corrections, then request approval for fresh independently custodied holdout. The [proposed holdout](PROPOSED-HOLDOUT-PROTOCOL.md) has not been generated or run; it does not admit target use. No larger sparsity, new filters or search ordering are part of this increment.

Original source pre-run pins and all output/resource artifacts are preserved. This is a method pilot, not an additional numbered cipher hypothesis. The existing repository's current queue should be reconciled only when publishing the reviewed increment, preserving all earlier v1/v2 evidence.
