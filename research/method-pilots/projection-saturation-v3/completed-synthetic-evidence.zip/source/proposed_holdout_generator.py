"""UNEXECUTED proposed fresh-holdout generator. Parent approval and custodian required."""
import random,json,sys
from base_v2 import features,GROUP
OBS=list(range(21,34))+list(range(63,74))
def generate(seed):
    rng=random.Random(seed);cases=[]
    def add(ident,stratum,c,w):
        response=[sum(features([c[i-j] for j in range(1,7)])[j]*v for j,v in w)%26 for i in range(6,97)]
        # The generator has no solver calls or acceptance-by-runtime/recovery criteria.
        cases.append({'id':ident,'stratum':stratum,'instance':{'ciphertext':c,'observed':{str(i):response[i-6] for i in OBS},'requested':list(range(6,97))},'truth':response,'plant':w})
    for weight in range(4):
        for rep in range(4):
            groups=rng.sample(range(25),3)
            inds=[rng.choice([j for j in range(31) if GROUP[j]==g]) for g in groups]
            coeff=[rng.choice(list(range(1,26,2))) if k<weight else rng.choice(list(range(2,26,2))) for k in range(3)]
            w=sorted(zip(inds,coeff));add(f'ordinary-w{weight}-{rep}','ordinary', [rng.randrange(26) for _ in range(97)],w)
    for pattern in ('constant','periodic','binary','even'):
        for rep in range(3):
            if pattern=='constant':base=[rng.randrange(26)];c=base*97
            elif pattern=='periodic':base=[rng.randrange(26) for _ in range(2+rep)];c=[base[i%len(base)] for i in range(97)]
            elif pattern=='binary':pair=rng.sample(range(26),2);c=[rng.choice(pair) for _ in range(97)]
            else:c=[2*rng.randrange(13) for _ in range(97)]
            # At least one full-alphabet equality feature; no selection by matrix rank.
            inds=rng.sample(range(28),2)+[rng.randrange(28,31)]
            w=sorted((j,rng.randrange(1,26)) for j in inds);add(f'{pattern}-{rep}',pattern,c,w)
    for rep in range(4):add(f'zero-law-{rep}','zero-law',[rng.randrange(26) for _ in range(97)],[])
    for rep in range(4):
        c=[rng.randrange(26)]*97;add(f'contradiction-{rep}','contradiction',c,[])
        cases[-1]['instance']['observed'][str(OBS[1])]=rng.randrange(1,26);cases[-1]['truth']=None;del cases[-1]['plant']
    for index in (0,12,16,19):
        source=cases[index];truth=source['truth'].copy();truth[0]=(truth[0]+1)%26
        cases.append({'id':source['id']+'-misspecified-twin','stratum':'misspecified','instance':json.loads(json.dumps(source['instance'])),'truth':truth,'source_id':source['id']})
    assert len(cases)==40
    return {'solver_input':{'cases':[{'id':c['id'],'instance':c['instance']} for c in cases]},'secret_truth':{'classification':'fresh-heldout-after-approval','seed':seed,'cases':cases}}
if __name__=='__main__':
    raise SystemExit('Custodian must import generate(seed) only after explicit approval; no default draw.')
