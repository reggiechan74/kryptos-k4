# Projection saturation v3 — one fresh synthetic holdout

**Validated synthetic result; no K4 target run.** All 480 fixed stage outputs matched the independent maximal-support oracle. All 47,412 original-coordinate sparse witnesses and 78 certificates passed; a separate final reviewer independently rechecked witnesses, certificates, seals and descriptive arithmetic.

- [Results and paired timing](validation/REPORT.md)
- [Exact conditional masks and statuses by stratum](validation/CONDITIONAL-MASKS.md)
- [Independent final release review](release-review/REPORT.md)
- [Resource accounting](validation/RESOURCE-ACCOUNTING.json): 488.783194 total deduplicated managed CPU seconds, including historical work; no inner/outer double-counting.
- [Frozen source manifest](source/PROPOSED-FREEZE-MANIFEST.json) and [analysis manifest](source/ANALYSIS-MANIFEST.json)
- [Pre-draw implementation/protocol review](implementation-audit/REPORT.md)

Charged-stage sums of paired case medians were CRT 24.405472 → 13.323356 seconds and parity 16.280120 → 9.048368 seconds. There were respectively 14 and 10 regressions among 40 pairs. This deliberately structured mixture is not representative-workload or universal-speedup evidence. Both methods return the same exact masks; there is no comparative recovery gain. Four dependent misspecified twins each force one wrong hidden response. Retain saturation as optional/default-off, with conditional-model limitations explicit.

## Artifact layout

`source/` contains the byte-identical pre-draw pinned runtime, generator, verifier and analysis. Its proposed-protocol wording is retained as the original freeze record; the dated reports establish the subsequently authorized completed synthetic experiment. `results/` contains all 480 raw outputs, their resource receipts, schedule, progress and final integrity seal. `input/` contains solver-only inputs and the outer receipt. `released-truth/` contains the now-released synthetic seed/truth/plants and original custody commitments. `validation/` and `release-review/` contain the scientific analysis, descriptive tables and independent checks.

Computational/data artifacts remain byte-identical to their originals. Selected public prose copies remove internal coordination text; PUBLIC-PROVENANCE.json records original and public hashes. Historical manifests retain original commitments and must not be mistaken for public-byte checksums. Historical resource-command paths are retained because rewriting them would invalidate original receipt seals; they contain no private Page IDs, user messages, or task identifiers. Relative publication locations and all byte identities are recorded in `ARTIFACT-MANIFEST.json`. Any later path rewrite must be labeled a derivative and carry original-to-public hash mapping; it must not be represented as matching the original seals.

Custody was operational on a shared filesystem, not cryptographic/access-control blindness. Seed/truth were released only after all 480 output/resource seals and complete input/source post-seals were checked. No failed/capped stage, redraw, resume or method correction occurred.

## Recheck the sealed records (no new draw or solver run)

Run from this directory, writing new analysis receipts/output rather than overwriting evidence:

```sh
env -u BOUND_EXPECTED_PARENT python3 source/bounded_checked.py analysis-rerun.resource.json 600 512 1800 \
  python3 source/analyze_frozen.py \
  --input input/solver-input.json --truth released-truth/secret-truth.json \
  --results results --expected-cases 40 --output analysis-rerun.json \
  --source-manifest-sha256 cdc5c7db8df5775817798653daa82f756a7dbdc7e41058884abd7e7e53b65b41 \
  --analysis-manifest-sha256 4dea59eddf446019f8130cb3d8c66f2dff95e42dc33e8391d03d89fcd778be06 \
  --truth-sha256 8c419d949805967b761f878e02282954ffe69261fc4076028b43cb9a28825b74
```

The complete oracle recomputation costs resources; this command is documentation, not a record of an extra execution. The holdout input is already fixed and published. Future methodological changes require separately labeled evidence, not reuse of this exposed sample as a fresh holdout. No standalone repository, global novelty or target-admission claim follows.
