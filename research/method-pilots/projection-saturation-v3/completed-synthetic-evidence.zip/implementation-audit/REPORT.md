# Independent implementation and protocol audit — PASS

2026-10-31. **PASS for the final disclosed synthetic R2 implementation and proposed fresh-holdout protocol. No remaining implementation/protocol blocker found.** This is not authorization to generate/run a holdout, target admission, publication approval, novelty proof, or a K4 result. No holdout generator was executed; no K4 or old holdout data was read. Producer files were not edited by this auditor.

## Final identities

Producer root: `../projection-saturation-v3`.

- `PROPOSED-FREEZE-MANIFEST.json`: `cdc5c7db8df5775817798653daa82f756a7dbdc7e41058884abd7e7e53b65b41`
- `ANALYSIS-MANIFEST.json`: `4dea59eddf446019f8130cb3d8c66f2dff95e42dc33e8391d03d89fcd778be06`
- Solver: `fd10590b09883269717c343068bfff6c8f6c8269afb44393e0efeed65b9e4399`
- Independent verifier: `748777cc6523f117e52f5114e8aafc18e4aef3faec6364bb8b8869bce4bde779`
- Holdout driver: `09027be148d676fa08907b47ead6758fb0d04835ff12a8fa136bd21e12d7c14c`
- Frozen analysis: `7f3877e89d4e8ad99135f951778b92602ca35fc24b0eea9ef5371aa0ba6de8e5`

`REVIEWED-FILES.json` pins all reviewed runtime, protocol, analysis, independent-control and design files. Both manifests and all their source hashes were rechecked at report creation. Earlier test reports retain their original manifest references; final solver/oracle hashes are unchanged from the full R2 record audit, while the final driver/protocol/analysis received additional controls below.

Final doc-only rebind verified the explicit twelve-trace cohort counts, deduplicated historical resource reserve, operational custody wording, and seal-check versus later receipt-limit validation order. Runtime and analysis source hashes did not change; no scientific rerun was required. Prior report and pins are retained as `pre-doc-rebind-*`.

## Independently justified correctness

- Exact CRT enumeration uses common original maximal supports, so field marginals cannot be incorrectly combined across supports. Every support of size at most the budget is contained in a maximal support.
- Grouped parity lifting preserves all observation/output parity identities. It places at most one parity-only coefficient in a group without an active mod13 coefficient, otherwise uses an active coefficient; the resulting original modular support stays within budget. The code validates the lifted original vector before advertising any value. Full-Z26 equality indicators are computed before prime reduction.
- Dense FIXED tags carry directly checked row-span identities; FULL is always a sound field upper bound. CRT yields sound 1/2/13/26-value bounds. Dense contradictions directly annihilate the matrix and separate the RHS.
- Saturation requires an actual sparse feasibility witness and equality of every requested lower/upper marginal. Empty requested sets still require feasibility. Certificates cover every upper value with an original sparse witness, reject duplicate/noncanonical coordinates and forbid unsupported model fields. No joint-relation, unique-law or true-model claim follows.
- Dense-feasible sparse-infeasible cases require exhaustive search, not a singleton shortcut. Resource/support caps remain INCOMPLETE; feasibility false in such a record means no witness established, not certified rejection. Hard-killed stages cannot be treated as exact outputs. Exhaustion claims are independently checked with complete reference enumeration rather than accepted from a saturation certificate.

## Tests actually performed by this audit

1. **Fresh disclosed controls:** 70 tiny ring systems, each off/on, support caps 0/1 and deliberately loose upper bounds; independent original-ring enumeration. Three new 31-feature contexts also exercised CRT/parity × off/on and caps, including empty/reordered requested sets. **3,215 primary witnesses and 94 certificates checked.** R2 rerun passed with stable source pins. `fresh-audit-results.json` retains details; the pre-R2 pass is preserved separately.
2. **Complete R2 evidence recheck:** Independently authored full oracle rerun on all 15 disclosed production instances, all **4,495 supports per instance**. All **180 final outputs**, **16,488 original per-value sparse witnesses**, and **30 certificates** passed. Every stage receipt, output identity, timing containment and paired summary arithmetic checked. Inner inclusive CPU was **52.988606 seconds**, consistent with the driver progress. See `full-record-results.json`.
3. **Bounded execution and failure paths:** Actual CPU, address-space, wall, exit-code, parent-death cascade, nested wall-timeout, wrong-parent and pre-setsid timeout controls. Driver controls rejected unwrapped execution, empty source manifests, secret metadata and mutated sources; an invalid synthetic stage retained an INCOMPLETE row and receipt. A separate sleeping-stub interruption—not a solver run—proved outer wall kill terminates descendants and durably retains the 62-CPU in-flight reserve with incomplete accounting.
4. **Fail-closed optimized interpreter:** solver, stage runner and driver reject optimized Python; certificate verification is no longer executed only inside an assert.
5. **Final analysis:** Nine synthetic seal mutations rejected (incomplete status/accounting/in-flight/planned count, input/output/resource corruption, post-source mismatch, missing final integrity). The final analysis code independently rechecked all 180 disclosed outputs and reproduced the charged cost aggregates. Seal placeholders were not synthetic cipher cases or holdout executions. See `analysis-control-results.json`.

### Retained test failure, not silently erased

The first full launcher suite passed. A repeat suite under load exceeded its test harness's five-second subprocess wait during the pre-setsid fixture. Its own resource receipt nevertheless showed the intended child SIGKILL and wall timeout; no orphan remained. The failed suite receipt/log are retained under `driver-snapshot-final/`. One targeted retry with a fifteen-second test-only wait passed without changing the launcher. This is disclosed harness timing fragility, not evidence of an unbounded child. An initial optimized-control assertion also expected overly specific error wording; all original receipts show the intended fail-closed result and are preserved.

Managed top-level audit receipts total **29.997699 CPU seconds**, including retained repeats and the failed fixture. See `RESOURCE-ACCOUNTING.json`; nested receipts are not added twice. These are managed-stage totals, not a claim to measure every lightweight orchestration instruction.

## Four-arm timing judgment

The comparison is fair for the stated scalar-mask plus per-value-witness contract: identical cases, requested coordinates, support ordering and witness propagation; four arms interleaved for three repetitions; saturation pays dense/certificate overhead. R0/R1 were preserved and R2 reran the same disclosed cohort, not new independent evidence. Dense-UNSAT certificate assembly and actual original-vector materialization now have correct phase charges. Field-image algebra remains traversal; residual setup/clock overhead remains in kernel totals.

The stage runner performs a measured payload serialization and then serializes the whole output again for the final file. Therefore **receipt-derived paired costs**, not internal `fully_checked_cpu` alone, are the primary end-to-end measure:

| Method | Sum of off case-median child+supervisor CPU | On | Charged-stage wins |
| --- | ---: | ---: | ---: |
| CRT | 7.220924 s | 3.276185 s | 7/15 |
| Parity | 4.609144 s | 2.289918 s | 8/15 |

The four saturation cases are repeated/alias contexts; one is a dependent misspecified twin. Most ordinary cases do not saturate and can regress. No universal speedup, recovery gain or default-on recommendation is justified. Misspecified twins remain wrong despite conditional singleton predictions. The final report appropriately distinguishes internal checked metrics from charged process metrics.

## Proposed holdout judgment and remaining authorization gate

The 40-case generator was reviewed statically only. It has no solver-based selection, separates solver input from secret seed/truth/plants, uses predeclared parity/context/contradiction/twin strata, and retains dependent twins as such. Custody is operational, not cryptographic blindness on a shared filesystem. A custodian must keep truth out of runner inputs and release it only after all 480 outputs are sealed; no redraw after failure or tuning after a draw.

The final runner enforces exact inherited limits, parent-death guard, source-manifest identity and required source set, input seals, atomic/fsynced in-flight reservations, aggregate budget, output/resource seals and final integrity. Partial/killed accounting reports known CPU plus outstanding reserve, not a fabricated measured total. The frozen analysis checks complete seals before opening truth, requires external source/analysis/truth pins, recomputes the full independent oracle, validates all witnesses/certificates/receipts, and reports paired internal/charged CPU, spread, memory, statuses and strata.

The proposed conservative allocation is 4,908 CPU seconds and at most 2 GiB simultaneous process ceilings, below the stated 8 CPU-hour/8 GiB envelope. This is an upper allocation, not a runtime forecast; an incomplete stage must stop the run without replenishment. **The next gate is explicit stage approval and custodian setup—not an additional solver fix. No holdout, K4 execution or publication was performed or authorized by this audit.**
