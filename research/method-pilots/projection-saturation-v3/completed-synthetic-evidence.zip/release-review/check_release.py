"""Independent final release checks; no generator, solver or oracle execution."""
import ast, collections, datetime, hashlib, json, math, pathlib, random, statistics, sys
R=pathlib.Path('/workspace/shared/projection-saturation-v3')
I=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-input')
O=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-results')
C=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-custody')
V=pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-validation')
D=pathlib.Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def same(a,b,path='root'):
    if type(a) in (int,float) and type(b) in (int,float):
        assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10),(path,a,b)
    elif isinstance(a,dict):
        assert isinstance(b,dict) and set(a)==set(b),(path,'keys',set(a),set(b))
        for k in a:same(a[k],b[k],path+'/'+str(k))
    elif isinstance(a,list):
        assert isinstance(b,list) and len(a)==len(b),(path,'length')
        for i,(x,y) in enumerate(zip(a,b)):same(x,y,path+'/'+str(i))
    else:assert a==b,(path,a,b)
def dist(seq):
    x=sorted(seq)
    def q(t):
        u=(len(x)-1)*t;j=int(u);return x[j]+(x[min(j+1,len(x)-1)]-x[j])*(u-j)
    return dict(n=len(x),min=x[0],q25=q(.25),median=q(.5),q75=q(.75),max=x[-1])
pins={'PROPOSED-FREEZE-MANIFEST.json':'cdc5c7db8df5775817798653daa82f756a7dbdc7e41058884abd7e7e53b65b41',
      'ANALYSIS-MANIFEST.json':'4dea59eddf446019f8130cb3d8c66f2dff95e42dc33e8391d03d89fcd778be06'}
allpins={}
for filename,pin in pins.items():
    assert sha(R/filename)==pin
    for name,h in read(R/filename)['sources'].items():assert sha(R/name)==h;allpins[name]=h
assert sha(pathlib.Path('/workspace/shared/projection-saturation-v3-audit/REPORT.md'))=='098e7d872ab9a07ea9238e94a4f712c79ea45efebc4169cc5c09d913481ea73a'
gate=read(V/'RELEASE-GATE.json');commit=read(C/'CUSTODY-COMMITMENT.json');start=read(C/'DRAW-STARTED.json')
assert gate['status']=='PASS_RELEASE_AUTHORIZED' and gate['truth_was_opened_by_gate'] is False
assert start['verified_sources']==allpins and start['source_manifests']==commit['source_manifests']==pins
assert start['draw_script_sha256']==sha(C/'draw_once.py') and start['no_redraw'] and start['draw_limit']==1
assert datetime.datetime.fromisoformat(start['utc'])<datetime.datetime.fromisoformat(commit['utc'])<datetime.datetime.fromisoformat(gate['utc'])
drawtree=ast.parse((C/'draw_once.py').read_text())
assert sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='token_bytes' for n in ast.walk(drawtree))==1
assert sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='generate' for n in ast.walk(drawtree))==1
assert sha(C/'secret-truth.json')==gate['truth_sha256']==commit['secret_truth_sha256']
assert sha(I/'solver-input.json')==gate['input_sha256']==commit['solver_input_sha256']
truth=read(C/'secret-truth.json');inputs=read(I/'solver-input.json');analysis=read(V/'frozen-analysis.json');desc=read(V/'descriptive-results.json')
assert hashlib.sha256(truth['seed'].to_bytes(32,'big')).hexdigest()==commit['seed_bytes_sha256']
assert truth['classification']=='fresh-heldout-after-approval' and set(inputs)=={'cases'}
assert all(set(x)=={'id','instance'} for x in inputs['cases']) and len(inputs['cases'])==len(truth['cases'])==40
assert sha(V/'frozen-analysis.json')==desc['frozen_analysis_sha256']
assert analysis['status']=='PASS' and analysis['cases']==40 and analysis['outputs_verified']==480
assert analysis['truth_sha256']==commit['secret_truth_sha256'] and analysis['input_sha256']==commit['solver_input_sha256']
p=read(O/'progress.json');post=read(O/'post-run-integrity.json')
assert p['status']=='COMPLETE' and p['planned']==len(p['completed'])==480 and p['accounting_complete'] and p['in_flight'] is None and p['outstanding_cpu_reserve']==0
assert p['input_sha256']==post['input_sha256']==commit['solver_input_sha256']
assert p['manifest_sha256']==post['manifest_sha256']==pins['PROPOSED-FREEZE-MANIFEST.json'] and post['sources']==read(R/'PROPOSED-FREEZE-MANIFEST.json')['sources']
assert sha(O/'progress.json')==gate['progress_sha256'] and sha(O/'post-run-integrity.json')==gate['post_run_integrity_sha256']
jobs=[(i,m,on,rep) for i in range(40) for m in ('crt','parity') for on in (0,1) for rep in range(3)]
random.Random(202610311934).shuffle(jobs)
assert read(O/'schedule.json')==read(I/'schedule.json')==[list(x) for x in jobs]
assert sha(O/'schedule.json')==commit['schedule_sha256']==gate['schedule_sha256']
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'independent'))
from verifier import materialize, verify, instance_hash
raw={};total=0.;witnesses=certificates=0;status=collections.Counter();peak=0
oracles={x['id']:x for x in analysis['oracle']};labels={x['id']:x for x in truth['cases']}
assert len(oracles)==len(labels)==40
oracle_pins={x['file']:x['sha256'] for x in analysis['output_pins']}
assert len(oracle_pins)==480
for job,seal in zip(jobs,p['completed']):
    i,m,on,rep=job;name=f'{i:02d}-{m}-{on}-{rep}';f=O/(name+'.json');rf=O/(name+'.resource.json')
    assert seal['name']==name and seal['status']=='OUTPUT_SEALED' and seal['returncode']==0
    assert sha(f)==seal['output_sha256']==oracle_pins[f.name] and sha(rf)==seal['resource_sha256']
    out=read(f);rec=read(rf);res=out['result'];case=inputs['cases'][i];label=labels[case['id']]
    assert out['id']==case['id'] and out['method']==m and out['saturation'] is bool(on)
    assert label['instance']==case['instance']
    assert oracles[case['id']]['instance_hash']==instance_hash(case['instance'])
    assert oracles[case['id']]['result']['supports']==4495
    assert res['masks']==oracles[case['id']]['result']['masks'] and res['feasible']==oracles[case['id']]['result']['feasible']
    assert res['status'] in ('ENUMERATED','SATURATED','DENSE_UNSAT')
    assert bool(res['certificate'])==(res['status'] in ('SATURATED','DENSE_UNSAT'))
    a,b,rows,n,s=materialize(case['instance']);assert len(res['masks'])==len(rows)==len(res['witnesses'])==91
    for row,mask,covers in zip(rows,res['masks'],res['witnesses']):
        assert set(covers)=={str(v) for v in range(26) if mask>>v&1}
        for val,w in covers.items():
            assert len(w)<=3 and all(type(j) is int and type(v) is int and 0<=j<31 and 1<=v<=25 for j,v in w)
            assert [j for j,v in w]==sorted(set(j for j,v in w))
            assert all(sum(r[j]*v for j,v in w)%26==bv for r,bv in zip(a,b))
            assert sum(row[j]*v for j,v in w)%26==int(val)
            witnesses+=1
    if res['certificate']:assert verify(case['instance'],res['certificate']);certificates+=1
    assert rec['exit_code']==0 and not rec['wall_timeout'] and rec['parent_death_guard']
    assert rec['limits']=={'cpu_seconds_per_process':30,'address_space_bytes_per_process':268435456,'wall_seconds':60}
    assert all(math.isfinite(rec[k]) and rec[k]>=0 for k in ('child_cpu_seconds','parent_cpu_seconds','wall_seconds'))
    assert total+62<=2000
    total+=rec['child_cpu_seconds']+rec['parent_cpu_seconds']
    peak=max(peak,rec['child_peak_rss_kib'],rec['parent_peak_rss_kib'])
    raw[i,m,on,rep]=(out,rec)
    status[m,on,label['stratum'],res['status']]+=1
same(total,p['inclusive_inner_cpu_actual_known']);same(total,analysis['stage_inclusive_resource_cpu']);same(total,gate['stage_inclusive_cpu_seconds'])
assert witnesses==analysis['witnesses_verified']==47412 and certificates==analysis['certificates_verified']==78
assert collections.Counter(x['stratum'] for x in truth['cases'])=={'ordinary':16,'constant':3,'periodic':3,'binary':3,'even':3,'zero-law':4,'contradiction':4,'misspecified':4}
hidden=[]
for i,x in enumerate(truth['cases']):
    a,b,rows,n,s=materialize(x['instance']);ref=oracles[x['id']]['result'];unknown=[j for j in range(91) if str(j+6) not in x['instance']['observed']]
    if 'plant' in x:
        plant=x['plant'];assert len(plant)<=3
        assert [sum(row[j]*v for j,v in plant)%26 for row in rows]==x['truth']
        assert all(sum(row[j]*v for j,v in plant)%26==bv for row,bv in zip(a,b))
    if x['stratum']=='misspecified':
        original=labels[x['source_id']]
        assert x['instance']==original['instance'] and x['truth'][1:]==original['truth'][1:] and x['truth'][0]==(original['truth'][0]+1)%26
    excluded=[];wrong=[]
    if x['truth'] is not None:
        for j in unknown:
            if not ref['masks'][j]>>x['truth'][j]&1:
                row={'position_zero_based':j+6,'truth':x['truth'][j],'allowed_values':[v for v in range(26) if ref['masks'][j]>>v&1]};excluded.append(row)
                if ref['masks'][j].bit_count()==1:wrong.append(row)
    hidden.append({'id':x['id'],'stratum':x['stratum'],'source_id':x.get('source_id'),'feasible':ref['feasible'],'unknown_positions':len(unknown),
      'forced_unknown':sum(ref['masks'][j].bit_count()==1 for j in unknown),'hidden_truth_outside_masks':excluded,'wrong_forced':wrong,'truth_present':x['truth'] is not None,
      'marginal_cardinality_counts':{str(k):v for k,v in collections.Counter(z.bit_count() for z in ref['masks']).items()}})
same(hidden,desc['exact_hidden_truth_results'])
paired=[]
for i,item in enumerate(inputs['cases']):
    for m in ('crt','parity'):
        arms={}
        for on in (0,1):
            rr=[raw[i,m,on,rep] for rep in range(3)]
            vals={'median_charged_child_cpu':statistics.median(r['child_cpu_seconds'] for d,r in rr),
              'median_charged_stage_cpu':statistics.median(r['child_cpu_seconds']+r['parent_cpu_seconds'] for d,r in rr),
              'median_checked_cpu':statistics.median(d['result']['fully_checked_cpu'] for d,r in rr),
              'median_kernel_cpu':statistics.median(d['result']['kernel_cpu'] for d,r in rr),
              'min_checked_cpu':min(d['result']['fully_checked_cpu'] for d,r in rr),'max_checked_cpu':max(d['result']['fully_checked_cpu'] for d,r in rr),
              'median_phase_cpu':{k:statistics.median(d['result']['timing'][k] for d,r in rr) for k in rr[0][0]['result']['timing']},
              'peak_rss_kib':max(d['rss_kib'] for d,r in rr),'statuses':[d['result']['status'] for d,r in rr],'supports':[d['result']['stats']['supports'] for d,r in rr]}
            arms[str(on)]=vals
        h=hidden[i];paired.append({'id':item['id'],'stratum':h['stratum'],'method':m,'arms':arms,'forced_unknown':h['forced_unknown'],'wrong_forced':len(h['wrong_forced']) if h['truth_present'] else None,'dependent_twin':h['stratum']=='misspecified'})
same(paired,analysis['paired'])
def selected(r,g):
    if g=='ALL':return True
    if g=='IN_FAMILY_PLANTED':return r['stratum'] not in ('contradiction','misspecified')
    if g=='CONTRADICTION_CONTROLS':return r['stratum']=='contradiction'
    if g=='DEPENDENT_TWINS':return r['stratum']=='misspecified'
    if g.startswith('ordinary-weight-'):return r['stratum']=='ordinary' and r['id'].startswith('ordinary-w'+g[-1]+'-')
    return g==r['stratum']
for key,reported in desc['summaries'].items():
    method,group=key.split('/');rr=[x for x in paired if x['method']==method and selected(x,group)]
    costs={}
    for metric in ('charged_child_cpu','charged_stage_cpu','checked_cpu','kernel_cpu'):
        off=[r['arms']['0']['median_'+metric] for r in rr];on=[r['arms']['1']['median_'+metric] for r in rr];delta=[y-x for x,y in zip(off,on)];pc=[100*(y/x-1) for x,y in zip(off,on) if x>0]
        costs[metric]={'sum_off_case_medians':sum(off),'sum_on_case_medians':sum(on),'aggregate_percent_change':100*(sum(on)/sum(off)-1) if sum(off)>0 else None,
          'wins':sum(z<0 for z in delta),'ties':sum(z==0 for z in delta),'losses':sum(z>0 for z in delta),'paired_delta_seconds':dist(delta),'paired_percent_change':dist(pc) if pc else None}
    same({'cases':len(rr),'costs':costs},reported,key)
    for on in (0,1):
        arm=key+'/'+str(on);ct=collections.Counter(st for r in rr for st in r['arms'][str(on)]['statuses']);n=3*len(rr)
        same({'total_runs':n,'run_counts':dict(ct),'case_counts':{k:v/3 for k,v in ct.items()},'run_rates':{k:v/n for k,v in ct.items()}},desc['statuses'][arm],arm)
        phase={k:sum(r['arms'][str(on)]['median_phase_cpu'][k] for r in rr) for k in rr[0]['arms'][str(on)]['median_phase_cpu']}
        same(phase,desc['sum_case_median_phase_cpu'][arm]);same(max(r['arms'][str(on)]['peak_rss_kib'] for r in rr),desc['peak_solver_rss_kib'][arm])
receipts={};all_total=250.084503
for name,path,limits in [('draw',C/'draw.resource.json',(10,256,30)),('holdout',I/'holdout-outer.resource.json',(602,512,3600)),('release_gate',V/'release-gate.resource.json',(10,256,30)),('analysis',V/'analysis.resource.json',(600,512,1800)),('summary',V/'summary.resource.json',(10,256,30))]:
    r=read(path);assert r['exit_code']==0 and not r['wall_timeout'] and r['parent_death_guard']
    cpu,mem,wall=limits;assert r['limits']=={'cpu_seconds_per_process':cpu,'address_space_bytes_per_process':mem*1024**2,'wall_seconds':wall}
    charged=r['child_cpu_seconds']+r['parent_cpu_seconds'];all_total+=charged
    receipts[name]={'sha256':sha(path),'inclusive_cpu_seconds':charged}
assert receipts['holdout']['inclusive_cpu_seconds']>=total
assert 250.084503+sum(receipts[k]['inclusive_cpu_seconds'] for k in ('draw','release_gate','summary'))<500
assert all_total+22<4908
report_text=(V/'REPORT.md').read_text()
for phrase in ('47,412','78 certificates','optional, default-off','not a K4 run','32 in-family planted','Four contradiction controls','not independent recovery evidence','Three repeats','regressions'):
    assert phrase in report_text,phrase
result={'status':'PASS','source_manifests':pins,'source_pins':allpins,'outputs_rechecked':480,'per_value_witnesses_rechecked':witnesses,'certificates_rechecked':certificates,
  'masks_compared_to_frozen_independent_oracle_records':480,'oracle_rerun':False,'solver_or_generator_rerun':False,
  'case_count':40,'stage_failures':0,'missing_or_capped_outputs':0,'sealed_inner_cpu_seconds':total,'peak_stage_process_rss_kib':peak,
  'top_level_receipts':receipts,'managed_total_before_this_review_cpu_seconds':all_total,
  'all_posthoc_summary_groups_arithmetic_checked':len(desc['summaries']),
  'reviewed_artifact_sha256':{name:sha(V/name) for name in ('REPORT.md','frozen-analysis.json','descriptive-results.json','RELEASE-GATE.json')},
  'limitations':['This review checks all masks against the frozen oracle records, without executing a second full oracle. The separately pinned frozen analysis already performed that full enumeration.',
    'One-draw and noninspection custody rest on retained script/commitments and operational records, not cryptographic filesystem isolation.',
    'No universal performance, comparative recovery, target-admission or novelty claim is justified.']}
with (D/'review-results.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ('status','outputs_rechecked','per_value_witnesses_rechecked','certificates_rechecked','sealed_inner_cpu_seconds','managed_total_before_this_review_cpu_seconds','all_posthoc_summary_groups_arithmetic_checked')}))
