"""One authorized fresh synthetic draw; does not execute any solver."""
import datetime, hashlib, json, os, pathlib, random, secrets, sys

ROOT = pathlib.Path('/workspace/shared/projection-saturation-v3')
CUSTODY = pathlib.Path(__file__).resolve().parent
INPUT = pathlib.Path('/workspace/shared/projection-saturation-v3-holdout-input')
PINS = {'PROPOSED-FREEZE-MANIFEST.json': 'cdc5c7db8df5775817798653daa82f756a7dbdc7e41058884abd7e7e53b65b41',
        'ANALYSIS-MANIFEST.json': '4dea59eddf446019f8130cb3d8c66f2dff95e42dc33e8391d03d89fcd778be06'}
AUDIT = pathlib.Path('/workspace/shared/projection-saturation-v3-audit/REPORT.md')
AUDIT_PIN = '098e7d872ab9a07ea9238e94a4f712c79ea45efebc4169cc5c09d913481ea73a'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, obj):
    with p.open('x') as f:
        f.write(json.dumps(obj, indent=2, sort_keys=True) + '\n')
        f.flush(); os.fsync(f.fileno())
    p.chmod(0o444)

assert not INPUT.exists(), 'No overwrite or repeat draw'
assert sha(AUDIT) == AUDIT_PIN
verified = {}
for name, expected in PINS.items():
    assert sha(ROOT/name) == expected
    for rel, pin in json.loads((ROOT/name).read_text())['sources'].items():
        assert sha(ROOT/rel) == pin, rel
        verified[rel] = pin
save(CUSTODY/'DRAW-STARTED.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'draw_limit': 1, 'no_redraw': True, 'source_manifests': PINS, 'verified_sources': verified,
    'audit_sha256': AUDIT_PIN, 'draw_script_sha256': sha(pathlib.Path(__file__))})
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from proposed_holdout_generator import generate
seed_bytes = secrets.token_bytes(32)
payload = generate(int.from_bytes(seed_bytes, 'big'))
assert set(payload) == {'solver_input', 'secret_truth'}
assert len(payload['solver_input']['cases']) == 40
assert all(set(c) == {'id','instance'} for c in payload['solver_input']['cases'])
INPUT.mkdir()
save(CUSTODY/'secret-truth.json', payload['secret_truth'])
save(INPUT/'solver-input.json', payload['solver_input'])
jobs=[(i,m,on,r) for i in range(40) for m in ('crt','parity') for on in (0,1) for r in range(3)]
random.Random(202610311934).shuffle(jobs)
with (INPUT/'schedule.json').open('x') as f:
    f.write(json.dumps(jobs)); f.flush(); os.fsync(f.fileno())
(INPUT/'schedule.json').chmod(0o444)
commitment={'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'classification': 'fresh-synthetic-heldout-after-approval',
    'seed_entropy_bits': 256, 'seed_bytes_sha256': hashlib.sha256(seed_bytes).hexdigest(),
    'solver_input_sha256': sha(INPUT/'solver-input.json'), 'secret_truth_sha256': sha(CUSTODY/'secret-truth.json'),
    'schedule_sha256': sha(INPUT/'schedule.json'), 'schedule_seed': 202610311934,
    'case_count': 40, 'stage_count': 480, 'source_manifests': PINS, 'audit_sha256': AUDIT_PIN,
    'custody': 'Operational independence only; shared filesystem does not supply access-control blindness.',
    'release_condition': 'Independent verification of all 480 output/resource seals and complete source/input post-run seals.'}
save(CUSTODY/'CUSTODY-COMMITMENT.json', commitment)
save(INPUT/'INPUT-COMMITMENT.json', {k:commitment[k] for k in ('classification','solver_input_sha256','schedule_sha256','schedule_seed','case_count','stage_count','source_manifests','audit_sha256')})
print(json.dumps({'status':'ONE_DRAW_SEALED','solver_input_sha256':commitment['solver_input_sha256'],
    'schedule_sha256':commitment['schedule_sha256'], 'custody_commitment_sha256':sha(CUSTODY/'CUSTODY-COMMITMENT.json')}))
