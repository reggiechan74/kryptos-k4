# Parity-first v2: development and completed synthetic validation

The two namespaces are intentionally distinct:

- [Development](development/README.md): exact approved scientific source, development README/report, original/rejected methods and wrapper-failure history.
- [Validation](validation/README.md): completed40-case,240-output experiment and independent audit. Both methods return identical prediction sets; the measured improvement is computational efficiency, not additional recovered information.

## Verify this public bundle

From this directory, run `python verify_public_package.py`. This performs static hash/mapping checks only—no generator, solver or scientific rerun. `PUBLIC-VERIFICATION.json` and `PUBLIC-VERIFICATION-RESOURCE.json` record its bounded execution.

The approved freeze pins `development/README.md` and `development/REPORT.md`, **not** the validation README. Other approved computational pins are checked in both namespaces. `PROVENANCE.json` maps all679 original artifacts to their public paths and records original/public hashes and reasons for every metadata correction.

Five resource receipts have sanitized absolute execution/custody paths. Their measured quantities and status are unchanged, but their public bytes are **not claimed to equal original sealed bytes**. Original hash commitments remain in historical checksum lists and the original output seal. Of523 pre-release sealed files, only the public copy of the generation receipt is redacted; the later release receipt was not part of that seal.

The earlier validation verifier and `FINAL-INTEGRITY.json` are preserved under `validation/historical/`. They describe a pre-packaging execution workspace and **are not the current public-package verifier**. Historical checksum lists likewise remain evidence, while current namespace/root checksums describe published bytes.

All computational sources, inputs, seeds, truth,240 outputs, witness checks, timing values and scientific conclusions remain unchanged. These release metadata corrections did not rerun solvers or retune code. This bundle does not authorize a real-target test or establish worldwide novelty.
