# Release-only verification history

The first new public-package verifier rejected its own literal privacy-check URL pattern, before any scientific execution. The pattern was expressed without embedding that literal; the second static verification passed. The original nonzero resource receipt and empty stdout are retained. No computational source, data, timing or solver output changed.
