"""Static mapping-aware verifier. Never executes generators, solvers or auditors."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
p=json.loads((ROOT/'PROVENANCE.json').read_text());entries=p['entries'];by={(e['origin_namespace'],e['origin_path']):e for e in entries}
assert len(by)==len(entries)==679
for e in entries:
 assert H(e['public_path'])==e['public_sha256'],e['public_path']
 if e['action'] in ('exact_copy','relocated_exact_copy'):assert e['original_sha256']==e['public_sha256']
for ns in ('development','validation'):
 checksum=ROOT/by[ns,'SHA256SUMS']['public_path']
 for line in checksum.read_text().splitlines():
  digest,rel=line.split('  ',1);assert by[ns,rel]['original_sha256']==digest,(ns,rel)
assert H('development/FREEZE-MANIFEST.json')==p['approved_freeze_manifest_sha256']=='30e9950c7073f608fb4e62b5991eaf77bdb6e9c44417d85ff4f1475a84873302'
freeze=json.loads((ROOT/'development/FREEZE-MANIFEST.json').read_text())
for rel,digest in freeze['source_sha256'].items():
 assert H('development/'+rel)==digest,rel
 # Validation editorial README/report are intentionally not the development pins.
 if rel not in ('README.md','REPORT.md'):assert H('validation/'+rel)==digest,rel
assert H('validation/OUTPUT-SEAL.json')==p['validation_output_seal_sha256']
seal=json.loads((ROOT/'validation/OUTPUT-SEAL.json').read_text());changed=[]
for rel,digest in seal['sha256'].items():
 e=by['validation',rel];assert e['original_sha256']==digest,rel
 if e['public_sha256']!=digest:
  assert e['action']=='sanitized_metadata_copy';changed.append(rel)
assert len(seal['sha256'])==523
assert changed==['generation-resource-receipt.json'],changed
# Data/outputs and computational sources stay byte-identical, not merely equivalent.
for e in entries:
 rel=e['origin_path']
 if e['origin_namespace']=='validation' and (rel.startswith('benchmark/') or rel in ('solver-inputs.json','released-truth.json','released-seed.json','independent-audit-results.json')):
  assert e['original_sha256']==e['public_sha256'],rel
# Privacy check ignores harmless generic words, not executable/source evidence.
for f in ROOT.rglob('*'):
 if f.is_file() and f.suffix in ('.md','.json','.py'):
  text=f.read_text();assert not re.search(r'page_[0-9a-f]{20,}|https://chatgpt.com/' + 'space/|/work' + 'space/|/ro' + 'ot/',text),f
report=dict(passed=True,original_artifacts_mapped=len(entries),development_freeze_pins_exact=True,validation_computational_pins_exact=True,all240_outputs_and_data_exact=True,original523_seal_commitments_verified=True,sealed_public_metadata_redactions=changed,total_sanitized_receipts=sum(e['action']=='sanitized_metadata_copy' for e in entries),historical_verifier_not_current=True,scientific_execution=False)
print(json.dumps(report,indent=2))
