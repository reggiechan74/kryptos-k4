"""Synthetic-development exact sparse-function decoders. No target input bundled."""
from itertools import combinations, product

GROUP = tuple([0]+list(range(1,7))+list(range(1,7))+list(range(7,25)))
REPS = tuple(GROUP.index(g) for g in range(25))

def features(x):
    return [1]+list(x)+[v*v%26 for v in x]+[x[i]*x[j]%26 for i,j in combinations(range(6),2)]+[int(x[i]==x[i+1]) for i in (0,2,4)]

def field_solve(rows, rhs, p):
    n=len(rows[0]); a=[[v%p for v in r]+[b%p] for r,b in zip(rows,rhs)]; piv=[]; k=0
    for j in range(n):
        t=next((i for i in range(k,len(a)) if a[i][j]),None)
        if t is None: continue
        a[k],a[t]=a[t],a[k]; z=pow(a[k][j],-1,p); a[k]=[(v*z)%p for v in a[k]]
        for i in range(len(a)):
            if i!=k and a[i][j]:
                z=a[i][j]; a[i]=[(v-z*w)%p for v,w in zip(a[i],a[k])]
        piv.append(j); k+=1
    if any(not any(r[:n]) and r[n] for r in a): return None
    x=[0]*n
    for i,j in enumerate(piv): x[j]=a[i][n]
    ns=[]
    for f in range(n):
        if f not in piv:
            v=[0]*n; v[f]=1
            for i,j in enumerate(piv): v[j]=-a[i][f]%p
            ns.append(v)
    return x,ns

def dot(a,b,p): return sum(x*y for x,y in zip(a,b))%p

def images(sol,row,p):
    a,ns=sol; base=dot(a,row,p)
    for v in ns:
        d=dot(v,row,p)
        if d:
            inv=pow(d,-1,p)
            return {u:[(x+(u-base)*inv*y)%p for x,y in zip(a,v)] for u in range(p)}
    return {base:a}

def crt(a,b): return a+13*((b-a)%2)

def lift(s,a,beta):
    alpha=dict(zip(s,a)); bits={g:0 for g in range(25)}
    for g in beta: bits[g]=1
    parity={}
    for g in range(25):
        active=[j for j in s if GROUP[j]==g and alpha[j]]
        if active: parity[active[0]]=bits[g]
        elif bits[g]: alpha[REPS[g]]=0; parity[REPS[g]]=1
    return [[j,crt(v,parity.get(j,0))] for j,v in sorted(alpha.items()) if crt(v,parity.get(j,0))]

def solve(case,method='parity'):
    """Primary matched contract: masks and a sparse witness per allowed row/value.
    Output rows are all91 modeled positions, including24 observations. Empty masks
    are infeasibility, not certainty. No coefficient/global uniqueness claimed.
    """
    c=case['ciphertext']; assert len(c)==97 and all(0<=x<26 for x in c)
    obs={int(k):v for k,v in case['observed'].items()}; assert obs
    rows=[features([c[i-j] for j in range(1,7)]) for i in range(6,97)]
    inds=sorted(obs); ar=[rows[i-6] for i in inds]; b=[obs[i] for i in inds]
    masks=[0]*91; witnesses=[{} for _ in rows]; stats=dict(U=0,M=0,E=0,F=0)
    supports=list(combinations(range(31),3))
    def add(s,sol13,sol2=None,beta=None,pred=None):
        for i,row in enumerate(rows):
            r=[row[j] for j in s]
            im13=images(sol13,r,13)
            im2=images(sol2,r,2) if sol2 is not None else {pred[i]:None}
            for u,a in im13.items():
                for v,e in im2.items():
                    z=crt(u,v)
                    if not masks[i]>>z&1:
                        w=lift(s,a,beta) if beta is not None else [[j,crt(x,y)] for j,x,y in zip(s,a,e) if crt(x,y)]
                        masks[i]|=1<<z; witnesses[i][str(z)]=w
    if method=='crt':
        for s in supports:
            stats['U']+=1; stats['E']+=1
            mat=[[r[j] for j in s] for r in ar]
            q2=field_solve(mat,b,2)
            if q2 is None: continue
            q13=field_solve(mat,b,13)
            if q13 is None: continue
            stats['F']+=1; add(s,q13,sol2=q2)
    elif method=='parity':
        synd=[sum((r[REPS[g]]%2)<<i for i,r in enumerate(ar)) for g in range(25)]
        wanted=sum((v%2)<<i for i,v in enumerate(b)); matching=[]
        for k in range(4):
            for beta in combinations(range(25),k):
                z=0
                for g in beta: z^=synd[g]
                if z==wanted: matching.append(beta)
        stats['M']=len(matching)
        # Index every maximal support by all subsets of its covered groups.
        index={}
        for s in supports:
            gs=sorted(set(GROUP[j] for j in s))
            for k in range(len(gs)+1):
                for key in combinations(gs,k): index.setdefault(key,[]).append(s)
        cache={}
        for beta in matching:
            pred=[sum(r[REPS[g]] for g in beta)%2 for r in rows]
            for s in index.get(beta,[]):
                stats['E']+=1
                if s not in cache:
                    stats['U']+=1; cache[s]=field_solve([[r[j] for j in s] for r in ar],b,13)
                q=cache[s]
                if q is None: continue
                stats['F']+=1; add(s,q,beta=beta,pred=pred)
    else: raise ValueError(method)
    return dict(status='complete',feasible=bool(stats['F']),masks=masks,witnesses=witnesses,stats=stats)
