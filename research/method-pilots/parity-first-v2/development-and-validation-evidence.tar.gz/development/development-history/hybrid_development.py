import json,time,resource
from hybrid import solve
cases=json.load(open('../parity-first-v2-audit/development_cases.json'))['cases'];expected=json.load(open('../parity-first-v2-audit/independent_expected.json'));report=[]
for c in cases:
    selected='crt' if all(v%2==0 for v in c['observed'].values()) else 'parity'
    t=time.process_time();got=solve(c);elapsed=time.process_time()-t
    assert got['masks']==expected[c['id']]['masks'] and got['feasible']==expected[c['id']]['feasible']
    report.append(dict(id=c['id'],selected=selected,cpu_seconds=elapsed,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
json.dump(report,open('hybrid-development-results.json','w'),indent=2)
print(json.dumps(report,indent=2))
