"""Development-only fixed structural dispatcher; not the selected method."""
from decoder_optimized import solve as underlying

def solve(case,method='hybrid'):
    if method!='hybrid':return underlying(case,method)
    # Zero parity syndrome includes beta=0, so all4495 supports are eligible.
    selected='crt' if all(v%2==0 for v in case['observed'].values()) else 'parity'
    return underlying(case,selected)
