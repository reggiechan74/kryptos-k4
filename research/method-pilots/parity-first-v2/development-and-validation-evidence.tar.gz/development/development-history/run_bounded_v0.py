"""External single-process stage supervisor; preserves exit/cap failures and RSS."""
import json,os,resource,subprocess,sys,time
# Usage receipt.json CPU-seconds MiB wall-seconds command...
path,cpu,mem,wall,*cmd=sys.argv[1:]; cpu=int(cpu); mem=int(mem); wall=int(wall)
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu+1))
    resource.setrlimit(resource.RLIMIT_AS,(mem*1024**2,mem*1024**2))
t=time.monotonic(); p=subprocess.Popen(cmd,preexec_fn=limits,start_new_session=True)
try: rc=p.wait(timeout=wall); timeout=False
except subprocess.TimeoutExpired:
    import signal
    os.killpg(p.pid,signal.SIGKILL); rc=p.wait(); timeout=True
r=resource.getrusage(resource.RUSAGE_CHILDREN)
json.dump(dict(command=cmd,exit=rc,wall_timeout=timeout,wall_seconds=time.monotonic()-t,cpu_seconds=r.ru_utime+r.ru_stime,peak_rss_kib=r.ru_maxrss,limits=dict(cpu_seconds=cpu,memory_mib=mem,wall_seconds=wall)),open(path,'w'),indent=2)
sys.exit(rc if rc>=0 else 128-rc)
