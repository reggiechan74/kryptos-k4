"""Bound one single-process synthetic stage and its lightweight supervisor.
Usage: receipt.json cpu_seconds memory_MiB wall_seconds command ...
Nested children are permitted only via this same launcher, with an explicit
BOUND_EXPECTED_PARENT PID set by each launching driver. Each node has its own
limits; nested CPU totals must be collected from stage receipts without duplication.
"""
import json,os,resource,signal,sys,time,ctypes

def parent_death_guard(expected=None):
    # Linux: terminate every supervised link if its immediate parent disappears.
    parent=os.getppid() if expected is None else expected
    if os.getppid()!=parent: os.kill(os.getpid(),signal.SIGKILL)
    if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGKILL,0,0,0)!=0:
        raise OSError(ctypes.get_errno(), "PR_SET_PDEATHSIG failed")
    if os.getppid()!=parent: os.kill(os.getpid(),signal.SIGKILL)
parent_death_guard(int(os.environ["BOUND_EXPECTED_PARENT"]) if "BOUND_EXPECTED_PARENT" in os.environ else None)
out,cpu,mem,wall,*cmd=sys.argv[1:];cpu=int(cpu);mem=int(mem)*1024**2;wall=int(wall)
resource.setrlimit(resource.RLIMIT_AS,(mem,mem));resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu+1))
start=time.monotonic();supervisor_pid=os.getpid();pid=os.fork()
if pid==0:
    parent_death_guard(supervisor_pid);os.setsid();os.execvp(cmd[0],cmd)
timed_out=False
def timeout(*_):
    global timed_out
    timed_out=True
    try: os.killpg(pid,signal.SIGKILL)
    except ProcessLookupError: pass
signal.signal(signal.SIGALRM,timeout);signal.alarm(wall)
_,status,u=os.wait4(pid,0);signal.alarm(0);p=resource.getrusage(resource.RUSAGE_SELF)
r=dict(command=cmd,wall_seconds=time.monotonic()-start,child_cpu_seconds=u.ru_utime+u.ru_stime,parent_cpu_seconds=p.ru_utime+p.ru_stime,child_peak_rss_kib=u.ru_maxrss,parent_peak_rss_kib=p.ru_maxrss,exit_code=os.waitstatus_to_exitcode(status),wall_timeout=timed_out,limits=dict(cpu_seconds_per_process=cpu,address_space_bytes_per_process=mem,wall_seconds=wall),classification='synthetic-only',parent_death_guard=True)
open(out,'w').write(json.dumps(r,indent=2)+'\n');sys.exit(r['exit_code'] if r['exit_code']>=0 else 1)
