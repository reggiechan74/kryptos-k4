"""Bound one single-process synthetic stage and its lightweight supervisor.
Usage: receipt.json cpu_seconds memory_MiB wall_seconds command ...
No child processes permitted inside the stage: CPU/RSS are process accounting.
"""
import json,os,resource,signal,sys,time
out,cpu,mem,wall,*cmd=sys.argv[1:];cpu=int(cpu);mem=int(mem)*1024**2;wall=int(wall)
resource.setrlimit(resource.RLIMIT_AS,(mem,mem));resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu+1))
start=time.monotonic();pid=os.fork()
if pid==0:
    os.setsid();os.execvp(cmd[0],cmd)
timed_out=False
def timeout(*_):
    global timed_out
    timed_out=True
    try: os.killpg(pid,signal.SIGKILL)
    except ProcessLookupError: pass
signal.signal(signal.SIGALRM,timeout);signal.alarm(wall)
_,status,u=os.wait4(pid,0);signal.alarm(0);p=resource.getrusage(resource.RUSAGE_SELF)
r=dict(command=cmd,wall_seconds=time.monotonic()-start,child_cpu_seconds=u.ru_utime+u.ru_stime,parent_cpu_seconds=p.ru_utime+p.ru_stime,child_peak_rss_kib=u.ru_maxrss,parent_peak_rss_kib=p.ru_maxrss,exit_code=os.waitstatus_to_exitcode(status),wall_timeout=timed_out,limits=dict(cpu_seconds_per_process=cpu,address_space_bytes_per_process=mem,wall_seconds=wall),classification='synthetic-only')
open(out,'w').write(json.dumps(r,indent=2)+'\n');sys.exit(r['exit_code'] if r['exit_code']>=0 else 1)
