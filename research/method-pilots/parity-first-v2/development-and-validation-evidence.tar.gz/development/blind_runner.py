"""Proposed frozen paired driver. DO NOT RUN on holdout before approval.
Input is stripped solver cases, never source terms/truth. Runtime order seed only.
Launch this driver through bounded_checked.py as specified in protocol.
"""
import argparse,json,random,subprocess,sys,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--order-seed',required=True,type=int);a=p.parse_args()
cases=json.load(open(a.inputs))['cases'];assert len(cases)==40
for c in cases:assert set(c)=={'id','ciphertext','observed'}
root=Path(a.output_dir);root.mkdir(exist_ok=False)
rng=random.Random(a.order_seed);plan=[]
for repeat in range(3):
    indices=list(range(len(cases)));rng.shuffle(indices)
    for i in indices:
        methods=['crt','parity'];rng.shuffle(methods)
        plan.extend((repeat,i,m) for m in methods)
(root/'plan.json').write_text(json.dumps(plan));total=0.;receipts=[]
for repeat,i,method in plan:
    if total+122>4000:
        (root/'incomplete.json').write_text(json.dumps(dict(reason='aggregate budget reservation',inclusive_stage_cpu=total)));raise SystemExit(2)
    stem=root/f'{repeat}-{i:02d}-{method}';receipt=str(stem)+'-receipt.json';output=str(stem)+'.json'
    code=subprocess.run([sys.executable,'bounded_checked.py',receipt,'60','512','90',sys.executable,'run_one.py',a.inputs,str(i),method,output],env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid())}).returncode
    if Path(receipt).exists():
        r=json.load(open(receipt));total+=r['child_cpu_seconds']+r['parent_cpu_seconds'];receipts.append(receipt)
    else:
        (root/'incomplete.json').write_text(json.dumps(dict(reason='missing stage receipt',stage=str(stem))));raise SystemExit(3)
    (root/'progress.json').write_text(json.dumps(dict(completed=len(receipts),inclusive_stage_cpu=total,receipts=receipts),indent=2))
    if code:
        (root/'incomplete.json').write_text(json.dumps(dict(reason='nonzero stage exit',stage=str(stem),code=code)));raise SystemExit(4)
(root/'complete.json').write_text(json.dumps(dict(stages=len(receipts),inclusive_stage_cpu=total)))
