# Parity-first sparse-function decoder v2 — development evidence

31 October 2026. **Synthetic development only. No held-out v2 evaluation or target execution has occurred.** This is a model-specific algorithmic combination, not an established globally novel cryptanalytic theory or a solution claim.

## Fixed model and exact output

The 31 functions are constant1; six ciphertext lags; six squares;15 pair products;3 full-Z26 equality indicators. Indicators are evaluated before reduction. A law has at most3 nonzero coefficients modulo26. Inputs are97 synthetic ciphertext ranks and24 observed mask values C−P at zero-based positions21–33 and63–73. Only positions6–96 are modeled:91 rows,67 unobserved. No recovery of the first6 is claimed.

Both timed methods return **the same contract**: complete feasibility/emptiness, exact marginal26-bit masks for all91 rows, and a ≤3-term coefficient witness for every allowed value at every row. Every witness must satisfy all24 observations and its claimed row value. Different marginal values may require different laws; masks are not a Cartesian-product representation of whole plaintexts.

- **CRT baseline:** all4495 maximal3-feature containers, allowing zero coefficients, independent field solves on the same support, exact affine projections and CRT witnesses.
- **Parity-first:** all2626 beta vectors of weight≤3 in the25-group global parity quotient; keep every matching syndrome; use only3-feature containers covering beta's active groups. Mod13 solutions are cached per support. Every lift uses actual nonzero alpha entries and achieves the proved minimum support.
- **Grouped parity-first (`decoder_optimized.py`):** the selected development version additionally deduplicates equal **full91-row** parity predictions for the same support. A representative beta is retained for each projected witness. This is exact for the primary contract, but does not retain every beta fiber or enumerate all global functions.

All preprocessing is inside each timing, both methods use the same Python implementation level and field kernel, and both emit identical kinds of output. The independent correctness oracle does **not** share that kernel. No dense-singleton shortcut, heuristic pruning, early full-mask shortcut or v1 join comparison is used in the selected method. A fixed zero-parity-syndrome CRT fallback was separately tested as a development ablation and is not selected.

## Evidence and honest limits

An independently authored generator produced17 disclosed cases with seed202610311829:13 in-family cases;2 proven duplicate-context contradictions;2 observational twins with altered unobserved truth. Cases include beta weights0–3, nonunits, cancelling lag/square coefficients, zero/repeated contexts, indicator toggles and equal-crib/different-outside parity functions.

An independent4992-support oracle agreed with both implementations on **17/17** complete masks and feasibility. Every marginal-value witness passed direct replay. Exhaustive enumeration of17,576 tiny coefficient vectors yielded8,788 distinct global functions, verified exact minimal lift support and all4 budgets0–3 against maximal containers. Separately constructed evaluation bases have ranks31 overF13 and25 for the parity quotient; explicit basis contexts distinguish the genuinely different functions described in the independent audit.

All13 generated in-family truths are retained: **858/871** unobserved positions forced, **0 false forced**,10/13 cases force all67. Both contradictions are empty. Each disclosed observational twin has1 falsely forced hidden value: this deliberately demonstrates that consistency/uniqueness conditional on this model does not establish model membership.

### Uniqueness is not one property

| Property | What is established |
| --- | --- |
| Coefficient-vector uniqueness | Not returned by the primary solver. Distinct vectors may be globally identical, e.g.13x and13x². |
| Global-function uniqueness | Not inferred from grouped projection. Full descriptor fibers are not retained. Independent basis witnesses certify specific different functions, not uniqueness of every case. |
| Finite91-row prediction uniqueness | Exactly established when feasible and every marginal is singleton. This need not imply a unique global function. |
| Intended plaintext correctness | Only supported for generated in-family truth; misspecified twins show the limitation. |

## Development performance, not a speed claim

`isolated/` contains fresh-process, alternating-order measurements, one repeat per method/case. These are **development cases**, with concurrent audit activity and observable run variability. They establish feasibility and bottlenecks, not a held-out speedup.

| Method | Summed solver CPU,17 cases | Peak individual process RSS |
| --- | ---: | ---: |
| Maximal-support CRT |14.874s|8,320KiB|
| Grouped parity-first |11.299s|21,760KiB|

Grouped parity-first was slower on4/17 isolated development cases: beta1 nonunit, zero law, equal-crib/different-outside parity, and the mod13-only contradiction. Median paired ratio was0.586, but neither that ratio nor aggregate totals are a claim of general acceleration. Memory cost is higher. All losses remain in `summary.json`.

The initial ungrouped version took7.023s vs CRT2.481s on all-zero contexts; constant/alternating and parity-alias cases were also slower. Those original code/results remain unchanged. The proved full-row grouping was then implemented and independently audited as a separate development revision, not retrospectively presented as frozen blind performance.

Important structural counters on all-zero contexts are M=1694 matching beta, U=4495 unique mod13 support solves, E=29032 admitted incidences and F=29032 feasible pieces. Grouping saves repeated projection work, not these compatible functions. The same-crib/different-outside case remains a loss; grouping only crib syndromes would be wrong.

## Failures, corrections and resource accounting

The initial benchmark used a child-capped wrapper but omitted its lightweight supervisor's own caps/RSS. This is an instrumentation defect; the original receipt is retained and **not** called fully bounded retrospectively. The independent auditor's first `/usr/bin/time` launch failed because that binary was unavailable, before scientific computation; its failure is retained separately.

`bounded_checked.py` is the single final launch path. Supervisor and stage both have CPU/address-space limits; every supervisor records its own and child's CPU/RSS. Wall termination is complemented by Linux parent-death signaling on every supervised link, preventing nested new-session descendants from surviving loss of an ancestor. This launcher is Linux-specific and restricted to the declared supervised topology, not arbitrary adversarial subprocess trees.

Fresh controls passed inherited-limit inspection, exit7 preservation,128MiB memory failure,1-second CPU failure,1-second wall failure, manual ancestor-death cascade and a **nested outer-wall-timeout cascade** across a driver, inner new-session supervisor and leaf. The final independent audit used this same launcher: stage24.632CPU seconds, supervisor0.026s; stage24,308KiB RSS and supervisor8,320KiB; exit0 under300CPU/512MiB per process/600wall. No heavy stage reached a cap.

Recorded development and audit work is comfortably below8 aggregate CPU-hours/8GiB; a conservative450CPU-second envelope covers completed scientific runs and control probes. Static source reads/copies are not cipher execution. No target data, archived target tests, hidden v1 inputs, paid services or remote writes were used.

## Next gate

`PROPOSED-HOLDOUT-PROTOCOL.md` is a proposal requiring approval. The independently authored generator source is unexecuted. No seed is drawn or committed and no holdout exists. Freeze the reviewed source/protocol/generator/launcher hashes before an independent custodian generates fresh data. Preserve all strata and losses; do not tune after reveal. Successful synthetic validation would still not authorize a target run.

## Fixed hybrid ablation

A separately proposed, input-structural rule dispatches zero observed parity syndrome to CRT and other inputs to grouped parity-first. It is output-equivalent and passed17/17 independent expected-mask comparisons. It dispatches9 cases to CRT:3 had been parity losses, but6 had favored parity, including all-zero contexts. The mixture of existing isolated timings would total13.071s rather than pure parity11.299s; a separately executed single-process hybrid run took13.858s. These are development diagnostics, not paired speed proof. No threshold was tuned; recommendation is to retain pure grouped parity-first and preserve the rejected ablation.

Independent pre-freeze review additionally found and corrected parent-death startup races, pre-session wall-kill races, and soft-versus-hard CPU accounting. Expected parent PIDs are captured/passed explicitly, and killpg failure falls back to the unreaped child PID. Fresh controls exercise mismatched-parent rejection and a deliberately delayed pre-setsid child. These corrections change resource supervision, not scientific outputs; all old receipts and wrapper revisions are preserved.
