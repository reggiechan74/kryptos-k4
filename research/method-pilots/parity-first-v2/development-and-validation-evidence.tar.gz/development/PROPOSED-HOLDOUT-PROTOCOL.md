# Proposed fresh v2 validation gate — not yet authorized

## Decision requested

Approve or revise this frozen-method comparison **before any generator execution or seed draw**. The current evidence is development-only. The selected algorithm is grouped parity-first in `decoder_optimized.py`, compared to its same-module maximal-support CRT baseline. Both use the exact primary output contract in REPORT.md. No hybrid/dense shortcut is proposed.

## Data and separation

An independent custodian chooses a new unpredictable seed only after approval, records its sealed commitment, and runs the source-pinned independent generator. Do not inspect/reuse v1 hidden seed, fixtures, labels or observations; do not reuse development random draws. Proposed40-case fixed composition:24 ordinary cases (6 each beta weight0–3),6 degeneracy controls,2 equal-crib/different-outside parity controls,4 provable contradictions,4 observational twins. These are not40 independent draws: twins depend on selected ordinary cases; deterministic zero control is explicitly a structural replay, not unseen evidence. Publish counts by stratum and provenance.

The custodian retains source laws/truth/category labels separately, strips solver inputs to id/ciphertext/observed, and hashes both sealed truth and solver-input artifacts before execution. Fixture admission cannot depend on solver agreement, singleton counts or timing. A changed hidden value in a twin is not automatically proved outside the sparse class; classify membership unknown unless an exact certificate establishes otherwise.

## Execution and fair comparison

Freeze decoder, benchmark harness, generator, independent oracle/auditor, wrapper and this protocol hashes. Record Python/platform. Run both solvers on every case, three repetitions each, with seeded randomized paired order independent of outcomes. Use fresh processes. Account preprocessing and witness production equally. Primary timing is solver CPU; report inclusive child CPU, wall and peakRSS too, with medians over repetitions and per-stratum paired distributions. A correctness failure or incomplete cap result remains visible; no silent retry/omission or tuned rerun.

Primary complete outputs:91 exact marginal masks, nonempty/empty decision and a valid sparse witness for every permitted row/value; report67 unobserved positions separately. No full relation or law-uniqueness extra work is permitted in one timed method but not the other. No primary global-function count is claimed by grouped output.

Run the independent source-disjoint4992-support oracle once per case and validate each final output mask and every witness. Tiny exhaustive/global-basis controls must pass on the frozen source before generation. Retain all seed/input/source checks and failures. Any source correction after labels become available creates a new development revision and requires separately approved fresh validation; it cannot salvage the same blind test.

## Resource topology and stop rules

Use only `bounded_checked.py`. Each benchmark driver is capped300CPU/512MiB/1800wall. Each sequential method process is capped60CPU/512MiB/90wall; at most one scientific solver per driver, no concurrency. The soft CPU limit60 has hard limit61 for each inner supervisor and solver. A mandatory4,000CPU-second cumulative budget covers the sum of inclusive inner-supervisor+solver receipts; reserve122 seconds before each launch and stop incomplete if that reservation would cross4,000. Do not confuse240 solver launches with240 independent process ceilings: supervisors also have caps. Separately reserve602CPU seconds for driver+outer supervisor,1,202 for independent auditor+supervisor,500 for nested-wrapper controls, and450 for development. The conservative total6,754CPU-second envelope is below8 aggregate CPU-hours. Driver1800wall can truncate pathological cases before all240 stages; retain incompleteness. No partial absence implies rejection or uniqueness.

Every nested driver/supervisor must use the reviewed expected-parent PID guard, passed explicitly by its launcher and checked before/after parent-death registration; the forked child uses the supervisor PID captured before fork. The root supervisor is held by the managed executor. The wall watchdog falls back to killing the unreaped child PID if its process group does not yet exist. verify the frozen nested-timeout control before generation. Do not spawn unwrapped descendants. Maximum intended simultaneously live capped processes is four512MiB nodes (outer supervisor, driver, inner supervisor, solver), below8GiB even at their address-space ceilings. Independent audit runs separately, not concurrently. Wrapper CPU accounting contains nested usage: do not double-count inclusive parent receipts when summing leaf-stage receipts. Report each process peak and conservative simultaneous upper bound, not a misleading sum of nonconcurrent peaks.

## Acceptance and conclusions

Required: exact complete agreement on every finished case; no false forced values for independently generated in-family truths; direct sparse witness replay; both constructed contradiction types empty; no truth-based filtering. Twins are a limitation control: report compatibility and hidden mismatches without demanding they all be identified or rejected. Cap hits, errors or disagreements block correctness acceptance pending diagnosis, not a convenience exclusion.

Only after independent audit and seed release may paired performance be described for this fixed workload. Report wins and losses, tails/degeneracy, memory overhead and sensitivity across repetitions. A positive result supports this model-specific method, not global novelty, general cryptanalytic superiority or real-target applicability. A negative speed result is publishable and does not invalidate exactness. No target execution, expanded model, external submission or separate repository is authorized by passing this gate.
