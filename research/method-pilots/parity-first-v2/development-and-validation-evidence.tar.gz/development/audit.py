"""Source-independent ordinary CRT oracle and direct witness checker.
Truth construction imports only independently authored development generator.
Production decoder is imported only after independent expected masks computed.
"""
import itertools,json,time,sys,importlib.util
from pathlib import Path
from generate import features,generate,OBS

def eliminate(rows,targets,p):
    n=len(rows[0]);a=[[v%p for v in row]+[y%p] for row,y in zip(rows,targets)]; piv=[];r=0
    for col in range(n):
        k=next((k for k in range(r,len(a)) if a[k][col]),None)
        if k is None:continue
        a[r],a[k]=a[k],a[r];inv=pow(a[r][col],-1,p);a[r]=[(x*inv)%p for x in a[r]]
        for k in range(len(a)):
            if k!=r and a[k][col]:
                v=a[k][col];a[k]=[(x-v*y)%p for x,y in zip(a[k],a[r])]
        piv.append(col);r+=1
    if any(not any(row[:-1]) and row[-1] for row in a):return None
    x=[0]*n
    for k,col in enumerate(piv):x[col]=a[k][-1]
    basis=[]
    for col in range(n):
        if col not in piv:
            v=[0]*n;v[col]=1
            for k,pc in enumerate(piv):v[pc]=-a[k][col]%p
            basis.append(v)
    return x,basis

def image(sol,row,p):
    x,basis=sol
    if any(sum(a*b for a,b in zip(row,v))%p for v in basis):return range(p)
    return (sum(a*b for a,b in zip(row,x))%p,)

def oracle(case):
    matrix=[features(case['ciphertext'],i) for i in range(6,97)]
    ob=[(int(i)-6,v) for i,v in case['observed'].items()];targets=[v for i,v in ob]
    masks=[0]*91;feasible=False
    for size in range(4):
      for support in itertools.combinations(range(31),size):
        rows=[[matrix[i][j] for j in support] for i,v in ob]
        s13=eliminate(rows,targets,13)
        if s13 is None:continue
        s2=eliminate(rows,targets,2)
        if s2 is None:continue
        feasible=True
        for i,row in enumerate(matrix):
            reduced=[row[j] for j in support]
            for a in image(s13,reduced,13):
                for b in image(s2,reduced,2):masks[i]|=1<<(a+13*((b-a)%2))
    return masks,feasible

def check_witnesses(case,result):
    matrix=[features(case['ciphertext'],i) for i in range(6,97)]
    checked=0
    assert len(result['masks'])==len(result['witnesses'])==91
    for offset,(mask,ws) in enumerate(zip(result['masks'],result['witnesses'])):
        assert set(map(int,ws))=={z for z in range(26) if mask>>z&1}
        for value,terms in ws.items():
            assert len(terms)<=3 and len({j for j,c in terms})==len(terms)
            assert all(0<=j<31 and 1<=c<26 for j,c in terms)
            for i,target in case['observed'].items():assert sum(matrix[int(i)-6][j]*c for j,c in terms)%26==target
            assert sum(matrix[offset][j]*c for j,c in terms)%26==int(value)
            checked+=1
    return checked

def tiny():
    # Exhaustive 26^3 coefficients for dictionary (x,x²,[x=y]); global descriptor fibers.
    descriptors={};minimum={};signature_to_descriptor={}
    # A small evaluation basis discovered by rank, independent of production.
    contexts=[(0,0),(0,13),(1,0),(1,1),(2,0),(3,0),(13,0),(14,0)]
    for coeff in itertools.product(range(26),repeat=3):
        a,b,e=coeff;d=(a%13,b%13,e%13,(a+b)%2,e%2)
        values=tuple((a*x+b*x*x+e*(x==y))%26 for x,y in contexts)
        assert descriptors.setdefault(d,values)==values
        assert signature_to_descriptor.setdefault(values,d)==d
        cost=sum(v!=0 for v in coeff);minimum[d]=min(minimum.get(d,4),cost)
    for d,cost in minimum.items():
        a,b,e,par,ep=d
        formula=(a!=0)+(b!=0)+(e!=0)+(par==1 and not(a or b))+(ep==1 and not e)
        assert formula==cost
    # Direct set equality for every budget using separately enumerated alpha/beta descriptors.
    comparisons=0
    for budget in range(4):
        direct={d for d,c in minimum.items() if c<=budget};candidate=set()
        for a,b,e in itertools.product(range(13),repeat=3):
          for par,ep in itertools.product(range(2),repeat=2):
            T={j for j,v in enumerate((a,b,e)) if v};B=({0} if par else set())|({1} if ep else set())
            for S in itertools.combinations(range(3),budget):
                if T<=set(S) and B<={0 if j<2 else 1 for j in S}:
                    candidate.add((a,b,e,par,ep));break
        assert direct==candidate;comparisons+=1
    return dict(coefficient_vectors=26**3,global_functions=len(descriptors),minimum_lift_support_pass=True,maximal_container_budget_checks=comparisons,evaluation_basis=contexts)

if __name__=='__main__':
    root=Path(__file__).parent;report={'classification':'fresh disclosed synthetic development','tiny':tiny(),'cases':[]};cases=generate()
    expected=[]
    for case in cases:
        t=time.process_time();m,f=oracle(case);expected.append((m,f));print('oracle',case['id'],round(time.process_time()-t,3),flush=True)
    (root/'independent_expected.json').write_text(json.dumps({c['id']:{'masks':m,'feasible':f} for c,(m,f) in zip(cases,expected)},indent=2)+'\n')
    spec=importlib.util.spec_from_file_location('production',sys.argv[1]);production=importlib.util.module_from_spec(spec);spec.loader.exec_module(production)
    for case,(m,f) in zip(cases,expected):
        row={'id':case['id'],'feasible':f,'forced':sum(v.bit_count()==1 for v in m),'methods':{}}
        for method in ('parity','crt'):
            t=time.process_time();got=production.solve(case,method);elapsed=time.process_time()-t
            assert got['masks']==m,(case['id'],method,'mask mismatch')
            assert got['feasible']==f
            checked=check_witnesses(case,got)
            if case['in_family']:assert all(mask>>truth&1 for mask,truth in zip(m,case['truth_mask']))
            row['methods'][method]={'cpu_seconds':elapsed,'witness_values_checked':checked,'stats':got['stats']}
            print('checked',case['id'],method,round(elapsed,3),flush=True)
        report['cases'].append(row)
        (root/'audit_results.json').write_text(json.dumps(report,indent=2)+'\n')
    report['all_pass']=True;(root/'audit_results.json').write_text(json.dumps(report,indent=2)+'\n')
