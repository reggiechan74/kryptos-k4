"""Proposed independent post-execution checker; run under the bounded launcher.
Requires independent audit.py and generate.py beside this file; neither main runs
on import. Sealed truth may be disclosed to this auditor only at the agreed gate.
"""
import json,sys
from pathlib import Path
from audit import oracle,check_witnesses,tiny
cases=json.load(open(sys.argv[1]))['cases'];root=Path(sys.argv[2]);report={'tiny':tiny(),'cases':[]}
assert len(cases)==40
for i,c in enumerate(cases):
    masks,feasible=oracle(c);row=dict(id=c['id'],feasible=feasible,witness_checks=0)
    for repeat in range(3):
        for method in ('crt','parity'):
            out=json.load(open(root/f'{repeat}-{i:02d}-{method}.json'))['result']
            assert out['status']=='complete' and out['masks']==masks and out['feasible']==feasible
            row['witness_checks']+=check_witnesses(c,out)
    if c['in_family'] is True:assert all(m>>t&1 for m,t in zip(masks,c['truth_mask']))
    row['forced_unknown']=sum(masks[j-6].bit_count()==1 for j in range(6,97) if str(j) not in c['observed'])
    row['false_forced']=None if c['truth_mask'] is None else sum(m.bit_count()==1 and not(m>>t&1) for m,t in zip(masks,c['truth_mask']))
    report['cases'].append(row)
    Path(sys.argv[3]).write_text(json.dumps(report,indent=2))
report['passed']=True;Path(sys.argv[3]).write_text(json.dumps(report,indent=2))
