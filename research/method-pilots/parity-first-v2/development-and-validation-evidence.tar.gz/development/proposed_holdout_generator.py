"""UNEXECUTED PROPOSED generator: requires reviewed freeze and external seed.
No default seed. No development data/source imports. Exactly40 fixed-stratum cases.
Do not execute before approval. Function definitions alone draw no randomness.
"""
import argparse,json,random
from pathlib import Path
OBS=tuple(range(21,34))+tuple(range(63,74))
GROUP=[0]+list(range(1,7))+list(range(1,7))+list(range(7,25))
def values(c,i):
    x=c[i-6:i][::-1]
    return [1]+x+[a*a%26 for a in x]+[x[a]*x[b]%26 for a in range(6) for b in range(a+1,6)]+[int(x[a]==x[a+1]) for a in (0,2,4)]
def case(name,c,terms,category):
    truth=[sum(values(c,i)[j]*a for j,a in terms)%26 for i in range(6,97)]
    return {'id':name,'ciphertext':c,'observed':{str(i):truth[i-6] for i in OBS},'truth_mask':truth,'source_terms':terms,'category':category,'in_family':True,'provenance_kind':'fresh_random_parameter_draw','fresh_random_draw':True,'control_not_blind':False}
def generate(seed):
    rng=random.Random(seed);out=[]
    #24 ordinary draws:6 per beta weight. Exactly3 nonzero coefficient terms.
    for weight in range(4):
      for repeat in range(6):
        active=[];groups=set()
        while len(active)<weight:
            j=rng.randrange(31)
            if GROUP[j] not in groups:active.append(j);groups.add(GROUP[j])
        terms=[(j,rng.choice(list(range(1,26,2)))) for j in active]
        # In every weight stratum's second draw include13 where an active bit exists.
        if weight and repeat==1:terms[0]=(terms[0][0],13)
        filler=rng.sample([j for j in range(31) if j not in active],3-weight)
        terms += [(j,2*rng.randrange(1,13)) for j in filler]
        c=[rng.randrange(26) for _ in range(97)]
        out.append(case(f'ordinary-w{weight}-{repeat}',c,terms,f'ordinary-beta{weight}'))
    #6 degeneracy controls: parameters freshly drawn; no success-based filtering.
    # Fixed zero-law/all-zero trajectory repeats a development structural control.
    # It tests regression correctness, not unseen random-data performance.
    for r in range(2):out.append(case(f'zero-{r}',[0]*97,[(0,2*rng.randrange(1,13))] if r else [],'zero-context'))
    out[-2].update(provenance_kind='deterministic_structural_replay',fresh_random_draw=False,control_not_blind=True)
    for r in range(2):out.append(case(f'constant-{r}',[rng.randrange(26)]*97,[(rng.randrange(31),rng.randrange(1,26))],'constant-context'))
    for r in range(2):
        a=rng.randrange(13);c=([a,a+13]*49)[:97]
        out.append(case(f'alternating-{r}',c,[(28,13),(29,2*rng.randrange(1,13)),(6,rng.randrange(1,26))],'indicator-degeneracy'))
    #2 same-crib/different-outside parity controls with fresh unobserved impulse.
    for r in range(2):
        c=[0]*97;c[rng.choice(list(range(36,54)))]=rng.choice(list(range(1,26,2)))
        out.append(case(f'crib-parity-alias-{r}',c,[(1+r,13)],'crib-parity-alias'))
    #4 provably inconsistent duplicate-context observations,2 parity/2 mod13.
    for r in range(4):
        c=[rng.randrange(26)]*97;t=case(f'contradiction-{r}',c,[],'contradiction')
        t['observed']['22']=rng.choice(list(range(1,26,2))) if r<2 else 2*rng.randrange(1,13)
        t['truth_mask']=None;t['in_family']=False;t['certificate']='equal contexts21/22, unequal observed masks';out.append(t)
    #4 observational twins: same inputs as selected ordinary cases but changed hidden truth.
    #They test model-membership limits, not a claim that every altered truth is outside class.
    for r,index in enumerate((0,7,14,21)):
        t=json.loads(json.dumps(out[index]));t['id']=f'twin-{r}';t['category']='observational-twin';t['in_family']=None;t.update(provenance_kind='dependent_observational_twin',fresh_random_draw=False,control_not_blind=False)
        pos=rng.choice([i for i in range(6,97) if i not in OBS]);t['truth_mask'][pos-6]=(t['truth_mask'][pos-6]+rng.randrange(1,26))%26
        t['altered_position']=pos;t['twin_of']=out[index]['id'];out.append(t)
    assert len(out)==40
    return {'kind':'fresh holdout only after approval','seed':seed,'cases':out}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seed',required=True,type=int);parser.add_argument('--output',required=True);parser.add_argument('--approved-freeze',required=True)
    args=parser.parse_args()
    #A required approval identifier is audit metadata, not self-granted permission.
    data=generate(args.seed);data['approved_freeze']=args.approved_freeze
    Path(args.output).write_text(json.dumps(data,indent=2)+'\n')
