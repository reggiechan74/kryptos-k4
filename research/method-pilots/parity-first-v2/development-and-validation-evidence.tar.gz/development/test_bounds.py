"""Fresh static/synthetic control fixtures for the sole publication launcher."""
import json,os,signal,subprocess,sys,time
from pathlib import Path
root=Path('bounds-validation');root.mkdir(exist_ok=True)
for stale in root.glob('*.pid'):stale.unlink()
def run(name,cpu,mem,wall,code):
    p=subprocess.run([sys.executable,'bounded_checked.py',str(root/(name+'.json')),str(cpu),str(mem),str(wall),sys.executable,'-c',code],capture_output=True,text=True,env={**os.environ,"BOUND_EXPECTED_PARENT":str(os.getpid())})
    (root/(name+'.log')).write_text(p.stdout+p.stderr)
    return json.loads((root/(name+'.json')).read_text())
a=run('limits',2,128,5,'import resource;assert resource.getrlimit(resource.RLIMIT_CPU)==(2,3);assert resource.getrlimit(resource.RLIMIT_AS)==(134217728,134217728)');assert a['exit_code']==0
a=run('exit',2,128,5,'raise SystemExit(7)');assert a['exit_code']==7
a=run('memory',2,128,5,'a=bytearray(256*1024**2)');assert a['exit_code']==1
a=run('cpu',1,128,5,'while True: pass');assert a['exit_code']==-signal.SIGXCPU
a=run('wall',2,128,1,'import time;time.sleep(20)');assert a['wall_timeout'] and a['exit_code']==-9
leaf="import os,time;open('bounds-validation/leaf.pid','w').write(str(os.getpid()));time.sleep(30)"
inner=[sys.executable,'bounded_checked.py','bounds-validation/inner.json','3','128','35',sys.executable,'-c',leaf]
code="import os,subprocess;open('bounds-validation/driver.pid','w').write(str(os.getpid()));p=subprocess.Popen("+repr(inner)+",env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid())});open('bounds-validation/inner.pid','w').write(str(p.pid));p.wait()"
p=subprocess.Popen([sys.executable,'bounded_checked.py','bounds-validation/outer.json','4','128','40',sys.executable,'-c',code],env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid())})
for _ in range(100):
    if (root/'leaf.pid').exists():break
    time.sleep(.02)
else:raise RuntimeError('nested process did not start')
pids=[int((root/(name+'.pid')).read_text()) for name in ('driver','inner','leaf')]
p.kill();p.wait()
def alive(pid):
    try:return Path(f'/proc/{pid}/stat').read_text().split()[2] not in ('Z','X')
    except FileNotFoundError:return False
for _ in range(100):
    if not any(map(alive,pids)):break
    time.sleep(.02)
assert not any(map(alive,pids)),pids
# A second fresh chain is ended by the OUTER wall watchdog, not manual kill.
for name in ('driver','inner','leaf'):(root/(name+'.pid')).unlink()
p=subprocess.Popen([sys.executable,'bounded_checked.py','bounds-validation/nested-timeout.json','4','128','1',sys.executable,'-c',code],env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid())})
for _ in range(100):
    if (root/'leaf.pid').exists():break
    time.sleep(.005)
else:raise RuntimeError('timeout chain did not start')
pids=[int((root/(name+'.pid')).read_text()) for name in ('driver','inner','leaf')]
p.wait(timeout=5)
for _ in range(100):
    if not any(map(alive,pids)):break
    time.sleep(.02)
assert not any(map(alive,pids)),pids
assert json.loads((root/'nested-timeout.json').read_text())['wall_timeout']
# Wrong expected parent must terminate the supervisor before it launches a stage.
p=subprocess.run([sys.executable,'bounded_checked.py','bounds-validation/forbidden.json','2','128','5',sys.executable,'-c','raise RuntimeError("must not execute")'],env={**os.environ,'BOUND_EXPECTED_PARENT':'999999999'})
assert p.returncode==-signal.SIGKILL and not (root/'forbidden.json').exists()
# Force child descheduling BEFORE setsid; watchdog must fall back to kill(pid).
startup="import os,time,runpy,sys;old=os.setsid;os.setsid=lambda:(time.sleep(3),old())[1];sys.argv=['bounded_checked.py','bounds-validation/pre-session-timeout.json','2','128','1',sys.executable,'-c','import time;time.sleep(20)'];runpy.run_path('bounded_checked.py',run_name='__main__')"
p=subprocess.run([sys.executable,'-c',startup],env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid())},timeout=5)
r=json.loads((root/'pre-session-timeout.json').read_text());assert r['wall_timeout'] and r['exit_code']==-signal.SIGKILL
(root/'summary.json').write_text(json.dumps(dict(passed=True,nested_parent_death_cascade=True,nested_wall_timeout=True,expected_parent_mismatch_rejected=True,pre_session_wall_timeout=True,normal_limit_checks=True,memory_failure=True,cpu_failure=True,wall_failure=True,exit_code_preserved=True),indent=2))
print('Bounded launcher controls passed')
