"""Fresh disclosed SYNTHETIC DEVELOPMENT fixtures; never a blind benchmark."""
import json, random
from pathlib import Path
SEED=202610311829
OBS=tuple(range(21,34))+tuple(range(63,74))
def features(c,i):
    x=[c[i-j] for j in range(1,7)]
    return [1]+x+[v*v%26 for v in x]+[x[j]*x[k]%26 for j in range(6) for k in range(j+1,6)]+[int(x[j]==x[j+1]) for j in (0,2,4)]
def evaluate(c,terms):
    return [sum(features(c,i)[j]*v for j,v in terms)%26 for i in range(6,97)]
def make(name,c,terms,category):
    t=evaluate(c,terms)
    return dict(id=name,ciphertext=c,observed={str(i):t[i-6] for i in OBS},truth_mask=t,source_terms=terms,category=category,in_family=True)
def generate():
    rng=random.Random(SEED); out=[]
    specifications=[('beta0-even',[(1,2),(8,6),(22,24)]),('beta1-nonunit',[(1,13)]),('beta2',[(3,5),(11,17),(29,4)]),('beta3',[(2,9),(18,7),(30,15)]),('paired-alias-zero',[(1,13),(7,13)]),('paired-cancellation',[(2,3),(8,5),(15,2)]),('indicator-only',[(28,7),(29,13),(30,2)]),('zero-law',[])]
    for n,terms in specifications:
        c=[rng.randrange(26) for _ in range(97)]
        out.append(make(n,c,terms,'random-in-family'))
    out.append(make('all-zero-context',[0]*97,[],'degenerate'))
    out.append(make('constant-seven',[7]*97,[(0,5)],'degenerate'))
    out.append(make('alternating-zero-thirteen',[0,13]*48+[0],[(28,1),(29,13),(6,2)],'indicator-toggle'))
    c=([0,0,13,0,2,2,15,2,1,3,3,16]*9)[:97]
    out.append(make('indicator-blocks',c,[(28,3),(29,6),(30,13)],'indicator-toggle'))
    # Crib histories all zero; a non-crib impulse distinguishes lag1 and lag2 parity functions.
    c=[0]*97;c[43]=1
    out.append(make('same-crib-outside-different',c,[(1,13)],'parity-syndrome-alias'))
    for delta in (1,2):
        case=make('inconsistent-'+str(delta),[0]*97,[],'constructed-inconsistent')
        case['observed']['22']=delta;case['truth_mask']=None;case['in_family']=False
        case['certificate']='Identical context at observations21 and22 has unequal mask.'
        out.append(case)
    for src in (0,9):
        case=json.loads(json.dumps(out[src]));case['id']='misspecified-twin-'+str(src)
        case['category']='observational-twin';case['in_family']=False
        case['truth_mask'][40-6]=(case['truth_mask'][40-6]+1)%26
        case['note']='Same ciphertext and all observations as source, unobserved truth mask40 altered. This is external misspecification, not sparse-law ground truth.'
        out.append(case)
    return out
if __name__=='__main__':
    cases=generate()
    Path(__file__).with_name('development_cases.json').write_text(json.dumps(dict(kind='disclosed synthetic development',seed=SEED,cases=cases),indent=2)+'\n')
    print(json.dumps({'cases':len(cases),'seed':SEED}))
