# Exact parity-first sparse-function decoding: v2 development

**Status:**17 disclosed synthetic development cases passed independent exact auditing. No v2 holdout generated; no target test authorized. [Report](REPORT.md) · [Independent audit](independent/REPORT.md) · [Proposed approval gate](PROPOSED-HOLDOUT-PROTOCOL.md).

The selected implementation `decoder_optimized.py` compares a25-group parity-first quotient method with a strong4495-support CRT baseline. Both return exact marginal masks, feasibility and sparse supporting witnesses. Full global-function enumeration is deliberately outside this matched contract. Original failures, unoptimized results and a rejected structural hybrid remain in `development-history/`.

## Reproduce development, not a holdout

Use Linux and Python3. Make a **fresh working copy** before executing scripts: audited outputs are evidence, not scratch files. No dependencies beyond Python standard library. From the copy's root:

```sh
python bounded_checked.py wrapper-check.json 30 256 60 python test_bounds.py
python bounded_checked.py independent-check.json 300 512 600 python audit.py decoder_optimized.py
```

These commands run static/synthetic controls only. The second regenerates the disclosed17 development cases in memory and independently recomputes masks; it does not import or execute the proposed holdout generator. Original evidence files are in `independent/` and `evidence/`.

`blind_runner.py`, `audit_inputs.py` and `proposed_holdout_generator.py` are frozen **proposed** validation sources, not permission to run them. The latter has no default seed and has never been imported or executed. Obtain approval and independent seed custody first. Source hashes are in `FREEZE-MANIFEST.json`; no holdout seed commitment exists yet.

## Reading the results

- `summary.json`: complete17-case isolated development comparison, including every loss.
- `evidence/isolated/`: per-method exact masks/witnesses and process receipts.
- `independent/basis_results.json`: independent evaluation witnesses distinguishing global functions.
- `evidence/bounds-validation/`: CPU/memory/wall/exit and nested process-tree controls.
- `development-history/`: unoptimized source/results and instrumentation corrections, not selected implementations.

A singleton prediction is conditional on this31-feature,≤3-term model. It does not prove the model is correct or that its law is unique. The first6 positions are not modeled. General speed and worldwide novelty are unestablished.
