# Pre-freeze source-only review

31 October 2026. No scientific run, seed draw, generator import or generation performed for this review.

## Generator revision

Original source preserved verbatim as `proposed_holdout_generator_v0.py`, SHA256 `6ab77e3d5f6692efa5bba58e5f2dd04ee56126f32eabad1b548a0c706d56ec24`.
Revised active source SHA256 `fc5f4756f5ac173bbf77279494fa35c41e7614c1b50cc604a45a4a032eb29251`.

Twins now have membership `null` (unknown), not false; they carry dependent-observational-twin provenance and are not independent fresh draws. The deterministic all-zero/zero-law control is explicitly structural replay, `fresh_random_draw=false`, `control_not_blind=true`. Other generated cases carry fresh-parameter provenance. This is40 cases, not40 independent unseen random draws. Source was edited statically and never executed.

## Wrapper and nested controls

Reviewed `bounded_checked.py` SHA256 `90a7b5f1bc4d6832f46a3bfaa8914e7c1cdf3755af4fc1480a57cb3c692b50e3`, `test_bounds.py`, final controls receipt and summary. The recorded controls pass normal resource inheritance, exit status, memory error, CPU signal, wall timeout, manual ancestor-death cascade and outer-wall nested termination. Manual-kill and wall tests separately check that driver, nested supervisor and leaf are not live (zombies excluded) after termination. Control execution was bounded and measured.

These tests validate the exercised settled-process topology, not arbitrary process trees. In particular the guard initially samples `getppid()`: if the original parent already died before that first sample, it can bind to the reparenting process instead. The post-prctl comparison only closes the race after sampling. Recommendation: pass the expected parent PID from the launching process and check it before/after registration, including child PID expectation captured before fork. The wrapper's single-process-only docstring also conflicts with the protocol's deliberate nested drivers; specify wrapped nesting and no unwrapped descendants.

## Protocol arithmetic corrections required

The proposed40×2×3=240 solver launches are correct. With softCPU60/hard61, hard leaf allowance is14,640CPU seconds, not14,400. Every inner supervisor also has its own61-second hard allowance. Therefore the sum of all process ceilings can exceed8CPU hours after adding driver/audit/control/development cost. Actual supervisors are tiny, but that is empirical behavior rather than a hard ceiling.

Make the preferred4,000CPU-second cumulative stop mandatory. Reserve enough budget for both supervisor and solver hard allowances before every launch, plus bounded driver/audit/control overhead. Count inclusive receipts once, not alongside their already included leaf receipts. Clearly state what the4,000 cap includes. Four512MiB simultaneous nodes yield a conservative2GiB address-space upper bound, safely under8GiB. The1800-second outer wall cap can truncate the full240-launch plan at worst-case durations; retain incompleteness rather than imply all ceiling-duration runs can finish.

### Hardened revision review

The subsequently reviewed launcher captures the supervisor PID before fork, passes that expected value to the child's guard, and reads an explicitly supplied `BOUND_EXPECTED_PARENT` for nested launcher starts. Pre/post-prctl expected-parent checks close the identified registration race for this controlled topology. Normal nonprivileged Python exec preserves the Linux parent-death setting; nested drivers explicitly overwrite the environment PID for each launch. Hardened controls record rejection of an incorrect expected parent as well as both cascade tests.

The proposed runner now reserves122CPU seconds per sequential pair of60soft/61hard supervisor+solver allowances and stops before its recorded sum could exceed4,000CPU seconds. Driver/audit/control overhead still needs explicit separate protocol reservation. No holdout runner was executed for this review.

One additional source-only edge case was identified: an outer wall alarm may fire before its freshly forked child establishes the new process group. If killpg returns ESRCH and the handler merely ignores it, the child can remain live and wait4 can exceed wall time. The advised correction is a direct child-PID SIGKILL fallback when the group is absent; an unreaped child's PID cannot be reused. Freeze remains contingent on that correction and revised protocol accounting text.

### Final source-only clearance

Final launcher SHA256 `568db679348678a8d7f8a9beb0e05703adcb4a8de9f3f48be3c5e91db8cd8230` closes the pre-session wall race with direct unreaped-PID fallback. The final bounded controls receipt exits0 and summary reports the deliberately delayed pre-session wall control, expected-parent mismatch, both nested cascades, CPU/memory/wall failures and normal status inheritance passed. The root supervisor remains explicitly under the managed executor; nested topology is constrained to guarded same-launcher descendants, with no arbitrary child processes.

Reviewed protocol SHA256 `0768f05214db80f08b7ba7b62d59dbdd20c9da42a7e237b69cc3629836eb2a41` and runner SHA256 `caa033e34888baa566fc7b81e4476761abdac46e80115d0fffab3567e8f443c4`. The mandatory4,000CPU-second inner inclusive budget uses122-second reservation for each supervisor+solver pair. Separate ceilings602 driver/outer,1,202 auditor/supervisor,62 controls and450 development sum to6,316CPU seconds, below8CPU hours. Receipts must be counted once rather than summing inclusive ancestors and their already included descendants. Four512MiB live nodes bound this topology at2GiB address space. Outer wall exhaustion remains explicit incompleteness.

**Cleared for the parent's freeze review on these pinned sources and documented topology.** This is not authorization to execute the proposed holdout and does not establish safety for arbitrary unwrapped descendants or privileged executables. Selected comparison remains pure grouped parity-first versus matched maximal-support CRT, with no hybrid or third comparator. No additional scientific run or generator execution occurred during this clearance.

### Final-current protocol reservation amendment

Final-current protocol SHA256 `7e934b9e4ba1dffe18d4a9eee638ae7dc3c9f0bef82e82b4a87cabed17bdd9cd` conservatively increases the controls reservation to500CPU seconds to include nested descendant probes. Arithmetic:4,000+602+1,202+500+450=6,754CPU seconds, still below28,800CPU seconds (8CPU hours). This increases reserved headroom rather than changing execution caps or permitting additional science. Launcher, runner and generator source remain unchanged. Clearance applies to this final-current protocol; preceding review and hash remain historical evidence. No generation or execution occurred for this amendment.
