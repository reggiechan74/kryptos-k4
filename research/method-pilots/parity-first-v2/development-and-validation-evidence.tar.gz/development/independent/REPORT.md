# Independent parity-first v2 development audit

31 October 2026. **PASS for the tested disclosed synthetic development set.** No target data, historical holdout inputs, hidden labels or prior blind seed were read. This audit does not authorize target use or establish a speed improvement on unseen data.

## Scope and independence

The independently authored generator uses disclosed seed202610311829 and produces17 length97 rank-valued ciphertext traces. Mask observations are at21–33 and63–73 (zero based); modeled rows6–96. Full-Z26 equality is evaluated before reduction. Categories include even coefficients/beta0, beta weights1–3, nonunits, a cancelling lag/square alias, zero law, zero/repeated contexts, alternating0/13 indicator controls, same-crib/different-outside parity functions, two exactly inconsistent identical-context observations and two observationally indistinguishable misspecified twins.

The independent oracle enumerates all4992 coefficient support containers of sizes0–3, with separately written Gaussian elimination over F13 and F2 and exact scalar CRT projection. It computed all expected91-row masks before importing either production implementation. It imports no production code for truth, feature evaluation, elimination, masks or witness checking. The generator constructs masks directly from sparse terms, not by reverse engineering production output.

All17 cases agree exactly for feasibility and masks with both the original and optimized implementations, for both parity-first and common-support CRT methods. Every reported marginal value has a witness with at most3 distinct nonzero coefficients, which independently reproduces all24 observations and that row's value. Across the original two-method audit,3380 marginal-value witnesses were checked. In-family truth is contained in every mask. Constructed contradictions are empty. Misspecified twins deliberately do not carry an in-family truth guarantee.

## Algebra and distinct-function evidence

The tiny dictionary `(x,x²,[x=y])` exhausts26³=17,576 coefficient vectors. Its8,788 canonical global descriptors have the asserted exact minimum support, and sparse descriptor sets match maximal covering-container constructions for every budget0–3. An8-context evaluation set separates all those descriptors.

Separately, `basis_results.json` gives independently generated evaluation contexts of rank31 modulo13 and rank25 for the parity quotient. Explicit separating basis evaluations establish:

- constant5 and23×lag1 agree on all91 modeled rows of constant7 ciphertext, yet are different global functions;
-13×lag1 and13×lag2 agree on all-zero crib contexts, yet are different global functions;
- the coefficient vector13×lag1+13×square1 is globally zero, so coefficient multiplicity is not function multiplicity.

These are synthetic algebra examples, not assertions of global-function uniqueness for solver outputs.

## Safe optimization review

The optimized source differs only by skipping repeat projection for identical `(original support S, full91-row parity prediction)` pairs. For a fixed S its mod13 affine solution is identical, so these pairs have identical full91 mask projections. Keeping one beta representative supplies valid sparse witnesses. This preserves the current matched contract: exact masks, feasibility and supporting witnesses. It does **not** preserve all beta fibers for an explicit global-function relation and does not support a global uniqueness claim. Crib-only grouping would be unsafe. Full relation serialization and global uniqueness are not implemented or timed.

## Development timing, not a blind comparison

Original production methods within audit: parity28.901CPU s; CRT13.298CPU s. Optimized separate audit: parity15.126CPU s; CRT15.976CPU s; parity faster on13/17 individual measurements. It still loses on constant-seven, same-crib-outside-different, inconsistent-2 and misspecified-twin-0 in this run. These are small, disclosed, sequential development measurements; execution noise and concurrent work were not controlled, and optimizations were selected after development observation. They cannot establish held-out speed improvement. No full-law enumeration burden is assigned to either timed method.

Whole original audit:57.349CPU s, peak14,632KiB executed-stage RSS and7,680KiB supervisor RSS. Optimized audit:31.247CPU s, peak24,556KiB stage RSS and7,680KiB supervisor RSS. Both exited0 under600CPU-second/1GiB virtual-address/900wall-second per-stage bounds. The independent oracle and tiny algebra are included in original audit cost; optimized audit reuses the unchanged expected-mask artifact. Generator/basis/wrapper-validation/summary receipts are separate. Total local compute is under100CPU seconds, far below the requested600-second initial allocation.

`check_limits.py` verified inherited CPU/address caps and a16MiB touched allocation independently reported24,064KiB RSS, matching wait4. See `FAILURES.md` for initial unavailable timing executable and harmless status-only missing-file lookup; neither invalidated a computation. No broad archived test suite was run.

## Source pins and next gate

- Original decoder: `8c93d9ca85e6af660f8e4cbceb0d6c4e0ac5b22ca4d9ffff04d2286c2e626af1`.
- Optimized decoder: `9c5c6232cd31167f751f404f636832414fd52cc0c90a624cb9640dfb899bd17e`.
- All local artifacts are pinned in `SHA256SUMS`.

A separate reviewed freeze and fresh independently drawn holdout are still required. Freeze implementation, generator specification, output contract, ordering, resource caps and any hybrid rule before holdout generation. Include degeneracy and misspecification without selecting instances by solver outcome. This is a model-specific algorithmic combination; worldwide novelty is not established. No target run follows automatically.

## Final consolidated bounded repeat

A final optimized audit repeated the same disclosed cases and unchanged independent expected masks under the corrected supervisor `bounded_checked.py` (SHA256 `90a7b5f1bc4d6832f46a3bfaa8914e7c1cdf3755af4fc1480a57cb3c692b50e3`). All17 cases again passed for both methods and all returned witnesses. Receipt: `final_optimized_audit.resources.json`; results: `final_optimized_audit_results.json`. Cost24.632CPU seconds for stage plus0.0255 supervisorCPU; stage peak24,308KiB, supervisor8,320KiB. Bounds300CPU seconds and512MiB per process,600wall seconds, no timeout, exit0. The reviewed wrapper sets caps before forking and a Linux parent-death signal on both supervisor and stage; this audit launches no nested processes. Earlier results and resource receipts are retained. Total audit-development compute including this repeat is under130CPU seconds. This is a development recheck, not a fresh blind validation.

## Unexecuted proposed holdout source

`proposed_holdout_generator.py` is prepared but **has not been imported or executed**. It requires an external integer seed, output path and approved-freeze metadata. No default seed or development fixture import exists. Predetermined40 strata:24 ordinary cases (6 each beta weights0–3),6 degenerate cases,2 same-crib/different-outside parity controls,4 provable contradictions and4 observational twins. Parameters/ciphertexts are freshly drawn except deterministic structural controls; no draw is selected by solver results. Twins test limits of inferred model membership and are not automatically certified outside the class. Source SHA256 `6ab77e3d5f6692efa5bba58e5f2dd04ee56126f32eabad1b548a0c706d56ec24`. Review and approval remain necessary before any holdout generation.

The generator was subsequently revised **without execution**: unknown twin membership and deterministic-control provenance are explicit. Original source retained as v0. See `FREEZE-REVIEW.md` for new hash and source-only review of wrapper startup-race and cumulative-budget arithmetic; these are pre-freeze issues, not failed scientific results.
