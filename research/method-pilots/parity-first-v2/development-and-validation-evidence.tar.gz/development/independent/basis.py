"""Independent global-function separating evaluation evidence, synthetic only."""
import json,random,itertools
from pathlib import Path
from generate import features

def vector(x):return features(list(reversed(x))+[0],6)
def rank_basis(contexts,cols,p):
    piv={};chosen=[]
    for x in contexts:
        row=[vector(x)[i]%p for i in cols]
        for col in sorted(piv):
            scale=row[col]
            row=[(a-scale*b)%p for a,b in zip(row,piv[col])]
        col=next((i for i,v in enumerate(row) if v),None)
        if col is None:continue
        inv=pow(row[col],-1,p);piv[col]=[v*inv%p for v in row];chosen.append(x)
        if len(chosen)==len(cols):break
    assert len(chosen)==len(cols)
    return chosen
rng=random.Random(202610311832)
contexts=[[0]*6]+[[rng.randrange(26) for _ in range(6)] for _ in range(1000)]
a=rank_basis(contexts,list(range(31)),13);b=rank_basis(contexts,[0]+list(range(1,7))+list(range(13,31)),2)
# Two functions agree on every row of constant7 ciphertext, differ on this basis.
x=next(x for x in a+b if (5-23*x[0])%26)
# Parity lag1 and lag2 have same zero-context crib syndrome, but not same function.
y=next(x for x in a+b if (13*x[0]-13*x[1])%26)
report={'mod13_rank':31,'parity_quotient_rank':25,'mod13_context_basis':a,'parity_context_basis':b,'finite_trace_vs_global':{'trace_ciphertext_value':7,'function_a':[[0,5]],'function_b':[[1,23]],'all91_trace_values':5,'basis_context':x,'a_value':5,'b_value':23*x[0]%26},'crib_alias_vs_global':{'function_a':[[1,13]],'function_b':[[2,13]],'crib_contexts':[0]*6,'basis_context':y,'a_value':13*y[0]%26,'b_value':13*y[1]%26},'global_coefficient_alias':{'function_a':[],'function_b':[[1,13],[7,13]],'identity':'13(x+x²)=0 modulo26 for every x'}}
Path(__file__).with_name('basis_results.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS ranks31/25; two explicit separating basis evaluations')
