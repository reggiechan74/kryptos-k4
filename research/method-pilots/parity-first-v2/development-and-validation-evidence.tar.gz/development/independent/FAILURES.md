# Retained development failures and instrumentation corrections

- Initial generator command attempted `/usr/bin/time -v` as external resource recorder. Executable was absent; shell exited127 before generator computation. No data were produced by that failed launch.
- Replaced that unavailable command with `bounded.py`: supervisor and executed child have600CPU-second and1GiB virtual-address caps;900-second process-group wall termination; wait4 captures child CPU/RSS, and supervisor peak RSS is recorded separately. Generation completed under this wrapper.
- A later status-only shell command tried to list the final audit resource receipt before the running audit finished; `ls` exited2 for the not-yet-written file. The audit continued unaffected. This was not a computational failure or missing final instrumentation.
