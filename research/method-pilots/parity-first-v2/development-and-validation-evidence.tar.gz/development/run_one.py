import json,sys,time,resource
from decoder_optimized import solve
case=json.load(open(sys.argv[1]))['cases'][int(sys.argv[2])]
t=time.process_time(); w=time.monotonic(); result=solve(case,sys.argv[3])
json.dump(dict(id=case['id'],method=sys.argv[3],cpu_seconds=time.process_time()-t,wall_seconds=time.monotonic()-w,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,result=result),open(sys.argv[4],'w'))
