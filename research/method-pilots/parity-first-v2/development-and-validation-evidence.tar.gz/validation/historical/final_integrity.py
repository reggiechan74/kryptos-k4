"""Read-only final integrity/closure checks; no scientific solver execution."""
import hashlib,json,re
from pathlib import Path
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
seal=json.load(open('OUTPUT-SEAL.json'))
for p,h in seal['sha256'].items():assert H(p)==h,p
pins=json.load(open('FREEZE-MANIFEST.json'))['source_sha256']
for p,h in pins.items():
    if Path(p).exists():assert H(p)==h,p
assert H('OUTPUT-SEAL.json')=='3deac935255b28f32a1839e8f4911fd80f22ef35aec6f43bbf9ebd3c3baa1781'
audit=json.load(open('independent-audit-results.json'));assert audit['passed'] and len(audit['cases'])==40
assert sum(c['witness_checks'] for c in audit['cases'])==25806
analysis=json.load(open('validation-analysis.json'));assert analysis['summary']['stages']==240
for c,a in zip(audit['cases'],analysis['cases']):
    assert c['id']==a['id'] and c['feasible']==a['feasible'] and c['forced_unknown']==a['forced_unknown'] and c['false_forced']==a['false_forced']
for path in Path('.').glob('*.md'):
    assert not re.search(r'page_[0-9a-f]{20,}',path.read_text()),path
r=dict(all523_sealed_files_unchanged=True,all_present_frozen_sources_unchanged=True,independent_audit_pass=True,analysis_matches_audit=True,no_holdout_case_dropped=True,no_scientific_retry=True)
Path('FINAL-INTEGRITY.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
