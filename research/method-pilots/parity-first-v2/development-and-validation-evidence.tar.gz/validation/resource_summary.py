import json
from pathlib import Path
rows=[]
for p in sorted(Path('.').glob('*.json')):
    x=json.loads(p.read_text())
    if isinstance(x,dict) and 'child_cpu_seconds' in x and 'parent_cpu_seconds' in x:
        rows.append(dict(receipt=str(p),cpu=x['child_cpu_seconds']+x['parent_cpu_seconds'],exit=x['exit_code'],child_peak_rss_kib=x['child_peak_rss_kib'],parent_peak_rss_kib=x['parent_peak_rss_kib']))
r=dict(scope='Top-level completed stage receipts at this snapshot; nested receipts are already included, never added twice. Excludes this summary and subsequent packaging, whose separate receipts remain available.',cpu_seconds=sum(x['cpu'] for x in rows),receipts=rows)
Path('RESOURCE-SUMMARY.json').write_text(json.dumps(r,indent=2)+'\n');print(r['cpu_seconds'],len(rows))
