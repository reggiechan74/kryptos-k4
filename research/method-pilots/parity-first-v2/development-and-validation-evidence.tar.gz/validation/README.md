# Parity-first v2 — completed synthetic validation

**40 cases,240 timed outputs, independent exact agreement.** The decoder and strong CRT baseline recover identical prediction sets; the measured difference is computation, not extra recovered information.

- [Results and limits](VALIDATION-REPORT.md)
- [Independent audit and custody](CUSTODY-AND-INDEPENDENT-AUDIT.md)
- [Approved protocol, executed unchanged](PROPOSED-HOLDOUT-PROTOCOL.md)
- [Exact analysis](validation-analysis.json)
- [Historical pre-packaging integrity check](historical/FINAL-INTEGRITY.json)
- [Resource accounting](RESOURCE-SUMMARY.json)

Summed per-case median CPU was19.612s for CRT versus14.403s for parity-first on this fixed workload. Both parity-alias losses, higher memory use and substantial repeat variability remain visible. Four observational twins demonstrate that a unique conditional prediction can be wrong when the true process lies outside the model. This is not a real-target solution or general speed/novelty guarantee.

## Evidence layout

`benchmark/` contains all240 exact output files and240 resource receipts, the randomized plan and completion/budget records. `OUTPUT-SEAL.json` pins the523 files sealed **before** truth release; `release-verification.json` verifies the chronology. `released-seed.json`, `released-truth.json` and `solver-inputs.json` permit independent reconstruction. One deterministic structural replay and dependent twins are explicit; this was not40 independent unseen random draws.

`FREEZE-MANIFEST.json` is the historical pre-generation freeze: its “pending/no holdout generated” status describes that earlier timestamp, not current completion. Scientific source hashes remain unchanged. New reports and release files are later additions, separately checksummed in `SHA256SUMS`.

The generator's original IDs were retained as `source_id` in released truth and replaced with index-based opaque IDs in both released truth and stripped solver inputs. Inputs contain only `id`, `ciphertext`, `observed`. No case was selected or dropped by solver outcome.

## Rechecking

Use a fresh working copy on Linux/Python3. From the bundle root, run `python verify_public_package.py`. The historical `historical/final_integrity.py` is preserved evidence, not a current verifier: it predates namespace separation and metadata redaction. Then inspect the unchanged scientific sources. To rerun independent audit of the recorded results in that copy:

```sh
python bounded_checked.py replay-audit-resource.json 600 512 900 python audit_inputs.py released-truth.json benchmark replay-audit-results.json
```

This is an **archival synthetic recheck**, not a fresh blind test. Reading the released labels permanently ends their held-out status. No target execution or broader model is authorized. `generation-launch-failure.json` and the failed reporting-command receipt remain historical evidence; neither discarded a scientific draw or case.

## Public metadata corrections

This namespace is the validation report, not the development README pinned by the approved freeze. The exact approved development README and REPORT are under `../development/`. Root `PROVENANCE.json` maps every original artifact to its public copy, including receipt redactions. Sanitized metadata is not claimed to match original sealed bytes; the root verifier checks original-hash commitments and public-copy hashes separately. Original scientific/data bytes are unchanged.
