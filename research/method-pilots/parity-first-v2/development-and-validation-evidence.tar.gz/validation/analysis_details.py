import json
from pathlib import Path
d=json.load(open('validation-analysis.json'))
print('Loss cases',[(r['id'],r['ratio'],r['methods']['parity']['stats']) for r in d['cases'] if r['ratio']>1])
print('Twins',[(r['id'],r['false_forced'],r['forced_unknown']) for r in d['cases'] if r['category']=='observational-twin'])
print('Medians ratio',d['summary']['methods']['parity']['sum_case_median_cpu']/d['summary']['methods']['crt']['sum_case_median_cpu'])
print('Stage complete',json.load(open('benchmark/complete.json')))
print('Control flags',[(r['id'],r['control_not_blind']) for r in d['cases'] if r['control_not_blind']])
print('Audit exists',Path('independent-audit-resource.json').exists())
