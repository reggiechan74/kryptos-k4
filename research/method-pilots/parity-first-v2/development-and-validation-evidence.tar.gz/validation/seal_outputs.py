"""Custody integrity only; no truth, scoring or scientific source modification."""
import hashlib,json
from pathlib import Path
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert H('FREEZE-MANIFEST.json')=='30e9950c7073f608fb4e62b5991eaf77bdb6e9c44417d85ff4f1475a84873302'
assert H('solver-inputs.json')=='ec8352242ed2da7e78c4a28d68c1a77d8361874dfa49179b0f26d702bb3e2e1b'
for p,digest in json.load(open('FREEZE-MANIFEST.json'))['source_sha256'].items():
    if Path(p).exists():assert H(p)==digest,p
    else:assert p in ('REPORT.md','README.md')
assert not Path('benchmark/incomplete.json').exists()
complete=json.load(open('benchmark/complete.json'));assert complete['stages']==240 and complete['inclusive_stage_cpu']<=4000
for r in range(3):
    for i in range(40):
        for m in ('crt','parity'):
            stem=f'benchmark/{r}-{i:02d}-{m}'
            assert Path(stem+'.json').is_file()
            receipt=json.load(open(stem+'-receipt.json'));assert receipt['exit_code']==0 and not receipt['wall_timeout']
parent=json.load(open('benchmark-parent-receipt.json'));assert parent['exit_code']==0 and not parent['wall_timeout']
files=sorted(p for p in Path('.').rglob('*') if p.is_file() and '__pycache__' not in str(p) and not p.name.startswith('OUTPUT-SEAL') and not p.name.startswith('seal-resource'))
manifest={str(p):H(p) for p in files}
Path('OUTPUT-SEAL.json').write_text(json.dumps(dict(status='all240 stages complete; truth/seed not released to runner',complete=complete,sha256=manifest),indent=2)+'\n')
print('Sealed',len(files),'files; SHA256',H('OUTPUT-SEAL.json'))
