"""Descriptive analysis after all outputs are sealed and truth released; no tuning."""
import json,statistics,math
from pathlib import Path
cases=json.load(open('released-truth.json'))['cases']; rows=[]; allm={'crt':[],'parity':[]}
for i,c in enumerate(cases):
    d={}
    for method in ('crt','parity'):
        outputs=[json.load(open(f'benchmark/{r}-{i:02d}-{method}.json')) for r in range(3)]
        receipts=[json.load(open(f'benchmark/{r}-{i:02d}-{method}-receipt.json')) for r in range(3)]
        for out in outputs:assert out['result']['masks']==outputs[0]['result']['masks']
        cpu=[out['cpu_seconds'] for out in outputs]; wall=[out['wall_seconds'] for out in outputs]
        d[method]=dict(cpu=cpu,median_cpu=statistics.median(cpu),median_wall=statistics.median(wall),cpu_max_min_ratio=max(cpu)/min(cpu),median_inclusive_child_cpu=statistics.median(r['child_cpu_seconds'] for r in receipts),peak_rss_kib=max(r['child_peak_rss_kib'] for r in receipts),stats=outputs[0]['result']['stats'])
        allm[method].extend(cpu)
        if method=='crt':masks=outputs[0]['result']['masks'];feasible=outputs[0]['result']['feasible']
        else:assert masks==outputs[0]['result']['masks']
    unknown=[j for j in range(6,97) if str(j) not in c['observed']]
    forced=sum(masks[j-6].bit_count()==1 for j in unknown)
    false=None if c['truth_mask'] is None else sum(masks[j-6].bit_count()==1 and not(masks[j-6]>>c['truth_mask'][j-6]&1) for j in unknown)
    rows.append(dict(id=c['id'],source_id=c.get('source_id'),category=c['category'],in_family=c['in_family'],provenance=c.get('provenance'),control_not_blind=c.get('control_not_blind',False),methods=d,ratio=d['parity']['median_cpu']/d['crt']['median_cpu'],feasible=feasible,forced_unknown=forced,false_forced=false))
summary=dict(cases=len(rows),stages=240,exact_masks_agree_all_repeats=True,median_paired_ratio=statistics.median(r['ratio'] for r in rows),parity_faster=sum(r['ratio']<1 for r in rows),parity_slower=sum(r['ratio']>1 for r in rows),ties=sum(r['ratio']==1 for r in rows),in_family_cases=sum(r['in_family'] is True for r in rows),in_family_forced=sum(r['forced_unknown'] for r in rows if r['in_family'] is True),in_family_false_forced=sum(r['false_forced'] for r in rows if r['in_family'] is True),in_family_all_unknown_forced=sum(r['forced_unknown']==67 for r in rows if r['in_family'] is True),methods={m:dict(sum_case_median_cpu=sum(r['methods'][m]['median_cpu'] for r in rows),all_repetition_solver_cpu=sum(allm[m]),peak_rss_kib=max(r['methods'][m]['peak_rss_kib'] for r in rows),max_repetition_cpu_ratio=max(r['methods'][m]['cpu_max_min_ratio'] for r in rows)) for m in allm})
strata={}
for category in sorted({r['category'] for r in rows}):
    rr=[r for r in rows if r['category']==category]
    strata[category]=dict(cases=len(rr),parity_faster=sum(r['ratio']<1 for r in rr),median_ratio=statistics.median(r['ratio'] for r in rr),crt_cpu=sum(r['methods']['crt']['median_cpu'] for r in rr),parity_cpu=sum(r['methods']['parity']['median_cpu'] for r in rr),forced_unknown=sum(r['forced_unknown'] for r in rr))
Path('validation-analysis.json').write_text(json.dumps(dict(summary=summary,strata=strata,cases=rows),indent=2)+'\n')
print(json.dumps(summary,indent=2));print(json.dumps(strata,indent=2))
