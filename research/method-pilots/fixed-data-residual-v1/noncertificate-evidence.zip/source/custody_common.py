"""Fixed-data post-failure custody bridge. No import-time I/O or generation."""
import ctypes
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys

ROOT = Path('/workspace/shared/residual-fixed-data-reevaluation-v1')
PUBLIC_ROOT = Path('/workspace/shared/residual-fixed-data-reevaluation-v1-public')
ORIGIN_PATH = PUBLIC_ROOT / 'ORIGIN-MANIFEST.json'
ORIGIN_PIN = '002541c7d8c9786d21f1b5a3fb3293efc83709ee32d1cb72ba751eb7383ca80b'
ORIGIN_INVENTORY_PATH = PUBLIC_ROOT / 'ORIGIN-RUN-INVENTORY.json'
ORIGIN_INVENTORY_PIN = 'a86c20e9c142e00f8f9165fe83184517b7d8324039d7cc86ced3f79aeb642f70'
ORIGINAL_FREEZE_PIN = '77bda1efb5878971eb7ff42feeca26acd1e79813329ca30108b72aeeeebe8767'
ORIGINAL_INPUT_PATH = '/workspace/shared/residual-fresh-validation-v2-public/solver-input.json'
ORIGINAL_INPUT_PIN = '79319cb9272242cd7f44b7bf2ccf6c9a630450ddab82c7cc2adb6457bd297747'
ORIGINAL_GENERATOR_PATH = Path('/workspace/shared/residual-fresh-validation-v2/generator.py')
ORIGINAL_GENERATOR_PIN = '4bf7b8198603f255692b90b5d5ab479ac0c4fa74ab8c2fa9871f6f54668edfa9'
MIB = 1024 * 1024
JSON_MAX = 2 * MIB
PUBLIC_MAX = 262144
TRUTH_MAX = 262144
SOURCE_MAX = 64 * MIB
OBS_ROWS = tuple(range(15, 28)) + tuple(range(57, 68))
FREEZE_KEYS = {'schema','files','python','jobs','limits','mock_jobs','public_paths',
               'analysis_manifest_sha256','resource_allocation_sha256',
               'origin_manifest_sha256','generation_origin_freeze_sha256'}
CUSTODY_KEYS = {'schema','status','public_sha256','truth_sha256','seed_sha256',
               'freeze_sha256','analysis_manifest_sha256','resource_allocation_sha256',
               'draw_approval_sha256','private_commands_sha256','python_version','rng',
               'origin_manifest_sha256','generation_origin_freeze_sha256',
               'original_custody_sha256','reuse_approval_sha256'}
RUN_APPROVAL_KEYS = {'schema','status','freeze_sha256','input_sha256','custody_sha256',
                     'draw_approval_sha256','public_input_path','results_dir',
                     'origin_manifest_sha256','generation_origin_freeze_sha256',
                     'reuse_approval_sha256','ancestry_attestation_sha256'}
ANCESTRY_ATTESTATION_KEYS = {'schema','status','freeze_sha256','input_sha256','custody_sha256',
    'draw_approval_sha256','origin_manifest_sha256','generation_origin_freeze_sha256',
    'reuse_approval_sha256','candidate_sha256','binding_receipt_sha256',
    'binding_stdout_sha256','binding_stderr_sha256','approval_use_marker_sha256',
    'worker_cpu_seconds','supervisor_cpu_seconds','wall_seconds','external_tool_exit_code',
    'external_tool_completed','receipt_exit_code','child_reaped','wall_timeout','log_overflow',
    'post_sources_input_custody_checked'}
REUSE_APPROVAL_KEYS = {'schema','status','freeze_sha256','analysis_manifest_sha256',
                      'resource_allocation_sha256','origin_manifest_sha256','public_dir',
                      'private_commands_path','private_commands_sha256'}
PRIVATE_COMMAND_KEYS = {'schema','bind_ancestry','seal_results','analyze'}
PIN_NAMES = {'REUSE_APPROVAL_PIN','FREEZE_PIN','INPUT_PIN','CUSTODY_PIN',
             'PRIVATE_COMMANDS_PIN','RECEIPTS_PIN','TERMINAL_PIN','TRUTH_PIN','ANALYSIS_PIN'}
ANCESTORS = {
 '/workspace/shared/canonical-residual-dev/residual_decoder.py':'be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67',
 '/workspace/shared/canonical-residual-dev/affine_filter.py':'1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d',
 '/workspace/shared/canonical-residual-reference-v3/reference_v3.py':'0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9',
 str(ORIGINAL_GENERATOR_PATH):ORIGINAL_GENERATOR_PIN,
 str(ORIGIN_PATH):ORIGIN_PIN,
 str(ORIGIN_INVENTORY_PATH):ORIGIN_INVENTORY_PIN}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def integer(value, maximum=None):
    return type(value) is int and value >= 0 and (maximum is None or value <= maximum)


def finite(value):
    return ((type(value) is int and value >= 0) or
            (type(value) is float and math.isfinite(value) and value >= 0))


def digest(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def nonfinite(_value):
    raise ValueError('nonfinite JSON number')


def canonical_path(path, must_exist=True):
    path = Path(path)
    require(path.is_absolute() and str(path) == str(path.resolve()), 'canonical absolute path required')
    require(not path.is_symlink(), 'symlink path forbidden')
    if must_exist:
        require(path.is_file(), 'regular file required')
    return path


def read_bytes(path, limit):
    require(integer(limit), 'strict byte cap')
    path = canonical_path(path)
    require(path.stat().st_size <= limit, 'file exceeds byte cap before read')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    require(len(data) <= limit, 'file grew past byte cap')
    return data


def read_json(path, limit=JSON_MAX, pin=None):
    data = read_bytes(path, limit)
    if pin is not None:
        require(digest(pin) and hashlib.sha256(data).hexdigest() == pin, 'JSON hash mismatch')
    value = json.loads(data, object_pairs_hook=unique, parse_constant=nonfinite)
    require(canonical(value) == data, 'canonical JSON bytes required')
    return value


def sha(path, limit=SOURCE_MAX):
    path = canonical_path(path)
    require(integer(limit) and path.stat().st_size <= limit, 'hash byte cap')
    count = 0
    result = hashlib.sha256()
    with path.open('rb') as handle:
        while True:
            block = handle.read(min(MIB, limit - count + 1))
            if not block:
                break
            count += len(block)
            require(count <= limit, 'file grew past hash cap')
            result.update(block)
    return result.hexdigest()


def fsync_dir(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(path, value, limit=JSON_MAX):
    path = canonical_path(path, False)
    data = canonical(value)
    require(len(data) <= limit, 'serialized byte cap includes final LF')
    with path.open('xb') as handle:
        require(handle.write(data) == len(data), 'short write')
        handle.flush()
        os.fsync(handle.fileno())
    fsync_dir(path.parent)


def require_bounds(cpu, memory_mib):
    require(resource.getrlimit(resource.RLIMIT_CPU) == (cpu, cpu + 1), 'bounded CPU launcher required')
    memory = memory_mib * MIB
    require(resource.getrlimit(resource.RLIMIT_AS) == (memory, memory), 'bounded address space required')
    death = ctypes.c_int()
    require(ctypes.CDLL(None).prctl(2, ctypes.byref(death), 0, 0, 0) == 0
            and death.value == signal.SIGKILL, 'parent-death guard required')
    require(sys.flags.isolated == 1 and sys.dont_write_bytecode and not sys.flags.optimize,
            'custody entry requires isolated normal no-bytecode Python')


def verify_freeze(path, pin):
    require(str(canonical_path(path)) == str(ROOT / 'FREEZE.json'), 'fixed public freeze path')
    freeze = read_json(path, JSON_MAX, pin)
    require(type(freeze) is dict and set(freeze) == FREEZE_KEYS
            and freeze['schema'] == 'fixed-data-post-failure-reevaluation-v1-freeze', 'freeze schema')
    files = freeze['files']
    require(type(files) is dict and 8 <= len(files) <= 64, 'source file mapping')
    for name, expected in files.items():
        require(type(name) is str and digest(expected), 'source pin shape')
        p = canonical_path(name)
        require(p.parent == ROOT or name in ANCESTORS, 'source path outside frozen allowed roots')
        if name in ANCESTORS:
            require(expected == ANCESTORS[name], 'immutable engine/reference pin')
        require(sha(p) == expected, 'source changed: ' + name)
    for name, expected in ANCESTORS.items():
        require(files.get(name) == expected, 'missing immutable ancestor')
    require(str(ROOT / 'custody_common.py') in files, 'custody helper must be frozen')
    python = freeze['python']
    require(type(python) is dict and set(python) == {'executable','sha256','version'}, 'interpreter schema')
    require(python['executable'] == str(Path(sys.executable).resolve())
            and python['version'] == sys.version and digest(python['sha256'])
            and sha(python['executable']) == python['sha256'], 'interpreter identity')
    require(type(freeze['public_paths']) is dict and freeze['public_paths'] ==
            public_paths(), 'explicit fixed original input and NEW operational metadata paths')
    for value in freeze['public_paths'].values():
        canonical_path(value, False)
    require(freeze['public_paths']['results'] == str(ROOT / 'runs'), 'fixed result root')
    require(type(freeze['jobs']) is dict and len(freeze['jobs']) == 28, '28 frozen jobs required')
    require(type(freeze['mock_jobs']) is dict and len(freeze['mock_jobs']) == 2, 'two mock jobs required')
    for field, filename in (('analysis_manifest_sha256','ANALYSIS-MANIFEST.json'),
                            ('resource_allocation_sha256','RESOURCE-ALLOCATION.json')):
        require(digest(freeze[field]) and files.get(str(ROOT / filename)) == freeze[field], 'manifest linkage')
    require(freeze['origin_manifest_sha256'] == ORIGIN_PIN
            and freeze['generation_origin_freeze_sha256'] == ORIGINAL_FREEZE_PIN,
            'original-generation versus new-run freeze binding')
    read_origin(freeze)
    return freeze


def load_pinned(name, path, freeze):
    path = canonical_path(path)
    require(freeze['files'].get(str(path)) == sha(path), 'module source pin')
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'module loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read_public(path, pin):
    public = read_json(path, PUBLIC_MAX, pin)
    require(type(public) is dict and set(public) == {'schema','cases'}
            and public['schema'] == 'fresh-residual-public-v2', 'public schema')
    require(type(public['cases']) is list and len(public['cases']) == 12, '12 public base cases')
    for index, case in enumerate(public['cases']):
        require(type(case) is dict and set(case) == {'id','instance'}
                and case['id'] == 'v%03d' % index, 'neutral ordered case IDs')
        instance = case['instance']
        require(type(instance) is dict and set(instance) ==
                {'contexts','observed','sparsity','allowed_features'}, 'solver-only fields')
        require(type(instance['sparsity']) is int and instance['sparsity'] == 3
                and type(instance['allowed_features']) is list
                and all(type(v) is int for v in instance['allowed_features'])
                and instance['allowed_features'] == list(range(31)), 'fixed model')
        contexts = instance['contexts']
        require(type(contexts) is list and len(contexts) == 91, '91 contexts')
        for row in contexts:
            require(type(row) is list and len(row) == 6
                    and all(type(v) is int and 0 <= v < 26 for v in row), 'six Z26 symbols')
        require(all(contexts[i + 1][1:] == contexts[i][:-1] for i in range(90)), 'contiguous history overlap')
        observed = instance['observed']
        require(type(observed) is list and len(observed) == 24, '24 observations')
        for pair, row in zip(observed, OBS_ROWS):
            require(type(pair) is list and len(pair) == 2 and type(pair[0]) is int
                    and pair[0] == row and type(pair[1]) is int and 0 <= pair[1] < 26,
                    'fixed observed position/value')
    return public


def public_paths():
    """Never derive NEW approval paths from the reused original input's parent."""
    return {'input':ORIGINAL_INPUT_PATH, 'custody':str(PUBLIC_ROOT/'custody.json'),
            'run_approval':str(PUBLIC_ROOT/'RUN_APPROVAL.json'), 'results':str(ROOT/'runs'),
            'origin_manifest':str(ORIGIN_PATH),
            'ancestry_attestation':str(PUBLIC_ROOT/'REEVALUATION-ANCESTRY-ATTESTATION.json'),
            'approval_candidate':str(PUBLIC_ROOT/'REEVALUATION_RUN_APPROVAL.candidate.json')}


def validate_origin(value):
    """Exact custodian-authenticated canonical metadata, not generation or truth."""
    require(type(value) is dict and set(value)=={'schema','generation_origin','original_failure','scope'}
        and value['schema']=='fixed-data-post-failure-reevaluation-origin-v1','exact origin schema')
    # This fixed digest authenticates every nested key/value, including original
    # custody and sanitized external chronology. It grants no new run authority.
    require(hashlib.sha256(canonical(value)).hexdigest()==ORIGIN_PIN,'exact independently supplied origin commitment')
    origin=value['generation_origin'];custody=origin['custody']
    require(origin['freeze']['sha256']==ORIGINAL_FREEZE_PIN
        and origin['input']=={'path':ORIGINAL_INPUT_PATH,'sha256':ORIGINAL_INPUT_PIN}
        and origin['generator']=={'path':str(ORIGINAL_GENERATOR_PATH),'sha256':ORIGINAL_GENERATOR_PIN},
        'immutable original source/input/generator identity')
    require(custody['freeze_sha256']==ORIGINAL_FREEZE_PIN and custody['public_sha256']==ORIGINAL_INPUT_PIN
        and hashlib.sha256(canonical(custody)).hexdigest()==origin['custody_document']['sha256'],
        'original custody remains under original generation freeze')
    return value


def read_origin(freeze):
    require(freeze['origin_manifest_sha256']==ORIGIN_PIN
        and freeze['generation_origin_freeze_sha256']==ORIGINAL_FREEZE_PIN
        and freeze['public_paths']==public_paths(),'fixed origin and explicit NEW paths')
    return validate_origin(read_json(ORIGIN_PATH,65536,ORIGIN_PIN))


def verify_origin_metadata(origin):
    """Binder-only read-only hash preservation check. No private path or replay.

    No worker/mock calls this function. Certificate bytes are hashed once against
    the custodian's exact inventory, never parsed, copied or mathematically used.
    """
    validate_origin(origin)
    generation=origin['generation_origin'];failure=origin['original_failure']
    for name in ('freeze','analysis_manifest','resource_allocation','generator','input',
                 'custody_document','seed_commitment','run_approval','generation_attestation','generation_candidate'):
        item=generation[name]
        require(type(item) is dict and set(item)=={'path','sha256'}
            and sha(item['path'])==item['sha256'],'original public/source metadata changed: '+name)
    for name in ('state','lock','runner_external_completion','independent_failure_review','run_inventory'):
        item=failure[name]
        require(type(item) is dict and set(item)=={'path','sha256'}
            and sha(item['path'])==item['sha256'],'original failure metadata changed: '+name)
    old_freeze=read_json(generation['freeze']['path'],JSON_MAX,ORIGINAL_FREEZE_PIN)
    require(old_freeze['schema']=='fresh-residual-validation-v2-freeze','historical freeze schema')
    for name,pin in old_freeze['files'].items():
        require(sha(name)==pin,'original source remains immutable')
    inventory=read_json(ORIGIN_INVENTORY_PATH,65536,ORIGIN_INVENTORY_PIN)
    require(inventory['schema']=='fixed-data-post-failure-origin-run-inventory-v1'
        and inventory['file_count']==42 and inventory['total_bytes']==40761555,
        'fixed original failure inventory')
    original_root=Path(failure['results_path'])
    require(original_root==Path('/workspace/shared/residual-fresh-validation-v2/runs')
        and original_root.is_dir() and not original_root.is_symlink(),'fixed original runtime root')
    names=set();directories=set();total=0
    for item in inventory['files']:
        require(type(item) is dict and set(item)=={'path','bytes','sha256'}
            and type(item['path']) is str and integer(item['bytes'],32*MIB)
            and digest(item['sha256']),'original inventory entry')
        relative=Path(item['path'])
        require(not relative.is_absolute() and '..' not in relative.parts
            and len(relative.parts) in (1,2) and item['path'] not in names,'fixed original relative path')
        names.add(item['path'])
        if len(relative.parts)==2:directories.add(relative.parts[0])
        path=canonical_path(original_root/relative)
        require(path.stat().st_size==item['bytes'] and sha(path,item['bytes'])==item['sha256'],
            'original retained artifact changed')
        total+=item['bytes']
    actual={str(p.relative_to(original_root)) for p in original_root.rglob('*')}
    require(actual==names|directories and len(names)==42 and total==40761555,
            'exact original tree remains preserved')
    return True


def make_custody(origin,freeze,freeze_pin,reuse_approval_pin,private_commands_pin):
    """Pure new run binding; it never rewrites the original generation custody."""
    validate_origin(origin)
    old=origin['generation_origin']['custody']
    require(digest(reuse_approval_pin) and digest(private_commands_pin),'new authorization digests')
    return {'schema':'fixed-data-post-failure-run-binding-v1','status':'BOUND_EXISTING_FIXED_DATA',
        'public_sha256':old['public_sha256'],'truth_sha256':old['truth_sha256'],'seed_sha256':old['seed_sha256'],
        'freeze_sha256':freeze_pin,'analysis_manifest_sha256':freeze['analysis_manifest_sha256'],
        'resource_allocation_sha256':freeze['resource_allocation_sha256'],
        'draw_approval_sha256':old['draw_approval_sha256'],'private_commands_sha256':private_commands_pin,
        'python_version':old['python_version'],'rng':old['rng'],'origin_manifest_sha256':ORIGIN_PIN,
        'generation_origin_freeze_sha256':ORIGINAL_FREEZE_PIN,
        'original_custody_sha256':origin['generation_origin']['custody_document']['sha256'],
        'reuse_approval_sha256':reuse_approval_pin}


def validate_custody(value,freeze,freeze_pin,input_pin,origin=None):
    require(type(value) is dict and set(value)==CUSTODY_KEYS,'exact new run-binding schema')
    require(value['schema']=='fixed-data-post-failure-run-binding-v1'
        and value['status']=='BOUND_EXISTING_FIXED_DATA','run binding is not a new draw')
    for key in CUSTODY_KEYS-{'schema','status','python_version','rng'}:
        require(digest(value[key]),'run-binding digest: '+key)
    if origin is None:origin=read_origin(freeze)
    expected=make_custody(origin,freeze,freeze_pin,value['reuse_approval_sha256'],value['private_commands_sha256'])
    require(value==expected and input_pin==ORIGINAL_INPUT_PIN,'exact generation-origin/new-run binding')
    require(value['python_version']==freeze['python']['version'],'same original generator interpreter version')
    return value


def candidate_approval(custody,custody_pin,freeze,freeze_pin):
    require(digest(custody_pin),'run-binding pin')
    return {'schema':'fixed-data-post-failure-run-approval-candidate-v1','status':'PENDING_ANCESTRY_RECEIPT',
        'freeze_sha256':freeze_pin,'input_sha256':ORIGINAL_INPUT_PIN,'custody_sha256':custody_pin,
        'draw_approval_sha256':custody['draw_approval_sha256'],'origin_manifest_sha256':ORIGIN_PIN,
        'generation_origin_freeze_sha256':ORIGINAL_FREEZE_PIN,'reuse_approval_sha256':custody['reuse_approval_sha256'],
        'public_input_path':freeze['public_paths']['input'],'results_dir':freeze['public_paths']['results']}


def validate_run_identity(value,freeze,freeze_pin,input_pin,custody_pin):
    require(type(value) is dict and set(value)==RUN_APPROVAL_KEYS,'exact NEW public run approval')
    require(value['schema']=='fixed-data-post-failure-run-approval-v1'
        and value['status']=='APPROVED_WHOLE_FIXED_DATA_REEVALUATION','new whole fixed-data run not authorized')
    for key in RUN_APPROVAL_KEYS-{'schema','status','public_input_path','results_dir'}:
        require(digest(value[key]),'run approval pin: '+key)
    require(value['freeze_sha256']==freeze_pin and value['input_sha256']==input_pin==ORIGINAL_INPUT_PIN
        and value['custody_sha256']==custody_pin and value['origin_manifest_sha256']==ORIGIN_PIN
        and value['generation_origin_freeze_sha256']==ORIGINAL_FREEZE_PIN
        and value['public_input_path']==freeze['public_paths']['input']
        and value['results_dir']==freeze['public_paths']['results'],'new run approval bindings')
    require(freeze['public_paths']==public_paths(),'explicit new metadata paths required')
    return value


def validate_run_approval(value,freeze,freeze_pin,input_pin,custody_pin):
    validate_run_identity(value,freeze,freeze_pin,input_pin,custody_pin)
    custody=read_json(freeze['public_paths']['custody'],65536,custody_pin)
    validate_custody(custody,freeze,freeze_pin,input_pin)
    for key in ('draw_approval_sha256','reuse_approval_sha256','origin_manifest_sha256','generation_origin_freeze_sha256'):
        require(value[key]==custody[key],'run approval/custody ancestry: '+key)
    attestation=read_json(freeze['public_paths']['ancestry_attestation'],65536,value['ancestry_attestation_sha256'])
    validate_ancestry_attestation(attestation,value)
    candidate=read_json(freeze['public_paths']['approval_candidate'],65536,attestation['candidate_sha256'])
    require(candidate==candidate_approval(custody,custody_pin,freeze,freeze_pin),
        'active approval differs from pending ancestry candidate')
    return value


def validate_ancestry_attestation(value,run_approval):
    """Requires externally acknowledged binder completion; not self-activation."""
    require(type(value) is dict and set(value)==ANCESTRY_ATTESTATION_KEYS
        and value['schema']=='fixed-data-post-failure-ancestry-attestation-v1'
        and value['status']=='PARENT_CUSTODIAN_VERIFIED_ANCESTRY_BINDING','ancestry attestation schema/status')
    for key in ('freeze_sha256','input_sha256','custody_sha256','draw_approval_sha256',
                'origin_manifest_sha256','generation_origin_freeze_sha256','reuse_approval_sha256'):
        require(value[key]==run_approval[key] and digest(value[key]),'ancestry attestation linkage')
    for key in ('candidate_sha256','binding_receipt_sha256','binding_stdout_sha256',
                'binding_stderr_sha256','approval_use_marker_sha256'):
        require(digest(value[key]),'binding evidence digest')
    require(finite(value['worker_cpu_seconds']) and value['worker_cpu_seconds']<=31
        and finite(value['supervisor_cpu_seconds']) and value['supervisor_cpu_seconds']<=31
        and finite(value['wall_seconds']) and value['wall_seconds']<=120,'binding resource allowances')
    require(type(value['external_tool_exit_code']) is int and value['external_tool_exit_code']==0
        and type(value['receipt_exit_code']) is int and value['receipt_exit_code']==0
        and value['external_tool_completed'] is True and value['child_reaped'] is True
        and value['wall_timeout'] is False and value['log_overflow'] is False
        and value['post_sources_input_custody_checked'] is True,'binding receipt/exit/postseal gate')
    return value


def validate_reuse_approval(approval,freeze,freeze_pin,public_dir):
    require(type(approval) is dict and set(approval)==REUSE_APPROVAL_KEYS
        and approval['schema']=='fixed-data-post-failure-reuse-approval-v1'
        and approval['status']=='APPROVED_ONE_ANCESTRY_BINDING_ONLY','explicit one-shot reuse approval')
    require(approval['freeze_sha256']==freeze_pin
        and approval['origin_manifest_sha256']==ORIGIN_PIN
        and approval['analysis_manifest_sha256']==freeze['analysis_manifest_sha256']
        and approval['resource_allocation_sha256']==freeze['resource_allocation_sha256']
        and approval['public_dir']==str(PUBLIC_ROOT)==str(public_dir),'reuse approval bindings')
    require(digest(approval['private_commands_sha256']),'private command digest')
    private=canonical_path(approval['private_commands_path'])
    require(PUBLIC_ROOT not in private.parents and ROOT not in private.parents,
        'private commands outside public and source roots')
    return approval


def read_private_commands(path,pin):
    commands=read_json(path,JSON_MAX,pin)
    require(type(commands) is dict and set(commands)==PRIVATE_COMMAND_KEYS
        and commands['schema']=='fixed-data-post-failure-private-commands-v1','private command roles: no generator')
    for role in ('bind_ancestry','seal_results','analyze'):
        command=commands[role]
        require(type(command) is list and 5<=len(command)<=60
            and all(type(v) is str and 0<len(v)<=4096 for v in command),'private argv shape')
        for token in command:
            if '${' in token:
                require(token.startswith('${') and token.endswith('}')
                    and token[2:-1] in PIN_NAMES,'only approved whole-token pin substitutions')
    return commands


def bind_private_command(commands,role,pins,argv):
    require(role in ('bind_ancestry','seal_results','analyze') and type(pins) is dict
        and set(pins)<=PIN_NAMES and all(digest(v) for v in pins.values()),'derived pin mapping')
    expanded=[]
    for token in commands[role]:
        if token.startswith('${'):
            key=token[2:-1];require(key in pins,'missing derived pin');token=pins[key]
        expanded.append(token)
    actual=[str(Path(sys.executable).resolve()),'-I','-B',str(ROOT/(role+'.py'))]+list(argv)
    require(expanded==actual,'private command differs from frozen expanded argv')
    return expanded


def read_analysis_manifest(path,pin,freeze):
    require(str(canonical_path(path))==str(ROOT/'ANALYSIS-MANIFEST.json')
        and pin==freeze['analysis_manifest_sha256'],'analysis manifest identity')
    value=read_json(path,JSON_MAX,pin)
    require(type(value) is dict and set(value)=={'schema','files'}
        and value['schema']=='fixed-data-post-failure-analysis-manifest-v1'
        and type(value['files']) is dict,'analysis manifest schema')
    expected={str(ROOT/name) for name in
        ('analyze.py','custody_common.py','seal_results.py','supervisor.py','bounded_stage.py')}|{str(ORIGINAL_GENERATOR_PATH)}
    require(set(value['files'])==expected,'new analysis wrappers plus ORIGINAL historical generator')
    require(all(freeze['files'].get(path)==expected and sha(path)==expected
        for path,expected in value['files'].items()),'analysis dependency pins')
    return value
