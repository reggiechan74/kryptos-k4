# Exact next-stage authorization request — not an active approval

**Scope:** implement the reviewed fixed-data post-failure re-evaluation, preserving the original INCOMPLETE run and the same whole twelve-base dataset. The user's latest direction permits fixing and continuing tests; no further user reconfirmation is requested. The parent still controls these finite stage boundaries. This request itself performs or authorizes no invocation.

## Requested immediate parent decision

1. Reserve **3,000 NEW nominal CPU seconds** and the specified **1.25 GiB new-stage disk ceiling**. Allocation becomes 23,200/28,800, leaving 5,600. Keep the original 80, old canceled/unlaunched allocations and all older contingency unavailable. Exact partition:2,240 whole cohort +124 two mocks +62 one ancestry-only binder +12 sealer +362 released analysis +200 static/control/review/tails.
2. Authorize **source-only preparation** in `/workspace/shared/residual-fixed-data-reevaluation-v1`, new public operational metadata in `/workspace/shared/residual-fixed-data-reevaluation-v1-public`, and independent source-review metadata in the proposed review namespace. No original path may be written. If any proposed execution namespace already exists, stop for parent disposition; never overwrite or infer an earlier partial run is reusable.
3. Assign an operationally independent custodian to supply sanitized original public commitment pins and prepare the separate private ancestry command bindings, without opening seed/truth or creating a new seed/draw. Actual private bindings remain outside source/worker argv.
4. Permit **exactly two operational mock commands, normal then optimized, conditionally only after independent final source/schema/count/fixture/command freeze approval**. The parent may instead defer this mock permission until the source review; either route must be explicit. No binder, cohort, sealer, truth release or analysis is authorized by these preparation/mock decisions.

## Exact source-change boundary

| File/group | Allowed delta |
|---|---|
| Original producer, affine dependency, independent reference, original generator | **No byte changes and no copies with altered roots.** Pin their existing absolute source paths. Generator is historical source and post-release pure replay dependency only; no new generator CLI/entropy/seed operation |
| New `checker_blind.py` | Byte-identical copy of original SHA `065e3c29d2705c706b44a553bd9013b10c84751251145a4a683b940962ecc5c6`; no mathematical, parsing, accounting, traversal or schema change |
| New `preflight_blind.py` | Original bytes except `Caps.max_seconds` default **20.0→60.0**. No timing instrumentation or algorithm change. Existing certificate schema/role labels are retained structural version names, not a new-fresh claim |
| New `worker.py` | New root, explicit fixed-data run/report identity, origin-manifest binding and new authority validation; unchanged input selection by the frozen public IDs, mathematical call order/arguments, digest semantics and logical caps |
| New `supervisor.py` | New namespace/identity/ancestry paths and **completed preflight wall acceptance 20→60**; unchanged 28-slot schedule,60/75 worker CPU,4/5 supervisor CPU,150 wall, memory/log/storage/reservation/collector/reaping/mode-check semantics |
| New `custody_common.py` | Strictly distinguish original-generation provenance from new-run freeze/analysis/resource authority; explicitly freeze NEW attestation/candidate/approval paths instead of deriving them from the original input's parent; preserve strict types/canonical JSON/exclusive writes and fail-closed boundaries |
| New `bind_ancestry.py` | One bounded metadata-only custody bridge, new reuse marker and pending candidate; no generator import/call, entropy, solver, truth or seed path access, or old-state mutation. It cannot activate its own approval |
| New `bounded_stage.py` | Mechanical schema/role/mock-freeze adaptations only; no collector, bounds, process count, alarm, PID/death guard, waitid/WNOWAIT or wait4 algorithm change |
| New `seal_results.py` and `analyze.py` | New run/ancestry/private-command bindings and fixed-data interpretation; exact new terminal inventory before truth access; immutable original generator pure replay only after authorized release; preserve original plant/twin/coverage mathematics and no solver/reference calls |
| Manifests, schemas, protocol, accounting and `protocol_mock_tests.py` | Explicit finite origin/run graph, same fixed input hash, exact changed-source list, frozen commands/fixtures/count dictionary, missing-pin and external-completion gates, existing operational obligations mapped and added ancestry-boundary mocks |

The independent reviewer must reject any hunk outside this list or any unannounced source optimization. If byte-identical checker or one-literal preflight reuse proves impossible, stop and return the exact necessary delta to the parent before widening it. No case values may influence the source delta, scheduling, limits or tests.

## Before either mock

- Supply every exact origin commitment; freeze all source/interpreter/dependency hashes, immutable original generator path, public schemas, strict typed caps and finite disk inventory. Original freeze is `77bda1efb5878971eb7ff42feeca26acd1e79813329ca30108b72aeeeebe8767`; fixed input hash is `79319cb9272242cd7f44b7bf2ccf6c9a630450ddab82c7cc2adb6457bd297747`.
- Freeze the exact finite assertion/fixture/count dictionary; retain the original 266 obligations or explicitly map replacements, plus the specified ancestry/path/resource-boundary cases. No claim of a passing count before code/review exists.
- Freeze two outer mock commands and all 28 future worker/supervisor commands, plus one future binder, sealer and analyzer. Private commands have no generator role. Only finite named whole-token hash substitutions; no shell-generated unbounded loop.
- Independent reviewer issues exact source-freeze approval; parent or its exact conditional grant binds that freeze. Both mock source imports remain guarded against real generation, case access, solver/reference calls, actual inner children and truth reads.
- Each outer mock has worker 30/31 and supervisor 30/31 nominal CPU,512 MiB per process,120 s wall, bounded separately sealed logs and one-use marker. Normal failure/uncertainty stops optimized; no third invocation/retry. Static reviews do not gain separate scientific test invocations.

## Required later decisions, not included now

1. Independently accept both externally completed mock receipts and final frozen source; authorize the exact one-shot ancestry-only binder/private paths. Binder uses30/31 CPU per process,512 MiB per process,120 s wall and 62 allocation.
2. Parent+custodian accept binder receipt/log/use-marker/postseals and external completion, then pin new active run approval. No old draw/run approval can activate the new namespace.
3. Authorize the exact whole 28-slot schedule, normal then optimized per fixed ID, with uniform 60-second preflight and unchanged outer/resource/semantic criteria. Source/mock PASS is not run approval. No old successful slot is counted toward new completion.
4. Only all 28 accepted terminal slots with zero reserve and complete authenticated inventories can approach the separately authorized sealer. Parent must retain its terminal hash and external completed outer receipt before any release.
5. Separately permit custodian-controlled exact original-truth release and one bounded analysis. It may validate implementation on reused post-failure data, never independent fresh replication, retroactive original PASS, a new cipher hypothesis or K4 admission.

Any failure or uncertain completion preserves evidence/reservation and stops successors. Resource sufficiency is not promised:60+30+45=135<150 is arithmetic only; worker soft 60 CPU, supervisor soft 4/hard 5 hashing and final tails can still prevent completion. No timing instrumentation, additional resource experiment, replacement draw, source-mutated continuation or automatic retries are hidden in this request.

**Present status:** implementation, allocation, mock execution, binder, whole run, sealer and released analysis all unexecuted here. No permission denial or uncertain experimental execution occurred. The parent can grant the exact immediate preparation boundary after reading the independent design verdict; no additional user prompt is needed.
