# Fixed-data operational mock adaptation — source preparation only

The suite has **311 frozen obligations per mode: inherited 266 plus 45 ancestry obligations**. This is a source count, not an execution result. No source import, compilation, test invocation, binder operation, solver/reference call, case replay, instrumentation, seed/truth access or remote edit was performed by the mock adapter author.

## Inherited obligations

All original groups and counts remain: import_safety9, invalid_caps42, blind_schema15, certificate20, parser8, storage9, bounded_capture15, reaping6, launch_caps20, cpu_scalars8, commands11, producer_digest5, approval17, state13, report29, filesystem12, execution19, custody_io5 and truth_boundary3; total266.

Operational mappings only:

- The 9-module guarded import inventory substitutes `bind_ancestry.py` for `generator.py`. The binder's real `main` and bounded launch are poisoned before operational checks. No historical generator is imported.
- The 17 approval obligations use the new ancestry-attestation schema/fields and the unchanged external-completion/resource/predecessor rules, not a generation activation.
- The inherited cooperative wall boundary tests use 60/30/45, matching the sole preflight allowance change; the complete outer CPU/wall limits remain unchanged.
- Report fixtures use the new fixed-data schema and explicit origin-manifest field. The zero-context public schema and literal certificate controls retain historical structural schemas.
- The invalid private-command substitution obligation uses the binder role. No generator role is accepted.
- All 3 analyzer terminal-before-truth checks remain. They pass sanitized origin metadata explicitly to pure custody validation and use only the fixed original input **hash**, while `read_public` returns the disclosed zero-context fixture. The first truth access is intercepted at a nonexistent mock path; invalid terminal cases must never reach it.

## Added ancestry group: exactly 45

| Family | Count | Frozen scope |
|---|---:|---|
| Resource/schedule/namespace invariants | 6 | Uniform60 preflight; exact unchanged outer envelope; whole28 schedule; explicit NEW metadata paths; immutable historical generator/no new generator role/file; distinct generation and re-evaluation freezes |
| Origin commitment | 8 | Exact sanitized metadata accepted;7 bounded schema/commitment/private-field mutations rejected |
| New run binding | 9 | Exact pure binding accepted;8 old-schema/origin/new-freeze/custody/seed/truth/draw mutations rejected |
| New run identity | 7 | Exact identity accepted;5 invalid fields plus derivation of new attestation path from old input.parent rejected |
| Private command roles | 4 | Exact binder/seal/analyze roles accepted; replacement/extra generator role and unknown pin rejected through mocked reads |
| Full new authority graph | 4 | Mocked current custody/origin/attestation/candidate chain accepted; old generation candidate, self-activation and mismatched reuse authority rejected |
| Report origin commitment | 2 | Missing and mismatched origin fields rejected |
| Reuse marker | 5 | Exact public-commitment-only shape; invalid approval pin, malformed origin pin, old public target rejected; exclusive-writer reuse rejected on already-existing disclosed scratch file |
| **Total** | **45** | No actual authority marker or approval created |

The origin manifest is read only as a fixed, sanitized source dependency. The suite never calls `verify_origin_metadata`, which is the future binder's original-artifact hashing path, and never reads original public input values. All authority-graph/private-command reads are intercepted in memory and assert the exact allowed NEW metadata paths. No additional scratch file is introduced: only the inherited literal-public-schema and duplicate-JSON files remain.

The source still requires the exact count dictionary embedded in both frozen mock jobs, all prohibitive RNG/process/import guards, and only one prescribed invocation per mode. Parent ownership and independent final freeze approval are required before either invocation. Normal failure or uncertain completion stops optimized; no retry or third invocation is authorized.
