"""One blind fixed-model slot. Source-only until independent freeze and approvals.

No truth path, seed, generator or post-fit eligibility reaches this worker.
"""
import argparse
import copy
import ctypes
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys
import time

ROOT=Path('/workspace/shared/residual-fixed-data-reevaluation-v1')
ENGINE=Path('/workspace/shared/canonical-residual-dev/residual_decoder.py')
AFFINE=ENGINE.with_name('affine_filter.py')
REFERENCE=Path('/workspace/shared/canonical-residual-reference-v3/reference_v3.py')
ENGINE_PIN='be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67'
AFFINE_PIN='1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d'
REFERENCE_PIN='0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9'
MIB=1024*1024
REPORT_MAX=2*MIB
HASH_MAX=64*MIB
REPORT_SCHEMA='fixed-data-post-failure-slot-report-v1'
SOURCE_PATHS=(ENGINE,AFFINE,REFERENCE,ROOT/'preflight_blind.py',ROOT/'checker_blind.py')


def require(condition,message):
    if not condition: raise ValueError(message)


def sha(path,limit=MIB):
    path=Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size<=limit,'bounded hash input')
    h=hashlib.sha256()
    total=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(min(MIB,limit+1)),b''):
            require(len(block)<=limit-total,'hash input grew past cap')
            total+=len(block);h.update(block)
    return h.hexdigest()


def unique(pairs):
    out={}
    for key,value in pairs:
        require(key not in out,'duplicate JSON key');out[key]=value
    return out


def read_json(path,limit):
    path=Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size<=limit,'bounded regular JSON file')
    with path.open('rb') as f:raw=f.read(limit+1)
    require(len(raw)<=limit,'JSON grew beyond cap')
    return json.loads(raw,object_pairs_hook=unique,
        parse_constant=lambda _s:(_ for _ in ()).throw(ValueError('nonfinite JSON')))


def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def expanded_command(template,input_pin):
    require(type(input_pin) is str and len(input_pin)==64 and all(c in '0123456789abcdef' for c in input_pin),
            'exact input digest')
    require(type(template) is list and all(type(part) is str and 0<len(part)<=4096 for part in template),
            'command template strings')
    require(template.count('${INPUT_PIN}')==1,'one whole-token input substitution')
    for part in template:
        require('${' not in part or part=='${INPUT_PIN}','only whole-token input substitution')
    return [input_pin if part=='${INPUT_PIN}' else part for part in template]


def load(name,path,pin):
    path=Path(path)
    require(path.is_file() and not path.is_symlink() and sha(path)==pin,'pinned isolated module: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def require_worker_bounds():
    require(resource.getrlimit(resource.RLIMIT_CPU)==(60,75),'worker CPU wrapper')
    require(resource.getrlimit(resource.RLIMIT_AS)==(1024*MIB,1024*MIB),'worker address-space wrapper')
    guard=ctypes.c_int()
    require(ctypes.CDLL(None).prctl(2,ctypes.byref(guard),0,0,0)==0 and guard.value==signal.SIGKILL,
            'parent-death guard required')


def normalized_producer(result):
    """Only these two typed path rules remove time; every logical counter remains."""
    require(type(result) is dict and result.get('status')=='EXACT','complete producer required')
    out=dict(result)
    require(type(result.get('resources')) is dict and 'wall_seconds' in result['resources'],'root time field')
    out['resources']={k:v for k,v in result['resources'].items() if k!='wall_seconds'}
    require(type(result.get('pieces')) is list,'complete pieces')
    pieces=[]
    for piece in result['pieces']:
        p=dict(piece);core=dict(piece['core'])
        require(type(core.get('resources')) is dict and 'wall_seconds' in core['resources'],'piece time field')
        core['resources']={k:v for k,v in core['resources'].items() if k!='wall_seconds'}
        p['core']=core;pieces.append(p)
    out['pieces']=pieces
    return out


def producer_digest(result):
    # Stream the full representation, not masks/counts; never retain a second
    # unbounded JSON string or write a semantic relation to disk.
    h=hashlib.sha256();total=0
    encoder=json.JSONEncoder(sort_keys=True,separators=(',',':'),allow_nan=False)
    for token in encoder.iterencode(normalized_producer(result)):
        data=token.encode('utf8')
        require(len(data)<=HASH_MAX-total,'semantic digest serialization cap')
        total+=len(data);h.update(data)
    require(total<HASH_MAX,'semantic digest newline cap');h.update(b'\n')
    return h.hexdigest()


def write_report(path,report):
    data=canonical(report)
    require(len(data)<=REPORT_MAX,'report byte cap')
    with Path(path).open('xb') as f:
        require(f.write(data)==len(data),'short report write');f.flush();os.fsync(f.fileno())
    fd=os.open(Path(path).parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)


def literal_control(case_id):
    require(case_id in ('G0','G1'),'literal gate id')
    return dict(id=case_id,contexts=[[0]*6],observed=[] if case_id=='G0' else [[0,0]],
                sparsity=3,allowed_features=list(range(31)))


def main():
    parser=argparse.ArgumentParser()
    for flag in ('job','input','input-sha256','output'):parser.add_argument('--'+flag,required=True)
    args=parser.parse_args()
    require_worker_bounds()
    freeze_path=ROOT/'FREEZE.json';freeze=read_json(freeze_path,MIB);freeze_pin=sha(freeze_path)
    require(freeze.get('schema')=='fixed-data-post-failure-reevaluation-v1-freeze','freeze schema')
    files=freeze.get('files')
    require(type(files) is dict and all(type(p) is str and type(v) is str for p,v in files.items()),'source manifest')
    for path,pin in files.items():
        candidate=Path(path)
        require(candidate.is_absolute() and candidate.is_file() and not candidate.is_symlink() and sha(candidate)==pin,'frozen source changed')
    require(files.get(str(ENGINE))==ENGINE_PIN and files.get(str(AFFINE))==AFFINE_PIN
            and files.get(str(REFERENCE))==REFERENCE_PIN,'immutable scientific pins')
    require(str(Path(__file__).resolve()) in files,'worker frozen')
    spec=freeze['jobs'].get(args.job);require(type(spec) is dict,'scheduled worker only')
    expected=expanded_command(spec['command'],args.input_sha256)
    actual=[str(Path(sys.executable).resolve()),'-I','-B']+(['-O'] if sys.flags.optimize else [])+[str(Path(__file__).resolve())]+sys.argv[1:]
    require(actual==expected,'exact frozen worker command')
    require(spec['report_identity']['python_optimized'] is bool(sys.flags.optimize),'worker mode')
    common=load('fresh_custody_common',ROOT/'custody_common.py',files[str(ROOT/'custody_common.py')])
    common.verify_freeze(freeze_path,freeze_pin)
    public=common.read_public(args.input,args.input_sha256)
    run_path=Path(freeze['public_paths']['run_approval'])
    run=read_json(run_path,65536)
    require(type(run) is dict and set(run)==common.RUN_APPROVAL_KEYS,'exact public run approval')
    custody_path=Path(freeze['public_paths']['custody'])
    custody=common.read_json(custody_path,65536,run['custody_sha256'])
    common.validate_custody(custody,freeze,freeze_pin,args.input_sha256)
    common.validate_run_approval(run,freeze,freeze_pin,args.input_sha256,run['custody_sha256'])
    require(run['draw_approval_sha256']==custody['draw_approval_sha256'],'one-draw custody binding')
    require(run['public_input_path']==str(Path(args.input).resolve()),'public input path')
    case_id=spec['report_identity']['case_id'];output=Path(args.output)
    require(output==ROOT/'runs'/args.job/'result.json','fixed report path')
    require(type(case_id) is str,'case id')
    if case_id in ('G0','G1'):control=literal_control(case_id)
    else:
        matches=[c for c in public['cases'] if c['id']==case_id]
        require(len(matches)==1,'exact public case')
        control=dict(matches[0]['instance'],id=case_id)
    report=dict(schema=REPORT_SCHEMA,slot=args.job,case_id=case_id,python_optimized=bool(sys.flags.optimize),
        origin_manifest_sha256=freeze['origin_manifest_sha256'],
        freeze_sha256=freeze_pin,input_sha256=args.input_sha256,source_sha256=files,
        status='INCOMPLETE_OR_FAILED',preflight=None,producer=None,verification=None,
        semantic_summary=None,resources=None,reason=None)
    wall_start=time.monotonic();cpu_start=time.process_time()
    producer_counters=None;reference_counters=None
    producer_attempted=False;reference_attempted=False
    try:
        reference=load('fresh_reference_v3',REFERENCE,REFERENCE_PIN)
        preflight=load('fresh_preflight_blind',ROOT/'preflight_blind.py',files[str(ROOT/'preflight_blind.py')])
        checker=load('fresh_checker_blind',ROOT/'checker_blind.py',files[str(ROOT/'checker_blind.py')])
        evidence=preflight.EvidenceBudget()
        pf=preflight.run(control,output.parent/'case.cert.jsonl',args.input_sha256,REFERENCE_PIN,
                         freeze_pin,reference,checker,evidence)
        report['preflight']=pf
        if pf['status']=='GATE_REJECTED_LOWER_BOUND':
            require(pf['certificate']['complete'] and pf['exact_W'] is None
                    and type(pf['lower_bound']) is int and pf['lower_bound']>1000000,'complete resource gate')
            report['status']='CERTIFIED_RESOURCE_GATE'
        else:
            require(case_id not in ('G0','G1'),'predetermined resource control failed to gate')
            require(pf['status']=='WORKLOAD_ADMITTED' and pf['checked_supports']==4495
                    and type(pf['exact_W']) is int and 0<=pf['exact_W']<=1000000
                    and pf['certificate']['complete'],'precheck incomplete')
            load('affine_filter',AFFINE,AFFINE_PIN)
            engine=load('fresh_residual_decoder',ENGINE,ENGINE_PIN)
            observed=dict(control['observed'])
            producer_attempted=True
            result=engine.decode(control['contexts'],observed,3,list(range(31)),
                budget=engine.Budget(max_steps=2000000,max_pieces=40000,max_core_work=200000000,
                    max_core_solves=1000000,max_core_terms=100000,max_seconds=30.0))
            report['producer']={k:result[k] for k in ('status','resources','stats')}
            producer_counters={k:v for k,v in result['resources'].items() if k!='wall_seconds'}
            require(result['status']=='EXACT','supported producer not EXACT')
            budget=reference.BudgetV3(max_fiber_points=1000000,max_lift_trials=4000000,
                max_solve_calls=100000,max_certificate_checks=200000,max_row_operations=5000000,
                max_work_units=500000000,max_witness_checks=1000000,max_output_records=5000000,max_seconds=45.0)
            reference_attempted=True
            verified=reference.verify_result_v3(control['contexts'],observed,result,3,list(range(31)),
                budget=budget,expected_source_sha256=ENGINE_PIN)
            report['verification']=verified
            reference_counters={k:v for k,v in verified['resources'].items() if k!='wall_seconds'}
            require(verified['status']=='VERIFIED_EXACT' and verified['resources']['fiber_points']==pf['exact_W'],
                    'complete independent verification required')
            report['semantic_summary']=dict(producer_nontime_sha256=producer_digest(result),masks=result['masks'],
                pieces=verified['pieces_checked'],canonical_functions=verified['canonical_functions'],
                original_lifts=verified['original_lifts'],joint_predictions=verified['joint_predictions'],
                feasibility_witness=result['feasibility_witness'])
            report['status']='VERIFIED_EXACT'
        for path,pin in files.items():require(sha(path)==pin,'post-run source changed')
        require(sha(args.input,262144)==args.input_sha256,'post-run public input changed')
    except BaseException as error:
        report['status']='INCOMPLETE_OR_FAILED';report['semantic_summary']=None
        report['producer']=None;report['verification']=None
        report['reason']=type(error).__name__+': '+str(error)[:500]
    report['resources']=dict(worker_wall_seconds=time.monotonic()-wall_start,
                             worker_cpu_seconds=time.process_time()-cpu_start,
                             producer_counters=producer_counters,reference_counters=reference_counters,
                             producer_attempted=producer_attempted,reference_attempted=reference_attempted)
    write_report(output,report)
    return 0 if report['status'] in ('VERIFIED_EXACT','CERTIFIED_RESOURCE_GATE') else 1

if __name__=='__main__':sys.exit(main())
