"""Custodian pre-truth seal. Never opens seed or truth files."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/shared/residual-fixed-data-reevaluation-v1')


def load_common(manifest, expected):
    path = Path(manifest)
    if str(path) != str(ROOT / 'FREEZE.json') or path.is_symlink() or path.stat().st_size > 2097152:
        raise ValueError('bounded fixed freeze required')
    raw = path.read_bytes()
    if len(raw) > 2097152 or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('freeze hash')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate freeze key')
            result[key] = value
        return result
    freeze = json.loads(raw, object_pairs_hook=unique,
                        parse_constant=lambda _x: (_ for _ in ()).throw(ValueError('nonfinite freeze')))
    source = ROOT / 'custody_common.py'
    if source.is_symlink() or source.stat().st_size > 1048576:
        raise ValueError('bounded helper source required')
    if hashlib.sha256(source.read_bytes()).hexdigest() != freeze['files'][str(source)]:
        raise ValueError('helper source pin')
    spec = importlib.util.spec_from_file_location('fresh_v2_custody_common', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def make_terminal(snapshot, custody):
    return {'schema':'fixed-data-post-failure-terminal-seal-v1', 'snapshot':snapshot,
            'origin_manifest_sha256':custody['origin_manifest_sha256'],
            'generation_origin_freeze_sha256':custody['generation_origin_freeze_sha256'],
            'truth_sha256':custody['truth_sha256'],
            'analysis_manifest_sha256':custody['analysis_manifest_sha256'],
            'private_commands_sha256':custody['private_commands_sha256']}


def main():
    parser = argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','results',
                 'custody','custody-sha256','receipts-manifest','receipts-manifest-sha256',
                 'private-commands','private-commands-sha256','out'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    common = load_common(args.manifest, args.manifest_sha256)
    common.require_bounds(5, 512)
    freeze = common.verify_freeze(args.manifest, args.manifest_sha256)
    common.require(args.input == freeze['public_paths']['input']
                   and args.custody == freeze['public_paths']['custody']
                   and args.results == freeze['public_paths']['results'], 'fixed public bindings')
    common.read_public(args.input, args.input_sha256)
    custody = common.read_json(args.custody, pin=args.custody_sha256)
    common.validate_custody(custody, freeze, args.manifest_sha256, args.input_sha256)
    common.require(args.private_commands_sha256 == custody['private_commands_sha256'], 'private command commitment')
    commands = common.read_private_commands(args.private_commands, args.private_commands_sha256)
    common.bind_private_command(commands, 'seal_results',
        {'FREEZE_PIN':args.manifest_sha256, 'INPUT_PIN':args.input_sha256,
         'CUSTODY_PIN':args.custody_sha256, 'PRIVATE_COMMANDS_PIN':args.private_commands_sha256,
         'RECEIPTS_PIN':args.receipts_manifest_sha256}, sys.argv[1:])
    supervisor = common.load_pinned('fresh_v2_seal_supervisor', ROOT / 'supervisor.py', freeze)
    snapshot = supervisor.snapshot_terminal(args.results, args.input, args.input_sha256,
        args.manifest, args.manifest_sha256, args.custody, args.custody_sha256,
        args.receipts_manifest, args.receipts_manifest_sha256)
    output = common.canonical_path(args.out, False)
    results = Path(args.results)
    common.require(output != results and results not in output.parents, 'terminal seal outside results inventory')
    common.verify_freeze(args.manifest, args.manifest_sha256)
    common.write_new(output, make_terminal(snapshot, custody))
    print(json.dumps({'terminal_manifest_sha256':common.sha(output),
                      'status':'TERMINAL_INVENTORY_SEALED_NOT_SCIENTIFIC_PASS',
                      'next':'Parent must externally retain this hash and bounded seal receipt before truth release.'}))


if __name__ == '__main__':
    main()
