# Exact source delta and preparation boundary

Parent authorization: 2026-11-01 00:17:56 UTC, after bounded independent DESIGN PASS. NEW 3,000 nominal CPU seconds reserved, project allocation 23,200/28,800, remaining 5,600; new-stage disk ceiling 1.25 GiB. The preserved proposal/request remain design history; PREPARATION-AUTHORITY.json and RESOURCE-ALLOCATION.json state the subsequent narrow grant. No original reserve is reused. Real binder, cohort, sealer and truth/seed release/analysis remain unauthorized.

## Scientific invariants

- `checker_blind.py` is byte-identical to original SHA `065e3c29d2705c706b44a553bd9013b10c84751251145a4a683b940962ecc5c6`.
- `preflight_blind.py` has exactly one changed literal: `Caps.max_seconds` default `20.0` to `60.0`. Historical evidence/role schema identifiers remain structural versions; no other byte changes.
- Producer, affine helper, independent reference and historical generator remain at original absolute paths and hashes. There is no new generator.py and no permitted generator CLI role.
- Worker mathematical call order/arguments, all logical budgets, full-relation comparison/digest semantics, dictionary/support/beta ordering and accepted coverage mathematics are unchanged. `supervisor.validate_preflight` completion wall acceptance changes 20 to 60; producer/reference acceptance stays 30/45.
- `analyze_truth`, truth validation, residual/feature algebra and twin/coverage logic remain unchanged. The main wrapper adds fixed-data post-failure interpretation/status and explicit origin fields after analysis; it loads the unchanged original generator only after authenticating the new external terminal and accessing authorized committed truth.

## Operational adaptations

Root/run/report/approval/terminal schemas distinguish the new fixed-data post-failure execution. Original public input stays at its exact original path/hash. All new approval/candidate/attestation paths are independently fixed under the NEW public root, never derived from input.parent. Reports, run binding and terminal link the exact origin manifest; the new freeze carries both its own execution identity and the original generation-freeze digest.

`custody_common.py` retains the canonical bounded JSON/I/O and public-input validators and adds an exact independently supplied origin commitment. The whole canonical origin SHA authenticates every nested metadata field; it is not a new draw or execution approval. A new run binding retains original seed/truth/draw commitments while separately binding new source/analysis/resource/private commands and one-use reuse approval. New active run validation requires explicit new custody, origin, externally acknowledged ancestry attestation and pending candidate, in that order. Private roles are bind_ancestry/seal_results/analyze only. The historical generator path is an explicit analysis dependency.

`bind_ancestry.py` reuses the isolated source loader by source text and performs only bounded read-only origin/source/input/failure preservation hashing, then writes a new exclusive reuse marker, new public run binding and pending candidate. Original certificate bytes may be hashed against the custodian's sealed 42-file inventory, never parsed, copied or replayed. It checks original metadata and exact tree before and after binding. No entropy, generator, solver or secret-file operation exists in this module. It cannot issue active run approval or attest its own outer completion.

`bounded_stage.py` changes only operational schema/freeze/dependency allowlists and replaces generator with ancestry-binder as an allowed generic stage role. Collector, process limits, chunks, predebits, PID/death chain, alarm/disarm/reaping, wall deadline, accounting and exclusive one-use mechanics are unchanged. Supervisor changes are namespace/identity/ancestry binding and the single preflight completion constant; all outer limits, inventory/reservations and pair-exclusion rules remain unchanged.

Exactly 311 operational mock obligations per mode are frozen: inherited 266 mapped plus 45 finite ancestry/path/resource boundaries. MOCK-ADAPTATION.md supplies the group mapping. Only literal/schema/stub fixtures and sanitized public origin metadata are used, never original case values or truth. The first truth boundary is intercepted. Import/RNG/process guards precede new module imports; no real binder or solver runs inside mocks.

## Inventory and execution gate

Final freeze includes exact source/schema/caps/resource/origin/analysis/interpreter pins, the complete fixed 28-worker schedule, two outer mock commands and their exact count dictionaries. Prospective private binder/sealer/analyzer command templates are separately custodian-owned; their exact private instantiation is not a public-source field and grants no execution authority. PRE-MOCK-APPROVAL.json may be issued only by the independent reviewer after exact final-freeze acceptance under the parent's conditional grant.

Two mock slots only, normal then optimized, each 30/31 CPU per process, 512 MiB per process and 120 seconds supervised wall. No third invocation/retry or source change after mocks. A failure/uncertain completion retains evidence/reserve and prevents successors. Source/mock PASS is operational preparation only, not decoder validation, representative throughput, a new independent fresh replication or K4 admission.

During preparation only source-text writing, static AST parsing/schema extraction, comparisons, hashing and metadata accounting occurred. AST parsing does not import or execute target modules or expand data. Preparation CPU remains unmeasured in the 200-second overhead allowance. Exact monitored mock receipts, if later permitted and completed, are accounted separately without adding phase timers twice.
