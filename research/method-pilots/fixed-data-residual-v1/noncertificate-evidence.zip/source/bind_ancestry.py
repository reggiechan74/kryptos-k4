"""One ancestry-only binding. No entropy, generator, solver, seed or truth I/O."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/shared/residual-fixed-data-reevaluation-v1')


def load_common(manifest, expected):
    path = Path(manifest)
    if str(path) != str(ROOT / 'FREEZE.json') or path.is_symlink() or path.stat().st_size > 2097152:
        raise ValueError('bounded fixed freeze required')
    raw = path.read_bytes()
    if len(raw) > 2097152 or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('freeze hash')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate freeze key')
            result[key] = value
        return result
    freeze = json.loads(raw, object_pairs_hook=unique,
                        parse_constant=lambda _x: (_ for _ in ()).throw(ValueError('nonfinite freeze')))
    source = ROOT / 'custody_common.py'
    if source.is_symlink() or source.stat().st_size > 1048576:
        raise ValueError('bounded helper source required')
    if hashlib.sha256(source.read_bytes()).hexdigest() != freeze['files'][str(source)]:
        raise ValueError('helper source pin')
    spec = importlib.util.spec_from_file_location('fresh_v2_custody_common', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def make_use_marker(approval_pin,freeze_pin,origin_pin,public_dir):
    """Pure marker value; the sole actual write is exclusive and durable."""
    for value in (approval_pin,freeze_pin,origin_pin):
        if type(value) is not str or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('exact marker digest')
    expected='/workspace/shared/residual-fixed-data-reevaluation-v1-public'
    if type(public_dir) is not str or public_dir!=expected:
        raise ValueError('only NEW public binding destination')
    return {'schema':'fixed-data-post-failure-reuse-use-v1',
        'reuse_approval_sha256':approval_pin,'freeze_sha256':freeze_pin,
        'origin_manifest_sha256':origin_pin,'public_dir':public_dir}


def main():
    parser=argparse.ArgumentParser()
    for name in ('approval','approval-sha256','manifest','manifest-sha256','public-dir'):
        parser.add_argument('--'+name,required=True)
    args=parser.parse_args()
    common=load_common(args.manifest,args.manifest_sha256)
    common.require_bounds(30,512)
    freeze=common.verify_freeze(args.manifest,args.manifest_sha256)
    approval=common.read_json(args.approval,65536,args.approval_sha256)
    public_dir=common.canonical_path(args.public_dir,False)
    common.validate_reuse_approval(approval,freeze,args.manifest_sha256,public_dir)
    common.require(public_dir.is_dir() and not public_dir.is_symlink()
        and {p.name for p in public_dir.iterdir()}=={'ORIGIN-MANIFEST.json','ORIGIN-RUN-INVENTORY.json'},
        'NEW public root contains only two immutable origin artifacts before binding')
    expected_jobs=tuple(case+'-'+mode for case in ('G0','G1')+tuple('v%03d'%i for i in range(12))
                        for mode in ('normal','optimized'))
    common.require(tuple(freeze['jobs'])==expected_jobs,'one whole fixed28 schedule')
    commands=common.read_private_commands(approval['private_commands_path'],approval['private_commands_sha256'])
    common.bind_private_command(commands,'bind_ancestry',
        {'REUSE_APPROVAL_PIN':args.approval_sha256,'FREEZE_PIN':args.manifest_sha256},sys.argv[1:])
    origin=common.read_origin(freeze)
    common.verify_origin_metadata(origin)
    # Only the NEW reuse approval is consumed. No original marker is opened for
    # writing and there is no seed acquisition, generator or data expansion.
    marker=Path(args.approval).with_name(Path(args.approval).name+'.used.json')
    common.write_new(marker,make_use_marker(args.approval_sha256,args.manifest_sha256,
        common.ORIGIN_PIN,str(public_dir)),65536)
    custody=common.make_custody(origin,freeze,args.manifest_sha256,
        args.approval_sha256,approval['private_commands_sha256'])
    common.validate_custody(custody,freeze,args.manifest_sha256,common.ORIGINAL_INPUT_PIN,origin)
    common.write_new(freeze['public_paths']['custody'],custody,65536)
    custody_pin=common.sha(freeze['public_paths']['custody'],65536)
    candidate=common.candidate_approval(custody,custody_pin,freeze,args.manifest_sha256)
    common.verify_freeze(args.manifest,args.manifest_sha256)
    common.verify_origin_metadata(origin)
    common.write_new(freeze['public_paths']['approval_candidate'],candidate,65536)
    # This child cannot authenticate its own future outer receipt/tool exit.
    # No active run approval/attestation is emitted; parent activation is separate.
    print(json.dumps({'status':'BOUND_EXISTING_FIXED_DATA',
        'origin_manifest_sha256':common.ORIGIN_PIN,'input_sha256':common.ORIGINAL_INPUT_PIN,
        'custody_sha256':custody_pin,'activation':'PENDING_ANCESTRY_RECEIPT; no active approval emitted'}))


if __name__=='__main__':
    main()
