"""Bounded two-process launcher; source-only until independently frozen.

Derived from audited bounded_checked.py and the full31 supervisor. No module
import launches, consumes approval, creates files or reads experiment input.
CLI: receipt cpu_soft memory_MiB wall_seconds stdout_path stderr_path command...
"""
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import selectors
import signal
import sys
import time

MIB = 1024 * 1024
LOG_MAX = MIB
JSON_MAX = 2 * MIB
CHUNK = 16384
VERSION = 'fixed-data-post-failure-bounded-stage-v1'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def numeric(value):
    return ((type(value) is int and value >= 0) or
            (type(value) is float and math.isfinite(value) and value >= 0))


def integer(value, maximum=None):
    return type(value) is int and value >= 0 and (maximum is None or value <= maximum)


def digest_string(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def read_json(path, limit=JSON_MAX):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular JSON file required')
    require(path.stat().st_size <= limit, 'JSON file byte limit')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    require(len(data) <= limit, 'JSON file grew beyond byte limit')
    return json.loads(data, object_pairs_hook=unique_object,
        parse_constant=lambda _x: (_ for _ in ()).throw(ValueError('nonfinite JSON number')))


def sha(path, limit=None):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular hash input required')
    size = path.stat().st_size
    if limit is not None:
        require(size <= limit, 'hash input byte limit')
    digest = hashlib.sha256()
    total = 0
    with path.open('rb') as handle:
        while True:
            data = handle.read(MIB)
            if not data:
                break
            total += len(data)
            if limit is not None:
                require(total <= limit, 'hash input grew beyond limit')
            digest.update(data)
    require(total == size, 'hash input size changed')
    return digest.hexdigest()


def fsync_dir(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(path, value):
    path = Path(path)
    data = canonical(value)
    require(len(data) <= JSON_MAX, 'JSON output byte limit')
    with path.open('xb') as handle:
        require(handle.write(data) == len(data), 'short JSON write')
        handle.flush()
        os.fsync(handle.fileno())
    fsync_dir(path.parent)


def atomic(path, value):
    """Only fixed state/resource JSON uses .tmp; partial bytes are preserved."""
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    data = canonical(value)
    require(len(data) <= JSON_MAX, 'JSON output byte limit')
    with temporary.open('xb') as handle:
        require(handle.write(data) == len(data), 'short JSON write')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    fsync_dir(path.parent)


def death_guard(expected=None):
    parent = os.getppid() if expected is None else expected
    require(type(parent) is int and parent >= 1, 'expected positive parent PID')
    if os.getppid() != parent:
        os.kill(os.getpid(), signal.SIGKILL)
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'PR_SET_PDEATHSIG')
    if os.getppid() != parent:
        os.kill(os.getpid(), signal.SIGKILL)


def check_limits(limits):
    keys = {'worker_cpu_soft', 'worker_cpu_hard', 'supervisor_cpu_soft',
            'supervisor_cpu_hard', 'worker_address_space_bytes',
            'supervisor_address_space_bytes', 'wall_seconds', 'log_max_bytes'}
    require(type(limits) is dict and set(limits) == keys, 'exact launch limit schema')
    require(all(integer(value) and value > 0 for value in limits.values()), 'positive integer launch caps')
    require(limits['worker_cpu_soft'] <= limits['worker_cpu_hard'], 'worker CPU ordering')
    require(limits['supervisor_cpu_soft'] <= limits['supervisor_cpu_hard'], 'supervisor CPU ordering')
    require(limits['log_max_bytes'] == LOG_MAX, 'fixed one-MiB log cap')


def reserve_log_bytes(used, amount, maximum=LOG_MAX):
    require(integer(used, maximum) and integer(amount) and integer(maximum), 'log counter types')
    if amount > maximum - used:
        return None
    return used + amount


class BoundedCapture:
    """Actual collector debit/write policy; injected callbacks enable no-child mocks."""
    def __init__(self, write_callback, kill_callback, maximum=LOG_MAX):
        require(integer(maximum, LOG_MAX) and maximum > 0, 'bounded capture limit')
        require(callable(write_callback) and callable(kill_callback), 'capture callbacks')
        self.maximum, self.write_callback, self.kill_callback = maximum, write_callback, kill_callback
        self.written, self.read_bytes = [0,0], [0,0]
        self.overflow = False

    def feed(self, index, data):
        require(type(index) is int and index in (0,1), 'capture stream index')
        require(type(data) is bytes and 0 < len(data) <= CHUNK, 'bounded nonempty pipe chunk')
        self.read_bytes[index] += len(data)
        if self.overflow:
            return False
        following = reserve_log_bytes(self.written[index],len(data),self.maximum)
        if following is None:
            self.overflow = True
            self.kill_callback()
            return False
        self.written[index] = following
        require(self.write_callback(index,data) == len(data), 'short log write')
        return True


def reap_after_disarm(wait_ready, disarm, release_pid_guard, wait_usage):
    """Ordered unreaped exit -> alarm disarm -> guard release -> wait4.

    Callbacks are real OS operations in run_bounded and no-child stubs in mocks.
    An interrupted wait is the only retried operation; no child is relaunched.
    """
    for callback in (wait_ready,disarm,release_pid_guard,wait_usage):
        require(callable(callback), 'reaping callback')
    while True:
        try:
            wait_ready()
            break
        except InterruptedError:
            continue
    disarm()
    release_pid_guard()
    return wait_usage()


def expand_freeze_tokens(command, freeze_pin):
    require(digest_string(freeze_pin), 'mock freeze pin')
    require(type(command) is list and 1 <= len(command) <= 80
        and all(type(token) is str and len(token) <= 4096 for token in command), 'mock command template')
    require(all('${' not in token or token == '${FREEZE_PIN}' for token in command), 'only whole freeze-pin substitution')
    return [freeze_pin if token == '${FREEZE_PIN}' else token for token in command]


def mock_limits():
    return dict(worker_cpu_soft=30,worker_cpu_hard=31,
        supervisor_cpu_soft=30,supervisor_cpu_hard=31,
        worker_address_space_bytes=512*MIB,supervisor_address_space_bytes=512*MIB,
        wall_seconds=120,log_max_bytes=LOG_MAX)


def validate_mock_spec(freeze, freeze_pin, mode, args, command, root):
    """Pure exact argv/path gate, exercised by no-child source mocks."""
    root=Path(root)
    require(mode in ('normal','optimized') and type(freeze) is dict, 'mock mode/freeze')
    require(type(freeze.get('mock_jobs')) is dict
        and list(freeze['mock_jobs']) == ['normal','optimized'], 'exact two ordered mock slots')
    spec=freeze['mock_jobs'][mode]
    require(type(spec) is dict and set(spec)=={'launch_command','receipt','stdout','stderr',
        'output','cwd','script','command','expected_counts'}, 'exact mock job schema')
    directory=root/'mocks'/mode
    for name,basename in (('receipt','resource.json'),('stdout','stdout.txt'),
                          ('stderr','stderr.txt'),('output','result.json')):
        require(spec[name]==str(directory/basename), 'fixed mock '+name+' path')
    require(spec['cwd']==str(root) and spec['script']==str(root/'protocol_mock_tests.py'), 'fixed mock source/cwd')
    python=freeze.get('python')
    require(type(python) is dict and set(python)=={'executable','sha256','version'}, 'mock interpreter schema')
    expected=[python['executable'],'-I','-B']+(['-O'] if mode=='optimized' else [])+[
        spec['script'],'--freeze-sha256','${FREEZE_PIN}','--output',spec['output']]
    require(spec['command']==expected, 'fixed mock command template')
    expected_launch=[python['executable'],'-I','-B',str(root/'bounded_stage.py'),
        spec['receipt'],'30','512','120',spec['stdout'],spec['stderr']]+expected
    require(spec['launch_command']==expected_launch, 'fixed mock launcher template')
    require(command==expand_freeze_tokens(expected,freeze_pin), 'exact approved mock child argv')
    actual_launch=[str(Path(sys.executable).resolve()),'-I','-B',str(root/'bounded_stage.py')]+list(args)
    require(actual_launch==expand_freeze_tokens(expected_launch,freeze_pin), 'exact approved mock launcher argv')
    require(type(spec['expected_counts']) is dict and bool(spec['expected_counts'])
        and all(type(key) is str and integer(value) for key,value in spec['expected_counts'].items()), 'frozen exact mock counts')
    return spec


def validate_mock_report(report,spec,mode,freeze_pin):
    require(mode in ('normal','optimized'), 'fixed mock report mode')
    require(type(report) is dict and set(report)=={'schema','mode','freeze_sha256','status',
        'counts','resources','failure','scope'}, 'exact mock result schema')
    require(report['schema']=='fixed-data-post-failure-mock-report-v1' and report['mode']==mode
        and report['freeze_sha256']==freeze_pin and report['status']=='PASS'
        and report['failure'] is None, 'completed frozen mock result')
    require(type(report['counts']) is dict and set(report['counts'])==set(spec['expected_counts'])
        and all(integer(value) for value in report['counts'].values())
        and report['counts']==spec['expected_counts'], 'exact completed mock counts')
    resources=report['resources']
    zero_fields={'actual_inner_children','real_solver_calls','seed_draws','generator_expansions','truth_bytes_read'}
    require(type(resources) is dict and set(resources)==zero_fields|{'worker_cpu_seconds','worker_wall_seconds'}, 'mock resource schema')
    require(all(type(resources[name]) is int and resources[name]==0 for name in zero_fields), 'no forbidden mock work')
    require(numeric(resources['worker_cpu_seconds']) and resources['worker_cpu_seconds']<=31
        and numeric(resources['worker_wall_seconds']) and resources['worker_wall_seconds']<=120, 'mock reported limits')
    require(report['scope']=='fixed disclosed operational mocks; zero seed/case draws, real solvers, actual inner child launches or truth reads', 'mock scope identity')
    return True


def validate_mock_receipt(receipt,spec,mode,freeze_pin,approval_pin):
    require(mode in ('normal','optimized') and Path(spec['receipt']).parent.name==mode,
        'fixed mock receipt mode')
    execution_keys={'schema','command','cwd','limits','supervisor_pid','child_pid','child_reaped',
        'parent_death_guard','exit_code','wall_timeout','log_overflow','collector_error','wall_seconds',
        'child_user_cpu_seconds','child_system_cpu_seconds','child_cpu_seconds','supervisor_exclusive_cpu_sample',
        'supervisor_cpu_allocation_charged','supervisor_final_write_tail_measured',
        'child_peak_rss_kib','supervisor_peak_rss_kib','log_bytes_reserved','log_bytes_read','logs','failures'}
    require(type(receipt) is dict and set(receipt)==execution_keys|{'status','one_use_marker_sha256','mock_completion'}, 'exact mock resource receipt')
    require(receipt['schema']==VERSION and receipt['status']=='COMPLETED'
        and receipt['command']==expand_freeze_tokens(spec['command'],freeze_pin)
        and receipt['cwd']==spec['cwd'] and receipt['limits']==mock_limits(), 'mock receipt invocation/limits')
    require(type(receipt['exit_code']) is int and receipt['exit_code']==0
        and receipt['child_reaped'] is True and receipt['parent_death_guard'] is True
        and receipt['wall_timeout'] is False and receipt['log_overflow'] is False
        and receipt['collector_error'] is None and receipt['failures']==[], 'mock receipt completed without failure')
    require(numeric(receipt['wall_seconds']) and receipt['wall_seconds']<=120, 'mock receipt wall')
    for key in ('child_user_cpu_seconds','child_system_cpu_seconds','child_cpu_seconds','supervisor_exclusive_cpu_sample'):
        require(numeric(receipt[key]), 'finite mock CPU component')
    require(abs(receipt['child_user_cpu_seconds']+receipt['child_system_cpu_seconds']-receipt['child_cpu_seconds'])<=1e-8
        and receipt['child_cpu_seconds']<=31 and receipt['supervisor_exclusive_cpu_sample']<=31, 'mock CPU allowance')
    require(type(receipt['supervisor_cpu_allocation_charged']) is int
        and receipt['supervisor_cpu_allocation_charged']==31
        and receipt['supervisor_final_write_tail_measured'] is False, 'mock supervisor charge/tail')
    require(all(type(receipt[name]) is int and receipt[name]>=1 for name in ('supervisor_pid','child_pid'))
        and receipt['supervisor_pid']!=receipt['child_pid'], 'mock process identity')
    require(all(integer(receipt[name]) for name in ('child_peak_rss_kib','supervisor_peak_rss_kib')), 'mock RSS')
    for key in ('log_bytes_reserved','log_bytes_read'):
        require(type(receipt[key]) is list and len(receipt[key])==2
            and all(integer(value,LOG_MAX) for value in receipt[key]), 'mock bounded log counts')
    require(receipt['log_bytes_reserved']==receipt['log_bytes_read'], 'mock complete log capture')
    require(type(receipt['logs']) is list and len(receipt['logs'])==2, 'two mock log records')
    for index,name in enumerate(('stdout','stderr')):
        item=receipt['logs'][index]
        require(type(item) is dict and set(item)=={'path','bytes','sha256'} and item['path']==spec[name]
            and integer(item['bytes'],LOG_MAX) and item['bytes']==receipt['log_bytes_reserved'][index]
            and digest_string(item['sha256']), 'mock log identity')
    marker={'schema':'bounded-stage-one-use-v2','command':receipt['command'],
        'receipt':spec['receipt'],'stdout':spec['stdout'],'stderr':spec['stderr']}
    require(receipt['one_use_marker_sha256']==hashlib.sha256(canonical(marker)).hexdigest(), 'mock one-use marker commitment')
    completion=receipt['mock_completion']
    require(type(completion) is dict and set(completion)=={'freeze_sha256','pre_mock_approval_sha256','result'}, 'mock completion schema')
    require(completion['freeze_sha256']==freeze_pin and completion['pre_mock_approval_sha256']==approval_pin, 'mock approval/freeze commitment')
    item=completion['result']
    require(type(item) is dict and set(item)=={'path','bytes','sha256'} and item['path']==spec['output']
        and integer(item['bytes'],65536) and digest_string(item['sha256']), 'mock result commitment')
    return True


def mock_context(root,args,command,mode):
    """Read-only permission/source guard; returns before any marker or fork."""
    root=Path(root);freeze_path=root/'FREEZE.json';approval_path=root/'PRE-MOCK-APPROVAL.json'
    freeze_pin=sha(freeze_path,JSON_MAX);freeze=read_json(freeze_path)
    approval=read_json(approval_path)
    require(type(approval) is dict and set(approval)=={'schema','status','freeze_sha256'}
        and approval['schema']=='fixed-data-post-failure-pre-mock-approval-v1'
        and approval['status']=='APPROVED_FOR_TWO_FROZEN_MOCKS'
        and approval['freeze_sha256']==freeze_pin, 'independent two-mock approval gate closed')
    approval_pin=sha(approval_path,JSON_MAX)
    require(type(freeze) is dict and set(freeze)=={'schema','files','python','jobs','limits','mock_jobs',
        'public_paths','analysis_manifest_sha256','resource_allocation_sha256',
        'origin_manifest_sha256','generation_origin_freeze_sha256'}
        and freeze.get('schema')=='fixed-data-post-failure-reevaluation-v1-freeze', 'mock source freeze schema')
    spec=validate_mock_spec(freeze,freeze_pin,mode,args,command,root)
    other_mode='optimized' if mode=='normal' else 'normal'
    other=freeze['mock_jobs'][other_mode]
    validate_mock_spec(freeze,freeze_pin,other_mode,
        expand_freeze_tokens(other['launch_command'],freeze_pin)[4:],
        expand_freeze_tokens(other['command'],freeze_pin),root)
    require(spec['expected_counts']==other['expected_counts'], 'same finite mock count dictionary in both modes')
    require(freeze['python']=={'executable':str(Path(sys.executable).resolve()),
        'sha256':sha(Path(sys.executable).resolve(),64*MIB),'version':sys.version}, 'mock interpreter source pin')
    require(type(freeze.get('files')) is dict and 8<=len(freeze['files'])<=64, 'mock frozen source list')
    ancestors={
        '/workspace/shared/canonical-residual-dev/residual_decoder.py':'be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67',
        '/workspace/shared/canonical-residual-dev/affine_filter.py':'1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d',
        '/workspace/shared/canonical-residual-reference-v3/reference_v3.py':'0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9',
        '/workspace/shared/residual-fresh-validation-v2/generator.py':'4bf7b8198603f255692b90b5d5ab479ac0c4fa74ab8c2fa9871f6f54668edfa9',
        '/workspace/shared/residual-fixed-data-reevaluation-v1-public/ORIGIN-MANIFEST.json':'002541c7d8c9786d21f1b5a3fb3293efc83709ee32d1cb72ba751eb7383ca80b',
        '/workspace/shared/residual-fixed-data-reevaluation-v1-public/ORIGIN-RUN-INVENTORY.json':'a86c20e9c142e00f8f9165fe83184517b7d8324039d7cc86ced3f79aeb642f70'}
    for name,pin in freeze['files'].items():
        require(type(name) is str and Path(name).is_absolute()
            and (Path(name).parent==root or ancestors.get(name)==pin) and digest_string(pin)
            and sha(name,64*MIB)==pin, 'mock frozen source mismatch')
    for filename in ('bounded_stage.py','protocol_mock_tests.py'):
        require(str(root/filename) in freeze['files'], 'mock launcher/test source must be frozen')
    if mode=='optimized':
        previous=freeze['mock_jobs']['normal'];receipt=read_json(previous['receipt'])
        validate_mock_receipt(receipt,previous,'normal',freeze_pin,approval_pin)
        marker_path=Path(previous['receipt']).with_name(Path(previous['receipt']).name+'.started.json')
        require(sha(marker_path,JSON_MAX)==receipt['one_use_marker_sha256'], 'normal one-use marker changed')
        for item in receipt['logs']+[receipt['mock_completion']['result']]:
            cap=65536 if item['path']==previous['output'] else LOG_MAX
            path=Path(item['path'])
            require(path.stat().st_size==item['bytes'] and sha(path,cap)==item['sha256'], 'normal sealed artifact changed')
        validate_mock_report(read_json(previous['output'],65536),previous,'normal',freeze_pin)
        # A missing/failed resource receipt is an outstanding one-use reservation,
        # never permission to launch optimized. External tool completion is also
        # required by the parent's operating gate; this local receipt cannot prove it.
    return freeze,spec,freeze_pin,approval_pin


def run_bounded(command, cwd, stdout_path, stderr_path, limits):
    """Launch exactly one child; collect two bounded pipes in this supervisor.

    Process launch is reachable only through explicit callers, never import.
    The caller must durably reserve the invocation before calling this function.
    No process/thread is created to collect logs. waitid/WNOWAIT preserves the
    child's PID until alarm disarming and wait4; kill never targets a reaped PID.
    """
    check_limits(limits)
    require(type(command) is list and command and all(type(x) is str and len(x) <= 4096 for x in command), 'bounded argv')
    require(len(command) <= 64 and Path(command[0]).is_absolute(), 'absolute bounded command')
    cwd = Path(cwd)
    require(cwd.is_absolute() and cwd.is_dir() and not cwd.is_symlink(), 'canonical cwd')
    paths = [Path(stdout_path), Path(stderr_path)]
    require(all(p.is_absolute() and p.parent.is_dir() and not p.parent.is_symlink() for p in paths), 'log paths')
    require(paths[0] != paths[1], 'distinct logs')
    death_guard()
    max_cpu = max(limits['worker_cpu_hard'], limits['supervisor_cpu_hard'])
    max_memory = max(limits['worker_address_space_bytes'], limits['supervisor_address_space_bytes'])
    resource.setrlimit(resource.RLIMIT_CPU, (limits['supervisor_cpu_soft'], max_cpu))
    resource.setrlimit(resource.RLIMIT_AS, (limits['supervisor_address_space_bytes'], max_memory))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (32*MIB, 32*MIB))
    logfds = [os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600) for p in paths]
    pipes = [os.pipe(), os.pipe()]
    started = time.monotonic()
    supervisor_pid = os.getpid()
    child = os.fork()
    if child == 0:
        try:
            for index, (readfd, writefd) in enumerate(pipes):
                os.close(readfd)
                os.dup2(writefd, index+1)
                os.close(writefd)
            for fd in logfds:
                os.close(fd)
            death_guard(supervisor_pid)
            os.setsid()
            signal.signal(signal.SIGXCPU, signal.SIG_DFL)
            signal.signal(signal.SIGALRM, signal.SIG_DFL)
            resource.setrlimit(resource.RLIMIT_CPU, (limits['worker_cpu_soft'], limits['worker_cpu_hard']))
            memory = limits['worker_address_space_bytes']
            resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
            os.chdir(str(cwd))
            os.execve(command[0], command, {'PATH':'/usr/bin:/bin', 'LANG':'C.UTF-8'})
        except BaseException as error:
            os.write(2, canonical({'schema':'bounded-child-setup-error-v2',
                'type':type(error).__name__, 'message':str(error)[:400]})[:1024])
            os._exit(125)
    for _readfd, writefd in pipes:
        os.close(writefd)
    resource.setrlimit(resource.RLIMIT_CPU, (limits['supervisor_cpu_soft'], limits['supervisor_cpu_hard']))
    memory = limits['supervisor_address_space_bytes']
    resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
    selector = selectors.DefaultSelector()
    for index, (readfd, _writefd) in enumerate(pipes):
        os.set_blocking(readfd, False)
        selector.register(readfd, selectors.EVENT_READ, index)
    timed_out = False
    collector_error = None
    child_unreaped = True
    child_exited = False
    deadline = started + limits['wall_seconds']

    def kill_unreaped():
        if not child_unreaped:
            return
        try:
            os.killpg(child, signal.SIGKILL)
        except ProcessLookupError:
            try:
                os.kill(child, signal.SIGKILL)
            except ProcessLookupError:
                pass

    def timeout(_signum, _frame):
        nonlocal timed_out
        if child_unreaped:
            timed_out = True
            kill_unreaped()

    capture = BoundedCapture(lambda index,data: os.write(logfds[index],data), kill_unreaped)
    signal.signal(signal.SIGALRM, timeout)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        timeout(signal.SIGALRM, None)
    else:
        signal.setitimer(signal.ITIMER_REAL, remaining)
    try:
        while not child_exited or selector.get_map():
            if not child_exited:
                try:
                    found = os.waitid(os.P_PID, child, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                    child_exited = found is not None
                except InterruptedError:
                    pass
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timeout(signal.SIGALRM, None)
                break  # No pipe drain is permitted beyond the frozen deadline.
            events = selector.select(min(0.05, remaining)) if selector.get_map() else []
            if not events and not selector.get_map() and not child_exited:
                time.sleep(min(0.01, remaining))
            for key, _mask in events:
                fd, index = key.fd, key.data
                try:
                    data = os.read(fd, CHUNK)
                except BlockingIOError:
                    continue
                if not data:
                    selector.unregister(fd)
                    os.close(fd)
                    continue
                capture.feed(index,data)
    except BaseException as error:
        collector_error = type(error).__name__ + ':' + str(error)[:300]
        kill_unreaped()
    finally:
        for key in list(selector.get_map().values()):
            selector.unregister(key.fd)
            os.close(key.fd)
        selector.close()
    # If an exceptional collector exit ended early, kill and then await an
    # unreaped exit. All time after the deadline is cleanup, never a PASS.
    if collector_error is not None or timed_out or capture.overflow:
        kill_unreaped()
    def release_pid_guard():
        nonlocal child_unreaped
        child_unreaped = False
    _, wait_status, usage = reap_after_disarm(
        lambda: os.waitid(os.P_PID,child,os.WEXITED|os.WNOWAIT),
        lambda: signal.setitimer(signal.ITIMER_REAL,0), release_pid_guard,
        lambda: os.wait4(child,0))
    for fd in logfds:
        os.fsync(fd)
        os.close(fd)
    for parent in {p.parent for p in paths}:
        fsync_dir(parent)
    log_records=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p,LOG_MAX)) for p in paths]
    wall = time.monotonic() - started
    own = resource.getrusage(resource.RUSAGE_SELF)
    child_cpu = usage.ru_utime + usage.ru_stime
    own_cpu = own.ru_utime + own.ru_stime
    failures = []
    if timed_out or wall > limits['wall_seconds']:
        failures.append('wall_timeout_or_overshoot')
    if capture.overflow:
        failures.append('log_overflow')
    if collector_error is not None:
        failures.append('collector_error:' + collector_error)
    exit_code = os.waitstatus_to_exitcode(wait_status)
    if exit_code != 0:
        failures.append('child_exit_' + str(exit_code))
    if not numeric(child_cpu) or child_cpu > limits['worker_cpu_hard']:
        failures.append('worker_cpu_invalid_or_overshoot')
    if not numeric(own_cpu) or own_cpu > limits['supervisor_cpu_hard']:
        failures.append('supervisor_cpu_invalid_or_overshoot')
    return dict(schema=VERSION, command=command, cwd=str(cwd), limits=dict(limits),
        supervisor_pid=supervisor_pid, child_pid=child, child_reaped=True,
        parent_death_guard=True, exit_code=exit_code, wall_timeout=timed_out,
        log_overflow=capture.overflow, collector_error=collector_error,
        wall_seconds=wall, child_user_cpu_seconds=usage.ru_utime,
        child_system_cpu_seconds=usage.ru_stime, child_cpu_seconds=child_cpu,
        supervisor_exclusive_cpu_sample=own_cpu,
        supervisor_cpu_allocation_charged=limits['supervisor_cpu_hard'],
        supervisor_final_write_tail_measured=False,
        child_peak_rss_kib=usage.ru_maxrss, supervisor_peak_rss_kib=own.ru_maxrss,
        log_bytes_reserved=capture.written, log_bytes_read=capture.read_bytes,
        logs=log_records,
        failures=failures)


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    require(len(args) >= 7, 'receipt cpu MiB wall stdout stderr command required')
    receipt_text, cpu_text, memory_text, wall_text, stdout_text, stderr_text, *command = args
    require(all(text.isdigit() and str(int(text)) == text for text in (cpu_text,memory_text,wall_text)), 'canonical integer limits')
    cpu, memory_mib, wall = int(cpu_text), int(memory_text), int(wall_text)
    require((cpu,memory_mib,wall) in ((30,512,120),(5,512,120),(180,768,600)), 'only frozen generic stage envelopes')
    death_guard()
    resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu+1))
    resource.setrlimit(resource.RLIMIT_AS,(memory_mib*MIB,memory_mib*MIB))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_FSIZE,(32*MIB,32*MIB))
    require(len(command)<=64 and all(type(value) is str and len(value)<=4096 for value in command),'bounded stage argv')
    require(sys.flags.isolated==1 and sys.dont_write_bytecode is True and sys.flags.optimize==0,
        'launcher itself must use normal isolated no-bytecode Python')
    root = Path(__file__).resolve().parent
    require(command[0] == str(Path(sys.executable).resolve()) and command[1:3] == ['-I','-B'], 'isolated pinned Python command')
    script_index = 4 if len(command) > 3 and command[3] == '-O' else 3
    require(len(command) > script_index, 'stage script required')
    script = Path(command[script_index])
    require(script.parent == root and script.name in ('protocol_mock_tests.py','bind_ancestry.py','seal_results.py','analyze.py'), 'fixed stage script')
    require(script.is_file() and not script.is_symlink(), 'regular stage source')
    require(script_index == 3 or script.name == 'protocol_mock_tests.py', 'only mock optimized stage')
    expected_cpu = {'protocol_mock_tests.py':30,'bind_ancestry.py':30,'seal_results.py':5,'analyze.py':180}[script.name]
    require(cpu == expected_cpu, 'stage envelope identity')
    receipt, stdout, stderr = map(Path, (receipt_text,stdout_text,stderr_text))
    require(all(p.is_absolute() and p.parent.is_dir() and not p.parent.is_symlink() for p in (receipt,stdout,stderr)), 'absolute stage paths')
    require(len({receipt,stdout,stderr}) == 3, 'distinct stage paths')
    mock=None
    if script.name=='protocol_mock_tests.py':
        mode='optimized' if script_index==4 else 'normal'
        mock=mock_context(root,args,command,mode)
        require(not any(receipt.parent.iterdir()), 'fresh fixed mock slot directory required')
    marker = receipt.with_name(receipt.name + '.started.json')
    require(not receipt.exists() and not stdout.exists() and not stderr.exists(), 'new stage output paths required')
    write_new(marker, dict(schema='bounded-stage-one-use-v2', command=command,
        receipt=str(receipt),stdout=str(stdout),stderr=str(stderr)))
    marker_pin=sha(marker,JSON_MAX)
    limits = dict(worker_cpu_soft=cpu,worker_cpu_hard=cpu+1,
        supervisor_cpu_soft=cpu,supervisor_cpu_hard=cpu+1,
        worker_address_space_bytes=memory_mib*MIB,supervisor_address_space_bytes=memory_mib*MIB,
        wall_seconds=wall,log_max_bytes=LOG_MAX)
    result = run_bounded(command, root, stdout, stderr, limits)
    result['one_use_marker_sha256'] = marker_pin
    if mock is not None:
        freeze,spec,freeze_pin,approval_pin=mock
        result['mock_completion']=None
        try:
            require(sha(root/'FREEZE.json',JSON_MAX)==freeze_pin
                and sha(root/'PRE-MOCK-APPROVAL.json',JSON_MAX)==approval_pin, 'post-mock freeze/approval changed')
            for name,pin in freeze['files'].items():require(sha(name,64*MIB)==pin, 'post-mock source changed')
            output=Path(spec['output'])
            validate_mock_report(read_json(output,65536),spec,mode,freeze_pin)
            result['mock_completion']={'freeze_sha256':freeze_pin,'pre_mock_approval_sha256':approval_pin,
                'result':{'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output,65536)}}
        except (OSError,ValueError,TypeError,KeyError,MemoryError) as error:
            result['failures'].append('mock_completion:'+type(error).__name__+':'+str(error)[:300])
    own=resource.getrusage(resource.RUSAGE_SELF)
    result['supervisor_exclusive_cpu_sample']=own.ru_utime+own.ru_stime
    result['supervisor_peak_rss_kib']=own.ru_maxrss
    if not numeric(result['supervisor_exclusive_cpu_sample']) or result['supervisor_exclusive_cpu_sample']>cpu+1:
        result['failures'].append('supervisor_closeout_cpu_invalid_or_overshoot')
    result['status'] = 'COMPLETED' if not result['failures'] else 'INCOMPLETE_OR_FAILED'
    if mock is not None and not result['failures']:
        validate_mock_receipt(result,spec,mode,freeze_pin,approval_pin)
    write_new(receipt, result)
    return 0 if not result['failures'] else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except BaseException as error:
        if isinstance(error, SystemExit):
            raise
        os.write(2, canonical({'schema':'bounded-stage-error-v2','type':type(error).__name__,
            'message':str(error)[:400]})[:1024])
        sys.exit(1)
