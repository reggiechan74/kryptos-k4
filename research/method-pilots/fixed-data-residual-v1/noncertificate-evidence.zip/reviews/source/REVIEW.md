# Independent fixed-data v1 preparation closeout

**PASS — narrowly scoped source/freeze review and the two authorized operational mocks.** Both normal and optimized completed once with all **311 obligations per mode** passing; the non-time reports agree exactly. This closes preparation, not the scientific re-evaluation. Both mock permissions are consumed. No binder, cohort, terminal, truth release, analysis, new draw or target execution is authorized by this report.

## Bound sources and review

Source root: `/workspace/shared/residual-fixed-data-reevaluation-v1`.

- FREEZE: `32f31dba104ca29d9f7ccfe7113e7e3158699916d662d3194097fe3178aef46e`.
- ANALYSIS-MANIFEST: `377e72854fa29740ff326eb2c352a279873d3dbdd6620c8cfae2a6ded81d2314`.
- SOURCE-SHA256SUMS: `d546f5130cb4e1c680050db549926f90bed980ded68c13d611929c393876b820`.
- PRE-MOCK-APPROVAL: `918889866316430802e45f11c0b923a763c64b3c2aa881a74951df80c94ec64f`.
- Prior independent PRE-MOCK-REVIEW in this directory: `b886dfaa5b7b80af5e213173cd587295b195eb3b77f69b678f265403809a43a2`.

The detailed static review remains unchanged and is incorporated for scope, exact source/schema/origin/caps/fixtures/command checks and limitations. It covered all ten new Python modules, their predecessor deltas, 28 pinned dependencies/metadata files, both mock commands, the whole 28-slot prospective command schedule and the explicit origin/new-run split. An additional independent reviewer cross-checked the binder/origin path and original preservation inventory without private access or execution.

The checker is byte-identical to its predecessor; the preflight source change is exactly the default cooperative wall limit 20.0 to 60.0. Its acceptance guard matches. Engine/reference/generator and mathematical semantics remain unchanged. New metadata paths are explicit, not derived from the original input's parent. The binder remains metadata-only and pending-only. External ancestry activation and terminal-before-truth gates remain distinct. All 29 source/freeze checksum entries and the approval pin were rechecked after both mocks and remain unchanged.

## Observed mock outcomes and integrity

| Mode | Result SHA-256 | Resource receipt SHA-256 |
|---|---|---|
| normal | `bad1a603e7bc355c2c3640c46b5bc614d99d52252868ff6a9171937929fdbc98` | `bcaab274a0111ca59bc0a3d951c60443ebf55639816bdea9331eb7e1f064eebb` |
| optimized | `6146476eedb5fa60fadcf863d175fb514645de70edc2d3eb42d4fb940b77f079` | `422672c4a5f8ab4884a605b7599d0a6992e34f6d0d6662f252c87fff9a9bbdce` |

Execution-owner external observations: normal began in tool chunk `a0dc8d`, session 73138, and finalized in chunk `281916` with exit 0; optimized finalized in chunk `744e94` with exit 0 and no remaining session. Normal's final sealed artifacts were independently reviewed before optimized was permitted. These external observations are trusted execution-owner history, not a claim that this reviewer observed kernel syscalls directly.

Both receipts bind the exact frozen argv/cwd, unique per-mode durable marker, approval and freeze. Both report child reaped, parent-death guard enabled, exit 0, no collector error, no timeout/log overflow and no resource failures. User plus system CPU matches each wait4 total. Both successful reports have null failure, exact frozen count dictionaries and zero reported inner child launches, real solver calls, seed draws, generator expansions and truth bytes. Static guarded code and fixture inspection support that scope; the mock metrics are not independent physical monitoring of all conceivable effects.

Mode equality was independently checked after excluding **only** `mode`, `resources.worker_cpu_seconds` and `resources.worker_wall_seconds`. This repeats one operational mock implementation in two modes; it is not two independently authored scientific oracles or independent fresh replications.

Exact artifact inventory: **14 files, 46,897 bytes**. Each mode contains its result, resource receipt, started marker, two logs and two disclosed scratch JSON files. All paths, sizes and hashes were checked, including receipt-bound log/result/marker identities. No certificate, bytecode or cohort runs directory exists; the new public directory still contains only the two immutable origin metadata files. No real reuse marker, new custody or active run approval was created by these mocks.

Bound closeout metadata:

- MOCK-INVENTORY.json: `e308c145b2ee0e97c9b49e301c10abc8d48e5dfce0d7ee25b2749ca84683f87b`.
- MOCK-EXTERNAL-COMPLETIONS.json: `b44440a6c8f00eb04b384e1c4738463bd122ff62f9b5391a10fbf1f78dc14f13`.
- RESOURCE-ACCOUNTING.json: `59a8c52d3339f207af2ba9af8be7005a3f9bc76d2568356c0f0a9962d66a452e`.

`BOUND-ARTIFACT-SHA256SUMS` binds the seven relevant top-level source/approval/closeout artifacts and all 14 mock files. `CLOSEOUT-CHECK.json` records the independent standard-library-only metadata cross-check; it neither imports experimental modules nor reruns their validators or tests.

## Resource interpretation

| Quantity | CPU seconds |
|---|---:|
| normal worker wait4 | 2.282500 |
| optimized worker wait4 | 0.360974 |
| **worker total** | **2.643474** |
| normal supervisor exclusive sample | 0.901078 |
| optimized supervisor exclusive sample | 0.102118 |
| **supervisor sampled total** | **1.003196** |
| **known reported components** | **3.646670** |
| full supervisor policy allocation, separately | 62 |
| worker actual + supervisor policy, **not measured CPU** | 64.643474 |
| consumed two-mock nominal allocation | 124 |

The single stage ledger reconciles these figures. Distinct command/mode/receipt identities deduplicate runs; repeated namespace PIDs 2/5 are not unique run identifiers. Inner suite timers are subsets and are not added to wait4. Final receipt-write/exit tails and preparation/control work remain incompletely measured within the 200-second allowance. Reviewer metadata-only process intervals are separately recorded as 0.099445321 and 0.003677066 seconds (sum 0.103122387); they are not additional scientific worker receipts, not in the 3.646670 total and not proof that all review overhead was measured.

The new 3,000 nominal allocation and project total 23,200/28,800 are allocation figures, not measured consumption. Unlaunched allocations—62 binder, 2,240 cohort, 12 sealer and 362 released analysis—still need their separate approvals. No old 80-second reserve or unused allocation is reused; no third mock/retry is available.

## What remains unproved / next permitted decision

Operational mocks do not establish actual-case rank/workload, semantic masks, hidden prediction accuracy, scientific coverage or throughput. The 60-second cooperative preflight allowance is load-sensitive and at-risk, not a proof of completion under worker soft/hard 60/75 CPU, supervisor 4/5 CPU and 150 wall. Repeated hashing and late digest work remain; 60+30+45=135 is not a feasibility guarantee. Nominal OS limits and sampled receipts are not perfect physical metrology. The static review's inherited fail-closed bootstrap growth-race and unexpected-tree enumeration caveats remain unchanged.

Parent may now consider the separately gated ancestry-only binder and exact private-command instantiation, followed by an external completion acknowledgment and an explicit whole-fixed-data run approval. This report grants none of those actions. If authorized later, preserve all 28 new slots and stop rules; do not resume only the failed suffix or import old partial successes. Truth must remain withheld until a separately authorized, externally retained new terminal seal and release gate are satisfied.

Original fresh-v2 evidence remains **INCOMPLETE** (8 executed, 20 canceled, retained 80 within attempted reservations), and the older 48-case failure remains excluded. Any eventual new result must say **fixed-data post-failure re-evaluation**, not new-fresh validation or retroactive original PASS. No K4 admission or resolution of missing matbalez scope is implied.

Review used read-only source/artifact checks plus local independent report metadata writes. There was no reviewer experimental import/compile/run, scientific replay, private authority/seed/truth read, producer source edit or remote write. No operation is denied, pending or uncertain in this preparation closeout; future execution is simply outside its grant.
