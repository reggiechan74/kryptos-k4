# Independent pre-mock source review — fixed-data re-evaluation v1

**Verdict: bounded STATIC SOURCE / FREEZE PASS.** No material blocker was identified at the exact pins below. Under the parent's 2026-11-01 00:17:56 UTC conditional preparation grant, the two frozen operational mocks may be invoked once each by the implementation owner: normal first, optimized only after normal has externally completed and all receipt/source/one-use checks pass. This is not a mock-result PASS, a real ancestry-binding approval, a cohort authorization, a terminal/truth-release approval, a fresh replication, or K4 admission.

Review completed 2026-11-01 UTC. The private research governance register was reviewed first; its coordination identifier is omitted here. Latest user direction to repair and continue is respected by this narrow whole-fixed-data plan; no replacement draw or mathematical hypothesis change is introduced.

## Exact reviewed identity

Root: `/workspace/shared/residual-fixed-data-reevaluation-v1`.

| Artifact | SHA-256 |
|---|---|
| FREEZE.json | `32f31dba104ca29d9f7ccfe7113e7e3158699916d662d3194097fe3178aef46e` |
| ANALYSIS-MANIFEST.json | `377e72854fa29740ff326eb2c352a279873d3dbdd6620c8cfae2a6ded81d2314` |
| SOURCE-SHA256SUMS | `d546f5130cb4e1c680050db549926f90bed980ded68c13d611929c393876b820` |
| SCHEMAS.json | `0c516e18314faff7c0c904f48528f0d4c45fbdd08e4159f198d749d6e32426b3` |
| CAPS.json | `912461b0b97d4ad9738b830cf6130788e9295f9a92901a5af1664e9f3875a9d4` |
| COMMAND-TEMPLATES.json | `ca1d09368723058afb0e7ab886eb9a022a367b64f2c584f273da616b121201cc` |
| protocol_mock_tests.py | `044e59a28e2f4a15b63112c777ff3fe7c2f99a44a0047ec4e2532c07d6049242` |
| custody_common.py | `45011017c0a103d8520ca759100f1c38699a5f5d77c391c16af0c87a97daf569` |
| bind_ancestry.py | `0857ea0f5eba9b68b203ee50ec517ce8e77470bb352af8efcbb5ea4a1ab00a2d` |
| New-public ORIGIN-MANIFEST.json | `002541c7d8c9786d21f1b5a3fb3293efc83709ee32d1cb72ba751eb7383ca80b` |
| New-public ORIGIN-RUN-INVENTORY.json | `a86c20e9c142e00f8f9165fe83184517b7d8324039d7cc86ced3f79aeb642f70` |

The complete 28-file freeze map and all 29 source/freeze checksum entries were independently checked. The resolved Python binary pin is `fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`. Ten predecessor references, both exact mock launch commands, all 28 prospective worker and supervisor commands, and the six-file analysis manifest were cross-checked without importing experimental code. The analysis manifest explicitly retains the immutable historical generator, not a new generator role.

## Narrow mathematical and operational delta

1. `checker_blind.py` is byte-identical to original SHA `065e3c29d2705c706b44a553bd9013b10c84751251145a4a683b940962ecc5c6`. `preflight_blind.py` differs by exactly `Caps.max_seconds: 20.0 -> 60.0`; new SHA `7f1929c0bd3c29a4e972f814e1fa1ade045a33e4b1cfc629e0b696c7b71dfe43`. The completed-preflight report acceptance ceiling is correspondingly 60. All other preflight logical, storage, support/beta, rank/certificate and point-admission semantics remain unchanged.
2. Engine `be050003…`, affine helper `1e19e9ad…`, independent reference `0730f8b0…`, and original generator `4bf7b819…` remain pinned and unchanged. Worker mathematical call order/arguments and 30/45-second producer/reference budgets are unchanged. Full relation checking, optional-joint semantics and bounded 64 MiB producer digest remain unchanged.
3. Public input remains the original exact path and SHA `79319cb9272242cd7f44b7bf2ccf6c9a630450ddab82c7cc2adb6457bd297747`. No input values were read by this review. All 28 new slots cover the whole fixed 12-base set plus two controls in normal/-O pairs; no old result is carried forward to complete a new pair.
4. Namespace/report/status changes label this post-failure fixed-data re-evaluation. Historical certificate/public/truth structural schema names are retained deliberately, not used to claim new freshness. Analysis coverage/twin/residual mathematics is unchanged; success, if eventually established, is explicitly post-failure fixed-data success only.
5. Process topology, bounded nonblocking pipe collection, pre-write log limits, parent-death guards, waitid/WNOWAIT-before-reaping sequence, one-use reservations, paired-mode comparison and stop-on-failure rules are unchanged. No cache, fsync removal, digest omission, traversal shortcut or cap replenishment was introduced.

## Origin, custody and authorization

An additional independent source-only reviewer checked the origin/binder path at the same pins. Both reviews found the generation/run separation sound within its stated authority model:

- Original generation remains bound to original FREEZE `77bda1ef…`. New custody independently binds this new freeze, the immutable origin manifest, original custody hash, new reuse approval and new private-command commitment while retaining original seed/truth/draw commitments.
- New custody, candidate, ancestry attestation, active approval and results paths are explicit NEW paths, never derived from the original input's parent directory.
- The fixed whole-document origin SHA authenticates its nested original commitments. The supplied original 42-entry file inventory matches the prior independent preservation inventory exactly: 40,761,555 bytes, including eight original certificates. This does not independently authenticate unread private receipts; those remain pinned custodian chronology.
- Future binder code checks immutable original metadata/source/input/inventory, exact whole-28 schedule, private command identity and clean new public state before an exclusive durable new reuse marker. It checks original preservation again and emits only new custody plus a PENDING_ANCESTRY_RECEIPT candidate. It cannot issue active approval or attest its own external completion. There is no entropy, generator, solver, seed/truth read, original-state write or certificate replay/copy in that path.
- Active approval validation requires the exact new candidate/custody/externally acknowledged ancestry chain and strict finite resource/completion fields. Real binder invocation and exact private command instantiation remain separate parent/custodian gates, not granted here.
- New external terminal authentication and inventory/source reconciliation still precede the first truth access. Only then may the unchanged historical generator's pure reconstruction be loaded for separately approved released analysis. No generator CLI role exists in the new private command vocabulary.

No hash cycle or demonstrated fail-open was found. Two nonblocking fail-closed robustness caveats remain: inherited bootstrap stat-then-read_bytes growth races and eager enumeration of unexpected additions to the original results tree. Hash/exact-set rejection prevents acceptance; installed process limits bound failure, not a perfect physical I/O guarantee. These are not represented as validated adversarial-filesystem hard bounds.

## Exact two-mock permission

The frozen literal suite contains **311 obligations per mode**, inherited 266 plus 45 ancestry checks. Static inspection covered the literal fixtures and non-no-op mutation targets: new origin/custody/run identity, forbidden generator roles, explicit new paths, externally acknowledged activation, marker exclusivity, report origins, resource ceilings, existing schema/certificate/storage/collector/reaping/strict-cap checks and three intercepted terminal-before-truth boundaries.

RNG/process guards are installed before nine module imports; historical generator and real engine/reference are not imported. Operational stubs and disclosed literal schema records are used. The first would-be truth access is intercepted at a mock-only nonexistent path. Sanitized origin commitments are read; original case values and original certificate payloads are not. The mock counts are frozen identically in both modes. Count agreement alone will not establish scientific correctness or representative throughput.

For each mode, the sole allowed outer argv is the exact `FREEZE.mock_jobs[mode].launch_command`, with only the whole `${FREEZE_PIN}` token replaced by the FREEZE SHA above, and the frozen cwd. Each is one supervisor plus one child, nominal 30/31 CPU seconds and 512 MiB per process, 120-second supervised wall. Normal failure or uncertain external completion prevents optimized. No retry, third invocation or separate reviewer test is authorized. Before this approval, both mock directories were empty, `runs/` and PRE-MOCK-APPROVAL were absent, and the new public directory contained only the two immutable origin files.

## Limits and next gates

The new 3,000-second allocation is separate: 2,240 cohort slots + 124 mocks + 62 ancestry binding + 12 sealer + 362 released analysis + 200 preparation/control/closeout allowance. Project allocation is 23,200/28,800; remaining 5,600 is not execution authority. Original retained 80 seconds and unused prior reservations are not reused. Worker usage, supervisor exclusive samples, full supervisor policy allocation and retained reserves must remain separate; phase timers are subsets. Nominal limits are not physical accounting guarantees.

Uniform 60-second preflight is an explicitly at-risk finite trial: worker soft/hard 60/75 CPU, supervisor 4/5 CPU, 150-second wall. The sum 60+30+45=135 does not prove feasibility; repeated certificate/source hashing, digest work and scheduling remain possible failure causes. Any resource exhaustion or uncertain outcome must stop under the frozen contract, not trigger a silent relaxation.

Original fresh-v2 evidence remains permanently INCOMPLETE: eight executed, twenty canceled, retained 80 subset of attempted reservations. Earlier 48-case failure is excluded; no new draw, K4 data, target admission or unresolved matbalez scope is supplied. After the two mocks, read-only source/receipt/inventory/mode/accounting review is required for a preparation-result PASS. Real binder, active run, terminal, truth release and analysis still require their separate stated approvals.

This review used source text/diffs, checksums and metadata processing only. No experimental source import/compilation/execution, test, real case replay, private authority/seed/truth access, source edit or remote write occurred. `PRE-MOCK-METADATA-CHECK.json` records only its small standard-library metadata process CPU interval; earlier static review/shell overhead is unmeasured within the control allowance, not zero and not scientific worker usage.
