# Fixed-data post-failure re-evaluation v1 — preparation closeout

**Independent source + two-mock preparation PASS. Both permitted operational mocks completed once each and passed all 311 frozen obligations per mode.** The normal command reached external terminal exit 0 before its independent readback and the optimized command; optimized also reached external terminal exit 0. Source and approvals remained unchanged. The two mock permissions are consumed; no third invocation or retry is available.

This is operational preparation, **not** a real ancestry-binding operation, cohort result, decoder validation, representative throughput, independent fresh replication or K4 admission. No real binder, producer/reference, generator expansion, case replay, seed/truth access, sealer, released analysis or remote edit occurred. The actual reused input values were not inspected or used as mock fixtures.

## Exact handoff

Root: `/workspace/shared/residual-fixed-data-reevaluation-v1`.

| Artifact | SHA-256 |
|---|---|
| FREEZE.json | `32f31dba104ca29d9f7ccfe7113e7e3158699916d662d3194097fe3178aef46e` |
| ANALYSIS-MANIFEST.json | `377e72854fa29740ff326eb2c352a279873d3dbdd6620c8cfae2a6ded81d2314` |
| SOURCE-SHA256SUMS | `d546f5130cb4e1c680050db549926f90bed980ded68c13d611929c393876b820` |
| PRE-MOCK-APPROVAL.json | `918889866316430802e45f11c0b923a763c64b3c2aa881a74951df80c94ec64f` |
| mocks/normal/resource.json | `bcaab274a0111ca59bc0a3d951c60443ebf55639816bdea9331eb7e1f064eebb` |
| mocks/optimized/resource.json | `422672c4a5f8ab4884a605b7599d0a6992e34f6d0d6662f252c87fff9a9bbdce` |
| MOCK-EXTERNAL-COMPLETIONS.json | `b44440a6c8f00eb04b384e1c4738463bd122ff62f9b5391a10fbf1f78dc14f13` |
| MOCK-INVENTORY.json | `e308c145b2ee0e97c9b49e301c10abc8d48e5dfce0d7ee25b2749ca84683f87b` |
| RESOURCE-ACCOUNTING.json | `59a8c52d3339f207af2ba9af8be7005a3f9bc76d2568356c0f0a9962d66a452e` |

Independent pre-mock source review: `/workspace/shared/residual-fixed-data-reevaluation-v1-independent-source-review/PRE-MOCK-REVIEW.md`, SHA `b886dfaa5b7b80af5e213173cd587295b195eb3b77f69b678f265403809a43a2`. It separately verified exact source, origin, fixtures, counts, commands and empty one-use state before issuing the approval.

Final independent source/mock outcome **PASS**: `/workspace/shared/residual-fixed-data-reevaluation-v1-independent-source-review/REVIEW.md`, SHA `8d3a8eb2a5d45e1eb68980d118453b68a616c04b7736f956ae5e6a0ca3adfb01`. Its `SHA256SUMS` is `401675fd1775eec0cabcaf5fedd2a374c591579eabb2e61b2ec2506b4236d639`; all six review-manifest entries passed readback. No future scientific invocation is authorized by this review.

All 28 frozen file pins plus FREEZE (29 entries) passed readback after both invocations. The checker remains byte-identical; the preflight remains the exact one-literal 20.0-to-60.0 change. The mathematical sources and full verification requirements are unchanged. The new generation-origin/run split and explicit NEW operational metadata paths are independently reviewed. Immutable historical generator source remains an analysis-only dependency after the future external terminal/release gate.

## Outcomes, inventory and accounting

The reports agree after excluding only `mode`, `resources.worker_cpu_seconds` and `resources.worker_wall_seconds`. All five prohibited-operation counters are zero in both modes. Their 311 obligations are 266 inherited/mapped operational obligations plus 45 finite ancestry/path/resource/marker checks. Literal certificate/schema fixtures and in-memory authority graphs are not independent scientific cases or theorem replays.

Exactly **14 mock-tree files / 46,897 bytes** were retained, with two disclosed scratch files per mode. There are no certificates, bytecode or cohort runs directory. Both children were reaped, logs are bounded/sealed, marker/result/log hashes match, and there was no overflow, timeout, invalid receipt or observed nominal overshoot. This is supervised-launch cleanup evidence, not a machine-global process audit. The new public root still contains only the two custodian-supplied immutable origin artifacts; no active run approval, pending binder candidate or actual reuse marker exists there.

| Measured/reporting component | CPU seconds |
|---|---:|
| Normal worker wait4 | 2.282500 |
| Optimized worker wait4 | 0.360974 |
| **Worker total** | **2.643474** |
| Supervisor exclusive samples, both | **1.003196** |
| **Known reported components** | **3.646670** |

The complete supervisor policy charge is separately 62 seconds; worker actual plus that policy charge is 64.643474, **not measured CPU**. Two mock allocations total 124 seconds and both permissions are consumed. Internal phase timers are subsets, not added again; repeated namespace PID values do not deduplicate distinct launches. Final receipt-write/exit/control and static preparation/review overhead are incompletely measured within the fixed 200 allowance, not zero. The reviewer separately recorded metadata-process intervals totaling 0.103122387 seconds; these are partial control measurements, not additional scientific worker receipts or part of the 3.646670 stage total. One run per mode is not a performance comparison or explanation of the original failure.

Project allocation remains **23,200 / 28,800**, with **5,600 unallocated**, not measured project consumption. The separately gated future allocations total 2,676: binder 62, whole cohort 2,240, sealer 12 and released analysis 362. They remain unlaunched and require their exact next-stage authority. No old unused capacity, earlier contingency or original retained 80 was reused.

## Preserved science and remaining gates

Original fresh-v2 remains permanently INCOMPLETE: 28 planned, 8 executed, 20 canceled, 4 control-gate slots, 3 verified slots, 1 precheck-wall failure and only 1 completed base pair. Its source/input/custody/failure state/lock/reservation remain unmodified. The earlier 48-case cohort stays excluded and sealed. The eventual re-evaluation must still run all 28 new slots on the same 12 bases and retain all original and new outcomes; no selective suffix, replacement draw or changed hypothesis is allowed.

The uniform 60-second preflight is an explicitly at-risk planning choice. This mock PASS neither guarantees completion under worker 60/75 CPU, supervisor 4/5 CPU and 150 wall nor diagnoses CPU/I/O/scheduling causes. All original logical/storage/semantic limits and failure stops remain.

| Exact next action | Target/owner | Reason | Completed | Status |
|---|---|---|---|---|
| Accept final independent source/mock outcome review and exact private command instantiation | Parent + independent reviewer/custodian | Source/mocks do not authorize a real custody operation; private proposals are separately held by parent/custodian | No | Pending |
| Authorize one exact ancestry-only binder, then independently accept its outer receipt/logs/new marker/postseals and external completion before active approval | Parent + custodian | New binder cannot activate itself or reuse original draw/run approval | No | Pending |
| Authorize exact whole 28-slot schedule under the frozen source/input/resource envelope | Parent + execution owner | No actual cohort invocation is authorized by this preparation closeout | No | Pending |
| Accept external terminal seal before any truth release, then authorize one exact released analysis | Parent + custodian | Complete new inventory, zero reserve and full relation/mode checks remain mandatory | No | Pending |
| Reconcile canonical progress ledger for the completed preparation and chosen next phase | Parent | Keep current status and authority accurate without changing original failure | No | Pending parent handoff |

No denied operation or uncertain experimental outcome remains. The normal outer tool initially returned a running session; its explicit terminal exit was checked before proceeding. All other preparation commands were source-text/static-AST/hash/metadata work, not extra experimental invocations. No source mutation follows the two mocks; a later necessary correction must preserve these receipts and return for a separate scoped decision rather than silently continue.
