"""Post-label-release verification repeat; unchanged audit, never a fresh blind test."""
import subprocess,resource,time,json,pathlib,hashlib
root=pathlib.Path('/workspace/shared/sparse-law-blind40-audit');dest=pathlib.Path('/workspace/shared/sparse-law-blind40-capped-recheck');dest.mkdir(exist_ok=False)
audit=root/'audit_public.py';source_hash=hashlib.sha256(audit.read_bytes()).hexdigest()
def limit():
 resource.setrlimit(resource.RLIMIT_CPU,(300,300));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter()
with (dest/'console.jsonl').open('w') as f:
 result=subprocess.run(['python3',str(audit),'/workspace/shared/sparse-law-blind40/public.json','/workspace/shared/sparse-law-blind40/results',str(dest)],stdout=f,stderr=subprocess.PIPE,text=True,preexec_fn=limit,timeout=600)
after=resource.getrusage(resource.RUSAGE_CHILDREN)
assert hashlib.sha256(audit.read_bytes()).hexdigest()==source_hash
receipt={'classification':'post-seal verification repeat AFTER labels released, not fresh blind result','audit_source_sha256':source_hash,'source_unchanged':True,'returncode':result.returncode,'stderr':result.stderr,'cpu_s_including_waited_descendants':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall_s':time.perf_counter()-start,'maxrss_kib_waited_child_tree':after.ru_maxrss,'outer_audit_cpu_limit_s':300,'outer_audit_address_space_limit_bytes':2*1024**3,'wall_timeout_s':600,'replay_child_limits':'unchanged original30CPU seconds,60wall seconds,2GiB AS'}
(dest/'wrapper-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));assert result.returncode==0
