"""Independent public-only post-seal audit. Never reads private labels/generator.
Do not invoke until original run is sealed. All outputs outside frozen source.
"""
import sys, json, pathlib, hashlib, gzip, resource, subprocess, time
from itertools import combinations_with_replacement
SOURCE=pathlib.Path('/workspace/shared/sparse-law-pilot')
EXPECTED_FREEZE='21cbfd6793e2c4edbf4d5a676704c614b413bbe236ad7861a9cb88ba30e35bc9'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def replay_worker(public,index,dest):
 resource.setrlimit(resource.RLIMIT_CPU,(30,30))
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 sys.path.insert(0,str(SOURCE))
 from reference import solve
 case=json.loads(pathlib.Path(public).read_text())[index]
 assert set(case)=={'id','A','I','b'}
 result=solve(case['A'],case['I'],case['b'])
 pathlib.Path(dest).write_text(json.dumps(result))

def audit_case(case,out,index):
 A,I,b=case['A'],case['I'],case['b'];n=len(A);m=len(A[0]);q=26
 results={}
 for mode in ('oracle','join','dense','plain'):
  path=out/f'{index:02d}-{mode}.json'
  if path.exists():
   r=json.loads(path.read_text());assert r['id']==case['id'];assert r['mode']==mode
   if r.get('status')=='complete':
    assert len(r['masks'])==n and all(type(v)is int and 0<=v<1<<q for v in r['masks'])
    assert all(r['masks'][i] in (0,1<<v) for i,v in zip(I,b))
    results[mode]=r
 if 'oracle' in results and 'join' in results:assert results['oracle']['masks']==results['join']['masks']
 if 'oracle' in results and 'plain' in results:assert results['oracle']['masks']==results['plain']['masks']
 if 'oracle' in results and 'dense' in results:assert all(a&d==a for a,d in zip(results['oracle']['masks'],results['dense']['masks']))
 for mode in ('join','plain'):
  if mode not in results:continue
  r=results[mode]
  for i,ws in enumerate(r['witnesses']):
   assert sum(1<<int(v) for v in ws)==r['masks'][i]
   for v,theta in ws.items():
    assert len(theta)==m and all(type(t)is int and 0<=t<q for t in theta)
    assert sum(t!=0 for t in theta)<=3
    assert all(sum(a*t for a,t in zip(A[j],theta))%q==bv for j,bv in zip(I,b))
    assert sum(a*t for a,t in zip(A[i],theta))%q==int(v)
 # Independently establish completeness/feasibility of the compressed atom
 # relation. All products in a matched signature bucket are feasible, so no
 # exponentially large Cartesian expansion is necessary.
 relation_path=out/f'{index:02d}-join.json.relation.json.gz'
 if 'join' not in results:return {'status':'incomplete_join','complete_methods':list(results)}
 with gzip.open(relation_path,'rt') as f:packed=json.load(f)
 assert packed['atom_convention']=='0=empty;1+j*25+(k-1)=(feature j,coefficient k)'
 atoms=[(0,)*n]+[tuple(k*row[j]%q for row in A) for j in range(m) for k in range(1,q)]
 sig=[tuple(v[i] for i in I) for v in atoms]
 left={}
 for a,z in enumerate(sig):left.setdefault(z,set()).add(a)
 actual={};product_count=0;right_count=0;left_count=0
 for bucket in packed['relation']:
  ls=bucket['left'];rs=bucket['right'];assert ls and rs and len(set(ls))==len(ls)
  assert all(type(a)is int and 0<=a<len(atoms) for a in ls)
  signature=sig[ls[0]];assert set(ls)==left[signature]
  target=tuple((v-z)%q for v,z in zip(b,signature));assert target not in actual
  pairs=set()
  for pair in rs:
   assert len(pair)==2;a,d=pair
   assert type(a)is int and type(d)is int and 0<=a<=d<len(atoms)
   assert tuple((x+y)%q for x,y in zip(sig[a],sig[d]))==target
   assert (a,d) not in pairs;pairs.add((a,d))
  actual[target]=pairs;product_count+=len(ls)*len(rs);right_count+=len(rs);left_count+=len(ls)
 remaining={k:set(v) for k,v in actual.items()}
 expected_pairs=0
 for a,d in combinations_with_replacement(range(len(atoms)),2):
  target=tuple((x+y)%q for x,y in zip(sig[a],sig[d]))
  complement=tuple((v-z)%q for v,z in zip(b,target))
  if complement in left:
   assert target in remaining and (a,d) in remaining[target]
   remaining[target].remove((a,d));expected_pairs+=1
 assert all(not x for x in remaining.values())
 r=results['join']
 assert r['products']==product_count and r['right_descriptors']==right_count==expected_pairs
 assert r['left_descriptors']==left_count and r['matched_buckets']==len(actual)
 return {'status':'exact_factorized_relation_verified','complete_methods':list(results),'right_descriptors':right_count,'descriptor_products':product_count}

def main(public,out,dest):
 public=pathlib.Path(public);out=pathlib.Path(out);dest=pathlib.Path(dest)
 dest.mkdir(exist_ok=True)
 assert sha(SOURCE/'freeze-sha256.json')==EXPECTED_FREEZE
 seal=json.loads((out/'sealed-output-sha256.json').read_text())
 assert sha(public)==seal['PUBLIC_INPUT_SHA256']
 for name,digest in seal.items():
  if name!='PUBLIC_INPUT_SHA256':assert sha(out/name)==digest,(name,'seal mismatch')
 pre=json.loads((out/'pre-execution-hashes.json').read_text())
 for path,digest in pre.items():assert sha(path)==digest,(path,'source/input mutation')
 cases=json.loads(public.read_text());assert len(cases)==40 and all(set(c)=={'id','A','I','b'} for c in cases)
 receipt={'public_sha256':sha(public),'original_output_seal_sha256':sha(out/'sealed-output-sha256.json'),'audit_source_sha256':sha(__file__),'cases':[]}
 start=time.perf_counter();cpu0=resource.getrusage(resource.RUSAGE_SELF);child_total=0
 for index,case in enumerate(cases):
  row={'index':index,'id':case['id']}
  t=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN)
  target=dest/f'{index:02d}-oracle-replay.json'
  try:
   p=subprocess.run([sys.executable,__file__,'_replay',str(public),str(index),str(target)],capture_output=True,text=True,timeout=60)
   row['replay_status']='complete' if p.returncode==0 else 'incomplete_process'
   if p.returncode:row['replay_error']=p.stdout+p.stderr
  except subprocess.TimeoutExpired:row['replay_status']='incomplete_timeout'
  after=resource.getrusage(resource.RUSAGE_CHILDREN);cost=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
  child_total+=cost;row['replay_cpu_s']=cost;row['replay_wall_s']=time.perf_counter()-t
  assert child_total<=1201,'Replay CPU allocation exceeded'
  if row['replay_status']=='complete':
   replay=json.loads(target.read_text())
   for mode in ('oracle','join'):
    path=out/f'{index:02d}-{mode}.json'
    if path.exists():
     r=json.loads(path.read_text())
     if r.get('status')=='complete':assert replay['masks']==r['masks'],(index,mode,'replay disagreement')
   original=json.loads((out/f'{index:02d}-oracle.json').read_text())
   assert replay['program_unique']==original['program_unique']
   assert replay['feasible_support_count']==original['feasible_support_count']
  row['relation_audit']=audit_case(case,out,index)
  receipt['cases'].append(row)
  (dest/'audit-receipt.json').write_text(json.dumps(receipt,indent=2))
  print(json.dumps({'index':index,'replay':row['replay_status'],'relation':row['relation_audit']['status']}),flush=True)
 for name,digest in seal.items():
  if name!='PUBLIC_INPUT_SHA256':assert sha(out/name)==digest
 for path,digest in pre.items():assert sha(path)==digest
 cpu1=resource.getrusage(resource.RUSAGE_SELF)
 receipt.update(status='PASS' if all(x['replay_status']=='complete' and x['relation_audit']['status']=='exact_factorized_relation_verified' for x in receipt['cases']) else 'INCOMPLETE',replay_child_cpu_s=child_total,audit_cpu_s=cpu1.ru_utime+cpu1.ru_stime-cpu0.ru_utime-cpu0.ru_stime,wall_s=time.perf_counter()-start)
 (dest/'audit-receipt.json').write_text(json.dumps(receipt,indent=2))
 manifest={p.name:sha(p) for p in sorted(dest.iterdir()) if p.is_file() and p.name!='audit-output-sha256.json'}
 (dest/'audit-output-sha256.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps({k:v for k,v in receipt.items() if k!='cases'}),flush=True)

if __name__=='__main__':
 if sys.argv[1]=='_replay':replay_worker(sys.argv[2],int(sys.argv[3]),sys.argv[4])
 else:main(*sys.argv[1:])
