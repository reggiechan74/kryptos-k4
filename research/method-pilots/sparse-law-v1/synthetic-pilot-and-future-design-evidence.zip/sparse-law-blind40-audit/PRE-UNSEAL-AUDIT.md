# Independent pre-unseal blind40 audit

Status: PASS. All40 public cases replayed using the frozen independent oracle; all masks, coefficient-uniqueness flags and feasible-support counts matched original oracle results. Primary oracle/join mask equality and available plain/dense comparisons passed. Every returned join/plain marginal witness verified independently.

All40 compressed joint relations were independently validated: original left atom groups were reconstructed, every right descriptor was checked for exact signature complement, all unordered atom pairs (including empty atoms/repetition) were enumerated to establish relation coverage, no matching descriptor was omitted/duplicated, and reported descriptor counts/product counts matched. Cartesian products were not expanded; complete coupled relation correctness follows from all pairs within each exact-signature bucket being admissible.

Original input/source/output hashes verified before and after audit. No private labels or generator were read/invoked; audit completed before label release. All artifacts reside outside frozen source. No source changes or midrun test changes.

Measured replay subprocess CPU: 49.255908s; parent relation/witness-audit CPU: 64.287796s; combined measured CPU: 113.543704s. Audit wall: 114.642196s. Each replay subprocess enforced30CPU-second/60-wall-second/2GiB address-space limits. All40 completed. Audit parent CPU/memory were NOT resource-capped, and audit/replay peakRSS was not instrumented; do not present the memory envelope as measured or enforced for the parent. Input/source/seal hashing preceding the parent audit timer and final receipt/seal serialization after it add small unmeasured overhead; retained timing is not an exact whole-command total.

The script did not tune or optimize based on results. The CPU measurement remains well within the allocated1200CPU-second replay allowance; the extra parent verification cost must also be charged to the overall3CPU-hour budget. No target/K4 execution occurred.

Receipt: audit-receipt.json. Output hashes: audit-output-sha256.json (created at completion before this narrative report; this report is supplementary and is not in that existing seal).
