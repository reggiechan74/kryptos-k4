import itertools as it,json
from collections import defaultdict
from math import comb
G=[0]+list(range(1,7))+list(range(1,7))+list(range(7,25))
assert len(G)==31
supports=[s for k in range(4) for s in it.combinations(range(31),k)]
betas=[b for k in range(4) for b in it.combinations(range(25),k)]
counts=defaultdict(set); maximal_counts=defaultdict(set); total=maximal_total=0; zero_inc=zero_beta=zero_maximal=0
for b in betas:
 B=set(b); n=sum(len(s)+len(B-set(G[i] for i in s))<=3 for s in supports)
 counts[str((len(b),sum(1<=g<=6 for g in b)))].add(n);total+=n
 nmax=sum(len(s)==3 and B<=set(G[i] for i in s) for s in supports)
 maximal_counts[str((len(b),sum(1<=g<=6 for g in b)))].add(nmax);maximal_total+=nmax
 # context all six symbols zero: constant and three indicators only
 if sum(g in {0,22,23,24} for g in b)%2==0:zero_inc+=n;zero_beta+=1;zero_maximal+=nmax
assert total==100916
# Completely fresh tiny dictionary x,x^2,[x=y], not v1 fixtures.
# Exhaust all modular coefficients and compare canonical descriptors with
# container admission for every budget0..3, then every possible observation
# syndrome on three independently chosen context sets.
thetas=list(it.product(range(26),repeat=3)); descriptors={}
for t in thetas:
 d=(tuple(v%13 for v in t),( (t[0]+t[1])%2,t[2]%2 ))
 descriptors[d]=min(descriptors.get(d,4),sum(v!=0 for v in t))
assert len(descriptors)==8788
contexts=[[(0,0)],[(1,2),(14,1)],[(2,2),(15,2),(3,4)]]
checks=0
for budget in range(4):
 direct={d for d,c in descriptors.items() if c<=budget}; contained=set()
 for a in it.product(range(13),repeat=3):
  T={i for i,v in enumerate(a) if v};groups=[0,0,1]
  for b in it.product(range(2),repeat=2):
   B={i for i,v in enumerate(b) if v}
   if any(T<=set(S) and len(S)+len(B-{groups[i] for i in S})<=budget for k in range(budget+1) for S in it.combinations(range(3),k)):
    contained.add((a,b))
 assert direct==contained
 for d in direct:
  a,b=d; T={i for i,v in enumerate(a) if v};B={i for i,v in enumerate(b) if v}
  assert any(T<=set(S) and B<={groups[i] for i in S} for S in it.combinations(range(3),budget))
 for ctx in contexts:
  def obs(d):
   a,b=d
   return tuple(((a[0]*x+a[1]*x*x+a[2]*(x==y))%13,(b[0]*x+b[1]*(x==y))%2) for x,y in ctx)
  left=defaultdict(set);right=defaultdict(set)
  for d in direct:left[obs(d)].add(d)
  for d in contained:right[obs(d)].add(d)
  assert left==right;checks+=len(left)
result={'container_counts':{k:list(v)[0] for k,v in counts.items()},'maximal_container_counts':{k:list(v)[0] for k,v in maximal_counts.items()},'maximal_total_incidences':maximal_total,'zero_context_maximal_incidences':zero_maximal,'total_unfiltered_incidences':total,'zero_context_matching_beta_count':zero_beta,'zero_context_compatible_container_incidences_before_mod13_filter':zero_inc,'tiny_mod26_vectors':len(thetas),'tiny_distinct_descriptors':len(descriptors),'budgets_checked':4,'nonempty_syndrome_relations_checked':checks,'passed':True}
print(json.dumps(result,indent=2))
