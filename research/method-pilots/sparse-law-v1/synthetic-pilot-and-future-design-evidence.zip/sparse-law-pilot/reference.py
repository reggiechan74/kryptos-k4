"""Independent, synthetic-development-only sparse modular affine oracle.

No target data or imports from the production implementation. Run directly for
small exhaustive development checks; these are not sealed holdout tests.
"""
from itertools import combinations, product
import math
import time


def _affine(rows, rhs, width, prime):
    """Return one point and nullspace basis, or None (field Gaussian elimination)."""
    aug = [[v % prime for v in row] + [v % prime] for row, v in zip(rows, rhs)]
    pivots = []
    for col in range(width):
        k = len(pivots)
        pivot = next((j for j in range(k, len(aug)) if aug[j][col]), None)
        if pivot is None:
            continue
        aug[k], aug[pivot] = aug[pivot], aug[k]
        inv = pow(aug[k][col], -1, prime)
        aug[k] = [(v * inv) % prime for v in aug[k]]
        for j in range(len(aug)):
            if j != k:
                c = aug[j][col]
                aug[j] = [(a - c * v) % prime for a, v in zip(aug[j], aug[k])]
        pivots.append(col)
    if any(not any(row[:width]) and row[width] for row in aug):
        return None
    point = [0] * width
    for k, col in enumerate(pivots):
        point[col] = aug[k][width]
    basis = []
    for free in range(width):
        if free not in pivots:
            vec = [0] * width
            vec[free] = 1
            for k, col in enumerate(pivots):
                vec[col] = -aug[k][free] % prime
            basis.append(vec)
    return point, basis


def _validate(A, I, b, s, primes):
    if not A:
        raise ValueError('At least one row required to establish column count')
    m = len(A[0])
    if any(len(row) != m for row in A):
        raise ValueError('Ragged matrix')
    if len(I) != len(b) or any(not isinstance(i, int) or not 0 <= i < len(A) for i in I):
        raise ValueError('Invalid observed indices or rhs length')
    if not isinstance(s, int) or s < 0:
        raise ValueError('Nonnegative integer sparsity required')
    if len(primes) != 2 or primes[0] == primes[1] or any(p < 2 or any(p % d == 0 for d in range(2, math.isqrt(p)+1)) for p in primes):
        raise ValueError('Exactly two distinct primes required')
    if any(not isinstance(x, int) for row in A for x in row) or any(not isinstance(x, int) for x in b):
        raise ValueError('Integer matrix and rhs required')
    return m


def solve(A, I, b, s=3, primes=(2, 13), dense=False):
    """Exact row marginals for ||theta||_0 <= s modulo product(primes).

    Same support is used in both fields. Dense=True visits only full support,
    ignoring s. Support count counts feasible *containers*, not unique programs.
    program_unique concerns coefficient vectors, not semantic law equivalence.
    At most two full coefficient witnesses are retained.
    """
    started, cpu = time.perf_counter(), time.process_time()
    m = _validate(A, I, b, s, primes)
    p, r = primes
    q = p * r
    def crt(x, y):
        return (x + p * (((y - x) * pow(p, -1, r)) % r)) % q
    supports = [tuple(range(m))] if dense else (S for k in range(min(s,m)+1) for S in combinations(range(m), k))
    masks = [0] * len(A)
    visited = feasible = 0
    witnesses = []
    first = None
    unique = True
    for S in supports:
        visited += 1
        observed = [[A[i][j] for j in S] for i in I]
        fs = [_affine(observed, b, len(S), t) for t in primes]
        if any(v is None for v in fs):
            continue
        feasible += 1
        (x, N), (y, M) = fs
        theta = [0] * m
        for k,j in enumerate(S):
            theta[j] = crt(x[k], y[k])
        if first is None:
            first = theta
        if theta != first or N or M:
            unique = False
        if theta not in witnesses and len(witnesses) < 2:
            witnesses.append(theta)
        if len(witnesses) < 2 and (N or M):
            xx = [(a + n) % p for a,n in zip(x, N[0])] if N else x
            yy = [(a + n) % r for a,n in zip(y, M[0])] if not N else y
            alt = [0] * m
            for k,j in enumerate(S):
                alt[j] = crt(xx[k], yy[k])
            if alt not in witnesses:
                witnesses.append(alt)
        for i,row in enumerate(A):
            v = [row[j] for j in S]
            dot = lambda z: sum(a*c for a,c in zip(v,z))
            px = range(p) if any(dot(z) % p for z in N) else [dot(x) % p]
            ry = range(r) if any(dot(z) % r for z in M) else [dot(y) % r]
            for a,c in product(px,ry):
                masks[i] |= 1 << crt(a,c)
    return {'masks': masks, 'modulus': q, 'feasible_support_count': feasible,
            'supports_visited': visited, 'program_unique': bool(feasible and unique),
            'program_status': 'empty' if not feasible else 'unique' if unique else 'multiple',
            'witnesses': witnesses, 'dense': dense,
            'elapsed_seconds': time.perf_counter()-started,
            'cpu_seconds': time.process_time()-cpu}


def exhaustive(A, I, b, s=3, primes=(2,13), dense=False):
    """Independent plain enumeration of every coefficient vector (tiny only)."""
    m = _validate(A,I,b,s,primes)
    q = math.prod(primes)
    masks = [0] * len(A)
    count = 0
    for theta in product(range(q), repeat=m):
        if not dense and sum(v != 0 for v in theta) > s:
            continue
        pred = [sum(a*t for a,t in zip(row,theta)) % q for row in A]
        if any(pred[i] != v % q for i,v in zip(I,b)):
            continue
        count += 1
        for i,v in enumerate(pred):
            masks[i] |= 1 << v
    return {'masks': masks, 'program_count': count, 'program_unique': count == 1}


def selftest():
    import random
    import json
    import platform
    rng = random.Random(20261031)
    start,cpu = time.perf_counter(),time.process_time()
    cases = [([[2],[1]],[0],[2],1,(2,3)),
             ([[2],[1]],[0],[1],1,(2,3)),
             ([[1,1],[2,2]],[0],[1],1,(2,13)),
             ([[0,0],[0,0]],[],[],0,(2,13)),
             ([[],[]],[0],[1],0,(2,13)),
             ([[1],[1]],[0,0],[1,2],1,(2,13)),
             ([[13,2],[1,1]],[0],[1],1,(2,13))]
    for primes,reps,maxm in [((2,3),120,4),((2,13),40,3)]:
        q=math.prod(primes)
        for _ in range(reps):
            n,m=rng.randrange(1,7),rng.randrange(maxm+1)
            A=[[rng.randrange(q) for _ in range(m)] for _ in range(n)]
            I=rng.sample(range(n),rng.randrange(n+1))
            b=[rng.randrange(q) for _ in I]
            cases.append((A,I,b,rng.randrange(min(3,m)+1),primes))
    checks=0
    for A,I,b,s,primes in cases:
        for dense in (False,True):
            actual=solve(A,I,b,s,primes,dense)
            expected=exhaustive(A,I,b,s,primes,dense)
            assert actual['masks']==expected['masks'], (A,I,b,s,primes,dense,actual,expected)
            assert actual['program_unique']==expected['program_unique']
            assert bool(actual['feasible_support_count'])==bool(expected['program_count'])
            for theta in actual['witnesses']:
                assert dense or sum(v!=0 for v in theta)<=s
                assert all(sum(a*t for a,t in zip(A[i],theta))%math.prod(primes)==v%math.prod(primes) for i,v in zip(I,b))
            checks+=1
    smoke=solve([[int(i==j) for j in range(31)] for i in range(31)], [0], [1])
    assert smoke['supports_visited']==4992
    assert smoke['feasible_support_count']==466
    assert smoke['masks'][0]==2 and all(v==(1<<26)-1 for v in smoke['masks'][1:])
    result={'status':'PASS','classification':'synthetic development only; no holdout or target',
            'seed':20261031,'cases':len(cases),'sparse_dense_comparisons':checks,
            'support_smoke':{k:smoke[k] for k in ('supports_visited','feasible_support_count','elapsed_seconds','cpu_seconds')},
            'python':platform.python_version(),'elapsed_seconds':time.perf_counter()-start,
            'cpu_seconds':time.process_time()-cpu}
    print(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    selftest()
