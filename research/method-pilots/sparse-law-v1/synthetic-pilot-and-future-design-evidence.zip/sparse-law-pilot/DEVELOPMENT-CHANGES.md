> **Historical development-stage record.** This public prose copy is not claimed byte-identical to the frozen original; see PUBLIC-PROVENANCE.json. Later blind results are separately archived. Any developmental “same message plaintext” or “global” prediction wording refers only to the 91 modeled positions 6–96 of that fixed trajectory, not recovery of the first six positions or global function identity.

# Preserved development corrections and limitations

No holdout was generated/revealed. No scientific solver mismatch occurred on the disclosed tests. The following audit findings remain part of the record; fixes do not erase earlier reviewed snapshots/hashes in reference-audit.md.

1. **RHS normalization interface mismatch.** Original join verifier asserted `sum(a*x for a,x in zip(A[r],t))%q==y`, although solver normalizes y moduloq. Corrected to `==y%q`. Declared fixtures already canonical, so their results unchanged. Explicit b27 modulo26 regression and48exhaustive cases rerun passed.
2. **Initial runner lacked source/input change guard.** Input was only hashed at end, source not pinned per worker. Added pre-execution source/input hashes, check before each child and at end. This was a static review gap, not an observed mutation. A change-and-revert between checks is outside this cooperative procedural guard; this is not hostile tamper resistance.
3. **Initial runner validated only join witnesses.** Added sparse support/observation verification for oracle witnesses and observation verification for dense witnesses. Both revised worker paths rerun on disclosed developmentcase0 and unchanged masks verified.
4. **First pre-unseal checker skipped all comparisons if any of4files absent:**
   ```python
   if len(results)<4:
       rows.append({'index':i,'status':'incomplete_process'});continue
   ```
   This would hide a complete oracle/join disagreement if plain had timed out. Corrected to compare each available complete pair independently and separately list missing/incomplete methods. Also enforce91mask entries/integer26bit values before zipped comparisons. Disclosed regression with missing plain still compared oracle/join; truncated masks rejected. This flaw was caught by static audit before any holdout execution.
5. **Blinding wording corrected.** Public raw lag features reveal C0..95 and structural strata; ciphertext/category anonymity is not claimed. True unobserved responses and coefficient labels remain withheld. Commitment byte scheme made explicit.
6. **Plain expansion cap:**5of12development cases exceeded100000product descriptors. Stored status `incomplete_expansion_cap`, never negative/unique. Compressed join and independent oracle completed every case.
7. **Model failure intentionally exposed:** out-of-family observational twin yielded one wrong conditional forced unknown response. Its observation equivalence is mathematically unavoidable; no mechanism-membership certificate claimed.

Development source corrections precede the candidate freeze. Any correction after future blind reveal requires a fresh namespace/seed and retains prior output/failure receipts. No performance rescue variant or asymmetric CRT optimization was introduced.
