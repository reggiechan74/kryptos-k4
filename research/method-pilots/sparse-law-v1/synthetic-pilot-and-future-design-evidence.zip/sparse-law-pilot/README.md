> **Historical development-stage record.** This public prose copy is not claimed byte-identical to the frozen original; see PUBLIC-PROVENANCE.json. Later blind results are separately archived. Any developmental “same message plaintext” or “global” prediction wording refers only to the 91 modeled positions 6–96 of that fixed trajectory, not recovery of the first six positions or global function identity.

# Exact sparse modular-law inference — DEVELOPMENT ONLY

Method pilot `sparse-law-pilot-v1` (benchmark, not a tested K4 hypothesis; no numbered study ID reserved). Created 2026-10-31. No target ciphertext/crib letters are input. No holdout has been generated or executed. No remote repository changed.

## Frozen model

Length97; positions6..96 only. Ciphertext-history dictionary: constant, lag1..6, their squares,15 lexicographic distinct pair products, three adjacent equality indicators. At most3 nonzero coefficients modulo26. Observed positions21..33 and63..73 (zero based) leave67 unknown positions in the91-row matrix. No claim covers positions0..5.

The model is nonlinear in observed history but linear in unknown coefficients. Given a fixed starting ciphertext history, causal encryption adds the feature dot product to plaintext. Hence decryption/re-encryption is exact for each law, although unknown law or model membership need not be identifiable.

## Implementations and exactness

`reference.py`, authored independently without reading join code, enumerates4992 support containers. For each common support it solves both CRT fields, retaining affine solution images. A linear coordinate's image is singleton or the whole field. CRT combines these images bijectively; their union across supports gives exact row marginals. Zero coefficients inside containers are permitted. Support over26 is the UNION of field supports. Feasible-container counts are not program counts.

`join.py` groups singleton/empty left atoms by exact observed byte signatures. Right descriptors are empty, singletons, and unordered pairs with repetition of775 nonzero weighted atoms. Every <=3-support coefficient vector has a left/right decomposition. Conversely every product contributes at most3 atoms and therefore at most3 nonzero combined coefficients. Repeats/cancellations remain legal. A bucket product is wholly admissible, so its coordinate sumsets are exact. No hash digest substitutes for equality. All matching pair descriptors are retained; no one-representative quotient loses full-output fibers. The returned relation plus atom index convention specifies complete coupled predictions; its coordinate marginals are NOT their Cartesian product. Development JSON summaries omit relation serialization, explicitly, rather than pretending to archive the full relation.

Empty relation produces zero masks and abstention. Nonempty singleton masks are **model-conditional forced values**, not universal truth. Every marginal value has a coefficient witness verified against all observed equations and the claimed coordinate. Plain join expands products and counts distinct coefficient vectors/full outputs when below a predeclared100000-product cap; above it is incomplete, never a negative result. The independently exact oracle remains the primary performance baseline. Dense oracle drops sparsity to measure the structural assumption's value.

## Independence, tests, accounting

All timed implementations are Python standard library, same matrix input and observations. Independent fixture author did not inspect solvers. Fixtures generate synthetic ciphertext trajectories and responses; solver payload excludes labels. DEVELOPMENT fixtures are disclosed and cannot later be relabeled blind. `test_join.py` uses exhaustive coefficient enumeration over mod2,3,6,26. Reference selftest separately exercises shared CRT support/nonunits, nullspaces, sparse/dense completion and inconsistent inputs. `run_development.py` launches each method in a fresh process,120CPU-second/2GiB address-space cap,150-second wall timeout, sequentially; logs include preprocessing, solve, witness verification and per-process maximum RSS. Compilation/import setup, all tests and retries count toward overall8CPU-hour/8GiB envelope. There is no speed claim from this development pilot. Stage comparisons are descriptive and depend on implementation choices.

## Prior art and limits

Cipher-function reconstruction from known plaintext is established (Guillot–Mesnager); sparse dictionary inference, finite-field Gaussian elimination/CRT, meet-in-the-middle joins and relative generalized Hamming weights are established. The local deliverable combines unknown nonlinear law inference with exact model-conditional plaintext prediction and fiber-preserving representation. Neither global novelty nor a new mathematical theorem is claimed. Complete exact methods recover identical information; advantages, if any, concern computational cost or representation, not stronger deductions from the same constraints.

For any ring, uniform prediction identifiability for sparsity s is equivalent to absence of a vector delta with support<=2s, A_I delta=0 and A_J delta!=0. Necessity follows by partitioning support into two <=s sets; sufficiency follows by subtracting two feasible laws. This uniform condition is not a case-specific rejection rule. On a fixed trajectory, different coefficient vectors may define identical outputs. Program uniqueness reported here means coefficient-vector uniqueness, NOT universal functional equivalence.

An out-of-family mechanism can agree on all24observations but differ elsewhere. Synthetic observational twins deliberately demonstrate confidently incorrect model-conditional predictions. Such errors cannot be universally detected from this observation contract.

## Execution boundary

Commands in this directory are static compile checks or synthetic DEVELOPMENT only. No historical-target replay or target evaluation is authorized. Approval requires review of the exact sealed protocol, generator, seeds, hashes and measured budget before any holdout execution. 

Public A's lag columns inherently reveal ciphertext positions0..95. This is expected observed information, not a label leak; only actual generating-law labels and unobserved responses are sealed. Anonymous IDs cannot conceal easily recognized structural strata. These are blind-to-truth tests, not blind-to-input-structure tests.
