"""Approved-stage public-input runner. Does not generate or access private labels.

Invocation requires explicit --approved-synthetic-holdout flag after parent approval.
No authorization is implied by this file or flag. No dataset has been run here.
"""
import argparse,gzip,hashlib,json,pathlib,resource,subprocess,sys,time
ROOT=pathlib.Path(__file__).parent

def worker(case_path,index,mode,dest):
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 resource.setrlimit(resource.RLIMIT_CPU,(30,30))
 start=time.process_time();wall=time.perf_counter()
 case=json.loads(pathlib.Path(case_path).read_text())[index]
 assert set(case)=={'id','A','I','b'}
 A,I,b=(case[x] for x in ('A','I','b'))
 assert len(A)==91 and all(len(row)==31 for row in A)
 assert I==list(range(15,28))+list(range(57,68))
 assert len(b)==24 and all(0<=x<26 for row in A for x in row) and all(0<=x<26 for x in b)
 prep=time.process_time()-start
 if mode in ('oracle','dense'):
  from reference import solve
  result=solve(A,I,b,dense=mode=='dense');result['status']='complete'
  for theta in result['witnesses']:
   assert mode=='dense' or sum(x!=0 for x in theta)<=3
   assert all(sum(x*y for x,y in zip(A[i],theta))%26==v for i,v in zip(I,b))
 else:
  from join import solve,verify
  result=solve(A,I,b,plain=mode=='plain',plain_limit=100000)
  verify(A,I,b,result)
 solve_time=time.process_time()-start-prep
 # Exact relation stored losslessly, in separate file. Serialize cost included.
 relation=result.pop('relation',None)
 serialization_start=time.process_time()
 if relation is not None:
  with gzip.open(str(dest)+'.relation.json.gz','wt') as f:
   json.dump({'atom_convention':'0=empty;1+j*25+(k-1)=(feature j,coefficient k)','relation':relation},f,separators=(',',':'))
 result.update(id=case['id'],mode=mode,measurement={'preprocessing_cpu_s':prep,'solve_and_verify_cpu_s':solve_time,'relation_serialization_cpu_s':time.process_time()-serialization_start,'cpu_s':time.process_time()-start,'wall_s':time.perf_counter()-wall,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
 pathlib.Path(dest).write_text(json.dumps(result,separators=(',',':')))

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='_worker':
  worker(sys.argv[2],int(sys.argv[3]),sys.argv[4],sys.argv[5]);sys.exit()
 ap=argparse.ArgumentParser();ap.add_argument('--approved-synthetic-holdout',action='store_true',required=True);ap.add_argument('--public',required=True);ap.add_argument('--output',required=True)
 args=ap.parse_args();inp=pathlib.Path(args.public).resolve();out=pathlib.Path(args.output);out.mkdir(exist_ok=False)
 def hashes():
  return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [inp,*sorted(ROOT.glob('*.py')),ROOT/'BLIND-PROTOCOL.md']}
 frozen=hashes();(out/'pre-execution-hashes.json').write_text(json.dumps(frozen,indent=2))
 cases=json.loads(inp.read_text());assert len(cases)==40 and len({x['id'] for x in cases})==40
 assert all(set(c)=={'id','A','I','b'} for c in cases)
 receipts=[];cpu_charged=0
 for i,case in enumerate(cases):
  for mode in ('oracle','join','dense','plain'):
   assert hashes()==frozen,'Source or public input changed during execution'
   if cpu_charged>=6000:raise RuntimeError('Initial stage aggregate CPU budget exhausted')
   dest=out/f'{i:02d}-{mode}.json';start=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN)
   try:
    p=subprocess.run([sys.executable,__file__,'_worker',str(inp),str(i),mode,str(dest)],capture_output=True,text=True,timeout=60)
    state='complete_process' if p.returncode==0 else 'failed_process';detail=p.stdout+p.stderr
   except subprocess.TimeoutExpired as e:state='wall_timeout';detail=str(e)
   after=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime;cpu_charged+=cpu
   if state!='complete_process':dest.with_suffix('.failure.txt').write_text(detail)
   receipts.append({'id':case['id'],'mode':mode,'process_status':state,'wall_s':time.perf_counter()-start,'inclusive_child_cpu_s':cpu,'cumulative_child_cpu_s':cpu_charged})
   (out/'process-receipts.json').write_text(json.dumps(receipts,indent=2))
 assert hashes()==frozen,'Source or public input changed during execution'
 manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file()}
 manifest['PUBLIC_INPUT_SHA256']=hashlib.sha256(inp.read_bytes()).hexdigest()
 (out/'sealed-output-sha256.json').write_text(json.dumps(manifest,indent=2))
