"""Exact synthetic matrix sparse inference. No target data. Stdlib only."""
from itertools import combinations_with_replacement
from time import process_time

def solve(A,I,b,s=3,q=26,plain_limit=1000000,plain=False):
    if s!=3: raise ValueError('This join implements sparsity <=3 only')
    n,m=len(A),len(A[0]); zero=(0,)*n
    # IDs encode (feature, coefficient); ID0 is empty. No representative quotient.
    meta=[None]+[(j,k) for j in range(m) for k in range(1,q)]
    values=[zero]+[tuple(k*row[j]%q for row in A) for j,k in meta[1:]]
    sigs=[bytes(v[i] for i in I) for v in values]
    left={}
    for a,z in enumerate(sigs): left.setdefault(z,[]).append(a)
    needed={bytes((v-x)%q for v,x in zip(b,z)):z for z in left}
    right={z:[] for z in needed}
    def add(a,d):
        z=bytes((x+y)%q for x,y in zip(sigs[a],sigs[d]))
        if z in right: right[z].append((a,d))
    add(0,0)
    for a in range(1,len(values)): add(0,a)
    for a,d in combinations_with_replacement(range(1,len(values)),2): add(a,d)
    relation=[(left[needed[z]],pairs) for z,pairs in right.items() if pairs]
    products=sum(len(ls)*len(rs) for ls,rs in relation)
    result={'masks':[0]*n,'status':'complete','products':products,
            'right_descriptors':sum(len(rs) for _,rs in relation),
            'left_descriptors':sum(len(ls) for ls,_ in relation),
            'matched_buckets':len(relation),'atom_count':len(values)}
    if plain and products>plain_limit:
        result.update(status='incomplete_expansion_cap',masks=None);return result
    witnesses=[{} for _ in A]
    def theta(ids):
        t=[0]*m
        for a in ids:
            if a:
                j,k=meta[a]; t[j]=(t[j]+k)%q
        return t
    if plain:
        outputs=set(); programs=set()
        for ls,rs in relation:
            for a in ls:
                for d,e in rs:
                    v=tuple((x+y+z)%q for x,y,z in zip(values[a],values[d],values[e]))
                    outputs.add(v);programs.add(tuple(theta((a,d,e))))
                    for i,x in enumerate(v):
                        result['masks'][i]|=1<<x;witnesses[i].setdefault(x,(a,d,e))
        result.update(distinct_programs=len(programs),distinct_outputs=len(outputs))
    else:
        for ls,rs in relation:
            # Exact marginal summaries, keeping original product relation separately.
            lv=[{} for _ in A];rv=[{} for _ in A]
            for a in ls:
                for i,x in enumerate(values[a]): lv[i].setdefault(x,a)
            for d,e in rs:
                for i,(x,y) in enumerate(zip(values[d],values[e])):
                    rv[i].setdefault((x+y)%q,(d,e))
            for i in range(n):
                for x,a in lv[i].items():
                    for y,(d,e) in rv[i].items():
                        v=(x+y)%q;result['masks'][i]|=1<<v
                        witnesses[i].setdefault(v,(a,d,e))
    result['witnesses']=[{str(v):theta(ids) for v,ids in w.items()} for w in witnesses]
    # Returning the full relation maintains cross-coordinate coupling. Callers may
    # serialize its exact descriptors; marginal masks are never a Cartesian set.
    result['relation']=[{'left':ls,'right':rs} for ls,rs in relation]
    return result

def verify(A,I,b,result,q=26):
    if result['status']!='complete':return
    for i,w in enumerate(result['witnesses']):
        assert sum(1<<int(v) for v in w)==result['masks'][i]
        for v,t in w.items():
            assert sum(x!=0 for x in t)<=3
            assert all(sum(a*x for a,x in zip(A[r],t))%q==y%q for r,y in zip(I,b))
            assert sum(a*x for a,x in zip(A[i],t))%q==int(v)
