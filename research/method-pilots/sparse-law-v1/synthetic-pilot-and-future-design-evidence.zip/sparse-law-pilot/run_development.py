"""Synthetic-only DEVELOPMENT measurement. Never a holdout runner."""
import json,sys,time,resource,subprocess,pathlib,hashlib
ROOT=pathlib.Path(__file__).parent
if len(sys.argv)>1:
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
 from fixtures import build_fixtures,solver_payload
 mode=sys.argv[1];idx=int(sys.argv[2]);start=time.process_time();wall=time.perf_counter()
 case=build_fixtures()[idx];inputs=solver_payload(case)
 prep=time.process_time()-start
 if mode=='oracle' or mode=='dense':
  from reference import solve
  r=solve(**inputs,dense=mode=='dense')
 else:
  from join import solve,verify
  r=solve(**inputs,plain=mode=='plain',plain_limit=100000)
  verify(**inputs,result=r)
  # Relation is retained during computation and exact pair counts reported.
  # Only marginals/witnesses serialized in dev summaries, not full-relation export.
  r.pop('relation',None)
 r['measurement']={'cpu_s':time.process_time()-start,'wall_s':time.perf_counter()-wall,'preprocessing_cpu_s':prep,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 r['name']=case['name'];r['mode']=mode
 print(json.dumps(r));sys.exit()
from fixtures import build_fixtures
out=ROOT/'development';out.mkdir(exist_ok=True)
report=[]
for idx,case in enumerate(build_fixtures()):
 results={}
 for mode in ('oracle','join','dense','plain'):
  dest=out/f'{idx:02d}-{mode}.json'
  p=subprocess.run([sys.executable,__file__,mode,str(idx)],capture_output=True,text=True,timeout=150)
  if p.returncode:
   dest.with_suffix('.failure.txt').write_text(p.stdout+p.stderr);raise RuntimeError((mode,idx,p.returncode))
  dest.write_text(p.stdout);results[mode]=json.loads(p.stdout)
 o,j,d,p=(results[m] for m in ('oracle','join','dense','plain'))
 assert o['masks']==j['masks'],case['name']
 if p.get('status')=='complete':assert p['masks']==o['masks']
 assert all(x&y==x for x,y in zip(o['masks'],d['masks']))
 J=[i for i in range(91) if i not in case['I']]
 forced=lambda x:sum(x[i]!=0 and x[i]&(x[i]-1)==0 for i in J)
 false=sum(o['masks'][i]!=0 and o['masks'][i]&(o['masks'][i]-1)==0 and o['masks'][i]!=(1<<case['truth'][i]) for i in J)
 if case['in_family']:assert all(mask&(1<<v) for mask,v in zip(o['masks'],case['truth'])) and false==0
 row={'name':case['name'],'in_family':case['in_family'],'forced_unknown':forced(o['masks']),'dense_forced_unknown':forced(d['masks']),'false_forced':false,'program_status':o['program_status'],'plaintext_unique':all(o['masks'][i] and o['masks'][i]&(o['masks'][i]-1)==0 for i in J),'products':j['products'],'retained_right':j['right_descriptors'],'plain_status':p['status'],'measurements':{m:r['measurement'] for m,r in results.items()}}
 report.append(row);(out/'summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
