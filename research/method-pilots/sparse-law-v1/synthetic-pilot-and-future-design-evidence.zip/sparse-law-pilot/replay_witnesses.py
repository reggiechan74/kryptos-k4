"""Independent causal replay of synthetic developmental witnesses, no target."""
import json,pathlib,time
from fixtures import build_fixtures
start=time.process_time();count=0
for idx,case in enumerate(build_fixtures()):
 r=json.loads((pathlib.Path(__file__).parent/'development'/f'{idx:02d}-join.json').read_text())
 laws={tuple(t) for w in r['witnesses'] for t in w.values()}
 for law in laws:
  # Separately form history features without importing feature_matrix.
  rebuilt=case['c'][:6]
  for row in range(91):
   mask=sum(a*t for a,t in zip(case['A'][row],law))%26
   plain=(case['c'][row+6]-mask)%26
   h=rebuilt[-6:][::-1]
   features=[1,*h,*(x*x%26 for x in h)]
   for a in range(6):
    for b in range(a+1,6):features.append(h[a]*h[b]%26)
   features.extend([int(h[0]==h[1]),int(h[2]==h[3]),int(h[4]==h[5])])
   rebuilt.append((plain+sum(x*y for x,y in zip(features,law)))%26)
  assert rebuilt==case['c']
  count+=1
print(json.dumps({'status':'PASS','distinct_per_case_laws_replayed':count,'cpu_seconds':time.process_time()-start}))
