"""Disclosed synthetic DEVELOPMENT fixtures. No target data and no holdout builder.

Solver input is ONLY ``solver_payload(case)``. Remaining keys are evaluator labels.
Feature order: 1; six lags; six squares; pairs (1,2),(1,3),...,(5,6);
three equalities (1,2),(3,4),(5,6). Rows 0..90 represent positions 6..96.
"""
import random
import time

MODULUS = 26
OBSERVED_GLOBAL = tuple(range(21, 34)) + tuple(range(63, 74))
OBSERVED_ROWS = tuple(i - 6 for i in OBSERVED_GLOBAL)
FEATURE_NAMES = (['constant'] + [f'lag{j}' for j in range(1, 7)] +
                 [f'lag{j}^2' for j in range(1, 7)] +
                 [f'lag{j}*lag{k}' for j in range(1, 7) for k in range(j+1, 7)] +
                 ['lag1=lag2', 'lag3=lag4', 'lag5=lag6'])


def feature_matrix(c):
    """Independent stdlib feature construction; strict 97-symbol input."""
    if len(c) != 97 or any(type(x) is not int or not 0 <= x < 26 for x in c):
        raise ValueError('c must contain exactly 97 integers in 0..25')
    result = []
    for i in range(6, 97):
        lag = [c[i-j] for j in range(1, 7)]
        row = [1] + lag + [x*x % 26 for x in lag]
        row += [lag[j]*lag[k] % 26 for j in range(6) for k in range(j+1, 6)]
        row += [int(lag[j] == lag[j+1]) for j in (0, 2, 4)]
        result.append(row)
    return result


def _case(name, c, coefficients):
    A = feature_matrix(c)
    theta = [0]*31
    for j, v in coefficients.items():
        theta[j] = v % 26
    truth = [sum(x*y for x, y in zip(row, theta)) % 26 for row in A]
    return dict(name=name, A=A, I=list(OBSERVED_ROWS),
                b=[truth[i] for i in OBSERVED_ROWS], c=list(c), truth=truth,
                theta=theta, in_family=True)


def solver_payload(case):
    """Copy public input only, preventing accidental label/ciphertext disclosure."""
    return {'A': [row[:] for row in case['A']], 'I': case['I'][:], 'b': case['b'][:]}


def hidden_plaintext(case):
    """Evaluator-only plaintext on positions 6..96; first six are undefined."""
    return [(c-t) % 26 for c, t in zip(case['c'][6:], case['truth'])]


def build_development_fixtures(seed=20261031):
    """Return twelve fully disclosed development cases, never fresh holdouts.

    Changing the seed does not make this disclosed design a blind evaluation.
    theta=None means no generating in-family coefficient vector exists.
    """
    rng = random.Random(seed)
    uniform = lambda: [rng.randrange(26) for _ in range(97)]
    cases = []
    for support in range(4):
        cols = rng.sample(range(31), support)
        coeff = {j: rng.randrange(1, 26) for j in cols}
        cases.append(_case(f'uniform_support_{support}', uniform(), coeff))
    cases.append(_case('uniform_zero_divisor_coefficients', uniform(), {1: 2, 8: 13}))
    repeated = [5]*97
    cases.append(_case('repeated_trajectory', repeated, {0: 7}))
    binary = [rng.randrange(2) for _ in range(97)]
    binary[0:2] = [0, 1]
    cases.append(_case('global_square_lag_alias', binary, {1: 3, 7: 4}))
    zero_windows = uniform()
    equal_windows = uniform()
    for i in OBSERVED_GLOBAL:
        for j in range(1, 7):
            zero_windows[i-j] = 0
            equal_windows[i-j] = 3
    # Global position 7 is not observed: lag1 and lag2 are controlled witnesses.
    zero_windows[6] = 9
    equal_windows[5:7] = [2, 9]
    cases.append(_case('zero_on_observations_only', zero_windows, {1: 11}))
    cases.append(_case('equal_on_observations_only', equal_windows, {1: 5, 2: 8}))
    inconsistent = _case('inconsistent_observations', repeated, {0: 7})
    inconsistent['truth'][OBSERVED_ROWS[0]] = 8
    inconsistent['b'][0] = 8
    inconsistent.update(theta=None, in_family=False)
    cases.append(inconsistent)
    cases.append(_case('null_trajectory_zero_response', [0]*97, {}))
    outside = _case('out_of_family_observational_twin', repeated, {0: 7})
    outside['truth'][0] = 8
    outside.update(theta=None, in_family=False)
    cases.append(outside)
    return cases


# Stable public alias for callers.
build_fixtures = build_development_fixtures


def self_test():
    """Shape, indexing, generating labels, and analytic adversarial witnesses."""
    cases = build_fixtures()
    assert len(cases) == 12 and len(FEATURE_NAMES) == 31
    assert OBSERVED_ROWS == tuple(range(15, 28)) + tuple(range(57, 68))
    assert cases == build_fixtures()
    for case in cases:
        assert len(case['A']) == 91 and all(len(r) == 31 for r in case['A'])
        assert len(case['truth']) == 91 and len(case['c']) == 97
        assert case['b'] == [case['truth'][i] for i in case['I']]
        assert len(case['b']) == 24
        assert set(solver_payload(case)) == {'A', 'I', 'b'}
        assert len(hidden_plaintext(case)) == 91
        if case['in_family']:
            theta = case['theta']
            assert sum(v != 0 for v in theta) <= 3
            assert case['truth'] == [sum(x*y for x,y in zip(row,theta)) % 26 for row in case['A']]
    by_name = {case['name']: case for case in cases}
    A = by_name['global_square_lag_alias']['A']
    assert all(row[1] == row[7] for row in A)
    A = by_name['zero_on_observations_only']['A']
    assert all(A[i][1] == 0 for i in OBSERVED_ROWS) and A[1][1] == 9
    A = by_name['equal_on_observations_only']['A']
    assert all(A[i][1] == A[i][2] for i in OBSERVED_ROWS) and A[1][1] != A[1][2]
    for name in ('inconsistent_observations', 'out_of_family_observational_twin'):
        case = by_name[name]
        assert all(row == case['A'][0] for row in case['A'])
        assert len(set(case['truth'])) > 1  # No coefficient vector of ANY support fits.
    assert len(set(by_name['inconsistent_observations']['b'])) > 1
    assert by_name['out_of_family_observational_twin']['b'] == by_name['repeated_trajectory']['b']
    null = by_name['null_trajectory_zero_response']
    assert all(row[1] == 0 for row in null['A']) and set(null['truth']) == {0}
    # An independently hand-computed row covers all feature blocks and pair order.
    c = list(range(26))*3 + list(range(19))
    row = feature_matrix(c)[0]
    assert row == [1,5,4,3,2,1,0,25,16,9,4,1,0,20,15,10,5,0,12,8,4,0,6,3,0,2,0,0,0,0,0]
    return {'cases': len(cases), 'status': 'passed'}


if __name__ == '__main__':
    start = time.perf_counter()
    print(self_test())
    print('development_fixture_self_test_seconds=%.6f' % (time.perf_counter()-start))
