"""Synthetic development function-vs-coefficient alias diagnostic only."""
import json
from fixtures import build_fixtures
case=next(x for x in build_fixtures() if x['name']=='repeated_trajectory')
a=[0]*31;a[0]=7
b=[0]*31;b[1]=17
for law in (a,b):assert all(sum(x*y for x,y in zip(row,law))%26==7 for row in case['A'])
# New context of six zeros: constant7 vs17*lag1=0.
fresh=[1]+[0]*27+[1]*3
values=[sum(x*y for x,y in zip(fresh,law))%26 for law in (a,b)]
assert values==[7,0]
# In contrast,13*(x^2-x)=0 identically mod26.
assert all(13*(x*x-x)%26==0 for x in range(26))
print(json.dumps({'classification':'development synthetic diagnostic','same_all_91_trace_outputs':7,'different_functions_fresh_context':[0]*6,'fresh_outputs':values,'laws':[a,b],'global_identity_13_square_minus_lag_verified_all26':True,'status':'PASS'}))
