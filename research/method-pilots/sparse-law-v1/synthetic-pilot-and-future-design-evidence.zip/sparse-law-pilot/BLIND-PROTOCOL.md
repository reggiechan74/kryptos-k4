> **Historical development-stage record.** This public prose copy is not claimed byte-identical to the frozen original; see PUBLIC-PROVENANCE.json. Later blind results are separately archived. Any developmental “same message plaintext” or “global” prediction wording refers only to the 91 modeled positions 6–96 of that fixed trajectory, not recovery of the first six positions or global function identity.

# Sparse-law pilot v1 — proposed frozen blind protocol

**NOT AUTHORIZED / NOT GENERATED / NOT EXECUTED.** Approval required. No target-stage authority exists. Frozen scientific model is exactly README's31-feature,≤3-coefficient law; no alternative21-feature/state model, model tuning, language scoring or target letters.

## Inputs and40-case allocation

Independent generator `blind_generator.py` is the exact specification.16 ordinary uniform-ciphertext plants, generating support0..3 four each;4 nonunit cases;4 repeated/global-alias cases;4 observation-only-alias cases;4 independent uniform ciphertext/response nulls (may or may not fit, unknown membership);4 exact inconsistent repeated-context cases;4 misspecified observational twins. No recovery-based rejection sampling. Construction checks may assert a structural condition; failure invalidates generation and requires recorded review, not silent reroll.

The custodian draws one new256-bit seed after approval and records SHA256(b"sparse-law-pilot-v1/blind40/seed\x00" + bytes.fromhex(SHA256(BLIND-PROTOCOL.md bytes)) + seed), rendered as lowercase hex. Store secret seed/labels separately; solver operator receives anonymous shuffled IDs and only A,I,b. Matrix construction has independently checked feature order and coordinates. Truth, coefficients and category labels remain evaluator-only until predictions are sealed. Matrix lag columns reveal ciphertext positions0..95, so ciphertext is not treated as secret; final symbol is not needed for response prediction. Anonymous IDs hide explicit labels, not structural clues from which strata can be inferred. Random ciphertext under a causal law defines valid synthetic plaintext; this is not a natural-language or uniform-plaintext claim. Custodian independence is procedural within a shared filesystem, not an OS security boundary; solver operator must not inspect private labels.

## Frozen methods and outputs

Execution driver `run_public.py` takes only anonymous public JSON and an explicit approval flag. It is statically compiled but has not been run on any holdout. Run independent support/CRT oracle, compressed exact join, dense oracle and plain join with100000-product cap. Same Python stdlib/language, identical inputs/feature definition. Each process retains and validates its outputs; masks and ambiguity witnesses serialized. For compressed join also archive exact factorized relation (atom convention plus left/right descriptor products), compressed losslessly, separately from marginal prediction summary. Equality of per-coordinate sets is primary exactness metric; tiny exhaustive comparisons support whole-relation correctness. Do not claim complete whole-output equality merely from marginal equality.

Mark timeout/cap/crash as INCOMPLETE, never UNSAT or unique. Retain partial/error receipts, no automatic rerun or omission. Unseal only after every method terminates and output/resource/source hashes are recorded. Any code correction after reveal requires a new holdout namespace/seed; original failure remains public.

## Resource and fairness contract

Sequential subprocesses,30CPU-second limit each,60-second wall limit,2GiB address-space limit each; overall8GiB.40×4×30 maximum4800CPU seconds initial run. One independent exact-oracle replay can add1200CPU seconds. Include data generation, imports, preprocessing, witness checks and output serialization; log stage timings separately so common dense preprocessing and optional relation serialization are not hidden. Do not count incomplete plain runs as wins. Conservative total pilot budget3CPU hours, including development120seconds and all audits/retries, well below outer8hours. Stop dependent stage on budget exhaustion. No installs/external code/paid services. No speculative CRT optimization added after freeze.

## Pass criteria and reporting

1. Zero primary exact projection disagreement, zero missing true in-family values, zero false in-family forced letters; every marginal witness verifies support/observations/claimed value and causal replay.
2. Report feasible/empty/incomplete separately. Report exact forced unknown coverage /67, all67-output identifiability and coefficient-vector uniqueness separately; no alias count as independent evidence.
3. Report dense-vs-sparse coverage difference. Null model fit is empirical; null rejection does not establish general calibration. Observational twins can give false model-conditional certainties and must explicitly illustrate misspecification.
4. Report paired wall/CPU/RSS and descriptor compression, not only aggregate medians. No claim of speed benefit unless consistent matched evidence warrants it; oracle remains recommended if stronger. This40-case diagnostic is not global performance proof.
5. No minimum recovery threshold triggers target admission. Success validates only bounded synthetic capability and exact implementation; failure is retained, not rescued by dictionary expansion.

## Freeze and approvals

`freeze-sha256.json` pins source, protocol, audit and development summaries. The approving reviewer reviews this exact set and measured feasibility before authorizing generation/execution. No seed commitment yet. Publication and ledger reconciliation must preserve canonical queue structure and external-prior-art limits. No numbered cipher hypothesis ID is consumed.

The40-case sample is a pre-reveal development-informed feasibility pilot, replacing the designs' larger conflicting proposals before any holdout generation. It supports diagnostic correctness/capability conclusions, not high-powered population statistics or a universal false-positive rate. Multiple coefficient vectors are not necessarily different cipher functions: report global algebraic aliases separately; any example claiming different functions must include an explicit fresh-context distinguishing witness.

Runner hash guard pins public input, all local Python sources and this protocol before the first child, checks them before every child and at end; the approved freeze manifest must match these source bytes. Driver checks coefficient witnesses from oracle/dense and all marginal witnesses from join. `check_public_outputs.py` is a separate pre-unseal comparison stage; run it and retain its receipt before label release. Its comparison is marginal, not joint-set equality. Post-unseal evaluator separately verifies planted truth inclusion/forced precision, category metrics and causal ciphertext replay; the driver does not read labels or enforce those post-unseal criteria. Inclusive parent child-CPU and wall receipts, not worker CPU alone, are the primary fair timing because worker final JSON serialization is outside its own sampled timer.
