import itertools,random,json,time,resource
from join import solve,verify
start=time.process_time();rng=random.Random(1801);cases=0
for q in (2,3,6,26):
 for trial in range(12):
  n,m=5,3 if q==26 else 4
  A=[[rng.randrange(q) for _ in range(m)] for _ in range(n)]
  if trial==1:A=[[0]*m for _ in range(n)]
  if trial==2:
   for row in A:row[1]=row[0]
  I=[0,1];b=[rng.randrange(q) for _ in I]
  masks=[0]*n;outputs=set();programs=0
  for t in itertools.product(range(q),repeat=m):
   if sum(x!=0 for x in t)>3:continue
   v=tuple(sum(a*x for a,x in zip(row,t))%q for row in A)
   if [v[i] for i in I]!=b:continue
   programs+=1;outputs.add(v)
   for i,x in enumerate(v):masks[i]|=1<<x
  for plain in (False,True):
   got=solve(A,I,b,q=q,plain=plain,plain_limit=2000000)
   assert got['masks']==masks,(q,trial,plain)
   verify(A,I,b,got,q)
   if plain:assert (got['distinct_programs'],got['distinct_outputs'])==(programs,len(outputs))
  cases+=1
print(json.dumps({'cases':cases,'methods_per_case':2,'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'status':'PASS'}))
