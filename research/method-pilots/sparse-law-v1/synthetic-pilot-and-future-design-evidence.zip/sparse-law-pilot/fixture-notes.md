> **Historical development-stage record.** This public prose copy is not claimed byte-identical to the frozen original; see PUBLIC-PROVENANCE.json. Later blind results are separately archived. Any developmental “same message plaintext” or “global” prediction wording refers only to the 91 modeled positions 6–96 of that fixed trajectory, not recovery of the first six positions or global function identity.

# Synthetic development fixture receipt and proposed blind design

2026-10-31 UTC.  This is independent fixture implementation, not a solver. No solver source, actual ciphertext, actual crib letters, target execution, or holdout generation was accessed/performed.  Only this file and `fixtures.py` were written.

## Contract and separation

`build_fixtures()` / `build_development_fixtures(seed=20261031)` returns 12 dictionaries with `name,A,I,b,c,truth,theta,in_family`. The default seed and every development outcome are disclosed. `solver_payload(case)` returns deep-enough copies of **only A,I,b**. Do not pass full fixtures to a solver. A is 91×31 over Z/26; row r corresponds to global index r+6. I is rows 15..27 and 57..67 (24 observations). `truth` is the full 91-position mask response, not plaintext. Evaluator-only `hidden_plaintext(case)` computes `(c[6:]-truth) mod 26`; no prediction is asserted for positions 0..5. `theta` is a length-31 coefficient vector for positive cases and `None` for genuinely out-of-family cases. Generating theta is not necessarily uniquely recoverable or minimal.

Columns (zero based): 0 constant; 1..6 lag1..lag6; 7..12 their squares; 13..27 all pair products in lexicographic lag-index order; 28..30 the stated equality indicators. Values are reduced modulo26. Inputs are strict 97-symbol integer sequences. Seed changes remain development, never evidence of a fresh blind holdout.

## Disclosed cases and independently verified witnesses

| Case | Construction / purpose |
|---|---|
| uniform_support_0..3 | Four uniform independent ciphertext trajectories, exact sampled generating support 0..3, uniformly sampled nonzero residues. |
| uniform_zero_divisor_coefficients | Uniform trajectory, lag1 coefficient2 and lag2-square coefficient13; explicit nonunit CRT behavior. |
| repeated_trajectory | Constant ciphertext5; all feature rows identical; constant coefficient7. Many coefficient aliases, but every compatible law predicts the same constant mask globally. |
| global_square_lag_alias | Binary ciphertext; lag1 and lag1-square columns equal on every row. Coefficients3 and4 collapse to coefficient7 on lag1. |
| zero_on_observations_only | Set all ciphertext windows feeding observed rows to0; lag1 is zero at every observation but equals9 at row1. Generating lag1 coefficient11 is hidden by observed zeros. |
| equal_on_observations_only | Set all observed lag windows to3; lag1 and lag2 coincide at observations but controlled row1 is (9,2). Generating coefficients5,8 admit observation-equivalent alternatives with differing full predictions. |
| inconsistent_observations | Constant5 trajectory; truth normally7 but first observed response8. Identical A rows with distinct observed responses prove contradiction for any coefficient support, not merely support≤3. |
| null_trajectory_zero_response | Zero ciphertext; zero generating response. All lag/square/product columns zero globally, all equality columns equal constant. Demonstrates null coefficient freedom without plaintext ambiguity. |
| out_of_family_observational_twin | Exact same A,I,b as repeated_trajectory; response at unknown row0 changed7→8. Identical A rows and differing full truth prove no coefficient vector of any support fits, while all observations remain consistent. |

A zero response is distinct from an inconsistent response. A globally aliased coefficient is distinct from an observational alias that changes unobserved predictions. Out-of-family status alone cannot be detected when all supplied observations agree; the twin deliberately tests honest conditional reporting rather than impossible rejection.

## Validation receipt

Command classification: **synthetic development only**.

`python3 ../sparse-law-pilot/fixtures.py`

Observed output: `{'cases': 12, 'status': 'passed'}`; internal `perf_counter` elapsed **0.010694 seconds** on this environment, not a solver timing. Checks include dimensions, observation indexing, reproducibility, label/observation agreement, support limits, generating-law evaluation, public-key separation, global and observation-only alias witnesses, impossible-law proofs, observational-twin equality, and a fully hand-computed 31-feature row. No holdout or solver evaluation ran here.

## Proposed 32-case blind design — NOT GENERATED, NOT AUTHORIZED

Recommend 32 rather than48 initially, pending measured solver resources: 16 uniform in-family cases (four each exact generating supports0,1,2,3), four deliberate nonunit cases (2 and13 individually and together, varying supports), three trajectory-degeneracy/global-alias cases, four observation-only ambiguity cases (two zero-observation columns, two equal-only-at-observation columns), two exact inconsistent cases, and three out-of-family observation twins. Any48-case expansion requires a revised preapproved allocation; do not add cases adaptively after results.

Before generation, freeze solver code, reference code, fixture generator/version, case allocation, support≤3, exactness/timeout definitions, prediction-set metrics, budgets and stopping rules. An independent custodian draws a new 256-bit random seed **after approval**, stores it privately, and publishes SHA-256 of a domain-separated record containing protocol hash and seed. No seed or commitment has been created by this implementation. Generate once; do not reroll difficult cases. Keep a private manifest including seed, generating vectors, full truth, category and proofs/witnesses. Pass anonymous case IDs and only A,I,b to execution workers; even names are withheld because names leak strata. Store labels and public inputs in different locations/access scopes, not merely different keys of one file.

Compare optimized and independent-reference outputs before labels are revealed. Freeze result hashes before unsealing. Score exact existence/contradiction, per-position prediction sets, whether true mask is included, certified forced vs ambiguous positions, and resource limits. Do not score recovery of generating coefficients as identification, or penalize an observational twin's undetectable out-of-family provenance as missed contradiction. Fixed ciphertext converts mask prediction sets bijectively to plaintext sets. Positive cases should contain full true masks; negative inconsistent cases should be unsatisfiable; out-of-family twins can have consistent observations yet wrong forced unobserved values, illustrating conditional-model limitations.

The custodian must verify engineered conditions independently (not assume fixture titles establish them) and predeclare treatment of resource exhaustion as inconclusive. These development cases are permanently contaminated for any subsequent blind claim.

## Concrete 40-case freeze candidate (supersedes the 32-case suggestion above)

Authored `blind_generator.py`, version `blind40-v1`, **code only**. The earlier 32-case allocation is retained as proposal history, not the current candidate. No blind cases, secret seed, seed commitment, public inputs or private labels have been generated. Approval remains required before invoking `make`.

`make(seed)` requires exactly32 externally supplied secret bytes and returns `(public_cases, private_labels)`. It imports only stdlib `random` and the independently authored development module's deterministic `feature_matrix` and observation constants; it never imports any solver or calls the development fixture builder. A local `random.Random(seed)` controls all choices, with no global RNG, reroll, retry, seed creation, filesystem writes or main execution. Freeze both generator and dependency file hashes and Python version before seed creation. Static verification was only `compile(source_bytes, filename, 'exec')`, which passed; **the module was not imported or executed**.

Exact40-case allocation:

1. **16 ordinary in-family**: four each generating supports0,1,2,3; uniform97-symbol ciphertext, distinct sampled feature columns, uniform nonzero residues1..25. Generating support is not a claim about minimal support.
2. **4 explicit nonunit**: generating coefficient lists `[2]`, `[13]`, `[2,13]`, `[2,13,5]` assigned to distinct random feature columns on uniform trajectories.
3. **4 global aliases**: two constant trajectories with random constant-law coefficient, plus two binary trajectories with coefficients3 on lag1 and4 on its square. Binary positions5,6 are fixed0,1 to guarantee both lag values occur. Assertions independently verify identical full rows or full-column equality.
4. **4 observation-only aliases**: two uniform trajectories overwritten in observed six-lag windows with zeros and controlled ciphertext position6=9; generating coefficient11 on lag1. Two uniform trajectories overwritten with a random common observed-window symbol and controlled positions5,6=(2,9); coefficients5,8 on lag1,lag2. Assertions verify observed zero/equality, full-row disagreement, and nonzero mask differences against observation-compatible alternatives. These engineered strata intentionally expose the same *class* of vulnerability as development but contain fresh independently seeded trajectories; they are not a new conceptual holdout and must be described as a fresh-seed, predefined-stratum blind evaluation.
5. **4 independent-response nulls**: uniform random ciphertext and independently uniform91-symbol full response mask. The observed b is its24-position restriction. Private labels use `in_family=None`, `theta=None`; accidental sparse fits are possible. Do **not** assume these are contradictions or count a compatible fit as a solver error. Exact membership derives only from the independent-reference comparison, not fixture provenance.
6. **4 exact inconsistent repeated-context cases**: constant random ciphertext, constant random baseline response, one random observed position changed by a nonzero residue. All feature rows equal but b has two values, proving no law of any support fits. Private `in_family=False`, `theta=None`.
7. **4 out-of-family observational twins**: constant random ciphertext, constant baseline response, one random *unobserved* response changed by a nonzero residue. Full truth cannot equal any linear feature response, whereas observations exactly match the coefficient-on-constant law. Such twin baselines need not appear as separate cases. Private witnesses record the compatible constant coefficient and changed unknown row.

Generation-time assertions check every imposed witness; they are code awaiting authorized execution, not a report that blind fixtures passed. Assertion failure must invalidate/report the generator attempt without adaptive reroll. An approved repair would require a new freeze and newly committed seed, preserving the failed receipt.

All40 cases are shuffled once; IDs `case-001`..`case-040` are assigned *after* the shuffle. Public dictionaries contain exactly `id,A,I,b`. Category, ciphertext, generating theta, full91-symbol truth, plaintext and analytical witnesses occur only in the separate private-label mapping. IDs do not encode category, though input degeneracy can intrinsically reveal a stratum. The caller/custodian must enforce actual access separation; returning separate objects is not itself an access-control boundary. Never send the tuple or private mapping to the solver workers. The seed must remain secret until result hashes are frozen; a commitment is only created after approval. Keep resource exhaustion distinct from contradiction, and do not use newly revealed outcomes to tune and rescore this same blind set.
