"""FROZEN-CANDIDATE 40-case blind generator. CODE ONLY; invocation needs approval.

No seed generation, CLI, solver import, persistence, or execution at import time.
Call make(secret_seed_bytes) only after protocol approval. Return two separate
objects: anonymous public solver cases and private evaluator labels.
"""
import random
from fixtures import feature_matrix, OBSERVED_GLOBAL, OBSERVED_ROWS

GENERATOR_VERSION = 'blind40-v1'


def make(seed):
    """Build once from a custodian-supplied 32-byte secret; never reroll results.

    Returns (public_cases, private_labels). Public keys: id,A,I,b only.
    Private in_family=None denotes unclassified independent-response nulls.
    Invocation is NOT authorized merely because this function exists.
    """
    if type(seed) is not bytes or len(seed) != 32:
        raise ValueError('supply exactly 32 externally generated secret bytes')
    rng = random.Random(seed)
    cases = []
    def uniform():
        return [rng.randrange(26) for _ in range(97)]
    def add(category, c, coeff, truth=None, in_family=True, witness=None):
        A = feature_matrix(c)
        theta = [0]*31 if coeff is not None else None
        if coeff is not None:
            for j, value in coeff.items():
                theta[j] = value % 26
        if truth is None:
            truth = [sum(a*t for a,t in zip(row,theta)) % 26 for row in A]
        assert len(truth) == 91 and all(type(x) is int and 0 <= x < 26 for x in truth)
        b = [truth[i] for i in OBSERVED_ROWS]
        if in_family is True:
            assert theta is not None and sum(t != 0 for t in theta) <= 3
            assert truth == [sum(a*t for a,t in zip(row,theta)) % 26 for row in A]
        elif in_family is False:
            assert theta is None
        public = dict(A=A, I=list(OBSERVED_ROWS), b=b)
        private = dict(category=category, c=c[:], truth=truth[:], theta=theta,
                       in_family=in_family, witness=witness,
                       plaintext=[(v-t) % 26 for v,t in zip(c[6:],truth)])
        cases.append((public, private))
        return A, b

    # 16 ordinary cases: four per exact generating support. No rejection sampling.
    for support in range(4):
        for _ in range(4):
            cols = rng.sample(range(31), support)
            coeff = {j: rng.randrange(1,26) for j in cols}
            add('ordinary_support_%d' % support, uniform(), coeff)

    # Four explicit CRT/nonunit generating-coefficient cases.
    for values in ([2], [13], [2,13], [2,13,5]):
        cols = rng.sample(range(31), len(values))
        add('nonunit', uniform(), dict(zip(cols,values)))

    # Two repeated trajectories: every feature row is identical.
    for _ in range(2):
        value = rng.randrange(26)
        A, _ = add('global_repeated', [value]*97,
                   {0:rng.randrange(1,26)}, witness={'identical_rows': True})
        assert all(row == A[0] for row in A)
    # Two binary trajectories: square(lag1) equals lag1 globally.
    for _ in range(2):
        c = [rng.randrange(2) for _ in range(97)]
        c[5:7] = [0,1]  # Guarantee lag1 takes both values on eligible rows.
        A, _ = add('global_binary_alias', c, {1:3,7:4},
                   witness={'equal_columns_global':[1,7]})
        assert all(row[1] == row[7] for row in A)
        assert {row[1] for row in A} == {0,1}

    # Two columns-zero-on-observations cases, with explicit nonzero witness.
    for _ in range(2):
        c = uniform()
        for i in OBSERVED_GLOBAL:
            for lag in range(1,7):
                c[i-lag] = 0
        c[6] = 9
        A, _ = add('observation_zero_alias', c, {1:11},
                   witness={'column':1,'unknown_row':1,'value':9})
        assert all(A[i][1] == 0 for i in OBSERVED_ROWS)
        assert A[1][1] == 9 and 11*A[1][1] % 26 != 0
    # Two columns-equal-only-on-observations cases.
    for _ in range(2):
        c = uniform()
        value = rng.randrange(26)
        for i in OBSERVED_GLOBAL:
            for lag in range(1,7):
                c[i-lag] = value
        c[5:7] = [2,9]
        A, _ = add('observation_equal_alias', c, {1:5,2:8},
                   witness={'columns':[1,2],'unknown_row':1})
        assert all(A[i][1] == A[i][2] for i in OBSERVED_ROWS)
        assert A[1][1] != A[1][2]
        # Support-one coefficient13 on lag1 shares observations but not row1.
        assert (5*A[1][1]+8*A[1][2]-13*A[1][1]) % 26 != 0

    # Four independently uniform response nulls: NOT certified contradictions.
    for _ in range(4):
        c = uniform()
        truth = [rng.randrange(26) for _ in range(91)]
        add('independent_response_null', c, None, truth, in_family=None,
            witness={'membership':'unclassified; determine by exact solver'})

    # Four certified contradictions: same A row, different observed b values.
    for _ in range(4):
        value, base = rng.randrange(26), rng.randrange(26)
        truth = [base]*91
        altered = rng.choice(OBSERVED_ROWS)
        truth[altered] = (base+rng.randrange(1,26)) % 26
        A, b = add('inconsistent_repeated_context', [value]*97, None, truth,
                   in_family=False, witness={'altered_observed_row':altered})
        assert all(row == A[0] for row in A) and len(set(b)) == 2

    # Four out-of-family twins: observations match a constant coefficient law.
    unknown = [i for i in range(91) if i not in OBSERVED_ROWS]
    for _ in range(4):
        value, base = rng.randrange(26), rng.randrange(26)
        truth = [base]*91
        altered = rng.choice(unknown)
        truth[altered] = (base+rng.randrange(1,26)) % 26
        A, b = add('out_of_family_observational_twin', [value]*97, None, truth,
                   in_family=False,
                   witness={'altered_unknown_row':altered,
                            'compatible_constant_coefficient':base})
        assert all(row == A[0] for row in A)
        assert len(set(truth)) == 2 and set(b) == {base}
        assert all(row[0]*base % 26 == y for row,y in zip([A[i] for i in OBSERVED_ROWS],b))

    assert len(cases) == 40
    rng.shuffle(cases)  # Anonymous order carries no explicit category labels.
    public_cases, private_labels = [], {}
    for number, (public, private) in enumerate(cases):
        case_id = 'case-%03d' % (number+1)
        public_cases.append(dict(id=case_id, **public))
        private_labels[case_id] = private
    assert all(set(c) == {'id','A','I','b'} for c in public_cases)
    return public_cases, private_labels
