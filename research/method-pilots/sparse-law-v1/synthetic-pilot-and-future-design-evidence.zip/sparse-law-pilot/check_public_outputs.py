"""Pre-unseal primary projection comparison; never reads labels/generator."""
import argparse,json,pathlib

def check(path):
 path=pathlib.Path(path);rows=[]
 for i in range(40):
  files={m:path/f'{i:02d}-{m}.json' for m in ('oracle','join','dense','plain')}
  results={m:json.loads(p.read_text()) for m,p in files.items() if p.exists()}
  complete={}
  for m,r in results.items():
   if r.get('status')=='complete':
    assert isinstance(r.get('masks'),list) and len(r['masks'])==91,('invalid mask shape',i,m)
    assert all(type(x) is int and 0<=x<(1<<26) for x in r['masks']),('invalid masks',i,m)
    complete[m]=r
  assert len({r['id'] for r in results.values()})<=1,('case id mismatch',i)
  comparisons=[]
  if 'oracle' in complete and 'join' in complete:
   assert complete['oracle']['masks']==complete['join']['masks'],('primary disagreement',i)
   comparisons.append('oracle_join_exact')
  if 'oracle' in complete and 'dense' in complete:
   assert all(x&y==x for x,y in zip(complete['oracle']['masks'],complete['dense']['masks'])),('dense subset',i)
   comparisons.append('oracle_subset_dense')
  if 'oracle' in complete and 'plain' in complete:
   assert complete['plain']['masks']==complete['oracle']['masks'],('plain disagreement',i)
   comparisons.append('oracle_plain_exact')
  rows.append({'index':i,'status':'primary_exact_agreement' if 'oracle_join_exact' in comparisons else 'primary_incomplete',
               'comparisons':comparisons,'missing_methods':sorted(set(files)-set(results)),
               'incomplete_methods':sorted(set(results)-set(complete))})

 return rows
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('output_directory');a=ap.parse_args()
 print(json.dumps(check(a.output_directory),indent=2))
