> **Historical development-stage record.** This public prose copy is not claimed byte-identical to the frozen original; see PUBLIC-PROVENANCE.json. Later blind results are separately archived. Any developmental “same message plaintext” or “global” prediction wording refers only to the 91 modeled positions 6–96 of that fixed trajectory, not recovery of the first six positions or global function identity.

# Independent reference audit — synthetic development only

Date: 2026-10-31 UTC.  Repository AGENTS, policy, current hypothesis state/queue, and experiment/prior-art introductions read. No cipher experiment selected. No actual K4 ciphertext or crib data read or executed; no holdout generated or executed. No external writes. 

## Independence and reproducibility

`reference.py` was authored without reading the primary implementation. It imports Python standard-library modules only and contains its own field elimination, CRT reconstruction, exhaustive tiny oracle and synthetic checks.

Command, classified **synthetic development validation**:

```sh
python3 ../sparse-law-pilot/reference.py
```

Run: Python 3.12.14; deterministic `random.Random(20261031)`; PASS. 167 input cases, each tested in sparse and dense modes: **334 exact comparisons** against plain enumeration of every coefficient vector, with matching full row masks, emptiness and coefficient uniqueness. Witness feasibility/sparsity also checked. Bounds: 120 randomized modulus-6 matrices with 1–6 rows and 0–4 columns; 40 randomized modulus-26 matrices with 1–6 rows and 0–3 columns; seven explicit edge cases. Sparsity ranges 0 through min(3,m). Includes empty observations, zero-column matrices, inconsistent duplicate observations, nonunit coefficients, duplicate-column aliases and impossible relations.

Measured suite wall time **0.726968263 seconds**, process CPU **0.726968558 seconds**. Separate 31-column synthetic identity smoke visits **4,992** supports and finds **466** feasible support containers, row0 exactly1 and every other row unrestricted. Smoke wall **0.080302999 seconds**, CPU **0.080307828 seconds**. These are observed development timings, not speedup claims or blind resource benchmarks.

## Mathematics

For each support container S of size at most s, solve `A[I,S] theta=b` independently over F2 and F13 **using the same S**. Each consistent solution set is a particular point plus a nullspace. The image of a scalar row functional on an affine space over a prime field is either a singleton (annihilates every basis direction) or the entire field. Enumerating the Cartesian product of those two images and applying CRT gives the exact modulo26 image for that row on this support. Union across all supports gives exact per-row marginals for every coefficient vector of modular nonzero count at most s. Allowing zero coefficients within a support is necessary; duplicate support descriptions are harmless for union masks.

The identity smoke support count is 1 + 30 + C(30,2) = 466. The total domain is 1 + 31 + C(31,2) + C(31,3) = 4,992.

A regression explicitly tests observation `[13,2] theta=1 (mod26)` with s=1. Each field separately has a one-column explanation but on different columns; no shared one-column support is feasible. Combining field results across different supports would incorrectly admit this case.

Coefficient-vector uniqueness is exact: any feasible support with a nonzero nullspace in either field gives at least two modular vectors; otherwise each support yields one reconstructed vector, compared across supports. Up to two distinct coefficient witnesses are retained. Feasible-support count is **not** a count of distinct vectors, laws, or plaintexts. Dense mode checks the single full support and has no sparsity restriction.

## Limits and interpretation

- Masks are exact **marginal** sets, not a representation of all jointly compatible output sequences. Arbitrary per-position selections may be mutually inconsistent.
- `program_unique` means uniqueness of the coefficient vector in the chosen feature coordinates. Duplicate/identical feature functions can produce different vectors with identical output. This does not decide semantic global-law uniqueness. If every output mask is a singleton and the relation is nonempty, the entire output vector on the supplied rows is unique even if the coefficient vector is not.
- A zero mask means no compatible program; do not confuse emptiness with identifiability or a full prediction alphabet.
- Supports count containers, including redundant supersets. The solver is generic matrix arithmetic, not a claim that ciphertext lag features capture the true mechanism.
- The reference requires at least one matrix row to infer m; n=0 is rejected explicitly. Zero columns are supported. Indices are zero-based; repeated observations are preserved and contradictions detected.
- Exactly two distinct prime factors are supported, including (2,3) for modulus6 tests. Repeated prime-power moduli require different algebra and are rejected.
- These are development tests, now revealed. They cannot serve as a later blind holdout. Neither target eligibility nor held-out recovery is established.

## Method lesson and next gate

The development oracle is inexpensive at tiny dimensions and caught no disagreement in this run. The core risk is semantic rather than timing: independently unioning field supports destroys sparsity coupling; counting support descriptions overstates program counts; singleton marginals and coefficient uniqueness answer different questions. Retain exact support coupling and independent brute-force checks. Next validation should compare the primary implementation against this reference, then freeze source hashes and an independently generated, unrevealed validation protocol before any additional authorized holdout. No holdout or target step has started here.

## Post-reference-freeze review of primary join

The reference was finalized at SHA-256 `d298355a973ee126262346102cc607552e67ec6aaacf5f3f46f8c57b86e3d93e` **before** reading `join.py`. Subsequent review therefore did not influence reference implementation. Source review confirms exact coverage: each sparse vector of support <=3 has a decomposition into zero or one left atom plus zero to two right atoms. Repeated-feature atoms are permitted but sum to another vector of support <=3, so they introduce descriptions rather than invalid vectors. Sorting right atom pairs loses no vector. For a given observed signature, every left descriptor and every matching right descriptor form a valid pair, so separately reducing row values within one matched bucket preserves each marginal image and permits reconstructible full-program witnesses. Full descriptor products remain in the returned relation; masks are not substituted for this coupling.

Additional **revealed synthetic development tests**, seed `789321`, used 60 modulus6 and 40 modulus26 random matrices with n=1–7, m=0–4 and random observation subsets/RHS. All 100 cases matched independent reference masks, fast-join masks and plain-expanded-join masks. All row/value witnesses checked with `join.verify`; reference coefficient uniqueness agreed with deduplicated plain-join program counts. For m<=3, those counts also matched independent exhaustive coefficient enumeration. Total **3,531,657 descriptor products**, wall **8.382931896 seconds**, CPU **8.381074078 seconds**. PASS; no holdout or target input.

One interface caveat was recorded during review: `join.solve` reduces RHS values modulo q during signature matching, while `join.verify` compares reconstructed residues to raw RHS values. Noncanonical b therefore works in solve but can fail verification. Either require/document 0<=b<q or normalize RHS in verify. Declared normalized modulo26 fixtures are unaffected. The join bytes representation also implies q<=256 and should not be advertised as supporting arbitrary large moduli without validation.

## Static-only proposed blind40 review — 2026-10-31 18:02 UTC

Reviewed `blind_generator.py`, `BLIND-PROTOCOL.md`, and the imported feature definition by reading source text only. **Did not import, execute, compile or invoke the generator; did not create/request/read a seed or generate any blind cases.** Review snapshots:

- Generator SHA-256: `c0d9cadf1cb1678b5afdbfd692709af742fe359edb22b13a5a10d110e8be86b3`.
- Protocol SHA-256: `dc9d2ecaf4fed16ab6d410a5320f0f36924e197aa09f27e8b16f9c04888c0334`.

Static allocation is exactly 40: 16 ordinary (four per generating support 0–3), four nonunit, four globally repeated/binary-alias, four observation-only aliases, four unclassified independent-response nulls, four certified inconsistent observations, and four out-of-family observational twins. Thus 28 cases are declared in-family, four deliberately unclassified, and eight analytically out-of-family on the full trajectory. No minimum-support or unique-law claim is warranted from the planted generating support.

Construction invariants are sound on source inspection. Observed lag windows occupy ciphertext indices15–32 and57–72; manual witnesses at indices5/6 cannot disturb those windows. Binary lag1 takes both0 and1 and equals its square. Repeated context forces every full response row equal for every coefficient vector, so differing observed b proves inconsistency even for dense laws, while an altered unobserved response is outside the model but observationally compatible with a constant coefficient. Independent response nulls correctly remain unclassified. A fixed seed makes sampling deterministic; no success-based rejection/reroll occurs. Runtime assertions are proposed checks, **not yet executed evidence**.

Protocol correctly distinguishes marginal equality from joint relation equality, incomplete from empty, coefficient uniqueness from function identity, model-conditional certainty from truth, and diagnostic pilot evidence from broad calibration/target admission. It specifies no automatic target advancement. Four methods ×40 cases ×30CPU seconds = 4,800CPU seconds; one40-case oracle replay adds1,200CPU seconds. The3CPU-hour budget leaves overhead room but execution enforcement and custodial separation remain unverified until an authorized runner is reviewed. Shared-filesystem procedural blinding is explicitly weaker than access isolation.

Two pre-freeze clarifications were requested:

1. **Ciphertext leakage through public features:** A contains raw lag1..6 columns. These disclose ciphertext indices0..95 exactly; only index96 is absent. This is inherent and legitimate for the inference problem, but ciphertext should not be described as a secret blind label. Truth, planted theta, evaluator category and final ciphertext symbol remain excluded from the public record. Repeated/binary structural categories are also inferable from A, so anonymous shuffled IDs are not category-blindness. The important protection is unrevealed true responses on unknown rows and fixed code before label reveal.
2. **Commitment byte convention:** specify an exact domain tag, encoding of the pinned protocol SHA-256, concatenation order/separators and32-byte raw-seed treatment. “Domain-separated protocol hash+seed” alone is insufficient for interoperable reproduction. Do not commit a mutable self-referential protocol hash; pin the approved precommit protocol artifact.

No generator source defect requiring execution was found. Approval remains pending; this is source review, not a passed blind test. The implementation review reports the earlier join RHS-normalization issue corrected (`y % q`) and48 primary regression tests rerun successfully; that report does not retroactively alter the first reviewed source snapshot.

### Reproducible comparison source

The exact body of the earlier 100-case stdin command is now preserved as `independent_join_audit.py` (with a provenance-only module docstring). It was transcribed directly from the retained tool call, without altering test logic or seed. Run `python3 independent_join_audit.py` from this directory. No rerun was needed merely to preserve the already executed command; its recorded timing belongs to the original stdin execution, not a later execution of this file.

## Static runner review — 2026-10-31 18:03 UTC

Reviewed source only; no runner or generator execution in this review. Initial reviewed runner SHA-256 `6cd69e34782747595a2a5bccad4489e6c94a700df28cbcf068e80630e035463d`; updated protocol SHA-256 `13fdd6c854c1f3085976adb7abca0b1565dfa8f98aa4295203e403c7fa4fcb43`; generator unchanged at `c0d9cadf1cb1678b5afdbfd692709af742fe359edb22b13a5a10d110e8be86b3`.

The protocol now correctly discloses ciphertext/structure leakage and gives exact domain-tag/binary-protocol-digest/raw-seed commitment bytes. Runner reads only public JSON, validates expected public keys and matrix shape, and does not invoke the generator or inspect labels. Sequential child processes enforce30CPU-second,60-wall-second and2GiB address-space limits. Parent wait accounting includes child startup and final serialization, while the embedded worker `cpu_s` is captured before final result JSON writing and must not be the inclusive performance measure. A fresh output directory prevents accidental overwrite of a prior run. Failure receipts and capped output statuses are preserved.

Recommendations sent before final freeze:

- Hash public input and approved source files **before** starting children, then require identical hashes after completion. The reviewed version hashes public input only at the end and records no source hashes; procedural custody alone would otherwise have to establish all workers consumed the same source/input snapshot.
- Validate reference/dense coefficient witnesses as well as join witnesses. The reviewed version calls verification only for join modes.
- Assign cross-method mask equality and causal replay explicitly to evaluator stages; the driver itself does not perform them. Label-unaware comparisons can precede reveal; truth/membership scoring follows reveal. A completed process is not necessarily a completed result (plain cap has its own incomplete result status).

These are implementation/recording gaps, not evidence of a projection error. This audit did not modify production source. Final freeze must pin any revised runner/protocol rather than the superseded hashes above.

### Runner corrections reviewed

Static reread of runner SHA-256 `21f0fb3b86ec9b24c0f67f7a1083e4e5919f7f053140d6296e69df0ac1946610` and protocol `bcd23c496ab6988a3a8316abd66a90c3a6f356f82be1a484e976ce7b7e9bcd6a` confirms pre-execution public/source hashes, checks before each child and at completion, retained prehash receipt, and oracle/dense coefficient-witness validation. Protocol explicitly assigns separate pre-unseal comparisons and post-unseal truth/replay scoring and uses inclusive parent timings. These resolve the earlier recommendations under procedural no-mutation custody (not an adversarial filesystem security guarantee).

First comparison-script snapshot `6ada2a0e3110c21cd454bffe83cbe4f33e34d47379c52368432bebbf64fdf913` had a reporting gap: missing any method file skipped even available oracle-vs-join comparisons. A plain timeout could therefore suppress a valid primary comparison. Requested independent available-pair comparisons and explicit status/mask-length91 checks, rather than allowing zip truncation or trusting any existing result file. No runtime validation or blind execution performed during this review.

### Final static source review disposition

Final reread confirms the comparison script now compares every available complete oracle/join, oracle/dense and oracle/plain pair independently. Missing or incomplete methods remain separately reported; complete masks must be length91 lists of integer26-bit masks. Thus absent plain output no longer hides primary comparison, and truncation cannot pass zip comparison. The implementation review additionally reports disclosed development regression checks for missing plain and truncated join masks passed; this reviewer performed source-only confirmation, not a new execution.

Final reviewed hashes:

| Artifact | SHA-256 |
| --- | --- |
| `blind_generator.py` | `c0d9cadf1cb1678b5afdbfd692709af742fe359edb22b13a5a10d110e8be86b3` |
| `BLIND-PROTOCOL.md` | `bcd23c496ab6988a3a8316abd66a90c3a6f356f82be1a484e976ce7b7e9bcd6a` |
| `run_public.py` | `21f0fb3b86ec9b24c0f67f7a1083e4e5919f7f053140d6296e69df0ac1946610` |
| `check_public_outputs.py` | `1e5eb13b47ac55c428ce989c824dba7307c3089fd929c928076bebd6cbbbeafe` |
| `reference.py` | `d298355a973ee126262346102cc607552e67ec6aaacf5f3f46f8c57b86e3d93e` |
| `independent_join_audit.py` | `35db47876cda41245430c001a5deadc9b834bdef759d59cd25a7d1cada701eec` |

Disposition: no remaining source-level blocker identified for independent review of this proposed synthetic pilot. This is not execution authorization or evidence that a blind run passed. No seed or blind instance was generated, imported, read or executed by this reviewer. Prior findings and superseded source hashes above are intentionally retained. Custodian must verify the approved freeze manifest, preserve hashes/receipts, and keep incomplete outcomes explicit; post-unseal scoring/replay remains a separately required stage.
