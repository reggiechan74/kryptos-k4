> **Historical development-stage record.** This public prose copy is not claimed byte-identical to the frozen original; see PUBLIC-PROVENANCE.json. Later blind results are separately archived. Any developmental “same message plaintext” or “global” prediction wording refers only to the 91 modeled positions 6–96 of that fixed trajectory, not recovery of the first six positions or global function identity.

# Development report — not blind validation

All12 disclosed cases completed for exact oracle, compressed join and dense completion. Primary projections agreed exactly. Plain join completed7 cases and explicitly capped5; no capped result was interpreted as an exclusion.

|Case|Sparse forced /67|Dense forced /67|Program vectors|Oracle CPU s|Join CPU s|Plain|
|---|---:|---:|---|---:|---:|---|
|uniform_support_0|63|0|multiple|1.5117|0.9146|complete|
|uniform_support_1|59|0|multiple|0.4187|0.6133|complete|
|uniform_support_2|67|0|multiple|0.3986|0.5177|complete|
|uniform_support_3|67|0|multiple|0.3798|0.4934|complete|
|uniform_zero_divisor_coefficients|67|0|multiple|0.4031|0.5574|complete|
|repeated_trajectory|67|67|multiple|2.7824|3.1075|incomplete_expansion_cap|
|global_square_lag_alias|67|52|multiple|0.5863|0.6429|complete|
|zero_on_observations_only|0|0|multiple|3.5903|3.0358|incomplete_expansion_cap|
|equal_on_observations_only|0|0|multiple|3.6240|3.7280|incomplete_expansion_cap|
|inconsistent_observations|0|0|empty|0.2200|0.5358|complete|
|null_trajectory_zero_response|67|67|multiple|2.4915|2.9112|incomplete_expansion_cap|
|out_of_family_observational_twin|67|67|multiple|2.2996|3.5062|incomplete_expansion_cap|

All10 in-family cases retained true masks at every coordinate; zero false in-family forced letters. The inconsistent case was empty. The misspecified observational twin fit observations but gave one wrong model-conditional forced letter: the guarantee cannot establish model membership.

All11 nonempty cases had multiple coefficient vectors. This includes exact global aliases; it is NOT evidence for independent mechanisms. Six of10 in-family cases had all67 unknown coordinates forced; the remaining coverage was63,59,0,0. There is no claim that uniformly drawn plaintext was recovered: ordinary fixtures draw uniform ciphertext and derive plaintext under a planted law, explicitly.

- oracle: total CPU 18.706054s; maximum per-case CPU 3.623995s; peak observed RSS 13,428KiB.
- join: total CPU 20.563783s; maximum per-case CPU 3.728047s; peak observed RSS 34,688KiB.
- dense: total CPU 0.129935s; maximum per-case CPU 0.023997s; peak observed RSS 13,428KiB.
- plain: total CPU 8.403000s; maximum per-case CPU 1.467903s; peak observed RSS 34,176KiB.

Oracle faster on10/12 cases. Retain it as the default exact implementation; join is an optional representation experiment, not a demonstrated faster solver. Median unpaired times conceal case mix and are not used as speedup evidence. Verification overhead differs (join verifies one witness for every marginal value); these are transparent end-to-end implementation timings, not a claim of asymptotic superiority.

Compressed products reached155,112,720 descriptors while retaining301,476 right descriptors. Those products include syntactic aliases, not independent evidence or distinct plaintext counts. Factorization avoids expansion, but the simpler oracle also handles ambiguity efficiently.

## Tests and failures retained
- 48 exhaustive join cases, both compressed/plain, mod2/3/6/26, passed; rerun after normalization fix passed.
- Independent oracle334 sparse/dense-vs-exhaustive comparisons and4992-support smoke passed.
- Post-freeze independent join audit100 additional cases passed.
- 520 distinct-per-case witness laws causally re-encrypted synthetic ciphertext exactly.
- Development revealed a minor interface mismatch: solve normalized RHS but verify compared unnormalized RHS. Fixed verify to use y%q, added regression; no declared normalized fixture result changed.
- Plain capped5 cases at100000 descriptor products. No target or blind failures concealed; no holdout has run.

## Accounting
48-method development process CPU47.802772s; primary tiny test0.890290s; independent audit8.381074s; reference selftest approx0.73s; replay0.333240s; normalization rerun approx0.9s; fixture tests approx0.011s. Measured total is around59CPU seconds, with minor shell/import/static overhead not fully metered. Conservatively charge120CPU seconds against the overall8-hour budget, not pretend unmeasured overhead is zero. All processes sequential except short independent tiny audit; observed memory nowhere near8GiB.

## Next decision
Review frozen40-case synthetic blind protocol and source before generating a secret seed. No K4 target execution follows from this result. Scope is benchmark-only original-method development, not a new tested cipher family.

## Coefficient aliases versus different functions

`alias_diagnostic.py` explicitly separates these. On repeated ciphertext5, the two allowed laws constant7 and17×lag1 both predict7 throughout all91 rows, hence the same message plaintext. At the fresh six-zero ciphertext context they output7 and0, proving genuinely different functions, not just two coefficient encodings. Conversely13×(lag1²−lag1)=0 for all26 ranks is a global algebraic alias; coefficient-vector nonuniqueness by itself cannot establish different mechanisms. A single-trace alias is never called global equivalence.

Further static runner audit found missing source/input guards, missing reference witness validation and an initial comparison-checker skip when plain output was absent. All were corrected before freeze; disclosed driver/regression tests passed. `DEVELOPMENT-CHANGES.md` preserves original faulty snippets and exact scope. No holdout outcome informed these corrections. Conservative120CPU-second pre-holdout charge includes these small extra tests; no precise total is claimed for unmetered shell overhead.
