"""Preserved exact body of the earlier 100-case synthetic audit stdin command.

Originally executed 2026-10-31, seed789321, independently after reference freeze.
This file is a transcription of that tool-call body; no new holdout inputs.
"""
import reference,join,random,time,json
rng=random.Random(789321); t=time.perf_counter();c=time.process_time();cases=0; products=0
for primes,reps in [((2,3),60),((2,13),40)]:
 q=primes[0]*primes[1]
 for trial in range(reps):
  m=rng.randrange(0,5);n=rng.randrange(1,8)
  A=[[rng.randrange(q) for _ in range(m)] for _ in range(n)]
  I=rng.sample(range(n),rng.randrange(n+1));b=[rng.randrange(q) for _ in I]
  ref=reference.solve(A,I,b,primes=primes)
  fast=join.solve(A,I,b,q=q);plain=join.solve(A,I,b,q=q,plain=True)
  assert ref['masks']==fast['masks']==plain['masks'],(A,I,b,ref,fast,plain)
  join.verify(A,I,b,fast,q=q);join.verify(A,I,b,plain,q=q)
  assert ref['program_unique']==(plain['distinct_programs']==1)
  # Every descriptor product is a feasible sparse program; every unique vector
  # counted by expansion agrees in cardinality with exhaustive oracle.
  if m<=3:
   full=reference.exhaustive(A,I,b,primes=primes)
   assert full['program_count']==plain['distinct_programs']
  products+=fast['products'];cases+=1
print(json.dumps({'status':'PASS','cases':cases,'seed':789321,'descriptor_products':products,'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-c}))
