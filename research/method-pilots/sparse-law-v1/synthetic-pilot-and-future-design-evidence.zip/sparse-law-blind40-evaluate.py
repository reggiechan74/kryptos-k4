"""Post-seal/post-unseal evaluator only. No solver/feature-generator imports."""
import json,pathlib,sys,time,hashlib

def evaluate(public_path,label_path,result_dir):
 public=json.loads(pathlib.Path(public_path).read_text());labels=json.loads(pathlib.Path(label_path).read_text());out=pathlib.Path(result_dir)
 rows=[];replays=0;start=time.process_time()
 for i,case in enumerate(public):
  ident=case['id'];label=labels[ident];A,I,b=case['A'],case['I'],case['b'];J=[j for j in range(91) if j not in I]
  o=json.loads((out/f'{i:02d}-oracle.json').read_text());j=json.loads((out/f'{i:02d}-join.json').read_text());d=json.loads((out/f'{i:02d}-dense.json').read_text());p=json.loads((out/f'{i:02d}-plain.json').read_text())
  assert o['id']==ident==j['id']==d['id']==p['id'];assert o['masks']==j['masks']
  truth=label['truth'];assert [truth[k] for k in I]==b
  c=label['c'];assert len(c)==97
  # Independent feature row recomputation, ensuring observation payload matches C.
  for row in range(91):
   h=c[row:row+6][::-1];features=[1,*h,*(x*x%26 for x in h)]
   for a in range(6):
    for z in range(a+1,6):features.append(h[a]*h[z]%26)
   features.extend([int(h[0]==h[1]),int(h[2]==h[3]),int(h[4]==h[5])]);assert features==A[row]
  laws={tuple(theta) for w in j['witnesses'] for theta in w.values()}
  for law in laws:
   assert sum(x!=0 for x in law)<=3
   rebuilt=c[:6]
   for row in range(91):
    plaintext=(c[row+6]-sum(x*y for x,y in zip(A[row],law)))%26
    h=rebuilt[-6:][::-1];features=[1,*h,*(x*x%26 for x in h)]
    for a in range(6):
     for z in range(a+1,6):features.append(h[a]*h[z]%26)
    features.extend([int(h[0]==h[1]),int(h[2]==h[3]),int(h[4]==h[5])])
    rebuilt.append((plaintext+sum(x*y for x,y in zip(features,law)))%26)
   assert rebuilt==c;replays+=1
  masks=o['masks'];forced=[k for k in J if masks[k] and masks[k]&(masks[k]-1)==0]
  false=[k for k in forced if masks[k]!=(1<<truth[k])]
  missing=[k for k,v in enumerate(truth) if not masks[k]&(1<<v)]
  if label['in_family'] is True:assert not false and not missing
  denseforced=sum(bool(d['masks'][k]) and d['masks'][k]&(d['masks'][k]-1)==0 for k in J)
  rows.append({'id':ident,'category':label['category'],'in_family':label['in_family'],'feasible':bool(o['feasible_support_count']),'forced_unknown':len(forced),'dense_forced_unknown':denseforced,'false_forced_unknown':len(false),'missing_true_rows':len(missing),'program_status':o['program_status'],'plaintext_unique':len(forced)==67,'products':j['products'],'right_descriptors':j['right_descriptors'],'plain_status':p['status']})
 return {'cases':rows,'distinct_per_case_law_replays':replays,'cpu_s':time.process_time()-start}
if __name__=='__main__':
 result=evaluate(*sys.argv[1:4]);print(json.dumps(result,indent=2))
