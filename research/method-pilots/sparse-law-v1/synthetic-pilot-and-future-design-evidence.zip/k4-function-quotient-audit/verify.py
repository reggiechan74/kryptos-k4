"""Fresh synthetic-only quotient verification; Python standard library only."""
import itertools,json,random,time,hashlib
from pathlib import Path
start=time.process_time()
out=Path(__file__).parent
pairs=list(itertools.combinations(range(6),2))
def features(x):
 return [1]+list(x)+[a*a for a in x]+[x[i]*x[j] for i,j in pairs]+[int(x[i]==x[i+1]) for i in (0,2,4)]
def independent_rows(rows,p):
 basis={}; witnesses=[]
 for x in rows:
  a=[v%p for v in features(x)]
  for k,b in sorted(basis.items()):
   if a[k]:
    c=a[k];a=[(v-c*w)%p for v,w in zip(a,b)]
  nz=next((i for i,v in enumerate(a) if v),None)
  if nz is not None:
   inv=pow(a[nz],-1,p);basis[nz]=[(v*inv)%p for v in a];witnesses.append(x)
 return len(basis),witnesses
rng=random.Random(20261031)
contexts=[tuple(rng.randrange(26) for _ in range(6)) for _ in range(1000)]
ranks={}
for p in (2,13):
 rank,witness=independent_rows(contexts,p);assert rank=={2:25,13:31}[p]
 ranks[str(p)]={'rank':rank,'witness_contexts':witness}
# All 676 lifts of one lag/square pair, covering all 338 canonical pairs.
mins={}
for a,b in itertools.product(range(26),repeat=2):
 key=(a%13,b%13,(a+b)%2);cost=int(a!=0)+int(b!=0)
 mins[key]=min(cost,mins.get(key,3))
assert len(mins)==338
for (a,b,e),cost in mins.items():
 t=int(a!=0)+int(b!=0);assert cost==(t if t else e)
# One pair plus one unpaired coordinate: all 17,576 lifts and 8,788 classes.
m3={}
for a,b,c in itertools.product(range(26),repeat=3):
 key=(a%13,b%13,c%13,(a+b)%2,c%2)
 cost=sum(v!=0 for v in (a,b,c));m3[key]=min(cost,m3.get(key,4))
for (a,b,c,e,f),cost in m3.items():
 s=int(a!=0)+int(b!=0)+int(c!=0)
 expected=s+int(a==b==0 and e==1)+int(c==0 and f==1)
 assert cost==expected
assert all((13*(x*x-x))%26==0 for x in range(26))
result={'scope':'Fresh algebraic contexts only; no K4, holdout, or v1 files read or modified', 'random_seed':20261031,'contexts_generated':1000,'rank_certificates':ranks,'pair_lifts_exhausted':676,'pair_canonical_classes':len(mins),'pair_plus_singleton_lifts_exhausted':26**3,'pair_plus_singleton_classes':len(m3),'all_assertions_passed':True,'cpu_seconds':time.process_time()-start}
(out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rank_certificates'},indent=2))
