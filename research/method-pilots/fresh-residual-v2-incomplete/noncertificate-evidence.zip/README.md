# Fresh residual v2: incomplete fresh validation, preserved failure

**Scientific outcome: INCOMPLETE, not validation PASS.** The unchanged20-second cooperative preflight wall gate stopped slot8 (`v001-optimized`) at4,153 fully checked supports. Seven prior slots produced four nonsemantic control gates and three individually VERIFIED_EXACT results. Only one fresh base completed both modes;20successors were canceled. The failed80-second policy reservation and original lock remain preserved. No truth analysis, twin outcome, K4 admission or replacement draw followed.

## Evidence map

- `source/` and `dependencies/`: exact frozen source/schema/protocol/interpreter commitments, preserved at original absolute-path bindings. Sources are documentation/evidence, **not a launch authorization or ready-to-run rebased reproduction**. No source was rewritten for publication.
- `preparation/`, `mocks/`, `reviews/source/`: prior source/two-operational-mock PASS. These are not scientific holdout samples.
- `public/`: solver-only input, public run approval and sanitized generation attestation; no seed, truth or custody document.
- `runs/` and `evidence/`: exact original noncertificate slot/state/lock artifacts and all eight observed outer-tool completions. Empty logs are retained.
- `certificates.tar.gz`: **one authorized publication archive; each of the eight actual original certificate files occurs exactly once**, including the failed partial. No certificate has been extracted or copied loose. `CERTIFICATE-PROVENANCE.json` binds original path, status, bytes/hash to archive/member and archive digest. Normal/optimized files remain distinct provenance records even where bytes match. Streaming byte verification is not mathematical certificate replay.
- `reviews/failure/REVIEW.md`: independent preservation/integrity PASS; scientific INCOMPLETE remains unchanged.
- `closeout/`: exact custodian failure/accounting/handoff records. Their statements that review or copy authority was pending are historical at their creation. **The later independent review and separate publication-copy authorization supersede only those workflow statuses**, not the frozen scientific failure.
- `SOURCE-PROVENANCE.json`: exact-original/public-file mapping. Private source locations are represented by opaque artifact labels with exact original digest, not exposed paths. `SHA256SUMS` covers every package file other than itself.

## Accounting and cause

Known reported worker CPU51.756527 plus supervisor samples4.318978 totals56.075505CPU seconds across two mocks, one generation and eight cohort launches. Full supervisor policy133 is separate;184.756527worker-plus-policy is not measuredCPU. The retained80 is a subset of attempted640cohort allocation, not a second charge. Stage3,000/project20,200 allocations remain unchanged; tails and preparation/review/publication overhead are unmeasured, not zero. Publication archive storage is separate from original runtime evidence. Nominal CPU/address-space limits are not physical maxima/RSS guarantees.

Diagnostics establish cooperative wall exhaustion, not which computation, filesystem or scheduling subphase caused it; no OS timeout or CPU overshoot was observed. The complete normal result's W=1 must not be transferred into the failed optimized result. Only one paired fresh base contributes to blind completion; truth-based coverage remains unevaluated. The older48-case failed cohort remains sealed and permanentlyINCOMPLETE. Matbalez scope remains unresolved; K4 remainsNO-GO.

## Next decision and publication boundary

Prefer any later **separately authorized, whole fixed-data post-failure re-evaluation** over replacement draws or selective suffix retries. Preserve this original protocol/result permanently. Re-evaluation would require new explicit finite resource/orchestration/custody review and allocation, with unchanged mathematical semantics and no new-fresh claim. No such action is currently authorized.

This local package has not been remotely published. Independent release/privacy/provenance review must pass before publisher handoff. No seed/truth, raw private draw/command/custody material, actual private operational path, success-only terminal seal or analysis is included. A publication-copy permission is not scientific execution authority.
