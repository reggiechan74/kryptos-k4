"""Post-release algebra/coverage analysis; no solver/reference execution.

The complete blind relation was verified in each admitted worker. This module
checks authenticated reports and plant membership, not another complete oracle.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path('/workspace/shared/residual-fresh-validation-v2')


def load_common(manifest, expected):
    path = Path(manifest)
    if str(path) != str(ROOT / 'FREEZE.json') or path.is_symlink() or path.stat().st_size > 2097152:
        raise ValueError('bounded fixed freeze required')
    raw = path.read_bytes()
    if len(raw) > 2097152 or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('freeze hash')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate freeze key')
            result[key] = value
        return result
    freeze = json.loads(raw, object_pairs_hook=unique,
                        parse_constant=lambda _x: (_ for _ in ()).throw(ValueError('nonfinite freeze')))
    source = ROOT / 'custody_common.py'
    if source.is_symlink() or source.stat().st_size > 1048576:
        raise ValueError('bounded helper source required')
    if hashlib.sha256(source.read_bytes()).hexdigest() != freeze['files'][str(source)]:
        raise ValueError('helper source pin')
    spec = importlib.util.spec_from_file_location('fresh_v2_custody_common', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def feature_row(x):
    result = [1]
    result.extend(x)
    result.extend((value * value) % 26 for value in x)
    for i in range(6):
        for j in range(i + 1, 6):
            result.append(x[i] * x[j] % 26)
    result.extend(1 if x[i] == x[i + 1] else 0 for i in (0, 2, 4))
    return result


def descriptor(theta):
    alpha = [value % 13 for value in theta]
    beta = [0] * 25
    for j, value in enumerate(theta):
        beta[j if j < 7 else j - 6] ^= value % 2
    return alpha, beta


def residual(alpha, beta):
    if not any(alpha[q] or beta[q - 6] for q in (28, 29, 30)):
        return False
    if not any(beta[g] for g in range(2, 25)):
        return False
    for q in (28, 29, 30):
        if (beta[q - 6] == 1 and not any(beta[g] for g in range(25) if g not in (0, q - 6))
            and alpha[q] in (1, 12) and not any(alpha[j] for j in range(31) if j not in (0, q))):
            return False
    return True


def validate_truth(common, truth):
    common.require(type(truth) is dict and set(truth) == {'schema','seed_hex','bases','twins'}
        and truth['schema'] == 'fresh-residual-truth-v2', 'truth schema')
    common.require(common.digest(truth['seed_hex']), 'exact32-byte seed hex')
    common.require(type(truth['bases']) is list and len(truth['bases']) == 12
        and type(truth['twins']) is list and len(truth['twins']) == 3, 'truth denominators')
    for index, base in enumerate(truth['bases']):
        common.require(type(base) is dict and set(base) ==
            {'id','stratum','repetition','stream','theta','true_values'}
            and base['id'] == 'v%03d' % index and base['stratum'] in ('A','B','C')
            and type(base['repetition']) is int and 0 <= base['repetition'] < 4, 'base truth identity')
        for field, length in (('stream',97),('theta',31),('true_values',91)):
            common.require(type(base[field]) is list and len(base[field]) == length
                and all(type(value) is int and 0 <= value < 26 for value in base[field]), 'truth residues: ' + field)
    common.require({(base['stratum'], base['repetition']) for base in truth['bases']} ==
        {(s, k) for s in ('A','B','C') for k in range(4)}, 'exact stratum/repetition inventory')
    for stratum, twin in zip(('A','B','C'), truth['twins']):
        common.require(type(twin) is dict and set(twin) == {'id','parent_id','override_row','true_values'}
            and twin['id'] == 't' + stratum and type(twin['parent_id']) is str
            and type(twin['override_row']) is int and twin['override_row'] == 84
            and type(twin['true_values']) is list and len(twin['true_values']) == 91
            and all(type(v) is int and 0 <= v < 26 for v in twin['true_values']), 'dependent twin schema')


def analyze_truth(common, public, truth, read_report):
    """Bounded in-memory report/plant analysis; never calls a solver."""
    validate_truth(common, truth)
    inputs = {case['id']:case['instance'] for case in public['cases']}
    truth_by_id = {base['id']:base for base in truth['bases']}
    observed_rows = set(common.OBS_ROWS)
    outcomes = []
    admitted = set()
    stratum_counts = {s:{'planned':4,'admitted_both_modes':0,'gated_both_modes':0} for s in ('A','B','C')}
    summaries = {}
    informative_total = 0
    informative_bases = 0
    supported_wrong = 0
    for base in truth['bases']:
        case_id = base['id']
        instance = inputs[case_id]
        contexts = instance['contexts']
        expected_contexts = [[base['stream'][t-j] for j in range(1, 7)] for t in range(6, 97)]
        common.require(contexts == expected_contexts, 'contiguous stream/context binding')
        values = [sum(a*b for a, b in zip(base['theta'], feature_row(context))) % 26 for context in contexts]
        common.require(values == base['true_values']
            and all(values[i] == y for i, y in instance['observed']), 'plant output/observation binding')
        alpha, beta = descriptor(base['theta'])
        common.require(sum(v != 0 for v in base['theta']) <= 3 and residual(alpha, beta), 'global supported R plant')
        plaintext = [(base['stream'][t] - values[t-6]) % 26 for t in range(6, 97)]
        common.require(all((plaintext[i] + values[i]) % 26 == base['stream'][i+6] for i in range(91)),
                       'causal encryption identity')
        normal = read_report(case_id + '-normal')
        optimized = read_report(case_id + '-optimized')
        common.require(normal['status'] == optimized['status'], 'mode status discrepancy')
        record = {'id':case_id, 'stratum':base['stratum'], 'status':normal['status'],
                  'semantic_result':None, 'forced_wrong_hidden_rows':None,
                  'informative_distinct_hidden_contexts':0}
        if normal['status'] == 'CERTIFIED_RESOURCE_GATE':
            common.require(normal['semantic_summary'] is None and optimized['semantic_summary'] is None,
                           'resource gate must carry no semantic result')
            stratum_counts[base['stratum']]['gated_both_modes'] += 1
        else:
            common.require(normal['status'] == 'VERIFIED_EXACT'
                and normal['semantic_summary'] == optimized['semantic_summary'], 'complete matching semantic summaries')
            summary = normal['semantic_summary']
            masks = summary['masks']
            common.require(type(masks) is list and len(masks) == 91, '91 complete masks')
            for mask in masks:
                common.require(type(mask) is list and 1 <= len(mask) <= 26
                    and all(type(v) is int and 0 <= v < 26 for v in mask)
                    and mask == sorted(set(mask)), 'canonical nonempty Z26 mask')
            common.require(all(values[i] in masks[i] for i in range(91)), 'supported truth omitted from complete mask')
            common.require(all(masks[i] == [y] for i, y in instance['observed']), 'observed singleton masks')
            wrong = [i for i in range(91) if i not in observed_rows and len(masks[i]) == 1 and masks[i][0] != values[i]]
            common.require(not wrong, 'wrong forced prediction on supported plant')
            observed_contexts = {tuple(contexts[i]) for i in observed_rows}
            informative = {tuple(contexts[i]) for i in range(91)
                if i not in observed_rows and tuple(contexts[i]) not in observed_contexts and len(masks[i]) <= 25}
            informative_total += len(informative)
            informative_bases += bool(informative)
            supported_wrong += len(wrong)
            admitted.add(case_id)
            summaries[case_id] = summary
            stratum_counts[base['stratum']]['admitted_both_modes'] += 1
            record.update(semantic_result={'pieces':summary['pieces'], 'canonical_functions':summary['canonical_functions'],
                'original_lifts':summary['original_lifts'], 'joint_predictions':summary['joint_predictions'],
                'plant_membership':'global R + support + observed fit in independently verified complete relation'},
                forced_wrong_hidden_rows=wrong, informative_distinct_hidden_contexts=len(informative))
        outcomes.append(record)
        del normal, optimized
    twin_outcomes = []
    for stratum, twin in zip(('A','B','C'), truth['twins']):
        parent = truth_by_id[twin['parent_id']]
        common.require(parent['stratum'] == stratum and parent['repetition'] == 0, 'preselected twin parent')
        instance = inputs[parent['id']]
        common.require(instance['contexts'][27] == instance['contexts'][84]
            and 27 in observed_rows and 84 not in observed_rows, 'observed/hidden duplicate context proof')
        different = [i for i, (a, b) in enumerate(zip(parent['true_values'], twin['true_values'])) if a != b]
        common.require(different == [84] and twin['true_values'][84] == (parent['true_values'][84] + 1) % 26,
                       'exact one-symbol out-of-family perturbation')
        common.require(twin['true_values'][27] != twin['true_values'][84], 'deterministic-function contradiction')
        result = {'id':twin['id'], 'parent_id':parent['id'], 'dependent':True,
                  'misspecification_proof':'observed row27 equals hidden row84 context but truth values differ',
                  'status':'NO_SEMANTIC_RESULT_RESOURCE_GATE', 'false_forced_hidden_rows':None}
        if parent['id'] in admitted:
            masks = summaries[parent['id']]['masks']
            wrong = [i for i in range(91) if i not in observed_rows and len(masks[i]) == 1
                     and masks[i][0] != twin['true_values'][i]]
            common.require(masks[84] == [parent['true_values'][27]] and wrong == [84], 'required false forced twin prediction')
            result.update(status='VERIFIED_CONDITIONAL_MODEL_FALSE_FORCE', false_forced_hidden_rows=wrong)
        twin_outcomes.append(result)
    twin_parents_admitted = sum(twin['parent_id'] in admitted for twin in truth['twins'])
    coverage = {'admitted_base_pairs':len(admitted), 'required_base_pairs':6,
        'strata':stratum_counts, 'all_three_twin_parents_admitted':twin_parents_admitted == 3,
        'informative_distinct_hidden_contexts':informative_total, 'informative_base_clusters':informative_bases}
    enough = (len(admitted) >= 6 and all(v['admitted_both_modes'] >= 2 for v in stratum_counts.values())
              and twin_parents_admitted == 3 and informative_total >= 12 and informative_bases >= 3)
    return {'status':'SUCCESS_WITH_DECLARED_RESOURCE_GATES' if enough else 'INSUFFICIENT_SEMANTIC_COVERAGE',
        'denominators':{'base_clusters':12,'truth_records':15,'dependent_twins':3,'base_hidden_positions':804,
                        'dependent_twin_hidden_positions':201,'disclosed_controls':2,'worker_slots':28},
        'base_outcomes':outcomes, 'twin_outcomes':twin_outcomes, 'coverage':coverage,
        'all12_semantically_verified':len(admitted) == 12, 'supported_false_forced_predictions':supported_wrong,
        'twin_false_forced_predictions':twin_parents_admitted,
        'semantic_scope':'Conditional fixed-model implementation validation only; gates have no semantic result.',
        'admission':'NONE; matbalez historical scope and real-world model membership remain unresolved.'}


def main():
    parser = argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','analysis-manifest','analysis-manifest-sha256',
                 'results','results-manifest','results-manifest-sha256','truth','truth-sha256','custody','custody-sha256',
                 'private-commands','private-commands-sha256','out'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    common = load_common(args.manifest, args.manifest_sha256)
    common.require_bounds(180, 768)
    started = time.process_time()
    freeze = common.verify_freeze(args.manifest, args.manifest_sha256)
    common.read_analysis_manifest(args.analysis_manifest, args.analysis_manifest_sha256, freeze)
    common.require(args.input == freeze['public_paths']['input']
        and args.custody == freeze['public_paths']['custody'] and args.results == freeze['public_paths']['results'], 'fixed public paths')
    output = common.canonical_path(args.out, False)
    common.require(output != Path(args.results) and Path(args.results) not in output.parents,
                   'analysis output must not mutate sealed results inventory')
    public = common.read_public(args.input, args.input_sha256)
    custody = common.read_json(args.custody, pin=args.custody_sha256)
    common.validate_custody(custody, freeze, args.manifest_sha256, args.input_sha256)
    common.require(args.truth_sha256 == custody['truth_sha256']
        and args.private_commands_sha256 == custody['private_commands_sha256'], 'custody commitments')
    commands = common.read_private_commands(args.private_commands, args.private_commands_sha256)
    common.bind_private_command(commands, 'analyze',
        {'FREEZE_PIN':args.manifest_sha256, 'INPUT_PIN':args.input_sha256,
         'CUSTODY_PIN':args.custody_sha256, 'PRIVATE_COMMANDS_PIN':args.private_commands_sha256,
         'TERMINAL_PIN':args.results_manifest_sha256, 'TRUTH_PIN':args.truth_sha256,
         'ANALYSIS_PIN':args.analysis_manifest_sha256}, sys.argv[1:])
    terminal = common.read_json(args.results_manifest, pin=args.results_manifest_sha256)
    common.require(type(terminal) is dict and set(terminal) ==
        {'schema','snapshot','truth_sha256','analysis_manifest_sha256','private_commands_sha256'}
        and terminal['schema'] == 'fresh-residual-terminal-seal-v2', 'externally retained terminal schema')
    frozen_snapshot = terminal['snapshot']
    common.require(type(frozen_snapshot) is dict, 'terminal snapshot')
    supervisor = common.load_pinned('fresh_v2_analysis_supervisor', ROOT / 'supervisor.py', freeze)
    snapshot = supervisor.snapshot_terminal(args.results, args.input, args.input_sha256,
        args.manifest, args.manifest_sha256, args.custody, args.custody_sha256,
        frozen_snapshot['receipts_manifest_path'], frozen_snapshot['receipts_manifest_sha256'])
    sealer = common.load_pinned('fresh_v2_analysis_sealer', ROOT / 'seal_results.py', freeze)
    common.require(terminal == sealer.make_terminal(snapshot, custody), 'complete external terminal seal reconstruction')
    # No truth path is statted, hashed, read or parsed before the external terminal
    # commitment and complete current terminal tree above have both verified.
    truth = common.read_json(args.truth, common.TRUTH_MAX, args.truth_sha256)
    validate_truth(common, truth)
    seed = bytes.fromhex(truth['seed_hex'])
    common.require(hashlib.sha256(seed).hexdigest() == custody['seed_sha256'], 'committed seed identity')
    generator = common.load_pinned('fresh_v2_released_generator', ROOT / 'generator.py', freeze)
    replay_public, replay_truth = generator.generate(seed)
    common.require(replay_public == public and replay_truth == truth, 'exact one-draw deterministic replay')
    del replay_public, replay_truth
    def read_report(slot):
        path = Path(args.results) / slot / 'result.json'
        artifact = snapshot['artifacts'][slot + '/result.json']
        common.require(path.stat().st_size == artifact['bytes'], 'sealed result byte length')
        return common.read_json(path, common.JSON_MAX, artifact['sha256'])
    report = analyze_truth(common, public, truth, read_report)
    report.update(schema='fresh-residual-analysis-v2', freeze_sha256=args.manifest_sha256,
        input_sha256=args.input_sha256, custody_sha256=args.custody_sha256, truth_sha256=args.truth_sha256,
        terminal_manifest_sha256=args.results_manifest_sha256,
        analysis_manifest_sha256=args.analysis_manifest_sha256,
        analysis_worker_cpu_so_far=time.process_time() - started,
        worker_cpu_seconds=snapshot['worker_cpu_seconds'],
        supervisor_allocation_seconds=snapshot['supervisor_allocation_seconds'],
        accounting_note='Worker and analysis subset timers are not added to inclusive outer receipts again.')
    common.verify_freeze(args.manifest, args.manifest_sha256)
    common.read_analysis_manifest(args.analysis_manifest, args.analysis_manifest_sha256, freeze)
    for path, pin, limit in ((args.input,args.input_sha256,common.PUBLIC_MAX),
                            (args.custody,args.custody_sha256,common.JSON_MAX),
                            (args.truth,args.truth_sha256,common.TRUTH_MAX),
                            (args.results_manifest,args.results_manifest_sha256,common.JSON_MAX),
                            (args.private_commands,args.private_commands_sha256,common.JSON_MAX)):
        common.require(common.sha(path, limit) == pin, 'post-analysis commitment changed')
    common.write_new(output, report)
    print(json.dumps({'status':report['status'], 'analysis_sha256':common.sha(args.out)}))


if __name__ == '__main__':
    main()
