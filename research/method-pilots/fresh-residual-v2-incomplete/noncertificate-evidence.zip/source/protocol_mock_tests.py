"""Exactly one prescribed in-process operational mock suite per Python mode.

No seed, generator expansion, real solver/reference call or child launch is
permitted. Fixtures are disclosed zero-context/schema records, never a cohort.
The outer bounded_stage is the sole real supervisor/worker pair for this suite.
"""
import argparse
import copy
import ctypes
from dataclasses import replace
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time
from types import SimpleNamespace, ModuleType

ROOT=Path('/workspace/shared/residual-fresh-validation-v2')
MIB=1024*1024
PIN='a'*64
EXPECTED_COUNTS={
    'import_safety':9,'invalid_caps':42,'blind_schema':15,'certificate':20,
    'parser':8,'storage':9,'bounded_capture':15,'reaping':6,'launch_caps':20,
    'cpu_scalars':8,'commands':11,'producer_digest':5,'approval':17,
    'state':13,'report':29,'filesystem':12,'execution':19,'custody_io':5,'truth_boundary':3
}


def require(ok,message):
    if not ok:raise ValueError(message)


def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def sha(path):
    p=Path(path);require(p.is_file() and not p.is_symlink() and p.stat().st_size<=MIB,'bounded mock source')
    with p.open('rb') as f:raw=f.read(MIB+1)
    require(len(raw)<=MIB,'source grew');return hashlib.sha256(raw).hexdigest()


def load(name,path,pin):
    require(sha(path)==pin,'mock isolated module pin')
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


class Suite:
    def __init__(self):self.counts={key:0 for key in EXPECTED_COUNTS}
    def yes(self,group,fn):fn();self.counts[group]+=1
    def no(self,group,fn,classes=(ValueError,)):
        try:fn()
        except classes:self.counts[group]+=1
        else:raise ValueError('negative mock accepted: '+group)


class FixtureMeter:
    """Mock accounting only; never presented as actual reference computation."""
    def __init__(self,caps):self.caps=caps;self.ref=self;self.counts={}
    def work(self,n=1):require(type(n) is int and n>=0,'mock work');self.counts['work']=self.counts.get('work',0)+n
    def charge(self,name,amount=1):require(type(amount) is int and amount>=0,'mock charge');self.counts[name]=self.counts.get(name,0)+amount
    def record(self,n=1):self.charge('records',n)


def forbid(*_args,**_kwargs):raise RuntimeError('forbidden RNG, generator, solver or child launch in mock')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--freeze-sha256',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args();mode='optimized' if sys.flags.optimize else 'normal'
    require(resource.getrlimit(resource.RLIMIT_CPU)==(30,31),'mock CPU bounds')
    require(resource.getrlimit(resource.RLIMIT_AS)==(512*MIB,512*MIB),'mock address-space bounds')
    require(sys.flags.isolated==1 and sys.dont_write_bytecode,'mock isolated no-bytecode mode')
    guard=ctypes.c_int();require(ctypes.CDLL(None).prctl(2,ctypes.byref(guard),0,0,0)==0 and guard.value==signal.SIGKILL,'mock parent-death guard')
    freeze_path=ROOT/'FREEZE.json'
    require(freeze_path.is_file() and not freeze_path.is_symlink() and freeze_path.stat().st_size<=MIB,'bounded freeze before read')
    with freeze_path.open('rb') as f:raw=f.read(MIB+1)
    require(len(raw)<=MIB and hashlib.sha256(raw).hexdigest()==args.freeze_sha256,'mock freeze pin')
    freeze=json.loads(raw)
    spec=freeze['mock_jobs'][mode]
    expected=[args.freeze_sha256 if x=='${FREEZE_PIN}' else x for x in spec['command']]
    actual=[str(Path(sys.executable).resolve()),'-I','-B']+(['-O'] if sys.flags.optimize else [])+[str(Path(__file__).resolve())]+sys.argv[1:]
    require(actual==expected,'exact frozen mock command')
    require(spec['expected_counts']==EXPECTED_COUNTS,'frozen mock obligations')
    output=Path(args.output);require(output==ROOT/'mocks'/mode/'result.json','fixed mock output')
    scratch=output.parent/'scratch';scratch.mkdir(exist_ok=False)
    suite=Suite();start_cpu=time.process_time();start_wall=time.monotonic()
    report={'schema':'fresh-residual-mock-report-v2','mode':mode,'freeze_sha256':args.freeze_sha256,
            'status':'INCOMPLETE_OR_FAILED','counts':suite.counts,'resources':None,'failure':None,
            'scope':'fixed disclosed operational mocks; zero seed/case draws, real solvers, actual inner child launches or truth reads'}
    # Poison process/RNG entry points before any newly prepared source import.
    original={name:getattr(os,name) for name in ('fork','execve','getrandom','urandom')}
    saved_rng_modules={name:sys.modules.get(name) for name in ('random','secrets')}
    for name in original:setattr(os,name,forbid)
    # Do not import random/secrets: stdlib random import itself can seed its
    # global instance. Rejecting stubs prevent that incidental initialization.
    for name in ('random','secrets'):
        stub=ModuleType(name);stub.__getattr__=lambda _name:forbid
        for attribute in ('Random','SystemRandom','seed','random','randrange','choice','shuffle',
                          'token_bytes','token_hex','token_urlsafe','randbelow'):
            setattr(stub,attribute,forbid)
        sys.modules[name]=stub
    try:
        modules={}
        for filename in ('custody_common.py','generator.py','seal_results.py','analyze.py','bounded_stage.py',
                         'supervisor.py','preflight_blind.py','checker_blind.py','worker.py'):
            name=filename[:-3];modules[name]=load('mock_'+name,ROOT/filename,freeze['files'][str(ROOT/filename)])
            suite.counts['import_safety']+=1
        common=modules['custody_common'];generator=modules['generator'];sealer=modules['seal_results'];analysis=modules['analyze']
        bounded=modules['bounded_stage'];supervisor=modules['supervisor'];preflight=modules['preflight_blind'];checker=modules['checker_blind'];worker=modules['worker']
        # Explicitly poison every scientific entry reachable from imported wrappers.
        generator.generate=forbid;bounded.run_bounded=forbid
        common.verify_freeze(freeze_path,args.freeze_sha256)
        control=worker.literal_control('G0');caps=preflight.Caps()
        for field in caps.__dataclass_fields__:
            for bad in ((-1,float('nan')) if field=='max_seconds' else (-1,True)):
                badcaps=replace(caps,**{field:bad})
                suite.no('invalid_caps',lambda bc=badcaps:preflight.run(None,scratch/'MUST_NOT_EXIST.cert.jsonl',None,None,None,None,None,None,bc))
        for bad in (True,float('inf'),float('-inf'),'1',None,[] ): 
            suite.no('invalid_caps',lambda b=bad:preflight.validate_caps(replace(caps,max_seconds=b)))
        require(not (scratch/'MUST_NOT_EXIST.cert.jsonl').exists(),'invalid cap must precede file creation')
        zero_instance=dict(id='v000',contexts=[[0]*6 for _ in range(91)],observed=[[i,0] for i in common.OBS_ROWS],sparsity=3,allowed_features=list(range(31)))
        for value in (control,worker.literal_control('G1'),zero_instance):
            suite.yes('blind_schema',lambda v=value:preflight.validate_control(v,FixtureMeter(caps)))
        for key in ('seed','plant','stratum','hidden_values','truth_path','dependency','full_outputs','original_coefficients'):
            suite.no('blind_schema',lambda k=key:preflight.validate_control(dict(control,**{k:0}),FixtureMeter(caps)))
        mutations=[dict(control,id='A'),dict(control,sparsity=True),dict(control,allowed_features=[True]+list(range(1,31))),dict(control,contexts=[[False,0,0,0,0,0]])]
        for value in mutations:suite.no('blind_schema',lambda v=value:preflight.validate_control(v,FixtureMeter(caps)))

        digest=preflight.input_hash(control)
        binding=preflight.binding(control,[0,1,2],digest,SimpleNamespace(VERSION='independent-residual-reference-3'))
        cert={'version':'affine-certificate-3','q':13,'n':3,'binding':binding,
              'equations_sha256':hashlib.sha256(b'[13,3,[]]').hexdigest(),'operations':[],'rref':[],
              'consistent':True,'rank_a':0,'rank_aug':0,'dimension':3,'pivots':[],'free':[0,1,2],
              'point':[0,0,0],'basis':[[1,0,0],[0,1,0],[0,0,1]]}
        def fixture_replay(rows,n,claim,*,meter,binding):
            require(rows==[] and n==3 and claim==cert and binding==cert['binding'],'literal mock replay; no elimination')
            return {'rank_a':0,'consistent':True}
        reference=SimpleNamespace(VERSION='independent-residual-reference-3',SOURCE_SHA256=checker.REFERENCE_SHA256,replay_certificate=fixture_replay)
        header={'kind':'header','schema':checker.SCHEMA,'case_id':'G0','input_sha256':digest,'public_sha256':PIN,
                'point_cap':1000000,'sparsity':3,'allowed_features':list(range(31)),
                'reference_sha256':checker.REFERENCE_SHA256,'freeze_sha256':'b'*64}
        record={'kind':'support','index':0,'support':[0,1,2],'input_sha256':digest,'certificate':cert,
                'beta_groups':[0,1,2],'compatible_betas':[[2],[1,2],[0,2],[0,1,2]],'term':8788,'prefix_lower_bound':8788}
        def reader(point_cap=1000000):
            return checker.EvidenceChecker(control,PIN,checker.REFERENCE_SHA256,'b'*64,reference,
                FixtureMeter(replace(caps,point_cap=point_cap)),point_cap=point_cap)
        def accepted_first():
            r=reader();r.consume(canonical(header));answer=r.consume(canonical(record));require(answer['term']==8788,'literal contribution')
        suite.yes('certificate',accepted_first)
        for key,value in [('case_id','G1'),('point_cap',True),('sparsity',True),('freeze_sha256','0'*64)]:
            suite.no('certificate',lambda k=key,v=value:reader().consume(canonical(dict(header,**{k:v}))))
        for key,value in [('index',1),('support',[0,1,3]),('input_sha256','0'*64),('beta_groups',[0,1]),
                          ('compatible_betas',[[2]]),('term',True),('prefix_lower_bound',8787),('certificate',dict(cert,rank_a=1))]:
            def bad_support(k=key,v=value):
                r=reader();r.consume(canonical(header));r.consume(canonical(dict(record,**{k:v})))
            suite.no('certificate',bad_support)
        def premature(status,exact):
            r=reader();r.consume(canonical(header));r.consume(canonical(record))
            r.consume(canonical({'kind':'terminal','status':status,'support_count':1,'lower_bound':8788,'exact_W':exact,
                'content_sha256':hashlib.sha256(canonical(header)+canonical(record)).hexdigest()}))
        suite.no('certificate',lambda:premature('WORKLOAD_ADMITTED',8788))
        suite.no('certificate',lambda:premature('GATE_REJECTED_LOWER_BOUND',None))
        suite.no('certificate',lambda:reader().finish())
        def poison():
            r=reader()
            try:r.consume(canonical(dict(header,case_id='G1')))
            except ValueError:pass
            else:raise ValueError('first poison accepted')
            try:r.consume(canonical(header))
            except ValueError:pass
            else:raise ValueError('poisoned checker resumed')
            try:r.finish()
            except ValueError:pass
            else:raise ValueError('poisoned checker finished')
        suite.yes('certificate',poison)
        def completed_zero_cap():
            r=reader(0);h=dict(header,point_cap=0);r.consume(canonical(h));r.consume(canonical(record))
            terminal={'kind':'terminal','status':'GATE_REJECTED_LOWER_BOUND','support_count':1,'lower_bound':8788,'exact_W':None,
                      'content_sha256':hashlib.sha256(canonical(h)+canonical(record)).hexdigest()}
            r.consume(canonical(terminal));require(r.finish()['lower_bound']==8788,'strict zero-cap gate')
        suite.yes('certificate',completed_zero_cap)
        suite.no('certificate',lambda:reader().consume(canonical(dict(header,extra=1))))
        def after_terminal():
            r=reader(0);h=dict(header,point_cap=0);r.consume(canonical(h));r.consume(canonical(record))
            r.consume(canonical({'kind':'terminal','status':'GATE_REJECTED_LOWER_BOUND','support_count':1,'lower_bound':8788,'exact_W':None,'content_sha256':hashlib.sha256(canonical(h)+canonical(record)).hexdigest()}))
            r.consume(canonical(record))
        suite.no('certificate',after_terminal)
        for rawline in (b'{}',b'{}\n{}\n',b'{"a":1,"a":2}\n',b'{"a": 1}\n',b'{"a":NaN}\n',b'\xff\n',b' '*65537):
            suite.no('parser',lambda b=rawline:checker.parse_canonical_line(b,FixtureMeter(caps)))
        suite.yes('parser',lambda:require(checker.parse_canonical_line(b'{}\n',FixtureMeter(caps))=={},'canonical parser positive'))
        for used,total,amount,accepted in ((0,0,65536,True),(0,0,65537,False),(33554431,0,1,True),
                                          (33554432,0,1,False),(0,33554431,1,True),(0,33554432,1,False)):
            action=lambda u=used,t=total,n=amount:preflight.reserve_bytes(u,t,n,caps)
            if accepted:suite.yes('storage',action)
            else:suite.no('storage',action,(preflight.PreflightLimit,))
        for value in (True,-1,1.5):suite.no('storage',lambda v=value:preflight.reserve_bytes(v,0,1,caps))

        def capture_sequence():
            writes=[];kills=[];c=bounded.BoundedCapture(lambda i,b:(writes.append((i,b)) or len(b)),lambda:kills.append(1),4)
            require(c.feed(0,b'abcd') and c.written==[4,0],'capture exact cap')
            require(not c.feed(0,b'e') and not c.feed(1,b'z') and kills==[1] and writes==[(0,b'abcd')],'overflow before write, no repeat kill')
        suite.yes('bounded_capture',capture_sequence)
        for maximum in (-1,0,True,bounded.LOG_MAX+1):suite.no('bounded_capture',lambda v=maximum:bounded.BoundedCapture(lambda i,b:len(b),lambda:None,v))
        for index,data in ((True,b'a'),(2,b'a'),(0,b''),(0,b'x'*(bounded.CHUNK+1)),(0,'x')):
            suite.no('bounded_capture',lambda i=index,b=data:bounded.BoundedCapture(lambda i,b:len(b),lambda:None).feed(i,b))
        for used,amount,maximum in ((True,1,4),(-1,1,4),(5,1,4)):
            suite.no('bounded_capture',lambda u=used,a=amount,m=maximum:bounded.reserve_log_bytes(u,a,m))
        suite.yes('bounded_capture',lambda:require(bounded.reserve_log_bytes(3,1,4)==4 and bounded.reserve_log_bytes(4,1,4) is None,'log debit boundary'))
        suite.no('bounded_capture',lambda:bounded.BoundedCapture(lambda i,b:0,lambda:None).feed(0,b'a'))
        def reaping(interrupted=False):
            events=[]
            def ready():
                events.append('ready')
                if interrupted and len(events)==1:raise InterruptedError()
            result=bounded.reap_after_disarm(ready,lambda:events.append('disarm'),lambda:events.append('release'),lambda:(events.append('wait4') or 7))
            require(result==7 and events==(['ready'] if interrupted else [])+['ready','disarm','release','wait4'],'safe reaping order')
        suite.yes('reaping',lambda:reaping(False));suite.yes('reaping',lambda:reaping(True))
        for index in range(4):
            callbacks=[lambda:None]*4;callbacks[index]=None
            suite.no('reaping',lambda c=callbacks:bounded.reap_after_disarm(*c))
        launch=supervisor.launch_limits()
        suite.yes('launch_caps',lambda:bounded.check_limits(launch))
        for key in launch:
            for bad in (True,-1):suite.no('launch_caps',lambda k=key,b=bad:bounded.check_limits(dict(launch,**{k:b})))
        suite.no('launch_caps',lambda:bounded.check_limits(dict(launch,worker_cpu_soft=76)))
        suite.no('launch_caps',lambda:bounded.check_limits(dict(launch,log_max_bytes=2)))
        suite.no('launch_caps',lambda:bounded.check_limits(dict(launch,extra=1)))
        for value in (True,False,-1,float('nan'),float('inf'),float('-inf'),'1',None):
            suite.yes('cpu_scalars',lambda v=value:require(not bounded.numeric(v) and not supervisor.numeric(v) and not common.finite(v),'reject invalid CPU scalar'))
        for maximum in (20,30,45):
            suite.yes('report',lambda m=maximum:supervisor.completion_wall(m-1,m))
            suite.yes('report',lambda m=maximum:supervisor.completion_wall(m,m))
            suite.no('report',lambda m=maximum:supervisor.completion_wall(m+.001,m))
        template=[str(Path(sys.executable).resolve()),'-I','-B',str(ROOT/'worker.py'),'--input-sha256','${INPUT_PIN}']
        suite.yes('commands',lambda:require(worker.expanded_command(template,PIN)==supervisor.expanded_command({'command':template},PIN),'shared exact whole-token expansion'))
        for bad in (template[:-1]+['${INPUT_PIN}x'],template[:-1]+['${OTHER}'],template+['${INPUT_PIN}'],template[:-1]):
            def bad_command(t=bad):
                rejected=0
                for fn in (lambda:worker.expanded_command(t,PIN),lambda:supervisor.expanded_command({'command':t},PIN)):
                    try:fn()
                    except ValueError:rejected+=1
                require(rejected==2,'both independent command checks reject')
            suite.yes('commands',bad_command)
        suite.no('commands',lambda:worker.expanded_command(template,True))
        producer={'status':'EXACT','resources':{'steps':1,'wall_seconds':1.0},'pieces':[{'core':{'resources':{'work':2,'wall_seconds':3.0}}}],'masks':[[0]]}
        original_producer=copy.deepcopy(producer)
        baseline=worker.producer_digest(producer)
        suite.yes('producer_digest',lambda:require(producer==original_producer,'digest is nonmutating'))
        changed=copy.deepcopy(producer);changed['resources']['wall_seconds']=8;changed['pieces'][0]['core']['resources']['wall_seconds']=9
        suite.yes('producer_digest',lambda:require(worker.producer_digest(changed)==baseline,'only declared times excluded'))
        changed=copy.deepcopy(producer);changed['resources']['steps']=2
        suite.yes('producer_digest',lambda:require(worker.producer_digest(changed)!=baseline,'logical counters retained'))
        suite.no('producer_digest',lambda:worker.normalized_producer(dict(producer,status='INCOMPLETE')))
        previous_hash_max=worker.HASH_MAX;worker.HASH_MAX=1
        try:suite.no('producer_digest',lambda:worker.producer_digest(producer))
        finally:worker.HASH_MAX=previous_hash_max

        approval={'schema':'fresh-residual-run-approval-v2','status':'APPROVED_FROZEN_COHORT_EXECUTION',
            'freeze_sha256':args.freeze_sha256,'input_sha256':PIN,'custody_sha256':'c'*64,'draw_approval_sha256':'d'*64,
            'public_input_path':freeze['public_paths']['input'],'results_dir':freeze['public_paths']['results'],'generation_attestation_sha256':'e'*64}
        attestation={key:False for key in common.GENERATION_ATTESTATION_KEYS}
        attestation.update(schema='fresh-residual-generation-attestation-v2',status='PARENT_CUSTODIAN_VERIFIED_GENERATION',
            **{k:approval[k] for k in ('freeze_sha256','input_sha256','custody_sha256','draw_approval_sha256')},
            candidate_sha256='f'*64,generation_receipt_sha256='1'*64,generation_stdout_sha256='2'*64,
            generation_stderr_sha256='3'*64,approval_use_marker_sha256='4'*64,
            worker_cpu_seconds=1,supervisor_cpu_seconds=1,wall_seconds=1,external_tool_exit_code=0,receipt_exit_code=0,
            external_tool_completed=True,child_reaped=True,wall_timeout=False,log_overflow=False,post_sources_input_custody_checked=True)
        suite.yes('approval',lambda:common.validate_generation_attestation(attestation,approval))
        for key,value in [('worker_cpu_seconds',True),('worker_cpu_seconds',32),('supervisor_cpu_seconds',float('nan')),
                          ('wall_seconds',121),('external_tool_exit_code',False),('receipt_exit_code',1),('external_tool_completed',False),
                          ('child_reaped',False),('wall_timeout',True),('log_overflow',True),('post_sources_input_custody_checked',False),
                          ('freeze_sha256','0'*64),('candidate_sha256','bad')]:
            suite.no('approval',lambda k=key,v=value:common.validate_generation_attestation(dict(attestation,**{k:v}),approval))

        state={'schema':supervisor.SCHEMA,'freeze_sha256':args.freeze_sha256,'input_sha256':PIN,'run_approval_sha256':'b'*64,
            'completed':[{'slot':slot,'status':'CERTIFIED_RESOURCE_GATE','resource_sha256':'c'*64} for slot in supervisor.JOBS],
            'paired_cases':list(supervisor.CASES),'in_flight':None,'stopped':False,'canceled':[],
            'worker_cpu_actual':1,'supervisor_allocation_charged':140,'certificate_bytes':28,'certificate_files':28,'artifact_bytes':28}
        suite.yes('state',lambda:supervisor.validate_state_shape(state,args.freeze_sha256,PIN,'b'*64,True))
        for key,value in [('in_flight',{}),('stopped',True),('canceled',['v000-normal']),('completed',state['completed'][:-1]),
                          ('paired_cases',[]),('worker_cpu_actual',True),('worker_cpu_actual',float('nan')),('worker_cpu_actual',2101),
                          ('supervisor_allocation_charged',139),('certificate_files',27),('freeze_sha256','0'*64),('extra',1)]:
            suite.no('state',lambda k=key,v=value:supervisor.validate_state_shape(dict(state,**{k:v}),args.freeze_sha256,PIN,'b'*64,True))
        # Structural mock receipt only: it is never persisted or used as evidence
        # of a real prefix computation, semantic relation, stage or fresh case.
        pf_counts={key:0 for key in supervisor.PREFLIGHT_COUNTERS};pf_counts.update(supports=89,solve_calls=89,certificate_checks=178,generation_beta_candidates=700,audit_beta_candidates=700)
        pf_counts['wall_seconds']=0.1
        report0={'schema':'fresh-residual-slot-report-v2','slot':'G0-normal','case_id':'G0','python_optimized':False,
            'freeze_sha256':args.freeze_sha256,'input_sha256':PIN,'source_sha256':freeze['files'],'status':'CERTIFIED_RESOURCE_GATE',
            'preflight':{'status':'GATE_REJECTED_LOWER_BOUND','checked_supports':89,'lower_bound':1006226,'exact_W':None,
                'certificate':{'name':'case.cert.jsonl','bytes':1,'sha256':'d'*64,'complete':True},'resources':pf_counts},
            'producer':None,'verification':None,'semantic_summary':None,
            'resources':{'worker_wall_seconds':1,'worker_cpu_seconds':1,'producer_counters':None,'reference_counters':None,'producer_attempted':False,'reference_attempted':False},'reason':None}
        report_spec=freeze['jobs']['G0-normal']
        suite.yes('report',lambda:supervisor.validate_report(report0,report_spec,freeze,args.freeze_sha256,PIN))
        for key,value in [('python_optimized',0),('semantic_summary',{}),('producer',{}),('reason','unexpected')]:
            suite.no('report',lambda k=key,v=value:supervisor.validate_report(dict(report0,**{k:v}),report_spec,freeze,args.freeze_sha256,PIN))
        for key,value in [('solve_calls',88),('certificate_checks',177),('supports',True),('work_units',50000001)]:
            bad=copy.deepcopy(report0);bad['preflight']['resources'][key]=value
            suite.no('report',lambda r=bad:supervisor.validate_report(r,report_spec,freeze,args.freeze_sha256,PIN))
        pair=copy.deepcopy(report0);pair['slot']='G0-optimized';pair['python_optimized']=True;pair['resources']['worker_wall_seconds']=2;pair['preflight']['resources']['wall_seconds']=3
        suite.yes('report',lambda:supervisor.compare_pair(report0,pair))
        for mutate in ('certificate','prefix','counter'):
            bad=copy.deepcopy(pair)
            if mutate=='certificate':bad['preflight']['certificate']['sha256']='e'*64
            elif mutate=='prefix':bad['preflight']['lower_bound']+=1
            else:bad['preflight']['resources']['work_units']+=1
            suite.no('report',lambda r=bad:supervisor.compare_pair(report0,r))
        failed=copy.deepcopy(report0);failed.update(status='INCOMPLETE_OR_FAILED',reason='mock failure',verification={'status':'VERIFIED_EXACT'})
        suite.no('report',lambda:supervisor.validate_report(failed,report_spec,freeze,args.freeze_sha256,PIN))
        # Exercise real inventory functions against a tiny virtual filesystem;
        # no certificate file or solver output is created by these mocks.
        def virtual_inventory(kind):
            root='/MOCK/slot'
            entries={name:{'size':1,'symlink':False,'pin':'d'*64} for name in supervisor.ARTIFACT_CAPS}
            entries['resource.json']={'size':1,'symlink':False,'pin':'d'*64}
            if kind=='extra':entries['unsealed.txt']={'size':1,'symlink':False,'pin':'d'*64}
            if kind=='missing':del entries['case.cert.jsonl']
            if kind=='oversize':entries['case.cert.jsonl']['size']=supervisor.CERT_MAX+1
            if kind=='symlink':entries['case.cert.jsonl']['symlink']=True
            if kind in ('partial_bad','partial_ok'):entries['resource.json.tmp']={'size':1,'symlink':False,'pin':'d'*64}
            if kind.startswith('root_'):
                entries={'state.json':{'size':1,'symlink':False,'pin':'d'*64}}
                if kind=='root_extra':entries['unsealed.txt']={'size':1,'symlink':False,'pin':'d'*64}
                if kind=='root_lock':entries['IN_FLIGHT.lock']={'size':1,'symlink':False,'pin':'d'*64}
            class VirtualPath:
                def __init__(self,value):self.value=value.value if isinstance(value,VirtualPath) else str(value)
                @property
                def name(self):return self.value.rsplit('/',1)[-1]
                def __str__(self):return self.value
                def __lt__(self,other):return self.value<other.value
                def __truediv__(self,other):return VirtualPath(self.value+'/'+str(other))
                def is_dir(self):return self.value==root
                def is_file(self):return self.name in entries and self.value!=root
                def is_symlink(self):return entries.get(self.name,{}).get('symlink',False)
                def stat(self):return SimpleNamespace(st_size=entries[self.name]['size'])
                def iterdir(self):return iter(VirtualPath(root+'/'+name) for name in entries)
            saved_path,saved_sha=supervisor.Path,supervisor.sha
            supervisor.Path=VirtualPath
            def mock_sha(path,cap):
                require(path.stat().st_size<=cap,'virtual hash cap');return entries[path.name]['pin']
            supervisor.sha=mock_sha
            try:
                if kind.startswith('root_'):
                    empty=copy.deepcopy(state);empty.update(completed=[],paired_cases=[],worker_cpu_actual=0,
                        supervisor_allocation_charged=0,certificate_bytes=0,certificate_files=0,artifact_bytes=0)
                    inventory,_=supervisor.inspect_completed(empty,freeze,args.freeze_sha256,PIN,'b'*64,root)
                    require(set(inventory)=={'state.json'},'empty prefix root inventory')
                else:
                    inventory=supervisor.artifact_inventory(root,kind!='partial_ok')
                    require({item['name'] for item in inventory}==set(supervisor.ARTIFACT_CAPS),'virtual complete artifact names')
                    if kind in ('claim_ok','claim_bad'):
                        claim=copy.deepcopy(report0)
                        if kind=='claim_bad':claim['preflight']['certificate']['bytes']=2
                        supervisor.compare_certificate_claim(claim,inventory)
            finally:supervisor.Path=saved_path;supervisor.sha=saved_sha
        for kind in ('complete','partial_ok','claim_ok','root_ok'):
            suite.yes('filesystem',lambda k=kind:virtual_inventory(k))
        for kind in ('extra','missing','oversize','symlink','partial_bad','claim_bad','root_extra','root_lock'):
            suite.no('filesystem',lambda k=kind:virtual_inventory(k))
        command=supervisor.expanded_command(report_spec,PIN);jobdir=Path(command[-1]).parent
        execution=dict(schema=bounded.VERSION,command=command,cwd=report_spec['cwd'],limits=supervisor.launch_limits(),
            supervisor_pid=1,child_pid=2,child_reaped=True,parent_death_guard=True,exit_code=0,wall_timeout=False,
            log_overflow=False,collector_error=None,wall_seconds=1,child_user_cpu_seconds=.25,child_system_cpu_seconds=.25,
            child_cpu_seconds=.5,supervisor_exclusive_cpu_sample=.25,supervisor_cpu_allocation_charged=5,
            supervisor_final_write_tail_measured=False,child_peak_rss_kib=1,supervisor_peak_rss_kib=1,
            log_bytes_reserved=[0,0],log_bytes_read=[0,0],
            logs=[{'path':str(jobdir/name),'bytes':0,'sha256':hashlib.sha256(b'').hexdigest()} for name in ('stdout.txt','stderr.txt')],failures=[])
        suite.yes('execution',lambda:supervisor.validate_execution(execution,command,report_spec['cwd']))
        for key,value in [('extra',1),('child_cpu_seconds',76),('supervisor_exclusive_cpu_sample',6),('child_cpu_seconds',True),
                          ('wall_seconds',151),('child_reaped',False),('exit_code',False),('wall_timeout',True),('log_overflow',True),
                          ('command',command+['--extra']),('supervisor_pid',0)]:
            suite.no('execution',lambda k=key,v=value:supervisor.validate_execution(dict(execution,**{k:v}),command,report_spec['cwd']))
        # Pure mock-launch authority/command/receipt integration. These objects
        # are never written as approval, completed receipt or predecessor state.
        for mockmode in ('normal','optimized'):
            ms=freeze['mock_jobs'][mockmode]
            suite.yes('commands',lambda m=mockmode,s=ms:bounded.validate_mock_spec(freeze,args.freeze_sha256,m,
                bounded.expand_freeze_tokens(s['launch_command'],args.freeze_sha256)[4:],
                bounded.expand_freeze_tokens(s['command'],args.freeze_sha256),ROOT))
        normal_spec=freeze['mock_jobs']['normal']
        normal_command=bounded.expand_freeze_tokens(normal_spec['command'],args.freeze_sha256)
        normal_args=bounded.expand_freeze_tokens(normal_spec['launch_command'],args.freeze_sha256)[4:]
        bad_freeze=copy.deepcopy(freeze);bad_freeze['mock_jobs']['normal']['output']+='.other'
        suite.no('commands',lambda:bounded.validate_mock_spec(bad_freeze,args.freeze_sha256,'normal',normal_args,normal_command,ROOT))
        suite.no('commands',lambda:bounded.validate_mock_spec(freeze,args.freeze_sha256,'normal',[normal_args[0]+'.other']+normal_args[1:],normal_command,ROOT))
        suite.no('commands',lambda:bounded.validate_mock_spec(freeze,args.freeze_sha256,'normal',normal_args,normal_command+['--extra'],ROOT))
        mock_report={'schema':'fresh-residual-mock-report-v2','mode':'normal','freeze_sha256':args.freeze_sha256,
            'status':'PASS','counts':dict(EXPECTED_COUNTS),'resources':{'worker_cpu_seconds':1,'worker_wall_seconds':1,
            'actual_inner_children':0,'real_solver_calls':0,'seed_draws':0,'generator_expansions':0,'truth_bytes_read':0},
            'failure':None,'scope':report['scope']}
        suite.yes('report',lambda:bounded.validate_mock_report(mock_report,normal_spec,'normal',args.freeze_sha256))
        for key,value in [('status','INCOMPLETE_OR_FAILED'),('mode','optimized'),('resources',dict(mock_report['resources'],actual_inner_children=1)),
                          ('counts',dict(EXPECTED_COUNTS,import_safety=True)),('counts',{})]:
            suite.no('report',lambda k=key,v=value:bounded.validate_mock_report(dict(mock_report,**{k:v}),normal_spec,'normal',args.freeze_sha256))
        mock_receipt=copy.deepcopy(execution)
        mock_receipt.update(command=normal_command,cwd=normal_spec['cwd'],limits=bounded.mock_limits(),
            supervisor_cpu_allocation_charged=31,status='COMPLETED',
            logs=[{'path':normal_spec[name],'bytes':0,'sha256':hashlib.sha256(b'').hexdigest()} for name in ('stdout','stderr')])
        marker={'schema':'bounded-stage-one-use-v2','command':normal_command,'receipt':normal_spec['receipt'],
                'stdout':normal_spec['stdout'],'stderr':normal_spec['stderr']}
        mock_receipt['one_use_marker_sha256']=hashlib.sha256(canonical(marker)).hexdigest()
        mock_receipt['mock_completion']={'freeze_sha256':args.freeze_sha256,'pre_mock_approval_sha256':'9'*64,
            'result':{'path':normal_spec['output'],'bytes':1,'sha256':'8'*64}}
        suite.yes('execution',lambda:bounded.validate_mock_receipt(mock_receipt,normal_spec,'normal',args.freeze_sha256,'9'*64))
        for key,value in [('status','INCOMPLETE_OR_FAILED'),('mock_completion',None),('one_use_marker_sha256','0'*64),
                          ('mock_completion',dict(mock_receipt['mock_completion'],freeze_sha256='0'*64)),
                          ('child_cpu_seconds',32),('extra',1)]:
            suite.no('execution',lambda k=key,v=value:bounded.validate_mock_receipt(dict(mock_receipt,**{k:v}),normal_spec,'normal',args.freeze_sha256,'9'*64))
        def reject_predecessor(kind):
            saved_read,saved_hash=bounded.read_json,bounded.sha
            def mock_read(path,*_):
                if str(path)==str(ROOT/'FREEZE.json'):return freeze
                if str(path)==str(ROOT/'PRE-MOCK-APPROVAL.json'):
                    return {'schema':'fresh-residual-pre-mock-approval-v2','status':'APPROVED_FOR_TWO_FROZEN_MOCKS','freeze_sha256':args.freeze_sha256}
                if str(path)==normal_spec['receipt']:
                    if kind=='missing':raise FileNotFoundError('mock missing predecessor receipt')
                    if kind=='failed':return dict(mock_receipt,status='INCOMPLETE_OR_FAILED')
                    return dict(mock_receipt,mock_completion=None)
                raise ValueError('unexpected predecessor read')
            def mock_hash(path,*_):
                name=str(path)
                if name==str(ROOT/'FREEZE.json'):return args.freeze_sha256
                if name==str(ROOT/'PRE-MOCK-APPROVAL.json'):return '9'*64
                if name==freeze['python']['executable']:return freeze['python']['sha256']
                require(name in freeze['files'],'only pinned source mock hash');return freeze['files'][name]
            bounded.read_json=mock_read;bounded.sha=mock_hash
            try:
                s=freeze['mock_jobs']['optimized']
                bounded.mock_context(ROOT,bounded.expand_freeze_tokens(s['launch_command'],args.freeze_sha256)[4:],
                    bounded.expand_freeze_tokens(s['command'],args.freeze_sha256),'optimized')
            finally:bounded.read_json=saved_read;bounded.sha=saved_hash
        for kind in ('missing','failed','unsealed'):
            suite.no('approval',lambda k=kind:reject_predecessor(k),(ValueError,FileNotFoundError))
        fixture_path=scratch/'literal-public-schema.json'
        public_fixture={'schema':'fresh-residual-public-v2','cases':[{'id':'v%03d'%i,'instance':{k:v for k,v in zero_instance.items() if k!='id'}} for i in range(12)]}
        common.write_new(fixture_path,public_fixture,262144);fixture_pin=common.sha(fixture_path)
        suite.yes('custody_io',lambda:common.read_public(fixture_path,fixture_pin))
        suite.no('custody_io',lambda:common.write_new(fixture_path,{},262144),(FileExistsError,))
        suite.no('custody_io',lambda:common.read_public(fixture_path,'0'*64))
        malformed=scratch/'duplicate.json';malformed.write_bytes(b'{"a":1,"a":2}\n')
        suite.no('custody_io',lambda:common.read_json(malformed))
        suite.no('custody_io',lambda:common.bind_private_command({'generator':template},'generator',{'UNAPPROVED_PIN':PIN},[]))

        # Full real analyzer entry ordering with stubbed I/O. No truth path exists
        # and even the positive boundary is intercepted before its first read.
        custody={key:'c'*64 for key in common.CUSTODY_KEYS}
        custody.update(schema='fresh-residual-custody-v2',status='DRAWN_ONCE',public_sha256=PIN,
            freeze_sha256=args.freeze_sha256,analysis_manifest_sha256=freeze['analysis_manifest_sha256'],
            resource_allocation_sha256=freeze['resource_allocation_sha256'],python_version=freeze['python']['version'],
            rng='Python random.Random MT19937 from committed256-bit big-endian seed')
        snapshot={'receipts_manifest_path':'/MOCK/receipts.json','receipts_manifest_sha256':'4'*64,
                  'artifacts':{},'worker_cpu_seconds':0,'supervisor_allocation_seconds':0}
        terminal=sealer.make_terminal(snapshot,custody)
        class TruthBoundary(Exception):pass
        def boundary_test(kind):
            argv=['--input',freeze['public_paths']['input'],'--input-sha256',PIN,'--manifest',str(freeze_path),'--manifest-sha256',args.freeze_sha256,
                '--analysis-manifest',str(ROOT/'ANALYSIS-MANIFEST.json'),'--analysis-manifest-sha256',freeze['analysis_manifest_sha256'],
                '--results',freeze['public_paths']['results'],'--results-manifest','/MOCK/terminal.json','--results-manifest-sha256',('8'*64 if kind=='wrong_pin' else '7'*64),
                '--truth','/MOCK/TRUTH_MUST_NOT_EXIST.json','--truth-sha256',custody['truth_sha256'],'--custody',freeze['public_paths']['custody'],
                '--custody-sha256','c'*64,'--private-commands','/MOCK/private-commands.json','--private-commands-sha256',custody['private_commands_sha256'],
                '--out','/MOCK/analysis.json']
            attempts=[]
            class FakeCommon:
                def __getattr__(self,name):return getattr(common,name)
                def require_bounds(self,*_):return None
                def verify_freeze(self,*_):return freeze
                def read_analysis_manifest(self,*_):return None
                def read_public(self,*_):return public_fixture
                def read_private_commands(self,*_):return {'analyze':[str(Path(sys.executable).resolve()),'-I','-B',str(ROOT/'analyze.py')]+argv}
                def read_json(self,path,*pos,**kw):
                    if str(path)==freeze['public_paths']['custody']:return custody
                    if str(path)=='/MOCK/terminal.json':
                        require(kw.get('pin')=='7'*64,'external terminal pin before truth');return terminal
                    if str(path)=='/MOCK/TRUTH_MUST_NOT_EXIST.json':attempts.append(1);raise TruthBoundary()
                    raise ValueError('unexpected mock read')
                def load_pinned(self,name,path,_freeze):
                    if Path(path).name=='supervisor.py':
                        value=dict(snapshot,extra=1) if kind=='inventory' else snapshot
                        return SimpleNamespace(snapshot_terminal=lambda *_:value)
                    if Path(path).name=='seal_results.py':return sealer
                    raise ValueError('generator/solver loading prohibited before truth boundary')
            saved_common,saved_argv=analysis.load_common,sys.argv
            analysis.load_common=lambda *_:FakeCommon();sys.argv=[str(ROOT/'analyze.py')]+argv
            try:
                if kind=='valid':
                    try:analysis.main()
                    except TruthBoundary:require(attempts==[1],'one intercepted first-truth boundary')
                    else:raise ValueError('valid terminal did not reach boundary')
                else:
                    try:analysis.main()
                    except ValueError:require(attempts==[],'invalid terminal reached truth')
                    else:raise ValueError('invalid terminal accepted')
            finally:analysis.load_common=saved_common;sys.argv=saved_argv
        for kind in ('wrong_pin','inventory','valid'):suite.yes('truth_boundary',lambda k=kind:boundary_test(k))
        require(suite.counts==EXPECTED_COUNTS,'exact finite mock count dictionary')
        require(not any('reference_v3' in name or 'residual_decoder' in name for name in sys.modules),'real solver/reference module imported')
        report['status']='PASS'
    except BaseException as error:
        report['failure']=type(error).__name__+': '+str(error)[:800]
    finally:
        for name,value in original.items():setattr(os,name,value)
        for name,previous in saved_rng_modules.items():
            if previous is None:sys.modules.pop(name,None)
            else:sys.modules[name]=previous
    report['resources']={'worker_cpu_seconds':time.process_time()-start_cpu,'worker_wall_seconds':time.monotonic()-start_wall,
                         'actual_inner_children':0,'real_solver_calls':0,'seed_draws':0,'generator_expansions':0,'truth_bytes_read':0}
    data=canonical(report);require(len(data)<=65536,'mock report cap')
    with output.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    fd=os.open(output.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    print(json.dumps({'status':report['status'],'mode':mode,'counts':suite.counts},sort_keys=True))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':sys.exit(main())
