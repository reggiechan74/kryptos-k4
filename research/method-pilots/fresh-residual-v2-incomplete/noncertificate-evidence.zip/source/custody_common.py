"""Pinned custody/shape helpers for fresh residual v2. No import-time I/O."""
import ctypes
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys

ROOT = Path('/workspace/shared/residual-fresh-validation-v2')
MIB = 1024 * 1024
JSON_MAX = 2 * MIB
PUBLIC_MAX = 262144
TRUTH_MAX = 262144
SOURCE_MAX = 64 * MIB
OBS_ROWS = tuple(range(15, 28)) + tuple(range(57, 68))
FREEZE_KEYS = {'schema','files','python','jobs','limits','mock_jobs','public_paths',
               'analysis_manifest_sha256','resource_allocation_sha256'}
CUSTODY_KEYS = {'schema','status','public_sha256','truth_sha256','seed_sha256',
               'freeze_sha256','analysis_manifest_sha256','resource_allocation_sha256',
               'draw_approval_sha256','private_commands_sha256','python_version','rng'}
RUN_APPROVAL_KEYS = {'schema','status','freeze_sha256','input_sha256','custody_sha256',
                     'draw_approval_sha256','public_input_path','results_dir',
                     'generation_attestation_sha256'}
GENERATION_ATTESTATION_KEYS = {'schema','status','freeze_sha256','input_sha256','custody_sha256',
    'draw_approval_sha256','candidate_sha256','generation_receipt_sha256',
    'generation_stdout_sha256','generation_stderr_sha256','approval_use_marker_sha256',
    'worker_cpu_seconds','supervisor_cpu_seconds','wall_seconds','external_tool_exit_code',
    'external_tool_completed','receipt_exit_code','child_reaped','wall_timeout','log_overflow',
    'post_sources_input_custody_checked'}
DRAW_APPROVAL_KEYS = {'schema','status','freeze_sha256','analysis_manifest_sha256',
                      'resource_allocation_sha256','public_dir','secret_dir',
                      'private_commands_path','private_commands_sha256'}
PRIVATE_COMMAND_KEYS = {'schema','generator','seal_results','analyze'}
PIN_NAMES = {'DRAW_APPROVAL_PIN','FREEZE_PIN','INPUT_PIN','CUSTODY_PIN',
             'PRIVATE_COMMANDS_PIN','RECEIPTS_PIN','TERMINAL_PIN','TRUTH_PIN','ANALYSIS_PIN'}
ANCESTORS = {
 '/workspace/shared/canonical-residual-dev/residual_decoder.py':'be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67',
 '/workspace/shared/canonical-residual-dev/affine_filter.py':'1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d',
 '/workspace/shared/canonical-residual-reference-v3/reference_v3.py':'0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def integer(value, maximum=None):
    return type(value) is int and value >= 0 and (maximum is None or value <= maximum)


def finite(value):
    return ((type(value) is int and value >= 0) or
            (type(value) is float and math.isfinite(value) and value >= 0))


def digest(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def nonfinite(_value):
    raise ValueError('nonfinite JSON number')


def canonical_path(path, must_exist=True):
    path = Path(path)
    require(path.is_absolute() and str(path) == str(path.resolve()), 'canonical absolute path required')
    require(not path.is_symlink(), 'symlink path forbidden')
    if must_exist:
        require(path.is_file(), 'regular file required')
    return path


def read_bytes(path, limit):
    require(integer(limit), 'strict byte cap')
    path = canonical_path(path)
    require(path.stat().st_size <= limit, 'file exceeds byte cap before read')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    require(len(data) <= limit, 'file grew past byte cap')
    return data


def read_json(path, limit=JSON_MAX, pin=None):
    data = read_bytes(path, limit)
    if pin is not None:
        require(digest(pin) and hashlib.sha256(data).hexdigest() == pin, 'JSON hash mismatch')
    value = json.loads(data, object_pairs_hook=unique, parse_constant=nonfinite)
    require(canonical(value) == data, 'canonical JSON bytes required')
    return value


def sha(path, limit=SOURCE_MAX):
    path = canonical_path(path)
    require(integer(limit) and path.stat().st_size <= limit, 'hash byte cap')
    count = 0
    result = hashlib.sha256()
    with path.open('rb') as handle:
        while True:
            block = handle.read(min(MIB, limit - count + 1))
            if not block:
                break
            count += len(block)
            require(count <= limit, 'file grew past hash cap')
            result.update(block)
    return result.hexdigest()


def fsync_dir(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(path, value, limit=JSON_MAX):
    path = canonical_path(path, False)
    data = canonical(value)
    require(len(data) <= limit, 'serialized byte cap includes final LF')
    with path.open('xb') as handle:
        require(handle.write(data) == len(data), 'short write')
        handle.flush()
        os.fsync(handle.fileno())
    fsync_dir(path.parent)


def require_bounds(cpu, memory_mib):
    require(resource.getrlimit(resource.RLIMIT_CPU) == (cpu, cpu + 1), 'bounded CPU launcher required')
    memory = memory_mib * MIB
    require(resource.getrlimit(resource.RLIMIT_AS) == (memory, memory), 'bounded address space required')
    death = ctypes.c_int()
    require(ctypes.CDLL(None).prctl(2, ctypes.byref(death), 0, 0, 0) == 0
            and death.value == signal.SIGKILL, 'parent-death guard required')
    require(sys.flags.isolated == 1 and sys.dont_write_bytecode and not sys.flags.optimize,
            'custody entry requires isolated normal no-bytecode Python')


def verify_freeze(path, pin):
    require(str(canonical_path(path)) == str(ROOT / 'FREEZE.json'), 'fixed public freeze path')
    freeze = read_json(path, JSON_MAX, pin)
    require(type(freeze) is dict and set(freeze) == FREEZE_KEYS
            and freeze['schema'] == 'fresh-residual-validation-v2-freeze', 'freeze schema')
    files = freeze['files']
    require(type(files) is dict and 8 <= len(files) <= 64, 'source file mapping')
    for name, expected in files.items():
        require(type(name) is str and digest(expected), 'source pin shape')
        p = canonical_path(name)
        require(p.parent == ROOT or name in ANCESTORS, 'source path outside frozen allowed roots')
        if name in ANCESTORS:
            require(expected == ANCESTORS[name], 'immutable engine/reference pin')
        require(sha(p) == expected, 'source changed: ' + name)
    for name, expected in ANCESTORS.items():
        require(files.get(name) == expected, 'missing immutable ancestor')
    require(str(ROOT / 'custody_common.py') in files, 'custody helper must be frozen')
    python = freeze['python']
    require(type(python) is dict and set(python) == {'executable','sha256','version'}, 'interpreter schema')
    require(python['executable'] == str(Path(sys.executable).resolve())
            and python['version'] == sys.version and digest(python['sha256'])
            and sha(python['executable']) == python['sha256'], 'interpreter identity')
    require(type(freeze['public_paths']) is dict and set(freeze['public_paths']) ==
            {'input','custody','run_approval','results'}, 'public path schema')
    for value in freeze['public_paths'].values():
        canonical_path(value, False)
    require(freeze['public_paths']['results'] == str(ROOT / 'runs'), 'fixed result root')
    require(type(freeze['jobs']) is dict and len(freeze['jobs']) == 28, '28 frozen jobs required')
    require(type(freeze['mock_jobs']) is dict and len(freeze['mock_jobs']) == 2, 'two mock jobs required')
    for field, filename in (('analysis_manifest_sha256','ANALYSIS-MANIFEST.json'),
                            ('resource_allocation_sha256','RESOURCE-ALLOCATION.json')):
        require(digest(freeze[field]) and files.get(str(ROOT / filename)) == freeze[field], 'manifest linkage')
    return freeze


def load_pinned(name, path, freeze):
    path = canonical_path(path)
    require(freeze['files'].get(str(path)) == sha(path), 'module source pin')
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'module loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read_public(path, pin):
    public = read_json(path, PUBLIC_MAX, pin)
    require(type(public) is dict and set(public) == {'schema','cases'}
            and public['schema'] == 'fresh-residual-public-v2', 'public schema')
    require(type(public['cases']) is list and len(public['cases']) == 12, '12 public base cases')
    for index, case in enumerate(public['cases']):
        require(type(case) is dict and set(case) == {'id','instance'}
                and case['id'] == 'v%03d' % index, 'neutral ordered case IDs')
        instance = case['instance']
        require(type(instance) is dict and set(instance) ==
                {'contexts','observed','sparsity','allowed_features'}, 'solver-only fields')
        require(type(instance['sparsity']) is int and instance['sparsity'] == 3
                and type(instance['allowed_features']) is list
                and all(type(v) is int for v in instance['allowed_features'])
                and instance['allowed_features'] == list(range(31)), 'fixed model')
        contexts = instance['contexts']
        require(type(contexts) is list and len(contexts) == 91, '91 contexts')
        for row in contexts:
            require(type(row) is list and len(row) == 6
                    and all(type(v) is int and 0 <= v < 26 for v in row), 'six Z26 symbols')
        require(all(contexts[i + 1][1:] == contexts[i][:-1] for i in range(90)), 'contiguous history overlap')
        observed = instance['observed']
        require(type(observed) is list and len(observed) == 24, '24 observations')
        for pair, row in zip(observed, OBS_ROWS):
            require(type(pair) is list and len(pair) == 2 and type(pair[0]) is int
                    and pair[0] == row and type(pair[1]) is int and 0 <= pair[1] < 26,
                    'fixed observed position/value')
    return public


def validate_custody(value, freeze, freeze_pin, input_pin):
    require(type(value) is dict and set(value) == CUSTODY_KEYS, 'custody schema')
    require(value['schema'] == 'fresh-residual-custody-v2' and value['status'] == 'DRAWN_ONCE', 'custody state')
    for key in CUSTODY_KEYS - {'schema','status','python_version','rng'}:
        require(digest(value[key]), 'custody digest: ' + key)
    require(value['freeze_sha256'] == freeze_pin and value['public_sha256'] == input_pin
            and value['analysis_manifest_sha256'] == freeze['analysis_manifest_sha256']
            and value['resource_allocation_sha256'] == freeze['resource_allocation_sha256'], 'custody linkage')
    require(value['python_version'] == freeze['python']['version']
            and value['rng'] == 'Python random.Random MT19937 from committed256-bit big-endian seed', 'generator runtime')
    return value


def validate_run_approval(value, freeze, freeze_pin, input_pin, custody_pin):
    require(type(value) is dict and set(value) == RUN_APPROVAL_KEYS, 'public run approval schema')
    require(value['schema'] == 'fresh-residual-run-approval-v2'
            and value['status'] == 'APPROVED_FROZEN_COHORT_EXECUTION', 'cohort not authorized')
    for key in ('freeze_sha256','input_sha256','custody_sha256','draw_approval_sha256','generation_attestation_sha256'):
        require(digest(value[key]), 'run approval pin')
    require(value['freeze_sha256'] == freeze_pin and value['input_sha256'] == input_pin
            and value['custody_sha256'] == custody_pin
            and value['public_input_path'] == freeze['public_paths']['input']
            and value['results_dir'] == freeze['public_paths']['results'], 'run approval bindings')
    parent = Path(freeze['public_paths']['input']).parent
    attestation = read_json(parent / 'GENERATION-ATTESTATION.json', pin=value['generation_attestation_sha256'])
    validate_generation_attestation(attestation, value)
    candidate = read_json(parent / 'RUN_APPROVAL.candidate.json', pin=attestation['candidate_sha256'])
    expected = {key:field for key, field in value.items() if key != 'generation_attestation_sha256'}
    expected.update(schema='fresh-residual-run-approval-candidate-v2', status='PENDING_GENERATION_RECEIPT')
    require(candidate == expected, 'active approval differs from committed generation candidate')
    return value


def validate_generation_attestation(value, run_approval):
    """Authenticates sanitized parent/custodian metadata, not a self-issued receipt.

    Parent externally pins RUN_APPROVAL only after checking the raw private receipt,
    logs, use marker, sources/input/custody and external tool completion. No code
    can infer that human/agent chronology from a self-declared JSON object.
    """
    require(type(value) is dict and set(value) == GENERATION_ATTESTATION_KEYS
        and value['schema'] == 'fresh-residual-generation-attestation-v2'
        and value['status'] == 'PARENT_CUSTODIAN_VERIFIED_GENERATION', 'generation attestation schema/status')
    for key in ('freeze_sha256','input_sha256','custody_sha256','draw_approval_sha256'):
        require(value[key] == run_approval[key] and digest(value[key]), 'generation attestation linkage')
    for key in ('candidate_sha256','generation_receipt_sha256','generation_stdout_sha256',
                'generation_stderr_sha256','approval_use_marker_sha256'):
        require(digest(value[key]), 'generation evidence digest')
    require(finite(value['worker_cpu_seconds']) and value['worker_cpu_seconds'] <= 31
        and finite(value['supervisor_cpu_seconds']) and value['supervisor_cpu_seconds'] <= 31
        and finite(value['wall_seconds']) and value['wall_seconds'] <= 120, 'generation resource allowances')
    require(type(value['external_tool_exit_code']) is int and value['external_tool_exit_code'] == 0
        and type(value['receipt_exit_code']) is int and value['receipt_exit_code'] == 0
        and value['external_tool_completed'] is True and value['child_reaped'] is True
        and value['wall_timeout'] is False and value['log_overflow'] is False
        and value['post_sources_input_custody_checked'] is True, 'generation receipt/exit/postcheck gate')
    return value


def read_private_commands(path, pin):
    commands = read_json(path, JSON_MAX, pin)
    require(type(commands) is dict and set(commands) == PRIVATE_COMMAND_KEYS
            and commands['schema'] == 'fresh-residual-private-commands-v2', 'private command schema')
    for role in ('generator','seal_results','analyze'):
        command = commands[role]
        require(type(command) is list and 5 <= len(command) <= 60
                and all(type(v) is str and 0 < len(v) <= 4096 for v in command), 'private argv shape')
        for token in command:
            if '${' in token:
                require(token.startswith('${') and token.endswith('}')
                        and token[2:-1] in PIN_NAMES, 'only whole-token approved pin substitutions')
    return commands


def bind_private_command(commands, role, pins, argv):
    require(role in ('generator','seal_results','analyze') and type(pins) is dict
            and set(pins) <= PIN_NAMES and all(digest(v) for v in pins.values()), 'derived pin mapping')
    expanded = []
    for token in commands[role]:
        if token.startswith('${'):
            key = token[2:-1]
            require(key in pins, 'missing derived pin')
            token = pins[key]
        expanded.append(token)
    actual = [str(Path(sys.executable).resolve()), '-I', '-B', str(ROOT / (role + '.py'))] + list(argv)
    require(expanded == actual, 'private command differs from frozen expanded argv')
    return expanded


def read_analysis_manifest(path, pin, freeze):
    require(str(canonical_path(path)) == str(ROOT / 'ANALYSIS-MANIFEST.json')
            and pin == freeze['analysis_manifest_sha256'], 'analysis manifest identity')
    value = read_json(path, JSON_MAX, pin)
    require(type(value) is dict and set(value) == {'schema','files'}
            and value['schema'] == 'fresh-residual-analysis-manifest-v2'
            and type(value['files']) is dict, 'analysis manifest schema')
    require(set(value['files']) == {str(ROOT / name) for name in
            ('analyze.py','generator.py','custody_common.py','seal_results.py','supervisor.py','bounded_stage.py')},
            'analysis dependency inventory')
    require(all(freeze['files'].get(path) == expected and sha(path) == expected
                for path, expected in value['files'].items()), 'analysis dependency pins')
    return value
