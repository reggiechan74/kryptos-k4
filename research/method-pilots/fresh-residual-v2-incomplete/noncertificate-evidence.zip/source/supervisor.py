"""One-use blind-cohort supervisor and read-only terminal authenticator.

SOURCE ONLY until independent freeze confirmation and separate parent authority.
No import-time launch, seed, input/custody read, state mutation or solver import.
"""
import argparse
import ctypes
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys

ROOT = Path('/workspace/shared/residual-fresh-validation-v2')
MIB = 1024*1024
REPORT_MAX = 2*MIB
LOG_MAX = MIB
CERT_MAX = 32*MIB
CERT_TOTAL = 28*CERT_MAX
STAGE_MAX = 1280*MIB
NONCOHORT_RESERVE = 64*MIB
SCHEMA = 'fresh-residual-supervisor-v2'
FREEZE_SCHEMA = 'fresh-residual-validation-v2-freeze'
CASES = ('G0','G1') + tuple('v%03d' % index for index in range(12))
JOBS = tuple(case+'-'+mode for case in CASES for mode in ('normal','optimized'))
ACCEPTED = ('VERIFIED_EXACT','CERTIFIED_RESOURCE_GATE')
ARTIFACT_CAPS = {'stdout.txt':LOG_MAX,'stderr.txt':LOG_MAX,
                 'result.json':REPORT_MAX,'case.cert.jsonl':CERT_MAX}
REPORT_KEYS = {'schema','slot','case_id','python_optimized','freeze_sha256',
    'input_sha256','source_sha256','status','preflight','producer','verification',
    'semantic_summary','resources','reason'}
PREFLIGHT_COUNTERS = {'fiber_points','lift_trials','solve_calls','certificate_checks',
    'row_operations','work_units','witness_checks','output_records',
    'generated_row_operations','replayed_row_operations','supports',
    'generation_beta_candidates','audit_beta_candidates',
    'generation_parity_row_tests','audit_parity_row_tests'}
REFERENCE_COUNTERS = PREFLIGHT_COUNTERS - {'supports','generation_beta_candidates',
    'audit_beta_candidates','generation_parity_row_tests','audit_parity_row_tests'}
PRODUCER_COUNTERS = {'steps','core_work','core_solves','core_terms'}
PRODUCER_CAPS = {'steps':2000000,'core_work':200000000,'core_solves':1000000,'core_terms':100000}
REFERENCE_CAPS = {'fiber_points':1000000,'lift_trials':4000000,'solve_calls':100000,
    'certificate_checks':200000,'row_operations':5000000,'work_units':500000000,
    'witness_checks':1000000,'output_records':5000000,
    'generated_row_operations':5000000,'replayed_row_operations':5000000}
PREFLIGHT_CAPS = {'fiber_points':0,'lift_trials':0,'witness_checks':0,
    'supports':4495,'generation_beta_candidates':35264,'audit_beta_candidates':35264,
    'generation_parity_row_tests':846336,'audit_parity_row_tests':846336,
    'solve_calls':4495,'certificate_checks':8990,'row_operations':1500000,
    'work_units':50000000,'output_records':2000000,
    'generated_row_operations':1500000,'replayed_row_operations':1500000}
EXECUTION_KEYS = {'schema','command','cwd','limits','supervisor_pid','child_pid',
    'child_reaped','parent_death_guard','exit_code','wall_timeout','log_overflow',
    'collector_error','wall_seconds','child_user_cpu_seconds','child_system_cpu_seconds',
    'child_cpu_seconds','supervisor_exclusive_cpu_sample','supervisor_cpu_allocation_charged',
    'supervisor_final_write_tail_measured','child_peak_rss_kib','supervisor_peak_rss_kib',
    'log_bytes_reserved','log_bytes_read','logs','failures'}
PAIR_EXCLUSIONS = (('slot',),('python_optimized',),
    ('preflight','resources','wall_seconds'),('producer','resources','wall_seconds'),
    ('verification','resources','wall_seconds'),('resources','worker_wall_seconds'),
    ('resources','worker_cpu_seconds'))


def require(condition,message):
    if not condition:
        raise ValueError(message)


def integer(value,maximum=None):
    return type(value) is int and value>=0 and (maximum is None or value<=maximum)


def numeric(value):
    return ((type(value) is int and value>=0) or
            (type(value) is float and math.isfinite(value) and value>=0))


def digest_string(value):
    return type(value) is str and len(value)==64 and all(c in '0123456789abcdef' for c in value)


def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def sha(path,limit=None):
    path=Path(path)
    require(path.is_file() and not path.is_symlink(),'regular hash input required')
    size=path.stat().st_size
    require(limit is None or size<=limit,'hash input exceeds cap')
    digest=hashlib.sha256();total=0
    with path.open('rb') as handle:
        while True:
            data=handle.read(MIB)
            if not data:break
            total+=len(data)
            require(limit is None or total<=limit,'hash input grew beyond cap')
            digest.update(data)
    require(total==size,'hash input changed size')
    return digest.hexdigest()


def _unique(pairs):
    out={}
    for key,value in pairs:
        require(key not in out,'duplicate JSON key');out[key]=value
    return out


def read_json(path,limit=REPORT_MAX):
    path=Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size<=limit,'bounded regular JSON')
    with path.open('rb') as handle:data=handle.read(limit+1)
    require(len(data)<=limit,'JSON grew beyond cap')
    return json.loads(data,object_pairs_hook=_unique,
        parse_constant=lambda _x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def limits():
    return dict(worker_cpu_soft=60,worker_cpu_hard=75,supervisor_cpu_soft=4,
        supervisor_cpu_hard=5,worker_address_space_bytes=1024*MIB,
        supervisor_address_space_bytes=256*MIB,wall_seconds=150,log_max_bytes=LOG_MAX,
        worker_cpu_allocation=2100,supervisor_cpu_allocation=140,
        certificate_file_max_bytes=CERT_MAX,certificate_stage_max_bytes=CERT_TOTAL,
        certificate_stage_max_files=28,report_max_bytes=REPORT_MAX,
        stage_max_bytes=STAGE_MAX,noncohort_storage_reserved_bytes=NONCOHORT_RESERVE,
        pair_exclusions=[list(path) for path in PAIR_EXCLUSIONS])


def launch_limits():
    return {key:limits()[key] for key in ('worker_cpu_soft','worker_cpu_hard',
        'supervisor_cpu_soft','supervisor_cpu_hard','worker_address_space_bytes',
        'supervisor_address_space_bytes','wall_seconds','log_max_bytes')}


def prepare_supervisor_bounds():
    """Called before argument/source/inventory reads, never at import."""
    parent=os.getppid()
    require(type(parent) is int and parent>=1,'positive expected parent PID')
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:
        raise OSError(ctypes.get_errno(),'PR_SET_PDEATHSIG')
    if os.getppid()!=parent:os.kill(os.getpid(),signal.SIGKILL)
    resource.setrlimit(resource.RLIMIT_CPU,(4,75))
    resource.setrlimit(resource.RLIMIT_AS,(256*MIB,1024*MIB))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_FSIZE,(CERT_MAX,CERT_MAX))


def _load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    require(spec is not None and spec.loader is not None,'explicit module loader')
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def context(freeze_path,freeze_pin):
    require(digest_string(freeze_pin),'freeze digest')
    freeze_path=Path(freeze_path)
    require(freeze_path==ROOT/'FREEZE.json' and sha(freeze_path,REPORT_MAX)==freeze_pin,'fixed freeze identity')
    preliminary=read_json(freeze_path)
    require(type(preliminary) is dict and type(preliminary.get('files')) is dict,'source map required')
    helper_path=ROOT/'custody_common.py'
    require(preliminary['files'].get(str(helper_path))==sha(helper_path,REPORT_MAX),'custody helper source pin')
    common=_load('fresh_residual_supervisor_custody',helper_path)
    freeze=common.verify_freeze(freeze_path,freeze_pin)
    require(freeze['schema']==FREEZE_SCHEMA and freeze['limits']==limits(),'frozen supervisor limits')
    require(list(freeze['jobs'])==list(JOBS),'exact frozen28-slot schedule')
    require(freeze['files'].get(str(ROOT/'supervisor.py'))==sha(ROOT/'supervisor.py',REPORT_MAX),'supervisor pinned')
    for slot in JOBS:
        spec=freeze['jobs'][slot]
        require(type(spec) is dict and set(spec)=={'script','cwd','command','report_identity'},'job specification schema')
        case=slot.rsplit('-',1)[0]
        require(spec['script']==str(ROOT/'worker.py') and spec['cwd']==str(ROOT),'fixed worker source/cwd')
        identity={'schema':'fresh-residual-slot-report-v2','slot':slot,'case_id':case,
                  'python_optimized':slot.endswith('-optimized')}
        require(spec['report_identity']==identity and type(spec['report_identity'].get('python_optimized')) is bool,'frozen report identity')
        expected=[freeze['python']['executable'],'-I','-B']
        if slot.endswith('-optimized'):expected.append('-O')
        expected += [str(ROOT/'worker.py'),'--job',slot,'--input',freeze['public_paths']['input'],
            '--input-sha256','${INPUT_PIN}','--output',str(ROOT/'runs'/slot/'result.json')]
        require(spec['command']==expected,'frozen exact worker argv/template')
    return common,freeze


def expanded_command(spec,input_pin):
    require(digest_string(input_pin),'input pin')
    command=spec['command']
    require(type(command) is list and command.count('${INPUT_PIN}')==1,'one whole-token input substitution')
    require(all(type(x) is str and ('${' not in x or x=='${INPUT_PIN}') for x in command),'only input pin substitution')
    return [input_pin if x=='${INPUT_PIN}' else x for x in command]


def counter_map(value,names):
    require(type(value) is dict and set(value)==set(names)|{'wall_seconds'},'exact counter schema')
    require(all(integer(value[name]) for name in names),'nonnegative exact integer counters')
    require(numeric(value['wall_seconds']),'finite wall counter')


def completion_wall(value,maximum):
    """Conservative completed-receipt acceptance, not a physical wall guarantee."""
    require(type(maximum) is int and maximum>0 and numeric(value) and value<=maximum,
            'completed cooperative wall allowance exceeded')


def bounded_counters(value,caps,allow_none=False):
    if value is None and allow_none:return
    require(type(value) is dict and set(value)==set(caps),'exact non-time counters')
    require(all(integer(value[key],maximum) for key,maximum in caps.items()),'counter type/cap')


def checked_preflight(value):
    require(type(value) is dict and set(value)=={'status','checked_supports','lower_bound','exact_W','certificate','resources'},'completed preflight exact schema')
    require(integer(value['checked_supports'],4495) and integer(value['lower_bound']),'preflight prefix counters')
    claim=value['certificate']
    require(type(claim) is dict and set(claim)=={'name','bytes','sha256','complete'},'certificate claim schema')
    require(claim['name']=='case.cert.jsonl' and integer(claim['bytes'],CERT_MAX)
        and digest_string(claim['sha256']) and claim['complete'] is True,'completed certificate identity')
    counter_map(value['resources'],PREFLIGHT_COUNTERS)
    completion_wall(value['resources']['wall_seconds'],20)
    bounded_counters({key:value['resources'][key] for key in PREFLIGHT_COUNTERS},PREFLIGHT_CAPS)
    require(value['resources']['supports']==value['checked_supports'],'preflight support meter linkage')
    require(value['resources']['solve_calls']==value['checked_supports']
            and value['resources']['certificate_checks']==2*value['checked_supports'],'preflight solve/replay counts')
    require(value['resources']['generation_beta_candidates']==value['resources']['audit_beta_candidates']
            and value['resources']['generation_parity_row_tests']==value['resources']['audit_parity_row_tests'],
            'generation/audit traversal counts')
    require(value['resources']['row_operations']==value['resources']['generated_row_operations']+
            value['resources']['replayed_row_operations'],'row operation subtotals')
    require(value['resources']['fiber_points']==0 and value['resources']['lift_trials']==0
            and value['resources']['witness_checks']==0,'no preflight semantic work')
    if value['status']=='GATE_REJECTED_LOWER_BOUND':
        require(value['checked_supports']>0 and value['lower_bound']>1000000 and value['exact_W'] is None,'certified gate prefix')
    else:
        require(value['status']=='WORKLOAD_ADMITTED' and value['checked_supports']==4495
            and integer(value['exact_W'],1000000) and value['exact_W']==value['lower_bound'],'complete workload admission')
    return value['status']


def validate_report(report,spec,freeze,freeze_pin,input_pin):
    require(type(report) is dict and set(report)==REPORT_KEYS,'exact report schema')
    require(type(report['python_optimized']) is bool,'strict report mode boolean')
    require(all(report[key]==value for key,value in spec['report_identity'].items()),'report identity/mode')
    require(report['freeze_sha256']==freeze_pin and report['input_sha256']==input_pin
            and report['source_sha256']==freeze['files'],'report source/input identity')
    require(type(report['resources']) is dict and set(report['resources'])=={'worker_wall_seconds','worker_cpu_seconds',
        'producer_counters','reference_counters','producer_attempted','reference_attempted'} and numeric(report['resources']['worker_wall_seconds'])
        and numeric(report['resources']['worker_cpu_seconds']),'report resource fields')
    require(type(report['resources']['producer_attempted']) is bool
        and type(report['resources']['reference_attempted']) is bool,'strict attempt flags')
    require(not report['resources']['reference_attempted'] or report['resources']['producer_attempted'],'reference follows producer')
    bounded_counters(report['resources']['producer_counters'],PRODUCER_CAPS,True)
    bounded_counters(report['resources']['reference_counters'],REFERENCE_CAPS,True)
    for name in ('producer','reference'):
        require(report['resources'][name+'_attempted'] or report['resources'][name+'_counters'] is None,'uncalled stage cannot claim counters')
    if report['status']=='INCOMPLETE_OR_FAILED':
        require(all(report[field] is None for field in ('producer','verification','semantic_summary')),'no incomplete semantic claims')
        if report['preflight'] is not None:
            require(type(report['preflight']) is dict and type(report['preflight'].get('resources')) is dict,'incomplete preflight resource shape')
            counter_map(report['preflight']['resources'],PREFLIGHT_COUNTERS)
            bounded_counters({key:report['preflight']['resources'][key] for key in PREFLIGHT_COUNTERS},PREFLIGHT_CAPS)
        require(type(report['reason']) is str and 0<len(report['reason'])<=2000,'failure reason')
        return report['status']
    require(report['status'] in ACCEPTED and report['reason'] is None,'accepted report status')
    preflight_status=checked_preflight(report['preflight'])
    if report['case_id'] in ('G0','G1'):
        require(report['status']=='CERTIFIED_RESOURCE_GATE','disclosed controls must gate')
    if report['status']=='CERTIFIED_RESOURCE_GATE':
        require(preflight_status=='GATE_REJECTED_LOWER_BOUND','gate status linkage')
        require(all(report[key] is None for key in ('producer','verification','semantic_summary')),'gate has no semantic claim')
        require(report['resources']['producer_counters'] is None and report['resources']['reference_counters'] is None,'gate has no semantic calls')
        require(report['resources']['producer_attempted'] is False and report['resources']['reference_attempted'] is False,'gate cannot attempt semantics')
        return report['status']
    require(preflight_status=='WORKLOAD_ADMITTED','semantic result needs full admission')
    require(report['resources']['producer_attempted'] is True and report['resources']['reference_attempted'] is True,'completed semantic calls required')
    producer=report['producer']
    require(type(producer) is dict and set(producer)=={'status','resources','stats'}
            and producer['status']=='EXACT','exact producer summary')
    counter_map(producer['resources'],PRODUCER_COUNTERS)
    completion_wall(producer['resources']['wall_seconds'],30)
    bounded_counters({key:producer['resources'][key] for key in PRODUCER_COUNTERS},PRODUCER_CAPS)
    require(report['resources']['producer_counters']=={key:producer['resources'][key] for key in PRODUCER_COUNTERS},'producer diagnostic counters match subset')
    require(type(producer['stats']) is dict and set(producer['stats'])=={'containers','beta_candidates',
        'incompatible_beta','excluded_B','eligible_pieces','empty_pieces','feasible_pieces'}
        and all(integer(v) for v in producer['stats'].values()),'producer integer stats')
    verify=report['verification']
    require(type(verify) is dict and set(verify)=={'version','source_sha256','request_sha256','status',
        'resources','pieces_checked','canonical_functions','original_lifts','joint_predictions','stats'},'exact verifier schema')
    require(verify['version']=='independent-residual-reference-3' and verify['status']=='VERIFIED_EXACT','complete verifier required')
    require(verify['source_sha256']==freeze['files']['/workspace/shared/canonical-residual-reference-v3/reference_v3.py']
            and digest_string(verify['request_sha256']),'verifier identity')
    counter_map(verify['resources'],REFERENCE_COUNTERS)
    completion_wall(verify['resources']['wall_seconds'],45)
    bounded_counters({key:verify['resources'][key] for key in REFERENCE_COUNTERS},REFERENCE_CAPS)
    require(report['resources']['reference_counters']=={key:verify['resources'][key] for key in REFERENCE_COUNTERS},'reference diagnostic counters match subset')
    require(verify['resources']['row_operations']==verify['resources']['generated_row_operations']+
        verify['resources']['replayed_row_operations'],'completed reference row-operation subtotals')
    require(verify['resources']['fiber_points']==report['preflight']['exact_W'],'full verifier exact workload equality')
    for key in ('pieces_checked','canonical_functions','original_lifts','joint_predictions'):
        require(integer(verify[key]) and verify[key]>0,'nonempty complete reference count')
    require(type(verify['stats']) is dict and set(verify['stats'])=={'supports','beta_candidates',
        'eligible_beta','retained_points','legacy_ambient_points_equivalent'}
        and all(integer(v) for v in verify['stats'].values()),'reference integer stats')
    summary=report['semantic_summary']
    require(type(summary) is dict and set(summary)=={'producer_nontime_sha256','masks','pieces',
        'canonical_functions','original_lifts','joint_predictions','feasibility_witness'},'exact semantic summary')
    require(digest_string(summary['producer_nontime_sha256']),'full producer semantic hash')
    require(type(summary['masks']) is list and len(summary['masks'])==91,'91 verified masks')
    for mask in summary['masks']:
        require(type(mask) is list and 1<=len(mask)<=26 and all(integer(v,25) for v in mask)
                and mask==sorted(set(mask)),'canonical complete scalar mask')
    for summary_key,verify_key in (('pieces','pieces_checked'),('canonical_functions','canonical_functions'),
                                  ('original_lifts','original_lifts'),('joint_predictions','joint_predictions')):
        require(integer(summary[summary_key]) and summary[summary_key]==verify[verify_key],'semantic/reference count linkage')
    require(type(summary['feasibility_witness']) is dict,'verified nonempty witness retained')
    return report['status']


def pair_projection(report):
    """Exactly frozen field exclusions; all other semantics and counters remain."""
    require(type(report) is dict and set(report)==REPORT_KEYS,'pair report schema')
    result=json.loads(canonical(report))
    for path in PAIR_EXCLUSIONS:
        container=result
        absent_parent=False
        for part in path[:-1]:
            if container is None:
                absent_parent=True;break
            require(type(container) is dict and part in container,'pair exclusion parent')
            container=container[part]
        if absent_parent or container is None:
            continue  # Producer/reference are null on a certified gate.
        require(type(container) is dict and path[-1] in container,'exact pair exclusion field')
        del container[path[-1]]
    return result


def compare_pair(normal,optimized):
    require(normal['slot'].endswith('-normal') and optimized['slot'].endswith('-optimized')
            and normal['case_id']==optimized['case_id'],'same ordered pair')
    require(normal['python_optimized'] is False and optimized['python_optimized'] is True,'strict mode booleans')
    require(pair_projection(normal)==pair_projection(optimized),'normal/optimized deterministic disagreement')
    return True


def artifact_inventory(jobdir,completed=False):
    jobdir=Path(jobdir)
    require(jobdir.is_dir() and not jobdir.is_symlink(),'regular slot directory')
    entries=[]
    for path in sorted(jobdir.iterdir()):
        if path.name in ('resource.json','resource.json.tmp'):
            require(path.is_file() and not path.is_symlink() and path.stat().st_size<=REPORT_MAX,'bounded resource receipt/partial')
            if completed:require(path.name=='resource.json','no completed resource partial')
            continue
        require(path.name in ARTIFACT_CAPS,'unexpected slot artifact: '+path.name)
        cap=ARTIFACT_CAPS[path.name]
        require(path.is_file() and not path.is_symlink() and path.stat().st_size<=cap,'bounded regular slot artifact')
        entries.append(dict(name=path.name,bytes=path.stat().st_size,sha256=sha(path,cap),
            classification='certificate_evidence' if path.name=='case.cert.jsonl' else
                'result' if path.name=='result.json' else 'diagnostic_nonresult'))
    if completed:
        require({item['name'] for item in entries}==set(ARTIFACT_CAPS),'complete artifact set')
    return entries


def compare_certificate_claim(report,inventory):
    actual={item['name']:item for item in inventory}.get('case.cert.jsonl')
    claim=report['preflight']['certificate']
    require(actual is not None and claim['bytes']==actual['bytes'] and claim['sha256']==actual['sha256'],'certificate bytes differ from report')


def diagnostic_inventory(jobdir):
    """Preserve bounded failed-file metadata; never certify this as complete."""
    entries=[];complete=True
    with os.scandir(jobdir) as iterator:
        for index,entry in enumerate(iterator):
            if index>=64:
                complete=False;break
            path=Path(entry.path)
            regular=entry.is_file(follow_symlinks=False)
            size=entry.stat(follow_symlinks=False).st_size if regular else 0
            pin=sha(path,CERT_MAX) if regular and size<=CERT_MAX else None
            entries.append(dict(name=entry.name,bytes=size,sha256=pin,
                classification='certificate_evidence' if entry.name=='case.cert.jsonl' else 'diagnostic_nonresult'))
            if not regular or size>CERT_MAX:complete=False
    return sorted(entries,key=lambda item:item['name']),complete


def validate_execution(value,command,cwd):
    require(type(value) is dict and set(value)==EXECUTION_KEYS
            and value.get('schema')=='fresh-residual-bounded-stage-v2','bounded execution schema')
    require(value.get('command')==command and value.get('cwd')==cwd and value.get('limits')==launch_limits(),'execution invocation/limits')
    require(type(value.get('exit_code')) is int and value['exit_code']==0,'successful child exit')
    require(value.get('child_reaped') is True and value.get('parent_death_guard') is True,'child reaped and guarded')
    require(value.get('wall_timeout') is False and value.get('log_overflow') is False
            and value.get('collector_error') is None and value.get('failures')==[],'bounded execution failure')
    require(numeric(value.get('wall_seconds')) and value['wall_seconds']<=150,'finite bounded wall')
    for key in ('child_user_cpu_seconds','child_system_cpu_seconds','child_cpu_seconds','supervisor_exclusive_cpu_sample'):
        require(numeric(value.get(key)),'finite CPU component')
    require(abs(value['child_user_cpu_seconds']+value['child_system_cpu_seconds']-value['child_cpu_seconds'])<=1e-8,'CPU component sum')
    require(value['child_cpu_seconds']<=75 and value['supervisor_exclusive_cpu_sample']<=5,'nominal CPU ceiling exceeded')
    require(type(value.get('supervisor_cpu_allocation_charged')) is int
            and value['supervisor_cpu_allocation_charged']==5
            and value.get('supervisor_final_write_tail_measured') is False,'supervisor charge/tail distinction')
    require(all(type(value.get(k)) is int and value[k]>=1 for k in ('supervisor_pid','child_pid'))
            and value['supervisor_pid']!=value['child_pid'],'distinct positive process IDs')
    require(all(integer(value.get(k)) for k in ('child_peak_rss_kib','supervisor_peak_rss_kib')),'RSS fields')
    for key in ('log_bytes_reserved','log_bytes_read'):
        require(type(value.get(key)) is list and len(value[key])==2 and all(integer(v) for v in value[key]),'log counters')
    require(all(value['log_bytes_reserved'][i]==value['log_bytes_read'][i]<=LOG_MAX for i in (0,1)),'successful bounded log totals')
    require(type(value.get('logs')) is list and len(value['logs'])==2,'two log records')
    jobdir=Path(command[-1]).parent
    for i,name in enumerate(('stdout.txt','stderr.txt')):
        item=value['logs'][i]
        require(type(item) is dict and set(item)=={'path','bytes','sha256'}
            and item['path']==str(jobdir/name) and integer(item['bytes'],LOG_MAX)
            and item['bytes']==value['log_bytes_reserved'][i] and digest_string(item['sha256']),'execution log identity')


def validate_receipt(receipt,spec,slot,freeze,freeze_pin,input_pin,approval_pin):
    required={'schema','slot','case_id','freeze_sha256','input_sha256','run_approval_sha256',
        'status','execution','inventory','certificate_bytes','certificate_files','artifact_bytes',
        'mode_pair_checked','failures'}
    require(type(receipt) is dict and set(receipt)==required,'exact receipt schema')
    require(receipt['schema']==SCHEMA and receipt['slot']==slot and receipt['case_id']==slot.rsplit('-',1)[0],'receipt identity')
    require(receipt['freeze_sha256']==freeze_pin and receipt['input_sha256']==input_pin
            and receipt['run_approval_sha256']==approval_pin,'receipt source/input/approval')
    require(receipt['status'] in ACCEPTED and receipt['failures']==[],'accepted receipt only')
    require(type(receipt['mode_pair_checked']) is bool
            and receipt['mode_pair_checked']==slot.endswith('-optimized'),'pair-check receipt')
    validate_execution(receipt['execution'],expanded_command(spec,input_pin),spec['cwd'])
    inventory=receipt['inventory']
    require(type(inventory) is list and len(inventory)==4,'exact four worker artifacts')
    seen=set()
    for item in inventory:
        require(type(item) is dict and set(item)=={'name','bytes','sha256','classification'},'artifact record schema')
        name=item['name'];require(type(name) is str and name in ARTIFACT_CAPS and name not in seen,'artifact name uniqueness')
        seen.add(name)
        require(integer(item['bytes'],ARTIFACT_CAPS[name]) and digest_string(item['sha256']),'artifact bytes/hash')
        wanted='certificate_evidence' if name=='case.cert.jsonl' else 'result' if name=='result.json' else 'diagnostic_nonresult'
        require(item['classification']==wanted,'artifact class')
    require(seen==set(ARTIFACT_CAPS),'artifact inventory coverage')
    certificate=next(item for item in inventory if item['name']=='case.cert.jsonl')
    require(type(receipt['certificate_files']) is int and receipt['certificate_files']==1
            and receipt['certificate_bytes']==certificate['bytes'],'certificate receipt totals')
    require(type(receipt['artifact_bytes']) is int and receipt['artifact_bytes']==sum(item['bytes'] for item in inventory),'artifact receipt totals')
    by_name={item['name']:item for item in inventory}
    for item in receipt['execution']['logs']:
        actual=by_name[Path(item['path']).name]
        require(item['bytes']==actual['bytes'] and item['sha256']==actual['sha256'],'execution/inventory log identity')


def validate_state_shape(state,freeze_pin,input_pin,approval_pin,require_terminal=False):
    keys={'schema','freeze_sha256','input_sha256','run_approval_sha256','completed','paired_cases',
        'in_flight','stopped','canceled','worker_cpu_actual','supervisor_allocation_charged',
        'certificate_bytes','certificate_files','artifact_bytes'}
    require(type(state) is dict and set(state)==keys and state['schema']==SCHEMA,'exact state schema')
    require(state['freeze_sha256']==freeze_pin and state['input_sha256']==input_pin
            and state['run_approval_sha256']==approval_pin,'state identity')
    require(type(state['completed']) is list and len(state['completed'])<=28,'completed list')
    require(all(type(r) is dict and set(r)=={'slot','status','resource_sha256'}
        and r['status'] in ACCEPTED and digest_string(r['resource_sha256']) for r in state['completed']),'completed records')
    require([r['slot'] for r in state['completed']]==list(JOBS[:len(state['completed'])]),'completed exact prefix')
    require(state['in_flight'] is None and state['stopped'] is False and state['canceled']==[],'stopped/uncertain state')
    require(state['paired_cases']==list(CASES[:len(state['completed'])//2]),'completed mode pairs')
    require(numeric(state['worker_cpu_actual']) and state['worker_cpu_actual']<=2100,'state worker CPU')
    require(type(state['supervisor_allocation_charged']) is int and state['supervisor_allocation_charged']==5*len(state['completed']),'state supervisor allocation')
    require(integer(state['certificate_bytes'],CERT_TOTAL) and type(state['certificate_files']) is int
        and state['certificate_files']==len(state['completed']),'state certificate totals')
    require(integer(state['artifact_bytes'],STAGE_MAX-NONCOHORT_RESERVE),'state artifact bytes')
    if require_terminal:require(len(state['completed'])==28,'all28 terminal slots required')


def inspect_completed(state,freeze,freeze_pin,input_pin,approval_pin,runs,allow_lock=False):
    """Rehash complete recorded slot tree, without certificate replay or truth."""
    validate_state_shape(state,freeze_pin,input_pin,approval_pin)
    runs=Path(runs)
    allowed={'state.json'}|{record['slot'] for record in state['completed']}
    if allow_lock:allowed.add('IN_FLIGHT.lock')
    require({path.name for path in runs.iterdir()}==allowed,'exact root runtime inventory')
    total_cpu=0.0;total_certificate=0;total_artifacts=0;reports={};artifacts={}
    for record in state['completed']:
        slot=record['slot'];jobdir=runs/slot;receipt_path=jobdir/'resource.json'
        require(sha(receipt_path,REPORT_MAX)==record['resource_sha256'],'immutable receipt changed')
        receipt=read_json(receipt_path)
        spec=freeze['jobs'][slot]
        validate_receipt(receipt,spec,slot,freeze,freeze_pin,input_pin,approval_pin)
        require(receipt['status']==record['status'],'state/receipt status')
        inventory=artifact_inventory(jobdir,True)
        require(inventory==receipt['inventory'],'filesystem receipt inventory mismatch')
        report=read_json(jobdir/'result.json')
        require(validate_report(report,spec,freeze,freeze_pin,input_pin)==receipt['status'],'report/receipt status')
        compare_certificate_claim(report,inventory)
        reports[slot]=report
        if slot.endswith('-optimized'):
            compare_pair(reports[slot[:-9]+'normal'],report)
        total_cpu+=receipt['execution']['child_cpu_seconds']
        total_certificate+=receipt['certificate_bytes']
        total_artifacts+=receipt['artifact_bytes']+receipt_path.stat().st_size
        for item in inventory:
            artifacts[slot+'/'+item['name']]={'bytes':item['bytes'],'sha256':item['sha256']}
        artifacts[slot+'/resource.json']={'bytes':receipt_path.stat().st_size,'sha256':record['resource_sha256']}
    require(abs(total_cpu-state['worker_cpu_actual'])<=1e-8,'state actual CPU reconciliation')
    require(total_certificate==state['certificate_bytes'] and total_artifacts==state['artifact_bytes'],'state byte reconciliation')
    state_path=runs/'state.json'
    artifacts['state.json']={'bytes':state_path.stat().st_size,'sha256':sha(state_path,REPORT_MAX)}
    require(sum(item['bytes'] for item in artifacts.values())<=STAGE_MAX-NONCOHORT_RESERVE,'runtime stage bytes')
    return artifacts,reports


def snapshot_terminal(results,input_path,input_pin,freeze_path,freeze_pin,custody_path,custody_pin,
                      receipts_manifest_path,receipts_manifest_pin):
    """Read-only complete terminal seal input. No seed/truth read or solver call."""
    common,freeze=context(freeze_path,freeze_pin)
    paths=freeze['public_paths'];results=Path(results)
    require(str(results)==paths['results'] and str(input_path)==paths['input']
            and str(custody_path)==paths['custody'],'terminal frozen public paths')
    require(sha(input_path,262144)==input_pin and sha(custody_path,REPORT_MAX)==custody_pin,'terminal input/custody pins')
    custody=read_json(custody_path)
    require(custody.get('public_sha256')==input_pin and custody.get('freeze_sha256')==freeze_pin,'custody input/source binding')
    approval_path=Path(paths['run_approval']);approval_pin=sha(approval_path,REPORT_MAX)
    approval=read_json(approval_path)
    common.validate_run_approval(approval,freeze,freeze_pin,input_pin,custody_pin)
    require(approval['draw_approval_sha256']==custody.get('draw_approval_sha256'),'custody consumed-draw identity')
    manifest_path=Path(receipts_manifest_path)
    require(manifest_path.is_absolute() and manifest_path.resolve()==manifest_path,'canonical absolute receipt manifest path')
    require(results not in manifest_path.parents and manifest_path!=results,'receipt manifest outside result inventory')
    require(sha(manifest_path,REPORT_MAX)==receipts_manifest_pin,'external receipt manifest hash')
    manifest=read_json(manifest_path)
    require(type(manifest) is dict and set(manifest)=={'schema','freeze_sha256','input_sha256',
        'run_approval_sha256','state_sha256','receipts'} and manifest['schema']=='fresh-residual-receipts-manifest-v2','receipt manifest schema')
    require(manifest['freeze_sha256']==freeze_pin and manifest['input_sha256']==input_pin
            and manifest['run_approval_sha256']==approval_pin,'receipt manifest bindings')
    state_path=results/'state.json'
    require(sha(state_path,REPORT_MAX)==manifest['state_sha256'],'externally pinned state')
    state=read_json(state_path)
    validate_state_shape(state,freeze_pin,input_pin,approval_pin,True)
    require(type(manifest['receipts']) is dict and manifest['receipts']==
        {record['slot']:record['resource_sha256'] for record in state['completed']},'external exact receipt set')
    artifacts,_reports=inspect_completed(state,freeze,freeze_pin,input_pin,approval_pin,results)
    return dict(schema='fresh-residual-terminal-snapshot-v2',freeze_sha256=freeze_pin,
        input_sha256=input_pin,custody_sha256=custody_pin,run_approval_sha256=approval_pin,
        receipts_manifest_path=str(manifest_path),receipts_manifest_sha256=receipts_manifest_pin,artifacts=artifacts,
        worker_cpu_seconds=state['worker_cpu_actual'],supervisor_allocation_seconds=state['supervisor_allocation_charged'],
        certificate_bytes=state['certificate_bytes'],certificate_files=state['certificate_files'])


def main(argv=None):
    prepare_supervisor_bounds()
    parser=argparse.ArgumentParser()
    for name in ('job','approval','approval-sha256','input','input-sha256','freeze-sha256'):
        parser.add_argument('--'+name,required=True)
    args=parser.parse_args(argv)
    require(args.job in JOBS,'fixed slot only')
    common,freeze=context(ROOT/'FREEZE.json',args.freeze_sha256)
    paths=freeze['public_paths'];runs=Path(paths['results'])
    require(args.input==paths['input'] and args.approval==paths['run_approval'],'frozen public invocation paths')
    require(sha(args.input,262144)==args.input_sha256 and sha(args.approval,REPORT_MAX)==args.approval_sha256,'input/run approval seals')
    approval=read_json(args.approval);custody_pin=sha(paths['custody'],REPORT_MAX)
    common.validate_run_approval(approval,freeze,args.freeze_sha256,args.input_sha256,custody_pin)
    custody=read_json(paths['custody'])
    require(custody.get('public_sha256')==args.input_sha256 and custody.get('freeze_sha256')==args.freeze_sha256
            and custody.get('draw_approval_sha256')==approval['draw_approval_sha256'],'public custody linkage')
    bounded=common.load_pinned('fresh_residual_bounded_supervisor',ROOT/'bounded_stage.py',freeze)
    bounded.death_guard()
    runs.mkdir(exist_ok=True)
    require(not runs.is_symlink(),'regular runs root')
    lock=runs/'IN_FLIGHT.lock';state_path=runs/'state.json'
    bounded.write_new(lock,dict(schema='fresh-residual-slot-lock-v2',slot=args.job,
        freeze_sha256=args.freeze_sha256,run_approval_sha256=args.approval_sha256))
    if state_path.exists():
        state=read_json(state_path)
        inspect_completed(state,freeze,args.freeze_sha256,args.input_sha256,args.approval_sha256,runs,True)
    else:
        require(args.job==JOBS[0] and {p.name for p in runs.iterdir()}=={'IN_FLIGHT.lock'},'fresh first-slot directory')
        state=dict(schema=SCHEMA,freeze_sha256=args.freeze_sha256,input_sha256=args.input_sha256,
            run_approval_sha256=args.approval_sha256,completed=[],paired_cases=[],in_flight=None,
            stopped=False,canceled=[],worker_cpu_actual=0.0,supervisor_allocation_charged=0,
            certificate_bytes=0,certificate_files=0,artifact_bytes=0)
    require(len(state['completed'])<28 and args.job==JOBS[len(state['completed'])],'only next unconsumed slot')
    require(state['worker_cpu_actual']+75<=2100 and state['supervisor_allocation_charged']+5<=140,'CPU reservation unavailable')
    require(state['certificate_bytes']+CERT_MAX<=CERT_TOTAL and state['certificate_files']<28,'certificate reservation unavailable')
    require(state['artifact_bytes']+40*MIB+REPORT_MAX<=STAGE_MAX-NONCOHORT_RESERVE,'stage byte reservation unavailable')
    jobdir=runs/args.job;jobdir.mkdir()
    spec=freeze['jobs'][args.job];command=expanded_command(spec,args.input_sha256)
    state['in_flight']=dict(slot=args.job,worker_cpu_reserved=75,supervisor_cpu_reserved=5,
        certificate_bytes_reserved=CERT_MAX,artifact_bytes_reserved=40*MIB,command=command)
    bounded.atomic(state_path,state)
    execution=bounded.run_bounded(command,spec['cwd'],jobdir/'stdout.txt',jobdir/'stderr.txt',launch_limits())
    failures=list(execution['failures']);report=None;status='INCOMPLETE_OR_FAILED';pair_checked=False
    try:
        report=read_json(jobdir/'result.json')
        status=validate_report(report,spec,freeze,args.freeze_sha256,args.input_sha256)
        if status=='INCOMPLETE_OR_FAILED':failures.append('worker_incomplete:'+report['reason'][:200])
    except (OSError,ValueError,TypeError,KeyError,MemoryError) as error:
        failures.append('worker_report:'+type(error).__name__+':'+str(error)[:200])
    inventory=[]
    try:
        inventory=artifact_inventory(jobdir,status in ACCEPTED)
        if status in ACCEPTED:compare_certificate_claim(report,inventory)
    except (OSError,ValueError,TypeError,KeyError,MemoryError) as error:
        failures.append('artifact_inventory:'+type(error).__name__+':'+str(error)[:200])
        try:
            inventory,diagnostic_complete=diagnostic_inventory(jobdir)
            if not diagnostic_complete:failures.append('diagnostic_inventory_incomplete_retained_reserve')
        except (OSError,ValueError,TypeError,MemoryError) as diagnostic_error:
            failures.append('diagnostic_inventory_unavailable:'+str(diagnostic_error)[:200])
    if not failures and args.job.endswith('-optimized'):
        try:
            previous=state['completed'][-1]
            previous_dir=runs/previous['slot']
            require(sha(previous_dir/'resource.json',REPORT_MAX)==previous['resource_sha256'],'normal receipt changed during optimized slot')
            previous_receipt=read_json(previous_dir/'resource.json')
            normal_claim=next(item for item in previous_receipt['inventory'] if item['name']=='result.json')
            require(sha(previous_dir/'result.json',REPORT_MAX)==normal_claim['sha256'],'normal result changed during optimized slot')
            normal=read_json(previous_dir/'result.json')
            compare_pair(normal,report);pair_checked=True
        except (OSError,ValueError,TypeError,KeyError,MemoryError) as error:
            failures.append('mode_pair:'+str(error)[:200])
    try:
        common.verify_freeze(ROOT/'FREEZE.json',args.freeze_sha256)
        require(sha(args.input,262144)==args.input_sha256 and sha(args.approval,REPORT_MAX)==args.approval_sha256
            and sha(paths['custody'],REPORT_MAX)==custody_pin,'post-run public pin change')
    except (OSError,ValueError,TypeError,KeyError,MemoryError) as error:
        failures.append('post_run_source_input:'+str(error)[:200])
    own=resource.getrusage(resource.RUSAGE_SELF)
    execution['supervisor_exclusive_cpu_sample']=own.ru_utime+own.ru_stime
    execution['supervisor_peak_rss_kib']=own.ru_maxrss
    if not numeric(execution['supervisor_exclusive_cpu_sample']) or execution['supervisor_exclusive_cpu_sample']>5:
        failures.append('supervisor_closeout_cpu_invalid_or_overshoot')
    if failures:status='INCOMPLETE_OR_FAILED'
    cert_items=[item for item in inventory if item['name']=='case.cert.jsonl']
    cert_bytes=sum(item['bytes'] for item in cert_items)
    receipt=dict(schema=SCHEMA,slot=args.job,case_id=args.job.rsplit('-',1)[0],
        freeze_sha256=args.freeze_sha256,input_sha256=args.input_sha256,
        run_approval_sha256=args.approval_sha256,status=status,execution=execution,
        inventory=inventory,certificate_bytes=cert_bytes,certificate_files=len(cert_items),
        artifact_bytes=sum(item['bytes'] for item in inventory),mode_pair_checked=pair_checked,failures=failures)
    if not failures:validate_receipt(receipt,spec,args.job,freeze,args.freeze_sha256,args.input_sha256,args.approval_sha256)
    receipt_path=jobdir/'resource.json'
    if receipt_path.exists() or receipt_path.with_name('resource.json.tmp').exists():
        state['stopped']=True;state['canceled']=list(JOBS[len(state['completed'])+1:])
        bounded.atomic(state_path,state)
        raise ValueError('worker wrote a supervisor-only receipt path; preserved without replacement')
    bounded.atomic(receipt_path,receipt)
    state['worker_cpu_actual']+=execution['child_cpu_seconds']
    state['supervisor_allocation_charged']+=5
    state['certificate_bytes']+=cert_bytes;state['certificate_files']+=len(cert_items)
    state['artifact_bytes']+=receipt['artifact_bytes']+receipt_path.stat().st_size
    state['completed'].append(dict(slot=args.job,status=status,resource_sha256=sha(receipt_path,REPORT_MAX)))
    if not failures:
        state['in_flight']=None
        if pair_checked:state['paired_cases'].append(receipt['case_id'])
    else:
        # Conservatively retain reservation even when OS use is known; no retry.
        state['stopped']=True;state['canceled']=list(JOBS[len(state['completed']):])
    bounded.atomic(state_path,state)
    if not failures:
        lock.unlink();bounded.fsync_dir(runs)
    return 0 if not failures else 1


if __name__=='__main__':
    try:
        sys.exit(main())
    except BaseException as error:
        if isinstance(error,SystemExit):raise
        os.write(2,canonical({'schema':'fresh-residual-supervisor-error-v2',
            'type':type(error).__name__,'message':str(error)[:400]})[:1024])
        sys.exit(1)
