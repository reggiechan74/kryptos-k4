# Fresh residual v2 — implementation/source-freeze contract

Status: source preparation authorized; NEW3,000 CPU seconds reserved. Exactly two
pre-draw operational mock commands are conditionally authorized only after the
independent exact source/schema/cap/fixture/count/command freeze. No seed, real
case, approval-use consumption, cohort execution, K4 use or remote write is
currently authorized. The earlier incomplete48-case cohort remains sealed and
untouched. Parent approval time:2026-10-31 23:04UTC. Pilot publication was remotely
verified at7b9075daa6aee50187b18794b1d3c97e6d840249; that checkpoint is satisfied,
not authority for this cohort. Original design and r0/r1 history remain preserved.

## Exact implementation changes from reviewed design

The semantic engine be050003…, affine dependency1e19e9ad… and independent
reference0730f8b0… are loaded from their original absolute paths at fixed hashes;
none is modified. preflight_blind/checker_blind copy the already audited support,
rank-certificate, beta traversal and accounting algebra, replacing only the
truth-bearing public A/B schema with strictly solver-only inputs and case bindings.
Full31/s3, original ordering, filters and the genuine full-Z26 equality stay fixed.
Both schema validators independently check contiguous overlap and24 public rows.
One32MiB certificate file per slot replaces the pilot's two-file worker inventory.

The worker's complete-producer hash is streamed, with a64MiB predebit byte cap.
Only root resources.wall_seconds and each pieces[index].core.resources.wall_seconds
are excluded. All logical counts remain. Serialization overflow is a failed slot,
not a resource gate and not an exact result. No full semantic relation is written
to disk. On any failure—including a later digest/post-seal failure—producer,
verification and semantic_summary are all null. Nonsemantic resource snapshots
remain under resources with explicit producer_attempted/reference_attempted
booleans. Null counters mean unavailable or uncalled, distinguished by those flags;
unknown counters are not zero. Immutable solver exceptions are not instrumented.

Every completed optimized slot is compared before the next pair begins. Only
exact explicit field exclusions listed in CAPS.json are permitted. Preflight
status/support prefix/L/W/certificate bytes and all non-time counters must agree.
A valid random-case resource gate may advance the fixed schedule. Incomplete,
wrong status, mismatch, overflow, missing/invalid receipt or observed overshoot
retains failure/reservation state and cancels successors; never retry or resume.

## Bounded launcher and storage

bounded_stage is a separately reviewed narrow derivative of the audited launcher,
not a claim of byte-identical reuse. The sole supervisor owns two nonblocking
pipes, reads<=16KiB chunks, predebits<=1MiB per log before writing, kills on overflow
and drains only within the original wall deadline. No helper child/thread/logger.
It uses the audited unreaped waitid/WNOWAIT -> alarm disarm -> PID guard release ->
wait4 order. Mocks exercise feed/ordering with stubs, not additional OS children.
The outer mock launch itself supplies the real two-process supervisor/worker pair.

Generic supervisor/child each receive their prescribed per-process limits:
mock/generation30/31CPU,512MiB,120wall; sealer5/6,512MiB,120wall; analysis180/181,
768MiB,600wall. Cohort supervisor installs4softCPU/256MiB immediately before source
or prior-output hashing, retaining only75CPU/1GiB hard headroom for fork; worker
gets60/75CPU and1GiB, supervisor then lowers hard caps to5CPU/256MiB, wall150.
A legitimate namespace parentPID1 is accepted; actual parent identity changes
still kill. Bounded-stage source/path work is also inside early installed limits.

OS wait4 worker CPU is inclusive of any descendants (none are allowed here).
Supervisor samples are not full measurements: generic main refreshes its sample
after log hashing and any mock postchecks but before final receipt validation,
construction/write/exit; cohort supervisor refreshes its
sample after report/inventory/mode/source-input closeout but before its final
receipt/state operations. The full policy allocation remains31/6/181 or5 as
applicable, separately labeled—not the sampled CPU. Prior OS overshoot remains
unresolved. Missing receipts or observations above nominal ceilings are failures.
Reported wall/watchdog intervals cover supervised launch/collection/cleanup;
prelaunch source guards and final receipt tails are not silently included in that
measurement. They remain under process CPU/address-space limits and the explicit
overhead allocation, not a claimed physical whole-invocation wall guarantee.
Completed preflight/producer/reference receipt walls must also be<=20/30/45.
These conservative acceptance guards do not physically guarantee cooperative
deadlines: an observed completion-tail crossing is retained failure. Incomplete
diagnostic walls may exceed their cooperative caps and cannot advance execution.

Cohort runtime permits only state.json, its fixed .tmp, one in-flight lock and
28 fixed job directories. Each has stdout/stderr<=1MiB, result<=2MiB,
case.cert.jsonl<=32MiB and resource.json<=2MiB; resource.json.tmp<=2MiB is retained
only as an incomplete nonresult. No copied/backup/temp certificate is allowed.
Partials remain counted. Exact filesystem inventories are checked, not just
self-declared file lists. Every successful later slot rehashes prior receipts,
logs, reports and certificates without certificate replay. No certificate copies
for publication are authorized by this preparation.

Noncohort reserved storage is64MiB within the total1.25GiB stage ceiling. The
bounded inventory groups below are fixed; no hidden output/cache/tmp tree is
permitted. Immutable source/history/metadata hashes and actual bytes are retained
at freeze. Their combined pre-execution size must be<=4MiB (interpreter and the
three unchanged external modules are references, not copied stage files).

| Noncohort group | Allowed files/roots | Ceiling |
|---|---|---:|
| Source, preserved local source history, protocols, schemas, freezes and independent-review metadata | New stage/proposal/review roots; no runtime certificate copies |4MiB|
| Exactly two mock trees | mocks/{normal,optimized}: result<=64KiB, stdout/stderr<=1MiB each, resource+started marker<=2MiB each, scratch literal-public<=256KiB and duplicate.json<=64bytes; no others |14MiB|
| One generation operation plus public/custodian metadata | One resource+started marker<=2MiB each, stdout/stderr<=1MiB each; public input/truth<=256KiB each; seed/seed commitment/candidate/custody/active approval/attestation<=64KiB each; private command manifest and draw approval<=2MiB each; approval-use marker<=2MiB |14MiB|
| One pre-truth seal | resource+started marker<=2MiB each; stdout/stderr<=1MiB each; receipts manifest and terminal manifest<=2MiB each |10MiB|
| One released analysis | resource+started marker<=2MiB each; stdout/stderr<=1MiB each; analysis report<=2MiB |8MiB|
| Stage accounting/final integrity and external metadata | Fixed bounded closeout manifests/reports, no additional scientific invocation |14MiB|

The group ceilings sum64MiB. They are storage allocations, not promises that every
malformed artifact fits. A source/mock inventory check must verify actual bytes
before completion; later custodian parent stages must enforce this exact inventory
and ceilings before activation/release. A missing inventory is a gate, not license
to claim compliance. Live-site/remote publication is outside this stage.

## Acyclic custody and future path bindings

All JSON artifacts are sorted-key compact UTF8 with exactly one LF, no NaN,
duplicate keys, bool-as-int or unknown claim fields. The graph is:

1. Source/schema/cap/resource/analysis files and typed command templates -> public
   FREEZE hash. No FREEZE self-hash and no private path in the public freeze.
2. Private command manifest plus source FREEZE -> private DRAW_APPROVAL and its
   exclusive durable use marker -> one seed commitment, public input/truth hashes.
3. Those hashes -> custody, which does not reference RUN_APPROVAL.
4. Generator writes only RUN_APPROVAL.candidate.json with PENDING_GENERATION_RECEIPT.
   It never writes active run approval. Parent/custodian must inspect raw private
   generation command/receipt/logs/use marker, source/input/custody seals, nominal
   resource ceilings AND external tool completion, then publish sanitized
   GENERATION-ATTESTATION and externally pin active RUN_APPROVAL. The public
   attestation binds candidate/receipt/log/marker hashes and resource/exit facts;
   it exposes no raw private argv/path. Its JSON alone is not chronology proof.
5. Active public approval -> slot report -> receipt -> complete receipts manifest
   -> externally retained terminal seal. Reports never reference future receipts;
   terminal does not include its own digest.
6. Parent accepts completed outer sealer receipt/logs/tool exit and externally
   retains terminal hash BEFORE release. Analyzer authenticates complete current
   terminal inventory before stat/hash/read of truth, then replays the one draw.
   The analyzer has no solver/reference call and loads one report at a time.

Whole-token ${INPUT_PIN}, ${FREEZE_PIN} and the exact named derived pin vocabulary
in custody_common are the only substitutions. Private command templates bind
exact args/paths/modes, including --private-commands and its SHA for sealer/analyzer.
Self-document hashes are substituted in argv only after file creation, not embedded
recursively in their own bytes. Public source/command freeze does not grant a draw.

Public future paths (not created/consumed now):
- Public: /workspace/shared/residual-fresh-validation-v2-public
- Runtime results: /workspace/shared/residual-fresh-validation-v2/runs

Private destination proposals are supplied separately to the parent, never in
worker argv or the public freeze/command manifest. The authority directory must
be distinct from the initially nonexistent secret
and public destinations. Parent must separately authorize literal private command
instantiation, draw paths, candidate activation, cohort and eventual release.
Shared-filesystem separation is operational, not cryptographic/OS blindness.

## Frozen operational mocks:266 obligations per mode, not fresh experiments

Both modes use the same protocol_mock_tests source and disclosed literals. Counts
are test cases/obligations, not a claim of independent datasets or individual
assertion totals. The expected dictionary is frozen in source and each job.

9 import guards;42 malformed cap entry guards;15 solver-only schema checks;
20 literal serialized-certificate controls/mutations;8 canonical-parser cases;
9 storage reservations;15 bounded-capture cases;6 reaping-order stubs;20 launcher
cap checks;8 invalid CPU scalars;11 exact command-binding cases;5 full-producer
hash guards;17 generation-attestation/predecessor checks;13 state-shape cases;29 report/mode
cases;12 exact-filesystem/partial-file cases;19 receipt cases;5 custody-I/O helpers;
3 analyzer terminal-before-truth boundary cases. Total266.

Source imports are permitted only inside the two approved mocks after freeze.
Rejecting random/secrets module stubs and os entropy/process guards precede new
source imports. Generator expansion and real solver/reference modules/calls are
prohibited. The literal rank-zero replay is a mock stub equality check, NOT a new
reference solve or certificate theorem test. The zero context repeated in a
clearly labeled schema-only fixture is not a fresh cohort. Filesystem cases use
an in-memory Path/hash adapter and write no certificate. Approval reuse checks
exercise the exclusive-write helper, not a full seeded generator activation.
The positive analyzer test stops at an intercepted nonexistent-truth read boundary;
no truth bytes or seed are opened. The source's actual generator/model algebra
remains subject to independent static review and later authorized fresh validation.

Exactly two fixed one-use launch commands normal thenoptimized are in FREEZE.
PRE-MOCK-APPROVAL must independently bind that freeze first. Any normal failure,
missing/overshoot receipt or uncertain external tool outcome stops optimized;
there is no third mock/retry. Reviewer owns no additional test invocation.
After both complete, return exact source/mock receipts and independent audit for
parent's SEPARATE draw/execution decision. Even a full mock PASS is not decoder
validation or K4 admission. Matbalez historical scope remains unresolved.
