"""Custodian-only one-draw generator. Source preparation is not draw authority.

No import-time randomness, case generation, file access or solver imports.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path('/workspace/shared/residual-fresh-validation-v2')


def load_common(manifest, expected):
    path = Path(manifest)
    if str(path) != str(ROOT / 'FREEZE.json') or path.is_symlink() or path.stat().st_size > 2097152:
        raise ValueError('bounded fixed freeze required')
    raw = path.read_bytes()
    if len(raw) > 2097152 or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('freeze hash')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate freeze key')
            result[key] = value
        return result
    freeze = json.loads(raw, object_pairs_hook=unique,
                        parse_constant=lambda _x: (_ for _ in ()).throw(ValueError('nonfinite freeze')))
    source = ROOT / 'custody_common.py'
    if source.is_symlink() or source.stat().st_size > 1048576:
        raise ValueError('bounded helper source required')
    if hashlib.sha256(source.read_bytes()).hexdigest() != freeze['files'][str(source)]:
        raise ValueError('helper source pin')
    spec = importlib.util.spec_from_file_location('fresh_v2_custody_common', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def features(x):
    return ([1] + list(x) + [v*v % 26 for v in x]
            + [x[i]*x[j] % 26 for i in range(6) for j in range(i+1, 6)]
            + [int(x[i] == x[i+1]) for i in (0, 2, 4)])


def generate(seed):
    """Pure committed-seed expansion; called only by authorized draw or release analysis."""
    if type(seed) is not bytes or len(seed) != 32:
        raise ValueError('exact256-bit committed seed required')
    import random
    rng = random.Random(int.from_bytes(seed, 'big'))
    observations = list(range(15, 28)) + list(range(57, 68))
    evens = tuple(range(2, 26, 2))
    odds = tuple(range(1, 26, 2))
    mixed = (3, 5, 7, 9, 11, 15, 17, 19, 21, 23)
    records = []
    for stratum in ('A', 'B', 'C'):
        for repetition in range(4):
            stream = [rng.randrange(26) for _ in range(97)]
            if repetition == 0:
                stream[84:90] = stream[27:33]
            theta = [0] * 31
            theta[0] = rng.randrange(26)
            q = (28, 29, 30, 28)[repetition]
            j = (2, 8, 13, 27)[repetition]
            if stratum == 'A':
                theta[q] = evens[rng.randrange(len(evens))]
                theta[j] = odds[rng.randrange(len(odds))]
            elif stratum == 'B':
                theta[q] = 13
                theta[j] = evens[rng.randrange(len(evens))]
            else:
                theta[q] = mixed[rng.randrange(len(mixed))]
                theta[j] = odds[rng.randrange(len(odds))]
            contexts = [[stream[t-j] for j in range(1, 7)] for t in range(6, 97)]
            values = [sum(a*b for a, b in zip(theta, features(x))) % 26 for x in contexts]
            records.append({'stratum':stratum, 'repetition':repetition, 'stream':stream,
                            'theta':theta, 'true_values':values,
                            'instance':{'contexts':contexts, 'observed':[[i, values[i]] for i in observations],
                                        'sparsity':3, 'allowed_features':list(range(31))}})
    rng.shuffle(records)
    public = {'schema':'fresh-residual-public-v2', 'cases':[]}
    truth = {'schema':'fresh-residual-truth-v2', 'seed_hex':seed.hex(), 'bases':[], 'twins':[]}
    for index, record in enumerate(records):
        case_id = 'v%03d' % index
        public['cases'].append({'id':case_id, 'instance':record['instance']})
        truth['bases'].append({'id':case_id, **{key:record[key] for key in
            ('stratum','repetition','stream','theta','true_values')}})
    for stratum in ('A', 'B', 'C'):
        parent = next(base for base in truth['bases'] if base['stratum'] == stratum and base['repetition'] == 0)
        values = list(parent['true_values'])
        values[84] = (values[84] + 1) % 26
        truth['twins'].append({'id':'t' + stratum, 'parent_id':parent['id'],
                               'override_row':84, 'true_values':values})
    return public, truth


def main():
    parser = argparse.ArgumentParser()
    for name in ('approval','approval-sha256','manifest','manifest-sha256','public-dir','secret-dir'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    common = load_common(args.manifest, args.manifest_sha256)
    common.require_bounds(30, 512)
    freeze = common.verify_freeze(args.manifest, args.manifest_sha256)
    approval = common.read_json(args.approval, pin=args.approval_sha256)
    common.require(type(approval) is dict and set(approval) == common.DRAW_APPROVAL_KEYS
        and approval['schema'] == 'fresh-residual-draw-approval-v2'
        and approval['status'] == 'APPROVED_FOR_ONE_FRESH_DRAW_AND_FROZEN_RUN', 'explicit fresh draw approval required')
    public_dir = common.canonical_path(args.public_dir, False)
    secret_dir = common.canonical_path(args.secret_dir, False)
    common.require(public_dir != secret_dir and public_dir not in secret_dir.parents
        and secret_dir not in public_dir.parents and ROOT != secret_dir and ROOT not in secret_dir.parents,
        'separate nonnested custody directories required')
    common.require(not public_dir.exists() and not secret_dir.exists(), 'fresh destination directories required')
    common.require(approval['freeze_sha256'] == args.manifest_sha256
        and approval['analysis_manifest_sha256'] == freeze['analysis_manifest_sha256']
        and approval['resource_allocation_sha256'] == freeze['resource_allocation_sha256']
        and approval['public_dir'] == str(public_dir) and approval['secret_dir'] == str(secret_dir), 'draw approval bindings')
    common.require(freeze['public_paths']['input'] == str(public_dir / 'solver-input.json')
        and freeze['public_paths']['custody'] == str(public_dir / 'custody.json')
        and freeze['public_paths']['run_approval'] == str(public_dir / 'RUN_APPROVAL.json'), 'public destination freeze')
    private_path = common.canonical_path(approval['private_commands_path'])
    common.require(public_dir != private_path.parent and public_dir not in private_path.parents
        and ROOT not in private_path.parents, 'private commands must not be in public/source tree')
    commands = common.read_private_commands(private_path, approval['private_commands_sha256'])
    common.bind_private_command(commands, 'generator',
        {'DRAW_APPROVAL_PIN':args.approval_sha256, 'FREEZE_PIN':args.manifest_sha256}, sys.argv[1:])
    # Exclusive durable approval marker precedes every seed acquisition and destination creation.
    marker = Path(args.approval).with_name(Path(args.approval).name + '.used.json')
    common.write_new(marker, {'schema':'fresh-residual-draw-use-v2',
        'draw_approval_sha256':args.approval_sha256, 'freeze_sha256':args.manifest_sha256,
        'public_dir':str(public_dir), 'secret_dir':str(secret_dir)})
    public_dir.mkdir(mode=0o700)
    secret_dir.mkdir(mode=0o700)
    common.fsync_dir(public_dir.parent)
    common.fsync_dir(secret_dir.parent)
    seed = os.getrandom(32)
    common.require(type(seed) is bytes and len(seed) == 32, 'single seed acquisition must return32bytes')
    seed_pin = hashlib.sha256(seed).hexdigest()
    common.write_new(secret_dir / 'seed.json', {'schema':'fresh-residual-seed-v2', 'seed_hex':seed.hex()})
    common.write_new(public_dir / 'seed-commitment.json',
                     {'schema':'fresh-residual-seed-commitment-v2', 'seed_sha256':seed_pin})
    public, truth = generate(seed)
    common.write_new(public_dir / 'solver-input.json', public, common.PUBLIC_MAX)
    common.write_new(secret_dir / 'truth.json', truth, common.TRUTH_MAX)
    input_pin = common.sha(public_dir / 'solver-input.json', common.PUBLIC_MAX)
    common.read_public(public_dir / 'solver-input.json', input_pin)
    custody = {'schema':'fresh-residual-custody-v2', 'status':'DRAWN_ONCE',
        'public_sha256':input_pin, 'truth_sha256':common.sha(secret_dir / 'truth.json', common.TRUTH_MAX),
        'seed_sha256':seed_pin, 'freeze_sha256':args.manifest_sha256,
        'analysis_manifest_sha256':freeze['analysis_manifest_sha256'],
        'resource_allocation_sha256':freeze['resource_allocation_sha256'],
        'draw_approval_sha256':args.approval_sha256,
        'private_commands_sha256':approval['private_commands_sha256'],
        'python_version':sys.version,
        'rng':'Python random.Random MT19937 from committed256-bit big-endian seed'}
    common.validate_custody(custody, freeze, args.manifest_sha256, input_pin)
    common.write_new(public_dir / 'custody.json', custody)
    common.verify_freeze(args.manifest, args.manifest_sha256)
    candidate = {'schema':'fresh-residual-run-approval-candidate-v2', 'status':'PENDING_GENERATION_RECEIPT',
        'freeze_sha256':args.manifest_sha256, 'input_sha256':input_pin,
        'custody_sha256':common.sha(public_dir / 'custody.json'),
        'draw_approval_sha256':args.approval_sha256,
        'public_input_path':str(public_dir / 'solver-input.json'), 'results_dir':freeze['public_paths']['results']}
    # This child cannot attest its own future outer receipt. Only a separately
    # authorized parent/custodian activation after that receipt/tool completion
    # may publish active RUN_APPROVAL plus sanitized GENERATION-ATTESTATION.
    common.write_new(public_dir / 'RUN_APPROVAL.candidate.json', candidate)
    # The bounded launcher owns logs/receipt. Do not print seed, truth or private paths.
    print(json.dumps({'status':'DRAWN_ONCE', 'input_sha256':input_pin,
                      'custody_sha256':candidate['custody_sha256'],
                      'activation':'PENDING_GENERATION_RECEIPT; no active run approval emitted'}))


if __name__ == '__main__':
    main()
