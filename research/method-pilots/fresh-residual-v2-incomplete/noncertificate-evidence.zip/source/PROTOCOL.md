# Fresh residual validation v2 — proposal only

**Decision requested:** approve source-only preparation of the finite design below,
then independently review and freeze it before a separate one-shot execution
approval. **No source implementation, seed, case, approval file, allocation,
solver run or remote write is created by this proposal.**

This follows the agreed four-stage sequence; it
is not permission to bypass the intervening source/resource gates. The 48-case /
96-job predecessor stays permanently INCOMPLETE and sealed. None of its inputs,
seed, custody or truth was read or may be reused. Full31 pilot A/B passed their
four disclosed slots; those are development results, not fresh samples. The
Local AGENTS/POLICY/current ledger were read. The
ledger checkpoint is content provenance (remote84db7c30), not a Git-parent claim;
local synthetic history must not be presented as remote ancestry.

## 1. Fixed question and model

Does the **unchanged** canonical residual decoder return its complete conditional
relation on fresh synthetic traces, agree with the independently reconstructed
certified-fiber reference, and abstain from semantic claims when preflight gates?
There is no timing contest, new cipher, historical novelty or K4-admission claim.
Matbalez's prior recurrence scope remains unresolved. Passing cannot prove model
membership; the dependent twins deliberately expose false forced predictions.

Keep R=E\\(B union exact156 C), the same 31 original features, six newest-first
lags, support <=3, original support and beta ordering, full-Z26 equality before
reduction, and all old exclusions. No dictionary/order/predicate/optimization/
scoring/saturation change. Full relation means support/beta alpha fibers,
canonical functions, all original sparse lifts, minimum selected lifts, joint
predictions, marginal masks, feasibility and cross-piece provenance—not masks
alone and never a Cartesian product of marginals.

## 2. One finite cohort: 12 traces + 3 dependent truth twins

One separate custodian draws exactly one fresh 256-bit seed after the final
approval. Use the existing pinned Python Random/MT19937 seed convention with
fixed draw order, not candidate rejection. Each of twelve base traces has 97
fresh Z26 symbols c[0..96], 91 contexts x_t=(c[t-1],...,c[t-6]), t=6..96, and
24 observed shifts at t=21..33 and63..73 (rows15..27 and57..67). This is only the
public position pattern; no K4 symbols, target-derived values or old cases enter.
Draw all 97 symbols, then apply the fixed copying rule below where specified.
No equality, rank, uniqueness, workload or solver-output condition selects cases.

For each stratum, repetitions k=0,1,2,3 use respectively q=(28,29,30,28) and
j=(2,8,13,27). Thus lag, its square parity alias, and two pair products all occur.
All unnamed coefficients are zero. Independently draw theta0 uniformly0..25.
Coefficient choices use the listed ordered sets and rng.randrange(len(set)).

| Stratum | Bases | Fixed coefficient draws | Global R proof |
|---|---:|---|---|
| A: equality carried in F13 only |4|theta_q in(2,4,...,24); theta_j in(1,3,...,25)|Nonzero alpha equality gives E; odd j is outside constant/lag1 parity, excluding B and C.|
| B: equality carried in F2 only |4|theta_q=13; theta_j in(2,4,...,24)|Equality beta gives E and excludes B; alpha_q=0 excludes the signed-unit C functions.|
| C: equality in both fields |4|theta_q in(3,5,7,9,11,15,17,19,21,23); theta_j in(1,3,...,25)|Equality in both fields gives E; odd j excludes B and C.|

Compute y_t=theta dot features(x_t) mod26. Define p_t=c_t-y_t mod26 for t>=6;
the six initial symbols are the public initial history, outside the 91-output
claim. Then c_t=p_t+F(c[t-1],...,c[t-6]) is a valid causal synthetic encryption
trace by construction. This is not a natural-language plaintext distribution.
Draw order is strata A/B/C, k0..3; per base draw97 symbols, theta0, theta_q if
variable, theta_j. No extra random choice is conditional on observed values.

**Three constructively misspecified twins:** only k=0 in each stratum copies
c[27:33] to c[84:90] after its97 symbol draws. Consequently x_33=x_90, with
row27 observed and row84 hidden. A twin has the exact same public instance and
truth y'_90=y_90+1 mod26; all other truth values are unchanged. No deterministic
six-input function can fit both y_33 and y'_90. Every nonempty compatible relation
forces y_90=y_33, so an admitted twin must expose that wrong forced value. This
copying is predeclared input construction, not favorable filtering; all later
contexts are rebuilt from the modified contiguous stream. The twins are truth
annotations, not extra solver inputs, worker runs or independent samples.

Denominators: **12 fresh base clusters**, 4 per stratum, **15 truth records**,
3 dependent twins, 91 outputs/base, 24 observed and67 hidden/base. There are804
base hidden positions and201 dependent twin positions; report them separately.
No population confidence interval is justified by this structured small cohort.
IDs are neutral v000..v011 after one fixed final rng.shuffle of the12 bases;
truth retains the stratum/plant/dependency map. Run order is public ID ascending,
normal then optimized, not a performance-dependent order.

## 3. Two fixed resource-gate controls, not fresh observations

Four control slots precede the24 base-mode slots: G0-normal, G0-optimized,
G1-normal, G1-optimized. All use full31/s3. G0 has one zero context and no
observations; G1 has one zero context and observation[[0,0]]. Both must produce
GATE_REJECTED_LOWER_BOUND at the first completely checked support crossing
L>1,000,000, exact_W=null, with no producer/reference-semantic invocation.
G0 deliberately repeats the disclosed no-observation resource condition; it is
not counted as new validation data or a benchmark gain. For G1, the455 supports
inside product coordinates13..27 have rank0 and seven eligible beta assignments,
giving at least455*7*13^3=6,997,445 visits, so the cap must be crossed without
assuming anything about the residual semantic relation. Do not predeclare its
crossing index from an unperformed run. Both controls test the generalized blind
schema path. No new oracle/performance campaign accompanies them.

A correctly certified gate on a random base is an accounted outcome and the
fixed schedule continues. A precheck timeout/cap, semantic incomplete, malformed
certificate, discrepancy, missing receipt or observed OS overshoot stops all
successors; preserve canceled/unstarted slots. This continuation after a valid
random-case gate is explicit and differs from the disclosed pilot's B-stop rule.
There is no retry, resume, replacement or cap increase. Controls or source tests
failing after the one draw consume that draw too.

## 4. Workload proof and semantic acceptance

For every original maximal support T in lexicographic C(31,3), independently
certify raw F13 observation consistency chi_T and complete rank r_T. Independently
recompute all parity assignments and eligible compatible count K_T. Then
W=sum_T chi_T*K_T*13^(3-r_T) is the exact reference traversal count after beta's
B exclusion but before remaining E/C filtering, not the number of functions,
candidates or joint predictions. No
support/beta merging or favorable-rank pruning occurs. One checked prefix with
L>1,000,000 gates; admission requires all4495 supports and exact W<=1,000,000.
Partial/missing/invalid evidence admits nothing and implies no EMPTY/EXACT.

Every admitted base-mode runs the unchanged producer once and unchanged full
verify_result_v3 once. Require VERIFIED_EXACT, complete comparisons and reference
fiber_points=W; all supported plants are mathematically nonempty. A reported
EMPTY is a failure even if some unrelated malformed-input check passes. Verify
all pieces/lifts/joints/provenance before reducing the report. Hash the complete
canonical producer result with only declared timing/resource fields excluded;
normal/optimized semantic hashes, masks, counts and non-time counters must agree.
The two modes must also agree on preflight terminal status, checked support
prefix, L, exact_W and exact certificate bytes. A gate/admission mismatch is a
deterministic correctness failure, not merely a zero-coverage base.
The supervisor compares each completed optimized slot to its normal predecessor
before starting the next pair; disagreement cancels successors before truth
release. The final freeze enumerates exact semantic-hash field exclusions and
the non-time counter fields; a broad resource-field wildcard is forbidden.
No truth is needed for this complete independent comparison.

**SUCCESS_WITH_DECLARED_RESOURCE_GATES**, never unqualified whole-cohort PASS,
requires all28 slots accounted without failure, both controls gated correctly,
all admitted results fully verified, and all of:
- at least6 of12 base clusters admitted and verified in both modes;
- at least2 of4 in each stratum, including all3 preselected twin parents;
- at least12 informative hidden contexts (mask size1..25) across at least3 bases:
  exclude every context appearing in observations, deduplicate repeated hidden
  contexts within each base, and count once across the two modes;
- supported truth retained, zero wrong forced predictions on admitted supported
  bases, and the expected false forced prediction at row84 on each of3 twins.

The first thresholds require half the planned semantic cohort and representation
of each CRT/equality pathway; the12-context gate prevents duplicate-context tautology
alone from satisfying coverage. They are explicit anti-vacuity criteria, not
statistical power claims. All12 passing additionally permits “12/12 semantically
verified.” Below coverage is INSUFFICIENT_SEMANTIC_COVERAGE, including all-gated;
never decoder validation success. No bad outcome authorizes a second draw.

Report separately12 planned / admitted-both-modes / gated-both / mixed-mode /
incomplete / failed / canceled, all stratum counts, 3 twin outcomes, 2 disclosed
controls, 28 slots, exact conditional counts and missing measurements. A base
with only one verified mode contributes zero to semantic coverage. Resource-gated
cases have **no semantic result** even after truth is disclosed. Do not dilute
false forced twin predictions into supported accuracy.

## 5. Minimal source preparation and immutable freeze

A/B preflight is hard-wired to public plants/full outputs and cannot be called
with blind traces. Preserve that entire directory and its receipts unchanged.
Create a new version under /workspace/shared/residual-fresh-validation-v2 only
following source-preparation approval. Reuse its algebra, metering, streaming
writer and independent checker in separately named modules; change ONLY the
public schema binding, fixed IDs/path inventory and schedule/generalized input
validation. Author and reviewer independently inspect those changes. A solver
input never contains theta, true hidden y, seed, stratum or a secret path.

Reuse the actual audited generation approval-use marker, nonnested custody,
canonical byte writer, source/input seal and pre-truth terminal-inventory contract
from canonical-residual-validation-proposal r3. Reuse the full31 one-use
supervisor's wait4, wall watchdog, parent-death chain, finite CPU checks,
filesystem certificate inventory and conservative accounting. Frozen slot/path/
cap constants change, and a narrow separately audited bounded pipe collector is
required: old direct-log behavior is NOT byte-identical to this adaptation.
Do not copy the old96-job counts or the40/41 launcher limits into the new worker.
New bounded_stage.py derives from the pinned old bounded_checked.py, preserving
its two-process limit/death-guard/receipt contract but adding the collector below.
The predecessor launcher remains unchanged. Known compact-vs-pretty, eager loading,
mutable local-only sealing and wrong receipt-command defects must not return.

Freeze one exact list: generator.py, common.py, preflight_blind.py,
checker_blind.py, worker.py, supervisor.py, seal_results.py, analyze.py,
bounded_stage.py, protocol_mock_tests.py, PROTOCOL.md, SCHEMAS.json, CAPS.json, RESOURCE-ALLOCATION.json,
ANALYSIS-MANIFEST.json, interpreter executable/hash/version, unchanged engine /
affine/reference pins and explicit exact commands. No import-time generation.
The schema below is the design, not a claim those new modules exist or are audited.
All -I entry points explicitly load pinned sibling modules by canonical path,
as the full31 worker does; copying r3's bare `from common` imports under -I is
not executable. Public FREEZE.json exposes source/schema/cap pins and worker/mock
commands only; private draw/seal/analysis commands and private destination paths
are frozen separately by the custodian and hash-committed in the approval.

Finite pre-draw source/mock review (normal and-O, no real seed/solver): strict
cap types; duplicate/noncanonical JSON; hidden-field rejection; support/order/
beta/rank/hash/terminal mutations; exact path/file/partial inventory; CPU/nonfinite/
overshoot/missing-receipt stop; wrong external terminal hash before truth access;
approval reuse; masks-only comparison shortcut forbidden. Use previously disclosed
literal records and intercepted nonexistent-truth boundaries, not a covert draw.
Reviewer issues one SOURCE_FREEZE_APPROVED against exact new hashes, schema,
counts, limits and commands. Parent then makes the distinct execution decision.
Exactly two authorized mock invocations, normal and -O, are the whole executable
pre-draw mock inventory: each uses bounded_stage with CPU30/31 per process,
512MiB per process and120-second wall limit. Their exact assertion-count
dictionaries and disclosed literal records must be frozen and independently
reviewed before either invocation. Their combined allowance is124 CPU seconds;
this proposal does not authorize consuming it. No third mock, hidden fixture or
automatic retry is allowed; static preparation is not execution approval.

## 6. Caps, files, accounting and custody

Preflight per instance keeps the pilot's declared counters/caps: supports4495;
generation/audit beta candidates35264 each; parity row tests846336 each;
solves4495; certificate checks8990; row operations1,500,000; logical work50,000,000;
records2,000,000; seconds20; fiber/lift/witness caps0; point admission1,000,000.
All counters are shared cumulatively per preflight; generation+audit are separate
buckets (no accidental single35264 combined ceiling). Validate exact built-in
nonnegative integers (not bool) and finite nonnegative wall values before input,
files and early returns. Original predebit sites, serialized byte charges and
no partial semantic claims are retained. Record reserved versus completed units.

Producer caps stay2,000,000 steps /40,000 pieces /200,000,000 core work /
1,000,000 solves /100,000 terms /30 wall seconds. Reference caps stay1,000,000
fiber /4,000,000 lift /100,000 solves /200,000 certificate checks /5,000,000 row
operations /500,000,000 work /1,000,000 witnesses /5,000,000 records /45 seconds.
The20+30+45 cooperative limits do not promise completion under the outer envelope.

Each of28 slots has exactly one possible evidence path runs/SLOT/case.cert.jsonl,
max32MiB; all28 together <=896MiB. No temporary/backup/copy/alternate certificate
path is permitted. Each canonical UTF8+LF line<=64KiB, predebited before writing;
flush/fsync, exact-byte reread and independent consume before accepting a support.
The terminal hash covers exact preceding bytes; directory fsync completes the
file. Partial bytes remain in place and count forever. Exact filesystem inventory
includes partial and unstarted absence, not just file names claimed in reports.

Per slot: result.json<=2MiB, stdout/stderr<=1MiB each, resource.json<=2MiB;
only fixed state/resource .tmp files<=2MiB are allowed and inventoried as nonresults.
Each new supervisor owns two nonblocking pipes, reads at most16KiB per readiness
event, checks each cumulative log byte cap BEFORE writing, and kills the child
process group on an over-limit byte; excess data is drained/discarded under the
same wall/CPU limits. There are no extra logger subprocesses or threads. The
same bounded collector is used in bounded_stage for mocks, generation, sealing
and analysis. Its own diagnostics are bounded fixed-schema records, not shell
redirection of arbitrary tracebacks. The independent source freeze must verify
pipe closure/reaping/timeout/partial-byte behavior and explicit log inventories.
Preserve race-free unreaped-PID cleanup and alarm ordering: the audited
waitid/WNOWAIT, disarm, then wait4 sequence, or an independently reviewed
equivalent. Bounded draining may not extend the frozen wall deadline.
Final-size inspection alone cannot pass. A certificate allocation
cannot be reused after deletion; no full relation is written to disk. Size-check
before read/hash/parse; streams use bounded buffers. Total stage disk ledger
<=1.25GiB including certificate bytes, logs/reports/state, manifests and partials.
Source/runtime inventory is distinct from separately authorized later publication
copies. No publication or copying certificates into a second bundle is proposed.

**Proposed new allocation: exactly3,000 CPU seconds; currently unallocated.**
28 sequential slots*(75 worker+5 supervisor)=2,240; generation31+31=62;
terminal seal6+6=12; released analysis181+181=362; exactly two mock invocations
31+31 each=124; control, preparation and closeout allowance200. The last200 is
not permission for discretionary solver or test runs. Total retained project allocation
would be20,200/28,800, leaving8,600 unallocated. Earlier contingency is untouched.
Unused slots or allowances do not authorize replacement work or retries.

Each slot worker nominal CPU soft/hard60/75,1GiB address space; supervisor4/5,
256MiB; outer wall150 seconds. Reserve80 durably BEFORE launch; charge OS wait4
worker CPU and full5 supervisor allocation separately from exclusive measured
sample, never double-count nested stages. Actual inclusive outer generation/
seal/analysis receipts are counted once; inner subset timers are not added again.
The sequential maximum for those stages is two768MiB nodes, exactly1.5GiB; enforce
project concurrent memory<=8GiB. Resource limits are per-process address space,
not RSS promises; nominal RLIMIT_CPU is not a proven physical upper bound. Prior
SIGXCPU overshoot remains unexplained. A measured worker>75, supervisor>5,
missing receipt, unreaped child or nonfinite usage is a terminal failure; retain
reserve/unknown state and cancel successors. No overshoot is charged away as PASS.
Final write/exit tails and unmeasured control overhead remain explicit, covered
conservatively by the200 overhead allowance—not mislabeled measured zero.

Custodian consumes path-bound private DRAW_APPROVAL durably before seed draw; commits the seed
hash before cases; stores seed/truth separately and nonnested. Implementation
workers receive no secret path. The slot supervisor receives a distinct public
RUN_APPROVAL, never DRAW_APPROVAL or a private command/freeze manifest. Its fixed
projection contains only run/source/input/custody commitment hashes and public
paths; the custodian's authenticated linkage binds it to the one consumed draw
approval without revealing private destination paths. This is operational separation, not OS or
cryptographic blindness on a shared filesystem. Retain seed commitment on failure.
Only all28 properly terminal slots, zero reserve, valid resource receipts and a
complete post-run source/input/file inventory can reach the separate bounded
pre-truth sealer. It does not open truth. Parent externally retains its terminal
manifest hash and outer receipts BEFORE any release. Certified resource gates
are terminal; failures/cancellations keep truth sealed. Seal success is not
scientific success.

Released analysis authenticates the external terminal seal before opening truth,
then replays the one committed generator draw and requires exact public/truth
identity; this is not a redraw. It checks every planted global predicate/support,
trace encryption identity, observed equality, twin contradiction, masks and all
coverage denominators one report at a time. It does NOT rerun any solver/reference:
full independent comparisons already happened blind in each admitted slot. Global
R membership plus observation fit proves plant membership in the fully verified
relation; counts/masks determine uniqueness/forced correctness. Do not represent
this post-truth algebra and seal check as another independent complete oracle.
Analysis failure preserves sealed statuses and blocks validation success.

## 7. Exact prospective command interface (DO NOT EXECUTE)

New modules below are **not implemented**. During preparation substitute every
path and pin with the frozen absolute literal and retain expanded argv/shell
strings in the appropriate public or custodian-private frozen manifest. No shell PID is supplied as BOUND_EXPECTED_PARENT; only
an actual launching process passes its own PID to a supervised child. Every stage
uses supervisor-owned bounded separately sealed stdout/stderr logs, not unchecked
shell redirection. bounded_stage's positional interface is receipt,cpu,MiB,wall,
stdout_path,stderr_path,then child argv.

```
PY=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12
ROOT=/workspace/shared/residual-fresh-validation-v2
$PY -I -B "$ROOT/bounded_stage.py" MOCK_NORMAL_RECEIPT 30 512 120 MOCK_NORMAL_STDOUT MOCK_NORMAL_STDERR "$PY" -I -B "$ROOT/protocol_mock_tests.py" --freeze-sha256 FREEZE_PIN --output MOCK_NORMAL_OUTPUT
$PY -I -B "$ROOT/bounded_stage.py" MOCK_OPTIMIZED_RECEIPT 30 512 120 MOCK_OPTIMIZED_STDOUT MOCK_OPTIMIZED_STDERR "$PY" -I -B -O "$ROOT/protocol_mock_tests.py" --freeze-sha256 FREEZE_PIN --output MOCK_OPTIMIZED_OUTPUT
$PY -I -B "$ROOT/bounded_stage.py" GENERATION_RECEIPT 30 512 120 GENERATION_STDOUT GENERATION_STDERR "$PY" -I -B "$ROOT/generator.py" --approval DRAW_APPROVAL --approval-sha256 DRAW_APPROVAL_PIN --manifest "$ROOT/FREEZE.json" --manifest-sha256 FREEZE_PIN --public-dir NEW_PUBLIC --secret-dir NEW_SECRET
$PY -I -B "$ROOT/supervisor.py" --job SLOT --approval RUN_APPROVAL --approval-sha256 RUN_APPROVAL_PIN --input NEW_PUBLIC/solver-input.json --input-sha256 INPUT_PIN --freeze-sha256 FREEZE_PIN
$PY -I -B "$ROOT/bounded_stage.py" SEAL_RECEIPT 5 512 120 SEAL_STDOUT SEAL_STDERR "$PY" -I -B "$ROOT/seal_results.py" --input NEW_PUBLIC/solver-input.json --input-sha256 INPUT_PIN --manifest "$ROOT/FREEZE.json" --manifest-sha256 FREEZE_PIN --results "$ROOT/runs" --custody NEW_PUBLIC/custody.json --custody-sha256 CUSTODY_PIN --receipts-manifest RECEIPTS --receipts-manifest-sha256 RECEIPTS_PIN --out TERMINAL_OUTSIDE_RESULTS
$PY -I -B "$ROOT/bounded_stage.py" ANALYSIS_RECEIPT 180 768 600 ANALYSIS_STDOUT ANALYSIS_STDERR "$PY" -I -B "$ROOT/analyze.py" --input NEW_PUBLIC/solver-input.json --input-sha256 INPUT_PIN --manifest "$ROOT/FREEZE.json" --manifest-sha256 FREEZE_PIN --analysis-manifest "$ROOT/ANALYSIS-MANIFEST.json" --analysis-manifest-sha256 ANALYSIS_PIN --results "$ROOT/runs" --results-manifest TERMINAL_OUTSIDE_RESULTS --results-manifest-sha256 EXTERNALLY_RETAINED_TERMINAL_PIN --truth RELEASED_TRUTH --truth-sha256 TRUTH_PIN --custody NEW_PUBLIC/custody.json --custody-sha256 CUSTODY_PIN --out NEW_ANALYSIS
```

Exactly28 slot commands, in the fixed order above; no “while until pass” loop.
Worker argv is the frozen interpreter,-I,-B, optional-O, worker.py,--job,SLOT,
--input,absolute_public,--input-sha256,INPUT_PIN,--output,runs/SLOT/result.json.
Before draw source/command manifest binds public path and post-draw INPUT_PIN
placeholder by a single explicit custody substitution rule; it does not allow
arbitrary flags/paths/source edits. The draw approval binds source, generator,
analysis, schema, caps, resource and both destination hashes/paths. A source
correction after draw preserves the failure, withdraws that fresh claim and
cannot authorize redraw, retry or source-mutated continuation.

## 8. Blocking decisions and stopping condition

| Action | Target | Reason / completed evidence | Status |
|---|---|---|---|
| Accept design and authorize only finite source preparation | parent | Proposal and ancestor pins prepared; no executable new source exists | PENDING |
| Independently review final generalized schema/source/freeze | reviewer | Pilot interface cannot accept blind inputs unchanged; prior audits are not this review | PENDING |
| Authorize3,000 allocation and one path-bound draw/execution | parent | Existing allocation17,200; no new allocation authorized | PENDING |
| Reconcile pilot publication/ledger before launch | parent/publisher | Four pilot PASS receipts independently confirmed; publication in progress at handoff | PENDING |
| Establish custody and external seal retention | separate custodian + parent | Audited contracts exist; no new custodian draw or release performed | PENDING |
| K4 use / historical novelty | separate future decision | Matbalez scope unresolved and synthetic validation not model membership | NOT ADMITTED |

No denied or uncertain operation occurred in this proposal work. Stop after the
independent design verdict and return exact files/pins; this document grants no
next-stage execution authority. End any approved future run with canonical ledger
reconciliation, preserved failures and explicit coverage/result limits before
considering another experiment.
