# Fresh residual v2 — preparation handoff

**Independent source + two-mock PASS. Preparation is complete; no fresh draw or scientific execution is authorized by this result.**

The two permitted commands ran once each, normal then optimized, with final external tool exit 0 and complete sealed receipts. Each passed all **266 frozen operational obligations**. Their reports agree after removing only mode and the two internal timing values. All five prohibited-operation counters are zero. No fresh seed/case, generator expansion, real solver/reference call, old failed-cohort input/custody/truth, K4 use or remote write occurred. Both mock permissions are consumed; no retry or third invocation is available.

## Exact handoff

All stage paths below are under `/workspace/shared/residual-fresh-validation-v2`.

| Artifact | SHA-256 |
|---|---|
| FREEZE.json — source/schema/caps/commands | `77bda1efb5878971eb7ff42feeca26acd1e79813329ca30108b72aeeeebe8767` |
| ANALYSIS-MANIFEST.json | `11c5f756f5f1bd233c0994cc201c3099e929bbb995449e2f1381062001b1382a` |
| SOURCE-SHA256SUMS | `57b8080f3f61ce5c4a3df4bd73bd84e865c658ef9a6d23edcc7e1aa6b8830d77` |
| RESOURCE-ACCOUNTING.json — single deduplicated ledger | `ee3f6022ef74a5d9608687ded8c7c0986a375a1eaece2cbdd568b73c577622cd` |
| mocks/normal/resource.json | `2b5fe2425fdaf7859c93c81720336cba11f87ffbd3a398c807a4055432931236` |
| mocks/optimized/resource.json | `9dd26378ec2b9cc08721349917924804a4afe8e77a4982dd1a837102e49f209b` |

Independent final review: `/workspace/shared/residual-fresh-validation-v2-independent-source-review/REVIEW.md`, SHA `fe4bc1b4c775a677ed892f180b12a725765a491f335aec184e12361e8c1bcf35`. Its `SHA256SUMS` is `a81911255cee4ab857e9810cb855e19cc898564d2acf388d50ea178661761ce0`; all 11 review files pass readback. The earlier pre-mock approval and review are preserved unchanged.

All 21 source/freeze checks pass after execution. No source changed after the reviewed freeze. Predecessor sources/evidence and prefreeze revisions remain preserved. The fixed full31/s3/six-lag/raw-Z26 residual model is unchanged. Mock fixture replay is a disclosed stub, not a scientific reference solve; this PASS is operational preparation, not fresh decoder validation or K4 admission. Matbalez scope remains unresolved.

## Usage and inventory

Exactly **14 files / 46,622 bytes** in the two mock trees; no certificates, bytecode, partials or cohort runs directory. Worker wait4 CPU totals **0.547645 seconds**, supervisor samples **0.240450**, known combined components **0.788095**. Inner timers are subsets, not added again. The full supervisor policy charge is separately **62 seconds** and the two mock slots consume their full **124-second allocation/permissions**. Final-write/control/preparation/review overhead remains unmeasured within the fixed 200-second allowance, not zero.

The reserved new stage allocation is 3,000 seconds; project allocation remains **20,200 / 28,800**. The 2,676-second scientific-stage reservation is still awaiting authority. No earlier contingency was used; no unused capacity authorizes another invocation. OS limits remain nominal per-process limits, not proof of physical CPU maxima or RSS guarantees.

## Separate parent/custodian decision needed

Actual private destinations are proposed only in `/workspace/shared/residual-fresh-validation-v2-proposal/PROPOSED-CUSTODIAN-BINDINGS.json`, SHA `80b43e6c9d3fb31de58b8e256418fbcb9e0648323db6761b9ffbfa1956f6f737`. This proposal is outside the public freeze/worker argv and creates no authority or destination. Do not copy its private values into public source files.

| Action | Target/owner | Reason | Completed | Status |
|---|---|---|---|---|
| Assign operationally separate custodian; approve actual private paths and exact instantiated private command/approval graph | Parent + custodian; proposed binding file above | These literals and one-shot draw authority are not granted by source/mock PASS | No | Pending |
| Draw once only after the private freeze/review and explicit project authority; independently accept generation command/receipt/log/use-marker/postseals and external completion before activating RUN_APPROVAL | Custodian + parent | Generator emits only a pending candidate; self-declared JSON cannot authorize its own outer completion | No | Pending |
| Authorize cohort, terminal seal acceptance and eventual truth release/analysis under the frozen gates | Parent, execution owner, custodian | No scientific invocation or release is authorized now | No | Pending |

No denied or uncertain operation remains. One read-only review-manifest check used the stage cwd rather than the review cwd; the corrected read-only check passed all entries. This was not a mock failure, test retry or source mutation. The full31 publication gate was separately reported verified by the parent at `7b9075daa6aee50187b18794b1d3c97e6d840249`.
