# Fresh residual v2 — independent source and two-mock closeout

**PASS, bounded to the frozen implementation review and exactly two disclosed operational mock executions.** Both normal and optimized completed once, passed all 266 obligations and have identical non-time reports. No known blocker remains for this preparation stage. This is **not fresh scientific validation**, permission to draw, permission to run the real generator/solver/cohort, or K4 admission.

The two mock permissions are consumed. No retry, third mock, source-mutated continuation or use of unused allocation follows from this PASS. The old failed cohort remains permanently INCOMPLETE and sealed.

## Exact reviewed artifacts

Stage root: `/workspace/shared/residual-fresh-validation-v2`.

| Artifact | SHA-256 |
|---|---|
| FREEZE.json | `77bda1efb5878971eb7ff42feeca26acd1e79813329ca30108b72aeeeebe8767` |
| ANALYSIS-MANIFEST.json | `11c5f756f5f1bd233c0994cc201c3099e929bbb995449e2f1381062001b1382a` |
| SOURCE-SHA256SUMS | `57b8080f3f61ce5c4a3df4bd73bd84e865c658ef9a6d23edcc7e1aa6b8830d77` |
| SCHEMAS.json | `0943e4266175ce368abe874a1cbd15e320c90ad72f81dff6cb3b048e3aa61708` |
| PRE-MOCK-APPROVAL.json | `34641ddd61fd6e4dd3d2dbe7dc0915b1146f20710a242d86194eefb5404aad4e` |
| RESOURCE-ACCOUNTING.json | `ee3f6022ef74a5d9608687ded8c7c0986a375a1eaece2cbdd568b73c577622cd` |
| This directory's PRE-MOCK-REVIEW.md | `409ec666f70ff1b0299cdd53057fc574579db6f1729ef3ce4160aac258b2b1d1` |

The immutable pre-mock report contains the full ten-file implementation audit, exact cap/schema/fixture/command checks and the prefreeze findings corrected before execution. It remains unchanged. This closeout incorporates that audit rather than claiming that the mock harness itself proves scientific correctness.

All 21 SOURCE-SHA256SUMS entries and the resolved Python binary were rechecked after both mocks. Source, approval, scientific dependencies and exact frozen commands did not change. The scientific pins remain engine `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`, affine `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`, reference v3 `0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9`. This stage did not import or run those scientific modules.

## Final execution evidence

The implementing owner alone ran the two commands, sequentially. The reviewer ran no mock, solver or additional scientific test. Final external tool completion was reported in trusted execution-owner messages and retained in EXTERNAL-COMPLETION.json; it was not inferred merely from the existence of output files.

| Mode | Final external completion | Result SHA-256 | Resource receipt SHA-256 |
|---|---|---|---|
| normal | chunk `9d12b1`, exit 0, no session | `53869b4532e98305aef44492987c64f6db45ddb700ec20da48ea016b52910c84` | `2b5fe2425fdaf7859c93c81720336cba11f87ffbd3a398c807a4055432931236` |
| optimized | chunk `7d1863`, exit 0, no session | `6a5a9c831c4d640ae0252d04ce1de8e01737ce871812f509d9aa0b4dbdad4015` | `9dd26378ec2b9cc08721349917924804a4afe8e77a4982dd1a837102e49f209b` |

Both receipts say COMPLETED, exit 0, failures empty, child reaped, parent-death guard active, no timeout, no log overflow and no collector error. Both bind the exact mode-specific frozen argv/cwd, approval, freeze, result bytes/hash, one-use marker and bounded log bytes/hash. Normal was independently inspected before the optimized command was allowed to proceed under the existing approval. Namespace-local PIDs 2 and 5 recur in both launch contexts; deduplication uses the distinct mode/command/receipt identities, not globally unique PIDs.

Both PASS reports have null failure and exactly the frozen count dictionary: approval 17; blind schema 15; bounded capture 15; certificate 20; commands 11; CPU scalars 8; custody I/O 5; execution 19; filesystem 12; import safety 9; invalid caps 42; launch caps 20; parser 8; producer digest 5; reaping 6; report 29; state 13; storage 9; truth boundary 3. The sum is 266 per mode, not 532 independent scientific cases.

The complete reports agree after removing only `mode`, `resources.worker_cpu_seconds` and `resources.worker_wall_seconds`. Their common canonical normalized report SHA-256 is `d014d31301b83d90e5e8061a5a2f2ab705680df61a6d4c30fdd42b773dd7f353`. All five prohibited counters are zero in each: actual inner children, generator expansions, real solver calls, seed draws and truth bytes read. The literal scratch fixtures are byte-identical between modes.

## Inventory and cleanup scope

There are exactly seven files per mode: result, resource receipt, one-use marker, stdout, stderr and two fixed scratch JSON fixtures. Normal totals 23,297 bytes; optimized 23,325 bytes; combined **14 files / 46,622 bytes**. Normal stdout is 383 bytes, optimized stdout 386 bytes, and both stderr files are empty. No partials, certificate files, bytecode files, mock-tree symlinks or `runs/` directory exist.

The full observed inventory is recorded in MOCK-INVENTORY.tsv and MOCK-ARTIFACT-SHA256SUMS. The latter's SHA-256 is `59d5bc21cf7de3ebd6e90fdfc1fc95c4badacafcb25ed2d7e93420a12afa3d8a`; it matches the accounting ledger's exact 14-file inventory. Cleanup evidence is the bounded launcher's reaped-worker receipt plus final outer-tool completion with no live session. This is not a machine-global process audit or a claim about unrelated PID namespaces.

## Resource reconciliation

The single stage ledger above was independently checked against both receipts, exact commands, all artifact hashes/sizes and external completion evidence.

| Mode | Worker wait4 CPU seconds | Supervisor exclusive sample seconds | Supervised wall seconds |
|---|---:|---:|---:|
| normal | 0.192429 | 0.119673 | 0.19676580100349383 |
| optimized | 0.355216 | 0.120777 | 0.3832215639995411 |
| totals | **0.547645** | **0.240450** | not a CPU charge |

Known OS-reported worker-plus-supervisor components total **0.788095 CPU seconds**. The ledger serializes the worker sum as `0.5476449999999999`, ordinary binary-float representation of the displayed six-decimal total. Internal mock process timers are subsets of wait4 usage and are not added again. External tool wall values are not CPU charges.

Each supervisor also carries a full 31-second policy allocation charge, **62 total**, distinct from its measured sample. Worker usage plus that full supervisor policy charge is 62.547645, **not measured CPU**. Both slots' full nominal allocations are consumed as permissions: **124 seconds**. There is no failed, unknown or in-flight mock reserve. The separately proposed 2,676-second scientific-stage reservation is still pending authorization; 200 seconds remains the control/preparation/closeout allowance, not an extra test budget. Project allocation 20,200/28,800 is an allocation, not measured use.

Supervisor final receipt/write/exit tails and shell/tool/source-review/metadata/control overhead are explicitly unmeasured, not zero. The reviewer used only read-only shell/hash/JSON processing and local report preparation for closeout; there is no separate measured review-process receipt to add. The allowance is not an empirical claim that every overhead cycle was measured or strictly bounded. No earlier contingency was spent.

Observed usage is below the frozen nominal 30/31-second CPU, 512 MiB per-process address-space and 120-second wall limits. These successful short mocks do **not** establish physical-hard CPU ceilings, RSS guarantees or resolution of the historical CPU-limit overshoot. The collector/reaping/overflow mutations are pure deterministic mocks, not live stress trials.

## What this PASS establishes, and what remains

The independent source review found the frozen implementation consistent with its reviewed design: blinded complete-prefix workload evidence, exact raw-Z26 equality/CRT semantics, global residual predicate, full verification rather than count-only inference, predebited byte/work caps, failure clearing, one-use ordered commands and acyclic public/private custody commitments. The subsequent two executions exercise one frozen operational harness in normal and optimized Python modes. They are not two independently implemented harnesses.

In particular, the certificate envelope fixture uses a disclosed rank-zero literal and equality replay stub, not a real affine solve. Filesystem and reaping mutations use controlled adapters/stubs. The analyzer boundary intercepts a nonexistent truth read. No seed, real generator expansion, solver/reference call, scientific cohort, old failed-cohort input/truth, K4 data or remote write occurred. Classical affine/rank/CRT facts are distinguished from this local engineering application; neither global novelty nor cryptanalytic success is claimed. Prior-source scope limitations, including the unresolved matbalez scope, are unchanged.

Before any fresh draw, separate approval is required for the actual private path bindings and exact instantiated bounded generation command; assign the custodian; authorize one use; and retain the external generation-tool/receipt/log/postseal evidence before activating the public run approval. Later cohort execution, terminal sealing, truth release and analysis remain separate gates under the frozen protocol. A self-declared JSON attestation alone does not supply external chronology or authority. Shared-filesystem blindness remains an operational separation, not a cryptographic access boundary.

The applicable project instructions were read. The second still described pre-mock chronology; this report supplies the verified outcome for the project ledger to be updated. No project register or remote artifact was modified by the reviewer. No operation was denied or left with an uncertain execution outcome. **Preparation-stage review is complete; all further scientific work awaits separate authority.**
