# Fresh residual v2 — independent source and exact mock-freeze review

**PASS for exactly the two frozen pre-draw operational mocks, normal then optimized.** This is not a mock execution result and does not authorize a seed, draw, generator expansion, real solver/reference invocation, cohort, target, truth release or remote write. A failure, missing receipt, overshoot or uncertain outer-tool outcome stops the remaining mock; no retry or third invocation is approved.

## Exact reviewed freeze

Stage: `/workspace/shared/residual-fresh-validation-v2`.

- FREEZE.json: `77bda1efb5878971eb7ff42feeca26acd1e79813329ca30108b72aeeeebe8767`
- ANALYSIS-MANIFEST.json: `11c5f756f5f1bd233c0994cc201c3099e929bbb995449e2f1381062001b1382a`
- SOURCE-SHA256SUMS: `57b8080f3f61ce5c4a3df4bd73bd84e865c658ef9a6d23edcc7e1aa6b8830d77`
- SCHEMAS.json: `0943e4266175ce368abe874a1cbd15e320c90ad72f81dff6cb3b048e3aa61708`
- protocol_mock_tests.py: `3aa9ef81a428681066aee4c8deeb3a269dcf0d6021f62ad2599f58563c7236e5`
- Frozen resolved Python binary: `fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`, version `3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]`.

All 20 manifest source/metadata pins, the freeze pin, the six-file analysis dependency map and the interpreter pin were independently checked. SOURCE-SHA256SUMS contains the 20 source/metadata records plus FREEZE. Five applicable metadata files were byte-compared with sorted compact ASCII JSON plus LF. Exact 28 future job identities/order, two mock commands, paths, 266-count dictionaries, source pins and limit values were inspected. No source-tree symlink or concrete proposed private destination appears in the frozen public files. Mock directories were empty; runs and PRE-MOCK-APPROVAL were absent before approval.

The complete pin list and expanded mock argv are retained beside this report. The unchanged scientific dependencies are engine `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`, affine module `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d` and reference v3 `0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9`.

The current policy/ledger restrictions were observed. Only source/document inspection, shell hashes, static JSON metadata processing and report preparation occurred. No new experimental module was imported, compiled or run. The old failed cohort's inputs/seed/truth/custody were not accessed. Static-control overhead is unmeasured, not zero and not an additional scientific test. No denied or uncertain operation occurred.

## Full implementation review

All ten new Python files were read, including their prefreeze corrections and the final harness. The inherited affine theorem and global plant construction remain as reviewed in the separate DESIGN PASS. This audit does not claim new classical mathematics or global novelty.

**Blinded preflight/checker:** both independently validate the solver-only schema, exact raw-Z26 rows, contiguous history overlap, fixed observations and full original feature list. No plant, stratum or hidden output enters either. The generator retains the original lexicographic support traversal and complete bit-product beta enumeration. The independent serialized checker owns its cursor, sum, hash, original rows and covered-beta recomputation, and delegates only F13 transcript replay to the immutable audited reference. First strict prefix crossing rejects admission; only all 4,495 supports can admit. Invalid/unfinished streams cannot resume or claim completion. Generation/audit counters remain separate under the common work/wall caps. Writer bytes are predebited, fsynced and read back; final metadata hashing is bounded and can demote completion to incomplete. No semantic solver runs on a gate.

**Worker/full verification:** admitted slots call the unchanged producer once and full reference once; VERIFIED_EXACT and reference fiber_points=W are both required, never masks/counts alone. Full producer JSON is streamed to a 64 MiB-bounded digest with only the two exact timing-path exclusions. All non-time counts remain. This digest limit is an explicit finite implementation guard: overflow is failure, not resource admission or semantic success. No full relation is written to disk. Incomplete reports clear producer, verification and semantic_summary, including when failure occurs after a successful verifier or during a later source seal. Attempt flags and nonsemantic resource counters retain unavailable versus uncalled distinctions. Complete component walls above 20/30/45 seconds fail acceptance; incomplete diagnostics may report longer finite elapsed times without advancing.

**Generator and released analyzer:** the fixed 12-base draw order, three CRT/equality strata, constructive copied-context twins, shuffled neutral IDs and 24 observation positions match the design. All generation is inside explicit functions; no import-time generation occurs. The exclusive approval-use marker precedes seed acquisition. A generator child writes only a pending RUN_APPROVAL candidate, not an active approval for its own future outer receipt. Released analysis authenticates the external terminal hash and current complete inventory before its first truth read. It then checks committed-seed replay, plant predicate/support, encryption/observation identities, twin contradiction and all coverage gates without calling a solver/reference. Its report pair is bounded; retained summaries are small, not a full relation. It makes no population power or unconditional-model claim.

**Custody and commitment graph:** the active public approval requires separately retained parent/custodian generation attestation and exact candidate linkage. Private commands/paths are not in worker argv or public freeze. Public input/custody/approval paths and source hashes are fixed. Whole-token derived-pin vocabulary and exact command bindings avoid arbitrary substitution. There is no custody-to-future-approval back-reference, report-to-future-receipt edge or self-hashed terminal. The sealer never opens truth. Actual future private command/path instantiation, generation outer-tool acceptance and sealer outer-tool acceptance remain separate parent/custodian gates; the existence of a self-declared JSON attestation is not proof of chronology or permission. Shared-filesystem separation is operational, not cryptographic blindness.

**Launcher, supervisor and failure accounting:** each invocation has one supervisor and one worker. Logs use two nonblocking pipes, bounded chunks, pre-write caps and kill-on-overflow; no logger process/thread is added. Child PID remains unreaped until alarm disarm and wait4. Parent-death guards accept a legitimate namespace PID 1 while checking identity changes. Supervisor resource limits precede source/prior-output hashing, with only the required fork hard-limit headroom. Receipts enforce exact schemas, types, finite usage, resource caps, component sums, log identities and completed preflight solve/replay topology. Normal/optimized pair identity and exact certificate commitments are checked before a successor pair. Failures preserve partials/reserves and cancel successors. Sampled supervisor CPU and full policy allocations are different quantities; post-sample receipt/state/write/exit tails remain unmeasured. The historical kernel/CPU-limit overshoot is not explained or waived.

The mock launcher itself now requires the exact three-key reviewer approval, pinned source/interpreter, exact fixed outer/child argv and an empty one-use slot. Optimized additionally authenticates the completed normal receipt, marker, logs and report. Local receipt checks cannot establish external tool completion; the runner must also observe successful final tool completion before advancing.

## Prefreeze findings resolved

These were corrected before any mock, with prior source revisions preserved:

1. Worker used `{INPUT_PIN}` substring replacement while the supervisor used whole `${INPUT_PIN}`, leaving an erroneous dollar prefix. Both now require exactly one whole token and reject missing/duplicate/embedded tokens.
2. Terminal snapshot omitted receipts_manifest_path required by analysis. Exact snapshot schema and producer/consumer now agree.
3. Namespace parent PID 1 was wrongly rejected; nominal supervisor limits started after substantial prelaunch work. Both were corrected without changing scientific budgets.
4. Late failure could leave VERIFIED_EXACT counts in an incomplete report. Semantic fields now clear, and receipt guards reject leaks.
5. Bool/int equality and permissive receipt fields could pass malformed mode/count claims. Exact types, key sets and logical cap checks now apply.
6. Worker hashing and certificate metadata hashing needed explicit size/growth bounds. They now reject changed/oversized inputs.
7. Generator originally could emit active run authority before its outer receipt existed. Candidate plus externally verified generation activation replaces that self-authorization.
8. Public contract briefly named proposed private destinations; frozen public documentation now uses private placeholders. Actual private bindings are not approved here.
9. Mock imports of random/secrets could initialize an incidental PRNG. Rejecting stub modules now precede new-source imports; explicit process/entropy entry points and generator/solver calls are blocked.
10. Missing direct filesystem/partial and new mock-launch-gate coverage was added to the same two finite mock invocations. No extra invocation or real certificate was added.

## Exact finite mock scope

Each mode has the same 266 obligations, not 266 scientific cases or independent datasets:

9 import safety; 42 invalid caps; 15 blind schemas; 20 literal certificate envelopes; 8 parsers; 9 storage reservations; 15 bounded capture; 6 reaping-order stubs; 20 launch caps; 8 CPU scalars; 11 commands; 5 producer digest guards; 17 approvals; 13 state shapes; 29 reports/walls/mode checks; 12 virtual filesystems; 19 execution receipts; 5 custody-I/O helpers; 3 terminal-before-truth boundaries.

The certificate fixture uses a disclosed rank-zero literal and equality replay stub, not a real reference solve or fresh proof test. Filesystem mutations use an in-memory Path/hash adapter, creating no certificate. A repeated zero-context structure is only a schema fixture, not a cohort draw. Exclusive-write reuse is helper-level. The positive analyzer boundary stops at an intercepted nonexistent truth read. These limitations are intentional under the no-scientific-execution mock authority.

The only two real processes per mock are its bounded outer supervisor and mock worker. Both use nominal CPU 30/31 seconds, 512 MiB address space and 120-second wall, with 1 MiB logs. The two invocations reserve 124 CPU seconds within the new 3,000 allocation; 200 is reserved for control/preparation/closeout, not discretionary tests. No unused allocation permits a rerun. The total project allocation is 20,200/28,800, not measured use.

Pre-execution stage source/history occupied 927,217 bytes; proposal/design review files another 79,707 bytes before this report. The source/metadata 4 MiB envelope has ample room, and the fixed noncohort group reservations sum 64 MiB within the total 1.25 GiB stage cap. Actual mock inventories and usage must still be checked after each run. No certificate publication copies are included.

## Decision and next gate

The reviewer creates only PRE-MOCK-APPROVAL with schema `fresh-residual-pre-mock-approval-v2`, status `APPROVED_FOR_TWO_FROZEN_MOCKS` and the exact freeze hash above. The implementing owner exclusively runs normal, then optimized only after clean finalized normal completion. This reviewer owns no additional test process.

After both mocks, independently reconcile exact counts, mode invariance, source hashes, artifact inventory, outer receipts, remaining reservations and measured/policy usage. Only then return code/mock findings for a **separate** private-command/custody/draw decision. The frozen PROTOCOL retains the design-stage chronology; current preparation authority is recorded separately in EXECUTION-CONTRACT and RESOURCE-ALLOCATION. No fresh validation or K4 admission is granted by this pre-mock PASS.
