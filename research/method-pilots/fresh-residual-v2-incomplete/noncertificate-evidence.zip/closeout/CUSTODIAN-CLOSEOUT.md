# Fresh residual v2 — custodian failure closeout

**INCOMPLETE; no validation PASS.** One approved fresh seed was drawn and committed once. After the parent's generation acknowledgment, eight of 28 scheduled slots executed once. Slot eight, `v001-optimized`, exhausted the unchanged cooperative preflight wall gate. The frozen controller stopped, retained its conservative 80-second reservation and canceled all 20 successors. No retry, resume, redraw, cap/source change, successful terminal sealer, truth release, analysis, target use or remote write followed.

## Verified chronology and outcomes

- Frozen source and exactly two disclosed operational mocks had independent PASS before draw. Both mock permissions remain consumed; they are not scientific observations.
- Independent private-command instantiation review passed against the already frozen execution contract; no template/source change was made. One bounded generation then completed with outer tool chunk `a40088`, exit 0 and no session. Its receipt records a reaped child, no failures, 0.131048 worker wait4 CPU seconds and 0.047872 supervisor sampled CPU seconds. Source/interpreter, exact public shape, custody commitments, logs and one-use markers were checked.
- The parent acknowledged generation at 2026-10-31 23:50:14 UTC. Only then was the matching public RUN_APPROVAL activated and the blinded runner given safe public bindings. No seed, truth or private path was handed to the runner. This is operational separation on a shared filesystem, not a cryptographic access boundary.
- G0 normal/optimized both certified a resource gate after 89 checked supports, lower bound 1,006,226. G1 normal/optimized both gated after 505 supports, lower bound 1,001,832. All four exact W values remain null and carry no semantic conclusion.
- Fresh `v000` completed all 4,495 supports with W = 1 in both modes; the unchanged producer and full independent reference returned VERIFIED_EXACT and the exact mode comparison passed. This is one complete blind base pair, not a truth-validated success estimate.
- `v001-normal` likewise completed 4,495 supports, W = 1 and full VERIFIED_EXACT. Its optimized counterpart was incomplete: 4,153 fully checked supports, 4,154 support/solve reservations, lower bound 1, exact W null. The normal W must not be transplanted into that incomplete record. This incomplete pair contributes zero to paired semantic coverage.
- Failed preflight diagnostic wall was 20.32284503599658 seconds; worker-internal wall 20.434786878002342; outer supervised wall 21.78825701900496. Its final external tool chunk `5e5512` exited 1 with no live session. Worker wait4 CPU was 16.325925 seconds, supervisor sampled CPU 2.748263. Child reaped, parent-death guard active; no outer watchdog timeout, collector error, log overflow or observed 75/5-second CPU-limit crossing. Producer/reference were not attempted and all semantic fields were cleared.

## Scope and coverage

Schedule: 28 planned, eight executed, seven accepted bounded outcomes (four nonsemantic control gates and three individually verified semantic slots), one failed/incomplete slot, 20 canceled/unstarted slots. Two disclosed control pairs passed their exact gate checks. Among 12 planned fresh base clusters: one verified in both modes, one incomplete pair and ten canceled/unstarted; zero fresh bases certified resource-gated in both modes. The three dependent twins were never analyzed, and their parent identities/strata remain undisclosed here. All stratum, informative-hidden-context, plant-retention, supported-accuracy and false-forced-twin criteria remain unevaluated. No post-truth coverage or population conclusion is available. The six-base minimum is not met, and the required complete 28-slot gate failed.

This is an incomplete validation attempt, not a decoder contradiction, model exclusion, recovery result or timing comparison. The observed normal/optimized difference is completion under a load-sensitive wall gate, not an established semantic disagreement. The earlier 48-case failed cohort remains permanently INCOMPLETE and sealed. Matbalez historical scope remains unresolved; K4 remains NO-GO.

## Preserved evidence and accounting

All 42 original runtime files are inventoried in FAILURE-PRESERVATION.json: 40,761,555 bytes total, including eight original certificate/partial files totaling 40,699,407 bytes. The failed 9,434,520-byte certificate remains at its original path; no certificate was copied, replayed, removed or replaced. State and retained IN_FLIGHT.lock are preserved. The lock/reserve is conservative failure evidence, not a claim of a still-running OS child. All eight children were reaped and final external outcomes retained. This is not a machine-global process audit.

Combined stage components include the two mocks, one generation and eight cohort workers exactly once:

| Component | CPU seconds |
| --- | ---: |
| Worker wait4 total | 51.756527 |
| Supervisor exclusive samples | 4.318978 |
| Known reported component sum | **56.075505** |
| Separate full supervisor policy allocation | **133** |
| Worker actual + full supervisor policy (not measured CPU) | **184.756527** |

Internal phase timers are subsets, not additive charges. Final supervisor receipt/state/write/exit tails and source/review/control overhead remain unmeasured, not zero. The fixed 200-second overhead allowance is an allocation, not proof all overhead cycles were measured. Full stage allocation remains 3,000 and project allocation 20,200/28,800; earlier contingency is untouched. The attempted full nominal allocations total 826 (124 mocks + 62 generation + 640 for eight slots). The retained failed 80 is a subset of that 640, not another added charge. Canceled 20 slots account for 1,600; unlaunched sealer 12 and analysis 362; overhead 200 complete the original 3,000 allocation. None is reusable authority.

Nominal per-process CPU/address-space limits are not proven physical CPU maxima or RSS guarantees. This failure does not reproduce or explain the earlier OS CPU-overshoot anomaly. Exact source and interpreter pins remain unchanged.

## Established cause and bounded next decision

The unchanged Meter checks monotonic elapsed time on charged operations. The same preflight meter spans certificate construction, beta scans, canonical serialization, per-record fsync/readback, independent replay and terminal hashing. Diagnostics establish cooperative wall exhaustion before support 4,154 completed audit; they do not attribute the slowdown among computation, filesystem latency, CPU contention or scheduling. No per-subphase timer supports a stronger root-cause claim.

The best preservation choice is **not another fresh draw**. If the parent later chooses recovery, prefer a separately approved, explicitly labeled post-failure re-evaluation of these exact fixed public input bytes and same sealed truth commitment, retaining original scientific engine/algebra and original INCOMPLETE evidence. That would not be a resumed original run, a new fresh holdout or permission to combine only favorable original slots with replacements. A new versioned orchestration/resource protocol would need independent review, explicit finite envelope/allocation and fixed full schedule, separate output roots/one-use approvals, no data selection, renewed all-slot/pair/custody gates and an explicit truth-release decision. No numerical cap increase is justified or authorized by this report alone.

If a resource-envelope decision needs more evidence, first propose a separately frozen disclosed full-31 control diagnosis recording aggregate preflight generation, serialization/fsync and independent-replay CPU/monotonic timing. That is a proposal only, not an extra permitted invocation. Any such instrumentation or re-evaluation needs new explicit authority; no failed-cohort replay is currently allowed. Repeated replacement draws risk selection and waste and are not recommended.

## Review/publication boundary

Independent final integrity/cause review is pending at this closeout's creation. A sanitized publication/ledger handoff is prepared separately; no remote or repository update has been made by the custodian. Post-run certificate-copy authority has not been granted. The failure-preservation manifest is a read-only byte inventory, **not** the success-only terminal seal and cannot authorize analysis.
