"""Source-only independent preflight negative checks and reviewed shared driver.

This is not a second implementation of the semantic engine. It independently
authors serialized proof mutations and uses independent_checker for every real
support; the common orchestration enforces the same stop rule in every slot.
No extra files, subprocesses, data draws or post-stop executable checks.
"""
import copy
from dataclasses import replace
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/shared/residual-full31-preflight')
EXPECTED = dict(planned_full31_controls=2,malformed_cap_rejections=36,
    independent_stream_mutations=24,parser_rejections=6,poisoned_resume_rejections=6,
    strict_threshold_rejections=2,stream_lifecycle_rejections=2,
    positive_serialized_controls=2,storage_boundary_checks=6,storage_type_rejections=3)
FIELDS = ('max_supports','max_generation_beta_candidates','max_audit_beta_candidates',
    'max_generation_parity_row_tests','max_audit_parity_row_tests','max_fiber_points',
    'max_lift_trials','max_solve_calls','max_certificate_checks','max_row_operations',
    'max_work_units','max_witness_checks','max_output_records','max_file_bytes',
    'max_total_bytes','max_line_bytes','point_cap','max_seconds')


def need(ok,message):
    if not ok:
        raise ValueError(message)


def canonical(obj):
    return (json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def reject(call,exception,label):
    try:
        call()
    except exception as error:
        return str(error)
    raise ValueError('accepted frozen negative: '+label)


def literal(control,reference,point_cap=1000000):
    """The first A support, independently written without elimination."""
    digest = hashlib.sha256(canonical(control)).hexdigest()
    binding = dict(role='full31-workload',field=13,n=3,input_sha256=digest,
                   support=[0,1,2],control='A',reference_version=reference.VERSION)
    certificate = dict(version='affine-certificate-3',q=13,n=3,binding=binding,
        equations_sha256=hashlib.sha256(b'[13,3,[]]').hexdigest(),operations=[],rref=[],
        consistent=True,rank_a=0,rank_aug=0,dimension=3,pivots=[],free=[0,1,2],
        point=[0,0,0],basis=[[1,0,0],[0,1,0],[0,0,1]])
    header = dict(kind='header',schema='full31-workload-evidence-v1',control_id='A',
        input_sha256=digest,fixture_sha256='f'*64,point_cap=point_cap,sparsity=3,
        allowed_features=list(range(31)),reference_sha256=reference.SOURCE_SHA256)
    record = dict(kind='support',index=0,support=[0,1,2],input_sha256=digest,
        certificate=certificate,beta_groups=[0,1,2],
        compatible_betas=[[2],[1,2],[0,2],[0,1,2]],term=8788,prefix_lower_bound=8788)
    return header,record


def footer(header,record,status='GATE_REJECTED_LOWER_BOUND',exact=None):
    return dict(kind='terminal',status=status,support_count=1,lower_bound=8788,
        exact_W=exact,content_sha256=hashlib.sha256(canonical(header)+canonical(record)).hexdigest())


def review_tests(preflight,checker,reference,control):
    counts = dict(planned_full31_controls=2)
    receipts = []
    rejections = []
    def done(name): counts[name] = counts.get(name,0)+1
    def fresh(point_cap=1000000):
        meter = preflight.Meter(replace(preflight.Caps(),point_cap=point_cap),reference)
        audit = checker.EvidenceChecker(control,'f'*64,reference.SOURCE_SHA256,reference,meter,point_cap=point_cap)
        return audit,meter
    need(set(preflight.Caps.__dataclass_fields__) == set(FIELDS),'frozen cap field schema')
    for field in FIELDS:
        for value in ((-1,float('nan')) if field == 'max_seconds' else (-1,True)):
            # Invalid caps must reject at the PUBLIC entry before touching any
            # input, reference module, path or evidence-budget object below.
            bad_caps = replace(preflight.Caps(),**{field:value})
            reject(lambda:preflight.run(None,None,None,None,None,None,None,caps=bad_caps),
                   preflight.PreflightError,'malformed '+field)
            done('malformed_cap_rejections')
    header,record = literal(control,reference)
    audit,meter = fresh()
    audit.consume(canonical(header)); answer = audit.consume(canonical(record))
    need(answer['term'] == 8788 and answer['checked_supports'] == 1 and answer['lower_bound'] == 8788,
         'literal rank-zero contribution')
    need(meter.counts['audit_beta_candidates'] == 8 and meter.counts['audit_parity_row_tests'] == 0,
         'literal complete beta scan')
    need(meter.ref.counts['certificate_checks'] == 1 and meter.ref.counts['solve_calls'] == 0,
         'exactly one serialized replay, no solve')
    done('positive_serialized_controls'); receipts.append(meter.receipt())
    reject(audit.finish,checker.CheckerError,'missing terminal'); done('stream_lifecycle_rejections')

    short_header,short_record = literal(control,reference,8787)
    audit,meter = fresh(8787)
    audit.consume(canonical(short_header)); audit.consume(canonical(short_record))
    end = footer(short_header,short_record)
    terminal = audit.consume(canonical(end)); finished = audit.finish()
    need(terminal['status'] == 'GATE_REJECTED_LOWER_BOUND' and terminal['exact_W'] is None
         and finished['lower_bound'] == 8788 and finished['checked_supports'] == 1,'positive durable prefix format')
    need(finished['bytes'] == sum(map(len,(canonical(short_header),canonical(short_record),canonical(end)))),
         'independent exact byte accounting')
    done('positive_serialized_controls'); receipts.append(meter.receipt())
    reject(lambda:audit.consume(canonical(short_header)),checker.CheckerError,'data after terminal')
    done('stream_lifecycle_rejections')

    # Five header, fifteen support and four terminal mutations; no no-op targets.
    for index in range(24):
        h,r = literal(control,reference,8787)
        e = footer(h,r)
        if index == 0: h['point_cap'] = True
        elif index == 1: h['allowed_features'][0] = False
        elif index == 2: h['fixture_sha256'] = '0'*64
        elif index == 3: h['control_id'] = 'B'
        elif index == 4: h['undeclared'] = 1
        elif index == 5: r['index'] = 1
        elif index == 6: r['support'] = [0,1,3]
        elif index == 7: r['input_sha256'] = '0'*64
        elif index == 8: r['beta_groups'] = [0,1]
        elif index == 9: r['compatible_betas'] = [[2]]
        elif index == 10: r['compatible_betas'].reverse()
        elif index == 11: r['term'] = 8787
        elif index == 12: r['prefix_lower_bound'] = 8787
        elif index == 13: r['certificate']['rank_a'] = 1
        elif index == 14: r['certificate']['basis'].pop()
        elif index == 15: r['certificate']['binding']['support'] = [0,1,3]
        elif index == 16: r['certificate']['q'] = 2
        elif index == 17: r['certificate']['consistent'] = False
        elif index == 18: r['term'] = 8788.0
        elif index == 19: r['beta_groups'][0] = False
        elif index == 20: e['content_sha256'] = '0'*64
        elif index == 21: e['support_count'] = 2
        elif index == 22: e['exact_W'] = 8788
        else: e['status'],e['exact_W'] = 'WORKLOAD_ADMITTED',8788
        audit,meter = fresh(8787)
        def consume_mutation():
            audit.consume(canonical(h)); audit.consume(canonical(r)); audit.consume(canonical(e)); audit.finish()
        reason = reject(consume_mutation,(checker.CheckerError,reference.VerificationError),'stream mutation '+str(index))
        rejections.append(dict(kind='stream',index=index,reason=reason)); receipts.append(meter.receipt())
        done('independent_stream_mutations')

    bad_bytes = [b'{"kind":"header","kind":"header"}\n',canonical(header)[:-1],
        canonical(header)+b'\n',b'{ '+canonical(header)[1:],b'{"x":NaN}\n',canonical(header).decode()]
    for index,raw in enumerate(bad_bytes):
        audit,meter = fresh()
        reason = reject(lambda:audit.consume(raw),checker.CheckerError,'parser '+str(index))
        done('parser_rejections')
        reject(lambda:audit.consume(canonical(header)),checker.CheckerError,'poisoned state cannot resume')
        done('poisoned_resume_rejections'); rejections.append(dict(kind='parser',index=index,reason=reason))
    for status,exact in (('GATE_REJECTED_LOWER_BOUND',None),('WORKLOAD_ADMITTED',8788)):
        h,r = literal(control,reference,8788)
        audit,meter = fresh(8788); audit.consume(canonical(h)); audit.consume(canonical(r))
        reject(lambda:audit.consume(canonical(footer(h,r,status,exact))),checker.CheckerError,'strict cap/inventory boundary')
        done('strict_threshold_rejections')

    caps = preflight.Caps()
    storage = [(0,0,65536,True),(0,0,65537,False),
        (33554431,33554431,1,True),(33554432,33554432,1,False),
        (0,67108863,1,True),(0,67108864,1,False)]
    for file_bytes,total_bytes,amount,accepted in storage:
        if accepted:
            need(preflight.reserve_bytes(file_bytes,total_bytes,amount,caps) ==
                 (file_bytes+amount,total_bytes+amount),'exact storage boundary')
        else:
            reject(lambda:preflight.reserve_bytes(file_bytes,total_bytes,amount,caps),
                   preflight.PreflightLimit,'storage overrun')
        done('storage_boundary_checks')
    for values in ((True,0,1),(0,-1,1),(0,0,1.0)):
        reject(lambda:preflight.reserve_bytes(*values,caps),preflight.PreflightError,'strict storage counter')
        done('storage_type_rejections')
    need(counts == EXPECTED,'complete frozen independent pre-A/B obligations')
    return counts,dict(independent_literal_resources=receipts,rejection_details=rejections,
                       scope='in-memory disclosed first-A-support only; no files or extra solver calls')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    need(sys.flags.isolated and sys.dont_write_bytecode,'isolated no-bytecode invocation')
    freeze_path = ROOT/'FREEZE.json'
    need(freeze_path.is_file() and not freeze_path.is_symlink()
         and freeze_path.stat().st_size <= 1024*1024,'bounded regular source freeze')
    freeze = json.loads(freeze_path.read_bytes())
    need(freeze['version'] == 'full31-preflight-stage-v1','stage identity')
    for name,pin in freeze['files'].items():
        path = Path(name)
        need(path.is_absolute() and path.is_file() and not path.is_symlink() and sha(path) == pin,
             'frozen source before import: '+name)
    for name in ('worker.py','review_worker.py','independent_checker.py'):
        need(str(ROOT/name) in freeze['files'],'missing mandatory script pin')
    spec = importlib.util.spec_from_file_location('full31_shared_worker',ROOT/'worker.py')
    worker = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = worker
    spec.loader.exec_module(worker)
    return worker.main(role='independent-review',test_function=review_tests)


if __name__ == '__main__':
    sys.exit(main())
