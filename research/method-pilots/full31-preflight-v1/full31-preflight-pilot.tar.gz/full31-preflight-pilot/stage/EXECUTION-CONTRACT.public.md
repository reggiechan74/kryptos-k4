# Full-31 preflight pilot: one-use execution contract

This is source preparation, not a launch receipt. The exact two-control design was approved subject to independent source, fixture, schema, cap, command
and launcher freeze confirmation. No supervisor or worker may be imported,
compiled, tested or launched before that final gate. This contract does not
authorize any additional trial or replay.

## Immutable scientific scope

The design is `/workspace/shared/residual-reference-v3-next-stage-proposal/PROPOSAL.md`,
SHA-256 `cdd02be85e643b4226eb4a58bb7eade35f8d28108ea979ba82f87765025c7c0a`.
The fixed producer, affine dependency and independent reference v3 stay unchanged.
Only the disclosed A and B controls are used. No target, fresh holdout, failed
cohort replay, seed, truth or custody access is permitted. There is no source,
fixture, ordering, cap or engine change after the freeze.

## Source gate and schedule

`FREEZE.json` has version `full31-preflight-stage-v1`, an exact source/interpreter
hash mapping `files`, `limits` equal to `supervisor.limits()`, and an insertion-
ordered `jobs` object with exactly these one-use slots:

1. `author-normal`
2. `author-optimized`
3. `review-normal`
4. `review-optimized`

Each job freezes `script`, `cwd`, exact `command`, and `report_identity` containing
exactly `schema`, `suite_role`, `python_optimized`, and `obligations`. Obligations
are nonnegative built-in integer counts. Workers take only `--output` followed
by the exact `runs/<job>/result.json` path. Commands begin with the frozen resolved
Python executable, `-I -B`, then `-O` only in optimized slots, the frozen script,
and the fixed output pair. The whole literal shell launch command is frozen too.

The separate independent `PRE-RUN-APPROVAL.json` must have status
`APPROVED_FOR_FROZEN_DISCLOSED_TESTS` and the exact `freeze_sha256` before the
supervisor will proceed. The supervisor verifies all sources and interpreter
before launch and after reaping. This approval and source identity is attached
to every receipt. An approval object is not created by the supervisor.

## Resource partition

The new allocation is 320 CPU seconds: four worker reservations of 75 and four
supervisor charges of 5. It does not consume or replenish the earlier 680-second
contingency. Conservative project allocation becomes 17,200 of 28,800 CPU seconds;
these are allocations, not measured project use.

Each single-process worker receives nominal OS CPU limits 60 soft / 75 hard,
address space 1 GiB, core size zero, and per-file size 32 MiB. Each supervisor has
CPU 4 soft / 5 hard and address space 256 MiB. Before fork the parent retains only
the hard headroom needed for the child; after fork it lowers its own hard limits.
CPU/address-space limits are process limits, not physical or measured maxima.

The supervisor's independent real-time alarm covers the worker's 150-second wall
allowance, starting just before fork. On alarm it kills the child's process group,
with PID fallback. The child establishes a new session. Parent-death SIGKILL is
set for both supervisor and worker, with parent-identity race checks. The parent
waits using WNOWAIT, disarms the alarm before releasing the PID, then uses wait4
to reap and obtain worker CPU/RSS. There is no polling, retry or child relaunch.

Observed worker CPU above 75, wall above 150, any kill/nonzero exit, or supervisor
sample above 5 makes the stage stop. These checks do not claim that OS enforcement
cannot overshoot or resolve the prior unexplained overshoot. A supervisor killed
before finalization leaves a lock and in-flight reservation: uncertain state,
not permission to retry.

## Durable reservations and evidence inventory

`runs/IN_FLIGHT.lock` is created exclusively, fsynced and directory-fsynced before
any worker. Each launch records its fixed command, approval hash, timestamp and
75 CPU + 5 supervisor + 64 MiB/two-certificate reservation in `runs/state.json`
before fork. State/resource JSON uses a bounded fixed `.tmp`, fsync and atomic
replacement. A leftover temporary state/resource file is an incomplete operation,
not a new slot. No certificate ever uses a temporary or copy path.

Each job directory permits exactly these successful/expected-gate artifacts:

| Path | Ceiling | Purpose |
| --- | ---: | --- |
| `A.cert.jsonl` | 32 MiB | A complete checked prefix, or unfinished evidence |
| `B.cert.jsonl` | 32 MiB | B complete inventory/prefix, or unfinished evidence |
| `result.json` | 2 MiB | Worker summary and identities |
| `stdout.txt` | 32 MiB | Diagnostic output |
| `stderr.txt` | 32 MiB | Diagnostic output |
| `resource.json` | 2 MiB | Supervisor receipt |

The two certificate paths total at most 64 MiB per worker. Across the entire
fixed schedule there are only eight paths and at most 256 MiB. Earlier bytes
never reset or get deleted to reclaim space. The worker pre-debits bytes before
each append; the supervisor separately reserves the entire per-worker allowance
and records actual sizes, counts and SHA-256 after reaping. Complete and partial
files count equally. A/B paths can be absent only when never opened; B must not
be opened if A failed. Incomplete `result.json.tmp`, if produced by interruption,
is retained, inventoried and causes failure; certificate `.tmp` is forbidden.

Every durable certificate terminal is written at the original evidence path.
Its exact streaming schema and support-by-support serialized independent check
are frozen in the preflight contract. The supervisor binds the worker's claims
to actual evidence byte counts and hashes; it does not run a third mathematical
certificate replay. Partial artifacts and their exact hashes are retained.

Outer launch stdout/stderr are fixed in `launch-records/<job>.stdout.txt` and
`.stderr.txt`; shell noclobber (`set -C`) makes existing files a refusal, not a
retry. Successful launch records contain only bounded supervisor diagnostics.
No extra mathematical artifact, scratch certificate, worker or retry is allowed.

## Worker summary and stopping table

Reports contain `status`, `stage_freeze_sha256`, `source_sha256` equal to the
freeze mapping, the exact `report_identity` fields, and `controls` keyed by A/B.
For completed reports, A contains exactly `preflight`. A resource-gated B also
contains exactly `preflight`, so no masks, producer summary or other semantic
claims can leak through. Successful B contains exactly `preflight`,
`producer_status`, `producer_resources`, `verification`, and `producer_summary`.
Explicit INCOMPLETE control dictionaries remain diagnostic, never accepted proofs.
Completed preflight claims include `status`, `checked_supports`, `lower_bound`,
`exact_W`, and `certificate={name,bytes,sha256,complete:true}`. Additional meter
receipts are permitted, not interpreted as semantic verification by the wrapper.

- A must be `GATE_REJECTED_LOWER_BOUND`, with a nonempty checked prefix,
  `lower_bound > 1,000,000`, and `exact_W=null`. A producer and verifier are null.
- B `WORKLOAD_ADMITTED` requires exactly 4,495 checked supports and built-in
  nonnegative integer `exact_W=lower_bound <= 1,000,000`.
- A worker is `PASS` only after that admitted B returns producer `EXACT` and
  full independent verification `VERIFIED_EXACT`, with `fiber_points=exact_W`.
  This equality supplements rather than replaces the full verifier.
- A completed B `GATE_REJECTED_LOWER_BOUND` yields
  `RESOURCE_GATED_NO_SEMANTIC_RESULT`. B producer and verifier must be null.
  It is a retained resource result, not PASS or EMPTY.
- Any unexpected A, preflight/producer/verifier exhaustion, wrong status,
  malformed report, missing/changed evidence, kill, error or measured overrun
  yields `INCOMPLETE_OR_FAILED`. An explicit incomplete worker report carries a
  bounded nonempty `reason`; partial controls are permitted and remain uncertified.

Workers exit zero on a completed expected resource gate so that the supervisor
can distinguish that legitimate gate from a killed or malformed execution. The
supervisor exits 0 for PASS, 2 for expected B gate, and 1 for failure. This exit
classification is not scientific acceptance by itself.

Only PASS allows the next slot. On any other terminal state, the supervisor
records every remaining slot in `canceled`, leaves the one-use lock in place,
and sets `stopped=true`. No later author/reviewer or optimized preflight starts.
There is no rerun, alternative fixture, source correction trial, cap increase,
partial resume or executable post-stop audit without new explicit authority.
Static artifact inspection/reporting remains allowed.

Only four completed PASS receipts support a full pilot PASS. The supervisor
rehashes earlier PASS receipts/evidence before another scheduled slot, checking
exact directory inventories and cumulative ledgers. No source or output from
an earlier failed or resource-gated slot can authorize a new worker.

## Honest accounting

Receipts separate wait4 worker-inclusive CPU, supervisor-exclusive CPU sample,
the full five-second supervisor allocation charge, RSS, wall, signals/exits,
byte/file inventory, and reservation state. Worker timers inside the report are
subsets, not additional CPU to sum. The supervisor sample excludes final receipt
and state fsync/exit tails. Source preparation, orchestration, read/hash/write
and closeout costs are not silently declared zero. PID reuse across namespaces
does not identify a run: deduplicate by job, exact command and receipt hash.

No remaining reservation permits a retry or unplanned analysis. Final independent outcome audit and publication integrity review remain
separate from execution. No remote action belongs to this code.
