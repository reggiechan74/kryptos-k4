# Full31 workload preflight — implementation contract

This is the explicitly authorized disclosed resource pilot, conditional on the
independent final freeze gate. No target, hidden validation, seed, truth, failed
cohort replay, redraw, retry, performance campaign or new hypothesis is included.
Original producer, affine dependency and reference v3 source bytes stay fixed.
This root is separate from every prior stage. Preparation expands only the fixed
public trace with `prepare_fixtures.py`; no rank, workload or semantic result is
computed by preparation. The fixture file, preparation source and all implementation
bytes are pinned before execution. Original proposal and DESIGN PASS are preserved.
The explicitly authorized counter clarification is in `AMENDMENT.md`.

## Exact scope and outcome

Both A and B use all 31 original features, maximal supports in lexicographic
C(31,3) order, sparsity 3, original beta-group identities, and R=E minus (B union
exact 156 C). Equality uses unreduced Z26 values. There is no support/beta merging,
solver cache, pruning, saturation, predicate change or semantic-engine change.

Each support independently receives a fresh raw F13 solve and generated v3
certificate; the v3 generator replays its operations, complete augmented RREF,
rank and full free-coordinate kernel. Its serialized bytes receive the second
certificate replay. The independent checker reconstructs rows and betas from
public input, independently tracks support order, prefix and rolling byte hash.
The exact summand is chi*K*13^(3-rank). No fiber point or lift is visited here.
After the first fully checked support with lower bound >1,000,000, stop without
another support and certify GATE_REJECTED_LOWER_BOUND, exact_W=null. Only a full
4,495-support inventory with W<=1,000,000 returns WORKLOAD_ADMITTED. Any resource
exhaustion is PRECHECK_INCOMPLETE. None of these is semantic EMPTY or EXACT.

A must be certified above-cap, never sent to producer or semantic reference.
Only then B is attempted. B above-cap stops the whole stage as
RESOURCE_GATED_NO_SEMANTIC_RESULT. B incomplete/error or any later failure also
stops the stage and cancels all subsequent slots. When B is fully admitted, the
unchanged producer must return EXACT and unchanged full independent reference v3
must return VERIFIED_EXACT with fiber_points exactly W. This equality is necessary,
not sufficient; all full verifier obligations remain. Only all four successful
slots support pilot PASS. No executable post-stop artifact checking is authorized.

## Frozen public inputs

`fixtures.json` schema full31-public-controls-v1 has exactly controls A then B.
Each control has id, contexts, observed sorted [zero-based row,value] pairs,
public_outputs, stream and original_coefficients. A has one zero context, no
observations, empty public_outputs/stream, and theta28=13 as a nonempty residual
witness. B is exactly the original 97-symbol recurrence, 91 newest-first contexts,
24 observations at t 21..33 and 63..73 (row t-6), public y from the fixed formula,
and theta2=3, theta28=5, theta29=7. Its input c is not output y. All values are public.
The independent checker validates recurrence/context/output/observation/coefficient
bindings at header time; validation is charged, not a third solver pass.

## Meter definitions and predebit behavior

Every cap is validated before input, file creation, early return or prefix path.
Integer fields must be exact built-in nonnegative int (not bool), and wall must be
finite built-in nonnegative int/float. All tests use explicit runtime conditions,
never assert statements. Each control has one shared reference-v3 Meter and
five additional counters, all cumulative. No subcall resets a bucket.

- supports4495: charged once before each generated original support.
- generation_beta_candidates35264 and audit_beta_candidates35264: one per covered
  bit assignment in each respective complete product traversal. Even excluded B
  assignments and inconsistent F13 supports are included. Combined maximum 70528.
- generation_parity_row_tests846336 and audit_parity_row_tests846336: each candidate
  tests every observed row; mismatch never skips later rows. Combined 1692672.
- solve_calls4495; certificate_checks8990; generated+replayed row_operations1500000.
  These are the unchanged v3 charge sites (generator includes first replay;
  serialized audit includes second). No third certificate replay in each control.
- work_units50000000: shared old v3 algebra/validation work plus every new counter
  debit; explicit reconstructed matrix scalar slots; feature32 units/context;
  parity-dot active coordinates (minimum1); selected beta list copying; input and
  schema validation; prefix arithmetic; canonical encoding precharged at the64 KiB-line upper bound /64; exact
  readback/hash/parsing precharged in ceil(bytes/64) blocks (minimum1). A byte block is an explicit new
  serialization work unit, not an old arithmetic point or physical CPU claim.
- output_records2000000: unchanged v3 certificate/matrix/kernel records plus each
  streaming record and retained compatible beta/list coordinate counted by each
  implementation. Temporary decoded structures are bounded by64 KiB per line.
- fiber_points0, lift_trials0, witness_checks0. No semantic enumeration here.
- max_seconds 20 per control, checked by shared meter at every work/debit and
  completion. Outer independent wall watchdog 150 remains separate.
- file32 MiB, two-file shared total64 MiB, line64 KiB, point admission1000000.

Producer unchanged limits: steps2000000,pieces40000,core_work200000000,
core_solves1000000,core_terms100000,wall30. Full reference unchanged limits:
fiber1000000,lift4000000,solve100000,checks200000,row_ops5000000,
work500000000,witness1000000,records5000000,wall45.

## Durable streaming evidence

Exactly A.cert.jsonl and B.cert.jsonl are possible per worker. No temporary,
backup, copied certificate or alternate certificate path is permitted. Exactly
eight possible paths over the stage, at most256 MiB; B may be absent if unstarted.
The writer exclusively creates each file, predebits line/file/shared-worker bytes
before write (no refunds), flushes and fsyncs each line, rereads those exact bytes,
and passes them to the independent stateful checker. Partial bytes remain at the
same path and count; missing or invalid terminal never admits semantic execution.
A partially checked support never contributes to certified prefix lower bound.
Completion marker is written/fsynced only after checked support inventory; the
containing directory is fsynced before claiming durable completion. No deletion
reclaims evidence budget. Canonical JSON: sorted keys, compact separators,
allow_nan=False, UTF8, one LF. Duplicate keys/noncanonical bytes are rejected.

Header exact fields: kind=header,schema=full31-workload-evidence-v1,control_id,
input_sha256 (canonical control bytes including LF),fixture_sha256,point_cap,
sparsity,allowed_features,reference_sha256.

Support exact fields: kind=support,index (zero-based),support,input_sha256,
certificate (unchanged v3 schema),beta_groups,compatible_betas,term,
prefix_lower_bound. Compatible beta order is lexicographic product((0,1),repeat=k)
with active sorted groups and B-only assignments omitted. Original supports are
never collapsed when matrices agree. Certificate binding is exactly role=
full31-workload,field13,n3,input_sha256,support,control,reference_version.

Terminal exact fields: kind=terminal,status, support_count,lower_bound,exact_W,
content_sha256 (all exact preceding line bytes). Terminal status is either
GATE_REJECTED_LOWER_BOUND with null exactW, or WORKLOAD_ADMITTED with all 4495
supports and exactW=lower_bound<=cap. Checker's own cursor/L/hash independently
bind these claims. A complete evidence marker does not override an incomplete
outer call, source identity error, resource excess or semantic failure.

Worker report<=2 MiB retains statuses/resources, certificate hashes/bytes/complete
flags, test obligations and identity. Full producer/verifier comparisons occur
inside worker; the report retains full verification summary and bounded producer
summary, not a replacement standalone semantic proof. Certificate streaming is
the durable mathematical proof of this preflight only.

## Finite disclosed API tests

Each role executes exactly36 malformed-cap negatives: for all 17 integer fields,
-1 and True; for wall,-1 and NaN. One rank-zero support [0,1,2] record is a literal
positive control with term8788 and no observations. Exactly 8 mutations change
support,index,input binding,groups,beta list,term,prefix sum or rank. They must be
rejected. Six pure storage boundary cases exercise the actual writer reservation
helper at exact/over line, per-file and shared-total limits; no files are created. Every check uses a new finite Meter; those finite test counters are
reported as diagnostic subsets of the allocated worker CPU. They write no
certificate files and do not form extra full31 trial slots. Independent review slots use a separately authored in-memory suite: 36 malformed
cap rejections; 24 stream mutations (5 header, 15 support, 4 terminal); 6 parser
negatives; 6 poisoned-resume negatives; 2 strict threshold/inventory negatives;
2 lifecycle negatives; 2 positive serialized controls; 6 storage boundaries;
and 3 storage-counter type negatives. Its literal positive prefix uses the same
first A support with test-only point cap 8787; equality at 8788 must not reject,
and a one-support inventory cannot admit. This does not alter either real control.
The exact review_worker.py EXPECTED map and source bytes are frozen. No executable tests or source imports occur before final joint approval.

## Accounting and interpretation

New stage allocation 320 CPU seconds: workers 300, supervisors 20. Conservative project
allocation 17200/28800, not measured project CPU. Previous 680 contingency untouched.
Nominal CPU/RSS limits are not measured maxima. Any overshoot cancels dependent
work. Keep worker-inclusive wait4 CPU, supervisor-exclusive samples, full supervisor
policy charges and unresolved reservations separate. Preparation, control, source
hashing and final-write tails are disclosed unmeasured, not relabeled zero.
Classical affine rank/cardinality calculation; no global novelty or cryptanalytic
speedup claim. Matbalez historical scope remains unresolved. Failed cohort stays
permanently INCOMPLETE and sealed. K4 remains NO-GO.
