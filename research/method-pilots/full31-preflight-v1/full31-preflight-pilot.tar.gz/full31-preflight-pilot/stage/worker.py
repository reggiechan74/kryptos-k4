"""Frozen two-control worker. No retries, substitutions, or hidden controls."""
import argparse
from dataclasses import asdict, replace
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT=Path('/workspace/shared/residual-full31-preflight')
REFERENCE=Path('/workspace/shared/canonical-residual-reference-v3/reference_v3.py')
ENGINE=Path('/workspace/shared/canonical-residual-dev/residual_decoder.py')
DEPENDENCY=ENGINE.with_name('affine_filter.py')
REPORT_MAX=2*1024*1024

def require(ok,message):
    if not ok:raise ValueError(message)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_report(path,result):
    data=(json.dumps(result,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    require(len(data)<=REPORT_MAX,'report limit')
    with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def author_tests(preflight,checker,reference,control):
    """Pure disclosed in-memory API negatives; never an extra evidence file."""
    rejected=0
    for field in asdict(preflight.Caps()):
        values=(-1,float('nan')) if field=='max_seconds' else (-1,True)
        for bad in values:
            try:preflight.validate_caps(replace(preflight.Caps(),**{field:bad}))
            except preflight.PreflightError:rejected+=1
            else:raise ValueError('malformed cap accepted: '+field)
    require(rejected==36,'cap rejection count')
    # A single rank-zero support certificate is literal, not a new model/trial.
    digest=preflight.input_hash(control)
    certificate={'version':reference.CERT_VERSION,'q':13,'n':3,'binding':preflight.binding(control,[0,1,2],digest,reference),'equations_sha256':hashlib.sha256(b'[13,3,[]]').hexdigest(),'operations':[],'rref':[],'consistent':True,'rank_a':0,'rank_aug':0,'dimension':3,'pivots':[],'free':[0,1,2],'point':[0,0,0],'basis':[[1,0,0],[0,1,0],[0,0,1]]}
    record={'kind':'support','index':0,'support':[0,1,2],'input_sha256':digest,'certificate':certificate,'beta_groups':[0,1,2],'compatible_betas':[[2],[1,2],[0,2],[0,1,2]],'term':8788,'prefix_lower_bound':8788}
    header={'kind':'header','schema':preflight.VERSION,'control_id':'A','input_sha256':digest,'fixture_sha256':'a'*64,'point_cap':1000000,'sparsity':3,'allowed_features':list(range(31)),'reference_sha256':reference.SOURCE_SHA256}
    def check_literal(value):
        meter=preflight.Meter(preflight.Caps(),reference)
        audit=checker.EvidenceChecker(control,'a'*64,reference.SOURCE_SHA256,reference,meter)
        audit.consume(preflight.canonical(header))
        answer=audit.consume(preflight.canonical(value))
        return answer,meter
    answer,meter=check_literal(record)
    require(answer['term']==8788,'positive literal record')
    mutations=[('support',[0,1,3]),('index',1),('input_sha256','0'*64),('beta_groups',[0,1]),('compatible_betas',[[2]]),('term',8787),('prefix_lower_bound',8787),('certificate',dict(certificate,rank_a=1))]
    positive_resources=meter.receipt()
    negative_resources=[]
    for key,value in mutations:
        changed=dict(record);changed[key]=value
        meter=preflight.Meter(preflight.Caps(),reference)
        audit=checker.EvidenceChecker(control,'a'*64,reference.SOURCE_SHA256,reference,meter)
        audit.consume(preflight.canonical(header))
        try:audit.consume(preflight.canonical(changed))
        except (ValueError,reference.VerificationError):pass
        else:raise ValueError('certificate mutation accepted: '+key)
        negative_resources.append(meter.receipt())
    storage=storage_tests(preflight)
    return {'planned_full31_controls':2,'malformed_cap_rejections':rejected,'certificate_mutations':len(mutations),'positive_serialized_control':1,'storage_boundary_checks':storage}, {'literal_positive_resources':positive_resources,'mutation_resources':negative_resources}

def storage_tests(preflight):
    caps=preflight.Caps();checks=0
    cases=[(0,0,caps.max_line_bytes,True),(0,0,caps.max_line_bytes+1,False),
           (caps.max_file_bytes-1,0,1,True),(caps.max_file_bytes,0,1,False),
           (0,caps.max_total_bytes-1,1,True),(0,caps.max_total_bytes,1,False)]
    for file_bytes,total_bytes,amount,accepted in cases:
        try:
            result=preflight.reserve_bytes(file_bytes,total_bytes,amount,caps)
            require(accepted and result==(file_bytes+amount,total_bytes+amount),'storage reservation outcome')
        except preflight.PreflightLimit:
            require(not accepted,'valid storage boundary rejected')
        checks+=1
    return checks

def main(role='author',test_function=None):
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    output=Path(args.output)
    freeze_path=ROOT/'FREEZE.json';freeze=json.loads(freeze_path.read_bytes());freeze_hash=sha(freeze_path)
    require(output.parent.name in freeze['jobs'] and output.name=='result.json','fixed report path')
    spec=freeze['jobs'][output.parent.name]
    require(str(output)==spec['command'][-1] and spec['report_identity']['suite_role']==role,'worker identity')
    for path,digest in freeze['files'].items(): require(sha(path)==digest,'source pin: '+path)
    result={'schema':'full31-preflight-report-v1','suite_role':role,'python_optimized':bool(sys.flags.optimize),'stage_freeze_sha256':freeze_hash,'source_sha256':freeze['files'],'status':'INCOMPLETE_OR_FAILED','controls':{},'obligations':None,'reason':None}
    started=time.monotonic()
    try:
        reference=load('reference_v3_full31',REFERENCE)
        preflight=load('preflight_full31',ROOT/'preflight.py')
        checker=load('independent_checker_full31',ROOT/'independent_checker.py')
        fixtures=json.loads((ROOT/'fixtures.json').read_bytes())
        require(fixtures['schema']=='full31-public-controls-v1' and [c['id'] for c in fixtures['controls']]==['A','B'],'fixture identity')
        controls=fixtures['controls'];budget=preflight.EvidenceBudget()
        test_function=test_function or author_tests
        obligations,test_receipts=test_function(preflight,checker,reference,controls[0])
        result['obligations']=obligations;result['test_resources']=test_receipts
        require(obligations==spec['report_identity']['obligations'],'frozen test obligations')
        fixture_sha=sha(ROOT/'fixtures.json');reference_sha=sha(REFERENCE)
        a=preflight.run(controls[0],output.parent/'A.cert.jsonl',fixture_sha,reference_sha,reference,checker,budget)
        result['controls']['A']={'preflight':a}
        require(a['status']=='GATE_REJECTED_LOWER_BOUND' and a['lower_bound']>1000000 and a['exact_W'] is None and a['certificate']['complete'],'A failed safe-rejection gate')
        b=preflight.run(controls[1],output.parent/'B.cert.jsonl',fixture_sha,reference_sha,reference,checker,budget)
        result['controls']['B']={'preflight':b}
        if b['status']=='GATE_REJECTED_LOWER_BOUND':
            result['status']='RESOURCE_GATED_NO_SEMANTIC_RESULT'
            result['reason']='B checked workload lower bound exceeds fixed point allowance; all later slots canceled'
        else:
            require(b['status']=='WORKLOAD_ADMITTED' and b['checked_supports']==4495 and type(b['exact_W']) is int and b['exact_W']<=1000000 and b['certificate']['complete'],'B workload preflight incomplete')
            load('affine_filter',DEPENDENCY);engine=load('residual_decoder_full31',ENGINE)
            control=controls[1];obs=dict(control['observed'])
            producer=engine.decode(control['contexts'],obs,3,list(range(31)),budget=engine.Budget(max_steps=2000000,max_pieces=40000,max_core_work=200000000,max_core_solves=1000000,max_core_terms=100000,max_seconds=30.0))
            result['controls']['B']['producer_status']=producer['status']
            result['controls']['B']['producer_resources']=producer['resources']
            require(producer['status']=='EXACT','B producer not EXACT')
            vb=reference.BudgetV3(max_fiber_points=1000000,max_lift_trials=4000000,max_solve_calls=100000,max_certificate_checks=200000,max_row_operations=5000000,max_work_units=500000000,max_witness_checks=1000000,max_output_records=5000000,max_seconds=45.0)
            verified=reference.verify_result_v3(control['contexts'],obs,producer,3,list(range(31)),budget=vb,expected_source_sha256=sha(ENGINE))
            result['controls']['B']['verification']=dict(verified,fiber_points=verified['resources']['fiber_points'])
            require(verified['status']=='VERIFIED_EXACT' and verified['resources']['fiber_points']==b['exact_W'],'B independent full semantic verifier failed')
            result['controls']['B']['producer_summary']={'pieces':len(producer['pieces']),'masks':producer['masks'],'feasibility_witness':producer['feasibility_witness']}
            result['status']='PASS'
        result['certificate_total_bytes']=budget.bytes
    except BaseException as exc:
        result['status']='INCOMPLETE_OR_FAILED';result['reason']=type(exc).__name__+': '+str(exc)[:500]
    result['attempted_control_count']=len(result['controls'])
    result['worker_wall_seconds']=time.monotonic()-started
    write_report(output,result)
    return 0 if result['status'] in ('PASS','RESOURCE_GATED_NO_SEMANTIC_RESULT') else 1

if __name__=='__main__':sys.exit(main())
