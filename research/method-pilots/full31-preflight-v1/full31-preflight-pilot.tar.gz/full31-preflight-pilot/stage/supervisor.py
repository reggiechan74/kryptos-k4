"""One-use, source-frozen full-31 pilot supervisor; never a semantic solver.

Source preparation only until the independently approved FREEZE exists.
Expected B resource gating is terminal, not PASS and not authorization to replay.
"""
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys
import time

ROOT = Path('/workspace/shared/residual-full31-preflight')
FREEZE = ROOT / 'FREEZE.json'
APPROVAL = ROOT / 'PRE-RUN-APPROVAL.json'
RUNS = ROOT / 'runs'
STATE = RUNS / 'state.json'
LOCK = RUNS / 'IN_FLIGHT.lock'
VERSION = 'full31-preflight-stage-v1'
JOBS = ('author-normal', 'author-optimized', 'review-normal', 'review-optimized')
MIB = 1024 * 1024
REPORT_MAX = 2 * MIB
FILE_MAX = 32 * MIB
CERT_JOB_MAX = 64 * MIB
CERT_STAGE_MAX = 256 * MIB
WORKER_CPU = 75
SUPERVISOR_CHARGE = 5
WORKER_TOTAL = 300
SUPERVISOR_TOTAL = 20
WALL = 150
POINT_CAP = 1000000
CERT_NAMES = ('A.cert.jsonl', 'B.cert.jsonl')
ARTIFACT_NAMES = ('stdout.txt', 'stderr.txt', 'result.json') + CERT_NAMES
TERMINAL = ('PASS', 'RESOURCE_GATED_NO_SEMANTIC_RESULT', 'INCOMPLETE_OR_FAILED')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def numeric(value):
    return ((type(value) is int and value >= 0)
            or (type(value) is float and math.isfinite(value) and value >= 0))


def integer(value, maximum=None):
    return type(value) is int and value >= 0 and (maximum is None or value <= maximum)


def digest_string(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as handle:
        while True:
            block = handle.read(MIB)
            if not block:
                return h.hexdigest()
            h.update(block)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def read_json(path, limit):
    require(path.is_file() and not path.is_symlink(), 'missing/symlink JSON')
    require(path.stat().st_size <= limit, 'oversized JSON')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    require(len(data) <= limit, 'JSON grew past limit')
    return json.loads(data, object_pairs_hook=unique_object,
                      parse_constant=lambda _value: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def fsync_dir(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic(path, obj):
    """Only small state/resource JSON may use a fixed .tmp; never certificates."""
    data = (json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    require(len(data) <= REPORT_MAX, 'supervisor JSON limit')
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('xb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    fsync_dir(path.parent)


def death_guard(expected):
    require(os.getppid() == expected, 'parent changed before guard')
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'PR_SET_PDEATHSIG')
    if os.getppid() != expected:
        os.kill(os.getpid(), signal.SIGKILL)


def limits():
    return dict(worker_cpu_soft=60, worker_cpu_hard=75,
        supervisor_cpu_soft=4, supervisor_cpu_hard=5,
        worker_address_space_bytes=1024*MIB, supervisor_address_space_bytes=256*MIB,
        wall_seconds=WALL, worker_total_cpu_allocation=WORKER_TOTAL,
        supervisor_total_cpu_allocation=SUPERVISOR_TOTAL,
        report_max_bytes=REPORT_MAX, file_max_bytes=FILE_MAX,
        certificate_worker_max_bytes=CERT_JOB_MAX,
        certificate_stage_max_bytes=CERT_STAGE_MAX, certificate_stage_max_files=8)


def certificate_claim(value, name, complete):
    require(type(value) is dict and set(value) == {'name', 'bytes', 'sha256', 'complete'},
            'certificate claim schema')
    require(value['name'] == name and integer(value['bytes'], FILE_MAX), 'certificate name/bytes')
    require(digest_string(value['sha256']), 'certificate digest')
    require(type(value['complete']) is bool and value['complete'] is complete, 'certificate completion claim')


def checked_preflight(value, name):
    require(type(value) is dict, 'preflight object')
    require(integer(value.get('checked_supports'), 4495), 'checked support count')
    require(integer(value.get('lower_bound')), 'preflight lower bound')
    certificate_claim(value.get('certificate'), name + '.cert.jsonl', True)
    status = value.get('status')
    if status == 'GATE_REJECTED_LOWER_BOUND':
        require(0 < value['checked_supports'] <= 4495 and value['lower_bound'] > POINT_CAP,
                'invalid gate prefix')
        require(value.get('exact_W') is None, 'prefix incorrectly claims exact count')
    elif status == 'WORKLOAD_ADMITTED':
        require(value['checked_supports'] == 4495, 'admitted incomplete support inventory')
        require(integer(value.get('exact_W'), POINT_CAP) and value['exact_W'] == value['lower_bound'],
                'admitted workload count')
    else:
        raise ValueError('invalid completed preflight status')
    return status


def validate_report(report, spec, freeze, freeze_hash):
    """Pure report identity/status checks; no mathematical replay or launch."""
    require(type(report) is dict and report.get('status') in TERMINAL, 'worker report status')
    require(report.get('stage_freeze_sha256') == freeze_hash, 'report freeze identity')
    require(type(report.get('python_optimized')) is bool, 'report optimization type')
    require(report.get('source_sha256') == freeze['files'], 'report source identities')
    expected = spec['report_identity']
    require(set(expected) == {'schema', 'suite_role', 'python_optimized', 'obligations'}, 'frozen report identity schema')
    for field, value in expected.items():
        require(report.get(field) == value, 'report identity: ' + field)
    require(type(report.get('obligations')) is dict and
            all(integer(v) for v in report['obligations'].values()), 'report obligation counts')
    controls = report.get('controls')
    require(type(controls) is dict and set(controls) <= {'A', 'B'}, 'report controls schema')
    if report['status'] == 'INCOMPLETE_OR_FAILED':
        require(type(report.get('reason')) is str and 0 < len(report['reason']) <= 2000,
                'incomplete report reason')
        return report['status']
    require(set(controls) == {'A', 'B'}, 'completed worker needs both controls')
    a, b = controls['A'], controls['B']
    require(type(a) is dict and type(b) is dict, 'control object')
    require(set(a) == {'preflight'}, 'A must contain only preflight claims')
    require(checked_preflight(a.get('preflight'), 'A') == 'GATE_REJECTED_LOWER_BOUND',
            'A must certify resource rejection')
    require(a.get('producer_status') is None and a.get('verification') is None,
            'A semantic work forbidden')
    bstatus = checked_preflight(b.get('preflight'), 'B')
    if report['status'] == 'RESOURCE_GATED_NO_SEMANTIC_RESULT':
        require(bstatus == 'GATE_REJECTED_LOWER_BOUND', 'B gate status mismatch')
        require(set(b) == {'preflight'}, 'gated B must contain only preflight claims')
        require(b.get('producer_status') is None and b.get('verification') is None,
                'gated B semantic work forbidden')
    else:
        require(set(b) == {'preflight', 'producer_status', 'producer_resources', 'verification', 'producer_summary'},
                'successful B exact claim schema')
        require(bstatus == 'WORKLOAD_ADMITTED' and b.get('producer_status') == 'EXACT',
                'B producer/gate not exact')
        verification = b.get('verification')
        require(type(verification) is dict and verification.get('status') == 'VERIFIED_EXACT',
                'B full verifier did not succeed')
        require(integer(verification.get('fiber_points')) and
                verification['fiber_points'] == b['preflight']['exact_W'],
                'successful verifier workload does not equal full preflight W')
    return report['status']


def validate_receipt(receipt, spec, job, freeze, freeze_hash, approval_hash):
    """Pure completed PASS/gate receipt checks, never evidence replay."""
    require(type(receipt) is dict and receipt.get('version') == VERSION, 'receipt version')
    require(receipt.get('status') in TERMINAL[:2] and receipt.get('job') == job, 'receipt job/status')
    require(receipt.get('command') == spec['command'] and receipt.get('cwd') == spec['cwd'], 'receipt command/cwd')
    require(receipt.get('freeze_sha256') == freeze_hash and receipt.get('approval_sha256') == approval_hash,
            'receipt pins')
    require(receipt.get('limits') == freeze['limits'], 'receipt limits')
    require(type(receipt.get('exit_code')) is int and receipt['exit_code'] == 0, 'receipt exit')
    require(receipt.get('wall_timeout') is False and receipt.get('child_reaped') is True, 'receipt timeout/reaped')
    require(receipt.get('parent_death_guard') is True and receipt.get('failures') == [], 'receipt safety')
    require(numeric(receipt.get('wall_seconds')) and receipt['wall_seconds'] <= WALL, 'receipt wall')
    for name in ('child_user_cpu_seconds', 'child_system_cpu_seconds', 'child_cpu_seconds',
                 'supervisor_exclusive_cpu_sample'):
        require(numeric(receipt.get(name)), 'receipt finite CPU: ' + name)
    require(abs(receipt['child_user_cpu_seconds'] + receipt['child_system_cpu_seconds']
                - receipt['child_cpu_seconds']) <= 1e-8, 'receipt CPU components')
    require(receipt['child_cpu_seconds'] <= WORKER_CPU, 'receipt worker allocation')
    require(receipt['supervisor_exclusive_cpu_sample'] <= SUPERVISOR_CHARGE, 'receipt supervisor sample')
    require(type(receipt.get('supervisor_cpu_allocation_charged')) is int and
            receipt['supervisor_cpu_allocation_charged'] == SUPERVISOR_CHARGE, 'receipt supervisor charge')
    require(receipt.get('supervisor_final_write_tail_measured') is False, 'receipt tail claim')
    for name in ('supervisor_pid', 'child_pid'):
        require(type(receipt.get(name)) is int and receipt[name] > 1, 'receipt PID')
    require(receipt['supervisor_pid'] != receipt['child_pid'], 'receipt distinct PIDs')
    for name in ('child_peak_rss_kib', 'supervisor_peak_rss_kib'):
        require(integer(receipt.get(name)), 'receipt RSS')
    inventory = receipt.get('inventory')
    require(type(inventory) is list and len(inventory) == len(ARTIFACT_NAMES), 'receipt artifact count')
    names = []
    cert_bytes = 0
    for item in inventory:
        require(type(item) is dict and set(item) == {'name', 'bytes', 'sha256', 'classification'},
                'receipt inventory schema')
        name = item['name']
        require(type(name) is str and name in ARTIFACT_NAMES and name not in names, 'receipt artifact name')
        require(integer(item['bytes'], REPORT_MAX if name == 'result.json' else FILE_MAX), 'receipt bytes')
        require(digest_string(item['sha256']), 'receipt artifact digest')
        classification = ('certificate_evidence' if name in CERT_NAMES else
                          'result' if name == 'result.json' else 'diagnostic_nonresult')
        require(item['classification'] == classification, 'receipt artifact classification')
        names.append(name)
        if name in CERT_NAMES:
            cert_bytes += item['bytes']
    require(set(names) == set(ARTIFACT_NAMES), 'receipt exact inventory')
    require(integer(receipt.get('certificate_bytes'), CERT_JOB_MAX) and receipt['certificate_bytes'] == cert_bytes,
            'receipt certificate bytes')
    require(type(receipt.get('certificate_files')) is int and receipt['certificate_files'] == 2,
            'receipt certificate files')


def compare_certificate_claims(report, inventory):
    by_name = {item['name']: item for item in inventory}
    for name, control in report.get('controls', {}).items():
        if type(control) is not dict or type(control.get('preflight')) is not dict:
            continue
        claim = control['preflight'].get('certificate')
        if claim is None:
            continue
        require(type(claim) is dict and claim.get('name') == name + '.cert.jsonl', 'certificate claim path')
        actual = by_name.get(claim['name'])
        require(actual is not None and claim.get('bytes') == actual['bytes'] and
                claim.get('sha256') == actual['sha256'], 'certificate artifact differs from worker claim')


def validate_state(state, freeze, freeze_hash, approval_hash):
    require(type(state) is dict and state.get('version') == VERSION, 'state version')
    require(state.get('freeze_sha256') == freeze_hash, 'state freeze changed')
    require(type(state.get('completed')) is list and len(state['completed']) <= len(JOBS), 'state completed')
    require([r.get('job') for r in state['completed']] == list(JOBS[:len(state['completed'])]), 'state order')
    require(state.get('in_flight') is None and state.get('stopped') is False and state.get('canceled') == [],
            'stage stopped or uncertain')
    require(all(r.get('status') == 'PASS' for r in state['completed']), 'prior non-PASS job')
    require(numeric(state.get('worker_cpu_actual')) and state['worker_cpu_actual'] <= WORKER_TOTAL, 'state CPU')
    require(type(state.get('supervisor_cpu_allocation_charged')) is int and
            state['supervisor_cpu_allocation_charged'] == SUPERVISOR_CHARGE * len(state['completed']),
            'state supervisor charge')
    require(integer(state.get('certificate_bytes'), CERT_STAGE_MAX), 'state certificate bytes')
    require(integer(state.get('certificate_files'), 8), 'state certificate files')
    require({path.name for path in RUNS.iterdir()} == {'state.json', 'IN_FLIGHT.lock'} |
            {r['job'] for r in state['completed']}, 'unexpected stage-root artifact')
    total_cpu = 0.0
    total_bytes = 0
    total_files = 0
    for record in state['completed']:
        jobdir = RUNS / record['job']
        require(jobdir.is_dir() and not jobdir.is_symlink(), 'prior directory changed')
        receipt_path = jobdir / 'resource.json'
        require(receipt_path.is_file() and not receipt_path.is_symlink() and
                sha(receipt_path) == record.get('resource_sha256'), 'prior receipt changed')
        receipt = read_json(receipt_path, REPORT_MAX)
        spec = freeze['jobs'][record['job']]
        validate_receipt(receipt, spec, record['job'], freeze, freeze_hash, approval_hash)
        require(receipt['status'] == 'PASS', 'prior receipt not PASS')
        require({path.name for path in jobdir.iterdir()} == {'resource.json'} | set(ARTIFACT_NAMES),
                'prior inventory has extra/missing files')
        for item in receipt['inventory']:
            path = jobdir / item['name']
            require(path.is_file() and not path.is_symlink(), 'prior file missing/symlink')
            require(path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], 'prior artifact changed')
        report = read_json(jobdir / 'result.json', REPORT_MAX)
        require(validate_report(report, spec, freeze, freeze_hash) == 'PASS', 'prior report not PASS')
        compare_certificate_claims(report, receipt['inventory'])
        total_cpu += receipt['child_cpu_seconds']
        total_bytes += receipt['certificate_bytes']
        total_files += 2
    require(abs(total_cpu - state['worker_cpu_actual']) <= 1e-8, 'state CPU reconciliation')
    require(total_bytes == state['certificate_bytes'] and total_files == state['certificate_files'],
            'state storage reconciliation')


def main():
    require(len(sys.argv) == 2 and sys.argv[1] in JOBS, 'usage: supervisor.py scheduled-job')
    job = sys.argv[1]
    initial_parent = os.getppid()
    death_guard(initial_parent)
    # Parent-only reductions follow fork; the worker inherits its own hard headroom.
    resource.setrlimit(resource.RLIMIT_CPU, (4, WORKER_CPU))
    resource.setrlimit(resource.RLIMIT_AS, (256*MIB, 1024*MIB))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (FILE_MAX, FILE_MAX))
    freeze = read_json(FREEZE, MIB)
    freeze_hash = sha(FREEZE)
    approval = read_json(APPROVAL, MIB)
    approval_hash = sha(APPROVAL)
    require(approval.get('status') == 'APPROVED_FOR_FROZEN_DISCLOSED_TESTS', 'review gate closed')
    require(approval.get('freeze_sha256') == freeze_hash, 'review freeze mismatch')
    require(freeze.get('version') == VERSION, 'freeze version')
    require(type(freeze.get('jobs')) is dict and list(freeze['jobs']) == list(JOBS), 'frozen schedule')
    require(freeze.get('limits') == limits(), 'frozen limits')
    for path, expected_hash in freeze['files'].items():
        candidate = Path(path)
        require(candidate.is_absolute() and candidate.is_file() and not candidate.is_symlink(), 'frozen path')
        require(sha(candidate) == expected_hash, 'frozen source changed: ' + path)
    require(str(Path(__file__).resolve()) in freeze['files'], 'supervisor not frozen')
    spec = freeze['jobs'][job]
    jobdir = RUNS / job
    output = jobdir / 'result.json'
    command = spec['command']
    require(type(command) is list and all(type(x) is str for x in command), 'command shape')
    require(command[-2:] == ['--output', str(output)], 'fixed output binding')
    require(command[0] == str(Path(sys.executable).resolve()), 'interpreter binding')
    require(command[1:3] == ['-I', '-B'], 'isolated no-bytecode invocation')
    require(command[3:-2] == (['-O'] if job.endswith('optimized') else []) + [spec['script']], 'fixed command')
    require(spec['script'] in freeze['files'], 'worker source not frozen')
    RUNS.mkdir(exist_ok=True)
    require(not RUNS.is_symlink(), 'symlink runs directory')
    lockfd = os.open(str(LOCK), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.write(lockfd, (job + '\n').encode())
    os.fsync(lockfd)
    os.close(lockfd)
    fsync_dir(RUNS)
    # All later errors leave a durable lock. Missing evidence is not permission to retry.
    if STATE.exists():
        state = read_json(STATE, REPORT_MAX)
        validate_state(state, freeze, freeze_hash, approval_hash)
    else:
        require(job == JOBS[0], 'first job must be author-normal')
        require({path.name for path in RUNS.iterdir()} == {'IN_FLIGHT.lock'}, 'first run directory not fresh')
        state = dict(version=VERSION, freeze_sha256=freeze_hash, completed=[],
            worker_cpu_actual=0.0, supervisor_cpu_allocation_charged=0,
            certificate_bytes=0, certificate_files=0, in_flight=None, stopped=False, canceled=[])
    require(len(state['completed']) < len(JOBS), 'all scheduled slots consumed')
    require(job == JOBS[len(state['completed'])], 'next scheduled job only')
    require(state['worker_cpu_actual'] + WORKER_CPU <= WORKER_TOTAL, 'worker reserve unavailable')
    require(state['supervisor_cpu_allocation_charged'] + SUPERVISOR_CHARGE <= SUPERVISOR_TOTAL,
            'supervisor reserve unavailable')
    require(state['certificate_bytes'] + CERT_JOB_MAX <= CERT_STAGE_MAX and
            state['certificate_files'] + 2 <= 8, 'certificate reservation unavailable')
    jobdir.mkdir()
    state['in_flight'] = dict(job=job, worker_cpu_reserved=WORKER_CPU,
        supervisor_cpu_reserved=SUPERVISOR_CHARGE, certificate_bytes_reserved=CERT_JOB_MAX,
        certificate_files_reserved=2, command=command, approval_sha256=approval_hash,
        timestamp_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    atomic(STATE, state)
    stdout = os.open(str(jobdir / 'stdout.txt'), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    stderr = os.open(str(jobdir / 'stderr.txt'), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    start = time.monotonic()
    supervisor_pid = os.getpid()
    child = os.fork()
    if child == 0:
        try:
            os.dup2(stdout, 1)
            os.dup2(stderr, 2)
            os.close(stdout)
            os.close(stderr)
            death_guard(supervisor_pid)
            os.setsid()
            signal.signal(signal.SIGXCPU, signal.SIG_DFL)
            signal.signal(signal.SIGALRM, signal.SIG_DFL)
            resource.setrlimit(resource.RLIMIT_CPU, (60, WORKER_CPU))
            resource.setrlimit(resource.RLIMIT_AS, (1024*MIB, 1024*MIB))
            os.chdir(spec['cwd'])
            os.execve(command[0], command, {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'})
        except BaseException as exc:
            os.write(2, ('worker setup failed: ' + repr(exc) + '\n').encode()[:4096])
            os._exit(125)
    os.close(stdout)
    os.close(stderr)
    resource.setrlimit(resource.RLIMIT_CPU, (4, SUPERVISOR_CHARGE))
    resource.setrlimit(resource.RLIMIT_AS, (256*MIB, 256*MIB))
    timed_out = False
    child_unreaped = True

    def timeout(_signum, _frame):
        nonlocal timed_out
        if not child_unreaped:
            return
        timed_out = True
        try:
            os.killpg(child, signal.SIGKILL)
        except ProcessLookupError:
            try:
                os.kill(child, signal.SIGKILL)
            except ProcessLookupError:
                pass

    signal.signal(signal.SIGALRM, timeout)
    remaining = WALL - (time.monotonic() - start)
    if remaining <= 0:
        timeout(signal.SIGALRM, None)
    else:
        signal.setitimer(signal.ITIMER_REAL, remaining)
    while True:
        try:
            os.waitid(os.P_PID, child, os.WEXITED | os.WNOWAIT)
            break
        except InterruptedError:
            continue
    signal.setitimer(signal.ITIMER_REAL, 0)
    child_unreaped = False
    _, wait_status, usage = os.wait4(child, 0)
    wall = time.monotonic() - start
    exit_code = os.waitstatus_to_exitcode(wait_status)
    child_cpu = usage.ru_utime + usage.ru_stime
    failures = []
    if timed_out:
        failures.append('wall_timeout')
    if wall > WALL:
        failures.append('reported_wall_exceeds_allocation')
    if exit_code != 0:
        failures.append('worker_exit_' + str(exit_code))
    if not numeric(child_cpu) or child_cpu > WORKER_CPU:
        failures.append('worker_cpu_allocation_exceeded_or_invalid')
    report = None
    report_status = None
    try:
        report = read_json(output, REPORT_MAX)
        report_status = validate_report(report, spec, freeze, freeze_hash)
    except (OSError, ValueError, TypeError, MemoryError, KeyError) as exc:
        failures.append('worker_report:' + str(exc)[:200])
    if report_status == 'INCOMPLETE_OR_FAILED':
        failures.append('worker_incomplete:' + report['reason'][:200])
    try:
        if sha(FREEZE) != freeze_hash or sha(APPROVAL) != approval_hash:
            failures.append('freeze_or_approval_changed_during_run')
        for path, expected_hash in freeze['files'].items():
            if sha(path) != expected_hash:
                failures.append('frozen_source_changed_during_run:' + path)
    except OSError as exc:
        failures.append('frozen_source_unreadable:' + str(exc)[:200])
    inventory = []
    cert_bytes = 0
    cert_files = 0
    for path in sorted(jobdir.iterdir()):
        if path.name == 'resource.json':
            continue
        if not path.is_file() or path.is_symlink():
            failures.append('unexpected_nonregular_artifact:' + path.name)
            continue
        if path.name not in ARTIFACT_NAMES:
            failures.append('unexpected_artifact:' + path.name)
        size = path.stat().st_size
        if size > (REPORT_MAX if path.name == 'result.json' else FILE_MAX):
            failures.append('artifact_exceeds_file_limit:' + path.name)
        classification = ('certificate_evidence' if path.name in CERT_NAMES else
                          'result' if path.name == 'result.json' else 'diagnostic_nonresult')
        inventory.append(dict(name=path.name, bytes=size, sha256=sha(path), classification=classification))
        if path.name in CERT_NAMES:
            cert_bytes += size
            cert_files += 1
    if cert_bytes > CERT_JOB_MAX or state['certificate_bytes'] + cert_bytes > CERT_STAGE_MAX:
        failures.append('certificate_byte_limit')
    if state['certificate_files'] + cert_files > 8:
        failures.append('certificate_file_limit')
    if report is not None:
        try:
            compare_certificate_claims(report, inventory)
        except (ValueError, TypeError, KeyError) as exc:
            failures.append('certificate_identity:' + str(exc)[:200])
    if not failures and {item['name'] for item in inventory} != set(ARTIFACT_NAMES):
        failures.append('completed_inventory_missing')
    self_usage = resource.getrusage(resource.RUSAGE_SELF)
    self_cpu = self_usage.ru_utime + self_usage.ru_stime
    if not numeric(self_cpu) or self_cpu > SUPERVISOR_CHARGE:
        failures.append('supervisor_sample_exceeds_allocation_or_invalid')
    status = report_status if not failures else 'INCOMPLETE_OR_FAILED'
    if status not in TERMINAL:
        status = 'INCOMPLETE_OR_FAILED'
        failures.append('missing_terminal_report')
    receipt = dict(version=VERSION, job=job, status=status, command=command, cwd=spec['cwd'],
        freeze_sha256=freeze_hash, approval_sha256=approval_hash,
        supervisor_pid=supervisor_pid, child_pid=child, child_reaped=True,
        exit_code=exit_code, wall_timeout=timed_out, wall_seconds=wall,
        child_user_cpu_seconds=usage.ru_utime, child_system_cpu_seconds=usage.ru_stime,
        child_cpu_seconds=child_cpu, supervisor_exclusive_cpu_sample=self_cpu,
        supervisor_cpu_allocation_charged=SUPERVISOR_CHARGE,
        supervisor_final_write_tail_measured=False,
        supervisor_tail_note='Final receipt/state fsync and exit tail not included in self sample; full five-second allocation charged. Preparation/control costs are not measured zero.',
        child_peak_rss_kib=usage.ru_maxrss, supervisor_peak_rss_kib=self_usage.ru_maxrss,
        limits=freeze['limits'], parent_death_guard=True, inventory=inventory,
        certificate_bytes=cert_bytes, certificate_files=cert_files, failures=failures,
        classification='two disclosed full31 controls; no target or fresh holdout')
    if not failures:
        validate_receipt(receipt, spec, job, freeze, freeze_hash, approval_hash)
    receipt_path = jobdir / 'resource.json'
    atomic(receipt_path, receipt)
    state['worker_cpu_actual'] += child_cpu
    state['supervisor_cpu_allocation_charged'] += SUPERVISOR_CHARGE
    state['certificate_bytes'] += cert_bytes
    state['certificate_files'] += cert_files
    state['completed'].append(dict(job=job, status=status, resource_sha256=sha(receipt_path)))
    state['in_flight'] = None
    state['stopped'] = status != 'PASS'
    state['canceled'] = list(JOBS[len(state['completed']):]) if state['stopped'] else []
    state['terminal_reason'] = (report.get('reason') if type(report) is dict else None) if state['stopped'] else None
    atomic(STATE, state)
    if not state['stopped']:
        LOCK.unlink()
        fsync_dir(RUNS)
    print(json.dumps(dict(job=job, status=status, child_cpu_seconds=child_cpu,
        supervisor_exclusive_cpu_sample=self_cpu, supervisor_cpu_allocation_charged=SUPERVISOR_CHARGE,
        canceled=state['canceled'], receipt=str(receipt_path)), sort_keys=True))
    return 0 if status == 'PASS' else 2 if status == 'RESOURCE_GATED_NO_SEMANTIC_RESULT' else 1


if __name__ == '__main__':
    sys.exit(main())
