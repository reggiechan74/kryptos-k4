"""Preparation only: expand the already-fixed public recurrence, never a solver."""
import json
from pathlib import Path
c=[3]
for t in range(1,97):
    c.append(c[t-1] if t%7==0 else (7*t**3+11*t**2+5*t+3)%26)
contexts=[[c[t-j] for j in range(1,7)] for t in range(6,97)]
y=[(3*x[1]+5*int(x[0]==x[1])+7*int(x[2]==x[3]))%26 for x in contexts]
a=[0]*31; a[28]=13
b=[0]*31; b[2]=3; b[28]=5; b[29]=7
obj={'schema':'full31-public-controls-v1','controls':[
 {'id':'A','contexts':[[0]*6],'observed':[],'public_outputs':[],'stream':[], 'original_coefficients':a},
 {'id':'B','contexts':contexts,'observed':[[t-6,y[t-6]] for t in list(range(21,34))+list(range(63,74))], 'public_outputs':y,'stream':c,'original_coefficients':b}]}
p=Path(__file__).with_name('fixtures.json')
with p.open('x') as f: json.dump(obj,f,sort_keys=True,separators=(',',':'),allow_nan=False);f.write('\n')
