# Full31 preflight: independent source and exact-freeze review

**STATIC PASS / PRE-RUN GATE CONFIRMED. No pilot result exists yet.**

This confirmation applies only to FREEZE.json
`eb9da11b8ee9de669294fc94c2dad98642d74bedc4a5e21399b663ba680f61ac`
at `/workspace/shared/residual-full 31-preflight`. All 21 manifest hashes were
checked against the reviewed bytes. No experimental source was imported,
compiled or tested for this review. The implementer's separately authorized
single public fixture-preparation command is disclosed in PREPARATION.md; it is
not a solver/test pass. Its overhead and static review/hash/write overhead are
unmeasured, not claimed zero.

The unchanged proposal is `cdd02be85e643b4226eb4a58bb7eade35f8d28108ea979ba82f87765025c7c0a`;
its design review is `6b250d0aafd979f3c005ee7b23663d3a8d2c2c3546729a4a98c8ca3e0e37765f`.
Existing reference/engine/source/result trees remain immutable.

## Reviewed new source pins

| Source | SHA-256 |
|---|---|
| preflight.py |`aa8f29a0a5b4546139f057e3810fe1c85578b325383e033512f5d8a27c5b5e98`|
| worker.py |`849bfaca3fd2bfd16529dd378e86c448c932fe0188ca30ac44c6b9caddb186d4`|
| independent_checker.py |`f03a8c1f7d947e86532908d50a9acf718689fa29f7568172c71505e46cf05143`|
| review_worker.py |`80caf9bac6c0acfcd157a075547ab6bac54e79c275804143395de01a833f3195`|
| supervisor.py |`879e632f38e705781d1b7fe332ca657a6238d90aba490261560eacd2da32b591`|
| fixtures.json |`1b5f84510a78fab0c71760a0496d160c3af4a0fffd6dd30992bb54ea945e4836`|
| AMENDMENT.md |`4bbef0338b661e1d57a764309ec72c3011aa6212035ad78ab1c616a20a1d603e`|

Other exact contract, preparation, packaging-authority, interpreter and immutable
dependency pins are in the21-file manifest and `frozen-files.sha256` here.

## Proof-to-code review

The generator freshly solves every original size 3 support in lexicographic
order. The immutable reference-v3 certificate generator performs its first
replay. The independently authored serialized checker rebuilds original features,
raw equations and beta constraints without importing generator helpers, then
calls the same previously audited immutable v3 certificate checker for the
second replay. It does not hide a third replay or solve. That checker proves
full augmented RREF, consistency, exact coefficient rank, complete free basis,
original-equation membership and strict recognized claims.

The generation and audit sides independently enumerate every covered beta bit
assignment, including B-excluded assignments and inconsistent mod13 supports.
Every observed row is tested even after a mismatch. Complete eligible beta lists
must agree in the evidence's fixed bit-product order. This order may differ
from the unchanged semantic engine's subset order without changing K or W.

The stateful checker owns its support iterator, zero-based cursor, input digest,
running sum and exact-byte rolling hash. Caller-supplied indices or sums are not
premises. Each contribution is independently recomputed as
chi*K*13^(3−rank), using exact integers. It refuses any support after the first
strict cap crossing. A prefix terminal requires L>cap and exact_W=None; admission
requires all 4,495 supports and W≤cap. A partial last support cannot contribute.
The checker is permanently poisoned after any error, preventing skip/resume
behavior. Missing terminal, extra data, repeated/missing/reordered support,
false binding or cumulative claims cannot produce a completed proof.

Canonical LF-terminated JSON, exact record keys, strict built-in field types,
bounded line sizes and duplicate-key rejection bind serialized claims. The
checker independently validates the entire fixed A/B input semantics, including
the B recurrence, all overlapping newest-first contexts, separate public outputs,
observed rows and original coefficients. This is runtime validation of frozen
literal inputs, not a replacement draw or semantic solving. Input feature rows
are preprocessed once per control; no solved-system cache is introduced.

Control A’s 64,670,892 fixed-traversal visits remain an analytic fact, distinct
from the runtime prefix lower bound. No A producer or semantic verification is
allowed. For B, workload admission is only a necessary point-cap gate. The fixed
producer must still be EXACT, and the unchanged full reference-v3 verifier must
be VERIFIED_EXACT with fiber_points=W. Mutual base inclusion, direct R/cut
comparison, complete original fibers/lifts/joints/masks/witnesses/provenance are
not removed. Count equality alone cannot establish semantic correctness.

## Explicit metering amendment

Static review identified that list generation plus independent recomputation
cannot fit a single 35,264-candidate ceiling for a complete inventory. The paired-counter clarification was approved before execution: each pass has 35,264
candidates and 846,336 parity-row tests, with combined maxima 70,528 and 1,692,672.
Both debit the same unchanged 50,000,000 logical-work meter and 20-second control
wall cap. The original proposal is preserved; AMENDMENT.md is frozen. No GF2
alternate solver, pruning or other cap increase was adopted.

Fresh solves, both certificate replays, generated/replayed row operations,
support/beta/row work, records, serialization and final evidence hashing are
charged. The byte-block units are explicit accounting conventions, not physical
CPU claims. Caps are strictly validated before input, module/path or evidence
access; validation no longer deep-copies malformed values before type checks.

Line/file/shared-worker bytes are predebited before writing. The writer uses
only the two fixed original certificate paths, exclusively created, with no
temporary certificate or extra copy. Each line is flushed/fsynced and its exact
read-back bytes checked independently. Footer and directory durability precede
completed evidence claims. Final file hashing is precharged; exhaustion there
demotes the outer call even if a valid footer was written. Partial bytes and
attempted debits are never used to replenish a budget. Complete evidence alone
cannot override an incomplete outer result.

## Driver, launcher and stop-state audit

Both roles deliberately share the reviewed orchestration and generator. The
independent role supplies independently authored mutation checks and the
mandatory independent serialized checker; it is not represented as a second
semantic-engine implementation. Every real serialized support in every role
receives that independent check, including author-normal before any later slot.

The launcher binds source/interpreter hashes, exact commands/cwds, role, mode,
schema and obligation counts. It reserves 75 worker CPU, 5 supervisor CPU and
64 MiB/two certificate paths before fork, with durable one-use lock/state. It
rehashes and revalidates prior PASS inventories before a successor. Existing
results or uncertain receipts cannot authorize retries. Worker groups, parent-
death guards, independent wall watchdog and WNOWAIT-before-wait4 avoid abandoned
children and reused-PID signal races. No extra launcher trial is authorized.

Completed A and resource-gated B reports can contain only preflight claims;
successful B has an exact frozen five-field claim schema. Partial failure
reports remain diagnostic, never successful evidence. Actual certificate sizes
and hashes must match reports. Runtime limits are two paths/64 MiB per worker,
eight paths/256 MiB for the stage, with partial bytes counted.

Only PASS permits the next worker. An expected B gate produces a retained
RESOURCE_GATED_NO_SEMANTIC_RESULT, worker exit 0 and supervisor exit 2; it cancels
all later slots and retains the lock. Every failure, cap, kill, wrong status,
observed overshoot or uncertain result also blocks successors. There is no
post-stop executable replay or extra analysis using spare allocation. Static
artifact inspection/reporting does not revive a canceled slot.

The supervisor's near-end exclusive sample omits its final write/exit tail;
the full 5 allocation charge remains separate from measured CPU. Worker wait4
usage is OS-reported, not perfect physical metrology. The prior unexplained OS
CPU overshoot remains unresolved. Suite timers are subsets, not extra CPU to sum.

## Frozen finite pre-A/B checks

Author mode: 36 malformed cap rejections, 8 literal serialized-record mutations,
one positive record, and 6 actual storage-reservation boundary checks. Independent
mode: 36 public-entry malformed-cap checks with all other arguments None,
24 header/support/terminal mutations, 6 parser negatives, 6 poisoned-resume
negatives, 2 strict-threshold/inventory negatives, 2 stream lifecycle negatives,
2 positive serialized controls, 6 storage boundaries and 3 storage-type negatives.
All use the disclosed first rank-zero A support or malformed data in memory;
no extra certificate file, solver trial, worker or full 31 control is created.

`planned_full31_controls=2` is expressly a plan count, not a completion claim.
The report separately records attempted controls and actual outcomes. Tests use
explicit checks under normal and -O, never Python assert. Their exact count
dictionaries match all four manifest jobs. They are still unexecuted here.

## Exact gate and limits

All 21 source pins and all four command/mode/count dictionaries match. At final
inspection `runs/` and PRE-RUN-APPROVAL.json were absent and launch-records/ was
empty. Only the authorized public preparation had executed. The fixed four
conditional slots are author-normal, author-optimized, review-normal and
review-optimized, sequentially and once. The implementer owns the first two;
the reviewer owns the latter two only after a clean finalized handoff.

This is a new 320 CPU-second allocation; the previous 680 contingency is untouched.
No further source correction, run, draw, cap increase or allocation reuse is
authorized by this confirmation. Later one-copy local certificate packaging is
separately conditioned on terminal closeout and independent outcome review;
it is not a runtime evidence slot or a replay permission.

This is classical rank/cardinality mathematics in a local certified workload
pilot. No production-readiness, speedup, hidden-validation or novelty claim is
made. The old failed cohort remains permanently INCOMPLETE and sealed; no target,
truth, holdout, v003 replay or remote write belongs to this task.
