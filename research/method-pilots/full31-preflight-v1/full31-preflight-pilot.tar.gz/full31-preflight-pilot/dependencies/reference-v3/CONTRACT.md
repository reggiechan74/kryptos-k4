# Reference v3 implementation contract — pre-run freeze candidate

No code in this directory has been imported, compiled or executed during source
preparation. Implementation is authorized; tests remain prohibited until the
joint independent pre-run freeze confirms source, fixtures, mutations, metering,
caps and supervisor. All predecessor/design files are preserved.

## Public API

Module `reference_v3.py`, VERSION `independent-residual-reference-3`:

- `BudgetV3(max_fiber_points, max_lift_trials, max_solve_calls,
  max_certificate_checks, max_row_operations, max_work_units,
  max_witness_checks, max_output_records, max_seconds)`; all fields required.
- `Meter(budget)` validates all caps first. Public `charge(counter,amount=1)`,
  `work(amount=1)`, `receipt()` and read-only-by-contract `counts` permit exact
  disclosed counter tests. Callers must use a normally constructed Meter;
  mutated/forged internal Meter state is outside the interface.
- `certify_affine(rows,n,*,meter,binding=None)` generates AND nonoptionally replays
  a certificate; `replay_certificate(rows,n,cert,*,meter,binding=None)` independently
  checks it. Both accept only F13, 0<=n<=3, at most256 equations. These helper
  calls can raise ReferenceLimit and never convert exhaustion to an empty space.
- `equivalent_bases(rows_a,rows_b,n,*,meter)` independently certifies both spaces
  and returns exact two-way affine equality. It accepts no cuts; B12 therefore
  exercises this helper before any engine cut-count guard.
- `residual(alpha,beta,*,meter)` and `minimum_support(alpha,beta,*,meter)` validate
  exact 31/25 canonical descriptor dimensions and charge their computations.
- `build_reference_v3(contexts,observed,sparsity=3,allowed_features=None,*,budget)`
  returns EXACT/EMPTY/INCOMPLETE and the complete relation on success.
- `verify_result_v3(contexts,observed,result,sparsity=3,allowed_features=None,*,
  budget,expected_source_sha256,expected=None)` returns VERIFIED_EXACT,
  VERIFIED_EMPTY, VERIFICATION_INCOMPLETE or PRODUCER_INCOMPLETE. Expected engine
  pin is mandatory; optional expected memo is diagnostic comparison ONLY after
  complete independent reconstruction. It cannot bypass any proof or charge.

Every integer cap requires exact built-in int>=0. Wall seconds permit exact
built-in nonnegative ints or finite floats, never bool/NaN/infinity. Huge integer
wall caps are finite integers and do not require lossy float conversion. Budget
validation precedes content inspection and all early/memo paths. Errors are
explicit exceptions, not assertions. Discovered invalidity raises
VerificationError; an earlier resource exhaustion remains incomplete checking.

Contexts are at most128 literal six-symbol Z26 lists/tuples. Observed keys must be
built-in integer row indices (JSON fixture pairs are converted by the suite).
Allowed indices must be sorted unique original coordinates in[0,30], s in[0,3].
No target parser, random generation, remote/network operation or subprocess
facility is present in the reference module.

## Native successful relation schema

`build_reference_v3` returns:

- `version`, `source_sha256`, `request_sha256`, `status`, `resources`, `stats`.
- `masks`: list of sets of allowed Z26 scalar values.
- `pieces`: dictionary `(support_tuple,beta_active_tuple) -> set(alpha_on_T)`.
- `piece_masks`: same keys -> list of Z26 scalar sets.
- `provenance`: list of dictionaries `value -> set(piece_keys)`.
- `lifts`: `(alpha31_tuple,beta25_tuple) -> set(original31_coefficient_tuple)`;
  all original sparse lifts, including nonminimal/cancellation representations.
- `joints`: set of full prediction tuples from common descriptors.

These complete sets are compared in memory, not serialized as an unbounded
report. `verify_result_v3` returns only checked counts, identity, stats and its
cumulative resources on successful verification. The unchanged engine need not
emit joint sets; the reference still reconstructs its entire induced relation.
If a producer adds optional `joints`, it must be a list of at most1,000,000 unique
full prediction lists/tuples, each exactly the context count in canonical Z26
built-in integers. Ordering is irrelevant; duplicate tuples reject. Its complete
set must equal the independently reconstructed joint relation. This branch is
fully metered; the engine is not required to provide it. An INCOMPLETE producer
may omit this optional field or set it to None, never leak a partial joint set.
Recognized reference-side semantic extras `piece_masks` and `lifts`, if supplied
on a producer INCOMPLETE result, must likewise be None; unrelated metadata is
not interpreted as a semantic claim.

INCOMPLETE/VERIFICATION_INCOMPLETE/PRODUCER_INCOMPLETE results contain a reason,
identity/version and diagnostic resources; masks, pieces, piece_masks,
provenance, joints, lifts, witnesses and feasibility_witness are ALL None.
PRODUCER_INCOMPLETE certifies only the no-partial-claim format. It cannot become
verified exact/empty. Budget exhaustion after partial internal accumulation
discards semantic outputs. Malformed or failed-certificate errors are not caught
as resource exhaustion.

## Certificate schema

Required: `version='affine-certificate-3'`, `q=13`, `n`, `binding`,
`equations_sha256`, `operations`, `rref`. Optional recognized claims (all emitted
by the generator): `consistent`, `rank_a`, `rank_aug`, `dimension`, `pivots`,
`free`, `point`, `basis`. Every supplied recognized claim must equal independently
derived data with strict types. Unknown keys are ignored nonclaim metadata and
are never copied to a derived proof. Derived output additionally gives `rank`
as an alias of `rank_a`; that alias is not an emitted certificate claim.

`point` and `basis` are None when inconsistent; `dimension` is also None then.
For consistency, the checker derives every free column, reconstructs point and
complete basis, verifies original equations and free-coordinate identity.

Operations are exact lists/tuples: `['swap',i,j]`, `['scale',i,u]`,
`['add',i,j,u]`. Scale requires nonzero u; add requires i!=j. Permitted no-ops
must not be used as false rejection mutations. Generator scans all augmented
columns left-to-right, picks first available pivot, and emits swap and scale
even when they are no-ops. A12's first swap is deterministically `[swap,0,1]`
and genuinely changes its intermediate matrix.

Transcript length <=(n+1)*(m+1), where m is original equation count. Full row
replay and canonical augmented RREF prove exact rank/consistency. Binding defaults
to generic role,field,n,reference_version; actual residual solves bind request
hash, exact original support, beta, role, field,n,reference version/source hash.
No cache or cross-run memo exists. A binding has at most16 string keys, bounded
strings, canonical small integers or bounded integer lists; bool aliases reject.
The original ordered equations and binding are checked, not merely a hash claim.

## Metering: exact named units

One Meter is shared through each entire public build/verify call. No nested
support/beta/helper resets it. Separate suite invocations/calls have separate
receipts; the suite aggregates them while the supervisor independently charges
inclusive worker CPU. Counter names are cap names without `max_`:

| Counter | Exact charging rule |
| --- | --- |
| fiber_points | One per observation alpha visited for one eligible T/beta; includes rejected R points and repeat visits across pieces/passes. Preflight exact13^d before a fiber. |
| lift_trials | One per original-coordinate parity assignment tried for each retained alpha/beta, including rejected group-XOR assignments. |
| solve_calls | One for each fresh independent `_make_space` elimination, observation or producer base; inconsistent solves count. |
| certificate_checks | One per replay; fresh solves always invoke replay. Explicit suite replays count again. |
| row_operations | Each generated operation plus each replayed operation. Generated/replayed subtotals are also reported. |
| work_units | Deterministic block charges detailed below; not CPU cycles or all Python bytecode operations. |
| witness_checks | Each advertised core alpha witness including feasibility, and each top/per-piece sparse witness checked. Reference lift trials have their separate counter. |
| output_records | Each logical retained record defined below; not bytes, RSS or every temporary Python object. |

Charges/checks occur before protected work. An incomplete receipt reports charged
units, which can include a unit reserved just before another cap interrupts the
associated operation. It does not claim all reserved units completed. Successful
row-operation totals equal generated+replayed subtotals. Direct Meter primitive
tests debit counters without pretending to perform the named algebra operation.

`work_units` schedule is the fixed source's explicit `work(k)` calls:

- Equation validation/copy:1 per system plus n+2 per row; matrix copying and
  hashing by full augmented width; full matrix equality by m*(n+1).
- Binding:1 header,1 per key, string/list length+1; scalar integer fields are
  covered by their key unit. Bounded generic headers/identity comparisons are
  charged at call sites; all arbitrary equation entries are charged.
- Elimination:1 per pivot-search cell and row tested; n+2 per emitted operation,
  covering the complete row update plus operation record. Replay:1 schema unit
  per operation plus n+1 for its complete row update.
- RREF: n+1 per row,1 per pivot-column entry, n+rank_aug+1 metadata,
  n*(d+1) before point/kernel zero-array construction,1 per kernel pivot entry,
  and1 per free-identity entry. Every original-equation
  point/kernel and affine-inclusion dot product costs max(1,vector length).
- Context validation:7 per context; features32; descriptor56; descriptor public
  validation58. Direct R charges56 for common E/B scans and56 for each inspected
  C equality alternative, including conservative short-circuit overcharging.
  Minimum support56. Point reconstruction max(1,n*(d+1)).
- Original support/beta traversal, observation parity, alpha extension, CRT,
  lift construction and scalar/key/schema checks are charged by their explicit
  bounded dimensions at their source call sites. Every vector dot uses
  max(1,width), treating one modular multiply/add component as one unit.
- `_add` charges max(1,declared tuple width) for hash/membership insertion.
  Full diagnostic expected-memo comparison first recursively charges each node
  of the independently reconstructed semantic objects. Memo comparison cannot
  erase reconstruction work.

Output-record schema:

- One per generated operation. Generator certificate header and each RREF row;
  independently derived replay header, RREF rows, point and basis vectors count
  separately. Bounded scalar metadata/claims belong to their header record.
- Reference relation headers (five) and row mask/provenance containers; each
  new piece/row-mask container; each newly inserted alpha, descriptor dictionary
  key, original lift, joint tuple, scalar mask value, provenance value key and
  contributing piece key. Duplicates still incur work but not a new record.
- Each temporary normalized value-map entry, each mask set and producer registry/ID entries
  count as verification storage records. Fixed-size scalar locals and bounded
  scratch matrices are covered by work and static input limits, not records.

This is a declared accounting convention, not a physical-memory proof. Supported
input sizes, record caps, external address-space and wall/CPU settings remain
separate safeguards. `legacy_ambient_points_equivalent` is only the mathematical
sum13^|T| over completed feasible pieces, never a resource debit/cap or measured
speedup. New units are not claimed equivalent to v2's old ambient `max_points`.

## Fixed pre-meter/bootstrap boundary

BudgetV3/Meter type-and-cap checks (constant number of fields), clock start,
module import and hashing of the pinned source file occur outside per-call work
counters. They remain inside supervisor-measured inclusive worker CPU. No
equation solving, fixture pass, input-file parsing or large semantic traversal
is treated as free pre-meter algebra. Incomplete receipt construction is bounded
diagnostic control work. Fixture JSON/report I/O and the independent raw oracle
are suite work accounted by the outer worker envelope, not hidden as reference
certificate work. The suite records raw-oracle vector counts separately.

## Cap allocations and execution gate

Ordinary per-call cap values are fixed in the suite source and in CAPS.json;
deliberate cap overrides have literal test definitions. A generous per-call
allocation is NOT a promise that every case or whole worker will finish.
No cap can be widened after a run starts. Per-call caps do not replenish the
outer stage reservation. Any ordinary incomplete result prevents suite PASS.

The separately owned supervisor must freeze its source, report identities,
inclusive worker/exclusive supervisor accounting, nominal limits, process-tree
watchdog and kill/overshoot policy before tests. Workers use no network or child
processes and emit <=2MiB summary JSON, never full relations. Only a successfully
completed, independently verified pre-run freeze authorizes the four planned
worker slots; this document itself is not that confirmation.
