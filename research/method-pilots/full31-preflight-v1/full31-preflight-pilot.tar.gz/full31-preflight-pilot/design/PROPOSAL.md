# Next recommendation: two disclosed full-31 controls and certified workload preflight

**DESIGN ONLY — no implementation, trace expansion, fixture draw, import, solver
or test has been performed for this proposal.** Current v3 PASS, its sources,
fixtures, receipts and predecessors remain immutable. This is a bounded local
resource/verification pilot, not a new hypothesis, holdout, performance campaign
or target admission. Separate reviewed authorization is required.

## Fixed mathematical controls

Both controls use all original feature indices 0..30, sparsity 3, the unchanged
31/25 canonical dictionary and R = E minus (B union exact156 C). All equality
tests are on unreduced Z26 symbols. No pruning, saturation, support/beta merging,
cache, alternate predicate or solver-engine change is proposed.

**A — deliberately excessive rank-zero traversal.** One public context is
`[0,0,0,0,0,0]`; there are no observations. The proposed point allowance is
1,000,000, so the preflight must return a certified resource-gate rejection.
This must not be labeled EMPTY: for example, 13 E12 is a residual function.

There are C(31,3)=4,495 original support containers. Six canonical groups have
two original members; the other 19 have one. Exactly 6*29=174 containers contain
a duplicate group and have two groups; the other 4,321 have three. Thus

    sum_T 2^|G(T)| = 4,321*8 + 174*4 = 35,264.
    sum_T 2^|G(T) intersect {0,1}|
        = 4,495 + 435 + 841 + 57 = 5,828.
    W_A = (35,264 - 5,828) * 13^3 = 64,670,892.

The latter four terms count all T, T containing constant, T meeting the lag1/
square1 group, and T meeting both. This is the exact observation-point count
of the **fixed reference traversal**, including points later rejected by R;
it is not an intrinsic lower bound for other algorithms.

**B — fixed, realizable contiguous public input stream.** Define 97 symbols,
without RNG or seed, by c_0=3 and, for integer t=1..96,

    c_t = c_(t-1)                         if t mod 7 = 0,
          (7t^3 + 11t^2 + 5t + 3) mod26  otherwise.

For t=6..96 define context L(t)=(c_(t-1),...,c_(t-6)), giving 91 overlapping
contexts. Define public outputs, separately from the input stream, by

    y_t = (3 L2(t) + 5 [L1(t)=L2(t)] + 7 [L3(t)=L4(t)]) mod26.

Observe exactly t in {21,...,33} union {63,...,73}, 24 positions, using row
index t-6. The same formula publicly defines every output: unobserved rows are
not secret or held out. In particular, c_t itself is NOT the observed y_t.
The fixed original support {2,28,29}, coefficients {3,5,7}, is a minimum-size
3 residual witness, with beta groups {2,22,23}; therefore a completed correct
semantic verification must be EXACT, not EMPTY. No uniqueness, rank, workload,
mask-size or runtime prediction is asserted. Do not replace this stream if its
workload is unfavorable. Literal expansion and byte freezing would happen only
after the separate implementation/development authorization.

## Certified preflight theorem and boundary

For each original size-3 support T, reconstruct the raw F13 observation system
A_T alpha=b. Let chi_T indicate consistency and r_T=rank(A_T), certified by full
augmented RREF and replayable invertible row operations. Let K_T count **every**
beta supported on covered groups G(T) whose F2 predictions match all observed
values and whose support is not contained in {0,1}. Then

    W = sum_T chi_T * K_T * 13^(3-r_T).

Ranks, counts, powers and accumulated bounds use exact integers, never floating
estimates. Neither W<=cap nor fiber_points=W alone proves successful verification.

Proof: each consistent observation system has exactly 13^(3-r_T) points;
parity compatibility is independent of alpha, and the fixed traversal visits
that entire affine fiber once for each of its K_T beta assignments. Inconsistent
systems contribute zero. No E/C cut or representation count is subtracted.

A standalone preflight visits original T in fixed lexicographic order, rebuilding
their matrices from the public input, replaying each generated certificate, and
enumerating every covered beta for that T (35,264 candidates in a full scan). A second
replay of serialized certificates checks binding, rank and consistency; exact
beta lists/counts are independently recomputed, never trusted. Keep identity by
original support/input/field, even for equal matrices. No cross-run trusted memo
or semantic-solver cache is introduced. Work and certificates are charged.

After each fully checked support, let L be the sum of the processed terms.
Unprocessed terms are nonnegative, so **stop promptly when L>1,000,000**:
the checked lexicographic prefix proves W>=L>cap without scanning further.
Retain its certificates, exact beta lists, prefix length and lower bound; return
`GATE_REJECTED_LOWER_BOUND`, with `exact_W=None`. Checking the prefix requires
no omitted/repeated/reordered support and complete beta coverage within each
processed support. This is a stopping rule for the resource gate, not pruning
inside a semantic solver. A's analytic full W above remains distinct from this
runtime prefix claim.

Only a full inventory of all 4,495 supports can report exact W or authorize a
within-point-cap attempt. The preflight emits no masks, joints, semantic
EMPTY/EXACT, or claim about producer correctness. W=0 is still only a workload
fact at this API boundary. Specifically, successful `VERIFIED_EXACT` or
`VERIFIED_EMPTY` v3 verification must have fiber_points equal to W; formatted
`PRODUCER_INCOMPLETE` and all incomplete/error returns make no such completed
relation claim, even if they happened to debit W. Malformed producers may be
rejected earlier. A partial
prefix that has not exceeded the cap cannot authorize an attempt. Computation
exhaustion stays PRECHECK_INCOMPLETE, not an exact count or semantic result.

If W exceeds the fixed point allowance, do not launch producer/semantic checking
for that control. Otherwise a bounded attempt is permitted, not promised to
finish: lift/solve/work/storage/time caps remain separate. For B, a successful
producer result must still undergo the unchanged **full independent v3 verifier**,
including mutual base inclusion, pointwise direct-R/cut comparison, complete
piece inventory, all lifts/joints/masks/witnesses/provenance. Preflight cannot
replace any of these checks or certify an unverified producer result.

## Proposed finite caps — not an allocation or launch approval

Per control's preflight, propose these cumulative ceilings. Integer caps require
exact built-in nonnegative int, excluding bool; wall caps require finite built-in
nonnegative numbers. Validate every cap before any prefix, early-return or memo
path. A prefix stop never resets counters or replenishes another bucket.

| Bucket | Ceiling |
|---|---:|
| Original supports / covered-beta candidates |4,495 /35,264|
| Parity row tests (at most24 rows per candidate) |846,336|
| F13 solves / certificate replays |4,495 /8,990|
| Generated plus replayed row operations |1,500,000|
| Explicit logical work / retained records |50,000,000 /2,000,000|
| Fiber points / lift trials / sparse witness checks |0 /0 /0|
| Wall seconds |20|

The operation ceiling covers at most100 operations per 24-row augmented solve,
generation plus two replays: 4,495*100*3=1,348,500. Exact new support/beta/parity
charge sites, serialization schema and byte accounting need their own pre-run
freeze; they are not silently assigned old units.

If admitted, producer caps are explicitly proposed as steps2,000,000;
pieces40,000; core work200,000,000; core solves1,000,000; core terms100,000;
wall30 seconds. Its algorithm and source stay fixed. Full-verifier caps retain
the current ordinary units and values: fiber points1,000,000; lift trials
4,000,000; solves100,000; certificate checks200,000; row operations5,000,000;
work500,000,000; witness checks1,000,000; records5,000,000; wall45 seconds.

Propose at most four one-use worker slots (author and independent review, normal
and -O), each nominal CPU60/75 seconds, wall150 seconds, address space1 GiB;
exclusive supervisors each nominal CPU4/5 seconds and256 MiB. This requests a
separate **320-second** allocation/reservation (300 worker +20 supervisor), not
reuse or replenishment from any previous allocation or the unspent contingency.
Final partition, exact commands, metering, fixtures, mutations, output identity,
watchdogs and independent pre-run approval must be frozen before execution.

Per artifact cap32 MiB, summary cap2 MiB. Propose exactly two fixed certificate
evidence paths per worker (A and B), including unfinished evidence at those same
paths: at most64 MiB per worker and **eight certificate files /256 MiB total**
over the stage. No extra certificate copy or temporary certificate file is
allowed outside that inventory. Complete and partial bytes both count. Stop
before exceeding either per-file or cumulative byte limits; retain the existing
prefix and mark PRECHECK_INCOMPLETE, never delete evidence to reclaim budget.
Exact streaming format, pre-debit byte/file metering, durable completion marker,
partial recognition and all final inventory paths remain pre-run prerequisites.

Freeze this explicit one-use decision table for each scheduled worker, in order
author-normal, author-O, independent-normal, independent-O:

| Observed outcome | Allowed next action |
|---|---|
| A certified above-cap prefix, as expected |Continue to B preflight in this same worker; never run A producer/semantic verification.|
| A unexpected result, certificate/schema error, or computation/storage cap |Retain evidence; stop stage; cancel all remaining worker slots.|
| B full checked inventory and W<=1,000,000 |Attempt bounded producer, then full independent v3 verification.|
| B certified above-cap prefix (or checked full count above cap) |Record RESOURCE_GATED_NO_SEMANTIC_RESULT; no B producer/semantic attempt; stop stage and cancel every remaining worker slot, including independent/-O preflights.|
| B preflight/producer/verifier computation cap, error, kill, or wrong semantic status |Retain evidence; stop stage; cancel every remaining worker slot.|
| B successful VERIFIED_EXACT and all identity/resource checks complete |Finish this worker; only then may the next scheduled slot start.|

Only all four completed successful slots support a full pilot PASS. A deliberate
B workload rejection is a retained resource finding, not an end-to-end B pass or
an EMPTY result. There is no redraw, retry, mode bypass, automatic cap increase
or favorable-case substitution. Executable checks of retained artifacts after
a stop need new explicit authorization, not spare CPU; static file inspection
and reporting do not revive canceled worker slots.

Keep worker-inclusive CPU, supervisor-exclusive samples, full supervisor policy
charges and outstanding reservations separate. Retain wall/CPU/RSS, kills and
partials. Nominal OS limits are not guaranteed measured maxima; any observed
overshoot stops dependent execution. Preparation/control and final-write tails
must remain disclosed, not relabeled as measured zero.

The earlier failed cohort remains permanently INCOMPLETE and is not a fixture.
Matbalez historical scope remains unresolved. No target or holdout is involved.
