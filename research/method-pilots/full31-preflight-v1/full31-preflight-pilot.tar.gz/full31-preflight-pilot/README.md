# Disclosed full-feature preflight pilot — publication package

**Scientific outcome: PASS for the exact two public controls.** Read
`stage/REPORT.md` and `review/REVIEW.public.md` inside the archive for results and
limits. This is neither fresh validation nor K4 admission.

The archive is the sole exported local copy of each of the eight runtime
certificate files. Certificates are streamed directly from their immutable
runtime paths into the archive; no extracted or temporary certificate copies
are created. Verification streams member bytes and checks hashes without running
scientific code. Original files remain unchanged.

## Integrity and privacy

`PACKAGE-PROVENANCE.json` maps every archived scientific artifact to its original
path, exact byte count and SHA-256, and records all sanitized administrative
prose and omitted private documents. Source code, fixtures, certificates, raw
results, receipts, final state and diagnostic logs are unchanged. Generic frozen
runtime paths are intentionally retained where required by scientific identities.
No target, failed-cohort seed/truth/custody, private Page ID/link or coordination
log is included.

**Sanitized launch metadata is not the original byte-identical or relaunch-ready
manifest.** `stage/FREEZE.public.json` and `stage/PRE-RUN-APPROVAL.public.json`
remove only private administrative coordination fields. Their complete original
scientific source-hash maps and original SHA-256 commitments remain recorded.
Raw receipts and reports still reference the original private launch objects,
not the public derivatives. Some administrative files and the installed Python
binary are deliberately omitted; the provenance map explains each omission.
Public review/contract prose has corresponding original/public hash mappings.
These substitutions do not claim to reproduce the original full launch folder.

Do not run or regenerate the pilot during publication. All four one-use slots
are consumed, with no automatic retry, replay, fresh draw or target permission.
The fixed code and durable proofs are provided for inspection; any new execution
requires its own appropriate protocol and resource review.

The private ledger integration handoff is delivered separately, not inside this
public archive. Remote publication requires its own integrity/privacy review;
this local package is not a remote-push receipt.
