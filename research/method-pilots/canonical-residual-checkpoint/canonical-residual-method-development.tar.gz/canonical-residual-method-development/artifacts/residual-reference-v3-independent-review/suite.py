"""Independent disclosed-literal review suite. SOURCE ONLY until shared freeze.

No author-suite imports, random input, historical cohort, external process or
network access. This source and every literal test must be frozen before run.
"""
import argparse
import copy
import ctypes
from decimal import Decimal
from fractions import Fraction
import hashlib
from itertools import product
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
AUTHOR = Path('/ARCHIVE_WORKSPACE/canonical-residual-reference-v3')
ENGINE = Path('/ARCHIVE_WORKSPACE/canonical-residual-dev')
EXECUTION = Path('/ARCHIVE_WORKSPACE/residual-reference-v3-execution')
FREEZE = EXECUTION/'FREEZE.json'
ENGINE_SHA = 'be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67'
DEPENDENCY_SHA = '1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d'
CAPS = dict(max_fiber_points=1000000, max_lift_trials=4000000,
    max_solve_calls=100000, max_certificate_checks=200000,
    max_row_operations=5000000, max_work_units=500000000,
    max_witness_checks=1000000, max_output_records=5000000, max_seconds=45.0)
EXPECTED = dict(affine_cases=16, affine_json_roundtrips=16,
    base_equivalence_cases=13, certificate_mutations=24,
    residual_cases=40, complete_relation_comparisons=42,
    relation_boundary_controls=2, engine_witness_collections=42,
    carry_descriptors=156, alias_pair_vectors=676, alias_pair_descriptors=338,
    symbol_alias_checks=26, producer_mutations=18, malformed_cap_requests=850,
    counter_boundary_slots=32, additional_cap_checks=4,
    wrapper_report_rejections=8, wrapper_receipt_rejections=16,
    wrapper_positive_controls=2, strict_input_rejections=12)
ref = oracle = wrapper = None


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def frozen():
    need(FREEZE.is_file() and not FREEZE.is_symlink() and FREEZE.stat().st_size <= 1024*1024,
         'regular bounded freeze required')
    digest = sha(FREEZE)
    data = json.loads(FREEZE.read_text())
    need(data['version'] == 'reference-v3-stage-v1', 'freeze version')
    need(type(data['files']) is dict and 1 <= len(data['files']) <= 128, 'frozen files')
    actual = {}
    for name, pin in data['files'].items():
        path = Path(name)
        need(path.is_absolute() and path.is_file() and not path.is_symlink(), 'frozen file')
        actual[name] = sha(path)
        need(actual[name] == pin, 'source changed: '+name)
    required = [HERE/'suite.py', HERE/'independent_oracles.py', HERE/'TEST-PLAN.md',
                AUTHOR/'reference_v3.py', AUTHOR/'fixtures.json', AUTHOR/'CAPS.json',
                EXECUTION/'supervisor.py', ENGINE/'residual_decoder.py', ENGINE/'affine_filter.py']
    need(all(str(path) in actual for path in required), 'missing pinned dependency')
    need(actual[str(ENGINE/'residual_decoder.py')] == ENGINE_SHA, 'engine pin')
    need(actual[str(ENGINE/'affine_filter.py')] == DEPENDENCY_SHA, 'generic pin')
    need(sha(FREEZE) == digest, 'freeze changed while reading')
    return digest, actual


def budget(**overrides):
    values = dict(CAPS)
    values.update(overrides)
    return ref.BudgetV3(**values)


def count(report, name, amount=1):
    report['obligations'][name] = report['obligations'].get(name, 0)+amount


def reject(call, kind, label):
    try:
        call()
    except kind as error:
        return str(error)
    raise RuntimeError('accepted negative control: '+label)


def args(case):
    return {key: case[key] for key in ('contexts', 'observed', 'sparsity', 'allowed_features')}


def verify(case, result, **extra):
    return ref.verify_result_v3(**args(case), result=result, budget=budget(),
                               expected_source_sha256=ENGINE_SHA, **extra)


def binding(case):
    return dict(role='independent-literal', fixture=case['id'], support=list(range(case['n'])),
                field=13, n=case['n'], reference_version=ref.VERSION)


def affine_checks(fixtures, report):
    stored = {}
    for case in fixtures['affine_cases']:
        m = ref.Meter(budget())
        cert = ref.certify_affine(case['rows'], case['n'], meter=m, binding=binding(case))
        proof = ref.replay_certificate(case['rows'], case['n'], cert, meter=m, binding=binding(case))
        grid = oracle.literal_affine_set(case['rows'], case['n'])
        if proof['consistent']:
            recovered = {tuple((proof['point'][j]+sum(t*v[j] for t,v in zip(parameters,proof['basis']))) % 13
                               for j in range(case['n']))
                         for parameters in product(range(13), repeat=len(proof['basis']))}
            need(len(recovered) == 13**proof['dimension'], 'complete independent kernel')
        else:
            recovered = set()
        need(grid == recovered, case['id']+' full affine grid')
        for key in ('consistent','rank','rank_aug','dimension'):
            need(proof[key] == case[key], case['id']+' '+key)
        roundtrip = ref.replay_certificate(case['rows'], case['n'], json.loads(json.dumps(cert)),
                                          meter=m, binding=binding(case))
        need(roundtrip == proof, 'certificate JSON roundtrip')
        need(m.counts['row_operations'] == m.generated_row_operations+m.replayed_row_operations,
             'row operation reconciliation')
        report['affine'].append(dict(id=case['id'], points=len(grid), resources=m.receipt()))
        stored[case['id']] = (case, cert)
        count(report,'affine_cases'); count(report,'affine_json_roundtrips')
    for case in fixtures['base_cases']:
        left = oracle.literal_affine_set(case['left'],case['n'])
        right = oracle.literal_affine_set(case['right'],case['n'])
        actual = ref.equivalent_bases(case['left'],case['right'],case['n'],meter=ref.Meter(budget()))
        need(type(actual) is bool and actual == (left == right) == case['equivalent'], 'mutual base equality')
        if case['id'] == 'B12':
            excluded = set().union(*(oracle.literal_affine_set(cut,case['n']) for cut in case['compensating_cuts']))
            need(right-excluded == left and not actual, 'compensated cut cannot rescue broader base')
        count(report,'base_equivalence_cases')
    for mutation in fixtures['certificate_mutations']:
        case, original = stored[mutation['case']]
        cert = copy.deepcopy(original)
        kind = mutation['kind']
        if kind == 'append-operation': cert['operations'].append(mutation['value'])
        elif kind == 'remove-operation':
            need(cert['operations'][mutation['index']] == mutation['expected'], 'non-no-op removal target')
            del cert['operations'][mutation['index']]
        elif kind == 'set-rref': cert['rref'][mutation['row']][mutation['column']] = mutation['value']
        elif kind == 'wrong-equation-identity': cert['equations_sha256'] = '0'*64
        elif kind == 'wrong-support-binding': cert['binding']['support'] = [1]
        elif kind == 'set-field': cert[mutation['key']] = mutation['value']
        elif kind == 'drop-last-kernel-vector': cert['basis'].pop()
        elif kind == 'duplicate-kernel-vector': cert['basis'][1] = list(cert['basis'][0])
        else: raise RuntimeError('unknown frozen certificate mutation')
        reject(lambda: ref.replay_certificate(case['rows'],case['n'],cert,
            meter=ref.Meter(budget()),binding=binding(case)),ref.VerificationError,mutation['id'])
        count(report,'certificate_mutations')
    # Additional strict-type and mandatory-binding mutations, all from A05.
    case, original = stored['A05']
    for index in range(8):
        cert = copy.deepcopy(original)
        if index == 0: cert['binding']['field'] = True
        elif index == 1: cert['binding'] = None
        elif index == 2: del cert['binding']
        elif index == 3: cert['version'] = [ref.CERT_VERSION]
        elif index == 4: cert['rank_a'] = True
        elif index == 5: cert['point'] = [True]
        elif index == 6: cert['n'] = True
        else: cert['equations_sha256'] = [cert['equations_sha256']]
        reject(lambda: ref.replay_certificate(case['rows'],case['n'],cert,
            meter=ref.Meter(budget()),binding=binding(case)),ref.VerificationError,'extra certificate '+str(index))
        count(report,'certificate_mutations')


def witness_collection(case, result, truth):
    if result['status'] == 'EMPTY':
        need(result['feasibility_witness'] is None, 'empty feasibility witness')
        return 0
    pieces = {p['id']:p for p in result['pieces']}
    number = 0
    def one(record,row=None,value=None):
        nonlocal number
        piece = pieces[record['piece']]
        oracle.check_original_witness(record['theta'],case['contexts'],case['observed'],
            piece['support'],piece['beta'],truth,row,value)
        number += 1
    one(result['feasibility_witness'])
    for piece in result['pieces']:
        one(piece['feasibility_witness'])
    for row, mapping in enumerate(result['witnesses']):
        for value, witness in mapping.items(): one(witness,row,int(value))
    return number


def relation_checks(fixtures,engine,report):
    cases = []
    for domain in fixtures['domains']:
        for k,pattern in enumerate(fixtures['patterns']):
            cases.append(dict(id=domain['id']+'-'+pattern['id'],
                contexts=[fixtures['contexts'][i] for i in pattern['context_indices']],
                observed=dict(pattern['observed']),sparsity=domain['sparsity'],
                allowed_features=domain['allowed_features'],expected_status=domain['statuses'][k]))
    need(len(cases) == 40,'fixed core count')
    for case in fixtures['boundary_controls']:
        cases.append(dict(case, observed=dict(case['observed']),expected_status=case['status']))
    retained = {}
    for position,case in enumerate(cases):
        truth = oracle.raw_relation(**args(case))
        reference = ref.build_reference_v3(**args(case),budget=budget())
        need(truth['status'] == reference['status'] == case['expected_status'],case['id']+' status')
        for key in ('pieces','piece_masks','lifts','joints','masks','provenance'):
            need(truth[key] == reference[key],case['id']+' complete '+key)
        result = engine.decode(**args(case))
        need(result['status'] == truth['status'],case['id']+' engine status')
        checked = verify(case,result)
        need(checked['status'] == 'VERIFIED_'+truth['status'],case['id']+' verification')
        witnesses = witness_collection(case,result,truth)
        count(report,'engine_witness_collections')
        count(report,'complete_relation_comparisons')
        count(report,'residual_cases' if position < 40 else 'relation_boundary_controls')
        if position >= 40:
            need(len(truth['joints']) == case['joint_count'],'boundary joint count')
            if case['id'] == 'shared-old-new':
                need(truth['joints'] == {(0,)},'nonempty shared trace')
                for coefficient,eligible in ((1,False),(25,False),(13,True)):
                    vector = [0]*31; vector[28] = coefficient
                    need(oracle.in_residual(*oracle.canonical(vector)) == eligible,'global not trace exclusion')
                    need(sum(x*y for x,y in zip(vector,oracle.feature_values(case['contexts'][0]))) % 26 == 0,
                         'same nonempty old/new trace')
            else:
                need((3,3) in truth['joints'] and (3,5) not in truth['joints'], 'non-Cartesian joint')
                need(3 in truth['masks'][0] and 5 in truth['masks'][1], 'marginals individually feasible')
                need(len(truth['masks'][0])*len(truth['masks'][1]) == 121,'marginal product')
        report['relations'].append(dict(id=case['id'],status=truth['status'],
            pieces=len(truth['pieces']),descriptors=len(truth['lifts']),
            lifts=sum(map(len,truth['lifts'].values())),joints=len(truth['joints']),
            raw_vectors=truth['raw_vectors_visited'],original_witnesses=witnesses,
            build_resources=reference['resources'],verify_resources=checked['resources']))
        if case['id'] in ('D00-P1','D01-P1','D03-P1','D03-P2','D05-P1'):
            retained[case['id']] = (case,reference,result)
    return retained


def descriptor_checks(report):
    carry = set()
    for j in (28,29,30):
        for constant,sign in product(range(26),(1,25)):
            vector = [0]*31; vector[0] = constant; vector[j] = sign
            carry.add(oracle.canonical(vector))
    m = ref.Meter(budget())
    for descriptor in carry:
        need(not oracle.in_residual(*descriptor) and not ref.residual(*descriptor,meter=m),'C exclusion')
    need(len(carry) == 156,'156 global C functions'); count(report,'carry_descriptors',len(carry))
    costs = {}
    for a,b in product(range(26),repeat=2):
        vector = [0]*31; vector[1] = a; vector[7] = b
        descriptor = oracle.canonical(vector)
        cost = int(a != 0)+int(b != 0)
        costs[descriptor] = min(costs.get(descriptor,3),cost)
        count(report,'alias_pair_vectors')
    for descriptor,cost in costs.items():
        need(ref.minimum_support(*descriptor,meter=m) == cost,'alias minimum support')
        count(report,'alias_pair_descriptors')
    for a in range(26):
        need(13*(a*a-a)%26 == 0,'Z26 square/lag alias'); count(report,'symbol_alias_checks')


def producer_checks(retained,report):
    case,reference,original = retained['D01-P1']
    for index in range(14):
        result = copy.deepcopy(original)
        if index == 0: result['pieces'] = []
        elif index == 1: result['pieces'].append(copy.deepcopy(result['pieces'][0]))
        elif index == 2: result['pieces'][0]['beta'] = []
        elif index == 3: result['pieces'][0]['forbidden'] = []
        elif index == 4: result['pieces'][0]['core']['feasibility_witness'] = [1]
        elif index == 5: result['feasibility_witness']['theta'] = [[28,1]]
        elif index == 6: result['feasibility_witness']['theta'] = [[28,2]]
        elif index == 7: result['masks'][0] = []
        elif index == 8: result['provenance'][0] = {}
        elif index == 9: result['source_sha256'] = '0'*64
        elif index == 10: result['joints'] = []
        elif index == 11: result['status'] = 'EMPTY'
        elif index == 12: result['status'] = 'INCOMPLETE'
        else:
            result['joints'] = [list(next(iter(reference['joints'])))]*2
        reject(lambda:verify(case,result),ref.VerificationError,'producer mutation '+str(index))
        count(report,'producer_mutations')
    # Broader raw-observation base, repaired core pin: not merely a hash mutation.
    case,reference,original = retained['D03-P2']
    result = copy.deepcopy(original); piece = result['pieces'][0]
    need(bool(piece['base']),'weakened-base non-no-op target'); piece['base'] = []
    scalars = [[oracle.feature_values(c)[j]%13 for j in piece['support']] for c in case['contexts']]
    piece['core']['instance_sha256'] = hashlib.sha256(json.dumps(['affine-filter-1',13,
        len(piece['support']),piece['base'],piece['forbidden'],scalars],separators=(',',':')).encode()).hexdigest()
    reject(lambda:verify(case,result),ref.VerificationError,'strict base inclusion'); count(report,'producer_mutations')
    # An original representation can be feasible yet nonminimal after alias cancellation.
    case,reference,original = retained['D05-P1']
    result = copy.deepcopy(original)
    piece = next(p for p in result['pieces'] if p['beta'] == [22])
    result['feasibility_witness'] = dict(piece=piece['id'],theta=[[1,13],[7,13],[28,13]])
    reject(lambda:verify(case,result),ref.VerificationError,'nonminimal cancellation lift'); count(report,'producer_mutations')
    case,reference,original = retained['D01-P1']
    memo = copy.deepcopy(reference); memo['joints'] = set()
    reject(lambda:verify(case,original,expected=memo),ref.VerificationError,'memo cannot bypass joints'); count(report,'producer_mutations')
    result = copy.deepcopy(original); result['status'] = 'INCOMPLETE'
    for field in ('masks','pieces','witnesses','provenance','feasibility_witness'): result[field] = None
    result['joints'] = []
    reject(lambda:verify(case,result),ref.VerificationError,'incomplete joint leak'); count(report,'producer_mutations')


def malformed_caps(fixtures,retained,report):
    class IntSubclass(int): pass
    values = [True,False,-1,0.0,1.0,0.5,-0.5,float('nan'),float('inf'),-float('inf'),
              '1',None,[],(),{},object(),Decimal(1),Decimal('NaN'),Fraction(1,1),IntSubclass(1)]
    wall_values = [True,False,float('nan'),float('inf'),-float('inf'),-1,'1',None,[],object()]
    case,memo,result = retained['D01-P1']; empty,empty_memo,empty_result = retained['D00-P1']
    incomplete = copy.deepcopy(result); incomplete['status'] = 'INCOMPLETE'
    for field in ('masks','pieces','witnesses','provenance','feasibility_witness'): incomplete[field] = None
    paths = [lambda cap:ref.build_reference_v3(**args(case),budget=cap),
             lambda cap:ref.verify_result_v3(**args(case),result=result,budget=cap,expected_source_sha256=ENGINE_SHA),
             lambda cap:ref.verify_result_v3(**args(case),result=result,budget=cap,expected_source_sha256=ENGINE_SHA,expected=memo),
             lambda cap:ref.verify_result_v3(**args(empty),result=empty_result,budget=cap,expected_source_sha256=ENGINE_SHA,expected=empty_memo),
             lambda cap:ref.verify_result_v3(**args(case),result=incomplete,budget=cap,expected_source_sha256=ENGINE_SHA)]
    for field in fixtures['integer_cap_fields']+['max_seconds']:
        for value in wall_values if field == 'max_seconds' else values:
            for call in paths:
                cap = budget(); object.__setattr__(cap,field,value)
                reject(lambda:call(cap),ref.VerificationError,'malformed '+field)
                count(report,'malformed_cap_requests')


def no_partial(result,status):
    need(result['status'] == status,'expected incomplete kind')
    for field in ('masks','pieces','piece_masks','provenance','joints','lifts','witnesses','feasibility_witness'):
        need(field in result and result[field] is None,'partial semantic output '+field)


def cap_checks(fixtures,retained,report):
    case,_,result = retained['D03-P2']
    for field in fixtures['integer_cap_fields']:
        name = field[4:]
        got = ref.verify_result_v3(**args(case),result=result,budget=budget(**{field:0}),expected_source_sha256=ENGINE_SHA)
        no_partial(got,'VERIFICATION_INCOMPLETE'); need(got['resources'][name] == 0,'zero cap debit')
        count(report,'counter_boundary_slots')
        m = ref.Meter(budget(**{field:2})); m.charge(name,2); need(m.counts[name] == 2,'exact cap')
        count(report,'counter_boundary_slots')
        m = ref.Meter(budget(**{field:1}))
        reject(lambda:m.charge(name,2),ref.ReferenceLimit,'one below cap'); need(m.counts[name] == 0,'predebit failure')
        count(report,'counter_boundary_slots')
        m.charge(name,1); reject(lambda:m.charge(name,1),ref.ReferenceLimit,'same meter cumulative')
        need(m.counts[name] == 1,'cumulative rollback'); count(report,'counter_boundary_slots')
    second,_,second_result = retained['D03-P1']
    got = ref.verify_result_v3(**args(second),result=second_result,budget=budget(max_fiber_points=169),expected_source_sha256=ENGINE_SHA)
    no_partial(got,'VERIFICATION_INCOMPLETE'); need(got['resources']['fiber_points'] == 169,'cross-beta cumulative cap')
    count(report,'additional_cap_checks')
    got = ref.build_reference_v3(**args(case),budget=budget(max_seconds=0))
    no_partial(got,'INCOMPLETE'); count(report,'additional_cap_checks')
    empty,_,empty_result = retained['D00-P1']
    got = ref.verify_result_v3(**args(empty),result=empty_result,budget=budget(max_seconds=10**1000),expected_source_sha256=ENGINE_SHA)
    need(got['status'] == 'VERIFIED_EMPTY','huge finite integer wall cap'); count(report,'additional_cap_checks')
    incomplete = copy.deepcopy(result); incomplete['status'] = 'INCOMPLETE'
    for field in ('masks','pieces','witnesses','provenance','feasibility_witness'): incomplete[field] = None
    got = verify(case,incomplete); no_partial(got,'PRODUCER_INCOMPLETE'); count(report,'additional_cap_checks')


def strict_inputs(report):
    good = dict(contexts=[[2,2,5,6,9,10]],observed={},sparsity=1,allowed_features=[28])
    mutations = [('contexts',[[True,2,5,6,9,10]]),('contexts',[[26,2,5,6,9,10]]),
        ('contexts',[[2,2,5,6,9]]),('observed',{'0':0}),('observed',{True:0}),
        ('observed',{0:True}),('sparsity',True),('sparsity',4),
        ('allowed_features',[28,28]),('allowed_features',[29,28]),
        ('allowed_features',[True]),('allowed_features',[31])]
    for field,value in mutations:
        changed = dict(good); changed[field] = value
        reject(lambda:ref.build_reference_v3(**changed,budget=budget()),ref.VerificationError,'strict input '+field)
        count(report,'strict_input_rejections')


def wrapper_checks(report):
    # Pure metadata mocks only: no main(), files, fork, child, or timer calls.
    pin,approval = 'a'*64,'b'*64
    freeze = dict(files={'/fixed/source.py':'c'*64},limits={'fixed':1})
    spec = dict(command=['/fixed/python','-I','-B','/fixed/suite.py','--output','/fixed/result.json'],cwd='/fixed',
        report_identity=dict(schema='mock-v1',suite_role='independent-review',python_optimized=False,obligations={'literal':1}))
    valid_report = dict(status='PASS',stage_freeze_sha256=pin,source_sha256=freeze['files'],**spec['report_identity'])
    wrapper.validate_report(valid_report,spec,freeze,pin); count(report,'wrapper_positive_controls')
    changes = [('status','FAIL'),('stage_freeze_sha256','0'*64),('source_sha256',{}),
        ('python_optimized',0),('schema','other'),('suite_role','author'),
        ('obligations',{'literal':0}),('obligations',{'literal':True})]
    for field,value in changes:
        mutated = copy.deepcopy(valid_report); mutated[field] = value
        reject(lambda:wrapper.validate_report(mutated,spec,freeze,pin),ValueError,'report '+field)
        count(report,'wrapper_report_rejections')
    receipt = dict(version='reference-v3-stage-v1',job='review-normal',status='PASS',
        command=spec['command'],cwd=spec['cwd'],freeze_sha256=pin,approval_sha256=approval,
        limits=freeze['limits'],exit_code=0,wall_timeout=False,child_reaped=True,parent_death_guard=True,
        failures=[],classification='post-failure disclosed development only',wall_seconds=1,
        child_user_cpu_seconds=0.75,child_system_cpu_seconds=0.25,child_cpu_seconds=1,
        supervisor_exclusive_cpu_sample=0.05,supervisor_cpu_allocation_charged=5,
        supervisor_final_write_tail_measured=False,supervisor_pid=100,child_pid=101,
        child_peak_rss_kib=100,supervisor_peak_rss_kib=100,
        inventory=[dict(name=name,bytes=1,sha256='d'*64,
                        classification='result' if name == 'result.json' else 'diagnostic_nonresult')
                   for name in ('stdout.txt','stderr.txt','result.json')])
    def check(value): wrapper.validate_receipt(value,spec,'review-normal',freeze,pin,approval)
    check(receipt); count(report,'wrapper_positive_controls')
    changes = [('job','author-normal'),('command',[]),('cwd','/elsewhere'),('freeze_sha256','0'*64),
        ('approval_sha256','0'*64),('exit_code',False),('wall_timeout',True),('child_reaped',False),
        ('child_cpu_seconds',float('nan')),('child_cpu_seconds',76),('child_system_cpu_seconds',0.5),
        ('supervisor_exclusive_cpu_sample',5.1),('supervisor_cpu_allocation_charged',True),
        ('supervisor_final_write_tail_measured',True),('wall_seconds',151),
        ('inventory',[dict(name='result.json.tmp',bytes=1,sha256='d'*64,classification='diagnostic_nonresult')]*3)]
    for field,value in changes:
        mutated = copy.deepcopy(receipt); mutated[field] = value
        reject(lambda:check(mutated),ValueError,'receipt '+field)
        count(report,'wrapper_receipt_rejections')


def publish(path,report):
    need(path.is_absolute() and path.parent.is_dir() and not path.exists(),'new output only')
    data = (json.dumps(report,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    need(len(data) <= 2*1024*1024,'summary output cap')
    temporary = path.with_name(path.name+'.tmp')
    with temporary.open('xb') as handle:
        handle.write(data); handle.flush(); os.fsync(handle.fileno())
    os.link(temporary,path); temporary.unlink()
    fd = os.open(str(path.parent),os.O_RDONLY|os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)


def main():
    global ref,oracle,wrapper
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',required=True)
    options = parser.parse_args(); start = time.process_time()
    report = dict(schema='reference-v3-suite-report-v1',suite_role='independent-review',
        python_optimized=bool(sys.flags.optimize),status='FAIL',stage_freeze_sha256=None,
        source_sha256={},obligations={},affine=[],relations=[],
        classification='post-failure disclosed development only')
    code = 1
    try:
        need(sys.flags.isolated and sys.dont_write_bytecode,'isolated no-bytecode invocation')
        need(resource.getrlimit(resource.RLIMIT_CPU) == (60,75),'frozen CPU limits')
        need(resource.getrlimit(resource.RLIMIT_AS) == (1024**3,1024**3),'frozen AS limits')
        delivery = ctypes.c_int()
        need(ctypes.CDLL(None).prctl(2,ctypes.byref(delivery),0,0,0) == 0
             and delivery.value == signal.SIGKILL,'worker parent-death guard')
        digest,inventory = frozen(); report.update(stage_freeze_sha256=digest,source_sha256=inventory)
        for path in (HERE,AUTHOR,ENGINE,EXECUTION): sys.path.insert(0,str(path))
        import independent_oracles as oracle
        import reference_v3 as ref
        import residual_decoder as engine
        import supervisor as wrapper
        need(Path(ref.__file__).resolve() == AUTHOR/'reference_v3.py','reference import pin')
        need(Path(engine.__file__).resolve() == ENGINE/'residual_decoder.py','engine import pin')
        need(Path(oracle.__file__).resolve() == HERE/'independent_oracles.py','oracle import pin')
        need(Path(wrapper.__file__).resolve() == EXECUTION/'supervisor.py','supervisor import pin')
        fixtures = json.loads((AUTHOR/'fixtures.json').read_text())
        need(fixtures['seed'] is None,'no seed'); need(json.loads((AUTHOR/'CAPS.json').read_text())['ordinary'] == CAPS,'caps freeze')
        affine_checks(fixtures,report)
        retained = relation_checks(fixtures,engine,report)
        descriptor_checks(report); producer_checks(retained,report)
        malformed_caps(fixtures,retained,report); cap_checks(fixtures,retained,report)
        strict_inputs(report); wrapper_checks(report)
        need(report['obligations'] == EXPECTED,'complete fixed independent obligations')
        need(frozen() == (digest,inventory),'post-run frozen source check')
        report['status'] = 'PASS'; code = 0
    except Exception as error:
        report['error'] = dict(type=type(error).__name__,message=str(error)[:2000])
        traceback.print_exc()
    usage = resource.getrusage(resource.RUSAGE_SELF)
    report['diagnostics'] = dict(script_cpu_seconds=time.process_time()-start,
        process_user_cpu_seconds=usage.ru_utime,process_system_cpu_seconds=usage.ru_stime,
        peak_rss_kib=usage.ru_maxrss,accounting='diagnostic only; do not add to inclusive supervisor receipt')
    publish(Path(options.output),report)
    print(json.dumps(dict(status=report['status'],obligations=report['obligations']),sort_keys=True))
    return code


if __name__ == '__main__':
    sys.exit(main())
