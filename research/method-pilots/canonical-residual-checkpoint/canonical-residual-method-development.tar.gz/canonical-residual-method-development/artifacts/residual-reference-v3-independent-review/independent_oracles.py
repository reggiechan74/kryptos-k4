"""Disclosed tiny-fixture oracles only. No implementation-under-test imports.

This file is source-only until the shared pre-test freeze is confirmed.
It is deliberately an original Z26 enumeration, not a field solver or cut compiler.
"""
from itertools import combinations, product


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def feature_values(context):
    need(len(context) == 6, 'six symbols')
    values = [1] + list(context)
    values += [(x * x) % 26 for x in context]
    values += [(context[i] * context[j]) % 26
               for i in range(6) for j in range(i + 1, 6)]
    values += [int(context[i] == context[i + 1]) for i in (0, 2, 4)]
    need(len(values) == 31, 'original dictionary width')
    return tuple(values)


def group_index(feature):
    return feature if feature < 7 else feature - 6


def canonical(vector):
    alpha = tuple(coefficient % 13 for coefficient in vector)
    beta = [0] * 25
    for feature, coefficient in enumerate(vector):
        beta[group_index(feature)] ^= coefficient % 2
    return alpha, tuple(beta)


def in_residual(alpha, beta):
    equality = (28, 29, 30)
    if all(alpha[j] == 0 and beta[group_index(j)] == 0 for j in equality):
        return False
    if all(beta[g] == 0 for g in range(2, 25)):
        return False
    # Test all actual signed-equality descriptors, including every constant.
    # The constant coordinates need not be inspected: any constant is in C.
    for j in equality:
        if alpha[j] not in (1, 12) or beta[group_index(j)] != 1:
            continue
        other_alpha_zero = all(alpha[k] == 0 for k in range(31) if k not in (0, j))
        other_beta_zero = all(beta[g] == 0 for g in range(25) if g not in (0, group_index(j)))
        if other_alpha_zero and other_beta_zero:
            return False
    return True


def literal_affine_set(rows, n):
    """Ambient grid for a disclosed matrix, without elimination/certificates."""
    need(type(n) is int and 0 <= n <= 3, 'tiny affine width')
    return {point for point in product(range(13), repeat=n)
            if all(sum(a * x for a, x in zip(row[:-1], point)) % 13 == row[-1]
                   for row in rows)}


def raw_relation(contexts, observed, sparsity, allowed_features):
    """Every original coefficient vector in the disclosed <=3-feature domain.

    Feasibility is checked directly in Z26. Support/beta pieces are constructed
    by embedding actual nonzero supports into every allowed maximal container.
    No reference/engine grouping, predicate, solver, certificate or cut API is used.
    """
    allowed = tuple(allowed_features)
    need(len(allowed) <= 3 and 0 <= sparsity <= 3, 'tiny disclosed raw domain')
    observations = {int(i): value for i, value in observed.items()}
    rows = tuple(feature_values(context) for context in contexts)
    containers = tuple(combinations(allowed, min(sparsity, len(allowed))))
    masks = [set() for _ in rows]
    provenance = [{} for _ in rows]
    pieces, piece_masks, lifts, minimum_cost = {}, {}, {}, {}
    joints = set()
    visited = 0
    for coefficients in product(range(26), repeat=len(allowed)):
        visited += 1
        active = frozenset(j for j, value in zip(allowed, coefficients) if value)
        if len(active) > sparsity:
            continue
        theta = [0] * 31
        for j, value in zip(allowed, coefficients):
            theta[j] = value
        prediction = tuple(sum(value * row[j] for j, value in zip(allowed, coefficients)) % 26
                           for row in rows)
        if any(prediction[i] != value for i, value in observations.items()):
            continue
        alpha, beta = canonical(theta)
        if not in_residual(alpha, beta):
            continue
        descriptor = (alpha, beta)
        vector = tuple(theta)
        lifts.setdefault(descriptor, set()).add(vector)
        minimum_cost[descriptor] = min(minimum_cost.get(descriptor, 32), len(active))
        joints.add(prediction)
        active_beta = tuple(g for g, bit in enumerate(beta) if bit)
        for support in containers:
            if not active <= set(support):
                continue
            key = (support, active_beta)
            pieces.setdefault(key, set()).add(tuple(alpha[j] for j in support))
            local = piece_masks.setdefault(key, [set() for _ in rows])
            for i, value in enumerate(prediction):
                local[i].add(value)
                masks[i].add(value)
                provenance[i].setdefault(value, set()).add(key)
    return dict(status='EXACT' if pieces else 'EMPTY', pieces=pieces,
                piece_masks=piece_masks, lifts=lifts, minimum_cost=minimum_cost,
                joints=joints, masks=masks, provenance=provenance,
                raw_vectors_visited=visited)


def check_original_witness(witness, contexts, observed, support, beta_active,
                           expected, row_index=None, value=None):
    """Direct nonzero original-coordinate witness check, independent of v3."""
    need(type(witness) in (list, tuple), 'witness sequence')
    theta = [0] * 31
    indices = []
    for entry in witness:
        need(type(entry) in (list, tuple) and len(entry) == 2, 'witness entry')
        j, coefficient = entry
        need(type(j) is int and j in support and j not in indices, 'witness index')
        need(type(coefficient) is int and 1 <= coefficient < 26, 'nonzero canonical coefficient')
        indices.append(j)
        theta[j] = coefficient
    need(indices == sorted(indices), 'witness ordering')
    descriptor = canonical(theta)
    alpha, beta = descriptor
    key = (tuple(support), tuple(beta_active))
    need(descriptor in expected['lifts'], 'witness descriptor absent')
    need(tuple(theta) in expected['lifts'][descriptor], 'witness original vector absent')
    need(len(indices) == expected['minimum_cost'][descriptor], 'nonminimal selected witness')
    need(tuple(g for g, bit in enumerate(beta) if bit) == tuple(beta_active), 'wrong witness beta')
    need(tuple(alpha[j] for j in support) in expected['pieces'][key], 'wrong witness piece')
    predictions = tuple(sum(a * b for a, b in zip(theta, feature_values(context))) % 26
                        for context in contexts)
    need(all(predictions[int(i)] == y for i, y in observed.items()), 'observation mismatch')
    if row_index is not None:
        need(predictions[row_index] == value, 'scalar witness mismatch')
    return descriptor
