# Reference v3 — final independent implementation and disclosed-test review

## Verdict

**PASS within the frozen generic development scope.** The full static proof/code
audit and both independently authored normal/optimized suites pass. The author's
two separately implemented suites also pass. All four one-use slots completed
without retries, signals, observed overshoots, or source changes.

This is not a new holdout result, production-readiness certification, performance
claim, historical novelty finding, or K4 admission. The failed earlier cohort
remains permanently INCOMPLETE, its truth unreleased, and replay canceled.

## Exact reviewed identity

- Reference module SHA-256:
  `0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9`.
- Four-slot FREEZE.json:
  `96460c513aa07c554beebd037fecd106f10c7295637de6228004dcb5dd662316`.
- Independent pre-run approval:
  `f03a4991ddade54c7fa6e1c065599c591199870588a8f8c4429eaec54f7c45ef`.
- Full static review, `STATIC-REVIEW.md`:
  `4b1674b5ad8526dbc1faa34af803031a42836f00d773d83cebba44d8c20fafea`.
- Exact pre-run review, `PRE-RUN-REVIEW.md`:
  `a1ae87a367a6bb355d80f3a64bfd1339681cf938186d7a1b5420efe1a3df6a7b`.
- Final four-PASS state:
  `91667f12bd50caef8bcdf2915267d0075199c0eb0b3a62da0539d6bd24af5473`.
- Single deduplicated stage ledger, execution/RESOURCE-ACCOUNTING.json:
  `270021286a1d7b123a1a3ddca4374f5e8dec6372371d928b6c4fb6a66d1eb70d`.

The execution root is `/ARCHIVE_WORKSPACE/residual-reference-v3-execution`;
the reference root is `/ARCHIVE_WORKSPACE/canonical-residual-reference-v3`.
The manifest binds 14 exact files, including both suites, fixtures, meter/schema/
cap plans, supervisor, fixed engine/dependency and resolved interpreter binary.
All 14 hashes were independently checked again after execution. All 16 finalized
receipt/result/worker-log artifacts match the state's receipt pins and each
receipt's exact byte counts and hashes. These checks are retained in
`final-frozen-file-checks.txt` and `final-artifact-checks.txt`.

## General correctness argument

The detailed source audit is in STATIC-REVIEW.md. Its key conclusions are:

1. Every fresh observation or producer-base solve invokes a complete, strict
   reversible row-operation replay. Augmented RREF establishes consistency and
   exact rank. All free columns, particular point and complete nullspace basis
   are reconstructed and checked against original equations and free-coordinate
   identity. This is a completeness proof, not merely witness validation.
2. Observation and producer bases must satisfy both affine inclusions before
   restricted enumeration. Thus cuts cannot hide extra producer-base points.
3. The reference independently traverses every original maximal support and
   covered beta, including absent/empty producer fibers. Every raw observation
   alpha point is compared against direct global R and producer cut membership.
   Final exact registry equality detects extra/ineligible/empty pieces.
4. Equality indicators use full Z26 input before reduction. R is the canonical
   E minus B union exact 156-C predicate, not a raw-support or finite-trace test.
   All original parity assignments satisfying group XOR are retained as sparse
   lifts, including cancellation representations. Full joint predictions are
   not replaced by Cartesian products of marginal masks.
5. Complete scalar masks, original witnesses, minimum selected support, referenced
   pieces and cross-piece provenance are verified. Optional advertised joints
   receive full-set comparison. Diagnostic expected memos never bypass proof or
   charging. Arbitrary undeclared metadata is not certified.
6. One cumulative meter spans a whole call. Named logical work/record/fiber/lift/
   solve/replay/witness units are strictly validated and precharged. Resource
   exhaustion yields no partial semantic output; discovered invalidity raises
   explicit errors. An earlier exhaustion is not evidence about unseen content.
   The same checks remain active under -O.

These use classical affine algebra, CRT and finite enumeration. The reviewed
local result is the correctness of this particular implementation and contract,
not a new general mathematical theorem or established cryptanalytic breakthrough.

## Independent executable evidence

The independent oracle enumerates every original Z26 coefficient assignment on
the fixed at-most-three-feature domains, then applies actual sparse support,
direct observations and an independently expressed canonical predicate. The
author instead enumerates exact nonzero supports. Neither oracle imports the
producer's algebra or the other's oracle. Affine truth is an independent ambient
grid. Shared disclosed fixtures mean independent code, not independent data.

Each independent mode completed:

| Obligation | Count |
|---|---:|
| Affine systems and JSON certificate roundtrips |16 each|
| Two-way affine base comparisons |13|
| Certificate mutations rejected |24|
| Core residual cases plus boundary controls |40+2|
| Complete relation and original-witness collection checks |42 each|
| Global C descriptors excluded |156|
| Original alias-pair vectors / canonical descriptor minima |676 /338|
| Symbol alias identities |26|
| Producer or expected-memo mutations rejected |18|
| Malformed cap requests rejected |850|
| Counter boundaries plus additional literal cap checks |32+4|
| Strict public-input negatives rejected |12|
| Pure report/receipt negatives rejected; positive controls |8+16;2|

The complete relation comparisons include all alpha points, original-support/
beta fibers, original lifts, full joints, scalar masks and provenance—not just
counts. Mutations cover incomplete kernels, wrong RREF/ranks/bindings, broader
producer bases with repaired identity, missing cuts/pieces, nonminimum canceling
lifts, false joints, false EMPTY, leaked partial claims and false expected memos.
The cap tests include actual later-beta exhaustion after 169 visits, wall 0, huge
finite integer wall cap, and empty/incomplete/memo public paths. Wrapper checks
were pure metadata functions inside the two allocated review workers; no extra
launcher trial or child process was created.

Case-summed diagnostics per independent mode (not globally distinct laws):

- 224,592 raw original coefficient vectors examined;
- 69 feasible piece instances, 46,314 canonical descriptor instances;
- 55,124 original lifts and 23,791 joint prediction instances;
- 1,747 advertised original sparse witnesses independently checked;
- 46,605 observation-fiber points in primary build comparisons and 46,605 in
  primary verification comparisons. Additional negative/cap calls are separate.

Normal and -O reports are byte-identical after removing only interpreter mode,
diagnostic timers and nested wall times. Their complete non-time artifact hash
is `98ae3b3e72b660e039ba5e7cfa04c2599791bbdd2c3351b04bb234f2622be978`.
All 42 per-case status/piece/descriptor/lift/joint count summaries match the
author's reports; common hash
`85dadb8bc46a8c1f45df160bceb8e6d9a9042a3ea2d7d7335e316cd358e4cfa1`.
These summary comparisons supplement, not replace, the complete in-worker
relation comparisons. No run was used to tune caps or change fixtures/source.

## Receipts and accounting

| Job | Reported worker CPU s | Supervisor sample s | Supervisor allocation charge s |
|---|---:|---:|---:|
| author-normal |8.761273|0.149550|5|
| author-optimized |9.407479|0.114985|5|
| review-normal |9.753088|0.118039|5|
| review-optimized |9.473537|0.120959|5|
| Stage total |37.395377|0.503533|20|

The independent pair is a subset: 19.226625 worker CPU, 0.238998 supervisor sample,
and 10 allocation charge. **Do not add it again to the stage ledger.** The
known reported components total 37.898910 seconds excluding unmeasured tails and
control work. The policy charge is 37.395377 + 20 = 57.395377, not measured CPU; do not
add supervisor samples again to that allocation-charge figure. An earlier brief
status rounded the supervisor sum incorrectly to 0.503534; the receipt-derived
ledger value 0.503533 here is authoritative.

Deduplication uses four job/command/receipt identities, not numeric PIDs: local
PID 2/5 repeat across separate launch namespaces. Suite-internal timers are
diagnostic subsets, not extra usage. The stage's 320 planned allocation and root's
1000 planning ceiling are not measured use or permission to spend contingency.
All slots are consumed, with no outstanding reserves, no repeat attempts and
no additional authorized slots. Historical allocations remain unchanged.

All workers exited 0, were wait4-reaped, and stayed below observed allocation
checks; highest reported worker RSS was 84,412 KiB. The final lock is absent and
state.in_flight is null. The tool sessions completed; a visible-namespace process
listing found no continuing review worker. This is not a global process census.
OS measurements are not perfect physical metrology; supervisor final write/exit
tails and preparation, hash/read/write, orchestration and closeout control costs
remain unmeasured. The earlier RLIMIT overshoot cause remains unresolved.

Independent receipt pins:

- review-normal resource:
  `f60b28463388642c7bb283e969d98e97c9627630fbfaaebe55586d088cd39ead`;
  result `701ad91f80ca5beff0b7cea1e597797c7a82cd781ce15a2b4e227f22d20a15c3`.
- review-optimized resource:
  `760eade2bc0b9145053dbb81d2375c58d839483e11c32e26c0b5fb4bf8f4eff4`;
  result `c3a0377ffc4b9fcf704db7a37a9fedb4b797eb7ec857ecb8d689d9f052f0ab97`.

## Integration prerequisites and scope boundary

Any future use requires a separately authorized protocol with exact supported
input/schema/cap/source/provenance bindings and honest changed work units. Do not
interpret v3's fiber cap as v2's ambient max_points, compare timings as speedup,
introduce unreviewed caches, or skip original support/beta inventories. A changed
module, certificate format, optional claim, metering rule or launcher requires
fresh review. Finite tests do not remove bounded input, memory, OS or malformed
object assumptions in the contract; this is not arbitrary-input production
certification. Incomplete states must remain distinct from empty/verified.

No denied, pending-uncertain or unaccounted test invocation occurred. No seed,
truth, old holdout, v003 replay, producer edit, remote write or target was used.
Matbalez historical scope remains unresolved. There is no K4 admission and no
authorization for another run, draw, replay or automatic 680-second contingency.
