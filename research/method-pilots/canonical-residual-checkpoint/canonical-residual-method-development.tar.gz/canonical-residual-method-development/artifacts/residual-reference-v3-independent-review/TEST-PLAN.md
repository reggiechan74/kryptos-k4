# Independent v3 disclosed-development suite — source-only freeze candidate

The suite and oracle are independently authored. No source here has been
imported, compiled, or executed during preparation. Only the two scheduled
review-normal/review-optimized workers may run after the joint freeze gate.
No subprocess, random source, network, old cohort, v003, seed, or truth is used.
The earlier validation remains permanently INCOMPLETE.

## Fixed scope and oracle

`independent_oracles.py` enumerates all 26^k original coefficient assignments on
each disclosed at-most-three-feature domain, then filters actual sparse support,
direct Z26 observations, and an independently expressed global R predicate.
This differs from the author's exact-nonzero-support enumeration. It embeds every
actual support into all maximal original containers, and compares every alpha,
beta, original lift, full joint prediction, mask, and piece provenance, not only
counts or witnesses. Affine truth uses direct ambient F13 grids, not elimination.
Every advertised original sparse witness is independently checked against the
full raw relation and its independently enumerated minimum representation cost.

The literal fixture file is shared and frozen, not hidden or independent data.
The independent implementation/oracle and code review are the independence
claims. Successful finite tests would not prove arbitrary-input correctness or
holdout performance. The source audit supplies the general proof argument.

## Exact obligations per mode

The `EXPECTED` dictionary in `suite.py` is normative and must match the frozen
job report identity:

- 16 affine systems, 16 JSON certificate roundtrips, 13 two-way base comparisons.
- 24 certificate mutations: the 16 literal mutations plus eight mandatory-binding,
  strict-type, rank/point/version/equation-hash mutations on A05.
- 40 core residual cases and two relation boundary controls; 42 complete relation
  comparisons and 42 complete advertised-original-witness collection checks.
- 156 global C descriptors; 676 original alias-pair vectors, 338 resulting
  descriptors with independently minimized support; 26 symbol alias identities.
- 18 producer/memo mutations, specified byte-for-byte by the source: missing and
  duplicate piece, beta, omitted cut, false alpha witness, C and B sparse witnesses,
  missing mask/provenance, wrong pin, false/duplicate joints, false EMPTY,
  INCOMPLETE partial claims, broader base with repaired core hash, nonminimum
  canceling lift, false expected joint memo, and explicit incomplete joint leak.
- 850 malformed cap requests: 20 bad values × eight integer caps × five public
  paths, plus ten bad wall values × five paths. A normally created local Budget
  is deliberately changed so API revalidation, not constructor behavior, is tested.
- 32 counter slots: for each counter, a functional zero-cap call, primitive exact
  debit 2, refused debit 2 against cap1, and two successive unit debits against cap1.
- Four extra cap checks: actual D03-P1 later-beta exhaustion at169 cumulative
  fiber visits with all semantic outputs discarded; wall cap0; finite integer
  wall cap10^1000; and valid no-partial producer-INCOMPLETE formatting.
- 12 strict public-input negatives with built-in type, range, dimension,
  uniqueness, ordering, and observation-key violations.
- Pure supervisor metadata checks: two positives, eight report mutations and16
  receipt mutations. These call validation functions only; never launcher main,
  files, forks, watchdogs, signals, or process creation.

Expected schema is `reference-v3-suite-report-v1`; suite_role is
`independent-review`; optimization bool comes from the interpreter. Report binds
the exact FREEZE hash and actual hashes of every file in that manifest.

## Fixed caps and process contract

Ordinary per-call Budget matches frozen author CAPS.json exactly. No cap is
learned from a baseline run. All deliberate overrides above are literal. Any
unexpected exception, ordinary incomplete result, wrong obligation count, or
source drift makes FAIL, never a smaller successful subset. No retry is planned.

The two worker commands are absolute pinned Python with `-I -B`, plus `-O` only
for optimized, and this absolute `suite.py --output <fixed job/result.json>`.
Each worker checks nominal CPU60/75, AS1GiB, isolated/no-bytecode mode, and inherited
parent-death SIGKILL. Supervisor owns independent wall150 and OS-reported wait4
usage. Each slot reserves75 worker+5 supervisor CPU; no second accounting of suite
diagnostics. CPU/RSS numbers are OS-reported; no physical hard-limit guarantee.
Output is <=2MiB compact JSON published without overwrite. Partial .tmp is not
a result. Worker stdout/stderr and supervisor logs are preserved separately.

The currently proposed stage partition is320 CPU; root's higher planning ceiling
does not authorize retries, source changes after freeze, or contingency spending.
