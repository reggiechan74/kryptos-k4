# Reference v3 — independent full static implementation review

**STATIC PASS, bounded scope. No code has been imported, compiled, or tested by
this reviewer at this report's creation.** Execution remains gated by a separate
exact-manifest pre-run confirmation. This is not a holdout result or K4 admission.

## Reviewed implementation pins

| File | SHA-256 |
|---|---|
| reference_v3.py | `0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9` |
| author suite.py | `1371c5e4bfad65725d293a148c5cff5888314845a66cf3b4d033d0ae87f124fa` |
| fixtures.json | `b4cfddb10c6d87dfd6ecdaeab8cbf5c1518bb1c037ae684163e6db8fee585fa6` |
| author CONTRACT.md | `bd038d2084eac7240a6981a55c061ecbc24305a3c13fd0cc641538930fc99715` |
| CAPS.json | `3f530d258d8d8fc5c1802e73730b1577b440e5686abc01722414c7e698fc0ca6` |
| author TEST-PLAN.md | `6fd0934b7bc37bee2914d340bbaa45d852703cabedd36de2914850ccd6d701fb` |
| supervisor.py | `9f52f277b4bf4836bd37a4a3192d910e780f4931076ceda4e614f56eeaff1ce2` |
| EXECUTION-CONTRACT.md | `2feffdc00229e56c6e5d117da8e41000eecada17326d8d5c7f849e90813b63f2` |
| independent suite.py | `40d51c77487bd15f75f5dcd079cdab72d90efd11b1d9dc14d9640479d55c7d2b` |
| independent_oracles.py | `4ae51bf0989fbf546b6acae143b97ee14e32cac6798a23c9b86981e2a04f98af` |
| independent TEST-PLAN.md | `36bec2404ce3c09673e7a6d002970767e581a4ba8f03151e83151153465e3acf` |

Author sources are under `/ARCHIVE_WORKSPACE/canonical-residual-reference-v3`,
execution sources under `/ARCHIVE_WORKSPACE/residual-reference-v3-execution`.
The fixed previously audited engine is `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`;
its generic affine dependency is `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`.
No producer or historical source was edited by this reviewer.

## Proof-to-code findings

1. **Exact affine space, not a witness certificate.** Each fresh solve uses
   independent F13 elimination and mandatory transcript replay. Every operation
   is an invertible row operation; exact original ordered equations, dimension,
   field, and request/support/beta/role binding are checked. The checker verifies
   full augmented RREF, pivot order and pivot columns. Inconsistency is exactly
   an augmented-column pivot. It derives every free column, point, and basis;
   original equations and free-coordinate identity certify complete kernel rank.
   All supplied recognized claims are compared with strict types. Unknown
   certificate metadata is deliberately not a claim and is not copied to proof.

2. **The restricted-domain pitfall is closed.** A producer base is independently
   certified, then both affine inclusions are checked using point and complete
   kernel bases. A broader producer base cannot pass merely because its cuts
   happen to compensate. Both inconsistent bases are equal as empty sets;
   exactly one inconsistent base is unequal. Width-zero consistent affine space
   is a singleton, distinct from an empty residual family.

3. **Complete original inventory.** All maximal allowed original supports and
   every covered canonical beta subset are traversed. Parity observations and B
   are applied independently, not inferred from producer pieces. Every remaining
   raw observation fiber is solved even if absent from producer output. On every
   independently reconstructed alpha point, direct global R is compared with
   producer cut membership. Missing feasible pieces reject; final exact registry
   equality rejects extra, inconsistent, ineligible, or empty pieces. Thus the
   verifier does not certify completeness from a supplied list of witnesses.

4. **Correct function semantics and lifts.** Equality features use full Z26
   symbols before either field reduction. Canonical R is E minus B union the
   exact constant-plus-signed-equality C functions, not raw support syntax or a
   finite trace comparison. For each retained descriptor every original parity
   assignment satisfying grouped XOR is tried, including cancellation and
   nonminimal lifts. CRT predicts complete Z26 vectors. Full joint sets are
   preserved separately from marginal masks; all cross-piece provenance is
   retained. No support/beta merging or caching silently drops fibers.

5. **Producer output claims.** Core scalar masks and alpha witnesses are checked
   against complete reconstructed piece sets; original sparse witnesses are
   checked for canonical coefficients, support membership, observations,
   descriptor, minimal support and referenced piece. Top-level masks, witness
   coverage and full provenance must match. Optional advertised joints receive
   complete set comparison, not marginal checking. The engine need not emit a
   joint field. Only declared engine claims plus optional joints are certified;
   arbitrary extra metadata is not authenticated. A diagnostic expected memo is
   checked only after reconstruction and can never supply a proof premise.

6. **Caps and strict failure states.** Every public build/verify call starts one
   cumulative meter; nested supports, betas, eliminations, replays, lifts and
   witness checks do not reset it. Exact13^d fiber preflight and per-visit debit
   include rejected residual points. Named caps are exact nonnegative built-in
   integers; wall accepts finite built-in nonnegative numbers, including huge
   finite integers without a float cast. Validation precedes early/memo paths.
   Discovered invalidity raises an explicit error. Earlier exhaustion remains
   incomplete, never proof of emptiness or invalidity. All semantic fields are
   discarded on resource failure. Producer-INCOMPLETE checks declared fields
   plus recognized optional joints/piece_masks/lifts and only certifies format.

7. **Honest accounting units.** Solve, replay, generated/replayed row operations,
   fiber visits, parity lift trials, witnesses, logical records and explicit
   work blocks are distinct and precharged before their protected operations.
   Record units are the frozen convention, not bytes or an RSS theorem. Work
   units are not CPU cycles or every Python instruction. Bootstrap, fixed cap
   validation and report I/O remain outside per-call units but within worker
   CPU. The legacy ambient equivalent is a mathematical diagnostic, not an old
   cap debit. No v2-cap or timing comparability/speedup conclusion follows.

## Supervisor audit

The four ordered one-attempt slots have durable exclusive lock and pre-fork
75-worker/5-supervisor reservations, independent remaining buckets, and no retry.
Pre/post pins include commands, role/mode/count schema and source map. A bare PASS
does not suffice. Prior finalized receipts, exact artifact inventories, report
identity and cumulative usage are revalidated before the next slot. Leftover
temporary results, source drift, timeout, signal, observed overshoot, malformed
report or uncertain receipt stop execution. Missing/uncertain outcomes retain
the reservation; a known reaped failure records use but cannot resume.

Fork occurs before the parent lowers hard headroom, allowing independent child
60/75CPU and1GiB versus parent4/5CPU and256MiB settings. Parent-death SIGKILL guards
both links. The worker has its own session; the wall watchdog kills its group
with a pre-setsid PID fallback. waitid(WNOWAIT) retains PID ownership until the
alarm is disarmed and wait4 reaps, avoiding a reused-PID signaling race. Child
setup logs are redirected first; supervisor-level logs are retained separately.

Worker wait4 CPU is OS-reported inclusive use, not perfect physical metrology.
The supervisor near-end sample is exclusive and omits final write/exit tail;
the full5 allocation is charged separately, not fabricated measured use or a
proven physical upper bound. The earlier unexplained CPU overshoot remains an
explicit limitation. Static review/hash/write control overhead is unmeasured,
not claimed zero; suite diagnostics must not be added again to worker receipts.

## Corrections resolved before freeze

Static review led to strict mandatory certificate bindings and string identities;
pre-debit allocation/copy ordering; huge integer wall handling; bounded provenance
IDs; optional joint claims and incomplete semantic leak guards; isolated-mode
suite bootstrap; exact report identity; full prior-receipt validation; leftover
temporary rejection; redirect-first child diagnostics; and a watchdog measured
from the same pre-fork wall origin. The current pins above include these fixes.
No previously executed artifact was rewritten and no runtime failure was tuned.

## Pending evidence and restrictions

The independently authored suite uses the same disclosed40+2 literal mathematical
cases but a different original-coefficient enumeration and direct finite oracle;
its fixed tests/counts are detailed in TEST-PLAN.md. Source-only author feedback
confirmed its engine/API mutation targets. This is independent code/oracle review,
not independent or hidden data. Normal and optimized execution are still pending.
All exact source, interpreter, commands, fixtures, mutations, schemas and limits
must join a final frozen manifest before approval; no syntax probe is exempt.

The affine algebra, Gaussian elimination, CRT and finite enumeration are classical
mathematics. The locally reviewed contribution is this specific certified
observation-fiber reference and integration contract, not a newly established
cryptanalytic breakthrough. This work does not salvage the failed cohort, unlock
truth, authorize replay/redraw, establish historical novelty, resolve matbalez
scope, or admit K4. The failed cohort remains permanently INCOMPLETE.
