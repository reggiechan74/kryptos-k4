# Independent review: full-feature resource pilot and workload preflight

## Verdict and exact scope

**DESIGN PASS, with implementation and execution gates still closed.** No
mathematical or protocol blocker remains in the clarified proposal. This review
does not authorize code, trace expansion, imports, solver calls, tests, data
draws, or use of any previous allocation or contingency.

Reviewed proposal:
`/ARCHIVE_WORKSPACE/residual-reference-v3-next-stage-proposal/PROPOSAL.md`

SHA-256:
`cdd02be85e643b4226eb4a58bb7eade35f8d28108ea979ba82f87765025c7c0a`.

private administrative register [reference omitted] was read first. Earlier proposal revisions are
preserved by their author. The completed v3 PASS, sources, fixtures, receipts and
reports remain unchanged. This review used document reading and direct symbolic
reasoning only: no recurrence expansion, fixture construction or mathematical
program execution occurred. Static read/hash/write overhead is unmeasured, not
claimed to be zero CPU.

## 1. Exact fixed-traversal workload theorem

For an original support T of size 3, the raw mod13 observation matrix does not
depend on beta. A consistent system with coefficient rank r_T has exactly
13^(3−r_T) solutions. Complete replayed augmented RREF establishes consistency
and rank; a complete free-coordinate basis explains this cardinality, not just
the existence of one solution.

Parity compatibility depends only on the covered canonical beta groups and the
observed parity values. K_T counts every covered beta passing those equations
and not contained in {0,1}. The unchanged v3 traversal visits the entire raw
observation fiber once for each such beta, before applying E/C residual cuts.
Thus its successful complete traversal has exactly

    W = Σ_T χ_T K_T 13^(3−r_T)

fiber-point visits. Inconsistent systems contribute zero. Duplicate matrices
from different original supports remain separate terms, and different betas
are not merged. All arithmetic must be exact integers.

This is an exact count of one fixed implementation's observation visits, not an
intrinsic lower bound for alternative algorithms, CPU time, memory or every other
meter. Successful VERIFIED_EXACT/VERIFIED_EMPTY receipts must have fiber_points=W.
The converse is false: a call can debit W and subsequently fail a witness, output,
time or storage check. PRODUCER_INCOMPLETE also does not establish this relation.
The preflight API intentionally makes no semantic claim even when W=0.

## 2. Independent verification of control A

There are C(31,3)=4,495 original support containers. Six canonical groups have
two original coordinates and 19 have one. A size 3 support can contain at most one
complete doubled group. Choosing that group and its third coordinate gives
6×29=174 supports with two covered groups; the other 4,321 cover three. Therefore

    Σ_T 2^|G(T)| = 4,321×8 +174×4 =35,264.

For beta restricted to the two B groups {0,1}, expand
2^|G(T)∩{0,1}|=(1+I_0)(1+I_1). The four summed terms are:

- all supports: 4,495;
- those containing the constant coordinate: C(30,2)=435;
- those meeting lag1/square1: 2 C(30,2)−29=841;
- those containing the constant and meeting lag1/square1: 2×29−1=57.

The sum is 5,828, leaving 29,436 eligible support/beta pairs. With no observations,
each mod13 system is consistent of rank 0. Consequently

    W_A =29,436×2,197 =64,670,892.

This includes all raw alpha points later rejected by R. It exceeds the proposed
1,000,000 allowance. A must be resource-gated, not called EMPTY: the coefficient
vector 13 E12 is a concrete residual law of support 1. A's full analytic W is not
to be confused with a runtime certificate proving only a prefix lower bound.

## 3. Certified prefix rejection

Each summand is nonnegative. After a fully checked lexicographic support prefix,
its exact sum L satisfies W≥L. Therefore L>1,000,000 soundly permits immediate
GATE_REJECTED_LOWER_BOUND with exact_W=None. This avoids scanning the rest of an
obviously excessive workload without changing or pruning the semantic solver.

The certificate checker must verify that the processed supports are exactly the
lexicographic prefix: no omission, duplicate or reordering. Each support needs
its complete reconstructed observation system, replayed rank/consistency proof,
and independently recomputed complete compatible-beta list. A partial last
support must not contribute to the certified L. Only a fully completed inventory
of all 4,495 supports can report exact W or admit a within-point-cap attempt.
L≤cap with an unfinished inventory cannot admit anything.

Generation and second serialized replay must retain exact original support,
input and field binding even when matrices match. No certificate count, rank or
beta list may be trusted merely because an author recorded it. Durable complete
prefix evidence must be distinguished from unfinished bytes. Exhaustion before
this evidence is complete is PRECHECK_INCOMPLETE, not an exact count or a mask.

## 4. Control B semantics and indexing

The symbolic recurrence defines 97 Z26 input symbols deterministically; each
forced repeat copies an earlier valid symbol, and every other step reduces the
polynomial mod26. No RNG or secret parameter is involved. For t=6,…,96, the
newest-first context (c_(t−1),…,c_(t−6)) is well-defined and gives 91 overlapping
contexts. The stated observation positions have 13+11=24 members and map by
t−6 exactly to rows 15,…,27 and 57,…,67.

Outputs y_t are separately defined by the public law, not identified with c_t.
This is a supervised relation on a contiguous input trace, not an assertion
that the input obeys an autoregressive output law or models a real cipher. All
outputs are public, including unobserved ones; this is not hidden validation.

The original coefficient vector with theta_2=3, theta_28=5, theta_29=7 has three
nonzero mod13 coordinates and beta groups {2,22,23}. It is in E, outside B, and
cannot be a constant-plus-single-signed-equality C descriptor. It is therefore
in R. Its three nonzero alpha coordinates force minimum original support 3;
the displayed vector achieves that minimum. It satisfies every defined output
by construction. Hence a completed correct semantic result for B must be EXACT,
not EMPTY. No uniqueness, rank, W, mask size or runtime conclusion follows.

The stream must not be replaced or redesigned after its resource outcome. The
present review did not calculate or expand any of its97 symbols or91 contexts.

## 5. Caps, accounting and stopping plan

The proposed finite preflight ceilings are internally consistent:

- at most 4,495 supports and 35,264 covered-beta candidates;
- at most 35,264×24=846,336 parity row tests;
- at most 4,495 independent solves and 8,990 replay checks;
- a 24-row augmented system of width 4 has at most 4 pivots, each with one swap,
  one scale and at most 23 additions:100 operations. Generation plus two replays
  therefore costs at most 4,495×100×3=1,348,500 operations, within 1,500,000;
- no observation-fiber enumeration, lift trials or sparse witness checks belong
  to this preflight. Its corresponding caps are zero.

The 50,000,000 logical work and 2,000,000 record allowances still require exact
charge-site definitions and implementation audit. They are not demonstrated CPU
or memory bounds. Proposed per-call wall and other caps do not override the
outer CPU/wall constraints. W≤1,000,000 admits only a bounded attempt: producer,
reference, lift, record, row-operation, memory and time caps may still stop it.

The certificate inventory is now bounded independently of per-file limits:
two fixed A/B evidence paths per worker, at most 32 MiB each and 64 MiB per worker;
at most eight certificate files/256 MiB over four workers. Partial bytes count;
no extra copies or temporary certificate paths can bypass the cap. Streaming
format, pre-debit byte/file accounting, durable completion markers, conditional
presence for unstarted B and all log/summary/resource paths must be frozen.

The revised decision table is unambiguous and conservative:

1. Expected certified A rejection permits only B preflight in the same worker;
   A semantic processing is never run.
2. Unexpected A status or any computational/schema/storage error stops the stage.
3. Fully checked B W within allowance permits a bounded producer attempt and the
   unchanged full independent v3 verifier; no preflight result replaces it.
4. B resource-gating or any failure/cap/kill cancels every later worker, including
   independent and optimized preflights. It yields no end-to-end B PASS.
5. Only successful B VERIFIED_EXACT plus all identity/resource checks permits
   the next fixed slot. All four successful slots are needed for full pilot PASS.

This deliberately means an early resource-gate finding need not receive a later
independent executable replay in the same schedule. Such a replay requires new
explicit authority, not leftover CPU. Static evidence review remains allowed.

The proposed new allocation is 300 worker +20 supervisor=320 CPU seconds, with
four one-use workers, nominal 60/75 CPU, wall150 and 1 GiB each, plus separately
limited 4/5 CPU and 256 MiB supervisors. This is a proposal only, not authorization
or reuse of the old 680 contingency. Worker-reported inclusive CPU, supervisor
exclusive samples, full policy charges and outstanding reservations remain
separate. Prior OS-limit overshoot uncertainty is not resolved by this design.

## Required next gate

Before any implementation or execution, obtain the respective explicit project
authorization. Any authorized implementation must use a new stage root and
manifest, preserve all existing sources/results, and receive full independent
source review. Freeze literal expanded inputs, original coefficients, bindings,
serialized certificate schema, exact meters/caps, mutations, fixed commands,
report identity, output inventory, failure transitions and durable launcher.
The earlier launcher cannot be assumed to accept new certificate artifacts
without a separately reviewed inventory/schema change and new approval.

Independent review must recompute covered betas and replay proof material rather
than trust count-only outputs. Current v3's full support/beta inventory, mutual
base equality, direct R/cut comparison and complete relations must remain intact.
No new cache, quotient merge or semantic shortcut is covered by this PASS.

This is a classical rank/cardinality calculation and a local resource-control
design. It is not a new cryptanalytic hypothesis or novelty claim. The old failed
cohort remains permanently INCOMPLETE and sealed; v003 is not a fixture. Matbalez
scope remains unresolved; no target, holdout or publication permission is granted.

For historical clarity, completed v3 evidence comprises two independently written
suite/oracle implementations—one author and one reviewer—each executed in normal
and optimized modes, not two separately implemented author suites. This wording
clarification does not alter any prior immutable evidence.
