# Literal reference-v3 suite — source-only pre-run freeze candidate

This is disclosed generic development, not a fresh holdout or K4 admission. The
literal fixtures and this source were authored without executing, importing or
compiling either the reference or suite. No RNG, seed, target data, historical
cohort replay, v003-derived fixture, truth file, cache or saturation is used.
The fixed producer and all predecessor artifacts remain unchanged. Matbalez
historical scope remains unresolved; these checks do not resolve that history.

Execution requires the independent joint freeze of all source bytes, this plan,
`fixtures.json`, `CAPS.json`, the implementation contract, supervisor, exact four
commands, output identities and approval gate. Neither this plan nor a proposed
cap authorizes execution. There is no automatic retry or budget enlargement.

## Command and output

The author worker command is the pinned Python executable followed by
`-I -B`, optional `-O`, the absolute `suite.py` path, and `--output` followed by
the supervisor's unique absolute result path. The suite imports the reference
and fixed engine only after hashing every file listed in the stage freeze.
It checks the same inventory again after all obligations, before PASS.
There are no worker subprocesses or network requests.

The atomic JSON output is at most 2 MiB. It has schema
`reference-v3-suite-report-v1`, `suite_role="author"`, Boolean
`python_optimized`, actual `stage_freeze_sha256`, and `source_sha256` equal to
the actual complete frozen path-to-hash map. The `obligations` object must equal
the following dictionary for PASS (all values are built-in nonnegative ints):

| Key | Required completed count |
|---|---:|
| affine_cases | 16 |
| affine_json_roundtrips | 16 |
| base_equivalence_cases | 13 |
| certificate_mutations | 16 |
| residual_cases | 40 |
| raw_complete_relation_comparisons | 42 |
| relation_boundary_controls | 2 |
| carry_descriptors | 156 |
| alias_pair_lifts | 676 |
| alias_pair_descriptors | 338 |
| symbol_alias_checks | 26 |
| result_mutations | 16 |
| malformed_cap_requests | 850 |
| counter_boundary_slots | 32 |

The report also records per-case counts and receipts, rejection reasons,
script-only CPU/wall/RSS diagnostics, and classification. Script CPU diagnostics
are subsets of supervisor receipts, not amounts to add again. A normal exception
produces FAIL with only completed obligation counts; an ordinary unexpected
INCOMPLETE also prevents PASS. Exit 0 means PASS only. A kill or missing final
report is incomplete, never an exact result. Atomic publication refuses to
overwrite a prior output and leaves no `.tmp` after successful publication.

## Finite inputs and independent comparisons

`fixtures.json` gives every context and equation as literal integers, with no
random-generation or favorable-selection step. The 10 domains crossed with the
four patterns produce the fixed 40 slots D00-P1 through D09-P4. Expected status
is the literal per-domain table; in particular P2 is EMPTY for D01/D04/D05/D06,
and every P3 is EMPTY because the same context is observed as both 0 and 1.
No status or cap is inferred from a test run.

The suite's own raw oracle enumerates every exact original support of size at
most s and every nonzero Z26 coefficient tuple. It computes full-Z26 equality
before reducing fields, independently constructs the 31/25 descriptor and the
156-member carry set, and directly applies E minus (B union C). It uses no
producer, generic-core or reference solve/predicate helper. It preserves every
raw lift, every containing maximal original support, each eligible canonical
beta, all per-piece points/masks, global descriptors/joint predictions, and all
cross-piece provenance. These complete sets must equal the reference sets for
all 42 relation fixtures. Each producer result is separately verified from raw
observations with a new cumulative Meter; ordinary results must be complete.

The two separate boundary controls are literal, nonempty cases:

* `shared-old-new`: context `[2,15,5,6,9,10]`, observed 0, feature 28 only.
  Excluded +E12 and -E12, and retained 13 E12, all predict 0 on this public
  context. The reference must remain EXACT with the singleton trace `(0,)`.
* `joint-not-cartesian`: two copies of `[2,2,5,6,9,10]`, no observations,
  feature 28 only. The joint set has 11 diagonal pairs; marginal product has
  121 pairs. `(3,3)` belongs, `(3,5)` does not, even though both marginal
  values are available. No new engine joint output field is required.

The affine helpers have 16 literal systems, dimension 0 through 3, translated,
rank-deficient, inconsistent, redundant and nonleading-pivot cases. Own ambient
enumeration is compared against the certificate's reconstructed free-coordinate
points. The empty n=0 consistent helper has one empty vector; this is not the
full residual D00 case, which has no E-eligible function and is EMPTY. Every
certificate also survives one JSON round trip with identical derived semantics.

There are 13 exact mutual-base comparisons, independently checked by own full
ambient point sets. B12 is **helper-only**: O is x=0, P is the full line, with
12 compensating cuts x=t for t=1..12. The final filtered sets agree, but the
uncut bases do not. It is not passed through the unchanged producer's two-cut
shape validator, which would mask the intended base-equivalence obligation.

## Frozen invalid-certificate targets

The exact 16 mutations C00-C15 are literal records in `fixtures.json` and each
must raise `VerificationError` with the ordinary sufficient proposed budget:
zero row scaling; same-row add; out-of-range swap; omission of A12's specific
first `swap(0,1)`; wrong augmented RREF entry; wrong equation hash; wrong support
binding; wrong field; false pivot list; omitted free coordinate; missing kernel
direction; duplicated dependent kernel direction; false dimension; wrong
particular point; inconsistent-system claim changed to consistent; Boolean
matrix coefficient. A12's targeted non-no-op is checked before removal; the
suite never assumes removal of an allowed no-op invalidates a certificate.

All optional claims are tested against checker-derived data rather than trusted.
The suite does not promise rejection before a cap has allowed the checker to
reach an offending claim: cap-incomplete and discovered semantic rejection are
distinct outcomes.

## Frozen result mutation targets

Each target starts from a fresh deep copy of the identified fixed producer
result, except the explicitly diagnostic expected memo mutation:

1. D01-P1 top row 0 value 3 witness becomes `[[28,1]]` (C).
2. Same target becomes `[[28,2]]` (B).
3. D01-P1 piece 0 core row 0 residue 0 witness becomes `[1]` (excluded alpha).
4. D01-P1 piece 0 first forbidden cut is removed.
5. D01-P1 complete piece list is cleared.
6. D01-P1 piece 0 is appended a second time.
7. D01-P1 piece 0 beta is changed to the empty list.
8. D01-P1 row 0 value 3 provenance list is cleared.
9. D01-P1 row 0 mask loses value 3.
10. D01-P1 source SHA256 is replaced by 64 zeroes.
11. D01-P1 adds advertised joint set `[]`, a false complete joint claim.
12. D01-P1 status becomes INCOMPLETE while partial semantic claims remain.
13. D01-P1 becomes a formally empty top relation, falsely claiming EMPTY.
14. D05-P1 piece 0 feasibility lift becomes
    `[[1,13],[7,13],[28,13]]`: cancellation yields a valid descriptor with a
    one-feature lift, so the advertised three-feature lift is not minimum.
15. D02-P2 piece 0 observation base is weakened to `[]`; its core identity is
    recomputed from the literal public base/cut/scalar identity expression so
    the test reaches the base-equivalence obligation, not a stale-hash check.
16. D01-P1 diagnostic expected reference memo has its joint set cleared;
    recomputation must reject the discrepancy instead of trusting the memo.

These targets are predetermined; a rejection for any semantic/shape reason is
recorded, while target-changing or favorable post-run selection is forbidden.

## Descriptor and cap checks

All 26 constants, three equality locations and both signs give 156 excluded C
descriptors. Every one of the 676 coefficient pairs on lag1/square1 is enumerated
to produce 338 canonical descriptors and exact minimum support costs; these
costs must match the reference. All 26 symbols check 13*x^2 = 13*x modulo 26.

Malformed cap coverage is 8 integer fields times 20 exact labels times 5 entry
paths, plus 10 malformed wall-limit labels times the same 5 paths: 850 calls.
Paths are build, ordinary verify, verify with diagnostic expected memo, verify
EMPTY, verify INCOMPLETE. Labels are frozen in JSON, including bools, negative
ints, floats (NaN and infinities), noninteger objects and an int subclass.
A local exact BudgetV3 instance is deliberately altered with `object.__setattr__`
before each call, so constructor-only validation cannot mask an entry bypass.

The 32 counter slots are four for each of eight named counters:

* Functional zero cap: actual D03-P2 verification must be
  VERIFICATION_INCOMPLETE, with no partial semantic fields and zero debits to
  the capped counter. This fixture has literal row `[2,1,0]`, requiring scale 7;
  rank alone is not used as proof of positive row-operation count.
* Primitive exact boundary: a same-Meter debit 2 at cap 2 succeeds.
* Primitive one-below: debit 2 at cap 1 raises before charging that debit.
* Cumulative: for seven counters, two consecutive one-unit debit blocks on the
  same Meter at cap 1 reject the second without resetting the first. For fiber
  points, actual D03-P1 verification uses cap 169: after visiting one full
  two-dimensional observation fiber, the next beta's 169-point preflight must
  return VERIFICATION_INCOMPLETE, receipt fiber_points=169, and all semantic
  fields None. No runtime-derived cap or work estimate is substituted.

Primitive slots test the shared cap mechanism, not a promise that every helper
has the same total operation count. Ordinary per-call numerical caps are exactly
`CAPS.json`; they are new units, not v2 max_points compatibility or CPU estimates.
Any failure stops PASS and cannot trigger an automatic enlarged retry.

## Outer resources and interpretation

The separate supervisor owns the four-worker schedule, bounded process trees,
nominal CPU and wall settings, actual receipts and allocation reconciliation.
The planned stage partition is 300 worker CPU seconds plus 20 exclusive
supervisor seconds (320 total); 680 contingency is not automatic replenishment.
Nominal OS limits are not claimed to be proven measured maxima. A measured
overshoot, kill or uncertain receipt is incomplete/failed and blocks reuse.
This plan neither compares v2 timing/cap units nor salvages the permanently
INCOMPLETE failed cohort. No exact source in this candidate has been run yet.
