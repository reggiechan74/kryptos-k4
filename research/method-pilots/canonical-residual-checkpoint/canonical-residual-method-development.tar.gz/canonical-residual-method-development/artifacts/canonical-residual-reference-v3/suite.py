"""Frozen literal disclosed-development suite. Execution requires freeze approval.

This file has been authored without importing, compiling or executing it.
The supervisor owns hard limits and inclusive process-tree accounting.
No cohort, old result, random generator, seed, truth or held-out file is read.
"""
import argparse
import copy
from decimal import Decimal
from fractions import Fraction
import hashlib
from itertools import combinations, product
import json
import os
from pathlib import Path
import resource
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
ref = None  # Imported only after the frozen source inventory has been checked.

ENGINE_DIRECTORY = Path('/ARCHIVE_WORKSPACE/canonical-residual-dev')
ENGINE_SHA256 = 'be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67'
DEPENDENCY_SHA256 = '1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d'
SUITE_VERSION = 'residual-reference-v3-disclosed-suite-1'
FREEZE_PATH = Path('/ARCHIVE_WORKSPACE/residual-reference-v3-execution/FREEZE.json')

# These are new named units, NOT the old ambient max_points cap. They are fixed
# before execution and may not be widened after a failure or unexpected cost.
ORDINARY_CAPS = dict(max_fiber_points=1_000_000, max_lift_trials=4_000_000,
    max_solve_calls=100_000, max_certificate_checks=200_000,
    max_row_operations=5_000_000, max_work_units=500_000_000,
    max_witness_checks=1_000_000, max_output_records=5_000_000, max_seconds=45.0)


class SuiteFailure(RuntimeError):
    pass


def check(condition, message):
    if not condition:
        raise SuiteFailure(message)


def budget(**changes):
    values = dict(ORDINARY_CAPS)
    values.update(changes)
    return ref.BudgetV3(**values)


def original_group(index):
    if index <= 6:
        return index
    return index - 6


def independent_features(x):
    row = [1]
    row += list(x)
    row += [(a*a) % 26 for a in x]
    for a in range(6):
        for b in range(a+1, 6):
            row.append((x[a]*x[b]) % 26)
    row += [1 if x[a] == x[a+1] else 0 for a in (0, 2, 4)]
    return tuple(row)


def independent_descriptor(vector):
    alpha = tuple(x % 13 for x in vector)
    beta = [0]*25
    for index, value in enumerate(vector):
        beta[original_group(index)] ^= value % 2
    return alpha, tuple(beta)


def independent_carry_set():
    answer = set()
    for q in (28, 29, 30):
        for constant in range(26):
            for sign in (1, 25):
                vector = [0]*31
                vector[0], vector[q] = constant, sign
                answer.add(independent_descriptor(vector))
    return answer


def independent_residual(desc, carry):
    alpha, beta = desc
    return (any(alpha[j] or beta[original_group(j)] for j in (28, 29, 30))
            and any(beta[2:]) and desc not in carry)


def raw_oracle(case, carry):
    """Own raw Z26 enumeration, no field solve/compiler/reference helpers."""
    contexts, observed = case['contexts'], case['observed']
    allowed, sparsity = case['allowed_features'], case['sparsity']
    rows = [independent_features(x) for x in contexts]
    maximal = list(combinations(allowed, min(sparsity, len(allowed))))
    pieces, lifts, joints = {}, {}, set()
    masks = [set() for _ in rows]
    point_count = 0
    for size in range(min(sparsity, len(allowed))+1):
        for support in combinations(allowed, size):
            for values in product(range(1, 26), repeat=size):
                point_count += 1
                # Independent exact support enumeration visits no zero-valued
                # stored coordinate; the empty support is included once.
                if any(sum(rows[i][j]*v for j, v in zip(support, values)) % 26 != z
                       for i, z in observed.items()):
                    continue
                vector = [0]*31
                for j, value in zip(support, values):
                    vector[j] = value
                desc = independent_descriptor(vector)
                if not independent_residual(desc, carry):
                    continue
                alpha, beta = desc
                lifts.setdefault(desc, set()).add(tuple(vector))
                joint = tuple(sum(row[j]*v for j, v in zip(support, values)) % 26
                              for row in rows)
                joints.add(joint)
                for i, value in enumerate(joint):
                    masks[i].add(value)
                for container in maximal:
                    if set(support).issubset(container):
                        key = (container, tuple(g for g, bit in enumerate(beta) if bit))
                        pieces.setdefault(key, set()).add(tuple(alpha[j] for j in container))
    provenance = [{z: set() for z in row} for row in masks]
    piece_masks = {}
    for key, points in pieces.items():
        container, active = key
        local = [set() for _ in rows]
        for alpha in points:
            for i, row in enumerate(rows):
                residue = sum(row[j]*a for j, a in zip(container, alpha)) % 13
                parity = sum(row[g if g <= 6 else g+6] for g in active) % 2
                value = residue if residue % 2 == parity else residue+13
                local[i].add(value)
                provenance[i][value].add(key)
        piece_masks[key] = local
    return dict(status='EXACT' if pieces else 'EMPTY', pieces=pieces, lifts=lifts,
                joints=joints, masks=masks, provenance=provenance,
                piece_masks=piece_masks, raw_vectors=point_count)


def plain_case(case):
    return {key: case[key] for key in ('contexts', 'observed', 'sparsity', 'allowed_features')}


def literal_cases(fixtures):
    answer = []
    for domain in fixtures['domains']:
        for number, pattern in enumerate(fixtures['patterns']):
            answer.append(dict(id=domain['id']+'-'+pattern['id'],
                contexts=[list(fixtures['contexts'][i]) for i in pattern['context_indices']],
                observed={i: value for i, value in pattern['observed']},
                allowed_features=list(domain['allowed_features']), sparsity=domain['sparsity'],
                expected_status=domain['statuses'][number]))
    return answer


def complete_equal(reference, oracle, label):
    check(reference['status'] == oracle['status'], label+': status differs')
    for key in ('pieces', 'lifts', 'joints', 'provenance', 'piece_masks'):
        check(reference[key] == oracle[key], label+': '+key+' differs')
    check([set(x) for x in reference['masks']] == oracle['masks'], label+': masks differ')


def summaries(reference):
    return dict(status=reference['status'], pieces=len(reference['pieces']),
                canonical_functions=len(reference['lifts']),
                original_lifts=sum(len(x) for x in reference['lifts'].values()),
                joint_predictions=len(reference['joints']),
                allowed_marginal_values=sum(len(x) for x in reference['masks']),
                resources=reference['resources'])


def run_relations(fixtures, engine, report):
    carry = independent_carry_set()
    check(len(carry) == 156, 'independent C set must contain exactly156 descriptors')
    cases = literal_cases(fixtures)
    check(len(cases) == 40, 'literal relation count')
    retained_cases = {}
    for case in cases:
        kwargs = plain_case(case)
        truth = raw_oracle(case, carry)
        check(truth['status'] == case['expected_status'], case['id']+': analytic status differs')
        reference = ref.build_reference_v3(**kwargs, budget=budget())
        check(reference['status'] != 'INCOMPLETE', case['id']+': ordinary reference incomplete')
        complete_equal(reference, truth, case['id'])
        result = engine.decode(**kwargs)
        check(result['status'] == case['expected_status'], case['id']+': engine status')
        verified = ref.verify_result_v3(**kwargs, result=result, budget=budget(),
            expected_source_sha256=ENGINE_SHA256)
        check(verified['status'] == 'VERIFIED_'+case['expected_status'], case['id']+': verification status')
        report['relations'].append(dict(id=case['id'], raw_vectors=truth['raw_vectors'],
            reference=summaries(reference), verification=verified))
        # Only tiny fixed cases needed by later fixed mutations/cap paths are kept.
        if case['id'] in ('D00-P1', 'D01-P1', 'D02-P2', 'D03-P1', 'D03-P2', 'D05-P1', 'D08-P1'):
            retained_cases[case['id']] = (case, reference, result)
    for fixture in fixtures['boundary_controls']:
        case = dict(id=fixture['id'], contexts=fixture['contexts'],
                    observed=dict(fixture['observed']), sparsity=fixture['sparsity'],
                    allowed_features=fixture['allowed_features'])
        truth = raw_oracle(case, carry)
        reference = ref.build_reference_v3(**plain_case(case), budget=budget())
        complete_equal(reference, truth, case['id'])
        check(reference['status'] == fixture['status'], case['id']+': boundary status')
        check(len(reference['joints']) == fixture['joint_count'], case['id']+': joint cardinality')
        if 'masks' in fixture:
            check([set(x) for x in reference['masks']] == [set(x) for x in fixture['masks']],
                  case['id']+': boundary masks')
        if 'marginal_product' in fixture:
            size = 1
            for mask in reference['masks']:
                size *= len(mask)
            check(size == fixture['marginal_product'] and size > len(reference['joints']),
                  'joint relation incorrectly treated as Cartesian')
            check((3, 3) in reference['joints'] and (3, 5) not in reference['joints'],
                  'frozen diagonal joint controls')
            check(3 in reference['masks'][0] and 5 in reference['masks'][1],
                  'negative joint control must be marginally allowed')
        if fixture['id'] == 'shared-old-new':
            # Nonempty PUBLIC finite trace, not an empty-context substitute.
            # Exclusion is a property of the function descriptor, not its trace.
            for coefficient, eligible in ((1, False), (25, False), (13, True)):
                vector = [0]*31
                vector[28] = coefficient
                check(independent_residual(independent_descriptor(vector), carry) == eligible,
                      'old/new shared trace predicate')
                check(tuple(sum(a*b for a, b in zip(independent_features(c), vector)) % 26
                            for c in case['contexts']) == (0,), 'shared nonempty trace')
            check(reference['joints'] == {(0,)}, 'shared old/new residual prediction retained')
        result = engine.decode(**plain_case(case))
        verified = ref.verify_result_v3(**plain_case(case), result=result, budget=budget(),
            expected_source_sha256=ENGINE_SHA256)
        check(verified['status'] == 'VERIFIED_EXACT', case['id']+': boundary verification')
        report['relation_boundaries'].append(dict(id=case['id'], reference=summaries(reference),
                                                verification=verified))
    return retained_cases, carry


def reject_mutation(name, case, reference, result, modify, report):
    altered = copy.deepcopy(result)
    modify(altered)
    try:
        ref.verify_result_v3(**plain_case(case), result=altered, budget=budget(),
            expected_source_sha256=ENGINE_SHA256)
    except ref.VerificationError as error:
        report['result_mutations'].append(dict(id=name, rejected=str(error)))
    else:
        raise SuiteFailure('result mutation not rejected: '+name)


def run_result_mutations(retained, report):
    case, reference, result = retained['D01-P1']
    tests = [
        ('wrong-C-witness', lambda r: r['witnesses'][0][3].__setitem__('theta', [[28,1]])),
        ('wrong-B-witness', lambda r: r['witnesses'][0][3].__setitem__('theta', [[28,2]])),
        ('wrong-core-alpha', lambda r: r['pieces'][0]['core']['witnesses'][0].__setitem__(0, [1])),
        ('omitted-cut', lambda r: r['pieces'][0]['forbidden'].pop(0)),
        ('missing-piece', lambda r: r['pieces'].clear()),
        ('duplicate-piece', lambda r: r['pieces'].append(copy.deepcopy(r['pieces'][0]))),
        ('wrong-beta', lambda r: r['pieces'][0].__setitem__('beta', [])),
        ('missing-provenance', lambda r: r['provenance'][0][3].clear()),
        ('wrong-mask', lambda r: r['masks'][0].remove(3)),
        ('wrong-source-identity', lambda r: r.__setitem__('source_sha256', '0'*64)),
        ('wrong-advertised-joint-set', lambda r: r.__setitem__('joints', [])),
        ('INCOMPLETE-with-partial-claims', lambda r: r.__setitem__('status', 'INCOMPLETE')),
    ]
    for name, modify in tests:
        reject_mutation(name, case, reference, result, modify, report)
    def false_empty(r):
        r.update(status='EMPTY', masks=[[] for _ in r['masks']],
                 witnesses=[{} for _ in r['witnesses']],
                 provenance=[{} for _ in r['provenance']], pieces=[], feasibility_witness=None)
    reject_mutation('false-EMPTY', case, reference, result, false_empty, report)
    case, reference, result = retained['D05-P1']
    reject_mutation('nonminimum-canceling-original-lift', case, reference, result,
        lambda r: r['pieces'][0]['feasibility_witness'].__setitem__(
            'theta', [[1,13],[7,13],[28,13]]), report)
    case, reference, result = retained['D02-P2']
    # Fixed source publishes raw observations. Weaken ONLY that base and repair
    # its generic identity so a stale hash cannot mask the intended failed
    # reverse inclusion. Generic transcript evidence is not trusted by v3.
    def weaken_base(r):
        piece = r['pieces'][0]
        piece['base'] = []
        scalars = [[independent_features(c)[j] % 13 for j in piece['support']]
                   for c in case['contexts']]
        piece['core']['instance_sha256'] = hashlib.sha256(json.dumps([
            'affine-filter-1', 13, len(piece['support']), [], piece['forbidden'], scalars
        ], separators=(',', ':')).encode()).hexdigest()
    reject_mutation('weakened-producer-base-extra-points', case, reference, result, weaken_base, report)
    case, reference, result = retained['D01-P1']
    changed_expected = copy.deepcopy(reference)
    changed_expected['joints'].clear()
    try:
        ref.verify_result_v3(**plain_case(case), result=result, budget=budget(),
            expected=changed_expected, expected_source_sha256=ENGINE_SHA256)
    except ref.VerificationError as error:
        report['result_mutations'].append(dict(id='false-reference-joint-memo', rejected=str(error)))
    else:
        raise SuiteFailure('wrong joint memo was trusted')


class IntSubclass(int):
    pass


def malformed_values():
    return {
        'true': True, 'false': False, 'negative-int': -1, 'zero-float': 0.0,
        'integral-float': 1.0, 'fractional-float': 0.5, 'negative-float': -1.0,
        'nan': float('nan'), 'positive-infinity': float('inf'),
        'negative-infinity': -float('inf'), 'string': '1', 'none': None,
        'list': [], 'tuple': (), 'dict': {}, 'object': object(),
        'decimal': Decimal(1), 'decimal-nan': Decimal('NaN'),
        'fraction': Fraction(1, 1), 'int-subclass': IntSubclass(1),
    }


def run_malformed_caps(fixtures, retained, report):
    case, reference, result = retained['D01-P1']
    empty_case, _, empty_result = retained['D00-P1']
    incomplete = copy.deepcopy(result)
    incomplete.update(status='INCOMPLETE', masks=None, witnesses=None,
                      provenance=None, pieces=None, feasibility_witness=None)
    paths = {
        'build': lambda cap: ref.build_reference_v3(**plain_case(case), budget=cap),
        'verify': lambda cap: ref.verify_result_v3(**plain_case(case), result=result,
            budget=cap, expected_source_sha256=ENGINE_SHA256),
        'verify-expected': lambda cap: ref.verify_result_v3(**plain_case(case), result=result,
            budget=cap, expected=reference, expected_source_sha256=ENGINE_SHA256),
        'verify-EMPTY': lambda cap: ref.verify_result_v3(**plain_case(empty_case), result=empty_result,
            budget=cap, expected_source_sha256=ENGINE_SHA256),
        'verify-INCOMPLETE': lambda cap: ref.verify_result_v3(**plain_case(case), result=incomplete,
            budget=cap, expected_source_sha256=ENGINE_SHA256),
    }
    check(list(paths) == fixtures['resource_test_paths'], 'resource path inventory')
    values = malformed_values()
    for field in fixtures['integer_cap_fields']+['max_seconds']:
        labels = fixtures['wall_bad_labels'] if field == 'max_seconds' else fixtures['integer_bad_labels']
        for label in labels:
            for name, call in paths.items():
                # The exact Budget class must be revalidated at EVERY API entry,
                # not only at construction. Deliberately mutate a local frozen
                # instance so any constructor validation cannot mask a bypass.
                cap = budget()
                object.__setattr__(cap, field, values[label])
                try:
                    call(cap)
                except ref.VerificationError as error:
                    report['malformed_caps'].append(dict(field=field, value=label,
                                                        path=name, rejected=str(error)))
                else:
                    raise SuiteFailure('malformed cap accepted: '+field+'/'+label+'/'+name)
    check(len(report['malformed_caps']) == 850, 'malformed cap request count')


def binding_for(case):
    return dict(role='literal-observation', support=list(range(case['n'])),
                fixture=case['id'], field=13, n=case['n'], reference_version=ref.VERSION)


def ambient_points(rows, n):
    return {point for point in product(range(13), repeat=n)
            if all(sum(a*x for a, x in zip(row[:-1], point)) % 13 == row[-1]
                   for row in rows)}


def reconstructed_points(space, n):
    if not space['consistent']:
        return set()
    return {tuple((space['point'][j] + sum(t*v[j] for t, v in zip(values, space['basis']))) % 13
                  for j in range(n))
            for values in product(range(13), repeat=len(space['basis']))}


def run_affine(fixtures, report):
    stored = {}
    for case in fixtures['affine_cases']:
        meter = ref.Meter(budget())
        binding = binding_for(case)
        certificate = ref.certify_affine(case['rows'], case['n'], meter=meter, binding=binding)
        checked = ref.replay_certificate(case['rows'], case['n'], certificate,
                                        meter=meter, binding=binding)
        expected = ambient_points(case['rows'], case['n'])
        got = reconstructed_points(checked, case['n'])
        check(got == expected, case['id']+': certified fiber differs from ambient truth')
        for key in ('consistent', 'rank', 'rank_aug', 'dimension'):
            check(checked[key] == case[key], case['id']+': incorrect '+key)
        json_certificate = json.loads(json.dumps(certificate))
        roundtrip = ref.replay_certificate(case['rows'], case['n'], json_certificate,
                                          meter=meter, binding=binding)
        check(roundtrip == checked, case['id']+': JSON certificate semantics changed')
        report['affine'].append(dict(id=case['id'], points=len(expected),
            rank=checked['rank'], rank_aug=checked['rank_aug'],
            dimension=checked['dimension'], resources=meter.receipt()))
        stored[case['id']] = (case, certificate)
    for case in fixtures['base_cases']:
        meter = ref.Meter(budget())
        actual = ref.equivalent_bases(case['left'], case['right'], case['n'], meter=meter)
        oracle = ambient_points(case['left'], case['n']) == ambient_points(case['right'], case['n'])
        check(type(actual) is bool and actual == case['equivalent'] == oracle,
              case['id']+': base equivalence')
        if case['id'] == 'B12':
            # Explicit helper-only obligation: the twelve cuts compensate as
            # sets, but cannot rescue failure of the unfiltered base contract.
            p = ambient_points(case['right'], case['n'])
            filtered = {point for point in p if all(not all(
                sum(a*x for a, x in zip(row[:-1], point)) % 13 == row[-1]
                for row in cut) for cut in case['compensating_cuts'])}
            check(filtered == ambient_points(case['left'], case['n']) and not actual,
                  'B12 must exercise base inequality despite compensated final set')
        report['base_equivalence'].append(dict(id=case['id'], equivalent=actual,
                                              resources=meter.receipt()))
    for mutation in fixtures['certificate_mutations']:
        case, original = stored[mutation['case']]
        altered = copy.deepcopy(original)
        kind = mutation['kind']
        if kind == 'append-operation':
            altered['operations'].append(mutation['value'])
        elif kind == 'remove-operation':
            check(altered['operations'][mutation['index']] == mutation['expected'],
                  mutation['id']+': frozen non-no-op target changed')
            del altered['operations'][mutation['index']]
        elif kind == 'set-rref':
            altered['rref'][mutation['row']][mutation['column']] = mutation['value']
        elif kind == 'wrong-equation-identity':
            altered['equations_sha256'] = '0'*64
        elif kind == 'wrong-support-binding':
            check(altered['binding']['support'] == [0], 'frozen binding mutation target')
            altered['binding']['support'] = [1]
        elif kind == 'set-field':
            altered[mutation['key']] = mutation['value']
        elif kind == 'drop-last-kernel-vector':
            check(len(altered['basis']) == 2, 'frozen omitted-kernel target')
            altered['basis'].pop()
        elif kind == 'duplicate-kernel-vector':
            check(len(altered['basis']) == 2 and altered['basis'][0] != altered['basis'][1],
                  'frozen dependent-kernel target')
            altered['basis'][1] = list(altered['basis'][0])
        else:
            raise SuiteFailure('unrecognized frozen certificate mutation')
        try:
            ref.replay_certificate(case['rows'], case['n'], altered,
                                   meter=ref.Meter(budget()), binding=binding_for(case))
        except ref.VerificationError as error:
            report['certificate_mutations'].append(dict(id=mutation['id'], rejected=str(error)))
        else:
            raise SuiteFailure('certificate mutation accepted: '+mutation['id'])


def run_descriptor_boundaries(carry, report):
    meter = ref.Meter(budget())
    for alpha, beta in sorted(carry):
        check(not ref.residual(alpha, beta, meter=meter), 'C descriptor accepted')
    costs = {}
    for x, y in product(range(26), repeat=2):
        vector = [0]*31
        vector[1], vector[7] = x, y
        desc = independent_descriptor(vector)
        count = int(x != 0)+int(y != 0)
        costs[desc] = min(costs.get(desc, 3), count)
    check(len(costs) == 338, 'alias pair canonical descriptor count')
    for (alpha, beta), cost in sorted(costs.items()):
        check(ref.minimum_support(alpha, beta, meter=meter) == cost,
              'minimum-support formula differs from exhaustive676 pair lifts')
    for x in range(26):
        check(13*(x*x-x) % 26 == 0, 'square/lag13 alias')
    report['descriptor_boundaries'] = dict(carry_descriptors=len(carry), alias_pair_lifts=676,
        alias_pair_descriptors=len(costs), symbol_alias_checks=26, resources=meter.receipt())


def no_partial(result, expected_status):
    check(result['status'] == expected_status, 'wrong capped status')
    for name in ('masks', 'pieces', 'piece_masks', 'provenance', 'joints', 'lifts',
                 'witnesses', 'feasibility_witness'):
        check(name in result and result[name] is None, 'cap leaked semantic field '+name)


def run_counter_boundaries(fixtures, retained, report):
    # Actual D03-P2 verification has positive work in every counter: rank-one
    # observation and producer bases, nonempty points/lifts/outputs/witnesses.
    # Its literal row[2,1,0] requires scale7; rank alone would not ensure a row op.
    case, _, result = retained['D03-P2']
    for field in fixtures['integer_cap_fields']:
        name = field[4:]
        zero = ref.verify_result_v3(**plain_case(case), result=result,
            budget=budget(**{field: 0}), expected_source_sha256=ENGINE_SHA256)
        no_partial(zero, 'VERIFICATION_INCOMPLETE')
        check(zero['resources'][name] == 0, field+': charged beyond zero cap')
        report['counter_boundaries'].append(dict(field=field, slot='zero-functional',
            status=zero['status'], resources=zero['resources']))

        exact = ref.Meter(budget(**{field: 2}))
        exact.charge(name, 2)
        check(exact.counts[name] == 2, field+': exact debit boundary')
        report['counter_boundaries'].append(dict(field=field, slot='exact-primitive',
            resources=exact.receipt()))

        below = ref.Meter(budget(**{field: 1}))
        try:
            below.charge(name, 2)
        except ref.ReferenceLimit:
            check(below.counts[name] == 0, field+': rejected debit was charged')
        else:
            raise SuiteFailure(field+': one-below boundary accepted')
        report['counter_boundaries'].append(dict(field=field, slot='one-below-primitive',
            resources=below.receipt()))

        if name == 'fiber_points':
            # D03-P1 has three eligible beta groups over F13^2. The first fiber
            # alone consumes169 visits; the second must exhaust the cumulative
            # cap, even after partial values have been internally accumulated.
            second_case, _, second_result = retained['D03-P1']
            partial = ref.verify_result_v3(**plain_case(second_case), result=second_result,
                budget=budget(max_fiber_points=169), expected_source_sha256=ENGINE_SHA256)
            no_partial(partial, 'VERIFICATION_INCOMPLETE')
            check(partial['resources']['fiber_points'] == 169,
                  'actual support/beta traversal reset the fiber counter')
            receipt = partial['resources']
            detail = 'actual second beta preflight rejects after169 visited points'
        else:
            cumulative = ref.Meter(budget(**{field: 1}))
            cumulative.charge(name, 1)
            try:
                cumulative.charge(name, 1)
            except ref.ReferenceLimit:
                check(cumulative.counts[name] == 1, field+': cumulative debit altered prior count')
            else:
                raise SuiteFailure(field+': cumulative counter reset')
            receipt = cumulative.receipt()
            detail = 'same-meter two successive one-unit debit blocks'
        report['counter_boundaries'].append(dict(field=field, slot='cumulative',
                                               detail=detail, resources=receipt))
    check(len(report['counter_boundaries']) == 32, 'counter slot count')


EXPECTED_OBLIGATIONS = {
    'affine_cases': 16,
    'affine_json_roundtrips': 16,
    'base_equivalence_cases': 13,
    'certificate_mutations': 16,
    'residual_cases': 40,
    'raw_complete_relation_comparisons': 42,
    'relation_boundary_controls': 2,
    'carry_descriptors': 156,
    'alias_pair_lifts': 676,
    'alias_pair_descriptors': 338,
    'symbol_alias_checks': 26,
    'result_mutations': 16,
    'malformed_cap_requests': 850,
    'counter_boundary_slots': 32,
}


def completed_obligations(report):
    desc = report.get('descriptor_boundaries', {})
    return dict(affine_cases=len(report['affine']),
        affine_json_roundtrips=len(report['affine']),
        base_equivalence_cases=len(report['base_equivalence']),
        certificate_mutations=len(report['certificate_mutations']),
        residual_cases=len(report['relations']),
        raw_complete_relation_comparisons=len(report['relations'])+len(report['relation_boundaries']),
        relation_boundary_controls=len(report['relation_boundaries']),
        carry_descriptors=desc.get('carry_descriptors', 0),
        alias_pair_lifts=desc.get('alias_pair_lifts', 0),
        alias_pair_descriptors=desc.get('alias_pair_descriptors', 0),
        symbol_alias_checks=desc.get('symbol_alias_checks', 0),
        result_mutations=len(report['result_mutations']),
        malformed_cap_requests=len(report['malformed_caps']),
        counter_boundary_slots=len(report['counter_boundaries']))


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_frozen_inventory():
    check(FREEZE_PATH.is_file() and not FREEZE_PATH.is_symlink(), 'missing regular stage freeze')
    check(FREEZE_PATH.stat().st_size <= 1024*1024, 'stage freeze too large')
    freeze_hash = file_sha256(FREEZE_PATH)
    freeze = json.loads(FREEZE_PATH.read_text())
    check(freeze.get('version') == 'reference-v3-stage-v1', 'stage freeze version')
    files = freeze.get('files')
    check(type(files) is dict and 1 <= len(files) <= 128, 'frozen inventory shape')
    actual = {}
    for name, expected in files.items():
        candidate = Path(name)
        check(candidate.is_absolute() and candidate.is_file() and not candidate.is_symlink(),
              'nonregular frozen input '+name)
        check(type(expected) is str and len(expected) == 64, 'frozen digest shape')
        actual[name] = file_sha256(candidate)
        check(actual[name] == expected, 'frozen source mismatch: '+name)
    for name in ('suite.py', 'fixtures.json', 'reference_v3.py', 'CAPS.json', 'CONTRACT.md',
                 'TEST-PLAN.md'):
        check(str(HERE/name) in actual, 'suite artifact not frozen: '+name)
    engine_path = str(ENGINE_DIRECTORY/'residual_decoder.py')
    check(actual.get(engine_path) == ENGINE_SHA256, 'fixed engine not frozen')
    check(DEPENDENCY_SHA256 in actual.values(), 'fixed affine dependency not frozen')
    check(file_sha256(FREEZE_PATH) == freeze_hash, 'freeze changed while reading')
    return freeze_hash, actual


def atomic_report(output, report):
    check(output.is_absolute() and output.parent.is_dir(), 'output path must have existing parent')
    check(not output.exists() and not output.is_symlink(), 'output must be new')
    data = (json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()
    check(len(data) <= 2*1024*1024, 'report exceeds frozen2MiB limit')
    temporary = output.with_name(output.name+'.tmp')
    with temporary.open('xb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    # A hard-link publish is atomic and refuses to overwrite an existing result.
    # Both names are in the same fixed directory/filesystem.
    os.link(temporary, output)
    temporary.unlink()
    directory_fd = os.open(str(output.parent), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def main():
    global ref
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    start_wall = time.monotonic()
    start_cpu = time.process_time()
    report = dict(schema='reference-v3-suite-report-v1', suite_role='author',
        suite_version=SUITE_VERSION, status='FAIL', python_optimized=bool(sys.flags.optimize),
        classification='post-failure disclosed development only',
        stage_freeze_sha256=None, source_sha256={}, obligations={},
        affine=[], base_equivalence=[], certificate_mutations=[], relations=[],
        relation_boundaries=[], result_mutations=[], malformed_caps=[], counter_boundaries=[])
    code = 1
    try:
        freeze_hash, inventory = read_frozen_inventory()
        report.update(stage_freeze_sha256=freeze_hash, source_sha256=inventory)
        import reference_v3 as ref
        check(Path(ref.__file__).resolve() == HERE/'reference_v3.py',
              'unexpected reference module path')
        fixtures = json.loads((HERE/'fixtures.json').read_text())
        caps = json.loads((HERE/'CAPS.json').read_text())
        check(caps['ordinary'] == ORDINARY_CAPS, 'suite/module contract cap mismatch')
        check(fixtures['seed'] is None, 'no seed allowed')
        sys.path.insert(0, str(ENGINE_DIRECTORY))
        import residual_decoder as engine
        check(Path(engine.__file__).resolve() == ENGINE_DIRECTORY/'residual_decoder.py',
              'unexpected engine module path')
        run_affine(fixtures, report)
        retained, carry = run_relations(fixtures, engine, report)
        run_descriptor_boundaries(carry, report)
        run_result_mutations(retained, report)
        run_malformed_caps(fixtures, retained, report)
        run_counter_boundaries(fixtures, retained, report)
        report['obligations'] = completed_obligations(report)
        check(report['obligations'] == EXPECTED_OBLIGATIONS, 'incomplete finite obligation inventory')
        final_hash, final_inventory = read_frozen_inventory()
        check(final_hash == freeze_hash and final_inventory == inventory, 'frozen input changed during suite')
        report['status'] = 'PASS'
        code = 0
    except Exception as error:
        report['error'] = dict(type=type(error).__name__, message=str(error)[:2000])
        report['obligations'] = completed_obligations(report)
        traceback.print_exc(file=sys.stderr)
    usage = resource.getrusage(resource.RUSAGE_SELF)
    report['diagnostics'] = dict(script_wall_seconds=time.monotonic()-start_wall,
        script_cpu_seconds=time.process_time()-start_cpu,
        process_user_cpu_seconds=usage.ru_utime, process_system_cpu_seconds=usage.ru_stime,
        peak_rss_kib=usage.ru_maxrss,
        accounting='diagnostic subset only; supervisor owns inclusive receipts; never add twice')
    atomic_report(Path(args.output), report)
    print(json.dumps(dict(status=report['status'], output=args.output,
                         obligations=report['obligations']), sort_keys=True))
    return code


if __name__ == '__main__':
    sys.exit(main())
