# Next recommendation: two disclosed full-31 controls and certified workload preflight

**DESIGN ONLY — no implementation, trace expansion, fixture draw, import, solver
or test has been performed for this proposal.** Current v3 PASS, its sources,
fixtures, receipts and predecessors remain immutable. This is a bounded local
resource/verification pilot, not a new hypothesis, holdout, performance campaign
or target admission. Separate reviewed authorization is required.

## Fixed mathematical controls

Both controls use all original feature indices 0..30, sparsity 3, the unchanged
31/25 canonical dictionary and R = E minus (B union exact156 C). All equality
tests are on unreduced Z26 symbols. No pruning, saturation, support/beta merging,
cache, alternate predicate or solver-engine change is proposed.

**A — deliberately excessive rank-zero traversal.** One public context is
`[0,0,0,0,0,0]`; there are no observations. The proposed point allowance is
1,000,000, so the complete preflight must return a resource-gate rejection.
This must not be labeled EMPTY: for example, 13 E12 is a residual function.

There are C(31,3)=4,495 original support containers. Six canonical groups have
two original members; the other 19 have one. Exactly 6*29=174 containers contain
a duplicate group and have two groups; the other 4,321 have three. Thus

    sum_T 2^|G(T)| = 4,321*8 + 174*4 = 35,264.
    sum_T 2^|G(T) intersect {0,1}|
        = 4,495 + 435 + 841 + 57 = 5,828.
    W_A = (35,264 - 5,828) * 13^3 = 64,670,892.

The latter four terms count all T, T containing constant, T meeting the lag1/
square1 group, and T meeting both. This is the exact observation-point count
of the **fixed reference traversal**, including points later rejected by R;
it is not an intrinsic lower bound for other algorithms.

**B — fixed, realizable contiguous public input stream.** Define 97 symbols,
without RNG or seed, by c_0=3 and, for integer t=1..96,

    c_t = c_(t-1)                         if t mod 7 = 0,
          (7t^3 + 11t^2 + 5t + 3) mod26  otherwise.

For t=6..96 define context L(t)=(c_(t-1),...,c_(t-6)), giving 91 overlapping
contexts. Define public outputs, separately from the input stream, by

    y_t = (3 L2(t) + 5 [L1(t)=L2(t)] + 7 [L3(t)=L4(t)]) mod26.

Observe exactly t in {21,...,33} union {63,...,73}, 24 positions, using row
index t-6. The same formula publicly defines every output: unobserved rows are
not secret or held out. In particular, c_t itself is NOT the observed y_t.
The fixed original support {2,28,29}, coefficients {3,5,7}, is a minimum-size
3 residual witness, with beta groups {2,22,23}; therefore a completed correct
semantic verification must be EXACT, not EMPTY. No uniqueness, rank, workload,
mask-size or runtime prediction is asserted. Do not replace this stream if its
workload is unfavorable. Literal expansion and byte freezing would happen only
after the separate implementation/development authorization.

## Certified preflight theorem and boundary

For each original size-3 support T, reconstruct the raw F13 observation system
A_T alpha=b. Let chi_T indicate consistency and r_T=rank(A_T), certified by full
augmented RREF and replayable invertible row operations. Let K_T count **every**
beta supported on covered groups G(T) whose F2 predictions match all observed
values and whose support is not contained in {0,1}. Then

    W = sum_T chi_T * K_T * 13^(3-r_T).

Proof: each consistent observation system has exactly 13^(3-r_T) points;
parity compatibility is independent of alpha, and the fixed traversal visits
that entire affine fiber once for each of its K_T beta assignments. Inconsistent
systems contribute zero. No E/C cut or representation count is subtracted.

A standalone preflight must certify all 4,495 original T separately, rebuild
their matrices from the public input, replay each generated certificate, and
enumerate the complete covered-beta domain (35,264 candidates overall). A second
replay of serialized certificates checks binding, rank and consistency; exact
beta lists/counts are independently recomputed, never trusted. Keep identity by
original support/input/field, even for equal matrices. No cross-run trusted memo
or semantic-solver cache is introduced. Work and certificates are charged.

The preflight reports W only after its complete inventory is checked. It emits
no masks, joints, semantic EMPTY/EXACT, or claim about producer correctness.
W=0 is still only a workload fact at this API boundary. For valid completed
v3 verification, its fiber_points receipt must equal W; malformed producers may
be rejected earlier. A bound or prefix after exhaustion is never called exact W.

If W exceeds the fixed point allowance, do not launch producer/semantic checking
for that control. Otherwise a bounded attempt is permitted, not promised to
finish: lift/solve/work/storage/time caps remain separate. For B, a successful
producer result must still undergo the unchanged **full independent v3 verifier**,
including mutual base inclusion, pointwise direct-R/cut comparison, complete
piece inventory, all lifts/joints/masks/witnesses/provenance. Preflight cannot
replace any of these checks or certify an unverified producer result.

## Proposed finite caps — not an allocation or launch approval

Per control's preflight, propose these cumulative ceilings:

| Bucket | Ceiling |
|---|---:|
| Original supports / covered-beta candidates |4,495 /35,264|
| Parity row tests (at most24 rows per candidate) |846,336|
| F13 solves / certificate replays |4,495 /8,990|
| Generated plus replayed row operations |1,500,000|
| Explicit logical work / retained records |50,000,000 /2,000,000|
| Fiber points / lift trials / sparse witness checks |0 /0 /0|
| Wall seconds |20|

The operation ceiling covers at most100 operations per 24-row augmented solve,
generation plus two replays: 4,495*100*3=1,348,500. Exact new support/beta/parity
charge sites, serialization schema and byte accounting need their own pre-run
freeze; they are not silently assigned old units.

If admitted, producer caps are explicitly proposed as steps2,000,000;
pieces40,000; core work200,000,000; core solves1,000,000; core terms100,000;
wall30 seconds. Its algorithm and source stay fixed. Full-verifier caps retain
the current ordinary units and values: fiber points1,000,000; lift trials
4,000,000; solves100,000; certificate checks200,000; row operations5,000,000;
work500,000,000; witness checks1,000,000; records5,000,000; wall45 seconds.

Propose at most four one-use worker slots (author and independent review, normal
and -O), each nominal CPU60/75 seconds, wall150 seconds, address space1 GiB;
exclusive supervisors each nominal CPU4/5 seconds and256 MiB. This requests a
separate **320-second** allocation/reservation (300 worker +20 supervisor), not
reuse or replenishment from any previous allocation or the unspent contingency.
Final partition, exact commands, metering, fixtures, mutations, output identity,
watchdogs and independent pre-run approval must be frozen before execution.

Per artifact cap32 MiB, summary cap2 MiB; certificates and cap-hit diagnostics
are retained, not erased. Expected A resource-gate rejection allows the fixed B
preflight to proceed. If B is gated out, or any preflight computation/producer/
verifier hits a cap or fails, retain the result and stop dependent semantic runs;
there is no redraw, retry, mode bypass, automatic cap increase or favorable-case
substitution. B gated out means no end-to-end B claim. Additional checks of a
retained artifact need explicit inclusion in the frozen schedule, not spare CPU.

Keep worker-inclusive CPU, supervisor-exclusive samples, full supervisor policy
charges and outstanding reservations separate. Retain wall/CPU/RSS, kills and
partials. Nominal OS limits are not guaranteed measured maxima; any observed
overshoot stops dependent execution. Preparation/control and final-write tails
must remain disclosed, not relabeled as measured zero.

The earlier failed cohort remains permanently INCOMPLETE and is not a fixture.
Matbalez historical scope remains unresolved. No target or holdout is involved.
