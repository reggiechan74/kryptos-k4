"""Second independent full-relation audit; fresh disclosed finite toys only."""
import copy, hashlib, itertools as it, json, math, random, resource, sys, time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
sys.dont_write_bytecode=True
sys.path.insert(0,'/ARCHIVE_WORKSPACE/canonical-residual-dev');import residual_decoder as d
sys.path.insert(0,'/ARCHIVE_WORKSPACE/canonical-residual-reference');import reference as r
START=time.process_time();PIN='be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67'
counts={'cases':0,'raw_vectors':0,'alpha_ambient_points':0,'sparse_witness_checks':0,'core_witness_checks':0,'C_laws':0,'hidden_C_aliases':0,'invalid_requests':0,'cap_checks':0,'mutations_rejected':0,'joint_checks':0}
def ck(x,m):
    if not x:raise RuntimeError(m)
def phi(x):
    vals=[1,*x]
    for t in x:vals.append(t*t%26)
    for a in range(6):
        for b in range(a+1,6):vals.append(x[a]*x[b]%26)
    for a,b in [(0,1),(2,3),(4,5)]:vals.append(1 if x[a]==x[b] else 0)
    return vals
def desc(v):
    return tuple(x%13 for x in v),tuple([v[0]%2]+[(v[j]+v[j+6])%2 for j in range(1,7)]+[v[j]%2 for j in range(13,31)])
C=set()
for eq,b,sgn in it.product((28,29,30),range(26),(1,25)):
    v=[0]*31;v[0]=b;v[eq]=sgn;C.add(desc(v))
ck(len(C)==156,'C cardinality')
def keep(v,key):
    return any(v[j] for j in (28,29,30)) and any(key[1][2:]) and key not in C

def raw(ctx,obs,s,allowed):
    rows=[phi(x) for x in ctx];containers=list(it.combinations(allowed,min(s,len(allowed))))
    pieces={};lifts={};joints=set();masks=[set() for _ in ctx];v=[0]*31;total=0
    for size in range(min(s,len(allowed))+1):
        for support in it.combinations(allowed,size):
            containing=[T for T in containers if set(support)<=set(T)]
            total+=25**size
            ck(total<=500000,'fresh raw per-case point cap')
            for values in it.product(range(1,26),repeat=size):
                for j,x in zip(support,values):v[j]=x
                key=desc(v)
                if keep(v,key):
                    prediction=tuple(sum(row[j]*x for j,x in zip(support,values))%26 for row in rows)
                    if all(prediction[i]==z for i,z in obs.items()):
                        lifts.setdefault(key,set()).add(tuple(v));joints.add(prediction)
                        bits=tuple(i for i,x in enumerate(key[1]) if x)
                        for T in containing:pieces.setdefault((T,bits),set()).add(tuple(key[0][j] for j in T))
                        for i,z in enumerate(prediction):masks[i].add(z)
                for j in support:v[j]=0
    return {'status':'EXACT' if lifts else 'EMPTY','lifts':lifts,'joints':joints,'masks':masks,'pieces':pieces,'raw_points':total}

summary=[]
def case(name,ctx,obs,s,allowed):
    expected=raw(ctx,obs,s,allowed);ref=r.oracle(ctx,obs,s,allowed,max_points=500000)
    for key in ('status','lifts','joints','masks','pieces'):ck(expected[key]==ref[key],name+': independent reference '+key)
    result=d.decode(ctx,obs,s,allowed,budget=d.Budget(max_seconds=30))
    ck(result['status']==expected['status'],name+': decoder status');ck([set(v) for v in result['masks']]==expected['masks'],name+': masks')
    receipt=r.verify_result(ctx,obs,result,s,allowed,expected=ref,max_points=500000,expected_source_sha256=PIN)
    counts['cases']+=1;counts['raw_vectors']+=expected['raw_points'];counts['alpha_ambient_points']+=receipt['ambient_points_checked'];counts['sparse_witness_checks']+=receipt['sparse_witnesses_checked'];counts['core_witness_checks']+=receipt['alpha_witnesses_checked']
    # Independent full alpha fiber equality, not mere witness existence.
    actual={}
    for p in result['pieces']:
        n=len(p['support']);pts=set()
        for a in it.product(range(13),repeat=n):
            sat=lambda eqs:all(sum(row[i]*a[i] for i in range(n))%13==row[-1] for row in eqs)
            if sat(p['base']) and all(not sat(w) for w in p['forbidden']):pts.add(a)
        actual[(tuple(p['support']),tuple(p['beta']))]=pts
        ck(len(p['forbidden'])<=2,'cut bound');ck(p['core']['route']=='small-union','unexpected route')
    ck(actual==expected['pieces'],name+': exact complete fibers')
    summary.append({'name':name,'status':result['status'],'functions':len(expected['lifts']),'joint_predictions':len(expected['joints']),'pieces':len(actual),'raw_vectors':expected['raw_points']})
    return result,ref

ctx=[[0,0,1,2,3,4],[0,13,1,2,3,4],[1,1,2,2,3,3],[1,2,3,4,5,6],[13,0,25,25,0,13]]
case('empty-domain',ctx,{},3,[]);case('zero-sparsity',ctx,{},0,[0,28]);case('no-context-no-domain',[],{},0,[])
case('full31-one-sparse',ctx,{},1,list(range(31)))
case('full31-two-sparse-no-output',[],{},2,list(range(31)))
for eq in (28,29,30):
    case('only-equality-'+str(eq),ctx,{},1,[eq])
    for j in range(28):case('pair-%d-%d'%(j,eq),ctx,{},2,[j,eq])
    for j in range(1,7):case('alias-%d-%d'%(j,eq),ctx,{},3,[j,j+6,eq])
for allowed in ([0,28,29],[0,29,30],[28,29,30],[13,28,30],[2,7,29]):
    case('three-'+str(allowed),ctx,{},3,allowed)
case('nonmaximal-representation-overlap',ctx,{},2,[0,1,7,28])
case('duplicate-context-conflict',[ctx[0],ctx[0]],{0:0,1:1},2,[0,28])
case('residue-equality-trap',[ctx[0],ctx[1]],{0:13,1:0},1,[28])
case('inconsistent-C-observations',[ctx[0],ctx[1]],{0:1,1:0},1,[28])
case('shared-old-new-finite-trace',[ctx[1]],{0:0},2,[0,28])
case('all-beta-fibers-same-finite-trace',[ctx[1]],{0:0},2,[28,29])
case('zero-equality-in-nonlinear-support',ctx,{i:x[1] for i,x in enumerate(ctx)},2,[2,28])
case('joint-not-Cartesian',[ctx[0],ctx[0]],{},1,[28])
rng=random.Random(202610312001)
for i in range(12):
    allowed=sorted(rng.sample([0,1,2,7,8,13,28,29,30],3));s=2 if i%2 else 3
    contexts=[[rng.randrange(26) for _ in range(6)] for _ in range(3)]
    contexts[0][1]=contexts[0][0]
    observed={0:rng.randrange(26)} if i%3 else {}
    case('fresh-seeded-'+str(i),contexts,observed,s,allowed)
# Independently exercise every sign and constant, plus global C hidden by alias pairs.
for eq,b,sgn in it.product((28,29,30),range(26),(1,25)):
    v=[0]*31;v[0]=b;v[eq]=sgn
    ck(not d.residual(*d.descriptor(v)) and not r.residual(*r.descriptor(v)),'C classification');counts['C_laws']+=1
    equal=[0]*6;unequal=[0,13,0,13,0,13]
    z=d.decode([equal,unequal],{0:(b+sgn)%26,1:b},2,[0,eq])
    ck(z['status']=='EMPTY','C exact exclusion')
for j,eq,sgn in it.product(range(1,7),(28,29,30),(1,25)):
    v=[0]*31;v[j]=v[j+6]=13;v[eq]=sgn;key=desc(v)
    ck(key in C and not d.residual(*d.descriptor(v)),'hidden global C alias')
    support=(j,j+6,eq);beta=(eq-6,);cuts=d.compile_exclusions(support,beta);alpha=[0,0,sgn%13]
    ck(any(all(sum(row[k]*alpha[k] for k in range(3))%13==row[-1] for row in w) for w in cuts),'hidden C compiler')
    counts['hidden_C_aliases']+=1
# Strict malformed requests and cumulative cap boundaries.
valid={'contexts':ctx,'observed':{},'sparsity':2,'allowed_features':[0,28]}
bad=[{'contexts':None},{'contexts':[[0]*5]},{'contexts':[[False]*6]},{'contexts':[[26]*6]},{'contexts':[[0]*6]*129},{'observed':{'0':0}},{'observed':{True:0}},{'observed':{-1:0}},{'observed':{0:True}},{'observed':{0:26}},{'sparsity':True},{'sparsity':4},{'sparsity':-1},{'allowed_features':[28,0]},{'allowed_features':[0,0]},{'allowed_features':[31]},{'allowed_features':[False]},{'allowed_features':{28}},{'budget':None},{'budget':d.Budget(max_seconds=float('nan'))},{'budget':d.Budget(max_seconds=float('inf'))},{'budget':d.Budget(max_seconds=True)},{'budget':d.Budget(max_steps=-1)},{'budget':d.Budget(max_pieces=True)},{'budget':d.Budget(max_core_work=10**12+1)}]
for update in bad:
    try:d.decode(**(valid|update))
    except ValueError:counts['invalid_requests']+=1
    else:raise RuntimeError('malformed accepted '+str(update))
for field,vals in [('max_steps',(0,1,2,5,10,20,100,500)),('max_pieces',(0,1,2,3,4)),('max_core_work',(0,1,100,1000,10000)),('max_core_solves',(0,1,5,10,50)),('max_seconds',(0,)),('max_core_terms',(0,))]:
    for value in vals:
        budget=d.Budget(**{field:value});out=d.decode(**valid,budget=budget)
        if out['status']=='INCOMPLETE':ck(all(out[k] is None for k in ('masks','witnesses','pieces','provenance','feasibility_witness')),'partial budget claim')
        else:r.verify_result(**valid,result=out,expected_source_sha256=PIN)
        ck(out['resources']['steps']<=budget.max_steps and out['resources']['core_work']<=budget.max_core_work and out['resources']['core_solves']<=budget.max_core_solves and out['resources']['core_terms']<=budget.max_core_terms,'cumulative budget excess')
        counts['cap_checks']+=1
# More strict result mutations, including no-output completeness and alias provenance.
no_args=dict(contexts=[],observed={},sparsity=2,allowed_features=[1,7,28]);no=d.decode(**no_args)
for mode in ('drop_piece','drop_feasibility','fake_empty','bad_alpha_bool','bad_beta_bool','nonminimal_theta','extra_provenance','wrong_input','partial_incomplete'):
    args=no_args.copy();z=copy.deepcopy(no)
    if mode=='drop_piece':z['pieces'].pop()
    elif mode=='drop_feasibility':z['feasibility_witness']=None
    elif mode=='fake_empty':z.update(status='EMPTY',pieces=[],feasibility_witness=None)
    elif mode=='bad_alpha_bool':z['pieces'][0]['core']['feasibility_witness'][0]=False
    elif mode=='bad_beta_bool':z['pieces'][0]['beta'][0]=True
    elif mode=='nonminimal_theta':z['pieces'][0]['feasibility_witness']['theta']=[[1,13],[7,13],[28,3]]
    elif mode=='extra_provenance':
        args=dict(contexts=[ctx[0]],observed={},sparsity=1,allowed_features=[28]);z=d.decode(**args);z['provenance'][0][next(iter(z['provenance'][0]))].append('missing')
    elif mode=='wrong_input':args['observed']={};args['allowed_features']=[0,28]
    elif mode=='partial_incomplete':z['status']='INCOMPLETE'
    try:r.verify_result(**args,result=z,expected_source_sha256=PIN)
    except r.VerificationError:counts['mutations_rejected']+=1
    else:raise RuntimeError('result mutation accepted '+mode)
args=dict(contexts=[ctx[0],ctx[0]],observed={},sparsity=1,allowed_features=[28]);out=d.decode(**args);p=out['pieces'][0];alpha=p['core']['feasibility_witness'];theta=d.lift(p['support'],alpha,p['beta']);val=sum(phi(ctx[0])[j]*v for j,v in theta)%26
ck(d.check_joint(args['contexts'],{},out,p['id'],alpha,[val,val])==theta,'valid common joint');counts['joint_checks']+=1
wrong=next(z for z in out['masks'][1] if z!=val)
try:d.check_joint(args['contexts'],{},out,p['id'],alpha,[val,wrong])
except d.af.CertificateError:counts['joint_checks']+=1
else:raise RuntimeError('Cartesian tuple accepted')
print(json.dumps({'status':'PASS','optimized':not __debug__,'engine_sha256':d.SOURCE_SHA256,'reference_sha256':hashlib.sha256(Path(r.__file__).read_bytes()).hexdigest(),'counts':counts,'cases':summary,'cpu_seconds':time.process_time()-START,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limits':{'cpu_seconds':120,'address_space_mib':768},'scope':'fresh disclosed bounded full-relation tests; no target or holdout; producer and reference originals unchanged'},indent=2))
