import json,os,resource,subprocess,sys,time
from pathlib import Path
out=Path(__file__).resolve().parent;v2=Path('/ARCHIVE_WORKSPACE/canonical-residual-reference-v2');env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');receipts=[]
for optimized in (False,True):
 for name,script,args in [('targeted',out/'check_reference_v2.py',[]),('regressions',v2/'test_point_caps.py',[]),('stored',v2/'audit_results.py',['--mode','all']+(['--optimized-results'] if optimized else []))]:
  label='v2-'+name+('-optimized' if optimized else '-normal');cmd=[sys.executable]+(['-O'] if optimized else [])+[str(script)]+args
  before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=150,env=env);after=resource.getrusage(resource.RUSAGE_CHILDREN)
  (out/(label+'.json')).write_text(p.stdout);(out/(label+'.stderr.txt')).write_text(p.stderr)
  if p.returncode:raise RuntimeError(label+': '+p.stderr)
  result=json.loads(p.stdout)
  if result['status']!='PASS':raise RuntimeError(label)
  receipts.append({'id':label,'command':cmd,'exit_code':p.returncode,'child_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'wall_seconds':time.monotonic()-start,'receipt':label+'.json','accounting':'inclusive child CPU; do not add script cpu_seconds again'})
(out/'v2-process-receipts.json').write_text(json.dumps({'status':'PASS','processes':receipts,'total_child_cpu_seconds':sum(x['child_cpu_seconds'] for x in receipts)},indent=2)+'\n');print(json.dumps({'status':'PASS','process_count':len(receipts),'total_child_cpu_seconds':sum(x['child_cpu_seconds'] for x in receipts)},indent=2))
