"""Independent targeted v2 patch audit; no new draw or producer changes."""
import ast, copy, hashlib, importlib.util, json, resource, sys, time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2));sys.dont_write_bytecode=True
START=time.process_time();root=Path('/ARCHIVE_WORKSPACE/canonical-residual-reference-v2');old=Path('/ARCHIVE_WORKSPACE/canonical-residual-reference/reference.py');new=root/'reference.py';pin='618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974'
def ck(v,m):
 if not v:raise RuntimeError(m)
ck(hashlib.sha256(new.read_bytes()).hexdigest()==pin,'v2 pin')
a=ast.parse(old.read_text());b=ast.parse(new.read_text());af={x.name:x for x in a.body if isinstance(x,ast.FunctionDef)};bf={x.name:x for x in b.body if isinstance(x,ast.FunctionDef)}
ck(set(bf)==set(af)|{'_point_cap'},'function inventory')
for name,original in af.items():
 left=copy.deepcopy(original);right=copy.deepcopy(bf[name])
 right.body=[x for x in right.body if not (isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='_point_cap')]
 if name=='oracle':left.body=[x for x in left.body if not (isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='ensure' and len(x.value.args)==2 and isinstance(x.value.args[1],ast.Constant) and x.value.args[1].value=='max_points')]
 ck(ast.dump(left,include_attributes=False)==ast.dump(right,include_attributes=False),'semantic diff outside cap guard '+name)
spec=importlib.util.spec_from_file_location('audited_reference_v2',new);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
sys.path.insert(0,'/ARCHIVE_WORKSPACE/canonical-residual-dev');import residual_decoder as d
args=dict(contexts=[],observed={},sparsity=1,allowed_features=[28]);result=d.decode(**args);memo=r.oracle(**args)
emptyargs=dict(contexts=[],observed={},sparsity=0,allowed_features=[]);empty=d.decode(**emptyargs);emptymemo=r.oracle(**emptyargs)
inc=copy.deepcopy(result);inc.update(status='INCOMPLETE',masks=None,witnesses=None,pieces=None,provenance=None,feasibility_witness=None)
calls=[lambda cap:r.oracle(**args,max_points=cap),lambda cap:r.brute_force(**args,max_points=cap),lambda cap:r.verify_result(**args,result=result,max_points=cap,expected_source_sha256=d.SOURCE_SHA256),lambda cap:r.verify_result(**args,result=result,expected=memo,max_points=cap,expected_source_sha256=d.SOURCE_SHA256),lambda cap:r.verify_result(**emptyargs,result=empty,expected=emptymemo,max_points=cap,expected_source_sha256=d.SOURCE_SHA256),lambda cap:r.verify_result(**args,result=inc,max_points=cap,expected_source_sha256=d.SOURCE_SHA256)]
class IntChild(int):pass
bad=[True,False,-1,0.0,1.0,float('nan'),float('inf'),-float('inf'),'0',None,[],{},(),complex(1),IntChild(1),object()];rejections=0
for call in calls:
 for cap in bad:
  try:call(cap)
  except r.VerificationError as exc:ck(str(exc)=='max_points must be a built-in nonnegative integer','wrong cap failure');rejections+=1
  else:raise RuntimeError('invalid point cap accepted')
zero_limited=0
for call in calls[:4]:
 try:call(0)
 except r.ReferenceLimit:zero_limited+=1
 else:raise RuntimeError('zero positive-work cap bypass')
ck(calls[4](0)['status']=='EMPTY' and calls[5](0)['status']=='INCOMPLETE','valid zero-work path')
ck(calls[0](26)['lifts']==memo['lifts'] and calls[1](26)['lifts']==memo['lifts'],'exact cap equality')
ck(calls[3](13)['status']=='EXACT','exact ambient cap')
try:calls[3](12)
except r.ReferenceLimit:pass
else:raise RuntimeError('ambient cap off by one')
# Validate normal and JSON-serialized complete results under the reviewed source pin.
r.verify_result(**args,result=json.loads(json.dumps(result)),expected=memo,max_points=13,expected_source_sha256=d.SOURCE_SHA256)
print(json.dumps({'status':'PASS','optimized':not __debug__,'reference_sha256':pin,'unchanged_function_bodies_after_guard_removal':len(af),'malformed_cap_rejections':rejections,'positive_work_zero_caps':zero_limited,'zero_work_successes':2,'exact_boundaries':3,'one_below_boundary_rejected':True,'serialized_result_verified':True,'cpu_seconds':time.process_time()-START,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2))
