# Independent full canonical residual implementation review

2026-10-31. **PASS for the bounded development contract using the unchanged engine and independently reviewed reference v2. The original reference-only cap-input defect was repaired separately and revalidated.** No engine source edit is requested. Original sources, fixtures and receipts remain preserved.

This review does not admit K4, authorize a new holdout, establish historical completeness/global novelty, or claim speed superiority. The unresolved matbalez operator scope remains explicit. the private administrative register [reference omitted] was read first. Source/operator conclusions were reused from the pinned independent operator audit; no target matrix, target fit, raw target replay, old holdout or new holdout was accessed or run.

## Reviewed identities

- Engine `canonical-residual-dev/residual_decoder.py`: `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`.
- Vendored generic core: `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`.
- Original reference `canonical-residual-reference/reference.py`: `51228db92f9b1feaab51895e76099c6d755060a2244890ab9806a57051be7b00`.
- Original reference audit driver: `54505169d58ccd5fe6108e90d86fd8880a006c2ea0cffb23f9f66cb9f79c449a`.
- Producer plan: `9d41f4423cdb3e3e9697839b7cacf263c38fd274c55910ea5fcc33f97f9d1da4`.
- Producer fixture generator: `0c85ad85c6f82dd440063862c50f6c426a6c40a2b33da34c478f653f95df1ddf`.
- Producer README: `10b99d8606aa8a085619fbc87b723eb4cb205298635fb0a50bd9eadf095474ac`.

Source-level inspection covered engine, vendored dependency identity, reference, reference self-tests/result audit, producer fixture generation, tests, runner, launcher, plans, reports and receipts. Original source hashes remained unchanged.

## Findings on exact mathematical implementation

### Canonical quotient and original support — PASS

Feature indices, lag/square grouping, pair-product order and equality groups match the unchanged 31-feature definition. Full Z26 equality is evaluated before either reduction; equality of 0 and 13 is correctly false. Mod-2 lag/square parity is merged because x²=x on parity. Mod-13 lag/square coordinates remain distinct.

The global descriptor is not inferred from raw support labels. For each parity group, every nonzero alpha coordinate costs one original coordinate. If none is active, beta=1 costs exactly one extra coefficient13; if any alpha is active, either parity can be assigned to one such coordinate without making it zero. This proves the minimum-support formula and the constructive lift. Square-only containers preserve the witness inside the actual available square coordinate. Alias cancellations such as 13*x+13*x²=0 do not invent global nonlinearity.

Every <=s original vector embeds in a maximal allowed support container; conversely each enumerated alpha/beta combination has a common original lift within that container and <=s coordinates. All covered beta subsets are enumerated. No independent fieldwise-minimum-support shortcut, prediction-based beta merge, or saturation early termination appears. Smaller supports, zero coefficients, duplicate global functions across containers, and nonminimal original representations are correctly represented implicitly.

### Frozen residual and compiler — PASS

The exact residual is R=E minus (B union C), not a data-dependent fitted filter.

- E is nonzero equality dependence in either canonical field descriptor.
- B is beta supported only on constant/lag1, including zero; it is checked for every candidate beta.
- C is exactly all 156 b±E_q functions, q in {E12,E34,E56}, b in Z26. Its descriptor has equality alpha 1 or 12, equality beta 1, unrestricted constant, and all other canonical coordinates zero.

For eligible fixed beta without an equality bit, the one cut is all equality alpha coordinates zero. If beta is supported on constant plus exactly one active equality, the two cuts impose that equality alpha=1 or 12 and every other nonconstant alpha zero. These cases are mutually exclusive, so at most two cuts occur. Coordinates outside the support are already zero; equations for absent equality coordinates correctly become zero equations. Thus the cuts are exact on the whole support fiber, including when observations lower its dimension. They are removed before scalar projection, preserving F13 holes and avoiding unsound full-model mask subtraction.

The all 156 sign/constant boundary and 36 hidden C alias-cancellation cases passed independently. Pure-parity equality 13 is retained when eligible and is not confused with C.

### Observations, CRT, complete relation and provenance — PASS

The parity syndrome uses canonical group representatives, compatible with all raw square/lag aliases. F13 equations use the same original support; beta compatibility and alpha compatibility are combined only through a common support/beta piece. Scalar CRT recombination uses the fixed piece's parity.

Every feasible support/beta piece is retained with complete affine-minus-cuts equations. Marginal masks are unions across these pieces, and provenance includes every contributing piece rather than just the first witness. Top-level witnesses carry a common piece and a checked original sparse realization; their support cost is verified exactly in the engine.

The relation is not Cartesian: a joint candidate must use one common piece and alpha. `check_joint` is correctly documented as a trusted in-memory helper, not an untrusted-result verifier; callers must supply the matching trusted context/result. Its actual evaluation rejects a tuple made from incompatible marginal choices.

### Output verification — PASS under documented trust boundaries

The reference imports no producer/core algebra or feature functions. Its original-coordinate F13/F2 enumeration, raw Z26 enumeration, and semantic output verifier are mathematically sound. The verifier checks the complete support/beta inventory and enumerates every published ambient alpha point, comparing the whole fiber—not just witnesses—to its independent oracle. It checks core masks, core points, sparse lifts, all provenance, feasibility and exact/empty status. The trusted `expected` memo is explicitly not untrusted evidence, and callers should supply the expected engine source pin.

The verifier intentionally ignores generic elimination transcripts when proving semantics; its complete finite oracle provides the proof instead. It is not a general hostile-file parser or an execution/resource-provenance authenticator. Execution statistics and budgets were separately inspected/reproduced in this review. Claimed source hashes do not authenticate execution by themselves.

### Engine inputs and resources — PASS for development contract

Decoder inputs reject noncanonical symbols, malformed contexts/observations, bools/nonintegers, invalid sparsity, unordered/duplicate/out-of-range feature indices, invalid Budget types and nonfinite budgets. Every cap exhaustion returns INCOMPLETE with masks, witnesses, pieces, provenance and feasibility all None. Core usage is charged cumulatively; eligible-piece/step/time caps are separate. Certificate errors are not relabeled EMPTY. The max_core_terms=0 case remains valid because this compiler always uses the small-union route with r<=2<13.

Work/step accounting and time checks are cooperative, not hard CPU-operation or memory bounds. The external launcher enforces CPU/address-space/wall limits and classifies worker death as failed/incomplete, not a solver exact result. The engine needs these outer controls in future use. No guaranteed completion or speedup follows from these tests.

## Independent fresh tests

`fresh_audit.py` uses a separately written original-coordinate enumerator, a precomputed156-element C descriptor set rather than the producer's C predicate loop, its own feature and descriptor evaluators, and independent complete support-fiber reconstruction. It compares full lifts, global functions, joint predictions, masks and pieces against the reference, then verifies decoder fibers and provenance. These are fresh disclosed tests, not holdout observations.

Normal and `-O` runs passed identical checks (counts are per run):

- 135 full-relation cases, 877,085 raw original coefficient vectors.
- 318,162 published ambient F13 points checked.
- 10,409 original sparse-witness checks; 18,508 core witness checks.
- All156 C laws and 36 global C laws obscured by raw lag/square cancellation.
- 25 malformed decoder requests;25 cumulative budget cases;9 result mutations;2 joint checks.

Coverage includes every equality/non-equality feature pair; each of six lag/square pairs with each equality; multiple equality indicators; products; no-output relations; empty domains; conflicting duplicate observations; full equality versus residue equality; old and retained laws sharing finite predictions; complete aliases and original representations; and all 31 features at sparsity 2 with no output contexts. The last case proves completeness cannot be inferred merely from marginal coverage.

Normal fresh audit: 47.31 CPU seconds; optimized: 56.49 CPU seconds. Both had 120 CPU-second/768 MiB limits and a 150-second outer watchdog. Timing is a resource receipt, not a performance comparison.

## Frozen-result and execution reproduction

The original reference audit driver was independently rerun in normal and optimized modes against all 14 stored disclosed cases. Each passed 17 existing mutations and 7 cap cases. Audit CPU was 5.01/6.15 seconds respectively.

Producer code was copied byte-for-byte into the review's isolated `producer-replay/` directory so the producer scripts could run without rewriting original artifacts. All four launcher configurations passed under their fixed outer limits. All 10 normal/optimized result files matched the originals exactly after removing only wall_seconds; this comparison includes all charged resource counters, statistics, masks, fibers, witnesses, identities and evidence.

Replay CPU/RSS receipts: tiny normal 2.32s/14,592KiB; tiny optimized 1.15s/18,660KiB; full31 normal 4.89s/28,980KiB; full31 optimized 6.34s/31,296KiB. Original full31 piece counts 116/57/90/8 and all associated semantics reproduced. No draws or fixture selections changed.

The excluded-C fixture's 1,476 residual global functions sharing one finite 91-row prediction remains a disclosed degenerate case, not recovery evidence. Filtering global old laws cannot subtract every prediction those laws share with residual functions.

## Original reference cap-input defect

Original `reference.py` validates max_points in `oracle`, but not in `brute_force` or in `verify_result` when a trusted expected memo bypasses oracle. At original pin51228d..., these both return EXACT:

```python
args = dict(contexts=[], observed={}, sparsity=1, allowed_features=[28])
result = decode(**args)
expected = oracle(**args)
brute_force(**args, max_points=float('nan'))
verify_result(**args, result=result, expected=expected,
              max_points=float('nan'), expected_source_sha256=ENGINE_PIN)
```

NaN makes `points > max_points` comparisons false, silently disabling the point cap. This is a strict-input/resource-contract defect, not a wrong residual/mask result. All audited historical and fresh runs used fixed valid integer caps plus external limits, so those results stand. The project owner authorized a separate reference-v2 patch; the original is preserved. Use the repaired reviewed v2 pin below rather than silently treating the original pin as fully hardened.

## Source scope and admission boundary

The previously audited fixed-alphabet causal-linear separation and exact Scott carry intersection are used only within their stated global-operator quantifiers. B is the defined inherited canonical parity exclusion; this implementation review does not reauthenticate original target extraction. None of these facts proves finite-trace separation, target model membership or complete historical novelty.

The precise matbalez recurrence/terminal-22 operator scope remains unavailable/uncertain. No new target, old holdout or fresh holdout was accessed. A future residual protocol requires a separate freeze/admission decision and must retain this unresolved historical scope, exact pins, controls, resource accounting, and independent output validation. This review grants no such admission.

## Artifacts

Review directory: `/ARCHIVE_WORKSPACE/canonical-residual-full-review/`.

- `fresh_audit.py`, `fresh-normal.json`, `fresh-optimized.json`.
- `stored-audit-normal.json`, `stored-audit-optimized.json`.
- `producer-replay/`: isolated byte-identical source replay, outputs, launcher receipts and `comparison.json`.
- `REVIEW.md`: this full source/implementation audit.

## Final reference-v2 hardening closeout — PASS

Reviewed replacement: `/ARCHIVE_WORKSPACE/canonical-residual-reference-v2/reference.py`, SHA256 `618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`. Engine and original reference pins above remain unchanged. The v2 patch changes only the reference version, introduces one shared built-in-int/nonnegative guard, and invokes it first in oracle, brute_force and verify_result—including INCOMPLETE, EMPTY and trusted-memo paths. After removing these guard changes, an independent AST comparison finds all 17 preexisting function bodies identical. No filtering, solver, fixture or output-semantics change occurred.

Independent targeted normal and `-O` runs each passed 96 malformed-cap rejections, 4 positive-work zero-cap exhaustions, 2 zero-work successes, 3 exact boundaries, an off-by-one boundary rejection and JSON-serialized result verification. Both modes independently reran the v2 author's 120-rejection regression suite and complete 14-case historical semantic audit; all passed. The six new subprocesses consumed 12.132276 inclusive child CPU seconds. These checks close the cap-input defect; no unresolved implementation blocker remains within the documented bounded development contract.

V2 evidence: `check_reference_v2.py`, `v2-targeted-{normal,optimized}.json`, `v2-regressions-{normal,optimized}.json`, `v2-stored-{normal,optimized}.json`, and `v2-process-receipts.json`.

## Deduplicated resource accounting

`CPU-ACCOUNTING.json` records each newly executed process, source receipt and accounting basis. Full residual implementation review plus independent v2 checks: **141.796503815 measured CPU seconds** across 14 distinct processes. Earlier separate affine/projection reviews by this same reviewer add 37.222177746 measured seconds, listed separately so project accounting can reconcile its broader allocation without counting original producer receipts or copied artifacts again. Total of all listed reviewer processes: 179.018681561 seconds.

These are measured-process totals, not a claim that every inspection, startup, hashing or orchestration CPU cost was measured. The unmeasured categories are explicit. Inclusive v2 subprocess CPU already contains its script work; do not add those internal script counters a second time.
