# Independent public v003 verifier-capacity proof

## Certain conclusion

**A correct complete result for public case v003 cannot receive VERIFIED under the frozen reference's 2,000,000-point cap, irrespective of additional CPU time.** This is a protocol-capacity obstruction, separate from the still-unresolved cause and execution phase of the failed job's SIGXCPU/CPU-ceiling anomaly. It neither proves an engine correctness defect nor authorizes rerunning, changing caps, releasing truth or replacing the cohort.

This proof uses only the public solver-input file and frozen source text. No solver, oracle, generator, original cohort job or generic diagnostic was executed. No seed/truth bytes were accessed. Prior reports, source, receipts and bundle remain unchanged.

## Public facts checked

Public file SHA256: `555a1f130f4be22446f35aa31c5a8df1d857a5d1e765a604ee5d5d912e31b87b`.

Index 3 has ID `v003`, all original features 0..30 allowed, sparsity 3, 91 distinct six-component contexts and 24 observed responses, all zero. Direct comparisons show each of the three full-Z26 equality indicators (features 28,29,30) is zero on every one of the 91 contexts. Distinctness and unobserved-row equalities are not necessary for the lower bound; zero equality columns on observed rows suffice.

Frozen reference SHA256: `618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`; engine SHA256: `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`. Source/analysis manifests remain `4c98ac170b0770b487b655dc4ba1ac8c96802669e1287e8a8090c1190669abc8` / `e64d9bd04a457cb5b318ecfe6200467c774077c5c6ceaeb63a3bee83f5bda46a`.

## Constructive feasible-piece lower bound

Let Q={28,29,30}. For any three-feature support container T and any nonempty subset S of T∩Q, choose original coefficients θ_j=13 for j∈S and zero otherwise. This has at most three nonzero original coefficients and is allowed inside T, including zero padding.

Its canonical F13 descriptor is α=0. Its F2 descriptor β has ones exactly in the equality groups corresponding to S (groups 22,23,24), with all other bits zero. Therefore:

- E holds because an equality β coordinate is nonzero.
- B does not hold: β is not supported only on constant/lag1.
- C does not hold: every α equality coordinate is zero, whereas each b±one-equality descriptor has a signed-unit equality α coordinate.

Thus the global law belongs to R=E\(B∪C). Every sample prediction is zero because all equality columns vanish, so the law fits the 24 zero observations. The zero vector belongs to each corresponding F13 fiber. Distinct pairs (T,S) give distinct required support/beta piece keys, even when they represent the same global function.

For |T∩Q|=k, the number of supports is C(3,k)C(28,3−k), and there are 2^k−1 nonempty equality subsets:

| k | Support containers | Feasible β choices each | Required pieces |
| --- | ---: | ---: | ---: |
| 1 | 1,134 | 1 | 1,134 |
| 2 | 84 | 3 | 252 |
| 3 | 1 | 7 | 7 |
| **Total lower bound** | | | **1,393** |

An independent counting order gives the same result: choose S first and pad T, obtaining 3C(30,2)+3C(29,1)+1=1,305+87+1=1,393. This constructs only **seven distinct pure-equality global descriptors**, replicated across required support containers—not 1,393 distinct functions. More feasible pieces/functions may exist; none are needed for the argument.

## Frozen cap semantics

`reference.py` lines 176–196 enumerates maximal support containers of size min(sparsity,allowed count), takes every original-coordinate F13/F2 solution, permits zero coefficients, filters the canonical residual and retains pieces keyed by `(support,beta_active)`. These padded pieces cannot be discarded as redundant in this API. `verify_result` line 373 requires support size three; line 425 requires exact equality between actual and expected support/beta key sets.

For every published piece, lines 387–389 add **13^n** to one cumulative `ambient_points` counter and raise `ReferenceLimit('published-fiber ambient enumeration cap')` if it exceeds `max_points`. Here n=3 for every piece, even when the feasible fiber contains only α=0. The trusted expected-oracle memo does not bypass this charge.

Consequently any legitimate complete result requires at least

**1,393 × 13³ = 1,393 × 2,197 = 3,060,421 ambient points > 2,000,000.**

Only 910 size-three pieces fit: 910×2,197=1,999,270, while the 911th raises the count to 2,001,467. Piece order cannot fix this; omitting pieces violates completeness. The oracle's separate original-coordinate field-pair cap may fail earlier, but no claim about that is necessary.

`run_one.py` calls both oracle and verifier with the frozen cap 2,000,000 and sets VERIFIED only after verification returns. A `ReferenceLimit` leaves the wrapper INCOMPLETE. Engine INCOMPLETE also cannot become VERIFIED; a falsely empty or incomplete piece set cannot legitimately pass the independent comparison. Thus both planned Python modes for this public case lack a conforming VERIFIED path under the frozen contract, and the 96-verified-output whole-cohort success criterion is unattainable for this drawn input.

## Scope and implication

The prior static review acknowledged possible reference caps but did not prove this specific post-draw capacity obstruction. Preserve it as historical evidence, with this separate addendum. More CPU or a more permissive CPU-receipt threshold cannot remove the fixed mathematical counting cap. No inference is made about where the killed process was executing, whether it had reached verification, or why its measured CPU exceeded the nominal hard limit.

For a future separately authorized protocol, capacity preflight should distinguish number of support containers, distinct descriptors, actual fiber points and verifier-charged ambient grids before interpreting successful verification as attainable. That is a design-review requirement, not permission to optimize the solver, enlarge this cohort's cap, reuse it as fresh evidence, redraw, or release its truth.
