# Independent reference-v3 design/proof review

## Verdict and boundary

**DESIGN PASS, subject to the explicit implementation prerequisites below. No mathematical blocker identified.** This reviews a specification and proof—not code, empirical performance, budget sufficiency or an implemented verifier. Separate approval, frozen implementation/fixture/resource specifications and a full independent implementation audit are still required.

Only design documents and the unchanged engine/reference source text were inspected. No implementation, fixture, solver, oracle, generator, cohort, historical replay or resource-control trial was executed. No seed/truth was accessed. The failed cohort, including v003, remains permanently INCOMPLETE and excluded from future fixtures. private administrative register [reference omitted] was reread. No producer document/source or remote artifact was edited.

## Final reviewed current pins

| Document | SHA-256 |
| --- | --- |
| `STATUS.md` | `2db3aa2f1fd20803be08f3b0510f62b8846befc2097d93f31760d7781254c50a` |
| `DESIGN.md` | `4aeeb375f265ccecf69b3c611ea92742b7fde75d065a2f614827242fea660e73` |
| `CERTIFICATE-AND-BUDGET.md` | `e1a97c5ee3210f7644075cbaeff0d3185a9a28fec8a82def7bda989f8656837a` |
| `PROPOSED-CHECKS.md` | `717fbd14912ce81d12e4bc4dfc82db0f40b5ac197b6a32c08ed2892541c4f29a` |
| `FINITE-DEVELOPMENT-PROPOSAL.md` | `489aa524ca280d09be075262c5c3952e5ca994a74d39b691d72098c0e297b319` |
| `SHA256SUMS` | `558f2877babce45a866f34da766d04ea8bc8f030ac2e323d46d4a9c43b58c4e0` |

The current revision resolves the wording clarifications below and adds a finite, still-unapproved fixture/resource proposal. Its final deltas were inspected statically. The original design is preserved under `r0/`, and the superseded unapproved author-only resource suggestion is preserved under `r1-superseded-resource-proposal/`.

### Reviewed original draft pins, retained as history

| Document | SHA-256 |
| --- | --- |
| `STATUS.md` | `4005cd03c931c550c3ab2db3b980e1e75c40f9ad0308a54d553c51323c6e30c3` |
| `DESIGN.md` | `e381db3c769f1a9aed7bc242795300937f71605816ec116f613848de0369ce15` |
| `CERTIFICATE-AND-BUDGET.md` | `d8c5b4ad966c4bd12e8e84943ad368b51f9815abacaded34fe226c8c43a0f176` |
| `PROPOSED-CHECKS.md` | `717fbd14912ce81d12e4bc4dfc82db0f40b5ac197b6a32c08ed2892541c4f29a` |
| `SHA256SUMS` | `ca35a2bf72e90a843ef8d673880724d1cd61ea03f2ff112493cc45a535f8107b` |

The fixed engine is `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`; predecessor reference v2 is `618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`. Neither was changed. The current revision and preserved original have distinct pins, rather than silently replacing historical evidence.

## 1. Affine certificate theorem

The proposed complete certificate is sufficient. Every permitted operation on the augmented matrix is invertible over F13: swapping rows; scaling by a nonzero field element; and adding a multiple of a distinct row. The checker receives the actual original equations, checks their identity, replays every operation, and checks literal final-matrix equality and full augmented RREF. Hashes alone, satisfying witnesses, declared rank and producer elimination transcripts are not accepted as proofs.

Full augmented RREF determines rank(A), rank([A|b]) and consistency. A pivot in the RHS column witnesses inconsistency. Otherwise, the checker itself obtains a particular point by setting every free coordinate to zero and obtains one kernel vector for each free column. The free-coordinate identity matrix proves linear independence. The pivot equations uniquely determine every other coordinate, proving spanning. Thus the parameter map is bijective, not merely a source of valid witnesses.

For dimension d=n−rank(A), this yields exactly 13^d solutions. The n=0/no-equations system has one empty vector; a nonzero RHS-only equation has none. Inconsistent systems still require algebra/certificate work even though their point count is zero.

The stated generator transcript ceiling w(m+1), w=n+1, is a valid conservative bound for the specified left-to-right Gauss–Jordan procedure: at most w pivots, two swap/scale operations per pivot and m−1 eliminations per pivot. It is a restriction for that generator/format, not a theorem about arbitrary implementations or total computational work. Matrix scans, copies and all replay/checking costs still need metering.

## 2. The essential base-equivalence proof

Given complete certified descriptions O=a+span(U) and P=b+span(V), each equation of P holds on all O exactly when it holds at a and annihilates every U direction. The converse inclusion is the same test with roles reversed. Therefore the proposed two inclusion tests prove **P=O**. Correct points with omitted kernel directions are insufficient, which is why full RREF/free-column completeness must precede these tests.

This closes the critical restricted-enumeration gap: checking only expected O points cannot detect extra producer points outside O unless P⊆O is independently proved. Conversely, only P⊆O would miss a producer base that wrongly deletes some observation solutions. Equal ranks alone also do not prove equality of translated affine spaces.

The contract is intentionally stronger than equality after applying cuts. A weaker base with compensating exclusions is rejected even if its final relation happens to be equivalent. That is an explicit versioned representation restriction, not a mathematical error. Source inspection confirms the fixed engine's `base` is exactly the raw mod13 observation system restricted to the original support, so this contract requires no engine change.

If one base is inconsistent and the other is not, reject. If both are inconsistent their solution sets agree, but a listed feasible piece remains invalid. EMPTY must follow independent complete inventory traversal, not lack of producer pieces.

## 3. Pointwise and global completeness

Once P=O and the parameterization is bijective, checking direct canonical R against producer cut membership for **every** observation point proves complete filtered-fiber equality. Rejected R points must also be inspected; enumerating only retained points would fail to detect omitted exclusions. No point outside O can escape because base equivalence already excludes it.

The expected inventory is independently traversed over every maximal original support and every covered canonical beta. Parity incompatibility and B ineligibility are sufficient reasons to discard a beta independently of producer predictions. Every remaining observation fiber is inspected even if the producer omits that key. Exact key-set equality catches missing, extra, duplicate, ineligible and empty purported pieces.

The lifting argument is sound: canonical groups partition the original feature indices. Because every active beta group has at least one member in T, choosing one member in each such group realizes the requested group XOR; choose zero parity elsewhere. CRT combines this assignment with any retained alpha into an original coefficient vector supported inside T. Enumerating all original parity assignments and retaining exactly the required XOR assignments recovers every lift, including nonminimal representations. Zero-padded maximal support containers retain smaller sparse vectors; they cannot be merged merely because they share a global law or finite prediction.

Consequently every original sparse residual law appears, every retained descriptor has a valid common original lift, and exact evaluation gives complete reference alpha sets, descriptors, lifts, marginals, joint tuples and provenance. Selected engine witnesses must separately satisfy independently checked minimal-support requirements. The complete reference relation is not a Cartesian product of scalar masks.

## 4. Clarifications resolved in the current revision

The owner incorporated these refinements in the final current pins. They clarify the normative implementation contract rather than repair the central theorem:

1. **Joint-field scope.** Full joint sets remain reference-side, as in v2. The unchanged engine need not acquire a new joint-set output field. A proposed wrong-joint-set mutation must concern a reference or actually advertised claim. Pointwise piece completeness still determines the engine's induced joint relation.
2. **Lift existence.** State the group-XOR construction explicitly, and keep all original parity-assignment trials/lifts, not only one minimal representative.
3. **Error versus exhaustion precedence.** A discovered invalid certificate/semantic mismatch is rejection, never EMPTY or a falsely successful resource result. But if a valid budget exhausts before an invalid item is inspected, the verifier can only report incomplete checking; it cannot promise to discover every malformed certificate under zero work. No incomplete run may certify uninspected obligations.
4. **Optional certificate data.** If supplied rank, pivot, free-column, particular or kernel fields are declared certificate claims, compare them with checker-derived information. Alternatively label a field explicitly as ignored nonclaim metadata. In neither case may it become a trusted premise.
5. **Changed traversal/accounting.** Canonical-beta traversal, original-lift reconstruction and added independent certificates change the reference's work accounting as well as the ambient-grid substitution. Do not imply identical v2 cap units, comparable timing or a proven speedup.

## 5. Budget and strict-API requirements

One cumulative meter per public invocation is the correct design. It must cover independent observation construction, both base solves/certificates, inclusion checks, every point visit including rejected/repeated points, every lift trial including rejected assignments, witnesses, exact comparisons and output allocation. A diagnostic expected memo cannot bypass any obligation or reset the meter. Separate public invocations have separate measured executions and need outer aggregation.

Actual fiber visits and the hypothetical legacy ambient-equivalent statistic must remain distinct. The new metric needs a new explicit allocation; reusing the numeric v2 cap is not preservation of its semantics. Preflighting 13^d is useful but does not cover the remaining cut/lift/witness/output work or guarantee completion.

Before implementation approval, freeze exact budget/schema versions, field/type and size limits, output-record charging, work-unit schedule, permitted constant-size pre-meter header validation, overflow/finite-value handling, and status/error precedence. Integer caps must reject bools, subclasses and floats; all public/early-return/memo paths validate caps first. Wall caps need explicit finite nonnegative handling. A known cap of zero does not make nonzero schema or algebra work free.

Budget exhaustion must suppress semantic partial results. Producer-INCOMPLETE format checking is not exact verification. VERIFIED_EMPTY requires complete independent scan. Invalid certificate data remains a semantic rejection when discovered. Source hashes bind identities but do not authenticate execution.

Nominal OS limits are operational settings, not proven strict observed CPU cutoffs. The unresolved historical overshoot remains a separate infrastructure issue; this design cannot repair it or retroactively release the failed cohort's reservation. Future execution requires a separately reviewed bounded process-tree/wall/CPU/memory plan and honest inclusive receipts.

## 6. Proposed fixture-plan review

The proposed generic fixture families cover the proof's critical failure modes: zero-dimensional and inconsistent systems; full/partial rank; translations; dependent/reordered rows; free columns in all positions; corrupted operations/RREF/rank/kernel completeness; both affine-containment directions; full-symbol equality; parity aliases and nonminimal lifts; exact E/B/C exclusions; missing/duplicate pieces; coincident predictions without provenance merging; false EMPTY; and joint-versus-marginal mistakes.

The planned independent ambient oracle on tiny literal F13 systems and raw Z26 enumeration on tiny declared feature subsets are appropriate disclosed cross-checks. They have not been run. Before any execution, freeze the literal fixtures, independent expected sets/outcomes, mutated-field schemas and exact budget boundaries. Require normal/-O equivalence for all non-resource semantics and late-exhaustion no-partial-output tests. Add explicit implementation cases for the clarification points above, without importing v003, failed-cohort-derived examples or old holdouts.

### Finite inventory and resource proposal

The final finite plan is also mathematically consistent: 16 explicitly listed affine systems; 13 ordered base-equivalence comparisons; 16 deterministic certificate-mutation slots; 40 residual domain/pattern slots; 850 malformed-cap requests per mode (8 integer caps × 20 values × 5 paths, plus 10 wall-cap values × 5 paths); and 32 boundary/cumulative slots. Exact mutation targets, work totals and fixture serialization remain unfrozen prerequisites, not executed tests. The additional 156 C-descriptor and 676 lag/square-pair checks are arithmetic boundary blocks, not hundreds of new full solver cases.

The 40-slot status table has valid analytic witnesses or impossibility arguments. For D01/D04/D05/D06 pattern 2, c0's lag1/square1 parity is zero; the observed zero forces equality parity zero, leaving beta in B, so the residual is empty. For D02, constant13 plus equality13 gives zero at c0 while remaining residual. For D03, lag2 coefficient1 plus E12 coefficient24 gives 2+24=0 mod26 and has non-B beta. For D07/D08/D09, 13E34 vanishes at c0 and is residual. Contradictory duplicate contexts are impossible for every deterministic law, and the empty feature domain never has equality dependence. These are proof-derived expected completed statuses, not predictions of successful completion under an untested cap.

The separate nonempty shared-prediction control at c1 correctly retains prediction zero despite excluding ±E12 globally. The repeated-c0 joint control has 11 retained odd equality coefficients (excluding ±1), hence 11 diagonal joint tuples rather than all 121 marginal combinations. These are distinct obligations. A00's single empty affine vector is correctly distinguished from the full residual API's empty relation for no features.

The 12-cut compensation adversary B12 is properly routed to the base-equivalence helper before the unchanged engine's at-most-two-cut shape guard, so it actually exercises base equality. Certificate mutation targets must be genuine non-no-ops; deleting an allowed identity operation need not invalidate a certificate.

The **320-CPU-second proposal is pending designer planning, not parent/coordinator approval**: four sequential worker invocations with 75 seconds allocated each (author normal/-O and independent normal/-O), plus a distinct 20-second exclusive-supervisor reserve. Illustrative worker settings are nominal 60/75 CPU, 150-second wall and 1 GiB address space; the supervisor/watchdog allocation is 256 MiB, for 1.25 GiB combined planned address space. Four worker invocations are not a claim that only four physical processes exist.

This is a coherent allocation/stopping-policy proposal, **not a guaranteed physical CPU ceiling or run-ready launcher specification**. Before execution, freeze the complete wrapper/watchdog topology, all actual process limits, exclusive-supervisor measurement, no-double-count aggregation and reservation discipline for BOTH worker and supervisor buckets. A new worker cannot launch merely because a global total appears sufficient if its supervisor reserve is exhausted. Any extra orchestration node must fit the declared allocation; unknown overhead must remain explicit. The earlier 600-author-only and intermediate 300 suggestions are not active approvals. No numeric execution allocation is approved by this review.

## Final scope

This is classical finite-field linear algebra and exhaustive finite verification applied to the local canonical residual. It supports a sound proposed verifier architecture, not a novelty, performance, model-membership, target-admission or completed-validation claim. Historical matbalez scope remains unresolved. K4 target status remains NO-GO.

**Gate:** obtain a separately authorized new implementation plan; freeze its schemas, counters, sources and disclosed fixtures; then perform independent full code/certificate/cap review before any later unseen validation. No coding or execution permission follows from this document.

No experiment/fixture CPU receipt exists for this design review because no such computation ran. File reads, hashes, discussion and report construction consumed unmetered control overhead; this is not a claim of zero total CPU use. No denied or uncertain operation remains pending.
