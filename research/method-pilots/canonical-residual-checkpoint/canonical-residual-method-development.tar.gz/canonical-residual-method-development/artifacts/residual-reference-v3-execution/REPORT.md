# Certified observation-fiber reference v3 — disclosed development PASS

31 October 2026. **All four frozen slots passed:** author normal/`-O` and
independent reviewer normal/`-O`. This is an implementation-validation result
on disclosed literal fixtures, not a fresh holdout, speedup study or K4 result.
The original failed validation remains permanently **INCOMPLETE** with truth
sealed. No original case was replayed and no source changed after this freeze.

## What was established

The separately versioned independent reference reconstructs the raw F13
observation solution space for each original support and compatible canonical
beta. Independently generated invertible row-operation certificates are replayed
and full augmented RREF, rank, consistency, all free columns and complete kernel
bases are checked. The producer's unfiltered base must equal the independent
observation base in **both directions** before restricted enumeration is allowed.

Every point in each certified observation fiber is visited, including rejected
points. Direct canonical R is compared with producer cut membership pointwise.
Complete independently traversed support/beta inventory prevents missing pieces
from disappearing. All original grouped-XOR assignments and CRT lifts are
retained, including aliases and nonminimal representations. Selected engine
witnesses must separately be minimum-support original-coordinate witnesses.

The predicate and producer are unchanged: R=E minus(B union C), with canonical
equality dependence in either field, B's constant/lag1 parity restriction, and
the exact156 signed-equality-plus-constant functions C. Equality is evaluated on
full Z26 symbols before reduction. Filtering functions is not subtraction of
old prediction masks; complete joint predictions are not marginal products.

## Finite evidence and independence

The **same42 literal relation fixtures** (40 core plus2 boundary controls) were
used in all four modes: **25 nonempty EXACT,17 EMPTY**. Repeated modes are not
new independent data cases. Both independently written raw Z26 oracles matched
the reference's complete per-piece alpha sets, all original lifts, canonical
descriptors, joint tuples, marginal masks and cross-piece provenance—not merely
counts or satisfying witnesses. The reviewer oracle uses ambient original
coefficient assignments; the author oracle enumerates exact nonzero supports.

Within each suite, normal and `-O` outputs and deterministic work counters agree
after removing only optimization mode, diagnostic timers/RSS and nested wall
timings. All42 per-case mathematical cardinalities also agree across the two
independently written suites.

| Completed obligation, per mode | Author | Independent reviewer |
| --- | ---: | ---: |
| Complete raw-coordinate relation comparisons |42|42|
| Affine systems / certificate JSON roundtrips |16/16|16/16|
| Two-way base-equivalence comparisons |13|13|
| Invalid certificate mutations rejected |16|24|
| Invalid producer/memo mutations rejected |16|18|
| Malformed-cap requests rejected |850|850|
| Counter boundary/cumulative slots |32|32|
| Additional cap/format controls |—|4|
| Strict public-input negatives |—|12|
| Pure wrapper negatives / positives |—|24/2|

Both modes also checked all156 C descriptors, all676 lag/square coefficient
pairs (338 descriptors), and all26 symbol aliases13x²=13x. Explicit nonempty
shared-prediction controls preserve zero while excluding old functions; the
joint control has11 diagonal tuples rather than121 marginal combinations.
Weaker producer bases, missing kernel directions, wrong residual witnesses,
missing provenance, false EMPTY and late cap exhaustion are covered.

Per independent mode, the42 fixtures involved224,592 raw coefficient vectors,
69 piece instances,46,314 descriptor instances,55,124 original-lift instances,
23,791 joint-prediction instances and1,747 checked advertised original witnesses.
These are sums **across fixtures**, not counts of globally distinct laws.
Primary reference construction and primary producer verification each visited
46,605 observation-fiber points. Mutation/control work is additional and retained
in the reports. No hypothetical ambient-equivalent count is treated as actual
work, an old cap debit or a speedup measurement.

## Resources, reservations and failures

| Slot | Reported worker CPU(s) | Supervisor exclusive sample(s) | Supervisor allocation charge(s) |
| --- | ---: | ---: | ---: |
| author-normal |8.761273|0.149550|5|
| author-optimized |9.407479|0.114985|5|
| review-normal |9.753088|0.118039|5|
| review-optimized |9.473537|0.120959|5|
| Total |**37.395377**|**0.503533**|**20**|

The known reported components sum to37.898910s **excluding** supervisor final
write/exit tails and static/control/closeout overhead. Full20 supervisor
allocation is a separate policy charge, not measured use to add again. Suite
timers are subsets, not extra processes to double-count. Numeric PIDs repeat
across separate launch contexts; deduplication uses scheduled job/command/receipt
identities, not PID numbers alone.

All workers exited0 and were reaped. There was no unexpected incomplete result,
failure, overshoot, retry, source drift, partial artifact or outstanding reserve.
Intentional cap controls correctly returned incomplete without semantic leakage.
All four slots are consumed; no further execution is authorized by this plan.

Maximum OS-reported worker RSS was84,412KiB; supervisor RSS was14,060KiB.
Settings were worker60/75CPU,1GiB,150wall and supervisor4/5CPU,256MiB. These are
nominal enforcement settings and reported observations, not guaranteed physical
maxima. The earlier CPU-limit anomaly is not explained by this successful stage.

Planned allocation remains320CPU seconds under the new1,000 planning ceiling;
680 contingency was unused and is not automatic replenishment. Previous project
allocations remain unchanged: the conservative total is16,880/28,800CPU seconds,
**not a fully measured project CPU total**. See the single deduplicated
[RESOURCE-ACCOUNTING.json](RESOURCE-ACCOUNTING.json).

## Immutable evidence

- [Exact execution freeze](FREEZE.json):
  `96460c513aa07c554beebd037fecd106f10c7295637de6228004dcb5dd662316`.
- [Independent pre-run approval](PRE-RUN-APPROVAL.json):
  `f03a4991ddade54c7fa6e1c065599c591199870588a8f8c4429eaec54f7c45ef`.
- New reference source, `../canonical-residual-reference-v3/reference_v3.py`:
  `0730f8b0a26109919ba6eb558be18063d137ced233b397cd188dc261a13fe8f9`.
- [Final state](runs/state.json):
  `91667f12bd50caef8bcdf2915267d0075199c0eb0b3a62da0539d6bd24af5473`.
- [Stage accounting](RESOURCE-ACCOUNTING.json):
  `270021286a1d7b123a1a3ddca4374f5e8dec6372371d928b6c4fb6a66d1eb70d`.
- Full static audit and independent execution review are in
  `../residual-reference-v3-independent-review/`; author implementation/API/fixture
  documents are in `../canonical-residual-reference-v3/`.
- Final independent `REVIEW.md` is **PASS**, SHA-256
  `20fbded3b1165c11656c8cf4974c7f23b35f3a3a128a35dd9d5b473fd1a07021`.
- Per-slot result, resource and child diagnostic artifacts are in `runs/`;
  supervisor stdout/stderr are separately preserved in `launch-records/`.

The fixed engine remains at `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`;
predecessor reference v2 remains at `618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`.
No historical artifact was overwritten.

## Limits and next gate

The implemented mathematics is classical finite-field linear algebra, CRT and
exhaustive finite verification. This is a locally validated verification utility,
not proof of global novelty, model membership, cipher recovery or speedup.
Historical matbalez scope remains unresolved. Only declared producer claims and
optional joint claims are verified; arbitrary extra metadata is not authenticated.

The finite tests use at most three allowed original features. They establish no
full31-feature runtime guarantee. Degenerate observation ranks can still make
complete exact enumeration infeasible. A separately reviewed **design-only**
full31-feature resource pilot and sound rank/beta workload preflight are the next
recommendation, not an authorized implementation or run. No new holdout or K4
stage follows automatically. Publication remains separately blocked/pending;
no remote edits were attempted here.
