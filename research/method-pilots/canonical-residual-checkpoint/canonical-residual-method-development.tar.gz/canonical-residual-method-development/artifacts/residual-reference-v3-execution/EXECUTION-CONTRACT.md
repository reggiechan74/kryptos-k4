# Reference v3 — bounded disclosed development execution contract

**DRAFT / PRE-RUN GATE CLOSED.** This is the execution layer for the separately
versioned reference implementation, not a replay, fresh holdout or K4 run.
Project authorization covered implementation and the design's literal disclosed tests on
2026-10-31, conditional on independent confirmation of the complete frozen
source/schema/meter/fixture/mutation/cap/launcher manifest before any test.

The fixed producer engine, references v1/v2, all historical artifacts and the
failed cohort are immutable. Failed-cohort inputs, seed/truth and old holdouts
are excluded. The failed cohort remains permanently INCOMPLETE. Historical
matbalez scope is unresolved; this stage grants no novelty or target admission.

## Allocation and one-use schedule

Root approved a NEW stage planning ceiling of 1,000 CPU seconds, leaving earlier
project allocations unchanged (16,880 total allocated out of 28,800). The
specific planned expenditure is **320 seconds**: four worker allowances of
75 seconds each and four supervisor allowances of 5 seconds each. The other
680 seconds are unspent contingency, **not automatic replenishment**.

Exactly these four single-process test workers may run, sequentially and once:

1. `author-normal`
2. `author-optimized`
3. `review-normal`
4. `review-optimized`

Each invocation is one supervisor plus at most one active worker. No worker may
spawn another process, access the network, or run an old/held-out case. No shell
chain is launched inside the supervisor. Static code review and source hashing
are not cryptanalytic execution; their unmeasured control overhead is disclosed,
not presented as zero CPU. A later source correction or additional run needs a
new explicit decision; the launcher cannot retry a slot or draw replacement data.

Per worker: nominal CPU soft/hard 60/75 seconds, 1 GiB address space, independent
supervisor wall watchdog 150 seconds, 32 MiB per output/log/partial file. A final
summary JSON is additionally capped at 2 MiB. Comparison of full mathematical
relations happens inside each worker; summaries retain results and counters.

Per supervisor: nominal CPU soft/hard 4/5 seconds, 256 MiB address space. Before
fork it keeps the 75-second/1-GiB hard headroom needed by its child while using
the smaller soft limits. The child raises its soft limits before executing the
frozen test command; the parent lowers its hard limits after fork. Thus worker
and supervisor limits are independent. Combined planned address space is
1.25 GiB, not an observed RSS figure or universal process-tree memory theorem.

Nominal OS thresholds are policy/enforcement settings, **not proven measured
maxima**. The prior CPU-limit overshoot remains unexplained. Any observed
overshoot, signal, wall timeout, failed test, malformed report, changed source
or missing receipt stops dependent execution. Passing normal mode does not
authorize a failed optimized run to be repeated. No performance or speedup
claim is an acceptance criterion.

## Frozen commands and independent pre-run gate

`FREEZE.json` will pin exact sources and dependencies, interpreter binary,
fixture/mutation specifications, internal cap/schema documents, this contract,
the supervisor, and all four full commands/cwds/limits. The commands are:

    <absolute pinned Python> -I -B [ -O ] <absolute suite> --output <fixed job/result.json>

`-I` isolates environment-based import settings; suites explicitly add only
their reviewed source roots before sibling imports. `-B` prevents bytecode
artifacts. No random seed or random fixture generation is used.

The independent reviewer must retain `PRE-RUN-APPROVAL.json` containing
`status="APPROVED_FOR_FROZEN_DISCLOSED_TESTS"` and the externally communicated
exact `FREEZE.json` SHA-256, after reading the full contract and sources. It is
not itself a proof of execution or semantic correctness. Neither an absent
approval nor an approval for another freeze can launch a worker. The approval
and source files are rehashed before and after every actual worker.

The frozen job specification also binds its report identity: schema
`reference-v3-suite-report-v1`, author/independent-review role, exact optimization
mode and expected obligation-count dictionary. The report must contain actual
source hashes equal to the complete frozen file map and the exact stage-freeze
hash. A bare PASS object is insufficient. Actual count fields must be built-in
nonnegative integers, not booleans. Both scripts independently hash their source
bindings before writing the report.

## Durable state and failures

The source root is `/ARCHIVE_WORKSPACE/residual-reference-v3-execution`.
Runtime artifacts are exclusively under its previously absent `runs/` tree.
Each fixed job owns `result.json`, optional `result.json.tmp`, `stdout.txt`,
`stderr.txt` and `resource.json`. Log/partial files are hashed as diagnostics,
never interpreted as successful results. Unexpected files or nonregular entries
fail the stage and are retained. No output is deleted to hide a failure.
An atomic temporary result remaining alongside a purported PASS is a failure,
not an accepted extra result. Prior PASS receipts are fully revalidated for
command/cwd/pins/limits/exit/timeout/reaping/CPU/identity and exact safe inventory
names before the next slot; a self-declared matching receipt hash is insufficient.

The caller also preserves supervisor-level stdout/stderr in fixed, previously
absent `launch-records/<job>.stdout.txt` and `.stderr.txt` files. The frozen outer
invocation uses shell `exec` (replacement, not an extra live shell), with
noclobber redirection. These logs preserve setup exceptions even when no worker
or finalized receipt exists; they are separately inventoried at closeout and
never accepted as worker results. Tool orchestration overhead is not
silently described as measured supervisor usage.

Before fork, an exclusive durable `IN_FLIGHT.lock` and atomic/fsynced `state.json`
reserve 75 worker CPU seconds and 5 supervisor CPU seconds. Job directories are
created exclusively. A completed job consumes that slot permanently. The next
slot requires all previous jobs PASS, unchanged prior receipts/inventory, no
in-flight reservation, sufficient worker and supervisor allocations separately,
and unchanged frozen sources. Both buckets are checked; a global total alone
cannot bypass an exhausted supervisor bucket.

Any uncertain/missing receipt leaves the lock and full reservations intact;
their absence of a result is not permission to retry. A fully reaped measured
failure may record its observed usage, but stops the stage and leaves the lock.
No later invocation is allowed to clear it. Interruptions during receipt/state
writing retain partial evidence and uncertainty rather than invent completion.

## Process and signal containment

Linux `PR_SET_PDEATHSIG=SIGKILL` with before/after parent-ID checks guards both
the supervisor link and worker link. The worker creates its own session/process
group before `execve`. The supervisor's wall signal kills that group; if the
child has not created its session yet, it falls back to the unreaped child PID.
The measured wall interval starts immediately before fork; after setup the
supervisor arms only the remaining portion of that same 150-second deadline.
If the deadline has already elapsed, it kills immediately instead of resetting
the interval. Child setup diagnostics are redirected before its guard/limits.

`waitid(..., WNOWAIT)` establishes termination without freeing the child PID.
Only after disabling the wall timer and marking the handler inactive does the
supervisor reap with `wait4`. This prevents a late wall handler from signaling
a reused PID/process-group ID. A dead supervisor can yield no trustworthy final
receipt; its durable reservation therefore remains outstanding.

## Receipts and non-double-counted accounting

Keep these quantities separate:

1. **Reported worker inclusive CPU:** `wait4` user+system usage, charged once.
   It is an OS-reported measurement, not an assertion of perfect physical CPU
   metrology. Worker-internal timer totals are diagnostic subsets, not additions.
2. **Observed supervisor exclusive CPU:** near-end `RUSAGE_SELF`, which excludes
   waited child CPU. The final receipt/state fsync and exit tail are unmeasured.
3. **Supervisor allocation charge:** the full 5 seconds for every attempted
   slot, regardless of the smaller observed self sample. It is not fabricated
   measured use and not a proven physical maximum.

The stage ledger aggregates worker reports and supervisor allocation charges
without mixing them into a falsely fully measured CPU total. A final summary
must report worker usage, supervisor samples, full allocation charges, remaining
reservations and unmeasured control/tail overhead separately. The 20-second
supervisor budget is fully partitioned even if measured samples are small.
No final artifact may claim that all project CPU has been measured.

Receipts bind job, command, cwd, source-freeze and approval hashes, process IDs,
reaped state, exit/signal classification, timeout, wall duration, CPU components,
RSS observations, declared limits and exact hashed artifact inventory. The
ledger binds every finalized receipt hash and reconciles prior worker totals.
Source changes after an earlier run invalidate later execution; historical
receipts stay preserved.

## Acceptance and remaining freeze prerequisites

A job is operationally PASS only when it exits zero, reports a bounded JSON
`status="PASS"`, respects all observed allocation checks, and preserves frozen
sources. Mathematical PASS still depends on the independent full-code audit
and the suite's complete relations, certificate/mutation and strict-cap checks.
Operational PASS alone is not reference correctness.

Still required before launch: final new reference source, exact work-unit and
record schemas, literal fixture/mutation files, internal numerical caps, author
and independent suite sources, complete manifest, and independent freeze
confirmation. No compilation, imports, suite calls or launcher trials have run.
