"""Frozen, one-attempt disclosed-development supervisor. Never a solver.

Exactly four scheduled single-process workers are permitted, one per invocation.
After freeze, independent in-worker mocks may import pure validation helpers.
They never invoke main/fork/watchdogs or create execution artifacts.
"""
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys
import time

ROOT = Path('/ARCHIVE_WORKSPACE/residual-reference-v3-execution')
FREEZE = ROOT / 'FREEZE.json'
APPROVAL = ROOT / 'PRE-RUN-APPROVAL.json'
RUNS = ROOT / 'runs'
STATE = RUNS / 'state.json'
LOCK = RUNS / 'IN_FLIGHT.lock'
JOBS = ('author-normal', 'author-optimized', 'review-normal', 'review-optimized')
WORKER_CPU = 75
SUPERVISOR_CHARGE = 5
WORKER_TOTAL = 300
SUPERVISOR_TOTAL = 20
WALL = 150
MIB = 1024 * 1024
REPORT_MAX = 2 * MIB
FILE_MAX = 32 * MIB


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as handle:
        while True:
            block = handle.read(MIB)
            if not block:
                return h.hexdigest()
            h.update(block)


def read_json(path, limit):
    require(path.is_file() and not path.is_symlink(), 'missing/symlink JSON')
    require(path.stat().st_size <= limit, 'oversized JSON')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    require(len(data) <= limit, 'JSON grew past limit')
    return json.loads(data)


def atomic(path, obj):
    data = (json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    require(len(data) <= REPORT_MAX, 'supervisor JSON limit')
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('xb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    fd = os.open(str(path.parent), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def death_guard(expected):
    require(os.getppid() == expected, 'parent changed before guard')
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'PR_SET_PDEATHSIG')
    if os.getppid() != expected:
        os.kill(os.getpid(), signal.SIGKILL)


def numeric(value):
    return ((type(value) is int and value >= 0)
            or (type(value) is float and math.isfinite(value) and value >= 0))


def digest_string(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def validate_report(report, spec, freeze, freeze_hash):
    """Pure frozen-suite identity check; no launch or filesystem access."""
    require(type(report) is dict and report.get('status') == 'PASS', 'worker report not PASS')
    require(report.get('stage_freeze_sha256') == freeze_hash, 'report freeze identity')
    require(type(report.get('python_optimized')) is bool, 'report optimization type')
    require(report.get('source_sha256') == freeze['files'], 'report source identities')
    expected = spec['report_identity']
    require(set(expected) == {'schema', 'suite_role', 'python_optimized', 'obligations'}, 'frozen report schema')
    for field, value in expected.items():
        require(report.get(field) == value, 'report identity: ' + field)
    counts = report.get('obligations')
    require(type(counts) is dict and all(type(v) is int and v >= 0 for v in counts.values()), 'report obligation counts')


def validate_receipt(receipt, spec, job, freeze, freeze_hash, approval_hash):
    """Pure validation of a finalized PASS receipt and safe inventory shape."""
    require(type(receipt) is dict and receipt.get('version') == 'reference-v3-stage-v1', 'receipt version')
    require(receipt.get('status') == 'PASS' and receipt.get('job') == job, 'receipt job/status')
    require(receipt.get('command') == spec['command'] and receipt.get('cwd') == spec['cwd'], 'receipt command/cwd')
    require(receipt.get('freeze_sha256') == freeze_hash and receipt.get('approval_sha256') == approval_hash, 'receipt pins')
    require(receipt.get('limits') == freeze['limits'], 'receipt limits')
    require(type(receipt.get('exit_code')) is int and receipt['exit_code'] == 0, 'receipt exit')
    require(receipt.get('wall_timeout') is False and receipt.get('child_reaped') is True, 'receipt timeout/reaped')
    require(receipt.get('parent_death_guard') is True, 'receipt death guard')
    require(receipt.get('failures') == [], 'receipt failures')
    require(receipt.get('classification') == 'post-failure disclosed development only', 'receipt classification')
    require(numeric(receipt.get('wall_seconds')) and receipt['wall_seconds'] <= WALL, 'receipt wall')
    for name in ('child_user_cpu_seconds', 'child_system_cpu_seconds', 'child_cpu_seconds', 'supervisor_exclusive_cpu_sample'):
        require(numeric(receipt.get(name)), 'receipt finite CPU: ' + name)
    for name in ('child_user_cpu_seconds', 'child_system_cpu_seconds', 'child_cpu_seconds'):
        require(receipt[name] <= WORKER_CPU, 'receipt worker CPU component ceiling')
    require(abs(receipt['child_user_cpu_seconds'] + receipt['child_system_cpu_seconds'] - receipt['child_cpu_seconds']) <= 1e-8, 'receipt CPU components')
    require(receipt['child_cpu_seconds'] <= WORKER_CPU, 'receipt worker ceiling')
    require(receipt['supervisor_exclusive_cpu_sample'] <= SUPERVISOR_CHARGE, 'receipt supervisor sample ceiling')
    require(type(receipt.get('supervisor_cpu_allocation_charged')) is int and receipt['supervisor_cpu_allocation_charged'] == SUPERVISOR_CHARGE, 'receipt supervisor charge')
    require(receipt.get('supervisor_final_write_tail_measured') is False, 'receipt tail claim')
    for name in ('supervisor_pid', 'child_pid'):
        require(type(receipt.get(name)) is int and receipt[name] > 1, 'receipt PID')
    require(receipt['supervisor_pid'] != receipt['child_pid'], 'receipt distinct PIDs')
    for name in ('child_peak_rss_kib', 'supervisor_peak_rss_kib'):
        require(type(receipt.get(name)) is int and receipt[name] >= 0, 'receipt RSS')
    inventory = receipt.get('inventory')
    require(type(inventory) is list and len(inventory) == 3, 'receipt inventory size')
    names = []
    for item in inventory:
        require(type(item) is dict and set(item) == {'name', 'bytes', 'sha256', 'classification'}, 'receipt inventory record')
        name = item['name']
        require(type(name) is str and name in ('stdout.txt', 'stderr.txt', 'result.json'), 'receipt safe inventory name')
        require(type(item['bytes']) is int and 0 <= item['bytes'] <= FILE_MAX, 'receipt artifact bytes')
        require(name != 'result.json' or item['bytes'] <= REPORT_MAX, 'receipt report bytes')
        require(digest_string(item['sha256']), 'receipt artifact hash')
        require(item['classification'] == ('result' if name == 'result.json' else 'diagnostic_nonresult'), 'receipt artifact class')
        names.append(name)
    require(set(names) == {'stdout.txt', 'stderr.txt', 'result.json'}, 'receipt exact inventory')


def validate_state(state, freeze, freeze_hash, approval_hash):
    require(type(state) is dict and state.get('version') == 'reference-v3-stage-v1', 'state version')
    require(state.get('freeze_sha256') == freeze_hash, 'state freeze changed')
    require(type(state.get('completed')) is list, 'state completed')
    require([r.get('job') for r in state['completed']] == list(JOBS[:len(state['completed'])]), 'state order')
    require(len(state['completed']) <= len(JOBS), 'too many completed jobs')
    require(numeric(state.get('worker_cpu_actual')) and state['worker_cpu_actual'] <= WORKER_TOTAL, 'state worker CPU')
    require(type(state.get('supervisor_cpu_allocation_charged')) is int, 'state supervisor charge')
    require(state['supervisor_cpu_allocation_charged'] == SUPERVISOR_CHARGE * len(state['completed']), 'state supervisor ledger')
    require(state.get('in_flight') is None and state.get('stopped') is False, 'stage stopped or uncertain')
    require(all(r.get('status') == 'PASS' for r in state['completed']), 'prior non-PASS job')
    require({path.name for path in RUNS.iterdir()} == {'state.json', 'IN_FLIGHT.lock'} | {r['job'] for r in state['completed']}, 'unexpected stage-root artifact')
    total = 0.0
    for record in state['completed']:
        jobdir = RUNS / record['job']
        require(jobdir.is_dir() and not jobdir.is_symlink(), 'prior directory changed')
        receipt_path = jobdir / 'resource.json'
        require(receipt_path.is_file() and not receipt_path.is_symlink(), 'prior receipt path')
        require(sha(receipt_path) == record['resource_sha256'], 'prior receipt changed')
        receipt = read_json(receipt_path, REPORT_MAX)
        spec = freeze['jobs'][record['job']]
        validate_receipt(receipt, spec, record['job'], freeze, freeze_hash, approval_hash)
        require({path.name for path in jobdir.iterdir()} == {'resource.json', 'result.json', 'stdout.txt', 'stderr.txt'}, 'prior inventory has extra/missing files')
        total += receipt['child_cpu_seconds']
        for item in receipt['inventory']:
            path = jobdir / item['name']
            require(path.is_file() and not path.is_symlink(), 'prior file missing/symlink')
            require(path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], 'prior inventory changed')
        validate_report(read_json(jobdir / 'result.json', REPORT_MAX), spec, freeze, freeze_hash)
    require(abs(total - state['worker_cpu_actual']) <= 1e-8, 'state CPU reconciliation')


def main():
    require(len(sys.argv) == 2 and sys.argv[1] in JOBS, 'usage: supervisor.py scheduled-job')
    job = sys.argv[1]
    initial_parent = os.getppid()
    death_guard(initial_parent)
    # Inherit enough hard headroom for the child; lower ONLY parent hard limits
    # after fork. CPU/AS limits are per process, not claimed physical maxima.
    resource.setrlimit(resource.RLIMIT_CPU, (4, WORKER_CPU))
    resource.setrlimit(resource.RLIMIT_AS, (256 * MIB, 1024 * MIB))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (FILE_MAX, FILE_MAX))
    freeze = read_json(FREEZE, MIB)
    freeze_hash = sha(FREEZE)
    approval = read_json(APPROVAL, MIB)
    require(approval.get('status') == 'APPROVED_FOR_FROZEN_DISCLOSED_TESTS', 'review gate closed')
    require(approval.get('freeze_sha256') == freeze_hash, 'review freeze mismatch')
    require(freeze.get('version') == 'reference-v3-stage-v1', 'freeze version')
    require(freeze.get('jobs') and list(freeze['jobs']) == list(JOBS), 'frozen job schedule')
    require(freeze.get('limits') == dict(worker_cpu_soft=60, worker_cpu_hard=75,
            supervisor_cpu_soft=4, supervisor_cpu_hard=5, worker_address_space_bytes=1024*MIB,
            supervisor_address_space_bytes=256*MIB, wall_seconds=WALL,
            worker_total_cpu_allocation=WORKER_TOTAL, supervisor_total_cpu_allocation=SUPERVISOR_TOTAL,
            report_max_bytes=REPORT_MAX, file_max_bytes=FILE_MAX), 'frozen limits')
    for path, expected_hash in freeze['files'].items():
        candidate = Path(path)
        require(candidate.is_absolute() and candidate.is_file() and not candidate.is_symlink(), 'frozen path')
        require(sha(candidate) == expected_hash, 'frozen source changed: ' + path)
    require(str(Path(__file__).resolve()) in freeze['files'], 'supervisor not frozen')
    spec = freeze['jobs'][job]
    jobdir = RUNS / job
    output = jobdir / 'result.json'
    command = spec['command']
    require(type(command) is list and all(type(x) is str for x in command), 'command shape')
    require(command[-2:] == ['--output', str(output)], 'fixed output binding')
    require(command[0] == str(Path(sys.executable).resolve()), 'interpreter binding')
    require(command[1:3] == ['-I', '-B'], 'isolated no-bytecode invocation')
    require(command[3:-2] == (['-O'] if job.endswith('optimized') else []) + [spec['script']], 'fixed command')
    require(spec['script'] in freeze['files'], 'worker source not frozen')
    RUNS.mkdir(exist_ok=True)
    require(not RUNS.is_symlink(), 'symlink runs directory')
    lockfd = os.open(str(LOCK), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.write(lockfd, (job + '\n').encode())
    os.fsync(lockfd)
    os.close(lockfd)
    # Any error after taking this one-use lock leaves the stage blocked. A
    # missing receipt is never permission to retry or remove reservations.
    if STATE.exists():
        state = read_json(STATE, REPORT_MAX)
        validate_state(state, freeze, freeze_hash, sha(APPROVAL))
    else:
        require(job == JOBS[0], 'first job must be author-normal')
        require({path.name for path in RUNS.iterdir()} == {'IN_FLIGHT.lock'}, 'first run directory not fresh')
        state = dict(version='reference-v3-stage-v1', freeze_sha256=freeze_hash,
            completed=[], worker_cpu_actual=0.0, supervisor_cpu_allocation_charged=0,
            in_flight=None, stopped=False)
    require(len(state['completed']) < len(JOBS), 'all scheduled slots already consumed')
    require(job == JOBS[len(state['completed'])], 'next scheduled job only')
    require(state['worker_cpu_actual'] + WORKER_CPU <= WORKER_TOTAL, 'worker reserve unavailable')
    require(state['supervisor_cpu_allocation_charged'] + SUPERVISOR_CHARGE <= SUPERVISOR_TOTAL, 'supervisor reserve unavailable')
    jobdir.mkdir()
    state['in_flight'] = dict(job=job, worker_cpu_reserved=WORKER_CPU,
        supervisor_cpu_reserved=SUPERVISOR_CHARGE, command=command,
        approval_sha256=sha(APPROVAL), timestamp_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    atomic(STATE, state)
    stdout = os.open(str(jobdir / 'stdout.txt'), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    stderr = os.open(str(jobdir / 'stderr.txt'), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    start = time.monotonic()
    supervisor_pid = os.getpid()
    child = os.fork()
    if child == 0:
        try:
            os.dup2(stdout, 1)
            os.dup2(stderr, 2)
            os.close(stdout)
            os.close(stderr)
            death_guard(supervisor_pid)
            os.setsid()
            signal.signal(signal.SIGXCPU, signal.SIG_DFL)
            signal.signal(signal.SIGALRM, signal.SIG_DFL)
            resource.setrlimit(resource.RLIMIT_CPU, (60, WORKER_CPU))
            resource.setrlimit(resource.RLIMIT_AS, (1024*MIB, 1024*MIB))
            os.chdir(spec['cwd'])
            os.execve(command[0], command, {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'})
        except BaseException as exc:
            os.write(2, ('worker setup failed: ' + repr(exc) + '\n').encode()[:4096])
            os._exit(125)
    os.close(stdout)
    os.close(stderr)
    resource.setrlimit(resource.RLIMIT_CPU, (4, SUPERVISOR_CHARGE))
    resource.setrlimit(resource.RLIMIT_AS, (256*MIB, 256*MIB))
    timed_out = False
    child_unreaped = True
    def timeout(_signum, _frame):
        nonlocal timed_out
        if not child_unreaped:
            return
        timed_out = True
        try:
            os.killpg(child, signal.SIGKILL)
        except ProcessLookupError:
            try:
                os.kill(child, signal.SIGKILL)
            except ProcessLookupError:
                pass
    signal.signal(signal.SIGALRM, timeout)
    remaining_wall = WALL - (time.monotonic() - start)
    if remaining_wall <= 0:
        timeout(signal.SIGALRM, None)
    else:
        signal.setitimer(signal.ITIMER_REAL, remaining_wall)
    while True:
        try:
            # WNOWAIT keeps the PID reserved until the alarm is disarmed. This
            # prevents a late handler from signaling a reused child/process ID.
            os.waitid(os.P_PID, child, os.WEXITED | os.WNOWAIT)
            break
        except InterruptedError:
            continue
    signal.setitimer(signal.ITIMER_REAL, 0)
    child_unreaped = False
    _, wait_status, usage = os.wait4(child, 0)
    wall = time.monotonic() - start
    exit_code = os.waitstatus_to_exitcode(wait_status)
    child_cpu = usage.ru_utime + usage.ru_stime
    failures = []
    if timed_out:
        failures.append('wall_timeout')
    if wall > WALL:
        failures.append('reported_wall_exceeds_allocation')
    if exit_code != 0:
        failures.append('worker_exit_' + str(exit_code))
    if not numeric(child_cpu) or child_cpu > WORKER_CPU:
        failures.append('worker_cpu_allocation_exceeded_or_invalid')
    report = None
    try:
        report = read_json(output, REPORT_MAX)
        validate_report(report, spec, freeze, freeze_hash)
    except (OSError, ValueError, TypeError, MemoryError) as exc:
        failures.append('worker_report:' + str(exc)[:200])
    if sha(FREEZE) != freeze_hash or sha(APPROVAL) != state['in_flight']['approval_sha256']:
        failures.append('freeze_or_approval_changed_during_run')
    for path, expected_hash in freeze['files'].items():
        if sha(path) != expected_hash:
            failures.append('frozen_source_changed_during_run:' + path)
    inventory = []
    for path in sorted(jobdir.iterdir()):
        if path.name == 'resource.json':
            continue
        if not path.is_file() or path.is_symlink():
            failures.append('unexpected_nonregular_artifact:' + path.name)
            continue
        if path.name not in ('stdout.txt', 'stderr.txt', 'result.json', 'result.json.tmp'):
            failures.append('unexpected_artifact:' + path.name)
        if path.name == 'result.json.tmp':
            failures.append('partial_tmp_remains')
        size = path.stat().st_size
        if size > FILE_MAX:
            failures.append('artifact_exceeds_file_limit:' + path.name)
        inventory.append(dict(name=path.name, bytes=size, sha256=sha(path),
            classification='result' if path.name == 'result.json' else 'diagnostic_nonresult'))
    self_usage = resource.getrusage(resource.RUSAGE_SELF)
    self_cpu = self_usage.ru_utime + self_usage.ru_stime
    if not numeric(self_cpu) or self_cpu > SUPERVISOR_CHARGE:
        failures.append('supervisor_sample_exceeds_allocation_or_invalid')
    status = 'PASS' if not failures else 'INCOMPLETE_OR_FAILED'
    receipt = dict(version='reference-v3-stage-v1', job=job, status=status,
        command=command, cwd=spec['cwd'], freeze_sha256=freeze_hash,
        approval_sha256=sha(APPROVAL), supervisor_pid=supervisor_pid, child_pid=child,
        child_reaped=True, exit_code=exit_code, wall_timeout=timed_out,
        wall_seconds=wall, child_user_cpu_seconds=usage.ru_utime,
        child_system_cpu_seconds=usage.ru_stime, child_cpu_seconds=child_cpu,
        supervisor_exclusive_cpu_sample=self_cpu,
        supervisor_cpu_allocation_charged=SUPERVISOR_CHARGE,
        supervisor_final_write_tail_measured=False,
        supervisor_tail_note='Final receipt/state fsync and exit tail not included in self sample; full five-second allocation charged. Not fully measured project CPU.',
        child_peak_rss_kib=usage.ru_maxrss, supervisor_peak_rss_kib=self_usage.ru_maxrss,
        limits=freeze['limits'], parent_death_guard=True, inventory=inventory,
        failures=failures, classification='post-failure disclosed development only')
    receipt_path = jobdir / 'resource.json'
    if not failures:
        validate_receipt(receipt, spec, job, freeze, freeze_hash, state['in_flight']['approval_sha256'])
    atomic(receipt_path, receipt)
    state['worker_cpu_actual'] += child_cpu
    state['supervisor_cpu_allocation_charged'] += SUPERVISOR_CHARGE
    state['completed'].append(dict(job=job, status=status, resource_sha256=sha(receipt_path)))
    state['in_flight'] = None
    state['stopped'] = bool(failures)
    atomic(STATE, state)
    if not failures:
        LOCK.unlink()
    print(json.dumps(dict(job=job, status=status, child_cpu_seconds=child_cpu,
        supervisor_exclusive_cpu_sample=self_cpu, supervisor_cpu_allocation_charged=SUPERVISOR_CHARGE,
        receipt=str(receipt_path)), sort_keys=True))
    return 0 if not failures else 1


if __name__ == '__main__':
    sys.exit(main())
