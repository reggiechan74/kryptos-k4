# Finite deterministic disclosed development proposal — NOT authorized to run

This is a bounded inventory for approval planning, not implemented fixtures,
drawn data, finalized tests or a fresh-validation protocol. All values below
are proposed literal mathematical examples. No seed is used or accessed. The
failed cohort, v003, historical case replay, sealed truth and all old holdouts
are excluded. The project owner must separately approve implementation and execution.

## 1. Sixteen generic affine-system cases

Field F13; each row is coefficients followed by RHS. These are linear-algebra
unit fixtures, not claims that every generic system arises from the feature
dictionary. Expected dimensions are mathematical specification, not run results.

| ID | n | Original augmented equations | Expected shape |
| --- | ---: | --- | --- |
| A00 | 0 | [] | Consistent singleton empty vector |
| A01 | 0 | [[1]] | Inconsistent |
| A02 | 1 | [] | Full dimension 1 |
| A03 | 2 | [] | Full dimension 2 |
| A04 | 3 | [] | Full dimension 3 |
| A05 | 1 | [[1,4]] | Singleton |
| A06 | 2 | [[1,0,2],[0,1,3]] | Singleton |
| A07 | 3 | [[1,0,0,1],[0,1,0,2],[0,0,1,3]] | Singleton |
| A08 | 3 | [[1,1,0,2]] | Translated rank-one plane |
| A09 | 3 | [[1,1,0,2],[2,2,0,4],[0,0,0,0]] | Same plane as A08 |
| A10 | 3 | [[1,1,0,2],[1,1,0,3]] | Inconsistent |
| A11 | 3 | [[1,0,1,2],[0,1,1,4]] | Translated rank-two line |
| A12 | 3 | [[0,1,0,2],[1,0,0,3]] | Pivot row swap; one free coordinate |
| A13 | 3 | [[0,1,0,2],[0,0,1,3]] | First coordinate free |
| A14 | 2 | [[0,1,5]] | First coordinate free |
| A15 | 3 | [[1,0,1,2],[0,0,1,3]] | Middle coordinate free |

Each future certified fiber is compared with a separate literal ambient-grid
oracle for exact point-set equality. This cross-check is a disclosed unit test,
not an authorized v3 production route or failed-case replay.
These are affine-helper outcomes: A00's one empty vector is NOT an admissible
residual law. The full residual API with no allowed features has no eligible
beta or E dependence and is EMPTY (D00 below), potentially with zero fiber
visits but still charged validation/inventory work. Keep these layers distinct.

## 2. Thirteen base-equivalence cases

Ordered pairs name independent O and published P. Both directions must be
checked internally; reversing an ordered test does not create a new model.

| ID | O and P | Expected base-contract result |
| --- | --- | --- |
| B00 | A05, A02 | Reject weaker P |
| B01 | A02, A05 | Reject stronger P |
| B02 | A05, [[1,5]] at n=1 | Reject translation |
| B03 | A08, A09 | Accept equivalent redundant rows |
| B04 | A12, its reversed row order | Accept |
| B05 | A10, [[1,1,0,5],[1,1,0,6]] | Both bases empty; never feasible |
| B06 | A10, A08 | Reject only O empty |
| B07 | A08, A10 | Reject only P empty |
| B08 | A01, [[2]] at n=0 | Both bases empty; never feasible |
| B09 | A00, A01 | Reject empty/singleton confusion |
| B10 | A04, [[0,0,0,0]] | Accept full-space equality |
| B11 | A06, [[1,1,5],[1,0,2]] at n=2 | Accept changed independent rows |
| B12 | O:[[1,0]], P:[] at n=1, with cuts x=t for all t=1..12 | Reject weakened base even if cuts compensate |

B12 is an adversarial representation-contract test, not an added engine compiler
family; the unchanged compiler still has at most two cuts. Route B12 directly
through the independently tested base-equivalence helper, before any engine
cut-count shape guard, so it tests the intended failed reverse inclusion rather
than a trivial twelve-cut rejection. It is not a full engine-output acceptance
fixture.

## 3. Sixteen certificate mutation slots

One deterministic mutation of an appropriate A-case certificate per slot:
zero scale; self-row add; bad row index; omitted operation; wrong final entry;
wrong original-equation identity; wrong T identity; wrong field; wrong pivot
claim; missing free column; missing kernel vector; dependent kernel vectors;
wrong dimension; wrong particular point; false consistency; malformed numeric
entry. Exact source-certificate/operation targets must be frozen before the
future run, with sufficient valid budgets to reach each intended rejection.
Do not claim all 16 are detectable when a deliberately insufficient budget
exhausts first.
Targets must actually violate the checked obligation. In particular, removing
an allowed no-op may leave a valid certificate and is NOT a rejection test.
For an omitted-operation mutation, pin an operation that changes its actual
intermediate matrix and for which omission breaks the advertised replay result;
do not choose mutation targets after observing test outcomes.

## 4. Forty tiny residual-relation slots

The following eight *proposed* literal Z26 contexts intentionally expose equality,
non-equality and full-symbol versus mod13 equality without any random draw:

    c0=(2,2,5,6,9,10)       c1=(2,15,5,6,9,10)
    c2=(4,7,8,8,11,12)     c3=(6,9,10,11,12,12)
    c4=(8,11,12,15,16,19)  c5=(9,9,14,14,17,17)
    c6=(12,25,6,19,4,17)   c7=(23,23,1,2,3,3)

Ten original-feature domain/sparsity pairs:

| ID | Allowed original features | s |
| --- | --- | ---: |
| D00 | [] | 0 |
| D01 | [28] | 1 |
| D02 | [0,28] | 2 |
| D03 | [2,28] | 2 |
| D04 | [1,7,28] | 2 |
| D05 | [1,7,28] | 3 |
| D06 | [7,28] | 2 |
| D07 | [13,29] | 2 |
| D08 | [28,29] | 2 |
| D09 | [2,29,30] | 3 |

For EACH domain, four deterministic observation/output patterns are proposed:

1. Contexts c0..c7; no observations.
2. Contexts c0..c7; observe row0 value0.
3. Contexts c0..c7 followed by c0 again; observe row0 value0 and row8 value1.
   This is an intentionally inconsistent duplicate-context system.
4. No contexts or observations; feasibility, complete lifts and inventory must
   still be verified without scalar masks.

All 40 complete relations must be compared against an independent raw Z26
coefficient oracle, including every sparse representation, descriptor, piece,
joint tuple and marginal/provenance set. These are tiny bounded support subsets,
not a 31-feature performance benchmark or length-matched recovery claim.

The following are the proposed mathematical semantic statuses, conditional on
completing verification, NOT predictions that untested resource caps will finish:

| Domain | Pattern1 | Pattern2 | Pattern3 | Pattern4 |
| --- | --- | --- | --- | --- |
| D00 | EMPTY | EMPTY | EMPTY | EMPTY |
| D01 | EXACT | EMPTY | EMPTY | EXACT |
| D02 | EXACT | EXACT | EMPTY | EXACT |
| D03 | EXACT | EXACT | EMPTY | EXACT |
| D04 | EXACT | EMPTY | EMPTY | EXACT |
| D05 | EXACT | EMPTY | EMPTY | EXACT |
| D06 | EXACT | EMPTY | EMPTY | EXACT |
| D07 | EXACT | EXACT | EMPTY | EXACT |
| D08 | EXACT | EXACT | EMPTY | EXACT |
| D09 | EXACT | EXACT | EMPTY | EXACT |

Reasons: an empty feature domain has no equality dependence; conflicting
duplicate observations are impossible; unconstrained nonempty domains all allow
13 times an equality indicator. At c0 the lag1 and square1 contributions are
even, so pattern2 forces equality parity zero in D01/D04/D05/D06; their remaining
beta is in B. For the positive pattern2 cases, explicit residual witnesses are
D02: constant13 plus E12 coefficient13; D03: lag2 coefficient1 plus E12
coefficient24; and D07/D08/D09: E34 coefficient13 alone. These are analytic
fixture specifications, not fitted laws or executed results.

If any ordinary fixture exhausts an internal or outer cap, its verification
status is INCOMPLETE and the development suite does not pass that obligation.
Deliberate resource tests instead require their explicitly frozen expected-cap
statuses. No fixture is presumed to complete merely because a ceiling is
proposed, and no outcome-based replacement is allowed.

Each slot has at most three allowed features. Its raw coefficient enumeration
has at most 26^3=17,576 vectors, so 40 slots have the loose finite upper bound
703,040 raw vectors per complete pass. This is a mathematical upper bound only,
not observed work or a cap allocation. Repeated reference/verifier passes and
negative mutation tests must each be charged separately. No v2 cap equivalence
is asserted.

Additional fixed boundary blocks: all 156 exact C descriptors; all 676 lag/square
coefficient pairs for the minimal-support formula; and one duplicated-row joint
counterexample using c0 with allowed feature[28] at s=1. These are arithmetic
boundary checks, not additional full-domain solver cases.

Add one explicitly NONEMPTY shared-old/new finite-trace boundary control outside
the 40 core slots: the single public context c1, allowed feature[28], s=1,
observed value0. Here E12(c1)=0, so excluded old laws +E12 and -E12 and retained
law 13*E12 all give the same prediction0. The completed residual result must
remain nonempty with mask{0}; global exclusion of old functions must not delete
that shared prediction. The repeated-c0 joint control is different: it has 11
retained odd coefficients, 11 equal-coordinate joint tuples and 121 combinations
in the marginal Cartesian product. These two controls explicitly test distinct
nonempty trace obligations, not only zero-output feasibility.

Detailed mutation
targets for the output/provenance checks in PROPOSED-CHECKS must be pinned during
implementation freeze, not selected from favorable outcomes.

## 5. Finite resource-regression slots

Eight integer cap fields, as named in CERTIFICATE-AND-BUDGET, each receive the
same 20 proposed malformed values: true, false, -1, 0.0, 1.0, 0.5, -1.0, NaN,
positive infinity, negative infinity, string"1", None, empty list, empty tuple,
empty dict, arbitrary object, Decimal(1), Decimal(NaN), Fraction(1,1), and an int
subclass instance. Apply each to five paths: build-reference; ordinary verify;
verify with expected memo; EMPTY branch; INCOMPLETE branch. That specifies 800
malformed integer-cap requests per Python mode before any executable fixtures.

For the separate wall cap, propose ten invalid values (true, false, NaN, positive
infinity, negative infinity, -1, string"1", None, empty list, arbitrary object)
on the same five paths: 50 requests. Valid finite float times are not invalid
merely because integer work caps reject floats.

Allocate three boundary-test slots per integer counter (zero, exact, one below)
and one cumulative-no-reset slot per counter: 32 slots. Their expected numeric
work totals CANNOT be finalized until the work-unit schedule, output-record
schema and exact source/certificate generation order are frozen. No promise
that every zero cap yields the same status is made; zero-work and positive-work
paths have different semantics.

## 6. Proposed separate execution envelope, requiring approval

For planning, propose **four sequential bounded workers at most**: author normal and
`-O`, then independent-review normal and `-O`. This is a NEW aggregate allocation
proposal, never a reuse of the failed validation allocation. It replaces the
earlier unapproved author-only suggestion preserved under
`r1-superseded-resource-proposal/`; neither proposal has been executed.
These are the designer's pending planning numbers, not root authorization or
an imposed coordinator cap. No numeric execution allocation is approved.

- Proposed NEW aggregate measured CPU ceiling: **320 seconds**, comprising
  **300 inclusive worker-child CPU seconds INCLUDING independent checks**
  (at most **75 seconds allocated per worker**) plus **20 seconds of exclusive
  launcher/supervisor CPU**. The latter is a separate reserved component, not
  silently omitted or counted again inside the child totals.
- Illustrative per-process nominal CPU settings: **60 seconds soft / 75 hard**,
  with **150 seconds wall watchdog** and **1 GiB address-space limit**.
- Separately reserve **256 MiB address space for the supervisor/watchdog**.
  Proposed concurrent topology is one accounted supervisor and at most one
  active worker, without an unaccounted shell chain. If a watchdog requires an
  additional process, its CPU/memory/topology must fit the explicit supervisor
  reserve and be frozen before execution. The combined proposed address-space
  allocation is **1.25 GiB**, not a claim about observed RSS or a guaranteed
  process-tree physical-memory maximum.
- Maximum four algorithm/test workers, no retry, resume, replacement case or
  additional draw. Orchestration is covered only by the explicit 20-second
  exclusive-CPU reserve; it is not a fifth test allowance.
- A 15-second nominal soft-to-hard gap and 75-second wall margin provide
  explicit headroom; they are not a runtime prediction or speedup claim.
- Record actual inclusive CPU, wall time, exit code/signal and all combinatorial
  counters. If a process fails, is killed, or exceeds the allocated envelope,
  retain its result as incomplete and stop dependent execution. Do not refill
  the budget or reinterpret an OS-limit overrun as a pass.

The previously reported CPU-limit anomaly means nominal OS limits are not a proof
that an observed process cannot exceed them. The 320-second figure is an
allocation/stopping policy, not an unconditional physical guarantee. An overrun
must be disclosed, not hidden; external limit behavior requires its own evidence.
Before any next process, sufficient unused allocation for its entire 75-second
envelope must remain, otherwise stop and seek a separate decision. Independent
check processes are already included, not an uncharged addition.

The future launcher must record each worker's inclusive child CPU exactly once
and its own CPU EXCLUDING those already counted children. Script-internal timing
counters are subsets/diagnostics, not additional charges to sum again. If other
orchestration cannot be measured, label that gap and do not claim complete CPU
accounting; an approval decision must handle it explicitly. The 20-second
reserve is a proposed maximum allocation, not fabricated measured usage.
Exact wrapper/watchdog process topology, supervisor self-CPU instrumentation,
memory settings and applicable enforcement evidence remain freeze prerequisites.

Implementation and all execution still require separate approval. Any later
fresh validation is excluded and needs its own approval/allocation. The exact
work-unit schedule, output-record schema, all internal cap numbers, deterministic
fixture bytes, certificate mutation targets, source pins and execution wrapper
are **implementation-freeze prerequisites**. This proposal does not finalize
or authorize those tests, and does not claim comparability with v2 timings/caps.
Per-call combinatorial cap allocations and the outer four-process cumulative CPU
allocation are separate controls; neither replenishes the other.
