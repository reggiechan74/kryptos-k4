# Exact observation-fiber verification — proposed reference v3

## 1. Fixed problem and the flaw to avoid

The engine's fixed 31 original features, canonical quotient, support bound at
most three, full-symbol equality-before-reduction semantics, and residual
`R = E \ (B union C)` remain unchanged. E requires canonical equality dependence
in F13 or F2; B is beta supported only on constant/lag1; C is exactly the 156
functions constant plus or minus one full-equality indicator. This proposal
does not change which functions are admissible.

For an allowed original support container T of size n, v2 checks a published
piece by enumerating every point of F13^n. The proposed verifier instead
enumerates the complete affine solution space of the *raw public observations*
restricted to T. If that system has rank r, it contains either zero points or
exactly 13^(n-r) points. Full rank means one point, not an ambient 13^n scan.
No observations means r=0, so there is no reduction and no speed guarantee.

**Essential safety condition:** before restricting enumeration, prove that the
producer's published base has exactly the same solution space as the independent
observation base. Merely checking cuts on expected observation solutions is
unsound: a weakened producer base can contain additional points outside that
space. A valid witness or one-way inclusion does not repair that omission.

## 2. Independent reconstruction

Let f_j(x) be the independently implemented original feature functions on a
six-symbol context x in Z26. For each observed row i, the public value y_i
constrains the law F(x_i); neither plaintext truth nor generating parameters
are input to this construction. For each original support T:

    O_T = {a in F13^n : sum_{j in T} f_j(x_i) a_j = y_i mod13
                              for every public observed row i}.

Raw full-equality indicators are evaluated on the original Z26 context before
mod13 or mod2 reduction. Observations are not reconstructed from producer
equations, masks, core certificates, a stored expected result or a declared
rank. They are reconstructed from validated public context/value inputs.

The verifier independently enumerates every maximal T of size
min(s, number of allowed original features), in fixed lexicographic order.
It enumerates every beta subset of the canonical groups covered by T. For each
candidate beta, direct evaluation of the canonical parity function on each
public observed context establishes parity compatibility. B is tested on beta
itself, before any prediction comparison. No beta or T is omitted because a
different piece has the same predictions.

For every parity-compatible, B-eligible (T,beta), a complete certified affine
description of O_T is obtained by the independent elimination procedure in
[CERTIFICATE-AND-BUDGET.md](CERTIFICATE-AND-BUDGET.md). The first implementation
need not cache or share solved certificates across pieces; every actual solve,
certificate replay and repeated point visit is cumulatively charged. Any later
cross-piece caching would be a separately reviewed change, not part of v3.

## 3. Certifying the observation fiber

The certificate checker replays a finite sequence of invertible elementary row
operations from the original augmented matrix, checks the final matrix and
canonical reduced-row-echelon structure, and derives consistency, rank, a
particular point a0 and a complete kernel basis U. It does not trust claimed
rank or a list of kernel vectors merely because those vectors satisfy the
homogeneous equations.

For a consistent observation system, the checker itself reconstructs the basis
using all free columns. The map

    phi(t) = a0 + sum_{k=1}^d t_k U_k,  t in F13^d, d = n-r,

is a bijection onto O_T:

1. Row-equivalence and direct checks imply a0 satisfies the original equations
   and every U_k satisfies their homogeneous part, so the image lies in O_T.
2. U has an identity matrix in the complete list of free coordinates, proving
   independence and injectivity of phi.
3. Every solution has a unique tuple of free coordinates. The certified RREF
   determines all pivot coordinates from that tuple, proving surjectivity.

An inconsistent system has an independently replayed contradiction row and no
points. With n=0, a consistent system has the single empty vector (13^0=1),
whereas an inconsistent right-hand-side-only row has no points. These are not
interchangeable empty-domain cases.

## 4. Producer-base equivalence — mandatory before restricted checks

For every listed producer piece, validate its support/beta and published base P
as finite canonical F13 equations. Independently certify P using the same
certificate contract, without trusting the generic core's transcript.

If exactly one of O_T and P is inconsistent, reject. If both are inconsistent,
their bases are equal as sets, but a published *feasible* piece is still invalid.
If both are consistent, write their certified full descriptions as

    O_T = a0 + span(U),        P = b0 + span(V).

Establish both inclusions against the ORIGINAL equation lists:

- O_T subset P: every equation h*x=c of P satisfies h*a0=c and h*U_k=0
  for every complete kernel vector U_k.
- P subset O_T: every equation g*x=d of O_T satisfies g*b0=d and g*V_l=0
  for every complete kernel vector V_l.

Each test is necessary and sufficient because affine equations distribute over
the displayed complete affine parametrizations. The two tests therefore prove
P=O_T. A missing kernel direction cannot make the test pass because basis
completeness is independently certified from RREF/free columns first.

This design deliberately requires equality of the *unfiltered bases*. It may
reject an alternative published representation whose weaker base and extra
cuts happen to give the same final relation. That representation is outside
the v3 base contract. The fixed engine already publishes the exact observation
base, so no engine change is needed. Do not relax to one-way inclusion or use
cut compensation as a fallback.

An equivalent canonical-RREF comparison could be proved separately, but mutual
affine inclusion is the normative v3 method. No unchecked shortcut is permitted.

## 5. Exhaustive predicate-versus-cuts comparison on the exact fiber

For each parity-compatible, B-eligible (T,beta), enumerate EVERY tuple t in
F13^d in fixed order, reconstruct phi(t), and extend alpha by zero outside T.
Evaluate the frozen canonical residual predicate R(alpha,beta) directly from
its original E/B/C definition. Do not call the engine's compiler or predicate.

For a listed producer piece, evaluate membership in the union of its published
affine forbidden systems directly at the same alpha. The mandatory pointwise
test is

    R(alpha,beta)  iff  alpha satisfies none of the published forbidden systems.

Every observation solution is tested, INCLUDING those rejected by R. Testing
only already-retained points would not detect missing exclusions. For an
unlisted piece, still enumerate its independent observation fiber and record
whether any point satisfies R; a nonempty result proves a missing piece.

Because phi is a bijection and P=O_T has already been proved, pointwise equality
on these 13^d points proves equality of the ENTIRE published filtered relation.
There can be no unseen producer points outside O_T, and no observation solution
is skipped inside O_T. No subtraction of full-model marginal masks occurs.

## 6. Complete inventory and preserved outputs

The expected feasible-piece inventory is derived from the full independent
T/beta traversal, not from the supplied producer list. A piece is expected iff
its beta is eligible/observation-compatible and at least one point of O_T is in
R. Require exact equality of this inventory and the producer's distinct keys.
Reject extra, duplicate, missing, ineligible or empty purported feasible pieces.
In particular, a producer claiming EMPTY must not bypass the independent scan.

For every retained alpha/beta, preserve the v2 semantic objects:

- Canonical descriptors (original 31 F13 coordinates and 25 parity groups).
- Complete alpha point sets per support/beta piece and corresponding F13 masks.
- Full joint prediction tuples, computed from one common descriptor, never a
  Cartesian product of independently allowed scalar values.
- Complete Z26 marginal masks and ALL contributing piece IDs for each value.
- Original sparse coefficient realizations. For each retained point, enumerate
  all original-coordinate parity assignments within T whose group XOR equals
  beta, lift by CRT and retain every resulting original vector. Count even
  discarded parity-assignment trials as lift work. A minimum-support witness
  is selected separately; nonminimal representations are not silently lost.

The coverage condition beta subset G(T) guarantees at least one original lift:
choose one member of T in each active beta group, give it parity 1 and give all
other members parity 0, then CRT-lift the prescribed alpha residues. For a
minimum-support lift, place that parity bit on a nonzero-alpha member whenever
one exists, and otherwise on any T member of the group. Enumerating all parity
assignments with the required group XOR, rather than retaining only this chosen
lift, preserves nonminimal representations and cancellations in inactive groups.

All supports have n<=s<=3, so these lifts stay within the permitted original
support. Every smaller sparse vector embeds in a maximal T; thus the union
contains all permissible original sparse witnesses. Duplicates across T do not
justify discarding a piece or its provenance.

Validate every top-level/core/per-piece witness against the independently
reconstructed residual fiber and the original observations. For original
witnesses, check the common T, beta, exact minimum original support for the
descriptor within that piece T for engine-selected
witnesses, requested scalar value and nonzero canonical coefficient format.
Reference lift sets may contain nonminimal representations even though selected
engine witnesses must be minimal. Generic core certificate transcripts remain
untrusted; their advertised output semantics are checked from the reference.

Full joint sets remain reference-side semantic objects, as in v2. The unchanged
engine is NOT required to add a joint-set output field. If a producer or saved
reference artifact advertises a joint claim, validate that claim against the
complete reference joint relation rather than inferring it from marginals.
Original coefficient representations (including cancellation/nonminimal lifts),
canonical descriptors, support/beta pieces and full joint prediction tuples
retain distinct counts; none of these multiplicities may be silently equated.

## 7. Completeness theorem

Assume validated inputs, independently accepted base certificates, successful
two-way base-equivalence tests, exhaustive free-coordinate enumeration for every
eligible T/beta, and successful pointwise R/cut and output comparisons.

Every original <=s sparse residual law induces some traversed maximal T and
covered beta. Its parity observations pass, its mod13 coefficients lie in O_T,
and bijectivity of phi makes the enumeration visit them. Direct R retains them,
so the law contributes to the reference inventory, lifts and predictions.
Conversely, every retained point has a common original lift in T and satisfies
all field observations and R, hence defines an admissible original law.
The reference relation therefore equals the exact bounded residual relation.
Base equality and pointwise R/cut equivalence make every producer piece equal
to the corresponding reference piece, and inventory equality gives the full
union. Complete masks, joint sets, witnesses and provenance follow by exact
evaluation of that union.

Any budget exhaustion BEFORE all obligations finish yields no exact/empty
verification claim. A DISCOVERED invalid certificate or semantic mismatch is
rejection, not a resource result. Exhaustion can occur before unseen malformed
content is examined; the verifier then reports incomplete checking, not a claim
that all invalid content was rejected (especially under zero work). Producer
INCOMPLETE remains INCOMPLETE and may only be
checked for the absence of leaked partial claims. This theorem does not assert
model membership, unique global-law identification, target compatibility,
completion within resource caps, or historical novelty.
