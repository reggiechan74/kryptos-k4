# Prospective disclosed checks — NOT generated or executed

This document describes generic mathematical fixtures for a possible separately
approved v3 implementation. No fixtures, random seed, cohort inputs or truth
have been drawn or accessed, and no algorithm has run. The failed cohort stays
permanently INCOMPLETE. Its v003 case, any original-case replay, old holdouts and
sealed truth/seed are NOT test sources.

## A. Certificate completeness and exact fibers

Use literal F13 systems of width at most three, with raw coefficients declared
in the future development plan before executing either reference route.

1. n=0 with no equations: one empty vector. n=0 with nonzero RHS: inconsistent.
2. No equations at n=1,2,3: full dimension; fiber and ambient counts coincide.
3. Full-rank identity equations with nonzero RHS: a translated singleton.
4. One equation x0+x1=2 in three variables: a translated rank-one plane, with
   both free directions certified; enumerate exactly 13^2 points.
5. Duplicate and scalar-multiple rows of that equation: same plane, not extra
   rank. Zero equations and reordered independent rows must not change the set.
6. The same left-hand side with incompatible RHS values: a replayable
   contradiction, zero fiber points and nonzero certificate/solve work.
7. Embedded rank-two translated line and systems whose first available pivot
   requires swapping rows. Include free columns before, between and after pivots.

For each tiny generic system, future validation compares certified fiber
enumeration with a separately written literal ambient-grid oracle. This oracle
is only a disclosed development cross-check, not the production v3 verification
route. Include exact tuple/cardinality equality, not only satisfying witnesses.

## B. Base-equivalence adversaries (critical regression)

1. Independent O: x0=0; published P: no equations. On all expected O points,
   producer membership can agree perfectly while P has extra points. V3 MUST
   reject by P subset O failure before restricted enumeration can certify it.
2. Independent O: x0=0 with x1 free; published P additionally fixes x1=0.
   Reject by O subset P failure. One-way containment is insufficient.
3. O fixes x0=1; P fixes x0=2. Reject shifted affine spaces despite equal ranks.
4. Equivalent bases expressed using redundant, reordered or nonzero-scaled rows:
   accept after complete certificates and mutual inclusion.
5. Exactly one base inconsistent: reject. Both inconsistent: base sets equal,
   but reject any claimed feasible piece. Do not infer a feasible singleton.
6. Weakened base with extra cuts intended to compensate: reject the base-contract
   violation even if a separate ambient oracle would find equal filtered sets.

## C. Certificate and rank tampering

Independently mutate a valid future certificate: zero scaling; self-row addition;
out-of-range row; omitted/reordered operation; altered final entry; missing zero
row; wrong original equation hash; another support's binding; incorrect pivot
claim; fake consistency; omitted free column/kernel direction; dependent kernel
vectors; satisfying but nonspanning kernel; wrong translated point; correct
point with wrong dimension. Explicitly verify rejection under normal Python and
`-O`. Merely replaying operations without checking complete RREF is not enough.

Include a malicious full-dimensional space that supplies only one kernel
direction. Its vectors satisfy homogeneous equations but do not span the space;
rank/free-coordinate checks must catch it before any base-inclusion proof.

## D. Fixed residual, all fibers and outputs

Use newly specified literal public six-symbol contexts and bounded subsets of
the UNCHANGED dictionary. Do not copy a failed/held-out case or tune examples
from its result. Predicates remain frozen before any eventual run.

- Full-symbol equality versus field-residue equality, e.g. symbols 0 and 13.
- 13*x²=13*x aliases; cancellation; square-only common-support minimal lifts;
  zero equality coefficients inside a nonlinear-labelled support container.
- E exclusion at equality alpha=0 with no equality beta but an otherwise
  eligible beta; C punctures at alpha=1 and12 with equality beta=1, across all
  26 constants and all three equality indicators and signs.
- Pure-parity equality, B-only beta eligibility, products and multiple equality
  terms. Confirm predicates use descriptors, never raw container labels.
- Distinct old/new functions sharing a finite prediction; cuts are applied to
  functions, not by subtracting all shared marginal values.
- Different beta/support fibers with identical predictions, and multiple pieces
  contributing the same scalar value. All inventory/provenance must survive.
- Feasible no-output requests, contradictory observations, empty residual fibers
  despite consistent observation bases, and nonempty residual fibers.
- Complete original sparse lifts, canonical descriptors and full joint tuples
  compared against independent raw Z26 enumeration on tiny feature subsets.
- A joint tuple assembled from separate marginal witnesses must be rejected
  unless one common descriptor produces it.

For stored-result mutations, test missing piece, duplicate piece, changed beta,
wrong/omitted cut, false EMPTY, omitted provenance contributor, wrong selected
minimal lift, nonresidual witness, wrong core alpha, incorrect full joint set,
and masks correct by accident while the underlying relation is incomplete.

## E. Strict and cumulative resources

Every public budget path, including diagnostic expected memo and producer
INCOMPLETE/EMPTY early branches, rejects bools, integral and fractional floats,
NaN/infinities, strings, None, containers, arbitrary objects, Decimal/Fraction,
int subclasses and negatives for every integer cap. All failures are explicit
and remain active under `-O`.

Design exact-boundary and one-below tests for fiber points, lift trials, solves,
certificate checks, row operations, work units, witness checks and output
records. Include zero-dimensional singleton versus inconsistent zero-point
systems, zero-output feasibility, and zero fiber budget with nonzero algebra
work. Deliberately exhaust the budget late, after masks could otherwise have
been accumulated: no semantic partial result may be emitted.

Use two or more supports/betas to prove that cumulative counters do not reset.
Charge repeated visits and both generated/replayed row operations. Diagnostic
memos do not erase work. Verify that hypothetical legacy ambient counts are
reported separately from actual fiber visits and cannot satisfy or extend a
cap. If a separately approved certificate cache is later added, retain exact
support/field/input identities and replay charges; matrix/prediction equality
must never merge logical provenance.

## F. Operational and evidence gate

A separate implementation approval must freeze new source pins, exact disclosed
fixtures, all cap allocations and expected outcomes before running. Choose an
outer wall/CPU/memory envelope with explicit headroom, record actual observed
wall/inclusive CPU and exit/signal status, and classify worker death as
incomplete. Nominal OS CPU thresholds are not proof of strict elapsed bounds.

Normal and `-O` must agree on all non-resource semantics. Retain failures and
corrections. Independent design review comes first; implementation/development
review follows only if separately authorized. No fresh holdout or target stage
is implied by passing any of these prospective disclosed tests.
