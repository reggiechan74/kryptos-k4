# Residual reference v3 — design/proof only

2026-10-31. **PROPOSED; not implemented or executed.** This folder contains only
a mathematical design, API/resource contract and prospective generic tests.
No source overwrites, solver execution, historical-case replay, new draw,
holdout/truth/seed access, or external publication is authorized by this work.
The failed residual cohort remains permanently **INCOMPLETE**; this proposal
cannot turn it into a pass, resume it, or make it a fresh cohort.

Reviewed predecessor identities remain unchanged:

- Engine `canonical-residual-dev/residual_decoder.py`:
  `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`
- Reference v2 `canonical-residual-reference-v2/reference.py`:
  `618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`

The private administrative register [reference omitted] was reread. Its failed-cohort/no-retry
boundary is retained. The separately authorized task here is design only.
Repository reconciliation is managed separately. Matbalez historical operator scope
remains unresolved; no target admission or novelty claim follows.

## Documents

- [DESIGN.md](DESIGN.md): exact reduced-fiber construction and completeness proof.
- [CERTIFICATE-AND-BUDGET.md](CERTIFICATE-AND-BUDGET.md): independently replayable
  linear-algebra certificates, API and cumulative resource semantics.
- [PROPOSED-CHECKS.md](PROPOSED-CHECKS.md): generic disclosed test specification,
  not generated or executed fixtures.

## Gate

First obtain independent mathematical/design review. Only a separate next
approval may authorize a new versioned implementation and disclosed development
tests. Any later unseen validation needs its own protocol, source pins, caps and
authorization; old inputs, outcomes or seeds must not be reused as fresh.

The only proposed algorithmic change is replacing unconditioned ambient
enumeration with certified observation-fiber enumeration. There is no saturation,
prediction grouping, beta merging, support pruning, alternative solver, cache
optimization, new residual predicate, or silent resource-cap increase.
