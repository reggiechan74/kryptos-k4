# Certificate, API and cumulative resource contract — proposed v3

This is a specification, not code or execution approval. Numeric resource
allocations must be chosen and frozen only with a separately approved disclosed
implementation-validation plan. V2 caps are not silently copied or enlarged.

## 1. Affine certificate format and checker

The actual residual field is F13. Original support width n is in [0,3]; systems
have at most 256 equations, each n+1 canonical built-in integer residues.
No imported producer/core elimination, rank, nullspace or certificate checker
is trusted. The independent reference contains its own generator and a separate
replay checker with explicit failures active under `python -O`.

An `AffineCertificateV3` contains:

- Certificate-format version and q=13, n, equation count.
- A hash of the EXACT original ordered augmented equations and semantic binding
  (input identity, original T, field, observation/producer-base role, source and
  compiler versions). The checker also receives the actual original equations;
  a hash alone is not proof of correspondence.
- An ordered list of elementary operations and the claimed final matrix.
- Claimed pivot/free-column lists, rank of A, rank of [A|b], consistency, and
  optional particular/kernel data. All claims are derived or reconstructed by
  the checker; none are trusted as premises.

Allowed operations on augmented rows of width n+1 are:

1. `swap(i,j)` with valid row indices; this is invertible, including a no-op swap.
2. `scale(i,u)` with canonical nonzero u in F13.
3. `add(i,j,u)` meaning row_i <- row_i + u row_j, with i != j and canonical u.
   A zero u is an allowed no-op; adding a row to itself is NOT this operation.

Reject zero scaling, out-of-range indices, wrong widths/types/residues, unknown
operations, oversized transcripts, and wrong original-equation bindings before
replay. Replay ALL operations from the actual input matrix and require literal
equality with the advertised final matrix. There is no sampled checking.

Check canonical RREF of the FULL augmented matrix, including its RHS column:

- Nonzero rows precede zero rows; every leading entry is 1.
- Leading columns strictly increase, and each leading column is zero in all
  other rows. Entries before a row's leading column are zero.
- Zero rows are exactly zero, and all entries remain canonical residues.
- Derive pivot columns from this matrix rather than trusting a separate list.

The number of pivots is rank([A|b]). Pivots before column n give rank(A).
A pivot in the RHS column is an independently replayed contradiction and means
inconsistent. Otherwise, the original system is consistent. Set every free
variable to zero to reconstruct a particular solution. For each and EVERY free
column f<n, reconstruct one homogeneous solution with that free coordinate 1,
all other free coordinates 0, and pivot coordinates given by the RREF equations.

Additionally check the reconstructed particular against all original equations,
all reconstructed kernel vectors against the homogeneous original equations,
the free-coordinate identity matrix, and dimension d=n-rank(A). These checks
are redundant with valid complete RREF but protect the implementation contract.
The complete free-column list plus identity proves independence; complete RREF
proves spanning. Merely checking A*U=0 does not prove spanning.

The deterministic planned generator uses standard left-to-right Gauss-Jordan
on all n+1 augmented columns with the first available pivot row. For m rows and
w=n+1 columns, it emits at most w(m+1) swaps/scalings/additions: at most 2w pivot
swap/scale operations and w(m-1) elimination operations. The transcript bound
is a proposed format restriction, not a bound for arbitrary elimination code.
Generation and replay both consume budget; neither is free because it is
reference code. An inconsistent certificate is a legitimate algebraic result;
a malformed/false certificate is a verification error, never EMPTY.

## 2. API proposal and identity

The proposed public entry points are conceptually:

- `build_reference_v3(public_request, *, budget)`
- `verify_result_v3(public_request, producer_result, *, budget,
  expected_engine_sha256, expected=None)`
- An exposed certificate-development entry point, if later needed, takes the
  same explicitly validated budget; otherwise certificate helpers are private.

There is no implementation at present and no allocation default is authorized.
`budget` is a required, exact versioned BudgetV3 type. All integer caps require
`type(value) is int and value >= 0`, excluding bools, floats including NaN and
infinity, subclasses, numeric lookalikes and negatives. A wall-time cap, if
represented as a float, requires an exact built-in int/float (not bool), finite,
nonnegative value. Static supported-input size limits remain independent.
Validate ALL caps FIRST, before input processing, memo use, or early returns.

The optional `expected` argument is only a trusted caller diagnostic memo to be
compared with independently reconstructed results. It MUST NOT bypass original
observation reconstruction, complete certificate checking, producer-base
equivalence, pointwise R/cut comparison, or the full support/beta traversal.
The first v3 design introduces no persisted or cross-run memo and no untrusted
expected-result shortcut. Removing this argument entirely would also be safe
but would be an explicit API-version decision, not silent v2 compatibility.

If a later implementation proposal uses observation-certificate memoization,
it must be reviewed separately. Its identity must include the exact original
support, field, public inputs, equation order/normalization, semantic version and
source pins; every use must replay certificates against raw equations and debit
the shared budget. Equal matrices or equal predictions never authorize merging
different supports or beta provenance. No cross-run untrusted memo is admitted.

The request/result identity binds the engine pin
`be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`,
fixed dictionary/grouping/E/B/C semantic versions, allowed original features,
sparsity, ordered contexts/observations, all declared output semantics, and the
eventual reference-v3 source pin. No v3 source pin exists yet. Budget allocation
and execution mode are separately bound in the execution receipt, not invented
as model semantics. A declared source hash does not authenticate execution.

## 3. Explicit cumulative counters and caps

Use ONE meter for an entire public verification invocation, including reference
construction, both base certifications, all inclusion tests, points, lifts,
witnesses and output comparisons. Nested helpers receive the same meter and
cannot reset it. Two separately launched public calls are separate executions;
an outer owner must aggregate their receipts, not treat the second as free.

Required allocation/counter pairs:

| Cap | Charged unit |
| --- | --- |
| `max_fiber_points` | Every visited observation solution alpha for one logical (T,beta), including points rejected by R and repeated visits in another pass/piece. |
| `max_lift_trials` | Every original-coordinate parity assignment tried for a retained descriptor, including rejected XOR assignments. |
| `max_solve_calls` | Every independent elimination invocation, observation or producer base, even if inconsistent or repeated. |
| `max_certificate_checks` | Every replay/rank/free-coordinate certificate verification, including memo replay if separately approved. |
| `max_row_operations` | Every generated elementary row operation PLUS every replayed operation; report generated and replayed subtotals. |
| `max_work_units` | Explicit deterministic work charges defined below; not CPU cycles. |
| `max_witness_checks` | Every advertised core, top-level, or per-piece witness checked. |
| `max_output_records` | Every retained reference/output record insertion or verification storage allocation charged by the eventual frozen schema; distinct logical records cannot be hidden by aliasing. |
| `max_seconds` | Cooperative wall time checked at every charged block. |

No counter is reset by a new support, beta, scalar, certificate, or failed local
candidate. A cap check happens BEFORE the operation or allocation it protects.
For a consistent certified fiber, preflight its exact 13^d point requirement
against remaining `max_fiber_points` and a minimal remaining work lower bound
before generating tuples. This does not guarantee enough work remains for cuts,
lifts, witnesses or set storage; cumulative checks continue throughout. For an
inconsistent fiber, charge its algebra/certificates but zero fiber points.

The frozen implementation must specify its `work_units` schedule, at least:

- Input/schema validation per examined scalar/container record; feature and
  original-equation construction; every parity-observation check.
- Matrix copying, every pivot-search cell examined, and generated row updates
  by full row width; certificate schema checks and full row-operation replay.
- Complete RREF/rank inspection, all original-equation particular/kernel tests,
  free-coordinate identity checks and both affine inclusion directions.
- Each reconstructed point coordinate, direct E/B/C inspection, every tested
  cut-equation component, scalar projection, CRT/lift operation and witness test.
- Actual exact-set comparisons, joint tuple construction and record insertion.

One modular multiply/add component may be one work unit; an implementation must
state that convention explicitly and charge all relevant loops. This is a
reproducible accounting convention, not an exact Python-operation or CPU bound.
Neither certificates nor the independently rebuilt oracle are unmetered work.

Statistics must distinguish:

- `observation_fiber_points_examined`: actual charged visits (new units).
- `retained_residual_points`, `lift_trials`, solves, replay work and witnesses.
- `legacy_ambient_points_equivalent`: optional mathematical comparator
  sum 13^|T| over the completed feasible-piece inventory, explicitly hypothetical
  and NOT actual work or an available cap. It does not include prior runs.

Do not rename `max_points=2_000_000` to a new metric while keeping the same
protocol claim. V3 needs an explicit new allocation. No increase, retry, resume,
or reinterpretation of the failed cohort's frozen caps is authorized here.
Per-piece point reduction does not prove total-runtime improvement: all eligible
pieces, inconsistent systems, certificate overhead, repeated beta fibers and
output requirements still matter.

## 4. Failure and zero-cap semantics

- Malformed input/cap: explicit validation error before shortcuts.
- Invalid certificate, base inequivalence or semantic mismatch: explicit
  verification rejection, never transformed into EMPTY or budget exhaustion.
- Exhausted valid verification budget: `VERIFICATION_INCOMPLETE`, or a dedicated
  ReferenceLimit caught only at the wrapper. No verified masks, sets, witnesses,
  or complete-inventory claims escape; diagnostic consumed-work counters may.
- Well-formed producer INCOMPLETE with all partial semantic fields null:
  `PRODUCER_INCOMPLETE`, meaning only no-partial-claim format was checked. This
  cannot become VERIFIED_EMPTY or VERIFIED_EXACT.
- Completed nonempty relation: VERIFIED_EXACT only after every proof obligation.
- Completed empty relation: VERIFIED_EMPTY only after complete independent
  inventory exhaustion; lack of producer pieces alone is insufficient.

Zero fiber cap can permit an algebraically inconsistent collection of eligible
pieces, or a no-enumeration producer-INCOMPLETE check, if all OTHER budgets allow
the required work. A consistent zero-dimensional fiber contains one point and
therefore requires one fiber unit. Zero work budget cannot be advertised as
having performed nonzero validation/linear algebra merely because fiber count
is zero. The budget and result contracts must state precisely which header-only
validation, if any, occurs before metering; no hidden expensive pass is allowed.

## 5. Outer process limits are a separate operational layer

Combinatorial counters are not elapsed CPU time or resident memory. Preserve an
external wall watchdog, CPU/resource settings, exit/signal classification and
inclusive process receipts in any later disclosed validation plan. A killed or
missing worker is incomplete/no verifier result, never exact or empty.

The retained record reports that the failed cohort recorded 47.947867 CPU seconds under
nominal 40/41-second CPU settings; the OS-level cause remains unresolved. This
design neither diagnoses that receipt nor accesses/replays its case. It must not
claim nominal RLIMIT_CPU settings are perfectly strict observed cutoffs. Future
approved disclosed fixtures need explicitly frozen generous headroom and both
wall/CPU receipts, with no dependent completeness claim if an outer limit fails
to behave as expected. The canceled original replay stays canceled; v003 and all
failed-cohort material are excluded from the prospective v3 fixture set.
