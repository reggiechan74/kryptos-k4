"""Fixed external CPU/address-space/wall bound; child death is INCOMPLETE."""
import argparse
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--optimized', action='store_true')
parser.add_argument('--script', default='test_residual.py', choices=['test_residual.py', 'run_development.py'])
args = parser.parse_args()
here = Path(__file__).resolve().parent
name = args.script.removesuffix('.py') + ('-optimized' if args.optimized else '')
def limits():
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_AS, (768*1024**2, 768*1024**2))
start = time.monotonic()
command = [sys.executable] + (['-O'] if args.optimized else []) + [str(here/args.script)]
try:
    completed = subprocess.run(command, cwd=here, capture_output=True, text=True,
                               timeout=180, preexec_fn=limits)
    receipt = dict(command=command, exit_code=completed.returncode, stdout=completed.stdout,
                   stderr=completed.stderr, wall_seconds=time.monotonic()-start,
                   outer_cpu_seconds=120, outer_address_space_bytes=768*1024**2,
                   outer_wall_seconds=180, status='COMPLETED' if completed.returncode == 0 else 'FAILED_OR_INCOMPLETE')
except subprocess.TimeoutExpired as exc:
    receipt = dict(command=command, status='INCOMPLETE', reason='external wall termination',
                   stdout=str(exc.stdout), stderr=str(exc.stderr), wall_seconds=time.monotonic()-start)
(here/(name+'-launcher.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
sys.exit(0 if receipt['status'] == 'COMPLETED' else 1)
