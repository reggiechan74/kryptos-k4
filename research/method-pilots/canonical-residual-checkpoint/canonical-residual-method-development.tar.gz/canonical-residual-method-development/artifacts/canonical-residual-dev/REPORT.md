# Canonical residual development result

2026-10-31. **PASS on the frozen disclosed development suite, independently
verified under normal Python and `-O`. Not target admission or a holdout result.**

## Exact implementation

- Engine `residual_decoder.py`: SHA256
  `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`.
- Fixed pre-run plan `PLAN.md`: SHA256
  `9d41f4423cdb3e3e9697839b7cacf263c38fd274c55910ea5fcc33f97f9d1da4`.
- Generator `development_cases.py`: SHA256
  `0c85ad85c6f82dd440063862c50f6c426a6c40a2b33da34c478f653f95df1ddf`.
- Reviewed generic core `affine_filter.py`: SHA256
  `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`.

No implementation correction was needed after execution. Frozen source hashes
still match. The relation is exactly the fixed canonical E minus(B union C),
with common original support≤3 and minimum sparse lifts. Every feasible
support/beta alpha-minus-cuts fiber survives with complete cross-piece provenance.
No scalar mask is subtracted from an old model's mask. No saturation or beta
prediction-grouping optimization is present.

## Producer checks

Both modes:10 tiny complete-set cases,22,960 directly enumerated original Z26
coefficient vectors,199,927 compiler point equivalences,156 exact C laws,
396 marginal witness checks,7 cap failures,9 malformed rejections,3 residual
witness rejections. Aliases, empty/zero containers, B eligibility, equality
before reduction, punctures at0/±1 and joint/marginal distinctions are explicit.

Four pre-frozen full31-feature cases each use a fresh length97 symbol stream,
91 modeled contexts,24 disclosed observations, s≤3 and seed202610311949.

| Case | Status | Feasible pieces | Canonical functions | Joint91-row predictions |
| --- | --- | ---: | ---: | ---: |
| fresh31-0 | EXACT |116|675|675|
| fresh31-1 | EXACT |57|13|13|
| fresh31-2 | EXACT |90|1,476|1|
| fresh31-3 | EXACT |8|50|50|

Function/joint counts are from the independent complete oracle, not inferred
from the number of containers or scalar masks. No law-identification claim is
made. The deliberately disclosed C plant in case2 is excluded as a global
function, but the fixed random stream has no equality events. Hence1,476
different residual laws still predict its same constant7 trace. This fixture
was retained unchanged. Even an exactly unique finite trace does not identify
the intended global law, prove model membership, or establish historical novelty.

## Independent complete reference

Review directory: `/ARCHIVE_WORKSPACE/canonical-residual-reference/`.
Independent `reference.py` SHA256:
`51228db92f9b1feaab51895e76099c6d755060a2244890ab9806a57051be7b00`.
Read `REVIEW.md`, `audit-normal.json`, `audit-optimized.json`, `reference.py`
and `audit_results.py` together. The independent oracle imports neither the
producer compiler nor the generic field solver. It enumerates original-coordinate
F13/F2 solutions with independent RREF and CRT, then applies the canonical
predicate directly. Tiny truth is separately cross-checked by raw Z26 enumeration.

Each audit mode exhaustively checked288 feasible pieces,602,004 ambient F13
points,29,883 core alpha witnesses and1,284 original sparse witnesses over all14
fixtures. Every fiber, marginal and all-piece provenance agrees.17 deliberate
tamper cases are rejected, including excluded C/B witnesses, missing cuts/fibers,
incorrect masks/provenance, core/source/instance identity changes, false EMPTY
and leaked INCOMPLETE masks. Six independently exercised exhausted budgets
suppress all partial result fields; a zero IE-term budget correctly remains exact
on this at-most-two-cut small-union route.

The generic module's certificates are not accepted on trust. The independent
development verifier reconstructs each complete finite alpha set and compares it
with the separate original-coordinate oracle. Its bounded enumeration is not a
production-grade compact certificate format or a guarantee outside its caps.

## Resource receipts, not benchmark claims

| Process | CPU seconds | Peak RSS KiB |
| --- | ---: | ---: |
| Producer tiny normal |2.6835|14,592|
| Producer tiny optimized |1.3037|18,720|
| Producer full31 normal |5.5588|28,852|
| Producer full31 optimized |7.0950|31,740|
| Independent full audit normal |5.7120|36,604|
| Independent full audit optimized |11.3854|37,740|

The four full31 cases cumulatively charged190,088 wrapper steps,24,510,401
generic work units and31,983 generic solves, with zero inclusion-exclusion terms,
in each producer mode. Work units are not all Python operations or CPU cycles.
Producer outer launchers enforce120CPU seconds/768MiB/180wall seconds; each
full31 call has25wall seconds. All disclosed cases completed; deliberate cap
tests correctly returned INCOMPLETE, not EMPTY. No speedup claim follows.

## Handoff and remaining gates

Completed: exact development compiler/decoder, complete compressed relation and
original sparse witness contract, frozen disclosed fixtures, normal/-O runs,
independent complete oracle and tamper/failure review. No blocked, denied or
uncertain operation occurred in this task. Main ledger/publication reconciliation
is managed separately; no remote edit was made here.

Historical matbalez recurrence support remains **unresolved**. This validation
does not establish that R is historically untried. No target data/matrix/fit,
prior held-out input, fresh residual holdout, or target search was used. No K4
admission follows automatically. Any next target decision needs explicit scope,
prior-art uncertainty resolution/decision, independently reviewed admission and
a separately frozen protocol. Saturation remains a separate future optimization,
not part of this correctness result.
