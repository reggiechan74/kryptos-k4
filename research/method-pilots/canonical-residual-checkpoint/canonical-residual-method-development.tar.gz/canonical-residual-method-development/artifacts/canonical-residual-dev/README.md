# Exact canonical residual decoder — development only

Implements the **fixed** residual `R = E \ (B ∪ C)` on the unchanged 31-feature
dictionary with at most three original nonzero coefficients. This is software
development on disclosed synthetic fixtures, **not K4 admission, a holdout,
a new cipher experiment, a solution, or a novelty/performance claim**. Precise
historical matbalez recurrence scope remains unresolved.

The pre-run [PLAN](PLAN.md) and [source freeze](FREEZE-SHA256SUMS) are immutable.
Read the [result report](REPORT.md) and the [independent review](../canonical-residual-reference/REVIEW.md).
The generic affine module is vendored byte-for-byte at the independently reviewed
SHA256 `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`.

## Contract

```python
from residual_decoder import decode, Budget
result = decode(
    contexts=[[0,0,1,2,3,4], [0,13,1,2,3,4]],
    observed={},              # row index -> observed F(context), NOT plaintext
    sparsity=2,
    allowed_features=[2,28],  # explicit tiny subdictionary; default is all 31
    budget=Budget(),
)
```

Inputs are canonical Z26 symbols, sorted distinct original feature indices,
0≤sparsity≤3, at most128 contexts, and finite explicit budgets. No target parser,
target data, canonical ciphertext, old holdout inputs, or blind study data exists
here. The four full-dictionary development streams are freshly generated with
public seed202610311949; the generator and plants were fixed before execution.

| Status | Meaning |
| --- | --- |
| EXACT | Nonempty complete feasible relation; every requested marginal value has a valid sparse witness. |
| EMPTY | Complete exhaustion proves no function in the declared bounded residual domain. Empty masks are not forced plaintext. |
| INCOMPLETE | Resource cap; masks, witnesses, pieces, provenance and feasibility witness are all `None`. No partial exact/empty claim. |

Malformed requests raise `ValueError`; certificate defects raise an error rather
than being relabeled as resource exhaustion. Outer worker death is recorded by
the launcher as failed/incomplete, never as an exact solver result.

## Why the pieces are exact

For each maximal original support container T, beta ranges over **all** subsets
of covered canonical groups, not independent fieldwise minimum supports. A
smaller support embeds by zero-padding. Conversely every alpha supported in T
and beta supported in G(T) has a common original lift inside T. The constructive
lift has exact global minimum support: nonzero alpha coordinates plus one extra
coordinate for each beta bit outside G(supp(alpha)). In a lag/square pair it
allocates parity to an already-active coordinate when possible; otherwise to
one member of T. The alias `13*x² = 13*x` is therefore preserved, including a
square-only support container.

Beta not in B is checked separately for **every** piece. B means beta supported
only on constant/lag1, including zero. Then the compiler imposes:

1. If no equality beta is active: remove the affine alpha set with all three
   equality coefficients zero (the complement of E).
2. If beta is supported only on constant and one equality group q, with beta_q=1:
   remove each of `alpha_q=1` and `alpha_q=12`, with alpha outside{constant,q}=0.
   These are exactly C, with constant unrestricted. Otherwise there is no C cut.

There are at most two cuts. They are removed by the reviewed generic core
**before** projection. Neither support-container names nor observed outputs
define eligibility. No full-model mask subtraction is performed. There is no
saturation optimization or merging of beta fibers by prediction.

## Complete fibers, witnesses, and provenance

`pieces` retains every feasible `(T,beta)` with exact alpha equations and cuts,
plus generic marginal/feasibility witnesses. These compressed fibers preserve
all canonical functions. Their original coefficient realizations are all CRT
parity assignments inside T whose group sums equal beta, including nonminimal
representations; the output's constructive representatives are minimum-support.
An individual function may occur in several containers, and different functions
may have the same finite prediction. Piece count, coefficient count, global
function count, and trace count are **not** interchangeable.

Each top-level marginal witness includes its piece ID and original sparse vector.
`provenance[row][value]` lists **every** contributing piece. A full joint candidate
must come from one common piece and one alpha; `check_joint` verifies this for a
trusted in-memory result. Combining one allowed value from each marginal is not
a joint-feasibility test. `check_sparse_witness` is a strict witness checker, not
a proof that an entire result is complete.

The dependency exports no untrusted-result verifier. The separate independent
reference in `/ARCHIVE_WORKSPACE/canonical-residual-reference/` supplies complete
bounded original-coordinate enumeration and verifies exact fiber sets, masks,
all provenance and witnesses without trusting the generic certificates. It is a
development oracle with explicit point/outer resource caps, not a production
cryptographic certificate format. Run/audit receipts and reviewed pins must stay
with exported results; a hash alone is not evidence of mathematical correctness.

## Frozen development checks

```sh
PYTHONDONTWRITEBYTECODE=1 python launch.py
PYTHONDONTWRITEBYTECODE=1 python launch.py --optimized
PYTHONDONTWRITEBYTECODE=1 python launch.py --script run_development.py
PYTHONDONTWRITEBYTECODE=1 python launch.py --optimized --script run_development.py
```

Every process has120CPU seconds,768MiB address space and180wall seconds; each
full31 decoder call has25wall seconds and cumulative work/solve/step/piece caps.
The internal meter is cooperative and not a count of every Python operation.
The outer limits remain necessary. Runs completed well below the envelope.

Producer normal and `-O` runs passed the same10 tiny complete-set comparisons,
22,960 direct original coefficient vectors,199,927 compiler equivalence points,
156 C laws,396 marginal witness checks,7 deliberate cap failures,9 malformed
requests and3 wrong residual witnesses. Coverage includes aliases, zero equality
coefficients in nonlinear containers, F13 punctures at0/±1, B eligibility, full
equality before field reduction, overlapping excluded/retained predictions and
non-Cartesian joint predictions. All four fresh31 cases returned EXACT, with
116/57/90/8 feasible support-beta pieces in both modes. These are overlapping
compressed fibers, **not counts of identified laws**.

The excluded C plant in fresh31-2 still permits other residual functions matching
its finite observations. Its90 feasible pieces are expected ambiguity, not failed
C subtraction and not evidence that the historical law is new. A method that
subtracts old prediction masks would incorrectly remove valid residual outputs.
The independent reference finds1,476 distinct residual global functions but only
ONE common91-row prediction in this case. The pre-frozen stream happens to have
zero occurrences of all three equality indicators, so all those different laws
agree with the constant7 finite trace. This degenerate fixture is retained without
replacement. The other three function/joint-prediction counts are675/675,13/13
and50/50. Finite-trace uniqueness is not global-function identification.

Resource receipts: normal tiny2.6835CPU seconds/14,592KiB peak RSS; optimized
tiny1.3037/18,720KiB. Full31 normal5.5588CPU seconds/28,852KiB; optimized
7.0950/31,740KiB. These are observed totals, not controlled speed comparisons.

## Boundaries and next gate

This engine does not establish model membership, identify intended laws from
finite observations, recover initial plaintext, resolve historical prior art,
or authorize K4 use. Independent review of this exact implementation and any
later changed source is required. No target-stage approval or fresh residual
holdout follows automatically. Main-repository ledger/publication reconciliation
is managed separately; this directory makes no remote changes.
