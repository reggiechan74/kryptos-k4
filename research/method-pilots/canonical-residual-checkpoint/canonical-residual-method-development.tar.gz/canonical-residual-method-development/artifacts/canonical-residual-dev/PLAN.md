# Canonical residual development freeze — 2026-10-31

Status: DEVELOPMENT ONLY. This plan precedes every test execution in this directory.
No target data/matrix/fit, prior held-out input, fresh holdout, remote edit, or
automatic model admission. Historical matbalez recurrence scope remains unresolved.
No saturation or parity-fiber grouping optimization is introduced.

## Fixed mathematical scope

31 features: constant; six lags; six squares; 15 pair products in lexicographic
order; full-Z26 equality indicators E12,E34,E56, evaluated BEFORE field reduction.
Canonical alpha has 31 F13 entries; beta has 25 F2 entries with lag/square merged.
The global functions have minimum original support at most s, with 0<=s<=3.
The only residual is R=E minus (B union C). E has some canonical equality entry
nonzero in either field. B has beta supported only on {constant,lag1}. C is exactly
the 156 functions b±E_q, with b in Z26 and q one of the three equality features.
No predicate is derived from fit quality or changed after seeing results.

For every maximal original support container T (size min(s,m) in an explicitly
declared allowed-feature subset of size m), enumerate every beta supported on
G(T). Retain exactly observation-compatible beta not in B. Alpha is supported
on T and satisfies the F13 observation equations. If beta has no equality bit,
exclude the affine set with all equality alpha entries zero. If beta is supported
on {constant,q}, beta_q=1, exclude the two affine sets alpha outside {constant,q}
zero and alpha_q=1 or12. Every exclusion is removed BEFORE scalar projection.

Completeness: any original <=s sparse vector can be padded with zero coordinates
to a maximal T. Its alpha lies there and beta is supported on G(T). Conversely
an alpha/beta in such a container has an original lift inside T of support <=s.
The lift uses nonzero-alpha coordinates first and, only for a zero-alpha group
with beta=1, one coordinate already in T. Its cost is exactly |supp(alpha)| plus
the count of beta bits outside G(supp(alpha)). Thus zero coefficients cannot
bypass E/B/C, which are tested on descriptors rather than container labels.

## API/output and trust

`decode(contexts, observed, sparsity=3, allowed_features=all31, budget=...)`
uses arbitrary explicitly supplied six-symbol development contexts. `observed`
constrains F(context), not plaintext; no target-specific parser exists.
Every feasible (T,beta) compressed alpha-minus-cuts fiber is retained, including
overlapping fibers and different beta with identical predictions. This retains
all original sparse witnesses implicitly; coefficient, function, finite-trace
and marginal multiplicities are not conflated. Every row/value has an original
sparse witness and a list of ALL contributing piece IDs. A joint candidate must
belong to one common piece and one alpha; marginal values cannot be combined.

EXACT means a nonempty complete relation and complete requested marginals.
EMPTY means the entire bounded relation was exhausted and is empty (never forced
certainty). INCOMPLETE means a cap was hit and publishes no masks, pieces,
witnesses or provenance; an externally killed worker has no solver result.
Exceptions for malformed input or failed certificates are not rewritten as EMPTY.
Logical identity binds canonical compiler version, inputs, domain, engine source
hash and pinned generic source hash. No persistent cache is introduced.

The generic core is vendored byte-identically at SHA256
1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d.
It has no exported untrusted-result verifier. An independent implementation must
enumerate complete finite reference solution sets and verify completeness,
every retained fiber, residual witness, provenance and tamper rejection.

## Frozen disclosed fixtures and checks

Tiny tests use explicitly bounded subsets of the unchanged dictionary, s=0..3.
Direct original coefficient enumeration (26 residues) provides complete truth.
Required cases: 13*x^2=13*x aliases; zero equality coefficient in an equality
container; F13 punctures at 0 (E) and ±1 (C); all C signs and constants; B-only
eligibility; mixed excluded/retained functions with the same finite prediction;
equality before reduction (symbols 0 and13); wrong residual witness rejection;
joint-versus-marginal counterexample; zero/tight caps and malformed inputs.
The test generator seed is 202610311949; fresh 31-feature development contexts
use random.Random with that seed, no imported cipher/holdout artifacts. Four
fresh length97 symbol streams yield 91 six-lag contexts, with 24 disclosed
evenly spaced observed rows. Plants: {E12:2,lag2:3}; {E34:13,lag1:13};
{E56:25,constant:7}; {E12:2,lag2:2,lag3:13}. These cover residual, residual
pure-parity equality, excluded C, and residual mixed-field cases. Plants need
not be uniquely identified; reference equality, not recovery rate, is the test.

Normal and -O runs are required; checks use explicit exceptions. Each outer
process gets 120 CPU seconds, 768 MiB address space, 180 seconds wall. Decoder
budgets are fixed in source before execution; reference enumeration receives
its own explicit point cap. Small fixtures must complete exactly; deliberate
budget fixtures must return INCOMPLETE without partial claims. Fresh full31
fixtures may legitimately be incomplete under their frozen caps; this is not
an empty result. Resource totals are receipts, not performance claims.

## Evidence read before work

private administrative register [reference omitted]; k4-parity-validation-publisher AGENTS,
HYPOTHESES current state/queue, EXPERIMENTS, EXTERNAL-PRIOR-ART and POLICY;
canonical quotient REPORT; pinned generic code and independent REVIEW;
OPERATOR-MAP, CLARIFICATIONS and INDEPENDENT-OPERATOR-AUDIT.
This task is the separately assigned engineering work, not a new K4 experiment.
Main ledgers/publication are reconciled separately; no remote changes here.
