"""Fresh disclosed synthetic development fixtures, never holdouts."""
import random

SEED = 202610311949


def feature_row(x):
    pairs = [(i, j) for i in range(6) for j in range(i+1, 6)]
    return ([1] + list(x) + [v*v % 26 for v in x]
            + [x[i]*x[j] % 26 for i, j in pairs]
            + [int(x[0] == x[1]), int(x[2] == x[3]), int(x[4] == x[5])])


def cases():
    contexts = [[0, 0, 1, 2, 3, 4], [0, 13, 1, 2, 3, 4],
                [1, 1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6],
                [2, 3, 4, 4, 6, 6], [13, 0, 0, 0, 0, 0]]
    tiny = [
        dict(name='zero-budget-domain', contexts=contexts[:2], observed={}, sparsity=0, allowed_features=[0, 28]),
        dict(name='one-equality', contexts=contexts, observed={}, sparsity=1, allowed_features=[28]),
        dict(name='constant-equality-C-punctures', contexts=contexts[:4], observed={}, sparsity=2, allowed_features=[0, 28]),
        dict(name='equality-E-puncture-with-lag2', contexts=contexts, observed={}, sparsity=2, allowed_features=[2, 28]),
        dict(name='alias-pair-equality', contexts=contexts, observed={}, sparsity=2, allowed_features=[1, 7, 28]),
        dict(name='nonlinear-container-zero', contexts=contexts, observed={i: x[1] for i, x in enumerate(contexts)}, sparsity=2, allowed_features=[2, 28]),
        dict(name='same-prediction-old-new', contexts=[contexts[0]], observed={0: 0}, sparsity=2, allowed_features=[0, 28]),
        dict(name='joint-not-cartesian', contexts=[contexts[0], contexts[0]], observed={}, sparsity=1, allowed_features=[28]),
        dict(name='no-rows-feasibility', contexts=[], observed={}, sparsity=2, allowed_features=[2, 28]),
        dict(name='three-coordinate', contexts=contexts, observed={0: 2, 1: 13}, sparsity=3, allowed_features=[2, 7, 28]),
    ]
    rng = random.Random(SEED)
    plants = [{28: 2, 2: 3}, {29: 13, 1: 13}, {30: 25, 0: 7}, {28: 2, 2: 2, 3: 13}]
    full = []
    for number, plant in enumerate(plants):
        stream = [rng.randrange(26) for _ in range(97)]
        rows = [[stream[i-j] for j in range(1, 7)] for i in range(6, 97)]
        inds = sorted({(i*90)//23 for i in range(24)})
        observed = {i: sum(feature_row(rows[i])[j]*v for j, v in plant.items()) % 26 for i in inds}
        full.append(dict(name='fresh31-%d' % number, contexts=rows, observed=observed,
                         sparsity=3, allowed_features=list(range(31)), disclosed_plant=sorted(plant.items())))
    return tiny, full


def arguments(case):
    return {k: case[k] for k in ('contexts', 'observed', 'sparsity', 'allowed_features')}
