"""Disclosed bounded development checks; independent review is separate."""
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import resource
import sys
import time
import residual_decoder as d
from development_cases import cases, arguments, feature_row


def check(ok, message):
    if not ok:
        raise RuntimeError(message)


def raw_truth(case):
    # Direct original-Z26 coefficient enumeration, no solve or affine projector.
    features = case['allowed_features']
    rows = [feature_row(c) for c in case['contexts']]
    masks = [set() for _ in rows]
    functions = set()
    count = 0
    for k in range(min(case['sparsity'], len(features))+1):
        for support in combinations(features, k):
            for vals in product(range(1, 26), repeat=k):
                count += 1
                theta = [0]*31
                for j, v in zip(support, vals):
                    theta[j] = v
                a = tuple(v % 13 for v in theta)
                b = tuple(([theta[0] % 2] + [(theta[j]+theta[j+6]) % 2 for j in range(1, 7)]
                           + [theta[j] % 2 for j in range(13, 31)]))
                E = any(a[j] or b[j-6] for j in (28, 29, 30))
                B = not any(b[2:])
                C = any(b[q-6] == 1 and a[q] in (1, 12)
                        and all(not b[g] for g in range(25) if g not in (0, q-6))
                        and all(not a[j] for j in range(31) if j not in (0, q)) for q in (28, 29, 30))
                if not E or B or C:
                    continue
                values = [sum(row[j]*v for j, v in zip(support, vals)) % 26 for row in rows]
                if any(values[i] != v for i, v in case['observed'].items()):
                    continue
                functions.add((a, b))
                for mask, value in zip(masks, values):
                    mask.add(value)
    return [sorted(m) for m in masks], functions, count


start = time.process_time()
counts = dict(tiny_cases=0, raw_vectors=0, witnesses=0, C_laws=0,
              compiler_points=0, caps=0, malformed=0, negative_witnesses=0)
tiny, _ = cases()
results = {}
for case in tiny:
    result = d.decode(**arguments(case))
    masks, functions, vectors = raw_truth(case)
    counts['raw_vectors'] += vectors
    check(result['status'] == ('EXACT' if functions else 'EMPTY'), case['name']+' status')
    check(result['masks'] == masks, case['name']+' complete marginals')
    for i, mapping in enumerate(result['witnesses']):
        for value, witness in mapping.items():
            check(d.check_sparse_witness(**arguments(case), theta=witness['theta'], row=i, value=value), 'witness')
            counts['witnesses'] += 1
    results[case['name']] = result
    counts['tiny_cases'] += 1

# Alias and minimum-support semantics.
left, right = [0]*31, [0]*31
left[1], right[7] = 13, 13
check(d.descriptor(left) == d.descriptor(right), '13x^2=13x alias')
for x in range(26):
    check((13*x*x-13*x) % 26 == 0, 'global alias')
for a0, a1, bit in product(range(13), range(13), range(2)):
    alpha = [0]*31
    alpha[1], alpha[7] = a0, a1
    beta = [0]*25
    beta[1] = bit
    theta = d.lift((1, 7), (a0, a1), (1,) if bit else ())
    check(len(theta) == d.support_cost(alpha, beta), 'pair minimal support')
    check(all(j in (1, 7) for j, v in theta), 'common original support')
check(d.lift((7,), (0,), (1,)) == [[7, 13]], 'square-only lift must stay inside T')
check(d.features([0, 13, 0, 0, 0, 0])[28] == 0, 'full equality before mod13')

# Exhaust complete C signs/constants on each of the three equality indicators.
for q in (28, 29, 30):
    equal = [0, 0, 1, 1, 2, 2]
    unequal = [0, 1, 1, 2, 2, 3]
    for constant, sign in product(range(26), (1, 25)):
        vector = [0]*31
        vector[0], vector[q] = constant, sign
        check(not d.residual(*d.descriptor(vector)), 'C descriptor exclusion')
        result = d.decode([equal, unequal], {0: (constant+sign) % 26, 1: constant},
                          sparsity=2, allowed_features=[0, q])
        check(result['status'] == 'EMPTY', 'exact C function exclusion')
        counts['C_laws'] += 1

# Exhaust relevant compiler fibers in all maximal supports from this small domain.
domain = (0, 1, 7, 2, 28, 29)
for support in combinations(sorted(domain), 3):
    groups = sorted({d.GROUP[j] for j in support})
    for k in range(len(groups)+1):
        for beta in combinations(groups, k):
            if not any(g not in (0, 1) for g in beta):
                continue
            cuts = d.compile_exclusions(support, beta)
            bits = [int(g in beta) for g in range(25)]
            for values in product(range(13), repeat=3):
                alpha = [0]*31
                for j, v in zip(support, values):
                    alpha[j] = v
                survives = all(not all(sum(x*y for x, y in zip(row[:-1], values)) % 13 == row[-1]
                                       for row in cut) for cut in cuts)
                check(survives == d.residual(alpha, bits), 'compiler equivalence')
                counts['compiler_points'] += 1

# Explicit F13 punctures, including zero-alpha equality with parity13 retained.
one = results['one-equality']
piece = next(p for p in one['pieces'] if p['beta'] == [22])
check(piece['core']['masks'][0] == [v for v in range(13) if v not in (1, 12)], 'C +/-1 punctures')
check(0 in piece['core']['masks'][0], 'pure parity equality13 survives C')
point = next(p for p in results['equality-E-puncture-with-lag2']['pieces'] if p['beta'] == [2])
check(point['core']['masks'][0] == list(range(1, 13)), 'E zero puncture')
check(results['nonlinear-container-zero']['status'] == 'EMPTY', 'zero equality cannot satisfy E')

# Excluded and residual functions can predict exactly the same finite output.
mixed = results['same-prediction-old-new']
check(mixed['status'] == 'EXACT' and mixed['masks'] == [[0]], 'full-mask subtraction would lose residual 0')
for wrong in ([[0, 25], [28, 1]], [[28, 2]], [[2, 1]]):
    try:
        d.check_sparse_witness([[0, 0, 1, 2, 3, 4]], {}, 2, list(range(31)), wrong)
    except d.af.CertificateError:
        counts['negative_witnesses'] += 1
    else:
        raise RuntimeError('wrong residual witness accepted')

# Joint feasibility needs one common alpha, not arbitrary marginal combinations.
joint_case = next(c for c in tiny if c['name'] == 'joint-not-cartesian')
joint = results[joint_case['name']]
p = joint['pieces'][0]
a = p['core']['feasibility_witness']
theta = d.lift(p['support'], a, p['beta'])
value = sum(feature_row(joint_case['contexts'][0])[j]*v for j, v in theta) % 26
check(d.check_joint(joint_case['contexts'], {}, joint, p['id'], a, [value, value]) == theta, 'joint witness')
different = next(v for v in joint['masks'][1] if v != value)
try:
    d.check_joint(joint_case['contexts'], {}, joint, p['id'], a, [value, different])
except d.af.CertificateError:
    pass
else:
    raise RuntimeError('Cartesian marginal tuple accepted as joint')

case = next(c for c in tiny if c['name'] == 'constant-equality-C-punctures')
for budget in (d.Budget(max_steps=0), d.Budget(max_pieces=0), d.Budget(max_core_work=0),
               d.Budget(max_core_solves=0), d.Budget(max_seconds=0), d.Budget(max_pieces=1),
               d.Budget(max_steps=25)):
    result = d.decode(**arguments(case), budget=budget)
    check(result['status'] == 'INCOMPLETE', 'deliberate cap')
    check(all(result[k] is None for k in ('masks', 'witnesses', 'provenance', 'pieces', 'feasibility_witness')), 'no partial claims')
    counts['caps'] += 1
for updates in ({'contexts': [[True, 0, 0, 0, 0, 0]]}, {'observed': {'0': 0}},
                {'sparsity': True}, {'sparsity': 4}, {'allowed_features': [28, 0]},
                {'allowed_features': [0, 0]}, {'budget': d.Budget(max_seconds=float('nan'))},
                {'budget': d.Budget(max_steps=True)}, {'contexts': [[26]*6]}):
    kwargs = arguments(case)
    kwargs.update(updates)
    try:
        d.decode(**kwargs)
    except ValueError:
        counts['malformed'] += 1
    else:
        raise RuntimeError('malformed input accepted')

here = Path(__file__).resolve().parent
suffix = '-optimized' if not __debug__ else ''
(here/('tiny-results'+suffix+'.json')).write_text(json.dumps(results, separators=(',', ':'))+'\n')
receipt = dict(status='PASS', counts=counts, source_sha256=d.SOURCE_SHA256,
               dependency_sha256=d.DEPENDENCY_SHA256, python=sys.version, optimized=not __debug__,
               cpu_seconds=time.process_time()-start, max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(here/('test-summary'+suffix+'.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
