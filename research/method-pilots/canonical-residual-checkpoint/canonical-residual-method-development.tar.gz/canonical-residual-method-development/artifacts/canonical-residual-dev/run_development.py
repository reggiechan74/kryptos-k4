"""Frozen fresh full31 development runs; no blind/target inputs."""
import hashlib
import json
from pathlib import Path
import resource
import sys
import time
from development_cases import cases, arguments, SEED
from residual_decoder import decode, Budget

out = Path(__file__).resolve().parent
optimized = not __debug__
suffix = '-optimized' if optimized else ''
start = time.process_time()
tiny, full = cases()
manifest = dict(seed=SEED, role='disclosed development, not holdout', tiny=tiny, full31=full)
(out/'development_cases.json').write_text(json.dumps(manifest, indent=2)+'\n')
results = []
for case in full:
    result = decode(**arguments(case), budget=Budget(max_seconds=25.0))
    path = out/(case['name']+suffix+'.json')
    path.write_text(json.dumps(result, separators=(',', ':'))+'\n')
    results.append(dict(name=case['name'], status=result['status'], stats=result['stats'],
                        resources=result['resources'], result_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
receipt = dict(status='COMPLETED', python=sys.version, optimized=optimized, seed=SEED,
               results=results, cpu_seconds=time.process_time()-start,
               max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(out/('development-summary'+suffix+'.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
