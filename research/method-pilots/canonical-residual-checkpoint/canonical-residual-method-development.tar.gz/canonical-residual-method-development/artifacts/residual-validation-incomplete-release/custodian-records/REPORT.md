# Fresh residual validation: incomplete, truth withheld

## Decision

**INCOMPLETE — no whole-cohort validation or truth release.** One authorized synthetic draw was generated, and the frozen run stopped on its 24th attempted job. No retry, resumption, replacement draw, solver change, or limit increase occurred. The incomplete run is retained as evidence, not converted into a successful validation.

The driver failed closed when a resource receipt violated its frozen per-process CPU ceiling. This establishes a resource-contract failure; it does not establish an engine/reference correctness failure, a cause for the CPU overshoot, or successful complete validation.

## Scope and custody chronology

1. The custodian read the private administrative register [reference omitted] and project ledger and verified the independent r3 protocol review and every source-manifest entry.
2. The project owner explicitly authorized one draw at the pinned source and analysis manifests, with separate new public and private directories. The durable approval-use marker preceded seed creation. The pinned generator wrote SHA256(seed) before generating any case.
3. Exactly one generation succeeded under the frozen 30/31-second, 512-MiB-per-process, 120-second-wall launcher. Only the neutral solver-input file and source pins were handed to the separate implementation runner. The project owner externally retained the approval, input, custody, seed/truth commitments, and generation evidence hashes.
4. The runner launched the pinned normal-Python driver once. It attempted the fixed public schedule until receipt rejection. The custodian independently checked the retained artifact hashes, receipt arithmetic, source/input identities, and the untouched incomplete progress state.
5. **Neither terminal sealing nor the released-truth analyzer was attempted.** The required 96-job terminal gate was not met. The project owner explicitly required truth to remain withheld. The custodian did not parse the seed or truth; the runner did not access them. Operational separation on the shared filesystem is not cryptographic blindness.

## Complete denominators and execution state

The predeclared design has 48 cases, 37 base clusters and 11 dependent controls: four contiguous-history cases and 44 algebraic/context-table controls. There are 96 planned jobs, normal and optimized Python once each. These are design counts, not completed independent observations.

| State | Jobs | Meaning |
| --- | ---: | --- |
| Completed, output and valid receipt recorded | 23 | Stored worker claims: 23 VERIFIED; stored engine claims: 22 EXACT, 1 EMPTY. These were **not independently reverified after the run** and are not a cohort PASS. |
| Started, failed, receipt rejected | 1 | `03-normal`: no final output and no `.json.tmp`; process exited -24 (SIGXCPU). Its 82-second reservation remains outstanding in frozen progress. |
| Not started | 72 | No replacement or later execution. |
| Total planned | 96 | 73 planned outputs are absent. |

The 97 retained result artifacts are 23 output/receipt/stdout/stderr sets, the failed job's receipt/stdout/stderr, schedule and progress. No driver post-run-integrity file was produced because the driver raised before reaching that step. An independent read-only hash check nevertheless confirmed all frozen source files and public input were unchanged. No partial output exists; zero-byte logs are retained and hashed.

The custodian's `INCOMPLETE-INVENTORY.json` is an immutable **preservation inventory, not a terminal-results seal**. It cannot satisfy the frozen analyzer's truth-release requirements. Per-stratum measured outcomes, plant eligibility/retention, complete relation counts, dependency/twin truth checks and forced-wrong-prediction counts are **not established**, because the authorized complete analysis never became admissible. No missing value is interpreted as zero or empty.

## Observed failure and resource accounting

The failed child receipt reports **47.947867 CPU seconds**, supervisor **0.028561 seconds**, SIGXCPU exit -24 and no wall timeout. The nominal child limits were soft/hard CPU 40/41 seconds, 512 MiB address space and 90 seconds wall. The frozen driver correctly rejected `child_cpu_seconds > 41` at line 55 before charging/releasing that job's reservation; the driver's outer exit is 1. **Why the reported CPU exceeded the nominal hard limit is unresolved.** No timing-based causal explanation or platform conformance is inferred from the receipt.

| Resource quantity | CPU seconds | Accounting scope |
| --- | ---: | --- |
| Generator inclusive receipt | 0.120891 | Count once. |
| Driver root inclusive receipt | 82.504641 | Includes driver, its supervisor and reaped worker descendants; count once. |
| Generator + driver measured execution | **82.625532** | Not a fully measured project total. |
| Accepted inner receipts | 34.133894 | Diagnostic subset of root, not additive. |
| Rejected inner receipt reported use | 47.976428 | Diagnostic subset of root, not additive and not an accepted protocol receipt. |
| Outstanding frozen execution reservation | **82** | Retained separately; not released or replenished. It overlaps the failed job's reported use and is not another measured CPU observation. |

The root receipt's maximum child RSS is 195,500 KiB; this is a per-process/descendant maximum, not simultaneous process-tree RSS. The prescribed address-space topology was at most 2 GiB sequentially; observed CPU enforcement did not satisfy its frozen receipt contract. No process matching this driver, worker or launcher remained in the custodian's read-only check of the visible PID namespace after failure; this is not a global host-process audit. The parent/worker wait receipts establish termination and reaping of the expected direct processes. No cleanup kill was needed or performed.

The frozen stage allocation remains 2,618 CPU seconds and retained project allocation remains 15,880 of 28,800; neither is replenished. Pre-draw protocol review measured 1.097573377 CPU seconds in scoped internal intervals. Custodian bookkeeping measured 0.001294747 + 0.000571729 + 0.154840594 seconds through the initial incomplete inventory. Shell/orchestration, source inspection, report construction, process startup/shutdown outside those intervals and historical accounting gaps remain explicitly unmeasured. Final independent review/packaging, if performed, needs separate scoped receipts, not invented totals.

## Immutable identity and evidence

| Artifact | SHA-256 |
| --- | --- |
| Frozen source manifest | `4c98ac170b0770b487b655dc4ba1ac8c96802669e1287e8a8090c1190669abc8` |
| Frozen analysis manifest | `e64d9bd04a457cb5b318ecfe6200467c774077c5c6ceaeb63a3bee83f5bda46a` |
| Independent pre-draw review | `2cb3c79a349090736c98b476406dd68aa0827e2b84aa7d4e11ea25a973b57f77` |
| Public solver input | `555a1f130f4be22446f35aa31c5a8df1d857a5d1e765a604ee5d5d912e31b87b` |
| Custody commitment | `a651c6875e92ab95a10082f7dec40ecf88710d643ce00538c03839fab4b98d7c` |
| One-use approval | `5ba520c5868973e9457fda9c9d9e1abced85773d195ccaa7179425701c922d05` |
| SHA256(seed), not seed bytes | `1f20ccfde3fd5a19fc0acb349120e349af1ad70f91bff18ba474dbf019b0cd0e` |
| Unreleased truth file | `af7d05777b108e5e72c4ab20b7f88444ddc1b73b831acce824b44a6cee7331ba` |
| Driver outer receipt | `6b748f8e96d57e73c7599a85cd7b0242503eb4ea85cb9a6c0771be85d052b343` |
| Failed job receipt | `01c029fe42ecef2739a76f012475a7200edde26cb0ddaad8d5040a9485219e48` |
| Incomplete preservation inventory | `86d4e29f767f8d06370df25a5b0161cf0a010537de0245091164d35d4365a77b` |
| Runner stop report | `3b3b71b989860aefab6ca8db88b5e3c6140b325d8c3c4ce645d44e9d7e786e4d` |

Source root: `/ARCHIVE_WORKSPACE/canonical-residual-validation-proposal`. Result root: `/ARCHIVE_WORKSPACE/residual-validation-results`. Runner records: `/ARCHIVE_WORKSPACE/residual-validation-run-records`. Custodian records: this directory. Historical r0/r1/r2 sources and all run artifacts remain unchanged. No remote write occurred.

## Bounded next decision

Keep this cohort closed and its truth withheld. First independently review the failed receipt, preserved process topology and accounting without executing any cohort work. If needed, propose a **separately authorized, non-cohort resource-launcher diagnostic**, with its own versioned freeze and small explicit budget, to investigate whether the execution environment can satisfy the required enforcement/receipt contract. Do not relax the receipt threshold based on this draw, silently resume, reuse this cohort as fresh evidence, or infer permission for another seed. Any changed launcher/protocol and any later validation require explicit separate review and authorization.

The fixed residual remains R = E minus (B union C); there is no speedup, novelty, mechanistic-recovery, model-membership, target-admission or solution claim. Historical matbalez scope remains unresolved. No K4 data or target execution was used.
