"""Read-only artifact/provenance check; no truth/seed/solver/generator access."""
import hashlib,json,resource,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(5,6));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2));start=time.process_time()
P=Path('/ARCHIVE_WORKSPACE/canonical-residual-validation-proposal');R=Path('/ARCHIVE_WORKSPACE/residual-validation-results');C=Path('/ARCHIVE_WORKSPACE/residual-validation-custodian-records');D=Path('/ARCHIVE_WORKSPACE/residual-validation-run-records');O=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(x,msg):
 if not x:raise ValueError(msg)
reportpin='5d9f362feaa0a171a8af2a345f9a969eab0f822d9f6642bbb24afe58c74609c4';invpin='86d4e29f767f8d06370df25a5b0161cf0a010537de0245091164d35d4365a77b';stoppin='3b3b71b989860aefab6ca8db88b5e3c6140b325d8c3c4ce645d44e9d7e786e4d'
for p,pin in [(C/'REPORT.md',reportpin),(C/'INCOMPLETE-INVENTORY.json',invpin),(D/'WORKER-STOP-REPORT.json',stoppin)]:check(sha(p)==pin,'changed reviewed artifact '+p.name)
v=json.loads((C/'INCOMPLETE-INVENTORY.json').read_text());progress=json.loads((R/'progress.json').read_text());schedule=json.loads((R/'schedule.json').read_text())
check(set(x.name for x in R.iterdir())==set(v['result_artifact_sha256']),'result inventory mismatch')
check(len(v['result_artifact_sha256'])==97,'result count')
for name,pin in v['result_artifact_sha256'].items():check(sha(R/name)==pin,'result hash '+name)
for name,pin in v['outer_artifact_sha256'].items():check(sha(D/name)==pin,'outer hash '+name)
for name,pin in v['generator_artifact_sha256'].items():check(sha(C/name)==pin,'generator receipt/log hash '+name)
freeze=json.loads((P/'FREEZE.json').read_text());check(sha(P/'FREEZE.json')==v['source_manifest_sha256'],'freeze hash');check(sha(P/'ANALYSIS-MANIFEST.json')==v['analysis_manifest_sha256'],'analysis hash')
for name,pin in freeze['sources'].items():check(sha(P/name)==pin,'source '+name)
# Public-file identity only: bytes hashed, no contexts/observations parsed.
check(sha(Path('/ARCHIVE_WORKSPACE/residual-validation-public-input/solver-input.json'))==v['public_input_sha256'],'public identity')
check(progress['status']=='INCOMPLETE' and len(progress['completed'])==23 and not progress['accounting_complete'],'incomplete progress')
names=[f'{i:02d}-{mode}' for i,mode in schedule]
check([e['name'] for e in progress['completed']]==names[:23] and names[23]=='03-normal','schedule prefix')
check(progress['in_flight']=={'name':'03-normal','reserved_cpu':82} and progress['outstanding_cpu_reserve']==82,'reserve')
check(not (R/'post-run-integrity.json').exists() and not (R/'03-normal.json').exists() and not (R/'03-normal.json.tmp').exists(),'unexpected final/partial')
claims={}
for e in progress['completed']:
 output=json.loads((R/(e['name']+'.json')).read_text());key=(output['status'],output['engine_result']['status']);claims[key]=claims.get(key,0)+1
check(claims=={('VERIFIED','EXACT'):22,('VERIFIED','EMPTY'):1},'stored claims tally')
inner=sum((lambda x:x['child_cpu_seconds']+x['parent_cpu_seconds'])(json.loads((R/(e['name']+'.resource.json')).read_text())) for e in progress['completed'])
failed=json.loads((R/'03-normal.resource.json').read_text());outer=json.loads((D/'driver.resource.json').read_text());generation=json.loads((C/'generator.resource.json').read_text())
check(abs(inner-progress['inclusive_inner_cpu_actual_known'])<1e-9,'accepted CPU')
check(failed['exit_code']==-24 and failed['child_cpu_seconds']>41 and outer['exit_code']==1,'failed receipt semantics')
result={'status':'PASS_FOR_INCOMPLETE_PRESERVATION_AND_SCOPE_ONLY','custodian_report_sha256':reportpin,'incomplete_inventory_sha256':invpin,'runner_stop_report_sha256':stoppin,'source_manifest_sha256':v['source_manifest_sha256'],'analysis_manifest_sha256':v['analysis_manifest_sha256'],'result_files_verified':97,'outer_files_verified':3,'generator_receipt_and_logs_verified':3,'stored_claims_NOT_independent_relation_validation':{'VERIFIED_EXACT':22,'VERIFIED_EMPTY':1},'completed_jobs':23,'failed_started_job':'03-normal','unstarted_jobs':72,'progress_reserve_unchanged':82,'accepted_inner_cpu_nonadditive':inner,'failed_inner_reported_cpu_nonadditive':failed['child_cpu_seconds']+failed['parent_cpu_seconds'],'outer_inclusive_cpu':outer['child_cpu_seconds']+outer['parent_cpu_seconds'],'generator_inclusive_cpu':generation['child_cpu_seconds']+generation['parent_cpu_seconds'],'seed_or_truth_bytes_read':False,'seed_truth_hashes_independently_recomputed':False,'approval_custody_chronology':'reviewed report/project-owner attestations, not independently reconstructed from private files','solver_generator_or_cohort_executed':False,'source_or_original_artifacts_changed':False,'internal_check_cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'measurement':'single read-only verification process internal interval; startup/final-write/shutdown/shell excluded'}
with (O/'CHECK.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
