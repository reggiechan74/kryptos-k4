# Independent incomplete-run preservation review

**PASS for preservation, arithmetic, provenance and reported scope only. The fresh validation remains INCOMPLETE; no terminal seal, truth release or cohort correctness PASS is established.**

Reviewed custodian report SHA256 `5d9f362feaa0a171a8af2a345f9a969eab0f822d9f6642bbb24afe58c74609c4`, preservation inventory `86d4e29f767f8d06370df25a5b0161cf0a010537de0245091164d35d4365a77b`, and runner stop report `3b3b71b989860aefab6ca8db88b5e3c6140b325d8c3c4ce645d44e9d7e786e4d`.

The independent read-only checker verified the exact 97-file result inventory and hashes, three driver receipt/log files, three generator receipt/log files, all frozen source hashes and the public-input byte hash. It did not parse public contexts for analysis, import a solver/generator, recompute any complete relation, or access any seed/truth bytes. Private commitment hashes and approval/custody chronology remain report/project-owner attestations rather than independently reopened private evidence.

The completed jobs are exactly the first 23 of the frozen schedule. The next job is `03-normal`; 72 remain unstarted. Stored worker claims are 23 VERIFIED, with 22 engine EXACT and one EMPTY. These are correctly labeled **stored claims, not independent post-run correctness validation**. The failed job has no output or partial output. No post-run-integrity artifact exists. Frozen progress remains INCOMPLETE, accounting incomplete, with the 82-second reservation untouched.

Receipt arithmetic reconciles:

- Accepted inner jobs: 34.133894 CPU seconds.
- Rejected failed inner receipt: 47.976428 seconds, including 47.947867 child and 0.028561 supervisor. This is reported use, not a contract-conforming accepted receipt.
- All 24 inner reports sum to 82.110322; driver outer inclusive CPU is 82.504641, leaving 0.394319 for outer/driver overhead. These nested receipts must not be added twice.
- Generator inclusive CPU is 0.120891; generator plus driver measured execution is 82.625532. The 82 outstanding reserve remains separate and overlapping, not another measured CPU observation.

The root and inner wait receipts establish termination/reaping of the expected direct processes; the visible process table showed no worker. That is not a host-wide cleanup audit. No cleanup kill, retry, resume or redraw was performed by this reviewer.

Each worker has a fresh launcher using `wait4` on its specific child; the reviewed worker/engine/reference code creates no descendants and changes no CPU limits or SIGXCPU disposition. Ordinary ancestor cumulative accounting explains the root receipt, not the anomalous failed worker's >41-second receipt. Signal-delivery/accounting cause remains unresolved. The separately authorized two generic controls are documented at `/ARCHIVE_WORKSPACE/residual-resource-ceiling-diagnostic/REPORT.md`; they demonstrate soft-threshold lag but neither reproduce nor explain the failed hard-ceiling excess. They do not amend or validate the failed cohort.

The unchanged source and analysis manifests remain `4c98ac170b0770b487b655dc4ba1ac8c96802669e1287e8a8090c1190669abc8` and `e64d9bd04a457cb5b318ecfe6200467c774077c5c6ceaeb63a3bee83f5bda46a`. The pre-draw protocol PASS covered static code and deterministic mocks, not an empirical guarantee that this environment realizes nominal hard CPU ceilings. Preserve that report unchanged and carry this qualification alongside it.

**Next step:** retain the incomplete preservation bundle, keep truth withheld, and close this cohort without retry or budget/threshold relaxation. Any future infrastructure correction or validation requires separate review and authorization. No historical novelty, speedup, mechanistic recovery, model membership or K4 admission follows. Historical matbalez scope remains unresolved.

Machine evidence is in `CHECK.json`; separate scoped post-stop CPU accounting and artifact pins accompany this review. No producer source or original run artifact was modified. This review does not authorize local/remote publication; it supplies the independent preservation check requested for the custodian's next authorized action.
