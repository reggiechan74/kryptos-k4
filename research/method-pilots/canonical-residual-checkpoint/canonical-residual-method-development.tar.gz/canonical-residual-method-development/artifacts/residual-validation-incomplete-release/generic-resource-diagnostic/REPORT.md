# Separate generic CPU-limit diagnostic

## Result

**Soft-limit signal delivery occurred after the configured threshold in both short controls; the cause of the failed cohort's much larger hard-ceiling excess remains unresolved.** No cohort was rerun. Do not relax its receipt guard or reinterpret its INCOMPLETE status.

The latest project authorization superseded an earlier larger proposal: exactly two seedless 1/2-second CPU, 128-MiB-per-process trials, each supervised by a separate 5-second wall timer, with at most 22 CPU seconds allocated. Only these two trials ran. The generic code imports no solver, generator, cohort, seed or truth. Original launcher and run artifacts were untouched.

| Mode | Child user CPU | Child system CPU | Child total CPU | Supervisor CPU | Elapsed wall | Exit |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Default SIGXCPU disposition | 1.135970 | 0.007952 | 1.143922 | 0.028023 | 1.145416 | -24, SIGXCPU |
| Python handler logs then exits | 1.229378 | 0.011851 | 1.241229 | 0.036349 | 1.242333 | 77, intentional diagnostic exit |

Two-trial inclusive measured CPU is **2.449523 seconds**, counted once as child plus supervisor self CPU. Startup before the supervisor's limit setup is included in its rusage; final receipt serialization/shutdown and shell/tool overhead are not fully measured. Neither wall watchdog fired. Both child PIDs were reaped and absent after `wait4`; no worker remained in the visible PID namespace. No third trial or repeat was performed.

## What the observations establish

The supervisor set RLIMIT_CPU=(1,2) before fork/exec, as in the production inheritance pattern. Each worker logged the inherited CPU and address-space limits before its bounded arithmetic loop. Periodic records contain separate self user/system rusage, `process_time`, `os.times`, monotonic time and runtime limits. The worker created no children or threads.

The default-disposition worker was still logging with limits [1,2] at process_time 1.135820 seconds, then terminated with SIGXCPU. Its final wait4 CPU was 1.143922 seconds. In the second control the Python SIGXCPU handler observed process_time 1.240691 and self rusage 1.240687 seconds, with the runtime limit now [2,2], then exited immediately. The handler time is **Python's observation time, not the kernel signal-generation timestamp**.

The process clocks, self rusage, wait4 rusage and wall time broadly agree in these CPU-bound, single-child controls. This is evidence that exceeding the configured soft threshold before observable signal termination is possible here without cumulative descendants or model computation. It does not measure the hard-limit kill behavior: both controls stopped below hard=2. There is no justified linear overshoot factor, worst-case slack bound, or conclusion that a 40/41-second worker may safely consume 47.95 seconds.

Linux documents SIGXCPU at the CPU soft limit and SIGKILL at the hard limit; it also describes incrementing the soft limit when SIGXCPU is handled. Limits survive fork/exec. The observed [1,2]→[2,2] transition is consistent with that behavior, but does not identify a kernel/runtime accounting defect. [Linux getrlimit documentation](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

`wait4` returns accounting for its selected child; waited descendants can propagate into ancestor usage. Thus a driver's inclusive receipt legitimately includes workers. This does not make a fresh worker's receipt cumulative across earlier sibling jobs. [Linux wait4 documentation](https://man7.org/linux/man-pages/man2/wait4.2.html), [Linux getrusage documentation](https://man7.org/linux/man-pages/man2/getrusage.2.html)

## Interpretation and honest receipt semantics

The larger cohort anomaly could reflect delayed enforcement/delivery relative to the reported accounting clock, differing runtime accounting bases, or another platform condition. These two controls do not distinguish those causes. The observed uname was Linux 6.18.57; that string alone does not establish the implementation details of the execution environment. Neither the failed receipt nor these controls capture kernel signal-generation timestamps, and the failed receipt omitted separate user/system components and any final worker-local clock sample.

For any future separately reviewed infrastructure, distinguish **configured limits**, **observed CPU**, **signal/timeout disposition**, and **contract conformity**. Retain separate user/system and supervisor/descendant measurements, never clamp or rewrite measured use to a nominal limit, and preserve a violation rather than automatically accept or retry it. A validated independently enforced wall/process-tree bound and conservative reservation would be needed before treating configured CPU values as strict project-budget maxima. This is a requirement for future review, not authorization to alter the frozen cohort or run further tests.

The original driver correctly failed closed on the rejected receipt. Its unchanged 82-second reservation and withheld truth remain appropriate. Preserve the original pre-draw review as history, while explicitly qualifying its nominal-hard-ceiling assumption with this post-draw evidence.

Source pin: `control.py` SHA256 `9902790e1aef74de10adac5de673d152ea335b9dcfd1b2526cebdeeed2e44f4b`. Raw JSONL observations, stdout/stderr and receipts are retained beside this report. The accompanying manifest and post-stop accounting ledger identify their exact hashes.
