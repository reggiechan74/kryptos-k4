"""Two authorized seedless infrastructure controls only; imports no project code/data."""
import ctypes,json,os,resource,signal,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def guard(expected):
    if os.getppid()!=expected:os.kill(os.getpid(),signal.SIGKILL)
    if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGKILL,0,0,0)!=0:raise OSError(ctypes.get_errno(),'pdeathsig')
    if os.getppid()!=expected:os.kill(os.getpid(),signal.SIGKILL)

def snapshot():
    r=resource.getrusage(resource.RUSAGE_SELF);t=os.times()
    return dict(monotonic=time.monotonic(),process_time=time.process_time(),utime=r.ru_utime,stime=r.ru_stime,
                os_times_user=t.user,os_times_system=t.system,cpu_limit=list(resource.getrlimit(resource.RLIMIT_CPU)),
                address_space_limit=list(resource.getrlimit(resource.RLIMIT_AS)))

def worker(mode,expected):
    guard(expected);fd=os.open(str(ROOT/(mode+'-worker.jsonl')),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    def log(event,**extra):os.write(fd,(json.dumps(dict(event=event,pid=os.getpid(),ppid=os.getppid(),**snapshot(),**extra),sort_keys=True)+'\n').encode())
    log('start',mode=mode,signal_handler='default' if mode=='default' else 'Python observer logs then exits77')
    if resource.getrlimit(resource.RLIMIT_CPU)!=(1,2) or resource.getrlimit(resource.RLIMIT_AS)!=(128*1024**2,128*1024**2):raise RuntimeError('inherited limits mismatch')
    if mode=='handler':
        def cpu_signal(sig,frame):
            log('python_SIGXCPU_handler_observed',signal=sig,warning='Python execution observation; not kernel generation timestamp')
            os._exit(77)
        signal.signal(signal.SIGXCPU,cpu_signal)
    else:signal.signal(signal.SIGXCPU,signal.SIG_DFL)
    last=time.monotonic();x=0
    while True:
        for _ in range(10000):x=(x+1)%1000003
        now=time.monotonic()
        if now-last>=.10:log('sample');last=now

if len(sys.argv)==4 and sys.argv[1]=='--worker':worker(sys.argv[2],int(sys.argv[3]));raise SystemExit(99)
mode=sys.argv[1]
if mode not in ('default','handler'):raise ValueError('fixed two modes only')
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(1,2))
guard(os.getppid());start=snapshot();parent=os.getpid();child=None;timed_out=False

def timeout(sig,frame):
    global timed_out
    timed_out=True
    if child is not None:
        try:os.kill(child,signal.SIGKILL)
        except ProcessLookupError:pass
signal.signal(signal.SIGALRM,timeout);signal.alarm(5)
child=os.fork()
if child==0:
    guard(parent);os.execv(sys.executable,[sys.executable,str(Path(__file__).resolve()),'--worker',mode,str(parent)])
_,status,r= os.wait4(child,0);signal.alarm(0);end=snapshot()
try:os.kill(child,0);still_exists=True
except ProcessLookupError:still_exists=False
receipt=dict(classification='GENERIC_SEEDLESS_INFRASTRUCTURE_DIAGNOSTIC_NOT_COHORT',mode=mode,
    command=sys.argv,supervisor_pid=parent,child_pid=child,requested_soft_hard_cpu=[1,2],wall_deadline_seconds=5,
    memory_per_process_bytes=128*1024**2,supervisor_start=start,supervisor_end=end,
    child_user_cpu=r.ru_utime,child_system_cpu=r.ru_stime,child_cpu=r.ru_utime+r.ru_stime,
    supervisor_cpu=end['utime']+end['stime'],elapsed_wall=end['monotonic']-start['monotonic'],
    exit_code=os.waitstatus_to_exitcode(status),wall_timeout=timed_out,child_reaped=True,child_pid_exists_after_wait=still_exists,
    peak_child_rss_kib=r.ru_maxrss,parent_death_guard=True,source_sha256=__import__('hashlib').sha256(Path(__file__).read_bytes()).hexdigest())
with (ROOT/(mode+'-receipt.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(receipt,indent=2))
