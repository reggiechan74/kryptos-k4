"""CUSTODIAN ONLY. No generation until reviewed manifest plus explicit approval.
No solver imports, rejection sampling by fit, or replacement draws.
"""
import argparse
import hashlib
import json
from pathlib import Path
import random
import secrets
from common import ROOT, require, require_bounds, sha, verify_manifest, write_new

def row(x):
    return ([1]+x+[v*v % 26 for v in x]
            +[x[i]*x[j] % 26 for i in range(6) for j in range(i+1, 6)]
            +[int(x[i] == x[i+1]) for i in (0, 2, 4)])

def generate(seed):
    require(type(seed) is bytes and len(seed) == 32, '256-bit seed required')
    rng = random.Random(int.from_bytes(seed, 'big'))
    cases = []
    ordinary_obs = [(i*90)//23 for i in range(24)]
    trace_obs = list(range(15,28))+list(range(57,68))
    def contexts(count=91, no_equal=False):
        result = [[rng.randrange(26) for _ in range(6)] for _ in range(count)]
        if no_equal:
            # Fixed constructive map, not retry/rejection by signal or fit.
            for x in result:
                for j in (0, 2, 4):
                    if x[j] == x[j+1]: x[j+1] = (x[j+1]+1) % 26
        return result
    def add(label, stratum, ctx, theta, allowed=None, sparsity=3, obs=None,
            dependency=None, kind='algebraic-context-table', hidden_override=None):
        values = [sum(row(x)[j]*v for j, v in theta.items()) % 26 for x in ctx]
        if obs is None: obs = ordinary_obs
        observed = {str(i): values[i] for i in obs}
        truth_values = list(values)
        if hidden_override is not None:
            require(hidden_override not in obs, 'override must remain unobserved')
            truth_values[hidden_override] = (truth_values[hidden_override]+1) % 26
        cases.append(dict(label=label, stratum=stratum, dependency=dependency, kind=kind,
            plant=sorted(theta.items()), true_values=truth_values, override=hidden_override,
            instance=dict(contexts=ctx, observed=observed, sparsity=sparsity,
                          allowed_features=list(range(31)) if allowed is None else allowed)))
    # 12 supported R cases. First4 are genuine contiguous97-symbol histories.
    for k in range(12):
        if k < 4:
            stream = [rng.randrange(26) for _ in range(97)]
            ctx = [[stream[i-j] for j in range(1, 7)] for i in range(6, 97)]
            kind = 'contiguous97-symbol-trace'
            theta = {28+k % 3: 2*rng.randrange(1, 13), 2: rng.choice(list(range(1, 26, 2)))}
        elif k < 8:
            ctx = contexts(); kind = 'algebraic-context-table'
            theta = {28+k % 3: 13, 1: 13, 0: rng.randrange(1, 26)}
        else:
            ctx = contexts(); kind = 'algebraic-context-table'
            theta = {28+k % 3: rng.choice(list(range(3, 25, 2))), 3: 2*rng.randrange(1, 13), 0: rng.randrange(1, 26)}
        add('a'+str(k), 'supported-R', ctx, theta, kind=kind, obs=trace_obs if k<4 else None)
    # Eight removed plants; residual compatibility is determined, not presumed.
    for k in range(8):
        theta = ({0: rng.randrange(26), 28+k % 3: rng.choice((1, 25))} if k < 4
                 else {0: rng.randrange(26), 28+k % 3: 2*rng.randrange(1, 13), 1: 13})
        add('b'+str(k), 'removed-C' if k < 4 else 'removed-B', contexts(), theta)
    # Eight complete tiny controls, including one dependent alias pair.
    for k in range(2):
        q = 28+k
        add('c'+str(k), 'forced-C-empty-residual', [[0,0,1,1,2,2], [0,1,1,2,2,3]],
            {0:rng.randrange(26), q:1 if k == 0 else 25}, [0,q], 2, [0,1])
    for k in range(2,4):
        add('c'+str(k), 'forced-B-empty-residual', [[1,1,2,3,4,5], [1,2,2,3,4,5], [2,3,2,3,4,5]],
            {1:13,28:2*rng.randrange(1,13)}, [1,28], 2, [0,1,2])
    add('c4', 'E-projection-puncture', [[0,0,1,2,3,4],[0,13,1,2,3,4]], {2:13,28:2}, [2,28], 2, [])
    add('c5', 'C-projection-puncture', [[0,0,1,2,3,4],[0,13,1,2,3,4]], {28:13}, [28], 1, [])
    alias_ctx = contexts(6)
    add('c6', 'alias-base', alias_ctx, {2:13,28:2}, [2,8,28], 2, [0,1])
    add('c7', 'alias-dependent', alias_ctx, {8:13,28:2}, [2,8,28], 2, [0,1], dependency='c6')
    # Four linked old/new finite-prediction pairs; no equality anywhere.
    for k in range(4):
        ctx = contexts(no_equal=True); b = rng.randrange(26); q = 28+k % 3
        add('d'+str(k), 'shared-prediction-residual-base', ctx, {0:b,q:13})
        add('d'+str(k+4), 'shared-prediction-C-dependent', ctx, {0:b,q:1}, dependency='d'+str(k))
    # Six supported bases and six guaranteed out-of-family dependent twins.
    for k in range(6):
        ctx = contexts(); ctx[90] = list(ctx[89]); obs = list(range(23))+[89]
        theta = {28+k % 3:2*rng.randrange(1,13),2:rng.choice(list(range(1,26,2)))}
        add('e'+str(k), 'misspecification-base', ctx, theta, obs=obs)
        add('e'+str(k+6), 'out-of-family-dependent-twin', ctx, theta, obs=obs,
            dependency='e'+str(k), hidden_override=90)
    require(len(cases) == 48, 'generator case inventory')
    rng.shuffle(cases)
    ids = {c['label']: 'v%03d' % i for i,c in enumerate(cases)}
    public = {'cases':[{'id':ids[c['label']], 'instance':c['instance']} for c in cases]}
    truth = {'seed_hex':seed.hex(), 'cases':[{k:v for k,v in c.items() if k != 'instance'} |
             {'id':ids[c['label']], 'dependency_id':ids[c['dependency']] if c['dependency'] else None}
             for c in cases]}
    return public, truth

def main():
    p = argparse.ArgumentParser(); p.add_argument('--approval', required=True); p.add_argument('--approval-sha256', required=True)
    p.add_argument('--manifest', required=True); p.add_argument('--manifest-sha256', required=True)
    p.add_argument('--public-dir', required=True); p.add_argument('--secret-dir', required=True); a = p.parse_args()
    require_bounds(30,512)
    verify_manifest(a.manifest,a.manifest_sha256)
    public_dir,secret_dir = Path(a.public_dir).resolve(),Path(a.secret_dir).resolve()
    require(public_dir != secret_dir and public_dir not in secret_dir.parents and secret_dir not in public_dir.parents
            and ROOT not in secret_dir.parents and secret_dir != ROOT, 'non-nested separate custody directories required')
    require(sha(a.approval) == a.approval_sha256, 'approval pin')
    approval = json.loads(Path(a.approval).read_text())
    require(approval == {'stage':'canonical-residual-validation-1', 'status':'APPROVED_AND_DRAW_AUTHORIZED',
                         'source_manifest_sha256':a.manifest_sha256,
                         'analysis_manifest_sha256':sha(ROOT/'ANALYSIS-MANIFEST.json'),
                         'resource_allocation_sha256':sha(ROOT/'RESOURCE-ALLOCATION.json'),
                         'public_dir':str(public_dir),'secret_dir':str(secret_dir)}, 'explicit matching draw approval required')
    # Consume approval BEFORE drawing. A failed/uncertain attempt cannot reuse it.
    write_new(Path(a.approval).with_suffix(Path(a.approval).suffix+'.used.json'),
              {'approval_sha256':a.approval_sha256,'public_dir':str(public_dir),'secret_dir':str(secret_dir)})
    public_dir.mkdir(parents=True,exist_ok=False); secret_dir.mkdir(parents=True,exist_ok=False)
    seed = secrets.token_bytes(32)
    # Seed commitment precedes any generated case, and is retained even on failure.
    write_new(secret_dir/'seed.json', {'seed_hex':seed.hex()})
    write_new(public_dir/'seed-commitment.json', {'seed_sha256':hashlib.sha256(seed).hexdigest()})
    public,truth = generate(seed)
    write_new(public_dir/'solver-input.json',public); write_new(secret_dir/'truth.json',truth)
    write_new(public_dir/'custody.json', {'status':'DRAWN_ONCE','public_sha256':sha(public_dir/'solver-input.json'),
        'truth_sha256':sha(secret_dir/'truth.json'),'seed_sha256':hashlib.sha256(seed).hexdigest(),
        'source_manifest_sha256':a.manifest_sha256,'analysis_manifest_sha256':sha(ROOT/'ANALYSIS-MANIFEST.json'),
        'approval_sha256':a.approval_sha256,'case_count':48,'base_clusters':37,'dependent_controls':11})
    verify_manifest(a.manifest,a.manifest_sha256)

if __name__ == '__main__': main()
