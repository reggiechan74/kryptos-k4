"""Custodian pre-truth terminal seal. Never opens seed or secret truth."""
import argparse
import json
from pathlib import Path
from common import ROOT, read_public, require, require_bounds, sha, terminal_snapshot, verify_manifest, write_new

def main():
    p=argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','results','outer-receipt','outer-receipt-sha256',
                 'custody','custody-sha256','out'):
        p.add_argument('--'+name,required=True)
    a=p.parse_args();require_bounds(5,512)
    pins=verify_manifest(a.manifest,a.manifest_sha256);read_public(a.input,a.input_sha256)
    require(sha(a.custody)==a.custody_sha256,'custody commitment')
    custody=json.loads(Path(a.custody).read_text())
    require(custody['public_sha256']==a.input_sha256 and custody['source_manifest_sha256']==a.manifest_sha256
            and custody['analysis_manifest_sha256']==sha(ROOT/'ANALYSIS-MANIFEST.json'),'custody/source/input linkage')
    snapshot=terminal_snapshot(a.results,a.input,a.input_sha256,a.manifest,a.manifest_sha256,pins,
                               a.outer_receipt,a.outer_receipt_sha256)
    require(Path(a.results).resolve() not in Path(a.out).resolve().parents,'terminal manifest must be outside result inventory')
    snapshot.update(version='residual-terminal-seal-1',custody_sha256=a.custody_sha256,
                    truth_sha256=custody['truth_sha256'],analysis_manifest_sha256=custody['analysis_manifest_sha256'])
    verify_manifest(a.manifest,a.manifest_sha256)
    write_new(a.out,snapshot)
    print(json.dumps({'terminal_results_manifest':str(Path(a.out).resolve()),'sha256':sha(a.out),
                      'instruction':'The project owner must retain this SHA externally BEFORE authorizing truth release.'}))

if __name__=='__main__':main()
