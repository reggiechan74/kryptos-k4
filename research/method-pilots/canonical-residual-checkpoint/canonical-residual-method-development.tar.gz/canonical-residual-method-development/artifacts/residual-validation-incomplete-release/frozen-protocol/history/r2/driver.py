"""Sealed96-job validation driver; durable actual+reserve, no truth input."""
import argparse
import json
import os
from pathlib import Path
import random
import subprocess
import sys
from common import ROOT, atomic, finite_cpu, read_public, require, require_bounds, sha, verify_manifest, write_new

def main():
    p=argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','out'): p.add_argument('--'+name,required=True)
    a=p.parse_args(); require_bounds(240,512)
    require(__debug__,'driver uses normal Python')
    require(all(Path(x).is_absolute() for x in (a.input,a.manifest,a.out)), 'absolute sealed driver paths required')
    pins=verify_manifest(a.manifest,a.manifest_sha256); read_public(a.input,a.input_sha256)
    dest=Path(a.out).resolve(); dest.mkdir(parents=True,exist_ok=False)
    jobs=[(i,mode) for i in range(48) for mode in ('normal','optimized')]
    random.Random(202610312008).shuffle(jobs)
    write_new(dest/'schedule.json',jobs)
    actual=0.0; done=[]; inflight=None; state='INCOMPLETE'
    def save(reason):
        atomic(dest/'progress.json',{'status':state,'reason':reason,'planned':96,'completed':done,
            'inclusive_inner_cpu_actual_known':actual,'in_flight':inflight,
            'outstanding_cpu_reserve':82 if inflight else 0,'accounting_complete':inflight is None,
            'cpu_cap':1500,'next_reservation':82,'input_sha256':a.input_sha256,
            'manifest_sha256':a.manifest_sha256})
    save('not started')
    for index,mode in jobs:
        if actual+82>1500: save('aggregate actual+reserve cap'); break
        name=f'{index:02d}-{mode}'; receipt=dest/(name+'.resource.json'); output=dest/(name+'.json')
        command=[sys.executable,str(ROOT/'bounded_checked.py'),str(receipt),'40','512','90',sys.executable]
        if mode=='optimized':command.append('-O')
        command += [str(ROOT/'run_one.py'),'--input',str(Path(a.input).resolve()),'--input-sha256',a.input_sha256,
                    '--manifest',str(Path(a.manifest).resolve()),'--manifest-sha256',a.manifest_sha256,
                    '--index',str(index),'--mode',mode,'--out',str(output)]
        inflight={'name':name,'reserved_cpu':82}; save('reservation durably committed before launch')
        stdout_path=dest/(name+'.stdout.txt');stderr_path=dest/(name+'.stderr.txt')
        with stdout_path.open('x') as stdout,stderr_path.open('x') as stderr:
            run=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr,
                env={**os.environ,'BOUND_EXPECTED_PARENT':str(os.getpid()),'PYTHONDONTWRITEBYTECODE':'1'})
            stdout.flush();os.fsync(stdout.fileno());stderr.flush();os.fsync(stderr.fileno())
        if not receipt.exists():
            done.append({'name':name,'status':'INCOMPLETE','reason':'missing receipt; reserve retained','returncode':run.returncode})
            save('unknown resource use, no continuation'); break
        rr=json.loads(receipt.read_text())
        require(rr['limits']=={'cpu_seconds_per_process':40,'address_space_bytes_per_process':512*1024**2,'wall_seconds':90},'stage limit receipt')
        require(rr['command']==command[6:] and rr['parent_death_guard'] is True
                and type(rr['exit_code']) is int and type(rr['wall_timeout']) is bool
                and run.returncode==(rr['exit_code'] if rr['exit_code']>=0 else 1)
                and (not rr['wall_timeout'] or rr['exit_code']!=0),'stage invocation/return receipt')
        used=finite_cpu(rr['child_cpu_seconds'])+finite_cpu(rr['parent_cpu_seconds'])
        require(used<=82,'invalid charged resource receipt')
        actual+=used; inflight=None
        row={'name':name,'status':'OUTPUT_SEALED' if run.returncode==0 and output.exists() else 'FAILED',
             'returncode':run.returncode,'resource_sha256':sha(receipt),
             'stdout_sha256':sha(stdout_path),'stderr_sha256':sha(stderr_path),
             'partial_output_sha256':sha(output.with_suffix(output.suffix+'.tmp')) if output.with_suffix(output.suffix+'.tmp').exists() else None,
             'output_sha256':sha(output) if output.exists() else None}
        done.append(row); save('running; failures retained without retries')
    else:
        verify_manifest(a.manifest,a.manifest_sha256); read_public(a.input,a.input_sha256)
        state='TERMINAL'; save('all96 planned jobs accounted; not a correctness verdict')
    post={'sources':{name:sha(ROOT/name) for name in pins['sources']},
          'input_sha256':sha(a.input),'manifest_sha256':sha(a.manifest)}
    write_new(dest/'post-run-integrity.json',post)
    if not (post['sources']==pins['sources'] and post['input_sha256']==a.input_sha256
            and post['manifest_sha256']==a.manifest_sha256):
        state='INCOMPLETE';save('post-run seal mismatch');return 2
    return 0 if state=='TERMINAL' else 2

if __name__=='__main__':sys.exit(main())
