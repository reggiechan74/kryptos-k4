"""Frozen complete-relation validation and truth analysis; never tunes a model."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import time
from common import ROOT, arguments, read_public, require, require_bounds, sha, verify_manifest, write_new

def serialize_relation(expected):
    return {'pieces':[{'support':list(key[0]),'beta':list(key[1]),'alpha_points':[list(v) for v in sorted(points)]}
                      for key,points in sorted(expected['pieces'].items())],
            'canonical_descriptors':[{'alpha':list(key[0]),'beta':list(key[1])} for key in sorted(expected['lifts'])],
            'joint_predictions':[list(v) for v in sorted(expected['joints'])]}

def main():
    p=argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','analysis-manifest','analysis-manifest-sha256',
                 'results','truth','truth-sha256','custody','custody-sha256','outer-receipt','outer-receipt-sha256','out'):
        p.add_argument('--'+name,required=True)
    a=p.parse_args(); require_bounds(180,768); start=time.process_time()
    pins=verify_manifest(a.manifest,a.manifest_sha256)
    verify_manifest(a.analysis_manifest,a.analysis_manifest_sha256,analysis=True)
    public=read_public(a.input,a.input_sha256); dest=Path(a.results)
    custody=json.loads(Path(a.custody).read_text())
    require(sha(a.custody)==a.custody_sha256 and custody['public_sha256']==a.input_sha256
            and custody['truth_sha256']==a.truth_sha256 and custody['source_manifest_sha256']==a.manifest_sha256
            and custody['analysis_manifest_sha256']==a.analysis_manifest_sha256,'custody seals')
    progress=json.loads((dest/'progress.json').read_text())
    require(progress['status']=='TERMINAL' and progress['planned']==96 and len(progress['completed'])==96
            and progress['in_flight'] is None and progress['outstanding_cpu_reserve']==0
            and progress['accounting_complete'] and progress['cpu_cap']==1500
            and progress['inclusive_inner_cpu_actual_known']<=1500,'all jobs must be terminal and accounted before truth release')
    require(progress['input_sha256']==a.input_sha256 and progress['manifest_sha256']==a.manifest_sha256,'progress identity')
    jobs=[(i,mode) for i in range(48) for mode in ('normal','optimized')]
    random.Random(202610312008).shuffle(jobs)
    require(json.loads((dest/'schedule.json').read_text())==[list(j) for j in jobs],'fixed schedule')
    require([r['name'] for r in progress['completed']]==[f'{i:02d}-{m}' for i,m in jobs],'exact executed job inventory')
    post=json.loads((dest/'post-run-integrity.json').read_text())
    require(post=={'sources':pins['sources'],'input_sha256':a.input_sha256,'manifest_sha256':a.manifest_sha256},'post-run seals')
    require(sha(a.outer_receipt)==a.outer_receipt_sha256,'outer resource seal')
    outer=json.loads(Path(a.outer_receipt).read_text())
    require(outer['limits']=={'cpu_seconds_per_process':240,'address_space_bytes_per_process':512*1024**2,'wall_seconds':3600}
            and outer['exit_code']==0 and not outer['wall_timeout'],'terminal bounded driver required')
    sealed={}; inner_cpu=0.0
    for entry in progress['completed']:
        receipt=dest/(entry['name']+'.resource.json'); output=dest/(entry['name']+'.json')
        require(sha(receipt)==entry['resource_sha256'],'resource changed')
        rr=json.loads(receipt.read_text())
        require(rr['limits']=={'cpu_seconds_per_process':40,'address_space_bytes_per_process':512*1024**2,'wall_seconds':90}
                and rr['parent_death_guard'],'stage wrapper evidence')
        inner_cpu+=rr['child_cpu_seconds']+rr['parent_cpu_seconds']
        if entry['output_sha256'] is not None:
            require(sha(output)==entry['output_sha256'],'sealed output changed')
            sealed[entry['name']]=json.loads(output.read_text())
        else: require(not output.exists(),'unsealed unexpected output')
    require(abs(inner_cpu-progress['inclusive_inner_cpu_actual_known'])<1e-7,'inner accounting reconciliation')
    # All source, input, output and job/accounting seals precede reading truth.
    require(sha(a.truth)==a.truth_sha256,'truth release seal')
    truth=json.loads(Path(a.truth).read_text()); seed=bytes.fromhex(truth['seed_hex'])
    require(len(seed)==32 and hashlib.sha256(seed).hexdigest()==custody['seed_sha256'],'seed commitment')
    from generate import generate
    replay_public,replay_truth=generate(seed)
    require(replay_public==public and replay_truth==truth,'deterministic custodian generation replay')
    require(sum(c['dependency_id'] is not None for c in truth['cases'])==11,'dependent-control count')
    import reference
    labels={c['id']:c for c in truth['cases']}; outcomes=[]; comparison_failures=[]
    totals={'verified_outputs':0,'incomplete_outputs':0,'failed_jobs':0,'pieces':0,'canonical_functions':0,
            'joint_predictions':0,'forced_wrong_hidden_predictions':0,'residual_empty_full_family_nonempty_controls':0}
    for index,case in enumerate(public['cases']):
        kwargs=arguments(case['instance']); label=labels[case['id']]
        try: expected=reference.oracle(**kwargs,max_points=2_000_000)
        except reference.ReferenceLimit as exc:
            outcomes.append({'id':case['id'],'stratum':label['stratum'],'status':'REFERENCE_INCOMPLETE','reason':str(exc)})
            totals['incomplete_outputs']+=2; continue
        complete=serialize_relation(expected)
        theta=[0]*31
        for j,v in label['plant']:theta[j]=v
        alpha,beta=reference.descriptor(theta); plant_R=reference.residual(alpha,beta)
        values=label['true_values']; model_truth=tuple(values) in expected['joints']
        removed=label['stratum'] in {'removed-C','removed-B','forced-C-empty-residual','forced-B-empty-residual','shared-prediction-C-dependent'}
        require(plant_R != removed,'frozen plant predicate classification')
        if label['override'] is None and plant_R:
            require((alpha,beta) in expected['lifts'],'supported plant must be in complete relation')
        if removed:require((alpha,beta) not in expected['lifts'],'removed plant leaked into residual')
        if label['stratum'].startswith('forced-'):
            require(expected['status']=='EMPTY','forced removed control must have empty residual')
            require(all(sum(x*y for x,y in zip(reference.feature_row(kwargs['contexts'][i]),theta))%26==v
                        for i,v in kwargs['observed'].items()),'full-family nonempty plant witness')
            totals['residual_empty_full_family_nonempty_controls']+=1
        if label['stratum']=='out-of-family-dependent-twin':
            require(kwargs['contexts'][89]==kwargs['contexts'][90] and values[89]!=values[90]
                    and 89 in kwargs['observed'] and 90 not in kwargs['observed'] and not model_truth,
                    'out-of-family duplicate-context contradiction')
        if label['kind']=='contiguous97-symbol-trace':
            require(len(kwargs['contexts'])==91 and all(kwargs['contexts'][i+1][1:]==kwargs['contexts'][i][:-1]
                    for i in range(90)),'causal history overlap')
        if label['stratum']=='E-projection-puncture':
            points=expected['pieces'][((2,28),(2,))]
            require({v[1] for v in points}==set(range(1,13)),'E scalar puncture')
        if label['stratum']=='C-projection-puncture':
            points=expected['pieces'][((28,),(22,))]
            require({v[0] for v in points}==set(range(13))-{1,12},'C scalar punctures')
        record={'id':case['id'],'stratum':label['stratum'],'dependency_id':label['dependency_id'],'kind':label['kind'],
                'relation_status':expected['status'],'pieces':len(expected['pieces']),
                'canonical_functions':len(expected['lifts']),'joint_predictions':len(expected['joints']),
                'truth_joint_in_residual':model_truth,'modes':{}}
        totals['pieces']+=len(expected['pieces']); totals['canonical_functions']+=len(expected['lifts']); totals['joint_predictions']+=len(expected['joints'])
        for mode in ('normal','optimized'):
            name=f'{index:02d}-{mode}'; output=sealed.get(name)
            entry=next(r for r in progress['completed'] if r['name']==name)
            if entry['status']=='FAILED' or output is None:
                record['modes'][mode]={'status':'FAILED'}; totals['failed_jobs']+=1; continue
            require(output['id']==case['id'] and output['index']==index and output['mode']==mode
                    and output['input_sha256']==a.input_sha256 and output['manifest_sha256']==a.manifest_sha256,'output identity')
            if output['status']=='INCOMPLETE':
                record['modes'][mode]={'status':'INCOMPLETE','reason':output.get('reason')}; totals['incomplete_outputs']+=1; continue
            try:
                require(output['status']=='VERIFIED' and output['reference_relation']==complete,'complete stored reference relation mismatch')
                checked=reference.verify_result(**kwargs,result=output['engine_result'],expected=expected,max_points=2_000_000,
                    expected_source_sha256=pins['sources']['residual_decoder.py'])
                require(checked==output['comparison'],'stored verification summary mismatch')
                wrong=[i for i,m in enumerate(output['engine_result']['masks']) if i not in kwargs['observed']
                       and len(m)==1 and m[0]!=values[i]]
                record['modes'][mode]={'status':'VERIFIED','forced_wrong_hidden_rows':wrong}
                totals['verified_outputs']+=1
                if mode=='normal':totals['forced_wrong_hidden_predictions']+=len(wrong)
            except (ValueError,KeyError,TypeError) as exc:
                record['modes'][mode]={'status':'CORRECTNESS_FAILURE','reason':str(exc)}
                comparison_failures.append({'job':name,'reason':str(exc)})
        outcomes.append(record)
    status='PASS' if totals['verified_outputs']==96 and not comparison_failures else 'INCOMPLETE_OR_FAILED'
    report={'status':status,'purpose':'fixed residual implementation validation; not speedup or novelty',
            'cases':48,'base_clusters':37,'dependent_controls':11,'contiguous_trace_cases':4,'algebraic_context_cases':44,
            'totals':totals,'correctness_failures':comparison_failures,'outcomes':outcomes,
            'inner_cpu_diagnostic_not_additive':inner_cpu,
            'driver_outer_inclusive_cpu':outer['child_cpu_seconds']+outer['parent_cpu_seconds'],
            'analysis_worker_cpu_so_far':time.process_time()-start,'source_manifest_sha256':a.manifest_sha256,
            'analysis_manifest_sha256':a.analysis_manifest_sha256,'truth_sha256':a.truth_sha256,
            'admission':'NONE; matbalez scope unresolved; no K4 inference'}
    verify_manifest(a.manifest,a.manifest_sha256);verify_manifest(a.analysis_manifest,a.analysis_manifest_sha256,analysis=True)
    write_new(a.out,report)

if __name__=='__main__':main()
