"""Frozen complete-relation validation and truth analysis; never tunes a model."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import time
from common import ROOT, arguments, load_sealed_output, read_public, require, require_bounds, sha, terminal_snapshot, verify_manifest, write_new

def serialize_relation(expected):
    return {'pieces':[{'support':list(key[0]),'beta':list(key[1]),'alpha_points':[list(v) for v in sorted(points)]}
                      for key,points in sorted(expected['pieces'].items())],
            'canonical_descriptors':[{'alpha':list(key[0]),'beta':list(key[1])} for key in sorted(expected['lifts'])],
            'joint_predictions':[list(v) for v in sorted(expected['joints'])]}

def main():
    p=argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','analysis-manifest','analysis-manifest-sha256',
                 'results','results-manifest','results-manifest-sha256','truth','truth-sha256','custody','custody-sha256','outer-receipt','outer-receipt-sha256','out'):
        p.add_argument('--'+name,required=True)
    a=p.parse_args(); require_bounds(180,768); start=time.process_time()
    pins=verify_manifest(a.manifest,a.manifest_sha256)
    verify_manifest(a.analysis_manifest,a.analysis_manifest_sha256,analysis=True)
    public=read_public(a.input,a.input_sha256); dest=Path(a.results)
    custody=json.loads(Path(a.custody).read_text())
    require(sha(a.custody)==a.custody_sha256 and custody['public_sha256']==a.input_sha256
            and custody['truth_sha256']==a.truth_sha256 and custody['source_manifest_sha256']==a.manifest_sha256
            and custody['analysis_manifest_sha256']==a.analysis_manifest_sha256,'custody seals')
    require(sha(a.results_manifest)==a.results_manifest_sha256,'externally retained pre-truth terminal seal required')
    terminal=json.loads(Path(a.results_manifest).read_text())
    snapshot=terminal_snapshot(dest,a.input,a.input_sha256,a.manifest,a.manifest_sha256,pins,a.outer_receipt,a.outer_receipt_sha256)
    snapshot.update(version='residual-terminal-seal-1',custody_sha256=a.custody_sha256,
                    truth_sha256=a.truth_sha256,analysis_manifest_sha256=a.analysis_manifest_sha256)
    require(terminal==snapshot,'terminal inventory/command/resource seal mismatch')
    progress=json.loads((dest/'progress.json').read_text())
    entries={entry['name']:entry for entry in progress['completed']}
    inner_cpu=terminal['inner_cpu_diagnostic_not_additive']
    # All source, input, output and job/accounting seals precede reading truth.
    require(sha(a.truth)==a.truth_sha256,'truth release seal')
    truth=json.loads(Path(a.truth).read_text()); seed=bytes.fromhex(truth['seed_hex'])
    require(len(seed)==32 and hashlib.sha256(seed).hexdigest()==custody['seed_sha256'],'seed commitment')
    from generate import generate
    replay_public,replay_truth=generate(seed)
    require(replay_public==public and replay_truth==truth,'deterministic custodian generation replay')
    require(sum(c['dependency_id'] is not None for c in truth['cases'])==11,'dependent-control count')
    import reference
    labels={c['id']:c for c in truth['cases']}; inputs={c['id']:c['instance'] for c in public['cases']}
    require(sum(c['kind']=='contiguous97-symbol-trace' for c in truth['cases'])==4,'trace stratum count')
    dependency_checks=[]
    def plant_descriptor(label):
        vector=[0]*31
        for j,v in label['plant']:vector[j]=v
        return reference.descriptor(vector)
    for label in truth['cases']:
        if label['dependency_id'] is None:continue
        base=labels[label['dependency_id']]
        require(base['dependency_id'] is None and inputs[label['id']]==inputs[base['id']], 'one-level dependent identical input')
        if label['stratum']=='alias-dependent':
            require(plant_descriptor(label)==plant_descriptor(base) and label['true_values']==base['true_values'],'alias pair equivalence')
        elif label['stratum']=='shared-prediction-C-dependent':
            require(plant_descriptor(label)!=plant_descriptor(base) and label['true_values']==base['true_values']
                    and not reference.residual(*plant_descriptor(label)) and reference.residual(*plant_descriptor(base)),
                    'distinct old/new functions with identical finite predictions')
        elif label['stratum']=='out-of-family-dependent-twin':
            require([i for i,(x,y) in enumerate(zip(label['true_values'],base['true_values'])) if x!=y]==[90],
                    'twin changes exactly fixed unobserved row90')
        else:raise ValueError('unknown dependency class')
        dependency_checks.append({'id':label['id'],'base':base['id'],'stratum':label['stratum'],'verified':True})
    outcomes=[]; comparison_failures=[]
    totals={'verified_outputs':0,'incomplete_outputs':0,'failed_jobs':0,'pieces':0,'canonical_functions':0,
            'joint_predictions':0,'forced_wrong_hidden_predictions':0,'residual_empty_full_family_nonempty_controls':0}
    for index,case in enumerate(public['cases']):
        expected=None;complete=None;output=None
        kwargs=arguments(case['instance']); label=labels[case['id']]
        try: expected=reference.oracle(**kwargs,max_points=2_000_000)
        except reference.ReferenceLimit as exc:
            modes={}
            for mode in ('normal','optimized'):
                name=f'{index:02d}-{mode}';entry=entries[name]
                if entry['status']=='FAILED' or entry['output_sha256'] is None:
                    modes[mode]={'stored_status':'FAILED','analysis_status':'REFERENCE_INCOMPLETE'};totals['failed_jobs']+=1
                else:
                    output=load_sealed_output(dest/(name+'.json'),entry['output_sha256'])
                    modes[mode]={'stored_status':output['status'],'stored_reason':output.get('reason'),
                                 'analysis_status':'REFERENCE_INCOMPLETE'};totals['incomplete_outputs']+=1
            outcomes.append({'id':case['id'],'stratum':label['stratum'],'status':'REFERENCE_INCOMPLETE','reason':str(exc),'modes':modes})
            continue
        complete=serialize_relation(expected)
        theta=[0]*31
        for j,v in label['plant']:theta[j]=v
        alpha,beta=reference.descriptor(theta); plant_R=reference.residual(alpha,beta)
        values=label['true_values']; model_truth=tuple(values) in expected['joints']
        removed=label['stratum'] in {'removed-C','removed-B','forced-C-empty-residual','forced-B-empty-residual','shared-prediction-C-dependent'}
        require(plant_R != removed,'frozen plant predicate classification')
        if label['override'] is None and plant_R:
            require((alpha,beta) in expected['lifts'],'supported plant must be in complete relation')
        if removed:require((alpha,beta) not in expected['lifts'],'removed plant leaked into residual')
        if label['stratum'].startswith('forced-'):
            require(expected['status']=='EMPTY','forced removed control must have empty residual')
            require(all(sum(x*y for x,y in zip(reference.feature_row(kwargs['contexts'][i]),theta))%26==v
                        for i,v in kwargs['observed'].items()),'full-family nonempty plant witness')
            totals['residual_empty_full_family_nonempty_controls']+=1
        if label['stratum']=='out-of-family-dependent-twin':
            require(kwargs['contexts'][89]==kwargs['contexts'][90] and values[89]!=values[90]
                    and 89 in kwargs['observed'] and 90 not in kwargs['observed'] and not model_truth,
                    'out-of-family duplicate-context contradiction')
        if label['kind']=='contiguous97-symbol-trace':
            require(len(kwargs['contexts'])==91 and all(kwargs['contexts'][i+1][1:]==kwargs['contexts'][i][:-1]
                    for i in range(90)) and sorted(kwargs['observed'])==list(range(15,28))+list(range(57,68)),
                    'causal history overlap and fixed public-position pattern')
        if label['stratum']=='E-projection-puncture':
            points=expected['pieces'][((2,28),(2,))]
            require({v[1] for v in points}==set(range(1,13)),'E scalar puncture')
        if label['stratum']=='C-projection-puncture':
            points=expected['pieces'][((28,),(22,))]
            require({v[0] for v in points}==set(range(13))-{1,12},'C scalar punctures')
        record={'id':case['id'],'stratum':label['stratum'],'dependency_id':label['dependency_id'],'kind':label['kind'],
                'relation_status':expected['status'],'pieces':len(expected['pieces']),
                'canonical_functions':len(expected['lifts']),'joint_predictions':len(expected['joints']),
                'truth_joint_in_residual':model_truth,'modes':{}}
        totals['pieces']+=len(expected['pieces']); totals['canonical_functions']+=len(expected['lifts']); totals['joint_predictions']+=len(expected['joints'])
        for mode in ('normal','optimized'):
            name=f'{index:02d}-{mode}';entry=entries[name];output=None
            if entry['status']=='FAILED' or entry['output_sha256'] is None:
                record['modes'][mode]={'status':'FAILED'}; totals['failed_jobs']+=1; continue
            output=load_sealed_output(dest/(name+'.json'),entry['output_sha256'])
            require(output['id']==case['id'] and output['index']==index and output['mode']==mode
                    and output['input_sha256']==a.input_sha256 and output['manifest_sha256']==a.manifest_sha256,'output identity')
            if output['status']=='INCOMPLETE':
                if output['engine_result'] is not None and output['engine_result'].get('status')=='INCOMPLETE':
                    reference.verify_result(**kwargs,result=output['engine_result'],expected=expected,max_points=2_000_000,
                        expected_source_sha256=pins['sources']['residual_decoder.py'])
                record['modes'][mode]={'status':'INCOMPLETE','reason':output.get('reason')}; totals['incomplete_outputs']+=1; continue
            try:
                require(output['status']=='VERIFIED' and output['reference_relation']==complete,'complete stored reference relation mismatch')
                checked=reference.verify_result(**kwargs,result=output['engine_result'],expected=expected,max_points=2_000_000,
                    expected_source_sha256=pins['sources']['residual_decoder.py'])
                require(checked==output['comparison'],'stored verification summary mismatch')
                wrong=[i for i,m in enumerate(output['engine_result']['masks']) if i not in kwargs['observed']
                       and len(m)==1 and m[0]!=values[i]]
                record['modes'][mode]={'status':'VERIFIED','forced_wrong_hidden_rows':wrong}
                totals['verified_outputs']+=1
                if mode=='normal':totals['forced_wrong_hidden_predictions']+=len(wrong)
            except (ValueError,KeyError,TypeError) as exc:
                record['modes'][mode]={'status':'CORRECTNESS_FAILURE','reason':str(exc)}
                comparison_failures.append({'job':name,'reason':str(exc)})
        outcomes.append(record)
    status='PASS' if totals['verified_outputs']==96 and not comparison_failures else 'INCOMPLETE_OR_FAILED'
    report={'status':status,'purpose':'fixed residual implementation validation; not speedup or novelty',
            'cases':48,'base_clusters':37,'dependent_controls':11,'contiguous_trace_cases':4,'algebraic_context_cases':44,
            'totals':totals,'correctness_failures':comparison_failures,'dependency_checks':dependency_checks,'outcomes':outcomes,
            'inner_cpu_diagnostic_not_additive':inner_cpu,
            'driver_outer_inclusive_cpu':terminal['outer_inclusive_cpu'],
            'analysis_worker_cpu_so_far':time.process_time()-start,'source_manifest_sha256':a.manifest_sha256,
            'analysis_manifest_sha256':a.analysis_manifest_sha256,'truth_sha256':a.truth_sha256,
            'terminal_results_manifest_sha256':a.results_manifest_sha256,
            'admission':'NONE; matbalez scope unresolved; no K4 inference'}
    verify_manifest(a.manifest,a.manifest_sha256);verify_manifest(a.analysis_manifest,a.analysis_manifest_sha256,analysis=True)
    write_new(a.out,report)

if __name__=='__main__':main()
