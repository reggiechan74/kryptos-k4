# Proposed fresh residual implementation validation

**NOT APPROVED. NO SEED OR FRESH INPUT DRAWN.**

Read [PROTOCOL.md](PROTOCOL.md), [FREEZE.json](FREEZE.json),
[ANALYSIS-MANIFEST.json](ANALYSIS-MANIFEST.json) and
[RESOURCE-ALLOCATION.json](RESOURCE-ALLOCATION.json).

-48 fixed cases,96 normal/optimized outputs;37 base clusters and11 dependent controls.
-Four supported cases use contiguous97-symbol histories and the prior public-position
  observation pattern;44 are explicitly algebraic/context-table controls.
-Exact complete support/beta fibers, canonical functions and joint predictions are
  compared against the repaired independent original-coordinate reference v2.
-No solver, dictionary, residual predicate or saturation change; no novelty/speed claim.
-Newstage allocation2,618CPU seconds, sequential peak≤2GiB; retained project
  allocation15,880CPU seconds of28,800. Known measurements are separate from reserves.

The source manifest SHA256 is
`4c98ac170b0770b487b655dc4ba1ac8c96802669e1287e8a8090c1190669abc8`.
Analysis manifest SHA256 is
`e64d9bd04a457cb5b318ecfe6200467c774077c5c6ceaeb63a3bee83f5bda46a`.
Candidate histories r0/r1/r2 are preserved; r3 is the current proposal.

## Before any execution

1. Obtain independent proposed-protocol/driver/analysis review at these exact pins.
2. The project owner explicitly approves one draw, with exact public and secret directories.
3. Separate custodian retains source/analysis/resource/approval hashes and uses
   the bounded commands in the protocol. Approval is consumed before seed creation.
4. Keep the same frozen source root for driver, terminal sealer and analyzer:
   receipt commands bind exact canonical paths. Public/secret directories must be
   non-nested; implementation worker receives no secret path.
5. Custodian seals terminal inventory and sends its SHA to the project owner for external
   retention **before** releasing truth. Analyze only with all required seals.

No automatic draw, execution, retry, resumption or replenishment is authorized by
the presence of these files. A cap or missing receipt remains incomplete/unknown.
Partial artifacts and failure logs are retained, not interpreted as exact results.
Historical matbalez scope remains unresolved; no K4 admission follows.
