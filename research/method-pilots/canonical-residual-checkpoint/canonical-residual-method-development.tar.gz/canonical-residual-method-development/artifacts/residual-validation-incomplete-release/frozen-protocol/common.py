"""Shared sealing/shape helpers; no data generation at import."""
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import signal
import shutil
import sys

ROOT = Path(__file__).resolve().parent
SOURCE_NAMES = {'residual_decoder.py', 'affine_filter.py', 'reference.py',
    'bounded_checked.py', 'common.py', 'generate.py', 'run_one.py', 'driver.py', 'seal_results.py',
    'analyze.py', 'PROTOCOL.md', 'RESOURCE-ALLOCATION.json', 'ANALYSIS-MANIFEST.json'}
ANALYSIS_NAMES = {'analyze.py', 'reference.py', 'generate.py', 'common.py', 'bounded_checked.py'}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_new(path, value):
    path = Path(path)
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, separators=(',', ':'), allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def atomic(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w') as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def atomic_bytes(path, payload):
    require(type(payload) is bytes, 'exact serialized bytes required')
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('wb') as f:
        f.write(payload);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
    fd=os.open(path.parent,os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def load_sealed_output(path, pin):
    path=Path(path)
    require(path.stat().st_size<=32*1024**2,'output exceeds frozen32MiB byte cap')
    require(sha(path)==pin,'sealed output changed')
    return json.loads(path.read_text())

def verify_manifest(path, pin, analysis=False):
    require(sha(path) == pin, 'manifest seal mismatch')
    value = json.loads(Path(path).read_text())
    required = ANALYSIS_NAMES if analysis else SOURCE_NAMES
    require(type(value) is dict and set(value) == {'sources'} and set(value['sources']) == required,
            'manifest source set mismatch')
    for name, expected in value['sources'].items():
        require(sha(ROOT/name) == expected, 'source pin mismatch: '+name)
    return value

def require_bounds(cpu, memory_mib):
    require(resource.getrlimit(resource.RLIMIT_CPU) == (cpu, cpu+1), 'approved CPU wrapper required')
    n = memory_mib*1024**2
    require(resource.getrlimit(resource.RLIMIT_AS) == (n, n), 'approved memory wrapper required')
    death = ctypes.c_int()
    require(ctypes.CDLL(None).prctl(2, ctypes.byref(death), 0, 0, 0) == 0
            and death.value == signal.SIGKILL, 'parent-death guard required')

def read_public(path, pin):
    require(sha(path) == pin, 'public input seal mismatch')
    value = json.loads(Path(path).read_text())
    require(type(value) is dict and set(value) == {'cases'} and len(value['cases']) == 48,
            'exactly48 solver-only cases required')
    ids = set()
    for case in value['cases']:
        require(set(case) == {'id', 'instance'} and type(case['id']) is str and case['id'] not in ids,
                'case ID or truth leakage')
        ids.add(case['id'])
        require(set(case['instance']) == {'contexts', 'observed', 'sparsity', 'allowed_features'},
                'solver-only instance keys required')
    return value

def arguments(instance):
    obs = instance['observed']
    require(type(obs) is dict and all(type(k) is str and k.isdigit() and str(int(k)) == k for k in obs),
            'canonical serialized observations required')
    return dict(instance, observed={int(k): v for k, v in obs.items()})

def finite_cpu(value):
    require(type(value) in (int,float) and math.isfinite(value) and value>=0, 'invalid finite CPU component')
    return value

def command_identity(command, script, flags, optimized=False):
    require(type(command) is list and all(type(x) is str for x in command), 'receipt command shape')
    require(bool(command) and os.path.realpath(shutil.which(command[0]) or '')==os.path.realpath(sys.executable),
            'receipt Python executable mismatch')
    prefix=[str(ROOT/script)] if not optimized else ['-O',str(ROOT/script)]
    require(command[1:1+len(prefix)]==prefix, 'receipt script/mode mismatch')
    tail=command[1+len(prefix):]
    require(len(tail)==2*len(flags) and len(set(tail[::2]))==len(flags)
            and dict(zip(tail[::2],tail[1::2]))==flags, 'receipt invocation arguments mismatch')

def terminal_snapshot(results, input_path, input_pin, manifest_path, manifest_pin, pins, outer_path, outer_pin):
    """No truth access. Reconstruct and authenticate an entire terminal job tree."""
    import random
    dest=Path(results).resolve(); input_path=Path(input_path).resolve(); manifest_path=Path(manifest_path).resolve()
    outer_path=Path(outer_path).resolve()
    require(dest not in outer_path.parents, 'outer receipt must be outside results inventory')
    require(sha(outer_path)==outer_pin, 'outer receipt seal')
    outer=json.loads(outer_path.read_text())
    require(outer['limits']=={'cpu_seconds_per_process':240,'address_space_bytes_per_process':512*1024**2,'wall_seconds':3600}
            and type(outer['exit_code']) is int and outer['exit_code']==0 and outer['wall_timeout'] is False
            and outer['parent_death_guard'] is True, 'terminal root resource receipt')
    command_identity(outer['command'],'driver.py',{'--input':str(input_path),'--input-sha256':input_pin,
                     '--manifest':str(manifest_path),'--manifest-sha256':manifest_pin,'--out':str(dest)})
    outer_child=finite_cpu(outer['child_cpu_seconds']);outer_parent=finite_cpu(outer['parent_cpu_seconds'])
    require(outer_parent<=241,'outer supervisor hard CPU allowance exceeded')
    outer_cpu=outer_child+outer_parent
    progress=json.loads((dest/'progress.json').read_text())
    require(progress['status']=='TERMINAL' and progress['planned']==96 and len(progress['completed'])==96
            and progress['in_flight'] is None and progress['outstanding_cpu_reserve']==0
            and progress['accounting_complete'] is True and progress['cpu_cap']==1500
            and finite_cpu(progress['inclusive_inner_cpu_actual_known'])<=1500, 'terminal complete accounting required')
    require(progress['input_sha256']==input_pin and progress['manifest_sha256']==manifest_pin,'progress input identity')
    jobs=[(i,mode) for i in range(48) for mode in ('normal','optimized')]
    random.Random(202610312008).shuffle(jobs)
    require(json.loads((dest/'schedule.json').read_text())==[list(j) for j in jobs],'fixed schedule')
    require([r['name'] for r in progress['completed']]==[f'{i:02d}-{m}' for i,m in jobs],'exact terminal job inventory')
    post=json.loads((dest/'post-run-integrity.json').read_text())
    require(post=={'sources':pins['sources'],'input_sha256':input_pin,'manifest_sha256':manifest_pin},'post-run seals')
    artifact_names={'progress.json','schedule.json','post-run-integrity.json'}; inner_cpu=0.0
    for entry,(index,mode) in zip(progress['completed'],jobs):
        name=entry['name']; output=dest/(name+'.json'); receipt=dest/(name+'.resource.json')
        require(sha(receipt)==entry['resource_sha256'],'stage resource seal')
        rr=json.loads(receipt.read_text())
        require(rr['limits']=={'cpu_seconds_per_process':40,'address_space_bytes_per_process':512*1024**2,'wall_seconds':90}
                and rr['parent_death_guard'] is True and type(rr['wall_timeout']) is bool
                and type(rr['exit_code']) is int, 'stage limits/exit shape')
        command_identity(rr['command'],'run_one.py',{'--input':str(input_path),'--input-sha256':input_pin,
            '--manifest':str(manifest_path),'--manifest-sha256':manifest_pin,'--index':str(index),
            '--mode':mode,'--out':str(output)}, optimized=mode=='optimized')
        expected_return=rr['exit_code'] if rr['exit_code']>=0 else 1
        require(type(entry['returncode']) is int and entry['returncode']==expected_return
                and (not rr['wall_timeout'] or rr['exit_code']!=0),'stage return/timeout linkage')
        child_cpu=finite_cpu(rr['child_cpu_seconds']);parent_cpu=finite_cpu(rr['parent_cpu_seconds'])
        require(child_cpu<=41 and parent_cpu<=41,'inner per-process hard CPU allowance exceeded')
        used=child_cpu+parent_cpu
        require(used<=82,'stage hard-reserve receipt exceeded');inner_cpu+=used
        for suffix,key in (('.stdout.txt','stdout_sha256'),('.stderr.txt','stderr_sha256')):
            require(sha(dest/(name+suffix))==entry[key],'stage log seal');artifact_names.add(name+suffix)
        artifact_names.add(name+'.resource.json')
        require(entry['status'] in ('OUTPUT_SEALED','FAILED'),'invalid terminal stage status')
        if entry['output_sha256'] is not None:
            require(output.stat().st_size<=32*1024**2,'stage output exceeds32MiB before read')
            require(sha(output)==entry['output_sha256'],'stage output seal');artifact_names.add(name+'.json')
        else:require(not output.exists(),'unsealed stage output')
        partial=output.with_suffix(output.suffix+'.tmp')
        if entry['partial_output_sha256'] is not None:
            require(partial.stat().st_size<=32*1024**2 and sha(partial)==entry['partial_output_sha256'],
                    'partial output diagnostic seal/size')
            require(entry['status']=='FAILED','partial output cannot accompany successful stage')
            artifact_names.add(name+'.json.tmp')
        else:require(not partial.exists(),'unsealed partial output diagnostic')
        require(entry['status']==('OUTPUT_SEALED' if entry['returncode']==0 and output.exists() else 'FAILED'),
                'stage status does not match receipt/output')
    require(abs(inner_cpu-progress['inclusive_inner_cpu_actual_known'])<1e-7,'inner resource reconciliation')
    require(outer_cpu+0.01>=inner_cpu,'outer inclusive CPU below accounted descendants')
    require(-0.01<=outer_child-inner_cpu<=241.01,'outer driver own CPU allowance exceeded or descendant undercount')
    require({f.name for f in dest.iterdir()}==artifact_names,'extra/missing terminal artifact')
    return {'results_dir':str(dest),'input_sha256':input_pin,'source_manifest_sha256':manifest_pin,
            'outer_receipt_sha256':outer_pin,'outer_inclusive_cpu':outer_cpu,'inner_cpu_diagnostic_not_additive':inner_cpu,
            'artifact_sha256':{name:sha(dest/name) for name in sorted(artifact_names)}}
