# Proposed fixed-residual fresh validation — NO DRAW OR EXECUTION AUTHORIZED

Version1,2026-10-31. Purpose: independently validate implementation of the exact
new canonical residual on fresh synthetic inputs. **Not a speedup campaign,
proof of historical novelty, model-membership test, K4 admission or target run.**
Historical matbalez recurrence support remains unresolved.

## Prerequisites and immutable scope

The engine is exactly SHA256
`be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`.
The generic core stays at `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`.
Independent reference v2 is exactly
`618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`.
The separate full implementation review passed these pins. V2 only hardens all
public reference point-cap entry guards; historical v1 artifacts remain intact.

Before any seed or case is drawn, independently review this protocol, generator,
driver, complete-relation analysis, source manifests, resource ledger and custody
steps. The project owner must then explicitly approve a matching draw. The generator rejects
missing/mismatched approval, source, analysis and resource hashes. No source
optimization, feature tweak, post-fit predicate, saturation, range extension,
signal-based rejection, failed-case replacement or adaptive redraw is allowed.
Any source correction after draw preserves the draw/failure and withdraws a fresh
blind claim for changed code; it is not permission to draw another cohort.

Fixed model:31 original features (constant,6 lags,6 squares,15 pair products and
3 full-Z26 equality indicators), common original support≤3. Canonical alpha∈F13^31
and beta∈F2^25 merge lag/square parity aliases. R=E minus(B union C): E has an
equality descriptor nonzero in either field; B has beta supported only on constant
and lag1; C is exactly156 functions b±one equality indicator. Full equality is
evaluated before field reduction. All feasible support/beta fibers are retained;
minimum sparse lifts and cross-piece provenance are required. No full-mask
subtraction or finite-prediction eligibility rule is used.

## Predeclared48 cases,37 base clusters and11 dependent controls

All categories, constants and sampling operations are implemented in `generate.py`
before draw. One fresh256-bit custodian seed determines one cohort. The seed has
no relation to prior v1/v2/v3 or residual-development data. Case order is shuffled
once by that seed; only neutral IDs and solver inputs are released.

| Stratum | Count | Fixed construction and interpretation |
| --- | ---: | --- |
| Supported R |12|Four equality-mod13/odd-lag plants on contexts from fresh contiguous97-symbol streams; four pure-parity-equality plants; four mixed-field equality plants. Latter8 use arbitrary91-row algebraic context tables. No equality-signal redraw. |
| Removed plants |8|Four C and four B plants on arbitrary91-row tables. The planted global function must be absent from R, but other residual laws may still fit. No assumption of empty residual. |
| Tiny exact controls |8|Two forced C and two forced B cases with residual empty while a full-family plant exists; one E zero-puncture and one C±1-puncture control; one lag/square alias base plus its dependent equivalent representation. Declared subdictionaries retain original feature indices. |
| Shared finite predictions |8|Four residual bases and four dependent C counterparts on identical no-equality context tables. Their finite outputs agree although global functions and eligibility differ. The no-equality map is constructive, not solver-based rejection. |
| Out-of-family twins |12|Six supported bases and six dependent twins. Rows89/90 have identical contexts;89 is observed,90 unobserved. Twin truth changes row90 by1, proving it is outside every deterministic function of the six inputs. Solver input is identical to its base. |

Exactly4 cases are realizable contiguous trace tests:97 freshly sampled symbols,
six-lag context rows at positions6..96,91 outputs. Their24 observed ciphertext
positions are21..33 and63..73 zero-based, hence context rows15..27 and57..67.
This is the same PUBLIC POSITION PATTERN as prior synthetic methodology, not
target letters, target ciphertext or target-derived responses. The generator never checks whether equality occurred or
the planted function is identifiable. Degenerate cases remain in the cohort.
The other44 are explicitly algebraic API/context-table controls, not claimed
contiguous ciphertexts or independently generated causal cryptosystems.

Ordinary algebraic full31 cases also use91 contexts, with24 fixed observed row
indices floor(90*k/23), k=0..23. Twin bases use observed rows0..22 and89. Tiny observation sets and
subdictionaries are fixed in the source. Dependent controls do not increase an
independent recovery sample count; no confidence interval or population claim
is inferred from this deliberately structured mixture. The4 causal cases replace
4 previously proposed arbitrary supported cases at the project owner's pre-draw request.
A further pre-draw correction aligns their observation geometry with the prior
synthetic public-position schema; it does not access target symbols. Historical
candidate r0 is preserved under `history/r0/`.

## Operational seed/truth custody

After explicit approval, a separate custodian runs the pinned generator under
the bounded launcher. It commits SHA256(seed) before generation and retains that
commitment on failure. Seed and truth live in a separate custodian directory,
not the implementation workspace. Solver input contains only IDs and instances:
contexts, observed responses, sparsity and allowed original feature IDs. It has
no plants, strata, dependency labels, true hidden values or seed.

Approval binds exact absolute public/secret destination directories, which must
be separate and non-nested. An exclusive durable approval-use marker is written
BEFORE any seed is drawn; a failed/uncertain attempt consumes that approval.
New paths cannot be substituted to reuse it. Custodian seals public input,
secret truth, seed commitment, approval and manifests.
The driver/worker never receives a truth path. Implementation workers must not
inspect custodian files until all96 planned jobs are sealed/accounted. This is
operational separation, **not cryptographic/access-control blindness**: collaborators
share a filesystem. No claim that category structure is statistically hidden is made.

Truth is released only after terminal96-job inventory, output/resource/log hashes,
source/input post-run seals and zero outstanding reserve have been checked by the
separate bounded `seal_results.py` custodian step. It binds exact root and child
invocation commands/paths/modes, exit/timeout values, finite nonnegative CPU
components and inclusive outer CPU at least summed inner CPU (0.01second rounding
tolerance).
Each inner CPU component must be≤41seconds and outer supervisor≤241seconds;
outer driver CPU minus summed inner CPU must be in[-0.01,241.01]seconds. Thus
the receipt values themselves must respect the individual hard allowances.
It seals the COMPLETE artifact inventory, outer receipt and source/input/custody/
truth commitments. The project owner must retain its terminal-manifest
SHA externally BEFORE truth release; self-declared progress hashes are insufficient.
The terminal manifest and outer receipt stay outside the result inventory.

Analysis requires externally retained source, analysis, custody, terminal-results,
truth and outer-receipt hashes. It reconstructs and checks the complete terminal
seal BEFORE opening truth. After release it deterministically replays generation from the
committed seed and checks exact public/truth equality; this is replay of the one
draw, not a new draw. Incomplete runs keep seed/input/truth commitments and cannot
silently restart, resume, replace failed cases or replenish resources.

## Primary exact comparison

Exactly96 jobs: every case once under normal Python and once under `-O`. This is
robustness validation, not96 independent cases or paired timing repetitions.
The job schedule uses public fixed seed202610312008, independent of truth.

Each worker first runs the unchanged engine, then the independently written
original-coordinate F13/F2 complete oracle. It tests R directly after CRT rather
than sharing the canonical cut compiler. Reference point cap2,000,000 applies to
every public cap API, including trusted memo paths. Complete published alpha
fibers are enumerated and checked against the oracle; every generic alpha witness,
minimal original sparse witness, residual predicate, common support, marginal,
feasibility result and all-piece provenance is checked. The full reference
relation is retained: every feasible support/beta alpha set, canonical descriptor,
and joint output vector. No comparison stops at marginal masks. Worker caps and
writes the SAME compact serialized byte string, including newline, rather than
checking compact size and writing a larger pretty version. Sealer and analyzer
reject outputs above32MiB before reading. Pre-truth checks retain paths/hashes
only; analysis loads one case/mode output at a time, not96 parsed JSON trees.

Analysis independently recomputes each of48 complete reference relations and
verifies both sealed modes. It validates the planted canonical eligibility and
supported-plant retention, four explicit empty-residual/full-family-nonempty
controls, partial projection punctures, alias equivalence, shared input/finite
predictions, and duplicate-context misspecification proofs. It reports complete
fiber/function/joint counts separately, never interprets container counts as
functions or a Cartesian product of scalar masks as a joint relation.

Supported truth need not be identified. Removed C/B plants can have residual
alternatives. Identical finite predictions do not imply identical global laws.
Out-of-family twins must remain separate dependent controls; report every forced
wrong hidden prediction rather than dilute it into in-family performance.

## Status/failure contract and success criterion

Engine EXACT means complete nonempty R relation; EMPTY means exact bounded
emptiness, not forced certainty; INCOMPLETE has no exact masks/fibers/witnesses.
Wrapper VERIFIED means the complete independent comparison passed. A worker may
return INCOMPLETE for an engine/reference/output cap. Oversized fibers, complete
output above32MiB, memory death, CPU/wall expiry or missing artifacts are retained
as incomplete/failed, never interpreted as empty, omitted or replaced.

The driver records every valid stage receipt and hashed stdout/stderr log, and
continues after a receipted failed job without retry. A missing/invalid receipt retains its outstanding
reservation and stops. TERMINAL means96 jobs accounted, **not** correctness PASS.
Analysis can report PASS only if all96 outputs independently verify. If its own
oracle caps, each mode's existing failed/incomplete/stored-verified status stays
separate from analysis-reference-incomplete. Any cap or
failed job prevents full-cohort PASS. Exact completed subcases may be reported
with their own scope, not converted into whole-cohort completeness. Correctness
failure blocks use and triggers a retained diagnosis, not a predicate change.

Report all denominators, per-stratum results, dependent links, verified/empty/
incomplete/failed cases, exact relation counts, witness checks, actual+reserved
CPU, peak memory and every missing measurement. No speedup ranking, novelty
claim, mechanistic recovery claim or target-stage approval follows from PASS.

## Frozen resource allocation and launch topology

`RESOURCE-ALLOCATION.json` records allocations separately from observed CPU.
Prior retained project allocations are600(v1)+6754(v2)+4908(v3)+1000(other
math/module/compiler development and audits). They are not added to their
measured actuals a second time. Latest v3 actual is488.783194CPU seconds with no
outstanding execution reserve. The other-development ledger deduplicates known
receipts and leaves orchestration/startup/inspection gaps explicit; it does not
claim a fully measured project total.

This stage allocates2,618CPU seconds: generator/supervisor62; driver/supervisor
own hard allowance482; inclusive inner-job actual+reservation cap1500; analysis/
supervisor362; pre-truth custodian sealing12; protocol checks/review reserve200.
Total retained project allocation15,880CPU seconds <28,800 (8CPU hours), leaving12,920 unallocated.
No reserve silently replenishes. Unknown historical overhead remains within the
conservative other-development reserve, not a claim of measured accounting.

Approved launcher is copied unchanged from audited v3. Limits apply to every
process, including supervisors, with Linux parent-death cascade. Sequential
topology has at most four512MiB nodes during driver+one worker, ≤2GiB; analysis
uses two768MiB nodes. The project owner must account any concurrent other work under8GiB.

| Stage | Soft/hard CPU per process | Memory per process | Wall |
| --- | --- | --- | --- |
| Custodian generation |30/31seconds|512MiB|120seconds|
| Driver root |240/241seconds|512MiB|3600seconds|
| One candidate+reference worker |40/41seconds|512MiB|90seconds|
| Pre-truth custodian seal |5/6seconds|512MiB|120seconds|
| Released-truth analysis |180/181seconds|768MiB|600seconds|

Before launching each worker, atomically write+fsync its82CPU reservation and
require actual+82≤1500. Release it only after a valid receipt. Root kill or
missing receipt leaves known actual plus outstanding reserve/unknown state.
Driver root inclusive resource receipt includes nested jobs and is counted ONCE
in stage/project actuals; inner receipts are separately reported diagnostics,
not added again. Worker decoder wall cap25seconds is cooperative; outer limits
remain necessary. Reference/serialization consume the same40CPU/90wall worker.

Proposed commands (paths/hashes supplied by custodian after approval):

```text
python bounded_checked.py GENERATOR_RECEIPT 30 512 120 python generate.py --approval APPROVAL --approval-sha256 APPROVAL_PIN --manifest FREEZE.json --manifest-sha256 FREEZE_PIN --public-dir NEW_PUBLIC --secret-dir NEW_SECRET
python bounded_checked.py DRIVER_RECEIPT 240 512 3600 python /ABSOLUTE/PROPOSAL/driver.py --input ABSOLUTE_PUBLIC --input-sha256 PUBLIC_PIN --manifest ABSOLUTE_FREEZE --manifest-sha256 FREEZE_PIN --out ABSOLUTE_NEW_RESULTS
python bounded_checked.py SEAL_RECEIPT 5 512 120 python seal_results.py --input ABSOLUTE_PUBLIC --input-sha256 PUBLIC_PIN --manifest ABSOLUTE_FREEZE --manifest-sha256 FREEZE_PIN --results ABSOLUTE_RESULTS --outer-receipt DRIVER_RECEIPT --outer-receipt-sha256 DRIVER_RECEIPT_PIN --custody CUSTODY --custody-sha256 CUSTODY_PIN --out TERMINAL_MANIFEST_OUTSIDE_RESULTS
python bounded_checked.py ANALYSIS_RECEIPT 180 768 600 python analyze.py --input ABSOLUTE_PUBLIC --input-sha256 PUBLIC_PIN --manifest ABSOLUTE_FREEZE --manifest-sha256 FREEZE_PIN --analysis-manifest ANALYSIS-MANIFEST.json --analysis-manifest-sha256 ANALYSIS_PIN --results ABSOLUTE_RESULTS --results-manifest TERMINAL_MANIFEST --results-manifest-sha256 EXTERNALLY_RETAINED_TERMINAL_PIN --truth RELEASED_TRUTH --truth-sha256 TRUTH_PIN --custody CUSTODY --custody-sha256 CUSTODY_PIN --outer-receipt DRIVER_RECEIPT --outer-receipt-sha256 DRIVER_RECEIPT_PIN --out NEW_ANALYSIS
```

Do not set a shell PID as BOUND_EXPECTED_PARENT; the driver passes its actual PID
only to nested launcher nodes. Each application rejects missing approved inherited
limits and parent-death guard before reading inputs. Driver/source/input/manifest/
result paths are canonical absolute paths for exact receipt binding. r0,r1,r2
remain under `history/`; r3 adds explicit individual CPU receipt ceilings and
Python-version recording. r2 closed pre-draw sealing, custody and I/O-resource findings without
changing solver predicates or drawing data. Preserve bounded partial worker
`.json.tmp` artifacts as hashed NON-RESULT diagnostics; they are never parsed as
exact outputs. All top-level generator/driver/sealer/analysis commands must
redirect stdout/stderr to new separate files; custodian retains their hashes
with the inclusive stage receipts for diagnosis, including failures. A killed
stage without a valid receipt remains unknown/reserved and cannot trigger retry.
The b=0 shared-prediction draws remain unchanged; high fibers may legitimately
be INCOMPLETE and are not a reason to redraw. No approval file, seed,
solver input, secret truth or fresh output has been created by this proposal.
