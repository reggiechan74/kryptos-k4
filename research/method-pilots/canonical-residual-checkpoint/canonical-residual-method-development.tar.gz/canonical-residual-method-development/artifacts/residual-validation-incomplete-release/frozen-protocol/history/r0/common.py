"""Shared sealing/shape helpers; no data generation at import."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal

ROOT = Path(__file__).resolve().parent
SOURCE_NAMES = {'residual_decoder.py', 'affine_filter.py', 'reference.py',
    'bounded_checked.py', 'common.py', 'generate.py', 'run_one.py', 'driver.py',
    'analyze.py', 'PROTOCOL.md', 'RESOURCE-ALLOCATION.json', 'ANALYSIS-MANIFEST.json'}
ANALYSIS_NAMES = {'analyze.py', 'reference.py', 'generate.py', 'common.py', 'bounded_checked.py'}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_new(path, value):
    path = Path(path)
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, separators=(',', ':'), allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def atomic(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w') as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def verify_manifest(path, pin, analysis=False):
    require(sha(path) == pin, 'manifest seal mismatch')
    value = json.loads(Path(path).read_text())
    required = ANALYSIS_NAMES if analysis else SOURCE_NAMES
    require(type(value) is dict and set(value) == {'sources'} and set(value['sources']) == required,
            'manifest source set mismatch')
    for name, expected in value['sources'].items():
        require(sha(ROOT/name) == expected, 'source pin mismatch: '+name)
    return value

def require_bounds(cpu, memory_mib):
    require(resource.getrlimit(resource.RLIMIT_CPU) == (cpu, cpu+1), 'approved CPU wrapper required')
    n = memory_mib*1024**2
    require(resource.getrlimit(resource.RLIMIT_AS) == (n, n), 'approved memory wrapper required')
    death = ctypes.c_int()
    require(ctypes.CDLL(None).prctl(2, ctypes.byref(death), 0, 0, 0) == 0
            and death.value == signal.SIGKILL, 'parent-death guard required')

def read_public(path, pin):
    require(sha(path) == pin, 'public input seal mismatch')
    value = json.loads(Path(path).read_text())
    require(type(value) is dict and set(value) == {'cases'} and len(value['cases']) == 48,
            'exactly48 solver-only cases required')
    ids = set()
    for case in value['cases']:
        require(set(case) == {'id', 'instance'} and type(case['id']) is str and case['id'] not in ids,
                'case ID or truth leakage')
        ids.add(case['id'])
        require(set(case['instance']) == {'contexts', 'observed', 'sparsity', 'allowed_features'},
                'solver-only instance keys required')
    return value

def arguments(instance):
    obs = instance['observed']
    require(type(obs) is dict and all(type(k) is str and k.isdigit() and str(int(k)) == k for k in obs),
            'canonical serialized observations required')
    return dict(instance, observed={int(k): v for k, v in obs.items()})
