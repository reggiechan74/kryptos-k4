"""One sealed candidate/reference comparison. Receives NO seed or truth."""
import argparse
import json
from pathlib import Path
import time
from common import ROOT, arguments, atomic, read_public, require, require_bounds, verify_manifest

def relation(expected):
    return {'pieces':[{'support':list(key[0]),'beta':list(key[1]),'alpha_points':[list(v) for v in sorted(points)]}
                      for key,points in sorted(expected['pieces'].items())],
            'canonical_descriptors':[{'alpha':list(key[0]),'beta':list(key[1])} for key in sorted(expected['lifts'])],
            'joint_predictions':[list(v) for v in sorted(expected['joints'])]}

def main():
    p=argparse.ArgumentParser()
    for name in ('input','input-sha256','manifest','manifest-sha256','out','mode'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--index',type=int,required=True); a=p.parse_args()
    require_bounds(40,512)
    require(a.mode in ('normal','optimized') and (__debug__ == (a.mode == 'normal')), 'Python mode mismatch')
    pins=verify_manifest(a.manifest,a.manifest_sha256)
    data=read_public(a.input,a.input_sha256)
    require(0<=a.index<48,'case index')
    case=data['cases'][a.index]; kwargs=arguments(case['instance'])
    import residual_decoder as decoder
    import reference
    start=time.process_time()
    result=decoder.decode(**kwargs,budget=decoder.Budget(max_seconds=25.0))
    output={'id':case['id'],'index':a.index,'mode':a.mode,'status':'INCOMPLETE',
            'input_sha256':a.input_sha256,'manifest_sha256':a.manifest_sha256,
            'engine_result':result,'comparison':None,'reference_relation':None}
    if result['status'] != 'INCOMPLETE':
        try:
            expected=reference.oracle(**kwargs,max_points=2_000_000)
            checked=reference.verify_result(**kwargs,result=result,expected=expected,max_points=2_000_000,
                expected_source_sha256=pins['sources']['residual_decoder.py'])
            output.update(status='VERIFIED',comparison=checked,reference_relation=relation(expected))
        except reference.ReferenceLimit as exc:
            output['reason']='reference cap: '+str(exc)
    else: output['reason']='engine cap: '+result['reason']
    output['worker_cpu_seconds']=time.process_time()-start
    encoded=json.dumps(output,separators=(',',':'),allow_nan=False).encode()
    if len(encoded)>32*1024**2:
        output.update(status='INCOMPLETE',reason='complete output exceeds frozen32MiB cap',
                      engine_result=None,comparison=None,reference_relation=None)
    verify_manifest(a.manifest,a.manifest_sha256); read_public(a.input,a.input_sha256)
    require(not Path(a.out).exists(),'never replace prior output')
    atomic(a.out,output)

if __name__=='__main__': main()
