# Independent residual validation protocol review — r3

## Verdict

**PASS for the proposed protocol, frozen source, and bounded operational mock scope. No outstanding implementation/protocol blocker identified.** This makes r3 eligible for the project owner's explicit approval decision; it does **not** authorize a seed draw, cohort execution, truth release, target access, or K4 admission. It is not a fresh-validation result.

Reviewed on 2026-10-31 after reading the private administrative register [reference omitted]. No producer source was edited. Historical r0/r1/r2 snapshots remain preserved. No generator was imported or called; no seed or case was drawn; no solver or real worker was executed; no actual truth bytes were read. The only deterministic mock input was a previously disclosed literal context, repeated in a clearly labeled non-cohort envelope, plus the protocol's already-public job schedule. No K4, prior holdout, or new holdout data was accessed.

### Exact reviewed SHA-256 pins

| Artifact | SHA-256 |
| --- | --- |
| `FREEZE.json` | `4c98ac170b0770b487b655dc4ba1ac8c96802669e1287e8a8090c1190669abc8` |
| `ANALYSIS-MANIFEST.json` | `e64d9bd04a457cb5b318ecfe6200467c774077c5c6ceaeb63a3bee83f5bda46a` |
| `residual_decoder.py` | `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67` |
| `affine_filter.py` | `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d` |
| `reference.py` | `618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974` |
| `bounded_checked.py` | `568db679348678a8d7f8a9beb0e05703adcb4a8de9f3f48be3c5e91db8cd8230` |
| `common.py` | `d05c32b070aff4b7aba3956c664bf45aac4e5d652aa99553d32c887bfbeb5ad8` |
| `generate.py` | `1a906e5d6855658a00b88849af1946f98367069cd1e686d5615c3862c3f8e01a` |
| `driver.py` | `551772ccafac911ddc11029ea2941dcbdcdd0529526752881fa48a13698db1df` |
| `run_one.py` | `da3dbd279522f707759c98fc61d034e3cc39869a15bc93c5054bc0bb606157c1` |
| `seal_results.py` | `847109e3bc5c038701a0ab1b8ad72010c3e39d827e7d92d06dcc955249089b1a` |
| `analyze.py` | `851c07b869b4549282e64f820ab59acb2cb39a56e7ebfce0e416be793ff1a72d` |

The machine-readable `SOURCE-PINS.json` is authoritative for every frozen file. The implementation/reference pins reuse the separate full audit at `/ARCHIVE_WORKSPACE/canonical-residual-full-review/REVIEW.md`; this review adds protocol/source orchestration review, not another solver cohort.

## Findings closed before any draw

The initial r0 was **not ready**. The author corrected these in separately preserved revisions:

1. **Mutable post-run claims were not an external pre-truth commitment.** A separate bounded custodian now reconstructs the complete terminal inventory, binds the outer receipt and custody/source/input/truth commitments, and emits a terminal-manifest SHA that the project owner must retain externally before truth release. Analysis reconstructs the same inventory before touching truth.
2. **Root and child receipt linkage/accounting were too weak.** Exact script, Python mode, unique flags, canonical input/manifest/results paths, child exit versus wrapper return code, timeout semantics, death guard, finite nonnegative CPU, per-process ceilings, aggregate reconciliation, and root-exclusive CPU allowance are now checked. Local progress/hash rewriting cannot preserve the externally retained terminal snapshot.
3. **The output cap checked different bytes from those written.** r0 wrote 8,599 pretty bytes after checking a 1,934-byte compact mock. r3 encodes once, includes its newline in the 32 MiB limit, and writes exactly those bytes. Oversize fallback clears engine/comparison/relation claims. Readers check the file-size cap before reading/hash/parsing.
4. **Analysis eagerly retained all decoded outputs.** It now keeps paths/receipt metadata and loads one case/mode output at a time. This avoids the avoidable 96-output accumulation; it does not guarantee that every individual complete reference relation fits its memory cap.
5. **Failure diagnosis, dependencies, and post-run status needed strengthening.** Hashed stdout/stderr and bounded partial `.json.tmp` NON-RESULT diagnostics are retained. Explicit alias/shared/twin invariants supplement generation replay. Post-run seal failure withdraws TERMINAL. Reference-cap analysis preserves each mode's stored status. Approval is path-bound and consumed durably before seed creation; public/secret directories must be separate and non-nested.
6. **Public observation geometry was corrected pre-draw.** Four contiguous-context cases now use context rows 15..27 and 57..67, corresponding to the requested public ciphertext-position pattern 21..33 and 63..73. This correction loaded no target letters. The b=0 shared-prediction possibility remains frozen, with cap failures retained rather than removed for tractability.

## Static generator and mathematical review

The fixed inventory is 12 supported + 8 removed + 8 tiny + 8 shared-prediction + 12 twin cases = **48 cases**, with **11 one-level dependent controls and 37 base clusters**. Exactly four cases use six-lag windows from independently sampled contiguous 97-symbol streams; the other 44 are explicitly algebraic context-table controls. The former's contexts have the required overlapping histories; this is not a claim that all 48 are causal ciphertext generators.

The supported plants remain globally in the audited canonical residual: equality coefficients establish E; the selected parity/other coefficients exclude B and the additional nonzero canonical terms or non-unit equality coefficient exclude C. Removed C plants are exactly b ± one equality, and removed B plants have parity descriptor restricted to constant/lag1. No finite sample mask is used to decide global eligibility.

The forced-C observations determine the constant and signed equality coefficient in the declared two-feature dictionary. Forced-B observations determine lag1=13 and the even equality coefficient in the declared dictionary. These yield full-family witnesses but empty residuals. The declared E puncture removes the zero F13 equality coefficient; the declared C puncture removes the two signed-unit values. These are algebraic controls, not inferred fresh results.

The alias pair uses the identity 13x²=13x modulo 26, with the same canonical descriptor and finite truth. The no-equality construction makes each shared pair's finite values agree while one plant is residual and the other is C; it is a fixed constructive mapping, not signal-dependent rejection. Twin cases share public inputs with their bases but change only hidden row90; the observed duplicate context at row89 proves the twin lies outside every deterministic six-input law. These dependent cases cannot be counted as independent recovery samples.

There is one committed 256-bit seed, one deterministic generator, no fit/signal rejection, no replacement, and no adaptive extension. Deterministic replay is only permitted after the future pre-truth seal and release. The review did not execute even a fixed-seed generator replay. These finite-field identities and inclusion/exclusion methods are classical mathematics; the contribution under review is their local canonical-residual implementation and validation design, not a demonstrated historical invention. Historical matbalez scope remains unresolved.

## API, complete-relation, and release contracts

The unchanged engine/reference strict input and cap behavior inherit the prior full audit. Here the worker receives only neutral IDs and solver instances, with canonical serialized observation indices. It checks source/input identities and Python mode before computation. The independent reference enumerates original-coordinate CRT solutions and filters R directly, rather than reusing the engine's cut compiler.

Comparisons cover **all support/beta alpha fibers**, canonical descriptors, complete joint predictions, minimal sparse lifts, provenance, witness validity, feasibility and marginals. They are not merely point witnesses or marginal-mask agreement. Analysis independently recomputes each reference relation and re-verifies both modes; VERIFIED is distinct from engine EXACT/EMPTY and driver TERMINAL. All 96 verified outputs are required for whole-cohort PASS. Engine/reference/output limits, memory/CPU deaths and failures cannot be treated as EMPTY or omitted to claim whole-cohort success.

The terminal snapshot checks the exact 96-job schedule and artifact-name inventory, including logs, receipts and any allowed bounded partial output. It requires zero outstanding reservation and complete accounting. Source/input post-run seals are checked. Analysis validates the external terminal SHA and full reconstructed snapshot before checking/reading truth, then verifies the seed commitment and exact generation replay. Source pins are checked again before writing the final analysis.

**Operational custody remains an essential external requirement.** Shared filesystem access is not cryptographic or OS-enforced blindness. The parent must actually retain approval, seed/custody, source/analysis, outer receipt and terminal-manifest hashes in the declared order, and withhold truth until the terminal seal succeeds. No code can authenticate that human/agent release chronology merely from self-declared files. Top-level stage stdout/stderr and receipts must also be retained and hashed; the protocol requires this operational step.

## Resource bounds and failure recovery

The copied launcher is unchanged from the independently audited parent-death-cascade implementation. Each supervisor and child receives its own CPU/address-space limit. Root/wrapper commands must use canonical absolute paths; normal Python is required for the driver, while each worker mode is explicitly bound in its receipt. Python versions are recorded for future reproducibility.

Before any worker launch the driver durably reserves 82 CPU seconds. It launches only when known actual + 82 ≤ 1500. A valid failed receipt is charged and retained, then the next scheduled job may run without retry. Missing/invalid receipts leave the reservation active and stop. The deterministic full-hard-use mock stops after 18 jobs at 1,476 CPU seconds rather than refill the cap. Incomplete root execution cannot obtain a terminal truth-release seal. A post-run pin change yields INCOMPLETE, not a stale terminal claim.

The new-stage allocation is **2,618 CPU seconds**: 62 generator/supervisor + 482 driver/supervisor exclusive allowance + 1,500 inner actual/reservation cap + 362 analysis/supervisor + 12 custodian sealer/supervisor + 200 control/review reserve. Retained project allocation is **15,880 < 28,800 CPU seconds**. Actual root inclusive CPU is counted once; nested receipts are diagnostics, not additive again. Sequential peak process-address-space bounds are ≤2 GiB; the project owner must include other concurrent work under the overall 8 GiB envelope.

These are conservative allocations, not fully measured historical/project CPU totals. Missing historical startup/orchestration/inspection overhead remains explicitly unmeasured. A high-fiber case may cap; the reference's 2,000,000-point bound, 32 MiB output bound, worker CPU/wall limits and analysis limits must not be raised or cases replaced after seeing results. Unknown/dead stages keep their outstanding reservation; no silent retry or resource replenishment is approved.

## Independent deterministic evidence

All checks below use reviewer-owned files; no producer changes or fresh data.

| Receipt | Scope/result |
| --- | --- |
| `r0-guard-results.json` | Confirmed r0 compact/pretty byte defect; missing/wrong resource guards rejected and matching guard accepted. |
| `r3-mock-normal.json` | PASS: 2 positive terminal checks, 20 terminal mutations rejected, 8 invalid scalar CPU values rejected, 5 driver failure/reserve/post-seal scenarios, 3 serialization/size checks. |
| `r3-mock-optimized.json` | PASS: same terminal/scalar/serialization checks under -O; driver refuses optimized execution before launching a child. |
| `r3-release-gate.json` | PASS: mocked custodian seal; wrong external terminal hash and wrong reconstructed inventory rejected before truth access; valid terminal reached an intercepted boundary before any truth bytes. |

The 20 terminal mutation tests include wrong root command/input/exit/timeout, invalid or inconsistent CPU, incomplete job/reserve status, wrong worker index/mode/return code, missing death guard, and an extra unsealed artifact. A changed log plus updated local progress produces a different external snapshot, as required. Failure mocks launch **zero actual subprocess children**. The release test's truth file does not exist and the attempted positive read is intercepted before hashing/reading it.

Four bounded test processes measured **1.096456286 CPU seconds** in their internal intervals; their hard allowances sum to 79 CPU seconds. Artifact bookkeeping is separately receipted in `CPU-ACCOUNTING.json`. This new protocol-review accounting is separate from the prior 179.018681561 reviewer CPU seconds, is not a cohort execution receipt, and does not add nested/copied receipts twice. Shell/source-inspection/startup/report overhead is explicitly not fully measured. See the ledger for exact scope and pins.

## Required handoff conditions

1. The project owner explicitly decides approval against these exact source, analysis and resource pins and fixed destination paths. This review itself grants no launch authority.
2. A separate custodian uses a new, explicitly authorized approval, consumes it once, retains commitments on any failure and does not expose truth to implementation workers.
3. Preserve all failed/incomplete jobs and top-level logs/receipts. Do not retry unknown work, replace cases, redraw, tune the solver, change source, expand support, or enlarge caps based on the draw.
4. Externally retain the complete terminal-results manifest and outer receipt before any truth release; nonterminal accounting must halt the dependent analysis.
5. Report all denominators, dependent controls, exact/empty/incomplete/failure statuses, resource actual/reserves and missing measurements. PASS only supports this fixed synthetic implementation check. It implies no speedup, historical novelty, mechanistic recovery, full dictionary admission, or K4 target authorization.

No denied or uncertain tool operation remains open in this review. Only the project owner's explicit approval decision is pending.
