# Residual validation — incomplete preservation bundle

**INCOMPLETE. Truth withheld. No cohort correctness PASS, terminal seal, retry, resumption or redraw.**

The frozen48-case/96-job run stopped after23 accepted job outputs; its24th attempted job exceeded the frozen CPU receipt ceiling.72 jobs were never started. Stored partial worker claims are not an independent whole-cohort result.

- [Custodian report](custodian-records/REPORT.md): execution, denominators, commitments and limits.
- [Independent preservation review](failure-review/REVIEW.md): PASS only for artifact integrity, arithmetic and scope.
- [Incomplete inventory](custodian-records/INCOMPLETE-INVENTORY.json): NOT a terminal-results seal.
- [Separate generic diagnostic](generic-resource-diagnostic/REPORT.md): two later separately authorized seedless controls showed soft-signal delay; the failed hard-ceiling excess remains unresolved. This later evidence qualifies the nominal-enforcement assumption of the preserved pre-draw review. It neither reran nor repaired the cohort.
- [Resource accounting](RESOURCE-ACCOUNTING.json): inclusive receipts counted once;82-second reserve retained separately; explicit measurement gaps.
- [Provenance](PROVENANCE.json) and [bundle manifest](BUNDLE-MANIFEST.json): exact copies with original locations/hashes. Original path strings are retained, not rewritten; use this bundle map when paths are unavailable elsewhere.

Seed and truth bytes are deliberately excluded; their pre-run commitments remain in custody metadata. Thus the bundle documents a failed/incomplete attempt and cannot reproduce a truth analysis. All original source revisions and failures remain preserved; pre-draw-review mock trees are labeled operational mocks, not cohort data. No remote write was performed.

The independent preservation check completed before this local bundle was assembled. Original reviewed reports are unchanged; later two-control findings appear in their separate report. Keep this cohort closed and truth sealed. Any infrastructure revision or future validation requires separate review and authorization. No K4 data/target run, solution, speedup, novelty, model-membership or target-admission claim follows. Matbalez historical scope remains unresolved.
