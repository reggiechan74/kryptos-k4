# Reference-only point-cap hardening freeze — version2

2026-10-31. Project authorization covered this bounded patch after an independent
full audit found missing strict max_points guards in raw brute_force and in the
verify_result trusted-expected path. NaN disables ordinary comparison caps.
Original fixed-integer audit results remain valid. Do not overwrite history.

## Exact change

Preserve `/ARCHIVE_WORKSPACE/canonical-residual-reference/` byte-for-byte and copy
its source, plan and receipts into `history-v1/`. Change reference VERSION from1
to2. All three public point-cap APIs (oracle, brute_force, verify_result) must
reject values whose built-in type is not int, or which are negative. This guard
must run before any early return, input processing or trusted-expected bypass.
Zero is a valid cap: an attempted positive point enumeration raises
ReferenceLimit; no-enumeration paths may return with no completeness overclaim.
No engine/compiler/model/predicate change, speed optimization or new scope.

## Fixed verification

Before execution, freeze patched source and regression-test hashes. Test every
API with bool, integral/nonintegral floats, NaN, both infinities, strings, None,
containers, arbitrary objects, Decimal, Fraction, int subclasses and negatives.
Include verifier with/without trusted expected and INCOMPLETE/EMPTY results.
Test zero-cap failure on positive enumeration and zero-cap success on legitimate
no-point paths. Use explicit exceptions so python -O retains checks.

Run regression tests in normal and optimized modes. Rerun the original disclosed
self-tests and14-case stored-output audit in normal/-O as HISTORICAL DEVELOPMENT
RERUNS, not fresh holdout validation. Retain prior receipts unchanged. Every run
uses120CPU seconds,768MiB address space and150-second external watchdog.

Send exact patch pin and receipts to independent-reviewer for an
independent patch review. Stop after bounded reruns and independent review,
or an actionable blocker. No new draw, target data/matrix/fit, holdout access,
remote edit or automatic admission. Matbalez historical scope remains unresolved.

private administrative register [reference omitted] was reread before this work. Repository reconciliation is managed separately. This patch does not weaken the fixed residual
R=E minus (B union C), common original support, minimum lift, complete fiber,
provenance, marginal/joint or incomplete-result requirements.
