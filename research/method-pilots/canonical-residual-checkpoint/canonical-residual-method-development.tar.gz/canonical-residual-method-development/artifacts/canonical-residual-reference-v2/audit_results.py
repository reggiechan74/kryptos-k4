"""Bounded independent audit of stored disclosed DEVELOPMENT-ONLY results."""
import argparse
import copy
import hashlib
import json
import resource
import sys
import time
from pathlib import Path
from reference import (oracle, brute_force, verify_result, ensure, VerificationError)

HERE = Path(__file__).resolve().parent
PRODUCER = Path('/ARCHIVE_WORKSPACE/canonical-residual-dev')
sys.path.append(str(PRODUCER))
from development_cases import cases, arguments

EXPECTED_SOURCE = 'be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67'
parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=('tiny', 'full', 'all'), default='all')
parser.add_argument('--optimized-results', action='store_true')
options = parser.parse_args()
resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
resource.setrlimit(resource.RLIMIT_AS, (768 * 1024**2, 768 * 1024**2))
start = time.process_time()
pins = {name: hashlib.sha256((PRODUCER/name).read_bytes()).hexdigest()
        for name in ('residual_decoder.py', 'affine_filter.py', 'development_cases.py', 'PLAN.md')}
ensure(pins['residual_decoder.py'] == EXPECTED_SOURCE, 'unexpected producer source before audit')
tiny, full = cases()
out = dict(status='PASS', producer_pins=pins, cases=[], mutations=[], caps=[])
suffix = '-optimized' if options.optimized_results else ''
if options.mode in ('tiny', 'all'):
    tiny_results = json.loads((PRODUCER/('tiny-results'+suffix+'.json')).read_text())
    expected_by_name = {}
    for case in tiny:
        kwargs = arguments(case)
        ref = oracle(**kwargs)
        raw = brute_force(**kwargs)
        for field in ('status', 'masks', 'joints', 'lifts'):
            ensure(ref[field] == raw[field], case['name'] + ': reference/raw mismatch')
        result = tiny_results[case['name']]
        receipt = verify_result(result=result, expected=ref,
                                expected_source_sha256=EXPECTED_SOURCE, **kwargs)
        receipt['name'] = case['name']
        receipt['raw_coefficient_points'] = raw['points']
        out['cases'].append(receipt)
        expected_by_name[case['name']] = ref

    def reject(name, case_name, modify):
        case = next(c for c in tiny if c['name'] == case_name)
        mutated = copy.deepcopy(tiny_results[case_name])
        modify(mutated)
        try:
            verify_result(result=mutated, expected=expected_by_name[case_name],
                          expected_source_sha256=EXPECTED_SOURCE, **arguments(case))
        except VerificationError as error:
            out['mutations'].append(dict(name=name, rejected=str(error)))
        else:
            raise RuntimeError('mutation accepted: '+name)

    one = 'one-equality'
    def first_record(r):
        return r['witnesses'][0][next(iter(r['witnesses'][0]))]
    reject('C witness', one, lambda r: first_record(r).__setitem__('theta', [[28, 1]]))
    reject('B witness', one, lambda r: first_record(r).__setitem__('theta', [[28, 2]]))
    reject('no equality witness', 'equality-E-puncture-with-lag2',
           lambda r: first_record(r).__setitem__('theta', [[2, 3]]))
    reject('wrong core alpha', one,
           lambda r: r['pieces'][0]['core']['witnesses'][0].__setitem__('0', [1]))
    reject('omitted beta fiber', 'constant-equality-C-punctures', lambda r: r['pieces'].pop())
    reject('omitted canonical cut', one, lambda r: r['pieces'][0]['forbidden'].clear())
    reject('wrong marginal mask', one, lambda r: r['masks'][0].pop())
    reject('missing provenance', one,
           lambda r: r['provenance'][0][next(iter(r['provenance'][0]))].clear())
    reject('duplicate piece', one, lambda r: r['pieces'].append(copy.deepcopy(r['pieces'][0])))
    reject('B beta replacement', one, lambda r: r['pieces'][0].__setitem__('beta', []))
    reject('wrong generic identity', one,
           lambda r: r['pieces'][0]['core'].__setitem__('instance_sha256', '0'*64))
    reject('wrong compiler', one, lambda r: r.__setitem__('compiler', 'other'))
    reject('wrong source', one, lambda r: r.__setitem__('source_sha256', '0'*64))
    reject('wrong instance', one, lambda r: r.__setitem__('instance_sha256', '0'*64))
    reject('wrong feasibility', one,
           lambda r: r['pieces'][0]['feasibility_witness'].__setitem__('theta', [[28, 1]]))
    def make_empty(r):
        r.update(status='EMPTY', masks=[[] for _ in r['masks']],
                 witnesses=[{} for _ in r['witnesses']],
                 provenance=[{} for _ in r['provenance']], pieces=[], feasibility_witness=None)
    reject('false EMPTY', one, make_empty)
    def incomplete_partial(r):
        r['status'] = 'INCOMPLETE'
    reject('INCOMPLETE leaks partial masks', one, incomplete_partial)

    # Public producer API is called only for synthetic cap behavior. Reference
    # computation and all validity/completeness checks remain independent.
    from residual_decoder import decode, Budget
    cap_case = next(c for c in tiny if c['name'] == one)
    for changes in ({'max_steps': 0}, {'max_steps': 20}, {'max_pieces': 0},
                    {'max_core_work': 0}, {'max_core_solves': 0}, {'max_seconds': 0.0}):
        cap_result = decode(**arguments(cap_case), budget=Budget(**changes))
        ensure(cap_result['status'] == 'INCOMPLETE', 'cap did not fail incomplete')
        checked = verify_result(result=cap_result, expected_source_sha256=EXPECTED_SOURCE,
                                **arguments(cap_case))
        out['caps'].append(dict(changes=changes, reason=cap_result['reason'], checked=checked))
    exact_no_ie = decode(**arguments(cap_case), budget=Budget(max_core_terms=0))
    ensure(exact_no_ie['status'] == 'EXACT', 'unneeded IE budget should not block small union')
    out['caps'].append(dict(changes={'max_core_terms':0}, checked=verify_result(
        result=exact_no_ie, expected=expected_by_name[one], expected_source_sha256=EXPECTED_SOURCE,
        **arguments(cap_case))))

if options.mode in ('full', 'all'):
    for case in full:
        path = PRODUCER/(case['name']+suffix+'.json')
        result = json.loads(path.read_text())
        # Runner may wrap result with metadata; accept only its explicitly named result.
        if 'status' not in result and 'result' in result:
            result = result['result']
        receipt = verify_result(result=result, expected_source_sha256=EXPECTED_SOURCE,
                                **arguments(case))
        receipt['name'] = case['name']
        out['cases'].append(receipt)

ensure(all(hashlib.sha256((PRODUCER/name).read_bytes()).hexdigest() == digest
           for name, digest in pins.items()), 'producer source changed during audit')
out['cpu_seconds'] = time.process_time()-start
out['max_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps(out, indent=2))
