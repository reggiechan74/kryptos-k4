"""Independent finite reference for the fixed DEVELOPMENT-ONLY residual.

No imports from the decoder, canonical compiler, or affine-filter implementation.
This is deliberately bounded enumeration, not a performance implementation.
"""
from itertools import combinations, product
import hashlib
import json

VERSION = 'independent-residual-reference-2'


class VerificationError(ValueError):
    pass


class ReferenceLimit(RuntimeError):
    pass


def ensure(condition, message):
    if not condition:
        raise VerificationError(message)


def _point_cap(max_points):
    """Validate every public cap before branches or trusted memo shortcuts."""
    ensure(type(max_points) is int and max_points >= 0,
           'max_points must be a built-in nonnegative integer')


def group(j):
    return j if j < 7 else j - 6


def feature_row(context):
    ensure(type(context) in (list, tuple) and len(context) == 6,
           'context must contain six symbols')
    ensure(all(type(x) is int and 0 <= x < 26 for x in context),
           'context symbols must be canonical Z26 integers')
    row = [1]
    row.extend(context)
    row.extend(x * x % 26 for x in context)
    row.extend(context[a] * context[b] % 26
               for a in range(6) for b in range(a + 1, 6))
    row.extend(1 if context[a] == context[a + 1] else 0 for a in (0, 2, 4))
    return tuple(row)


def descriptor(coefficients):
    ensure(len(coefficients) == 31, '31 coefficients required')
    ensure(all(type(x) is int and 0 <= x < 26 for x in coefficients),
           'noncanonical coefficient')
    alpha = tuple(x % 13 for x in coefficients)
    beta = [0] * 25
    for j, x in enumerate(coefficients):
        beta[group(j)] ^= x & 1
    return alpha, tuple(beta)


def minimum_support(alpha, beta):
    # Derive cost directly group by group, independently of any producer lift.
    total = 0
    for g in range(25):
        active = sum(1 for j in range(31) if group(j) == g and alpha[j] != 0)
        total += active if active else beta[g]
    return total


def residual(alpha, beta):
    """Direct fixed global-descriptor predicate, no affine-cut compilation."""
    ensure(len(alpha) == 31 and len(beta) == 25, 'descriptor dimensions')
    ensure(all(type(x) is int and 0 <= x < 13 for x in alpha), 'alpha domain')
    ensure(all(type(x) is int and x in (0, 1) for x in beta), 'beta domain')
    if not any(alpha[j] != 0 or beta[group(j)] != 0 for j in (28, 29, 30)):
        return False
    if not any(beta[g] for g in range(2, 25)):
        return False
    for j in (28, 29, 30):
        if (alpha[j] in (1, 12)
                and beta[group(j)] == 1
                and all(alpha[k] == 0 for k in range(31) if k not in (0, j))
                and all(beta[g] == 0 for g in range(25) if g not in (0, group(j)))):
            return False
    return True


def inner(a, b, p):
    ensure(len(a) == len(b), 'inner-product dimensions')
    return sum(x * y for x, y in zip(a, b)) % p


def affine_solutions(matrix, rhs, n, p):
    """Independent Gauss-Jordan followed by COMPLETE free-variable enumeration."""
    ensure(len(matrix) == len(rhs), 'equation count')
    work = [[x % p for x in row] + [y % p] for row, y in zip(matrix, rhs)]
    ensure(all(len(row) == n + 1 for row in work), 'matrix width')
    pivot_columns = []
    cursor = 0
    for col in range(n):
        pivot = None
        for i in range(cursor, len(work)):
            if work[i][col] != 0:
                pivot = i
                break
        if pivot is None:
            continue
        work[cursor], work[pivot] = work[pivot], work[cursor]
        inverse = next(x for x in range(1, p) if x * work[cursor][col] % p == 1)
        work[cursor] = [(x * inverse) % p for x in work[cursor]]
        for i in range(len(work)):
            if i == cursor:
                continue
            multiple = work[i][col]
            for k in range(n + 1):
                work[i][k] = (work[i][k] - multiple * work[cursor][k]) % p
        pivot_columns.append(col)
        cursor += 1
    if any(all(v == 0 for v in row[:n]) and row[-1] != 0 for row in work):
        return []
    free = [j for j in range(n) if j not in pivot_columns]
    solutions = []
    for values in product(range(p), repeat=len(free)):
        v = [0] * n
        for col, x in zip(free, values):
            v[col] = x
        for i, col in enumerate(pivot_columns):
            v[col] = (work[i][-1] - sum(work[i][j] * v[j] for j in free)) % p
        ensure(all(inner(row, v, p) == y % p for row, y in zip(matrix, rhs)),
               'reference elimination error')
        solutions.append(tuple(v))
    return solutions


def normalized_input(contexts, observed, sparsity, allowed_features):
    ensure(type(contexts) in (list, tuple) and len(contexts) <= 256, 'contexts')
    rows = [feature_row(x) for x in contexts]
    ensure(type(observed) is dict, 'observations dictionary required')
    observations = {}
    for k, v in observed.items():
        if type(k) is str:
            ensure(k.isdigit() and str(int(k)) == k, 'noncanonical observation key')
            k = int(k)
        ensure(type(k) is int and 0 <= k < len(rows), 'observation index')
        ensure(k not in observations, 'duplicate observation index')
        ensure(type(v) is int and 0 <= v < 26, 'observation value')
        observations[k] = v
    ensure(type(sparsity) is int and 0 <= sparsity <= 3, 'sparsity')
    if allowed_features is None:
        allowed_features = list(range(31))
    ensure(type(allowed_features) in (list, tuple), 'allowed features')
    ensure(all(type(j) is int and 0 <= j < 31 for j in allowed_features),
           'allowed feature index')
    ensure(list(allowed_features) == sorted(set(allowed_features)),
           'allowed features must be sorted and unique')
    return rows, observations, tuple(allowed_features)


def _predictions(coefficients, rows):
    return tuple(inner(coefficients, row, 26) for row in rows)


def oracle(contexts, observed, sparsity=3, allowed_features=None,
           max_points=2_000_000):
    """Complete reference using original-coordinate CRT solution enumeration.

    `pieces[(support,beta_active)]` is a set of complete alpha vectors on support.
    `lifts[descriptor]` contains every encountered original sparse vector.
    Each exact support <=s embeds in at least one maximal support container.
    """
    _point_cap(max_points)
    rows, observations, allowed = normalized_input(contexts, observed, sparsity, allowed_features)
    pieces, lifts, joints = {}, {}, set()
    masks = [set() for _ in rows]
    pair_points = 0
    supports_seen = 0
    for support in combinations(allowed, min(sparsity, len(allowed))):
        supports_seen += 1
        matrix = [[rows[i][j] for j in support] for i in sorted(observations)]
        rhs = [observations[i] for i in sorted(observations)]
        a13 = affine_solutions(matrix, rhs, len(support), 13)
        a2 = affine_solutions(matrix, rhs, len(support), 2)
        if len(a13) * len(a2) > max_points - pair_points:
            raise ReferenceLimit('complete original-coordinate field-pair enumeration cap')
        pair_points += len(a13) * len(a2)
        for u, v in product(a13, a2):
            coefficients = [0] * 31
            # Independent CRT by scanning the two possible F13 lifts.
            for j, a, b in zip(support, u, v):
                coefficients[j] = a if a % 2 == b else a + 13
            alpha, beta = descriptor(coefficients)
            if not residual(alpha, beta):
                continue
            ensure(minimum_support(alpha, beta) <= sparsity, 'unexpected support cost')
            key = (support, tuple(g for g, bit in enumerate(beta) if bit))
            pieces.setdefault(key, set()).add(u)
            d = (alpha, beta)
            lifts.setdefault(d, set()).add(tuple(coefficients))
            prediction = _predictions(coefficients, rows)
            joints.add(prediction)
            for i, value in enumerate(prediction):
                masks[i].add(value)
    provenance = [{z: set() for z in mask} for mask in masks]
    piece_masks = {}
    for key, points in pieces.items():
        support, beta_active = key
        local = [set() for _ in rows]
        for point in points:
            for i, row in enumerate(rows):
                a = inner([row[j] for j in support], point, 13)
                b = sum(row[g if g < 7 else g + 6] for g in beta_active) % 2
                z = a if a % 2 == b else a + 13
                local[i].add(z)
                provenance[i][z].add(key)
        piece_masks[key] = local
    return dict(status='EXACT' if pieces else 'EMPTY', masks=masks, pieces=pieces,
                piece_masks=piece_masks, provenance=provenance, joints=joints,
                lifts=lifts, pair_points=pair_points, supports_seen=supports_seen)


def brute_force(contexts, observed, sparsity=3, allowed_features=None,
                max_points=2_000_000):
    """Second oracle: raw nonzero Z26 coefficients, no field solving."""
    _point_cap(max_points)
    rows, observations, allowed = normalized_input(contexts, observed, sparsity, allowed_features)
    masks = [set() for _ in rows]
    joints, lifts = set(), {}
    points = 0
    for size in range(min(sparsity, len(allowed)) + 1):
        for support in combinations(allowed, size):
            if 25 ** size > max_points - points:
                raise ReferenceLimit('raw coefficient enumeration cap')
            points += 25 ** size
            for values in product(range(1, 26), repeat=size):
                coefficients = [0] * 31
                for j, x in zip(support, values):
                    coefficients[j] = x
                if any(inner(coefficients, rows[i], 26) != z for i, z in observations.items()):
                    continue
                alpha, beta = descriptor(coefficients)
                if not residual(alpha, beta):
                    continue
                d = (alpha, beta)
                lifts.setdefault(d, set()).add(tuple(coefficients))
                prediction = _predictions(coefficients, rows)
                joints.add(prediction)
                for i, z in enumerate(prediction):
                    masks[i].add(z)
    return dict(status='EXACT' if lifts else 'EMPTY', masks=masks, joints=joints,
                lifts=lifts, points=points)


def check_sparse_witness(witness, contexts, observed, sparsity=3,
                         allowed_features=None, row_index=None, value=None,
                         support=None, beta_active=None):
    """Check list [[feature,coefficient],...] without any producer helpers."""
    rows, observations, allowed = normalized_input(contexts, observed, sparsity, allowed_features)
    ensure(type(witness) in (list, tuple), 'witness list required')
    coefficients = [0] * 31
    indices = []
    for item in witness:
        ensure(type(item) in (list, tuple) and len(item) == 2, 'witness entry')
        j, x = item
        ensure(type(j) is int and j in allowed, 'witness feature outside domain')
        ensure(type(x) is int and 1 <= x < 26, 'witness coefficient not canonical/nonzero')
        ensure(j not in indices, 'duplicate witness feature')
        indices.append(j)
        coefficients[j] = x
    ensure(indices == sorted(indices), 'witness ordering')
    ensure(len(indices) <= sparsity, 'witness too large')
    if support is not None:
        ensure(set(indices) <= set(support), 'witness outside declared original support')
    alpha, beta = descriptor(coefficients)
    ensure(residual(alpha, beta), 'witness outside residual R')
    ensure(len(indices) == minimum_support(alpha, beta), 'witness is not minimum-support lift')
    if beta_active is not None:
        ensure(tuple(g for g, b in enumerate(beta) if b) == tuple(beta_active), 'wrong beta witness')
    ensure(all(inner(coefficients, rows[i], 26) == z for i, z in observations.items()),
           'witness violates observation')
    if row_index is not None:
        ensure(type(row_index) is int and 0 <= row_index < len(rows), 'witness row')
        ensure(type(value) is int and 0 <= value < 26, 'witness value')
        ensure(inner(coefficients, rows[row_index], 26) == value, 'witness predicts wrong marginal')
    return alpha, beta


def _keys(mapping):
    ensure(type(mapping) is dict, 'value-keyed dictionary required')
    converted = {}
    for k, v in mapping.items():
        if type(k) is str:
            ensure(k.isdigit() and str(int(k)) == k, 'noncanonical value key')
            k = int(k)
        ensure(type(k) is int and 0 <= k < 26, 'value key domain')
        ensure(k not in converted, 'duplicate integer/string value key')
        converted[k] = v
    return converted


def _mask(mask, modulus):
    ensure(type(mask) is list, 'mask list required')
    ensure(all(type(x) is int and 0 <= x < modulus for x in mask), 'mask residue')
    ensure(mask == sorted(set(mask)), 'mask must be sorted and unique')
    return set(mask)


def _equations(rows, n):
    ensure(type(rows) in (list, tuple), 'equation system required')
    ensure(len(rows) <= 256, 'too many equations')
    for row in rows:
        ensure(type(row) in (list, tuple) and len(row) == n + 1, 'equation dimensions')
        ensure(all(type(x) is int and 0 <= x < 13 for x in row), 'equation residue')
    return rows


def verify_result(contexts, observed, result, sparsity=3, allowed_features=None,
                  expected=None, max_points=2_000_000, expected_source_sha256=None):
    """Semantically verify an UNTRUSTED result by independent complete oracle.

    This verifier does NOT rely on generic elimination/cut certificates. It
    independently enumerates every feasible piece's entire ambient F13^|T| grid,
    compares its base-minus-cuts fiber with the original-coordinate reference,
    and checks every advertised marginal and witness. It does not authenticate
    the process/source that produced a result. Unknown extra fields are ignored.
    """
    _point_cap(max_points)
    rows, observations, allowed = normalized_input(contexts, observed, sparsity, allowed_features)
    ensure(type(result) is dict, 'result dictionary required')
    ensure(result.get('version') == 'canonical-residual-dev-1', 'unsupported decoder version')
    ensure(result.get('compiler') == 'E-minus-B-union-exact156-C-1', 'unsupported compiler')
    dependency = '1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d'
    ensure(result.get('dependency_sha256') == dependency, 'generic dependency identity')
    source = result.get('source_sha256')
    ensure(type(source) is str and len(source) == 64
           and all(x in '0123456789abcdef' for x in source), 'source identity format')
    if expected_source_sha256 is not None:
        ensure(source == expected_source_sha256, 'unexpected source pin')
    identity = hashlib.sha256(json.dumps([
        'canonical-residual-dev-1', 'E-minus-B-union-exact156-C-1', source, dependency,
        contexts, sorted(observations.items()), sparsity, allowed
    ], separators=(',', ':')).encode()).hexdigest()
    ensure(result.get('instance_sha256') == identity, 'wrong input/predicate/source identity')
    status = result.get('status')
    ensure(status in ('EXACT', 'EMPTY', 'INCOMPLETE'), 'status')
    public = ('masks', 'witnesses', 'provenance', 'pieces', 'feasibility_witness')
    if status == 'INCOMPLETE':
        ensure(all(k in result and result[k] is None for k in public),
               'INCOMPLETE must suppress all partial result fields')
        return dict(status='INCOMPLETE', verified_no_partial_claim=True)
    if expected is None:
        expected = oracle(contexts, observed, sparsity, allowed_features, max_points)
    ensure(status == expected['status'], 'false exact/empty status')
    for field in ('masks', 'witnesses', 'provenance'):
        ensure(type(result.get(field)) is list and len(result[field]) == len(rows),
               field + ' row count')
    ensure(type(result.get('pieces')) is list, 'pieces required')
    ensure([_mask(x, 26) for x in result['masks']] == expected['masks'], 'marginal masks differ')
    actual = {}
    piece_ids = {}
    ambient_points = 0
    alpha_witnesses_checked = 0
    for piece in result['pieces']:
        ensure(type(piece) is dict, 'piece dictionary')
        identifier = piece.get('id')
        ensure(type(identifier) is str and len(identifier) <= 100 and identifier,
               'piece id')
        ensure(identifier not in piece_ids, 'duplicate piece id')
        support = piece.get('support')
        beta = piece.get('beta')
        ensure(type(support) is list and all(type(j) is int for j in support), 'support list')
        ensure(support == sorted(set(support)), 'support ordering')
        ensure(set(support) <= set(allowed), 'support outside allowed features')
        ensure(len(support) == min(sparsity, len(allowed)), 'nonmaximal support container')
        ensure(type(beta) is list and all(type(g) is int and 0 <= g < 25 for g in beta),
               'beta active list')
        ensure(beta == sorted(set(beta)), 'beta ordering')
        ensure(set(beta) <= {group(j) for j in support}, 'beta outside original support groups')
        key = (tuple(support), tuple(beta))
        ensure(key in expected['pieces'], 'unexpected/ineligible/empty support-beta piece')
        ensure(key not in actual, 'duplicate support-beta piece')
        n = len(support)
        base = _equations(piece.get('base'), n)
        forbidden = piece.get('forbidden')
        ensure(type(forbidden) in (list, tuple) and len(forbidden) <= 256, 'forbidden systems')
        forbidden = [_equations(w, n) for w in forbidden]
        ensure(sum(len(w) for w in forbidden) + len(base) <= 256, 'total equation limit')
        ambient_points += 13 ** n
        if ambient_points > max_points:
            raise ReferenceLimit('published-fiber ambient enumeration cap')
        def member(point):
            sat = lambda system: all(inner(row[:-1], point, 13) == row[-1] for row in system)
            return sat(base) and all(not sat(w) for w in forbidden)
        actual_points = {point for point in product(range(13), repeat=n) if member(point)}
        ensure(actual_points == expected['pieces'][key], 'compiled fiber differs from canonical residual')
        core = piece.get('core')
        ensure(type(core) is dict and core.get('status') == 'EXACT', 'feasible piece core status')
        ensure(core.get('version') == 'affine-filter-1', 'unsupported core version')
        scalar_rows = [[row[j] % 13 for j in support] for row in rows]
        core_identity = hashlib.sha256(json.dumps([
            'affine-filter-1', 13, n, base, forbidden, scalar_rows
        ], separators=(',', ':')).encode()).hexdigest()
        ensure(core.get('instance_sha256') == core_identity, 'wrong core instance identity')
        ensure(type(core.get('masks')) is list and len(core['masks']) == len(rows), 'core masks')
        expected13 = [{inner([row[j] for j in support], point, 13)
                       for point in actual_points} for row in rows]
        ensure([_mask(mask, 13) for mask in core['masks']] == expected13, 'core masks incomplete')
        ensure(type(core.get('witnesses')) is list and len(core['witnesses']) == len(rows),
               'core witnesses')
        def check_point(point):
            ensure(type(point) in (list, tuple) and len(point) == n, 'alpha witness dimensions')
            ensure(all(type(x) is int and 0 <= x < 13 for x in point), 'alpha witness domain')
            ensure(tuple(point) in actual_points, 'alpha witness outside complete residual fiber')
        for i, ws in enumerate(core['witnesses']):
            ws = _keys(ws)
            ensure(set(ws) == expected13[i], 'core witness coverage')
            for z, point in ws.items():
                check_point(point)
                ensure(inner([rows[i][j] for j in support], point, 13) == z,
                       'wrong core marginal witness')
                alpha_witnesses_checked += 1
        check_point(core.get('feasibility_witness'))
        alpha_witnesses_checked += 1
        piece_ids[identifier] = key
        actual[key] = identifier
    ensure(set(actual) == set(expected['pieces']), 'missing canonical support-beta fibers')
    sparse_witnesses_checked = 0
    def check_record(record, row_index=None, value=None):
        nonlocal sparse_witnesses_checked
        ensure(type(record) is dict, 'witness record')
        identifier = record.get('piece')
        ensure(type(identifier) is str and identifier in piece_ids, 'witness unknown piece')
        support, beta = piece_ids[identifier]
        alpha, _ = check_sparse_witness(record.get('theta'), contexts, observations,
                                       sparsity, allowed, row_index, value, support, beta)
        ensure(tuple(alpha[j] for j in support) in expected['pieces'][(support, beta)],
               'sparse witness not in its piece')
        sparse_witnesses_checked += 1
    for i, ws in enumerate(result['witnesses']):
        ws = _keys(ws)
        ensure(set(ws) == expected['masks'][i], 'marginal witness coverage')
        for z, record in ws.items():
            check_record(record, i, z)
        ps = _keys(result['provenance'][i])
        ensure(set(ps) == expected['masks'][i], 'provenance value coverage')
        for z, ids in ps.items():
            ensure(type(ids) is list and all(type(x) is str for x in ids), 'provenance ids')
            ensure(len(ids) == len(set(ids)), 'duplicate provenance')
            ensure(all(x in piece_ids for x in ids), 'unknown provenance piece')
            ensure({piece_ids[x] for x in ids} == expected['provenance'][i][z],
                   'incomplete or incorrect cross-piece provenance')
    if status == 'EMPTY':
        ensure(result.get('feasibility_witness') is None, 'EMPTY feasibility witness')
    else:
        check_record(result.get('feasibility_witness'))
    for piece in result['pieces']:
        ensure(type(piece.get('feasibility_witness')) is dict,
               'piece sparse feasibility witness required')
        ensure(piece['feasibility_witness'].get('piece') == piece['id'],
               'piece feasibility witness has wrong provenance')
        check_record(piece['feasibility_witness'])
    return dict(status=status, pieces_checked=len(actual),
                ambient_points_checked=ambient_points,
                alpha_witnesses_checked=alpha_witnesses_checked,
                sparse_witnesses_checked=sparse_witnesses_checked,
                oracle_pair_points=expected['pair_points'],
                complete_joint_predictions=len(expected['joints']),
                complete_canonical_functions=len(expected['lifts']))
