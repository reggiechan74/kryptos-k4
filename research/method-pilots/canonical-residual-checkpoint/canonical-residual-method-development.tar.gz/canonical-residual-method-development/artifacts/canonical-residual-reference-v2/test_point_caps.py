"""v2 cap regressions on historical disclosed fixtures; NOT a fresh holdout."""
import copy
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import resource
import sys
import time

from reference import (VERSION, VerificationError, ReferenceLimit, ensure,
                       oracle, brute_force, verify_result)

ROOT = Path('/ARCHIVE_WORKSPACE/canonical-residual-dev')
sys.path.append(str(ROOT))
from development_cases import cases, arguments

resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
resource.setrlimit(resource.RLIMIT_AS, (768*1024**2, 768*1024**2))
start = time.process_time()
stored = json.loads((ROOT/'tiny-results.json').read_text())
tiny, _ = cases()
one = next(c for c in tiny if c['name'] == 'one-equality')
empty = next(c for c in tiny if c['name'] == 'zero-budget-domain')
args = arguments(one)
empty_args = arguments(empty)
truth = oracle(**args)
empty_truth = oracle(**empty_args)
incomplete = copy.deepcopy(stored[one['name']])
incomplete.update(status='INCOMPLETE', masks=None, witnesses=None, provenance=None,
                  pieces=None, feasibility_witness=None)

calls = {
    'oracle': lambda cap: oracle(**args, max_points=cap),
    'brute_force': lambda cap: brute_force(**args, max_points=cap),
    'verify_result/recompute': lambda cap: verify_result(
        **args, result=stored[one['name']], max_points=cap),
    'verify_result/trusted-memo': lambda cap: verify_result(
        **args, result=stored[one['name']], expected=truth, max_points=cap),
    'verify_result/EMPTY-trusted-memo': lambda cap: verify_result(
        **empty_args, result=stored[empty['name']], expected=empty_truth, max_points=cap),
    'verify_result/INCOMPLETE': lambda cap: verify_result(
        **args, result=incomplete, max_points=cap),
}

class IntSubclass(int):
    pass

bad = [('true', True), ('false', False), ('negative', -1),
       ('zero-float', 0.0), ('integral-float', 1.0), ('fractional-float', 0.5),
       ('negative-float', -1.0), ('NaN', float('nan')),
       ('positive-infinity', float('inf')), ('negative-infinity', -float('inf')),
       ('string', '1'), ('None', None), ('list', []), ('tuple', ()), ('dict', {}),
       ('object', object()), ('Decimal', Decimal(1)), ('Decimal-NaN', Decimal('NaN')),
       ('Fraction', Fraction(1, 1)), ('int-subclass', IntSubclass(1))]
rejected = []
for name, call in calls.items():
    for label, value in bad:
        try:
            call(value)
        except VerificationError as error:
            ensure(str(error) == 'max_points must be a built-in nonnegative integer',
                   'wrong validation failure for '+name+'/'+label)
            rejected.append(name+'/'+label)
        else:
            raise RuntimeError('malformed cap accepted: '+name+'/'+label)

zero_limited = []
for name in ('oracle', 'brute_force', 'verify_result/recompute', 'verify_result/trusted-memo'):
    try:
        calls[name](0)
    except ReferenceLimit:
        zero_limited.append(name)
    else:
        raise RuntimeError('zero cap did not limit positive enumeration: '+name)

zero_success = []
for name in ('verify_result/EMPTY-trusted-memo', 'verify_result/INCOMPLETE'):
    result = calls[name](0)
    ensure(result['status'] in ('EMPTY', 'INCOMPLETE'), 'wrong zero-work status')
    zero_success.append(name)
# Inconsistent equations admit no field pairs; zero cap is sufficient for oracle.
contradiction = oracle([[0]*6, [0]*6], {0: 0, 1: 1}, 1, [28], max_points=0)
ensure(contradiction['status'] == 'EMPTY' and contradiction['pair_points'] == 0,
       'zero-pair oracle path')
zero_success.append('oracle/inconsistent-no-field-pairs')

# Valid built-in integer boundaries remain accepted; no new upper bound added.
ensure(oracle(**args, max_points=26)['masks'] == truth['masks'], 'exact oracle cap')
ensure(brute_force(**args, max_points=26)['masks'] == truth['masks'], 'exact raw cap')
ensure(calls['verify_result/trusted-memo'](13)['status'] == 'EXACT', 'exact verifier cap')
for name, call in calls.items():
    call(10**1000)

print(json.dumps(dict(status='PASS', classification='historical-disclosed-regression',
    reference_version=VERSION,
    reference_sha256=hashlib.sha256(Path(__file__).with_name('reference.py').read_bytes()).hexdigest(),
    malformed_rejections=len(rejected), rejected=rejected,
    zero_cap_exhaustions=zero_limited, zero_cap_successes=zero_success,
    exact_integer_boundary_successes=3, large_integer_successes=len(calls),
    cpu_seconds=time.process_time()-start,
    max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss), indent=2))
