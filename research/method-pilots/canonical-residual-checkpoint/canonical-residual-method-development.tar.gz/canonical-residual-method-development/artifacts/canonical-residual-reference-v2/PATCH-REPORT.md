# Reference-only point-cap hardening — version2

2026-10-31. **Implementation, bounded regressions and independent review PASS.**
Independent patch-review evidence is recorded below. This corrects
reference API validation only; it does not change the residual decoder engine,
feature dictionary, fixed R predicate, observations, solver or admissible laws.

## Preserved defect and scope

The subsequent full implementation audit found that v1 `brute_force` lacked a
strict `max_points` guard, as did `verify_result` when given a trusted precomputed
`expected` memo. Passing NaN could make limit comparisons false and disable the
point cap. V1 `oracle` already required a built-in nonnegative integer, but its
check occurred after input normalization. All recorded scientific/development
reference comparisons used the valid fixed integer 2,000,000; those results are
not invalidated by this malformed-input defect.

V1 artifacts are preserved unchanged at their original path and byte-identically
under `history-v1/`, including original source, plan, audit reports and receipts.
The v2 diff is retained as `reference-v1-to-v2.patch`. No original receipt was
rewritten, and no new test is presented as an unseen holdout.

## Exact correction and pin

`reference.py` VERSION is now `independent-residual-reference-2`.
SHA256:
`618dbdabcd5bc3b74508372a1144a463994d705c766d4335e253b6e0dad91974`

One shared guard requires `type(max_points) is int and max_points >= 0` at the
start of each public point-cap API: `oracle`, `brute_force`, and `verify_result`.
It precedes input normalization, trusted-memo shortcuts and the verifier's
INCOMPLETE early return. Invalid caps raise explicit `VerificationError` under
normal Python and `-O`. Zero remains valid: positive enumeration raises
`ReferenceLimit`, while legitimate no-point paths can return without claiming
an unperformed enumeration. No arbitrary upper cap was introduced.

## Frozen checks and results

`PLAN-V2.md` and `FREEZE-V2-SHA256SUMS` preceded execution. Each normal and
optimized cap-regression run passed:

- 120 malformed-cap rejections: 20 values across 6 public API/branch paths,
  including bool, floats, NaN, infinities, nonnumbers, int subclasses, Decimal,
  Fraction, negatives, trusted EMPTY memo, and INCOMPLETE.
- 4 zero-cap exhaustions for paths requiring positive enumeration.
- 3 zero-cap successes for paths enumerating no points.
- 3 exact integer boundary successes and 6 arbitrary-large built-in integer
  successes.

Historical disclosed self-tests and the 14-case stored-output audit were rerun
under both Python modes. Every non-resource case/mutation/cap result exactly
matches the corresponding preserved v1 receipt: 288 complete support/beta
pieces, 602,004 ambient points, 29,883 core alpha witnesses, 1,284 sparse witnesses,
17 result-mutation rejections and 7 original cap cases per mode. These are
**historical development reruns**, not fresh validation or recovery evidence.

Normal historical audit: 5.851 CPU seconds. Optimized: 5.781 CPU seconds.
All runs used 120 CPU seconds, 768 MiB address space and a 150-second external watchdog.
Resources are receipts, not comparative performance evidence.

## Independent review and remaining limits

The independent [full review](../canonical-residual-full-review/REVIEW.md) passes
the exact source pin above. Its own targeted normal/-O checks each reject 96
malformed caps, verify 4 positive-work zero caps, 2 zero-work successes, 3 exact
boundaries and one-below-cap rejection, and verify JSON-loaded results. An AST
comparison confirms 17 existing function bodies are unchanged after removing
the guard insertion. The reviewer separately reran this patch's 120-rejection
suite and the 14-case historical audit in both modes; all passed. Engine and
original-reference hashes stayed unchanged.

Independent receipts live in `../canonical-residual-full-review/`:
`v2-targeted-normal.json`, `v2-targeted-optimized.json`,
`v2-regressions-*.json`, `v2-stored-*.json`, and `v2-process-receipts.json`.
No fresh protocol should freeze a different reference pin without its own review.
No unresolved implementation blocker remains within the bounded development
contract; the scientific/admission limits below remain unchanged.

The point cap still counts designated enumeration points, not every Python
operation, elimination cost or file parsing step; external limits remain
necessary. The verifier's optional expected memo remains trusted caller data,
not an independently accepted untrusted proof. No engine change, optimization,
target input/matrix/fit, holdout draw, remote edit or automatic admission occurred.
Historical matbalez scope remains unresolved. Parent owns ledger reconciliation.

## Files and reproduction

- `point-cap-regression-normal.json`, `point-cap-regression-optimized.json`
- `historical-selftest-normal.json`, `historical-selftest-optimized.json`
- `historical-audit-normal.json`, `historical-audit-optimized.json`
- `history-v1/`: preserved original lineage

```sh
timeout 150s python test_point_caps.py
timeout 150s python -O test_point_caps.py
timeout 150s python selftest.py
timeout 150s python -O selftest.py
timeout 150s python audit_results.py --mode all
timeout 150s python -O audit_results.py --mode all --optimized-results
```
