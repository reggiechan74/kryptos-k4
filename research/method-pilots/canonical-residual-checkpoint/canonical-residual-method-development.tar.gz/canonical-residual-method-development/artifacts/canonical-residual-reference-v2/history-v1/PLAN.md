# Independent canonical residual development reference — frozen plan

2026-10-31. This is DEVELOPMENT-ONLY, not a cipher experiment, admission, holdout,
or performance claim. No actual target, old holdout, new holdout, or remote write.
Historical matbalez operator scope remains unresolved. the private administrative register [reference omitted],
repository AGENTS and current ledgers, quotient proof and operator-scope reports
were read before implementation. Source artifacts will not be modified.

## Fixed predicate and scope

Use the original 31 features in the established order, full Z26 equality BEFORE
field reduction, and canonical quotient F13^31 x F2^25. R is exactly E minus
(B union C): E requires a nonzero equality descriptor in either field, B means
beta supported only on constant and lag1, C is exactly the 156 functions
b plus or minus one equality indicator. Canonical minimum support <=s<=3.

The independent oracle uses its own feature evaluator and elimination, original
coefficient support containers, complete F13/F2 affine solution enumeration and
CRT pairing, then checks the predicate directly. It imports no producer/core
algebra, compiler or membership functions. A second raw Z26 coefficient oracle
checks all exact supports of size <=s for tiny disclosed feature subsets.

The untrusted-result checker must verify complete support/beta piece inventory,
complete alpha fibers by enumerating every point in each published fiber and
comparing with the independent oracle, exact marginal masks and cross-piece
provenance, and valid original sparse witnesses. Joint predictions are checked
separately; marginal values cannot be combined to imply a joint model.

## Planned development cases and stopping rule

1. Literal tiny contexts, coefficients and allowed-feature subsets, with zero or
   a few observations. Include x/square aliases, zero coefficients in nonlinear
   support containers, E/B/C boundaries, constants/signs, punctured F13 fibers,
   equal predictions for old/new laws, and full equality vs residue equality.
2. Fresh disclosed producer 31-feature development fixtures, not held-out data.
3. Negative result mutations: wrong residual witness, omitted piece, changed
   mask or provenance, invalid lifted coefficient, fake exact/empty status.
4. Cap status and optimized-Python checks.

Each reference run is bounded by at most 2,000,000 enumerated field-pair points;
exhaustion is a validation limit, never a negative scientific result. Runs use
an outer 120 CPU-second/768 MiB limit and 150 second subprocess watchdog.
Do not expand the frozen family/predicate, introduce saturation optimization,
or choose postfit exclusions. Stop when checks pass or an actionable defect or
resource blocker is established. Report exact artifacts and limitations.
