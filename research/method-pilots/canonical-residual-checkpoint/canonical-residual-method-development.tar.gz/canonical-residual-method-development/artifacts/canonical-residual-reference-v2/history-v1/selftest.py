"""Disclosed tiny self-checks for the independent reference, no target inputs."""
import json
import resource
import time
from itertools import product
from reference import (oracle, brute_force, descriptor, residual, minimum_support,
                       feature_row, ensure, check_sparse_witness, VerificationError,
                       ReferenceLimit)

resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
resource.setrlimit(resource.RLIMIT_AS, (768 * 1024**2, 768 * 1024**2))
start = time.process_time()
contexts = [
    [0, 0, 0, 0, 0, 0],
    [0, 13, 0, 13, 0, 13],
    [1, 1, 2, 2, 3, 3],
    [1, 2, 3, 4, 5, 6],
    [13, 0, 2, 2, 25, 25],
    [2, 3, 4, 5, 6, 7],
]
fixtures = [
    ('zero-budget', [], 0, {}),
    ('no-equality-aliases', [0, 1, 7], 3, {}),
    ('one-equality-punctures', [28], 1, {}),
    ('constant-carry-boundaries', [0, 28], 2, {}),
    ('lag-square-equality', [1, 7, 28], 3, {}),
    ('beta-eligibility', [2, 28], 2, {}),
    ('multiple-equality-fibers', [28, 29], 2, {}),
    ('zero-in-nonlinear-container', [0, 1, 7, 28], 2, {0: 0, 1: 0}),
    ('observation-empty', [28], 1, {0: 1}),
    ('observation-compatible', [0, 28, 29], 2, {1: 0}),
    ('full-equality-not-mod13', [0, 28], 2, {1: 0, 0: 3}),
]
receipt = []
for name, allowed, s, observed in fixtures:
    a = oracle(contexts, observed, s, allowed)
    b = brute_force(contexts, observed, s, allowed)
    for key in ('status', 'masks', 'joints', 'lifts'):
        ensure(a[key] == b[key], name + ': two independent enumeration routes differ in ' + key)
    receipt.append(dict(name=name, status=a['status'], functions=len(a['lifts']),
                        pieces=len(a['pieces']), pair_points=a['pair_points'],
                        raw_points=b['points'], joint_predictions=len(a['joints'])))

# Entire alias pair fiber: independent minimum support equals observed minimum.
costs = {}
for x, y in product(range(26), repeat=2):
    v = [0] * 31
    v[1], v[7] = x, y
    d = descriptor(v)
    cost = (x != 0) + (y != 0)
    costs[d] = min(costs.get(d, 99), cost)
for (alpha, beta), cost in costs.items():
    ensure(minimum_support(alpha, beta) == cost, 'alias-pair minimum support')
for x in range(26):
    ensure(13 * (x*x-x) % 26 == 0, '13x² alias')
ensure(feature_row(contexts[1])[28:] == (0, 0, 0), 'full equality was reduced first')

# All exact C functions excluded for both signs, every constant and equality.
carry_descriptors = set()
for q, b, sign in product((28, 29, 30), range(26), (1, 25)):
    v = [0] * 31
    v[0], v[q] = b, sign
    a, beta = descriptor(v)
    carry_descriptors.add((a, beta))
    ensure(not residual(a, beta), 'C boundary included')
ensure(len(carry_descriptors) == 156, 'C count')

# Old and residual laws can give identical finite predictions.
zero_equality_context = [0, 13, 0, 13, 0, 13]
ensure(feature_row(zero_equality_context)[28] == 0, 'fixture')
v = [0] * 31
v[28] = 1
ensure(not residual(*descriptor(v)), 'old C fixture')
v[28] = 3
ensure(residual(*descriptor(v)), 'residual fixture')

# Repeated equal row: marginal product strictly exceeds the joint relation.
joint = oracle([contexts[0], contexts[0]], {}, 1, [28])
ensure(len(joint['joints']) < len(joint['masks'][0])*len(joint['masks'][1]),
       'joint/marginal counterexample absent')

rejections = 0
for witness in ([[28, 1]], [[28, 25]], [[1, 13], [7, 13]], [[28, 3], [28, 4]], [[28, 0]]):
    try:
        check_sparse_witness(witness, contexts, {}, 3)
    except VerificationError:
        rejections += 1
    else:
        raise RuntimeError('wrong residual/malformed witness accepted')
try:
    oracle(contexts, {}, 1, [28], max_points=1)
except ReferenceLimit:
    rejections += 1
else:
    raise RuntimeError('reference point cap ignored')

print(json.dumps(dict(status='PASS', fixtures=receipt, alias_pair_descriptors=len(costs),
                     carry_functions=len(carry_descriptors), deliberate_rejections=rejections,
                     cpu_seconds=time.process_time()-start,
                     max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss), indent=2))
