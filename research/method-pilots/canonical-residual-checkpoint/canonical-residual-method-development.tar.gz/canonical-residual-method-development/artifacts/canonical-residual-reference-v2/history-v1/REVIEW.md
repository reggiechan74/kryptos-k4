# Independent canonical residual development audit

2026-10-31. **PASS at the exact source pins below for the disclosed bounded
development contract.** No correctness defect was found; no producer source
change was made. This is not K4 admission, holdout validation, production
authorization, proof of global novelty, or a speedup claim. Historical matbalez
operator scope remains unresolved. No target data, matrix, fit, archived-target
replay, old held-out input, fresh holdout, or remote write was used.

The private administrative register [reference omitted], repository instructions and current
ledgers, canonical quotient proof, fixed E/B/C operator-scope material and
producer development freeze were read before acting. The independent plan is
`PLAN.md`, frozen before tests. Repository ledger reconciliation is managed separately.

## Exact reviewed producer pins

- `residual_decoder.py`:
  `be050003b9a73c14a7f7dda44afeb160e0e847045d57ddfa4b9527bdc68f7d67`
- Vendored `affine_filter.py`:
  `1e19e9ad872d517487cfe7968a9f4b906756007d5e710be216807620f078c90d`
- Other producer fixture/plan pins are recorded in both `audit-normal.json`
  and `audit-optimized.json`; all remained unchanged across both audits.

## Independent computation, not trust in producer certificates

`reference.py` imports no producer or generic-core feature evaluator, elimination,
canonicalization, compiler, residual predicate, lift or membership function.
It implements the original31-coordinate model independently. For each maximal
original support it solves the observation equations over F13 and F2 using its
own elimination, exhaustively enumerates free coordinates in both fields, pairs
them by CRT, canonicalizes only afterward, and tests R directly on descriptors.
Thus beta eligibility and all original coefficient lifts are preserved before
canonical deduplication. The raw tiny oracle separately enumerates all nonzero
Z26 coefficients on every support of size at most s, without linear solving.

`verify_result` is an independent, deliberately bounded untrusted-result
**semantic verifier**. It recomputes the complete reference relation, requires
the exact complete support/beta piece inventory, then enumerates every point of
each published piece's entire F13 ambient space. The advertised base-minus-cuts
set must equal the independently derived canonical residual fiber. It verifies:

- Every core alpha marginal mask, every core alpha witness, and core feasibility.
- Every top-level and per-piece original sparse witness, its common support and
  beta, residual membership, exact minimum-support cost and observations.
- Every complete Z26 marginal mask and ALL cross-piece provenance contributors.
- EXACT/EMPTY semantics, including feasible no-output cases; INCOMPLETE must
  suppress all partial masks, witnesses, provenance, pieces and feasibility.
- Declared input/compiler/dependency identities and the optional exact producer
  source pin; generic instance identities are reconstructed independently.

The generic elimination transcripts are not trusted or used for completeness.
This finite verifier does not authenticate execution provenance merely because
a declared hash matches. Use `expected_source_sha256` for a trusted reviewed pin.
Its optional `expected` argument is only a trusted in-process oracle memo, never
untrusted supplied evidence. The point cap raises `ReferenceLimit`, not EMPTY.
It remains a bounded development verifier, not an unlimited hostile-file parser.

## Normal and optimized-Python results

Both runs passed identical non-resource checks against the corresponding normal
and optimized stored producer outputs. **Counts below are per run, not summed
as if the two modes tested different instances.**

| Check | Result |
| --- | ---: |
| Producer disclosed tiny cases | 10 |
| Fresh31-feature disclosed development cases | 4 |
| Raw tiny original coefficient vectors | 22,960 |
| Original-coordinate field-pair points | 14,051 |
| Complete feasible support/beta pieces | 288 |
| Published F13 ambient points checked | 602,004 |
| Core alpha witnesses checked | 29,883 |
| Original sparse witnesses checked | 1,284 |
| Deliberate result mutations rejected | 17 |
| Cap behavior cases | 7 |

Mutation tests reject C and B witnesses, a witness with no equality dependence,
wrong core alpha, omitted beta fiber, omitted canonical cut, wrong mask, missing
provenance, duplicate piece, B beta replacement, wrong generic/input/compiler/
source identity, wrong per-piece feasibility witness, false EMPTY, and an
INCOMPLETE result leaking partial outputs. Six explicit zero/tight cap requests
return INCOMPLETE with no partial fields. A zero inclusion-exclusion term budget
correctly remains EXACT on the small-union route, where no IE terms are needed.

The separate reference self-test compares both complete oracle routes on11 more
disclosed tiny cases, checks all156 C functions,338 canonical lag/square pair
descriptors against all676 lifts, the 13*x²=13*x identity over all26 symbols,
full equality before field reduction, and a joint-versus-marginal counterexample.
Six intentionally invalid/capped self-test requests are rejected.

Resource receipts, not benchmarks: full normal independent audit5.712CPU
seconds/36,604KiB peak RSS; optimized audit11.385CPU seconds/37,740KiB.
Each process had120CPU seconds,768MiB address space and150-second watchdog.
Reference self-tests passed under both Python modes as well.

## Fresh31 ambiguity, including the excluded C plant

| Disclosed case | Residual global functions | Distinct full91-row predictions |
| --- | ---: | ---: |
| fresh31-0 | 675 | 675 |
| fresh31-1 | 13 | 13 |
| fresh31-2 | 1,476 | 1 |
| fresh31-3 | 50 | 50 |

Case2's planted b−E56 law is excluded C, but1,476 different residual global
functions fit the observations and give one common finite91-row prediction.
This frozen random development stream has no equality event for any of the
three designated pairs across its91 contexts, and every observed value is7.
It is a retained degenerate development fixture, not independent evidence of
recovery on equality-active observations. The other three streams have equality
exposure counts (2,3,2), (2,2,2), and (2,2,2), respectively.
This is correct, not leakage of C into R: global-law filtering does not subtract
every finite prediction shared by an old law. It is a concrete warning that
even a unique complete finite prediction does not identify a global function,
prove model membership, or recover the intended mechanism. The other plants
satisfy R; uniqueness was never required.

## Source-level conclusions and limits

The fixed-beta compiler is equivalent to the frozen R predicate: B is tested on
canonical beta, absence of equality beta produces the alpha-equality-zero cut,
and only a beta supported on constant plus one equality can produce the two C
cuts with equality alpha=1 or12 and all other nonconstant alpha zero. Full-symbol
equality is evaluated before either field reduction. Cuts are removed before
projection, not after marginal projection by full-mask subtraction.

Maximal original support containers are complete because any <=s original
vector can be zero-padded to one. Each admitted alpha/beta has a minimal original
lift inside that same container. Zero-alpha coordinates and square/lag aliases
cannot bypass global predicates. Every feasible fiber is retained even when
other fibers have identical predictions; all cross-piece provenance is kept.
No saturation optimization or parity-fiber merger has been introduced.

The tested code is development-only. Generic/core cooperative work/time budgets
are not hard resource bounds; external process limits remain necessary. This
audit does not establish scalable performance, any unknown historical scope,
target compatibility, unseen-case recovery, or automatic future admission.

## Reproduction

From this directory, with the pinned producer files and stored disclosed outputs:

```sh
timeout 150s python selftest.py
timeout 150s python -O selftest.py
timeout 150s python audit_results.py --mode all
timeout 150s python -O audit_results.py --mode all --optimized-results
```

`audit-normal.json`, `audit-optimized.json`, the two self-test receipts and
`SHA256SUMS` retain the results and exact local file identities. No denied,
pending or uncertain operation remains in this audit.
