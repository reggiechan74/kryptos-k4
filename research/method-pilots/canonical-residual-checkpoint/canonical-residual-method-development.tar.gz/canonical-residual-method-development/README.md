# Canonical residual method — implementation and incomplete-validation checkpoint

**Synthetic/disclosed method development only. K4 remains unsolved and NO-GO.**
The canonical residual decoder and its separately versioned certified-fiber
reference passed bounded implementation checks. The intervening single fresh
synthetic validation **failed its resource contract and remains permanently
INCOMPLETE**. A later full-feature resource pilot is **design-only and not run**.
These are different results, not one successful validation campaign.

- [Results and limits](RESULTS.md)
- [Source inventory and exclusions](SOURCE-INVENTORY.json)
- [Original/public artifact hashes and transformations](PROVENANCE.json)
- [Changed Python string tokens and rationale](PYTHON-STRING-CHANGES.json)
- [Publication integrity check](INTEGRITY-RECEIPT.json)
- [Complete archive manifest](MANIFEST.json)
- [Publication preparation, distinct from scientific execution](PACKAGING-NOTE.md)

## Evidence guide

| Stage | Evidence | Interpretation |
| --- | --- | --- |
| Canonical decoder | [Development report](artifacts/canonical-residual-dev/REPORT.md), [independent full review](artifacts/canonical-residual-full-review/REVIEW.md) | Fixed R compiler; 10 tiny and four disclosed full-31-feature controls, independent implementation review. |
| Reference v1 → v2 | [Original review](artifacts/canonical-residual-reference/REVIEW.md), [separate patch report](artifacts/canonical-residual-reference-v2/PATCH-REPORT.md) | Preserve the NaN point-cap flaw, strict-integer repair and historical fixed-integer results. |
| Single fresh cohort | [Approved incomplete-preservation release](artifacts/residual-validation-incomplete-release/README.md), [supplement](artifacts/residual-validation-incomplete-supplement/README.md) | 48 cases/96 scheduled jobs; 23 accepted outputs, one failed worker, 72 unstarted. No truth release or cohort PASS. |
| Capacity obstruction | [Counting proof](artifacts/residual-zero-trace-cap-proof/PROOF.md), [independent proof](artifacts/residual-capacity-proof-independent-review/PROOF.md) | 1,393 mandatory support/beta pieces require 3,060,421 ambient verifier points, above the frozen 2,000,000 cap. No case replay. |
| CPU diagnostic | [Separate two-control report](artifacts/residual-validation-incomplete-release/generic-resource-diagnostic/REPORT.md) | Modest soft-limit lag, not an explanation or repair of the original hard-ceiling excess. |
| Certified-fiber reference v3 | [Contract](artifacts/canonical-residual-reference-v3/CONTRACT.md), [execution report](artifacts/residual-reference-v3-execution/REPORT.md), [independent final PASS](artifacts/residual-reference-v3-independent-review/REVIEW.md) | Two independently written suite/oracle implementations, each run normal and optimized on the same 42 disclosed cases. Complete relations verified. |
| Next resource pilot | [Final proposal](artifacts/residual-reference-v3-next-stage-proposal/PROPOSAL.md), [independent DESIGN PASS](artifacts/residual-next-stage-independent-design-review/REVIEW.md) | Two proposed full-31 controls and certified rank/beta workload preflight; no implementation, trace expansion, draw or execution. |

## Fixed scope

The residual is **R = E ∖ (B ∪ C)**: E requires a canonical equality coefficient
in either field; B has parity support confined to constant/lag1; C contains the
156 constant ± one equality-indicator functions. Equalities are evaluated on
unreduced symbols. Sparse witnesses use a common original support of size at
most three; padded support/beta containers, all lifts, joint predictions and
cross-piece provenance are retained. Canonical functions, coefficients and
finite traces have different multiplicities. Marginal sets do not imply a
common joint witness.

The previously published filtered-affine/source audit independently verified
the retained **B receipt implication**, without recomputing the target or
re-authenticating its original canonical extraction. Historical source-only
review caveats are retained in their dated documents. Matbalez historical
operator scope remains unresolved. No global novelty, speedup, model-membership,
production-readiness or target-admission claim follows.

## How to read the archive

`artifacts/` contains sanitized derivatives of the named, explicitly approved
source roots. This is an evidence archive, **not a ready-to-run portable release**.
Absolute workspace/runtime strings and private coordination identifiers were
normalized; original hashes remain in historical freezes/receipts. Use the
package provenance to relate original and public bytes. Historical manifests
still describe their original execution tree; they are not checksums of every
sanitized public derivative. The new package manifest checks public bytes.

No seed or unreleased truth bytes are included. The only historical cohort
material comes from the already-approved incomplete release and supplement;
commitments and labeled operational mocks are retained. Private handoffs,
bytecode caches, unfrozen working drafts and third-party source caches are not
included. Original scientific files were never edited. Publication packaging
performed no solver, generator, replay, source-module import or new experiment.
