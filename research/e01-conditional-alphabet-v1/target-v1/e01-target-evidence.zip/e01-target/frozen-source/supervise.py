"""One invocation, retained external receipt even if the worker is killed."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(1,5))
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
import hashlib,json,pathlib,subprocess,sys,time,traceback
D=pathlib.Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('expected grant-pinned FREEZE SHA256')
expected=sys.argv[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((D/'FREEZE.json').read_bytes())==expected
manifest=json.loads((D/'FREEZE.json').read_text())
for name,h in manifest['files'].items():assert sha((D/name).read_bytes())==h
contract=json.loads((D/'EXECUTION.json').read_text())
for name,h in contract['binary_sha256'].items():assert sha(pathlib.Path(name).read_bytes())==h
argv=[expected if x=='<GRANT_FREEZE_SHA256>' else x for x in contract['worker_argv']]
receipt=pathlib.Path(contract['external_receipt'])
assert not receipt.exists() and not pathlib.Path(contract['output_directory']).exists()
def valid_result(worker):
    if worker.get('status')!='COMPLETE_ONE_CANDIDATE' or worker.get('source_freeze_sha256')!=expected:return False
    if worker.get('input_sha256')!=contract['input_sha256'] or worker.get('source_bank_sha256')!=contract['bank_sha256']:return False
    if type(worker.get('candidate_count')) is not int or worker['candidate_count']!=1:return False
    candidates=worker.get('candidates')
    if type(candidates) is not list or len(candidates)!=1 or type(candidates[0]) is not dict:return False
    c=candidates[0];plain=c.get('plaintext');reference=c.get('reference_plaintext')
    if type(plain) is not str or len(plain)!=97 or any(ch not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' for ch in plain) or reference!=plain:return False
    if c.get('model_id')!='E01-fixed-source-bank-Q-AZ':return False
    if any(c.get(k) is not True for k in ('reference_agreement','production_full_reencryption','reference_full_reencryption')):return False
    mask=c.get('clue_mask')
    if type(mask) is not list or len(mask)!=24 or any(type(v) is not bool for v in mask):return False
    if type(c.get('clue_matches')) is not int or c['clue_matches']!=sum(mask):return False
    if type(c.get('compatible')) is not bool or c['compatible']!=all(mask):return False
    if worker.get('outcome')!=('EXACT_COMPATIBLE' if all(mask) else 'EXACT_INCOMPATIBLE'):return False
    checks=[{'position_one_based':start+i,'expected':ch,'observed':plain[start-1+i],'match':plain[start-1+i]==ch} for start,text in ((22,'EASTNORTHEAST'),(64,'BERLINCLOCK')) for i,ch in enumerate(text)]
    return c.get('assertion_checks')==checks and mask==[v['match'] for v in checks]
start=time.monotonic();status='INCOMPLETE';rc=None;error=None;integrity=False
try:
    rc=subprocess.run(argv,check=False).returncode
    integrity=all(sha((D/name).read_bytes())==h for name,h in manifest['files'].items())
    result=pathlib.Path(contract['output_directory'])/'REPORT.json'
    worker=json.loads(result.read_text()) if result.exists() else {'status':'INCOMPLETE'}
    status='PASS' if rc==0 and integrity and valid_result(worker) else 'FAIL_OR_INCOMPLETE'
except BaseException as e:
    status='INCOMPLETE';error=repr(e)+'\n'+traceback.format_exc()
finally:
    child=resource.getrusage(resource.RUSAGE_CHILDREN);own=resource.getrusage(resource.RUSAGE_SELF)
    total=child.ru_utime+child.ru_stime+own.ru_utime+own.ru_stime
    if total>=4:status='FAIL_OR_INCOMPLETE'
    receipt.write_text(json.dumps({'status':status,'exit_code':rc,'error':error,'wall_seconds':time.monotonic()-start,'child_cpu_seconds':child.ru_utime+child.ru_stime,'supervisor_cpu_seconds':own.ru_utime+own.ru_stime,'aggregate_cpu_seconds_before_receipt_serialization':total,'maxrss_child_kib':child.ru_maxrss,'integrity':integrity,'argv':argv,'freeze_sha256':expected,'accounting_note':'Full worker/timeout and supervisor process CPU includes startup/imports and post-run metadata parsing/source hashing. Receipt serialization/final exit tail excluded; measured aggregate must be below4, leaving1CPU-second reserve. External tool/OS tail unmeasured. Supervisor soft CPU1/hard5 and128MiB; worker soft2/hard3 and128MiB.'},indent=2)+'\n')
if status!='PASS':raise SystemExit(1)
