"""Exactly one immutable E01 candidate. No invocation absent a separate grant."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(2,3))
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
import hashlib,json,pathlib,sys,time,traceback,types
D=pathlib.Path(__file__).resolve().parent
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
CRIBS=[{'start':22,'end':34,'plaintext':'EASTNORTHEAST'},{'start':64,'end':74,'plaintext':'BERLINCLOCK'}]
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,why):
    if not ok:raise RuntimeError(why)
def main(expected,out):
    fb=(D/'FREEZE.json').read_bytes();require(sha(fb)==expected,'grant freeze mismatch');freeze=json.loads(fb)
    for n,h in freeze['files'].items():require(sha((D/n).read_bytes())==h,'dependency mismatch:'+n)
    contract=json.loads((D/'EXECUTION.json').read_text())
    for n,h in contract['binary_sha256'].items():require(sha(pathlib.Path(n).read_bytes())==h,'binary mismatch')
    require(pathlib.Path(sys.executable).resolve()==pathlib.Path(contract['interpreter']).resolve(),'interpreter')
    require(out==pathlib.Path(contract['output_directory']),'output path')
    modules=[]
    for n in ('production','reference'):
        b=(D/(n+'.py')).read_bytes();require(sha(b)==freeze['files'][n+'.py'],'module mismatch')
        m=types.ModuleType(n);exec(compile(b,str(D/(n+'.py')),'exec',dont_inherit=True,optimize=0),m.__dict__);modules.append(m)
    prod,ref=modules
    bankbytes=(D/'source-bank.json').read_bytes();require(sha(bankbytes)==contract['bank_sha256'],'bank identity');bank=json.loads(bankbytes)
    rows=bank['rows'];require(set(rows)==set(AZ) and all(type(r) is str and len(r)==26 and set(r)==set(AZ) for r in rows.values()),'permutation bank')
    inp=pathlib.Path(contract['input_path']);ib=inp.read_bytes();require(len(ib)==308 and sha(ib)==contract['input_sha256'],'input identity')
    data=json.loads(ib);require(set(data)=={'ciphertext','length','indexing','cribs'},'input schema')
    require(type(data['length']) is int and data['length']==97 and data['indexing']=='one-based inclusive' and data['cribs']==CRIBS,'input metadata')
    text=data['ciphertext'];require(type(text) is str and len(text)==97 and all(c in AZ for c in text),'input framing')
    # Exactly one continuous model; clues do not enter either decoder.
    plain=prod.decrypt(text,rows,'Q',AZ);reference=ref.decrypt(text,rows,'Q',AZ)
    require(plain==reference and len(plain)==97,'decoder disagreement')
    require(prod.encrypt(plain,rows,'Q',AZ)==text,'production full re-encryption')
    require(ref.encrypt(reference,rows,'Q',AZ)==text,'reference full re-encryption')
    checks=[{'position_one_based':crib['start']+i,'expected':ch,'observed':plain[crib['start']-1+i],'match':plain[crib['start']-1+i]==ch} for crib in CRIBS for i,ch in enumerate(crib['plaintext'])]
    require(len(checks)==24,'all24 checks')
    mask=[c['match'] for c in checks];candidate={'model_id':'E01-fixed-source-bank-Q-AZ','plaintext':plain,'reference_plaintext':reference,'reference_agreement':True,'production_full_reencryption':True,'reference_full_reencryption':True,'assertion_checks':checks,'clue_mask':mask,'clue_matches':sum(mask),'compatible':all(mask)}
    require(inp.read_bytes()==ib,'input changed')
    for n,h in freeze['files'].items():require(sha((D/n).read_bytes())==h,'dependency changed:'+n)
    for n,h in contract['binary_sha256'].items():require(sha(pathlib.Path(n).read_bytes())==h,'binary changed')
    return {'status':'COMPLETE_ONE_CANDIDATE','outcome':'EXACT_COMPATIBLE' if all(mask) else 'EXACT_INCOMPATIBLE','candidate_count':1,'candidates':[candidate],'input_sha256':sha(ib),'source_bank_sha256':sha(bankbytes),'source_freeze_sha256':expected,'interpretation':'Only the frozen E01 source-conditioned model; compatibility is not intended-solution authentication.'}
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('expected grant-pinned freeze SHA and output directory')
    out=pathlib.Path(sys.argv[2]);out.mkdir(parents=False,exist_ok=False)
    start=time.monotonic();cpu=time.process_time();report={'status':'INCOMPLETE_OR_INVALID'}
    try:report=main(sys.argv[1],out)
    except BaseException as e:report={'status':'INCOMPLETE_OR_INVALID','error':repr(e),'traceback':traceback.format_exc()};raise
    finally:
        report['internal_receipt']={'cpu_seconds_after_imports':time.process_time()-cpu,'wall_seconds_after_imports':time.monotonic()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
        (out/'REPORT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
