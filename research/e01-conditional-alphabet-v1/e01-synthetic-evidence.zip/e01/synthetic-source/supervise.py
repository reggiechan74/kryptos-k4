"""One invocation, retained external receipt even if the worker is killed."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(2,60))
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
import hashlib,json,pathlib,subprocess,sys,time,traceback
D=pathlib.Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('expected grant-pinned FREEZE SHA256')
expected=sys.argv[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((D/'FREEZE.json').read_bytes())==expected
manifest=json.loads((D/'FREEZE.json').read_text())
for name,h in manifest['files'].items():assert sha((D/name).read_bytes())==h
contract=json.loads((D/'EXECUTION.json').read_text())
for name,h in contract['binary_sha256'].items():assert sha(pathlib.Path(name).read_bytes())==h
argv=[expected if x=='<GRANT_FREEZE_SHA256>' else x for x in contract['worker_argv']]
receipt=pathlib.Path(contract['external_receipt'])
assert not receipt.exists() and not pathlib.Path(contract['output_directory']).exists()
start=time.monotonic();status='INCOMPLETE';rc=None;error=None;integrity=False
try:
    rc=subprocess.run(argv,check=False).returncode
    integrity=all(sha((D/name).read_bytes())==h for name,h in manifest['files'].items())
    result=pathlib.Path(contract['output_directory'])/'REPORT.json'
    worker=json.loads(result.read_text()) if result.exists() else {'status':'INCOMPLETE'}
    status='PASS' if rc==0 and integrity and worker['status']=='PASS' else 'FAIL_OR_INCOMPLETE'
except BaseException as e:
    status='INCOMPLETE';error=repr(e)+'\n'+traceback.format_exc()
finally:
    child=resource.getrusage(resource.RUSAGE_CHILDREN);own=resource.getrusage(resource.RUSAGE_SELF)
    total=child.ru_utime+child.ru_stime+own.ru_utime+own.ru_stime
    if total>=59:status='FAIL_OR_INCOMPLETE'
    receipt.write_text(json.dumps({'status':status,'exit_code':rc,'error':error,'wall_seconds':time.monotonic()-start,'child_cpu_seconds':child.ru_utime+child.ru_stime,'supervisor_cpu_seconds':own.ru_utime+own.ru_stime,'aggregate_cpu_seconds_before_receipt_serialization':total,'maxrss_child_kib':child.ru_maxrss,'integrity':integrity,'argv':argv,'freeze_sha256':expected,'accounting_note':'Full worker/timeout and supervisor process CPU includes startup/imports and post-run metadata parsing/source hashing. Receipt serialization/final exit tail excluded; measured aggregate must be below59, leaving1CPU-second reserve. External tool/OS tail unmeasured. Supervisor soft CPU2/hard60 and128MiB; worker soft57/hard58 and128MiB.'},indent=2)+'\n')
if status!='PASS':raise SystemExit(1)
