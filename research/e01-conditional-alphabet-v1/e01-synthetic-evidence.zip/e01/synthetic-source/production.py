"""Fixed row-bank implementation. No target fixtures, fitting, or search."""
def validate(rows,start,alphabet,text):
    if not isinstance(alphabet,str) or len(alphabet)<2 or len(set(alphabet))!=len(alphabet):
        raise ValueError('alphabet')
    if set(rows)!=set(alphabet) or any(not isinstance(v,str) or sorted(v)!=sorted(alphabet) for v in rows.values()):
        raise ValueError('rows')
    if start not in alphabet or any(c not in alphabet for c in text): raise ValueError('symbols')

def encrypt(text,rows,start,alphabet='ABC'):
    validate(rows,start,alphabet,text)
    maps={s:dict(zip(row,alphabet)) for s,row in rows.items()}
    out=[]
    for p in text:
        out.append(maps[start][p]);start=p
    return ''.join(out)

def decrypt(text,rows,start,alphabet='ABC'):
    validate(rows,start,alphabet,text)
    maps={s:dict(zip(alphabet,row)) for s,row in rows.items()}
    out=[]
    for c in text:
        start=maps[start][c];out.append(start)
    return ''.join(out)

def compatible(plain,assertions):
    if any(type(i)!=int or not 0<=i<len(plain) or not isinstance(c,str) or len(c)!=1 for i,c in assertions.items()):
        raise ValueError('assertions')
    return all(plain[i]==c for i,c in assertions.items())

def build(fields,alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    normalized=[''.join(c for c in t if c in alphabet) for t in fields]
    counts={a:{b:0 for b in alphabet} for a in alphabet}
    for text in normalized:
        for a,b in zip(text,text[1:]): counts[a][b]+=1
    return counts,{a:''.join(sorted(alphabet,key=lambda b:(-counts[a][b],alphabet.index(b)))) for a in alphabet}
