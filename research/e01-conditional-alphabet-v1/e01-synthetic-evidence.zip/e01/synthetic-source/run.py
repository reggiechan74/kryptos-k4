"""One-shot synthetic checks only; run only following explicit parent grant."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(57,58))
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
import hashlib,itertools,json,pathlib,random,secrets,sys,time,traceback
import types
prod=ref=None
D=pathlib.Path(__file__).resolve().parent
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
def digest(b):return hashlib.sha256(b).hexdigest()
def write(out,name,obj):
    b=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode();(out/name).write_bytes(b);return digest(b)
def rows_reference(fields,alphabet=AZ):
    fields=[''.join(filter(lambda c:c in alphabet,t)) for t in fields]
    counts={a:{b:sum(sum(t.startswith(a+b,i) for i in range(len(t)-1)) for t in fields) for b in alphabet} for a in alphabet}
    rows={a:''.join(sorted(alphabet,key=lambda b:(-counts[a][b],alphabet.index(b)))) for a in alphabet}
    return counts,rows

def static_and_tiny(fields,bank):
    counts,rows=prod.build(fields)
    assert (counts,rows)==rows_reference(fields)==(bank['counts'],bank['rows'])
    # Punctuation stripped before adjacency; no cross-section pair.
    c,r=prod.build(['A?B','C'],'ABC');assert c['A']['B']==1 and sum(map(sum,(list(v.values()) for v in c.values())))==1
    c,r=prod.build(['ABA','ACA'],'ABC');assert r['A']=='BCA' and r['B']==r['C']=='ABC'
    c,r=prod.build(['A'],'ABC');assert all(v=='ABC' for v in r.values())
    n=0; perms=[''.join(p) for p in itertools.permutations('ABC')]
    messages=[''.join(p) for length in range(6) for p in itertools.product('ABC',repeat=length)]
    for bankrows in itertools.product(perms,repeat=3):
        tiny=dict(zip('ABC',bankrows))
        for start in 'ABC':
            for plain in messages:
                c=prod.encrypt(plain,tiny,start);assert c==ref.encrypt(plain,tiny,start)
                assert prod.decrypt(c,tiny,start)==ref.decrypt(c,tiny,start)==plain;n+=1
    assert n==235872
    for state,p in itertools.product(AZ,repeat=2):
        c=prod.encrypt(p,rows,state,AZ);assert c==ref.encrypt(p,rows,state,AZ)
        assert prod.decrypt(c,rows,state,AZ)==ref.decrypt(c,rows,state,AZ)==p
    good={c:'ABC' for c in 'ABC'}
    malformed=[('AAB',good,'A','A'),('ABC',{'A':'ABC'},'A','A'),('ABC',dict(good,A='AAC'),'A','A'),('ABC',dict(good,A='AB'),'A','A'),('ABC',good,'Z','A'),('ABC',good,'A','Z')]
    for alpha,rs,start,text in malformed:
        for module in (prod,ref):
            for fn in (module.encrypt,module.decrypt):
                try:fn(text,rs,start,alpha)
                except ValueError:pass
                else:raise AssertionError('malformed accepted')
    for assertions in ({-1:'A'},{3:'A'},{'0':'A'},{0:'AA'}):
        try:prod.compatible('ABC',assertions)
        except ValueError:pass
        else:raise AssertionError('bad assertion accepted')
    return {'tiny_cases':n,'real_row_cells':676,'malformed_cipher_cases':24,'malformed_assertion_cases':4}

def generate(out,seed,fields,rows):
    def rng(label):return random.Random(int.from_bytes(hashlib.sha256(seed+label.encode()).digest(),'big'))
    def uniform(r):return ''.join(r.choice(AZ) for _ in range(97))
    cases=[];answers={}; counter=0
    def add(kind,cipher,rs,assertions,plain=None):
        nonlocal counter
        caseid=hashlib.sha256(seed+f'id:{counter}'.encode()).hexdigest()[:24];counter+=1
        cases.append({'id':caseid,'ciphertext':cipher,'rows':rs,'assertions':list(assertions.items())})
        answers[caseid]={'kind':kind,'plain':plain}
    for i in range(64):
        plain=uniform(rng(f'positive:{i}')); cipher=ref.encrypt(plain,rows,'Q',AZ)
        assertions=dict(enumerate(plain[:24]))
        add('positive',cipher,rows,assertions,plain)
        wrong=assertions.copy();j=i%24;wrong[j]=AZ[(AZ.index(wrong[j])+1)%26]
        add('wrong',cipher,rows,wrong,plain)
        nr=rng(f'null:{i}');null=uniform(nr);na={j:nr.choice(AZ) for j in range(24)};add('null',null,rows,na)
        sc=list(cipher);rng(f'cipher-shuffle:{i}').shuffle(sc);add('shuffled_cipher',''.join(sc),rows,assertions)
        shuffled=[]
        for si,text in enumerate(fields):
            tail='Q' if si==2 else ''; body=list(text[:-1] if si==2 else text)
            rng(f'source-shuffle:{i}:{si}').shuffle(body);shuffled.append(''.join(body)+tail)
            assert sorted(shuffled[-1])==sorted(text)
        shuffled_rows=rows_reference(shuffled)[1]
        add('shuffled_source',cipher,shuffled_rows,assertions)
    rng('case-order').shuffle(cases)
    assert len(cases)==len(answers)==320
    write(out,'cases.json',cases);write(out,'answers.json',answers)
    return cases

def solve(cases,module):
    result={}
    for case in cases:
        plain=module.decrypt(case['ciphertext'],case['rows'],'Q',AZ)
        assertions=dict(case['assertions'])
        ok=prod.compatible(plain,assertions) if module is prod else not any(plain[i]!=value for i,value in assertions.items())
        assert module.encrypt(plain,case['rows'],'Q',AZ)==case['ciphertext']
        # Sparse, inconsistent assertions cannot modify plaintext; no clue passed to decrypt.
        sparse={0:plain[0],31:plain[31],96:plain[96]}
        assert prod.compatible(plain,sparse)
        result[case['id']]={'plain':plain,'compatible':ok}
    return result

def main(out,expected_freeze):
    global prod,ref
    freeze_bytes=(D/'FREEZE.json').read_bytes()
    assert digest(freeze_bytes)==expected_freeze, 'grant freeze mismatch'
    manifest=json.loads(freeze_bytes)
    for name,sha in manifest['files'].items():assert digest((D/name).read_bytes())==sha,(name,'freeze mismatch')
    contract=json.loads((D/'EXECUTION.json').read_text())
    for path,sha in contract['binary_sha256'].items():assert digest(pathlib.Path(path).read_bytes())==sha
    assert pathlib.Path(sys.executable).resolve()==pathlib.Path(contract['interpreter']).resolve()
    assert out==pathlib.Path(contract['output_directory'])
    modules=[]
    for name in ('production','reference'):
        b=(D/(name+'.py')).read_bytes();assert digest(b)==manifest['files'][name+'.py']
        m=types.ModuleType(name);exec(compile(b,str(D/(name+'.py')),'exec'),m.__dict__);modules.append(m)
    prod,ref=modules
    policy=json.loads((D/'source-policy.json').read_text());literal=json.loads((D/'source-fields.json').read_text())
    fields=[''.join(c for c in literal[k] if c in AZ) for k in ('k1','k2_as_inscribed','k3')]
    for key,text in zip(('k1','k2_as_inscribed','k3'),fields):
        assert len(text)==policy['source_plaintext_lengths'][key]
        assert digest(text.encode())==policy['source_plaintext_sha256'][key]
    assert fields[-1][-1]=='Q'
    bank=json.loads((D/'source-bank.json').read_text());checks=static_and_tiny(fields,bank)
    # Seed is drawn only after the frozen deterministic checks pass, never resampled.
    seed=secrets.token_bytes(32);write(out,'seed.json',{'hex':seed.hex(),'python':sys.version,'freeze_sha256':digest((D/'FREEZE.json').read_bytes())})
    cases=generate(out,seed,fields,bank['rows'])
    p=solve(cases,prod);psha=write(out,'production-results.json',p)
    r=solve(cases,ref);rsha=write(out,'reference-results.json',r)
    write(out,'sealed-results.json',{'production_sha256':psha,'reference_sha256':rsha})
    # Only now read the independently retained answers.
    answers=json.loads((out/'answers.json').read_text());assert p==r
    totals={kind:{'cases':0,'compatible':0} for kind in ('positive','wrong','null','shuffled_cipher','shuffled_source')}
    for caseid,answer in answers.items():
        got=p[caseid];kind=answer['kind'];totals[kind]['cases']+=1;totals[kind]['compatible']+=int(got['compatible'])
        if kind in ('positive','wrong'):assert got['plain']==answer['plain']
        if kind=='positive':assert got['compatible']
        if kind=='wrong':assert not got['compatible']
    assert all(v['cases']==64 for v in totals.values())
    for name,sha in manifest['files'].items():assert digest((D/name).read_bytes())==sha
    return {'status':'PASS','target_used':False,'checks':checks,'synthetic':totals,'null_shuffle_interpretation':'descriptive, no rejection threshold','source_bank_sha256':digest((D/'source-bank.json').read_bytes())}

if __name__=='__main__':
    if len(sys.argv)!=4 or sys.argv[1]!='--execute-approved':raise SystemExit('requires separate parent-approved one-shot invocation')
    out=pathlib.Path(sys.argv[3]);out.mkdir(parents=False,exist_ok=False)
    start=time.monotonic();cpu=time.process_time();report={'status':'INCOMPLETE'}
    try:report=main(out,sys.argv[2])
    except BaseException as e:
        report={'status':'FAIL','error':repr(e),'traceback':traceback.format_exc()};raise
    finally:
        report['receipt']={'cpu_seconds_after_worker_imports':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
        write(out,'REPORT.json',report)
