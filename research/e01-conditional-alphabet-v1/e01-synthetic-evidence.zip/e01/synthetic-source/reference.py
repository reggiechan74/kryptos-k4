"""Independent static-row-bank reference, authored before production inspection.

Rows map a previous-plaintext state to a permutation of the alphabet.
Encryption outputs the alphabet symbol at the position of the current plaintext
in that state's row; then the plaintext symbol becomes the next state.
No source loading, target input, test generation, or top-level execution.
"""


def validate(alphabet, rows, initial_state, text):
    if not isinstance(alphabet, str) or len(alphabet) < 2 or len(set(alphabet)) != len(alphabet):
        raise ValueError('alphabet must contain distinct symbols')
    if set(rows) != set(alphabet) or any(len(row) != len(alphabet) or set(row) != set(alphabet)
                                       for row in rows.values()):
        raise ValueError('one permutation row is required for each symbol')
    if initial_state not in alphabet or any(symbol not in alphabet for symbol in text):
        raise ValueError('state/text outside alphabet')


def encrypt(plaintext, rows, initial_state, alphabet='ABC'):
    validate(alphabet, rows, initial_state, plaintext)
    state = initial_state
    ciphertext = []
    for plain in plaintext:
        position = rows[state].index(plain)
        ciphertext.append(alphabet[position])
        state = plain
    return ''.join(ciphertext)


def decrypt(ciphertext, rows, initial_state, alphabet='ABC'):
    validate(alphabet, rows, initial_state, ciphertext)
    state = initial_state
    plaintext = []
    for cipher in ciphertext:
        position = alphabet.index(cipher)
        plain = rows[state][position]
        plaintext.append(plain)
        state = plain
    return ''.join(plaintext)
