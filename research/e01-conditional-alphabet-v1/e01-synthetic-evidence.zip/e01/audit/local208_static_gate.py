"""Static initial-emission table comparison only. No cipher/message loop or target input."""
import hashlib,json,pathlib,itertools
D=pathlib.Path(__file__).resolve().parent
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; KA='KRYPTOSABCDEFGHIJLMNQUVWXZ'
bank=json.loads((D/'SOURCE-BANK.json').read_text())
row=bank['rows']['Q']; e01=''.join(AZ[row.index(p)] for p in AZ)
records=[]
for arm,R,S,k in itertools.product(('A','B'),(AZ,KA),(AZ,KA),range(26)):
    local=''.join(S[(R.index(p)+(k if arm=='B' else 0))%26] for p in AZ)
    diffs=[p for p,a,b in zip(AZ,e01,local) if a!=b]
    records.append({'id':f'{arm}:{(AZ,KA).index(R)}:{(AZ,KA).index(S)}:{k}', 'initial_emission_by_AZ_input':local,'different_input_symbols':''.join(diffs),'first_difference':{'input':diffs[0],'E01':e01[AZ.index(diffs[0])],'local060':local[AZ.index(diffs[0])]} if diffs else None})
# Minimal common separating input set, exhaustively in cardinality then lexicographic order.
for size in range(1,27):
    sep=next((s for s in itertools.combinations(AZ,size) if all(any(p in r['different_input_symbols'] for p in s) for r in records)),None)
    if sep is not None: break
result={'status':'PASS_EXACT_LOCAL_208_GLOBAL_FUNCTION_DIFFERENCE','method':'initial emission table identity comparison, not a message batch','source_bank_sha256':hashlib.sha256((D/'SOURCE-BANK.json').read_bytes()).hexdigest(),'E01_initial_state':'Q','E01_initial_emission_by_AZ_input':e01,'descriptions':len(records),'matched_initial_maps':sum(r['first_difference'] is None for r in records),'distinct_local_initial_maps':len({r['initial_emission_by_AZ_input'] for r in records}),'minimum_common_separating_input_set':list(sep),'certificate':records}
(D/'LOCAL208-CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='certificate'},indent=2))
