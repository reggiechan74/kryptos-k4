# E01 / N100-044: source and mathematical admission audit

1 November 2026. **STATIC MODEL PASS; CONDITIONALLY ELIGIBLE FOR A FROZEN SYNTHETIC PILOT, NOT TARGET-ADMITTED.** No message encryption/decryption batch, K4 transformation, fit or clue check was performed. This is a source/proof audit, not a cipher result. It does not establish worldwide novelty.

## Exact model and frozen corpus

Use only `k1.plaintext`, `k2_as_inscribed.plaintext`, `k3.plaintext` from `data/controls.json` at baseline `ca3e86d21a86c6473593fbdd7920887acc58b026`. Whole-file SHA256 is `54f19ff0ecd1e058a6b84c6ddb4ad75a297e4181edb45803647ed208d8fc011b`. Source provenance is `sources/VERIFICATION.md`, SHA256 `e8cfeabe57f6766942758e754c51962a49cb525f7392f0fb31d61edb159d02dc`.

SOURCE-POLICY.json was written before the bank construction. Retain only uppercase ASCII A–Z in each named field; preserve IQLUSION, UNDERGRUUND, IDBYROWS, DESPARATLY, literal Xs and terminal Q. Question marks are removed before adjacency counting, so the letters on opposite sides of punctuation become adjacent. Do not count section-boundary pairs. Do not substitute corrected K2, original Carter prose or another source. Lengths are 63, 369, 336; total counted bigrams 765. Initial state is final K3 letter Q. This precisely resolves the original draft's source choice using its stated as-carved policy, without consulting a K4 result.

For source count n[a,b], row L_a is AZ sorted by (-n[a,b], b). Encode p in state a as AZ[rank_La(p)], then replace state with p. Decode c as L_a[rank_AZ(c)], then replace state with that decoded p. No updates to counts, reset, output shift or choice of alphabet exists. One deterministic model is proposed.

## Correctness and identifiability proof

Every row is a permutation: sorting assigns each of the 26 distinct letters one position, including all zero-count letters. At a common state the encoder and decoder are inverse permutations. Starting at the same fixed Q, induction on message length proves both state and entire output are recovered exactly. This remains true for zero-count rows, all ties, repetitions and empty messages.

Conditional uniqueness is trivial given the fixed bank and start state. It is not evidence that this was Sanborn's mechanism. The corpus is sparse and the arbitrary AZ tie convention materially shapes the model. No independent creator-use evidence for this statistical mechanism was found. This is a low-prior, fully disclosed speculative test; failure must not provoke a corpus/tie-break sweep.

## Source-only bank facts and a decisive distinction

SOURCE-BANK.json contains the source counts and 26 ranked rows, produced without processing any K4 symbols. There are 25 distinct rows; J and Z both have zero outgoing counts and give AZ. The only outgoing Q is the QL pair in IQLUSION (K3's terminal Q has no successor), giving:

- L_J = ABCDEFGHIJKLMNOPQRSTUVWXYZ
- L_Q = LABCDEFGHIJKMNOPQRSTUVWXYZ

At context J, input M encrypts to M and input A encrypts to A. At context Q, input M also encrypts to M, but input A encrypts to B. Thus these two distinct emission rows intersect in the pair M→M.

**Shift-bank lemma.** Fix arbitrary plaintext and ciphertext alphabet permutations X,Y and a fixed sign epsilon in {+1,-1}. Rows of the form Y[epsilon*rank_X(p)+k(h) mod26], where k depends on any strictly prior history h but not current p, are either identical or disagree at every input. Equality at one p forces equal k modulo26; then all outputs coincide. The J/Q witness contradicts this property. Prefixes ending J and Q are both allowed at the same position under E01, so it is a global functional distinction, not a target-trace observation.

Consequently E01 cannot be any fixed-axis Vigenere/Beaufort shift bank, even with an arbitrary causal scalar key rule. This separates the inspected Scott causal linear chains, ordinary additive autokey and ordinary fixed-source running-key mechanisms. It does not separate arbitrary noncyclic substitution banks, moving alphabets, current-symbol-dependent rules, or show that a finite target trace cannot coincide with an older model.

## Exact prior-art comparison

1. **Scott / EXT-048.** Read `novel/run_chain.py` at `a75178587efe9401ebf2a4edf3828472dd6fb2a2`, Git blob `4338bbcd8bc29a81e5127a49b31dc2cc06334317`. Its fixed independent axes, signs, strictly prior P/C lag terms, drift and constant all satisfy the shift-bank lemma. No external source was executed. [Pinned primary source](https://github.com/scott-dunphy/kryptos-k4/blob/a75178587efe9401ebf2a4edf3828472dd6fb2a2/novel/run_chain.py).
2. **mruckman / EXT-052.** Read preserved `033b_per_position_state_dependent.py` from `e4912152555f635c35e73fe454a8302a98a5902f`; Git blob `a9d9c2810fdb35deb8d57d9b4d219f08845c08bb`, local exact-body SHA256 `30c62679df56ba666ff52b114dbc88f5d4ce0df170ca58e0a357c88933ed8bf3`. It builds a keyword-derived alphabet pool and selects using seven position/current-ciphertext/prefix features, with default tuple sizes 2–6 and fixed-order combinations. It does not build K1–K3 conditional-frequency rows or use recovered plaintext as its state. This is a source-level distinction only: current-ciphertext selection can create implicit piecewise mappings, so absence of E01 rows from a pool would not alone prove global functional disjointness. No such global disjointness claim is made. [Pinned source](https://github.com/mruckman1/k4_cipher/blob/e4912152555f635c35e73fe454a8302a98a5902f/experiments/033b_per_position_state_dependent.py).
3. **Matbalez / EXT-051.** Rendered public handoff §6.6 reports adaptive frequency-count state rules; §6.7 reports causal feedback families and §8 describes fixed-axis autokey. E01 never updates counts and does not use the fixed shift-row structure. The specific adaptive-frequency overlap that blocks A01 therefore does not automatically subsume E01. The underlying adaptive sources are unavailable, so broader static-bank/selector coverage remains unknown. Do not turn missing equations into novelty evidence or import the author's run totals as verified exclusions. [Primary handoff](https://gist.github.com/matbalez/8300cb067a5cda55c3b44ef382d517c0#66-moving-alphabets-and-historical-machines).
4. **Local 060/H-EVOLVING-ALPHABET.** The pinned protocol defines persistent ciphertext-driven exchanges and prefix reversals using AZ/KA initial/reference alphabets, not a static source-conditioned bank. The completed follow-on static source gate proves global functional inequality against all 208 descriptions at the first emission: E01 sends A→B and L→A; every local description disagrees on at least one. See LOCAL208-GATE.md and the complete table certificate. This uses exact archived production/reference source, not different program names. No message batch was needed. [060 protocol](https://github.com/reggiechan74/kryptos-k4/blob/ca3e86d21a86c6473593fbdd7920887acc58b026/research/candidate-first-060/PROTOCOL.md).
5. **EXT-009/030/044/047 and local running-key/autokey records.** These inspect fixed-axis ciphertext feedback, interrupted/occurrence-stepped key schedules, progressive/reflected substitution, and earlier-section crib sliding respectively. E01 is neither a literal source stream nor a changing key index; known fixed-axis subclasses fall under the lemma. Other finite noncyclic source families still require exact source-row/signature checks rather than wholesale exclusion.

No matching exact E01 K4 attempt was located in the finite targeted search. Searches on 1 November included Kryptos plus conditional/bigram/frequency/previous-plaintext/alphabet-bank terms. Results mostly concerned n-gram scoring, classical ciphers, earlier-section running keys and the already inspected repositories. Search no-hit is not evidence of worldwide absence. No claimed solved plaintext or external verifier was used.

## Decision and remaining gates

The bank is well-defined and invertible, with a useful non-shift witness. **Proceed only to source implementation / independent review of a small synthetic protocol if the parent accepts the remaining finite prior-art uncertainty.** It is not currently target-ready. Remaining gates: independent corpus/count construction; honest treatment of arbitrary external selector coverage; and frozen control/source/runner contracts. An identical previously attempted function blocks this proposal; do not rescue it by changing corpus or tie-break.

### Proposed smallest pilot (not run or allocated)

One maximum 60-CPU-second, 128-MiB synthetic invocation after source review, with separate preparation accounting:

- Independently construct the 676 count cells and 26 rank rows from the three literal fields; require exact agreement with SOURCE-BANK.json. One implementation may scan pairs; the independent one can count explicit occurrences separately, both respecting stripped punctuation and section boundaries.
- Test all 216 possible 3-letter permutation banks (6^3), all 3 initial states and all messages of length 0..5 (364): 235,872 exact inverse checks. This tests generic finite-context row inversion, not a K4 search or global novelty proof.
- Check zero-count/tie normalization fixtures and all 676 direct emission/inverse pairs of the real source bank.
- Preserve the draft's proposed 64 fresh 97-letter synthetic messages without resampling; exact roundtrip plus one deliberately wrong asserted position per message must reject. Record shuffled-reference/ciphertext diagnostics without requiring universal rejection or claiming chance significance. Freeze seed-generation, controls and interpretation before generating them.
- Exact local208 source-operator gate is now PASS; retain and independently verify its certificate. External arbitrary selector coverage remains explicitly bounded, not globally resolved.

No target execution follows automatically. Any later proposed target is one fixed continuously decoded 97-letter string, all 24 fixed clue positions, full re-encoding, no scoring or tuning; compatible would not mean solved.

## Exposure and execution limits

The initial complete read of the shared controls fixture incidentally displayed its lower-panel K4 transcription rows. No K4 field was extracted, decoded, transformed, fitted or compared with clues. Parent was notified immediately; all subsequent source construction used only the three named K1–K3 plaintext fields. This audit must not be described as blinded or as having no raw-target-text exposure. External programs were read, never imported or executed. The only computation beyond metadata/search was the frozen corpus normalization, static count/row derivation and subsequent exact local208 initial-emission table comparison, not a message or cipher-test batch. No model variant was selected using a target outcome.

## Follow-on exact local gate

LOCAL208-GATE.md closes the previously outstanding available local208 comparison with an exact first-emission witness. E01 survives unchanged. A 120 nominal CPU-second preparation/pilot allocation was subsequently authorized (60 source/review,60 proposed pilot), but no synthetic invocation or target execution has been granted. The concrete proposed pilot protocol is separate.
