> Public administrative derivative; scientific verdict/evidence unchanged. Original hash is recorded in ADMIN-DERIVATIVES.json.

# E01 synthetic pilot — independent read-only outcome closeout

**PASS_SYNTHETIC_ONLY.** The one authorized invocation completed and stored evidence satisfies the frozen finite protocol. No target execution is authorized by this review and none occurred in this synthetic run. No cipher/reference function or case generator was replayed by the reviewer.

## Identity and completion

- Source freeze: `f2987d9fc3b65ac435ec113257facd3d7ec00ed8b47af86a3eda3db06c2fb0c1`.
- Source review: `c0c353bc1b851333794158fb1a89ec5398fef923ba70664d114aecae95dece98`.
- Worker report: `f985f6b45d730fa97bd9be777f2abe9fc09fa51ce3a2856073ee6d94d31c9c23`.
- External runtime receipt: `96d00b5ab706016ebb60d0e6abb80f3372c4301164c474865f53183d232ce027`.

All nine dependency hashes and both executable pins remain unchanged. The independent reference remains the pre-production-review source. Seed has32 bytes and the correct freeze binding. Production/reference result files are byte-identical and match their retained pre-answer seal hashes `ff55b1fbc8b5ed43ce1e294da28ca4788c340e63149d360cca23d625805ea017`.

## Finite outcome

The authenticated report contains235,872 tiny cases,676 real-bank row cells,24 malformed cipher calls and4 malformed assertion cases. Source review established that each specified check is mandatory before PASS; the independent outcome review authenticates those claims rather than rerunning the exhaustive suite.

All320 stored case IDs, answers and both result maps align exactly. Every stored ciphertext/plaintext is97 uppercase AZ symbols; each case bank has26 permutation rows and24 valid synthetic assertions at positions0–23. Independent comparison of stored plaintexts with their assertions reproduces:

| Kind | Cases | Compatible |
|---|---:|---:|
|Positive|64|64|
|Wrong-assertion twin|64|0|
|Independent null|64|0|
|Ciphertext shuffle|64|0|
|Source shuffle|64|0|

All positive/wrong stored plaintexts equal the retained answer; each wrong case has exactly one asserted-symbol mismatch. Both engine output maps agree in full. Full re-encoding is a mandatory original-run assertion and is not independently replayed here. Null/shuffle zero counts are descriptive observations, not evidence of a calibrated false-positive rate, universal rejection or K4 relevance. No fresh seed, shuffled source, message or candidate was generated during review.

The seven worker-created scientific artifacts total871,356 bytes; the external supervisor receipt is separate. Private tool/coordination records and later author narrative are not included in this public scientific inventory. Their omission does not alter any source, seed, case, answer, output, seal or runtime report.

## Resources and limits

External child/timeout CPU8.825865 seconds plus supervisor CPU0.116051 seconds gives8.941916 known sampled aggregate. Worker-command wall8.828568523 seconds; maximum child RSS40,960KiB. Internal worker CPU8.7556276 is already included and must not be added. Receipt serialization/final exit and external tool/OS tails are unmeasured, not zero; worker wall timer does not include supervisor startup/tail. Reported finite acceptance bounds hold, and no extra permission is recycled. The one60-second nominal pilot allocation is consumed within the existing120 allocation (60 preparation/review separate).

Successful metadata readback sampled0.082148764 CPU seconds, in addition to static metadata0.062712696, within the existing preparation/review allowance. Earlier inventory readback, source reading, shell/startup/report overhead remains unmeasured; this is not a comprehensive reviewer CPU measurement.

## Interpretation

The finite pilot supports the implementation's inverse/state semantics, source-bank agreement and declared controls. It does not establish creator use, a K4 plaintext or worldwide novelty. Earlier raw-target-text exposure remains disclosed; procedural answer separation is not a claim of observational blinding. Exact local208 and fixed-axis shift-bank distinctions remain bounded, with unavailable/arbitrary external selector coverage unresolved.

A separate target proposal, exact source review and explicit one-shot grant would be needed for any later K4 application. No target is automatically admitted, no next experiment was run, and no remote write was performed by this reviewer.
