> Public administrative derivative; scientific verdict/evidence unchanged. Original hash is recorded in ADMIN-DERIVATIVES.json.

# E01 synthetic pilot — independent source review

**SOURCE PASS**, restricted to freeze `f2987d9fc3b65ac435ec113257facd3d7ec00ed8b47af86a3eda3db06c2fb0c1`. No prepared module, cipher, synthetic batch or target test was executed. This is not an execution grant or target admission.

## Independence and fixed model

The reviewer authored `reference.py` before viewing production or the source-built bank. Its original SHA256 is `c14c162c499db89cee336cec84bd9c79335913811cd4809f91bef1199e20b3c5`; the pilot copy is byte-identical. The reference uses direct row.index/alphabet indexing, while production constructs forward/inverse dictionaries. Both update state to plaintext, not ciphertext. Starting in the same state, row permutations imply an inverse at each position and inductively identical states for every subsequent position. Empty messages, zero/tied rows and repetitions do not invalidate this argument.

The fixed real bank is generated solely from the named K1, K2-as-inscribed and K3 plaintext fields, uppercase ASCII filtering before adjacency, no section crossing, descending count then AZ ties. Start is terminal K3 Q. No correction, additional corpus, output alphabet choice, reset or state-dependent parameter fitting is present. The copied policy/bank bytes match admission artifacts. The pilot independently compares adjacent-pair counts against explicit overlapping startswith counts across all676 cells and26 rows; this review did not execute that comparison. Normalized lengths/hashes and finalQ are checked before cases are generated.

## Finite case contract

- All216 ABC permutation banks,3 starts and364 words of lengths0–5 give exactly235,872 exhaustive cases. Both encryptions and both inverses must agree.
- All676 real-bank single-symbol emissions/inverses are checked, together with stripping/no-cross-boundary, tied counts and zero-row fixtures.
- Six malformed cipher conditions ×two engines ×two directions give24 required ValueErrors; four malformed assertion conditions are separate. These tests are a stated finite set, not comprehensive fuzzing of all Python types.
- Fresh32-byte seed is drawn only after deterministic checks. Domain-separated labels initialize the disclosed Python PRNG; seed/version are retained, never resampled. Exactly64 each of positive, wrong-assertion twin, null, ciphertext-shuffle and source-shuffle produce320 opaque cases.
- The64 positives require exact97-letter recovery; each wrong twin changes exactly one asserted symbol and must reject while preserving its decoded plaintext. Null/shuffle survival is descriptive only, never a universal-rejection threshold or chance estimate.
- Source-shuffle diagnostics preserve per-section unigram counts and K3 terminalQ, with separate rebuilt rows for that diagnostic only. They are not model-selection candidates and cannot trigger target variants.
- Each decoder receives no asserted plaintext in its state-transition API. It decodes once continuously, then compatibility is checked. Sparse synthetic positions0,31,96 provide additional assertions without resets. Both full outputs must agree and re-encode exactly for every case.
- Cases and answers are retained separately, outputs written and hash-sealed before the answer file is read. This is procedural separation in one program, not cryptographic or observational blinding. The earlier raw-target exposure disclosure remains necessary and is retained in the source policy.

## Prior-art scope

The admission report's inverse proof is sound. The nonidentical J/Q emission rows agree at M but disagree at A, contradicting fixed-axis shift banks whose distinct shifts disagree everywhere. This does not cover arbitrary noncyclic or current-symbol selectors. The local208 initial-emission table separates all listed AZ/KA descriptions by inputs A and L; later state updates cannot erase a first-output mismatch. The reviewer checked that reasoning and table equations, not a fresh208-operator batch or external campaign. Missing adaptive/selector sources and unindexed/unpublished work remain unknown, not affirmative novelty evidence. Classical finite-state substitution principles are not newly invented. No historic creator-use evidence or K4 result follows from this source PASS.

## Execution and integrity review

All nine frozen dependency hashes, both executable hashes and exact original independent-reference bytes were authenticated in STATIC-READBACK.json; AST parsing only, no imports. `EXECUTION.json` pins the Python and timeout binaries, exact supervisor/worker argv and unique output/receipt paths. Grant supplies the final expected freeze SHA. The worker checks it and all source hashes before compiling authenticated production/reference bytes; `-I -B` avoids environment/local-bytecode import substitution. All frozen dependencies are rehashed before worker and supervisor acceptance. Runtime standard library/OS are trusted, not comprehensively hashed.

One worker is bounded at CPU soft57/hard58 and128MiB; supervisor soft2/hard60 and128MiB permits the child to lower its own hard limit. Timeout uses immediate KILL at120 seconds for the worker command. Supervisor startup and finite receipt tail sit outside that worker wall timer and are explicitly not claimed within120 total wall seconds. Cumulative worker/timeout and supervisor CPU must be below59 before receipt serialization, reserving1 nominal second for the small final tail. Nominal60 is permission, not a measured usage claim; OS/tool tails are not claimed measured. Internal worker timer excludes imports/startup and must not be added again to external child CPU.

The supervisor records worker nonzero exit, missing report and metadata parse errors as incomplete/failure; missing external completion or a killed supervisor cannot be called PASS from a worker file alone. Output/receipt absence was verified at review time. Worker creates its directory exclusively, supervisor checks absence, and parent must durably consume the single attempt before invoking. Local absence is not durable permission; no retry follows failure, timeout or uncertainty. The supervisor does not cryptographically attest its parent grant: actual retained parent authority and trusted tool completion are separate required evidence.

Concrete review findings—pre-authentication imports, missing exact binary/argv pins, timeout grace mismatch, missing supervisor caps, post-exit parsing receipt gap and imprecise CPU scope—were corrected before this freeze. Scientific production/reference functions and case definitions did not change. No failed experimental run occurred during those corrections.

## Decision and accounting

No remaining source blocker for this bounded synthetic pilot. A separate explicit parent one-shot grant is still required. After it, inspect actual external completion, unchanged sources, all result artifacts and counts independently; do not automatically admit a target. Output and external receipt were absent at final readback.

Metadata-only verification sampled0.062712696 CPU seconds within the existing60-second preparation/review allocation. Source reading, shell/startup/report overhead is unmeasured, not zero; no additional allocation was created. No remote write or scientific execution by this reviewer.
