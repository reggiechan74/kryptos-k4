import itertools,json,time,resource,hashlib
from clock import solve_case,encrypt,decrypt,primitive,schedule,seed_count
start=time.time(); cpu=time.process_time(); total=0; roundtrips=0
for p in range(2,5):
    keys=[k for k in itertools.product(range(2),repeat=p) if primitive(k)]
    for n in range(7):
        for c in itertools.product(range(2),repeat=n):
            c=list(c); truths=[(k,decrypt(c,k,2)) for k in keys]
            for k,pt in truths:
                assert encrypt(pt,k,2)==c; roundtrips+=1
            for mask in itertools.product((None,0,1),repeat=n):
                known=[(i,v) for i,v in enumerate(mask) if v is not None]
                truth=[(k,pt) for k,pt in truths if all(pt[i]==v for i,v in known)]
                result=solve_case({'ciphertext':c,'known':known,'periods':[p],'modulus':2})
                row=result['relations'][0]
                assert row['primitive_seed_count']==len(truth)
                plaintexts={tuple(pt) for k,pt in truth}
                assert row['plaintext_count']==len(plaintexts)
                assert result['union_status']==('empty' if not truth else 'unique' if len(plaintexts)==1 else 'ambiguous')
                for k in itertools.product(range(2),repeat=p):
                    represented=row['forced_consistent'] and primitive(k) and all(v is None or k[j]==v for j,v in enumerate(row['forced']))
                    assert represented==(k in [t[0] for t in truth])
                total+=1
# Cross-period exhaustive short unions, actual tuple sets.
for n in range(5):
    for c in itertools.product(range(2),repeat=n):
        for mask in itertools.product((None,0,1),repeat=n):
            known=[(i,v) for i,v in enumerate(mask) if v is not None]
            truth=set()
            for p in range(2,5):
                for k in itertools.product(range(2),repeat=p):
                    if not primitive(k): continue
                    pt=decrypt(c,k,2)
                    if all(pt[i]==v for i,v in known): truth.add(tuple(pt))
            r=solve_case({'ciphertext':list(c),'known':known,'periods':[2,3,4],'modulus':2})
            assert r['union_status']==('empty' if not truth else 'unique' if len(truth)==1 else 'ambiguous')
            assert all(tuple(w['plaintext']) in truth for w in r['witnesses'])
            total+=1
out={'status':'PASS','exact_cases':total,'roundtrips':roundtrips,'wall_seconds':time.time()-start,'cpu_seconds':time.process_time()-cpu,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'production_sha256':hashlib.sha256(open('clock.py','rb').read()).hexdigest()}
print(json.dumps(out,indent=2))
