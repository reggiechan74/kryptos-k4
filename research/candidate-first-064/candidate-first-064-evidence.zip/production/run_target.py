import datetime,json,hashlib,time,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(60,60)); resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
from clock import solve_case
ROOT=Path(__file__).parent; source=Path('/workspace/shared/k4-064-repo/data/k4.json')
assert hashlib.sha256((ROOT/'clock.py').read_bytes()).hexdigest()=='f4bd1ce5cfa9f4bb98261a0f003203b00e9d2a6cb042118ae2d7a093894d9681'
d=json.loads(source.read_text()); assert d['length']==97 and d['indexing']=='one-based inclusive'
known=[]
for crib in d['cribs']:
 assert crib['end']-crib['start']+1==len(crib['plaintext'])
 known.extend([[crib['start']-1+i,ord(ch)-65] for i,ch in enumerate(crib['plaintext'])])
case={'id':'K4-064-p5-only','ciphertext':[ord(ch)-65 for ch in d['ciphertext']],'known':known,'periods':[5],'modulus':26}
raw=json.dumps(case,sort_keys=True,indent=2)+'\n'; (ROOT/'target-input.json').write_text(raw)
freeze={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_path':'data/k4.json','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(raw.encode()).hexdigest(),'periods':[5],'approval':'Parent16:46:13UTC one production plus one independent reference; otherperiods inherited no rerun','limits':{'cpu_seconds':60,'memory_bytes':2*1024**3}}
(ROOT/'TARGET-FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();cpu=time.process_time();wall=time.monotonic()
r=solve_case(case)
out=json.dumps(r,sort_keys=True,indent=2)+'\n';(ROOT/'target-output.json').write_text(out)
receipt={'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'input_sha256':freeze['input_sha256'],'output_sha256':hashlib.sha256(out.encode()).hexdigest(),'source_sha256':freeze['source_sha256'],'status':'UNSAT_COMPLETE' if r['union_status']=='empty' else 'COMPATIBLE_EXACT','periods':[5],'new_target_evaluations':1,'other_periods_rerun':False}
(ROOT/'target-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt,indent=2))
