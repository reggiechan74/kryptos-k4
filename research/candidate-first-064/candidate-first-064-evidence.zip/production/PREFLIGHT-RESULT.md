# Study064 controlled preflight — target decision pending

Both independently authored exact solvers pass the frozen blind protocol. No target key differences, clue compatibility or target key search has been performed. Structural comparison against prior schedule banks is separate and its final admission review is pending.

## Verified controls
- Production development checks:169,516 exhaustive binary complete-relation/union cases,2,540 round trips;5.693 CPU seconds.
- Independent development checks:167,961 complete binary relations,1,119,740 brute primitive-seed comparisons,2,540 round trips;7.65 CPU seconds.
- Fresh third-worker mathematical audit:9,865 forced-pattern cases through period8, including9,799 nonempty binary witness checks;1.366 CPU seconds.
- Blind baseline:224 plants plus64 nulls, all seven periods searched for every case;21 separately frozen short/unused-coordinate diagnostics. All309 cases and2,163 exact period relations agree. Every planted full seed/plaintext retained.109 plants uniquely identified,115 ambiguous;64 nulls empty.14 diagnostics unique,7 ambiguous.367 production witnesses independently verified by re-encryption. No failures or post-reveal repairs.
- Exactness is established by independently constructed full primitive-seed-cylinder relations and existential projections, plus materialized complete tiny sets—not agreement of one selected key or count alone. Cross-period unions remain symbolic; no addition of overlapping counts.

## Freeze and provenance
Production clock hash `f4bd1ce5cfa9f4bb98261a0f003203b00e9d2a6cb042118ae2d7a093894d9681`; protocol `37d7b2636f5309187aa74714e5330b61cb50af639ef365d3d443abc1f7be5520`.
Independent source hash `ae56c839b757d9a2c5fd6d3c9d47c8f9603a50afe35334972a74fbcb58c41255`; generator `e3f5fa4816ad896ea3cc96c2907b9950ebcf59c9f90467925e412cf78acbeef6`.
Blind input hash `3bc8225b54d4a0ba282b682ac2b87d2a2bc3d0c5f985fb1562bb428ab5023bdc`; production output sealed16:41:50.667UTC hash `f119fe92aec94bbd608a5851125bfb3c5662ad67126a07c01ddbc8b154417f49`, before expected/truth reveal. Freeze records, generator seed, raw inputs/outputs and audit scripts retained; no unseen tests silently replaced.

## Current prior gate finding (under final audit)
There is no full-message equivalent clock in the inspected reconstructed banks. Local044 completed AZ/additive ordinary-period negative receipts can transfer crib-only exclusion to six recurrence periods2,3,4,6,7,8, without rerunning their compatibility. Period5 currently has only strictly weaker, low-information historical crib supermodels that were threshold-skipped; this does not by itself prove its new full-clock constraints were tried. The parent and independent admission reviewer are inspecting exact semantics before deciding eligibility. Missing evidence is not global novelty clearance. Original/corrected E122 banks remain separate; corrections alone do not prove historical execution.

## Pending decision
Request parent approval only after the structural receipt audit and fresh mathematical signoff complete. Any target stage would be compatibility/exclusion only for a specifically admitted residual domain, never guaranteed recovery; no rule changes, relaxed gates, target retuning or paid services. Preserve all frozen evidence and readable ledger layout at closeout.
