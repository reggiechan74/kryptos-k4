import json,time,resource,datetime,hashlib
from pathlib import Path
from clock import solve_case
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); wall=time.monotonic(); cpu=time.process_time()
source=Path('/workspace/shared/k4-064-independent/blind-input.json')
cases=json.loads(source.read_text()); out=[solve_case(c) for c in cases]
p=Path('blind-output.json'); p.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
receipt={'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path('clock.py').read_bytes()).hexdigest(),'cases':len(cases),'status':'complete','target':False}
Path('blind-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
