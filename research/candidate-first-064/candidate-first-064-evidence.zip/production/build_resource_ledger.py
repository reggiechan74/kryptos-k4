import json,datetime,hashlib
from pathlib import Path
base=Path('/workspace/shared')
entries=[('production','tiny-result.json'),('production','FINAL-VALIDATION.json'),('production','STATIC-VALIDATION.json'),('production','blind-receipt.json'),('independent','tiny-result.json'),('independent','BANK-SEAL.json'),('independent','AUDIT-RESULT.json'),('independent','TARGET-AUDIT.json'),('prior','structural-results.json'),('prior','structural-validation.json'),('prior','receipt-review-resources.json'),('audit','counts-result.json'),('audit','benchmark-verification.json')]
rows=[]
for group,name in entries:
 p=base/('k4-064-'+group)/name
 d=json.loads(p.read_text());rows.append({'phase':group+'/'+name,'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cpu_seconds':d['cpu_seconds'],'peak_rss_kib':d['maxrss_kib']})
for group,name in [('production','target-receipt.json'),('independent','TARGET-RECEIPT.json'),('audit','TARGET-AUDIT.json')]:
 p=base/('k4-064-'+group)/name
 if p.exists():
  d=json.loads(p.read_text()); rows.append({'phase':group+'/'+name,'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cpu_seconds':d['cpu_seconds'],'peak_rss_kib':d['maxrss_kib']})
result={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'measured_cpu_seconds':sum(r['cpu_seconds'] for r in rows),'maximum_single_process_rss_kib':max(r['peak_rss_kib'] for r in rows),'unmetered_tooling_and_reading_allowance_cpu_seconds':600,'allowance_is_not_measured_usage':True,'combined_cpu_budget_seconds':28800,'combined_memory_budget_gib':8,'notes':['Duplicate run.stdout and release receipts refer to same executions and are not double-counted.','Allowance conservatively budgets shell staging, hashing, source reads and orchestration; remote connector service CPU is unobservable.','Independent parent structural-review resource usage and final regression/publication work reported separately if available.','No paid compute, security change, external checker or third-party program execution.']}
(base/'k4-064-production'/'RESOURCE-LEDGER.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['measured_cpu_seconds'])
