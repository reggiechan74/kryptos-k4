"""Read-only artifact/certificate verification. Does not import or call either solver."""
import json,hashlib,pathlib,time,resource,datetime,subprocess
start=time.process_time();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
P=pathlib.Path('/workspace/shared/k4-064-production');I=pathlib.Path('/workspace/shared/k4-064-independent');R=pathlib.Path('/workspace/shared/k4-064-repo');A=pathlib.Path(__file__).parent
load=lambda p:json.loads(p.read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=load(R/'data/k4.json');pf=load(P/'TARGET-FREEZE.json');rf=load(I/'TARGET-FREEZE.json');ad=load(P/'ADMISSION-FREEZE.json');pr=load(P/'target-receipt.json');rr=load(I/'TARGET-RECEIPT.json')
for path,want in ad['files'].items():assert h(pathlib.Path(path))==want
for root in [P,I]:
 f=load(root/'FREEZE.json')
 for name,want in f['files'].items():assert h(root/name)==want
for name,want in rf['local_hashes'].items():assert h(I/name)==want
assert ad['frozen_utc']<'2026-10-31T16:46:13+00:00'<pf['frozen_utc']<pr['start_utc']<pr['end_utc']
assert '2026-10-31T16:46:13+00:00'<rf['frozen_utc']<rr['started_utc']<rr['ended_utc']
assert h(R/'data/k4.json')==pf['source_sha256']==rf['canonical_source_sha256']
# Read committed baseline bytes; no cipher execution.
base=subprocess.check_output(['git','show','HEAD:data/k4.json'],cwd=R)
assert hashlib.sha256(base).hexdigest()==h(R/'data/k4.json')
assert d['length']==len(d['ciphertext'])==97 and d['indexing']=='one-based inclusive'
known=[]
for x in d['cribs']:
 assert x['end']-x['start']+1==len(x['plaintext'])
 known.extend([[x['start']-1+j,ord(v)-65] for j,v in enumerate(x['plaintext'])])
for root,receipt,freeze in [(P,pr,pf),(I,rr,rf)]:
 c=load(root/'target-input.json');o=load(root/'target-output.json')
 assert c['periods']==[5] and c['modulus']==26 and c['known']==known
 assert c['ciphertext']==[ord(v)-65 for v in d['ciphertext']]
 assert h(root/'target-input.json')==receipt['input_sha256']
 assert h(root/'target-output.json')==receipt['output_sha256']
 assert len(o['relations'])==1 and o['relations'][0]['period']==5
 assert o['union_status']=='empty' and o['witnesses']==[]
 assert o['relations'][0]['primitive_seed_count']==o['relations'][0]['plaintext_count']==0
 assert freeze['limits']['cpu_seconds']==60
 assert list(v for k,v in freeze['limits'].items() if k!='cpu_seconds')==[2*1024**3]
pout=load(P/'target-output.json')['relations'][0];rout=load(I/'target-output.json')['relations'][0]
for field in ['period','schedule','forced','used','proper_divisors','primitive_seed_count','plaintext_count']:assert pout[field]==rout[field]
assert not pout['forced_consistent'] and not pout['consistent'] and not rout['consistent']
# Verify one contradiction from retained schedule and canonical inputs; no schedule generation or key search.
c=load(P/'target-input.json')['ciphertext'];groups={};certificate=None
for i,v in known:
 q=pout['schedule'][i];value=(c[i]-v)%26
 if q in groups and groups[q]['required_key_value']!=value:
  certificate={'residue':q,'first':groups[q],'second':{'index_zero_based':i,'ciphertext_rank':c[i],'plaintext_rank':v,'required_key_value':value}};break
 groups[q]={'index_zero_based':i,'ciphertext_rank':c[i],'plaintext_rank':v,'required_key_value':value}
assert certificate is not None
trans=load(pathlib.Path('/workspace/shared/k4-064-prior/local-negative-transfers.json'))
assert h(R/trans['receipt_path'])==trans['sha256']
assert sorted(set(x['recurrence_period'] for x in trans['transfers']))==[2,3,4,6,7,8]
for x in trans['transfers']:
 assert x['prior_outcome']['minimum_substitutions']>0
 assert x['prior_outcome']['mode']=='periodic' and x['prior_outcome']['alphabet']=='AZ'
 assert x['prior_outcome']['q']==26 and x['prior_outcome']['sigma']==x['prior_outcome']['tau']==1
out={'status':'PASS','scope':'nonsearch target artifact and contradiction certificate audit','parent_approval_utc':'2026-10-31T16:46:13+00:00','evaluated_periods':[5],'inherited_periods':[2,3,4,6,7,8],'new_solver_runs_by_auditor':0,'complete_relation':'empty in both independently sealed outputs','source_and_freeze_hashes_verified':True,'contradiction_certificate':certificate,'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'started_utc':utc,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(A/'TARGET-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
