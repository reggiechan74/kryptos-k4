import json,hashlib,sys,pathlib,time,resource,datetime,collections
start=time.process_time(); P=pathlib.Path('/workspace/shared/k4-064-production');I=pathlib.Path('/workspace/shared/k4-064-independent')
def load(p):return json.loads(p.read_text())
for root in (P,I):
 freeze=load(root/'FREEZE.json')
 for name,want in freeze['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==want
seal=load(I/'BANK-SEAL.json')
for name,want in seal['hashes'].items():assert hashlib.sha256((I/name).read_bytes()).hexdigest()==want
receipt=load(P/'blind-receipt.json');assert hashlib.sha256((P/'blind-output.json').read_bytes()).hexdigest()==receipt['output_sha256']
assert load(P/'FREEZE.json')['recorded_utc']<seal['started_utc']<seal['ended_utc']<receipt['start_utc']<receipt['end_utc']<load(I/'AUDIT-RESULT.json')['started_utc']
sys.path.insert(0,str(I));import reference as r
cases=load(I/'blind-input.json');outs=load(P/'blind-output.json');expect=load(I/'expected.json');truth=load(I/'secret-truth.json');assert len(cases)==len(outs)==len(expect)==len(truth)==309
stat=collections.Counter();witnesses=0
for c,o,e,t in zip(cases,outs,expect,truth):
 assert c['id']==o['id']==e['id']==t['id']
 assert c['periods']==list(range(2,9))
 assert len(o['relations'])==len(e['relations'])==7
 for a,b in zip(o['relations'],e['relations']):
  assert all(a[k]==b[k] for k in ('period','schedule','forced','used','proper_divisors','primitive_seed_count','plaintext_count'))
  assert a['forced_consistent']==b['consistent'] and a['consistent']==bool(b['primitive_seed_count'])
 assert o['union_status']==e['union_status']
 assert len(o['witnesses'])=={'empty':0,'unique':1,'ambiguous':2}[o['union_status']]
 assert len({tuple(x['plaintext']) for x in o['witnesses']})==len(o['witnesses'])
 for w in o['witnesses']:
  assert r.encrypt(w['plaintext'],w['key'])==c['ciphertext']
  assert r.accepts_seed(e['relations'][w['period']-2],w['key'])
  assert all(w['plaintext'][i]==v for i,v in c['known']);witnesses+=1
 if t['truth']:
  tr=t['truth'];stat[(tr['period'],tr['mask_style'])]+=1
  assert r.accepts_seed(e['relations'][tr['period']-2],tr['key'])
  assert r.encrypt(tr['plaintext'],tr['key'])==c['ciphertext']
assert len(stat)==28 and set(stat.values())=={8}
print(json.dumps({'status':'PASS','cases':309,'exact_relations':2163,'witnesses':witnesses,'plant_strata':28,'plants_per_stratum':8,'freeze_order_verified':True,'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
