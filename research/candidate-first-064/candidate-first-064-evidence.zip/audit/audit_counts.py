import sys,itertools,time,json,resource,hashlib,datetime
sys.path.insert(0,'/workspace/shared/k4-064-production')
import clock
start=time.process_time(); cases=0; witness_checks=0
# Independent primitive definition: no nonidentity cyclic rotation fixes vector.
def full_orbit(k):
    return all(k != k[j:]+k[:j] for j in range(1,len(k)))
for p in range(2,9):
    seeds=[k for k in itertools.product(range(2),repeat=p) if full_orbit(k)]
    for f in itertools.product((None,0,1),repeat=p):
        truth=[k for k in seeds if all(v is None or k[j]==v for j,v in enumerate(f))]
        assert clock.seed_count(f,2)==len(truth),(p,f)
        w=clock.witness(f,2)
        assert (w is None)==(not truth)
        if w is not None: assert tuple(w)==min(truth)
        cases+=1; witness_checks+=w is not None
# AX values outside binary range exercise residue-independent counting.
for p in range(2,9):
    for f in ([None]*p,[25]*p,list(range(p)),[None]+[25]*(p-1)):
        w=clock.witness(f,26)
        assert (clock.seed_count(f,26)>0)==(w is not None)
        if w is not None:
            assert full_orbit(w) and all(v is None or w[j]==v for j,v in enumerate(f))
        cases+=1
out={'status':'PASS','cases':cases,'binary_nonempty_witness_checks':witness_checks,'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_sha256':hashlib.sha256(open(clock.__file__,'rb').read()).hexdigest(),'oracle':'full cyclic orbit, exhaustive binary forced patterns p2..8, lexicographic brute witness'}
print(json.dumps(out,indent=2))
