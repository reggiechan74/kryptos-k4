import itertools,json,time,resource,hashlib
from pathlib import Path
import structural_audit as S
start=time.process_time();count=0
# Independent relation oracle: compare complete binary-valued compatible vectors.
for n in range(6):
 partitions=sorted({S.canon(v) for v in itertools.product(range(n or 1),repeat=n)})
 models={a:{v for v in itertools.product(range(2),repeat=n) if all(a[i]!=a[j] or v[i]==v[j] for i in range(n) for j in range(n))} for a in partitions}
 for a in partitions:
  for b in partitions:
   x=models[b]<=models[a];y=models[a]<=models[b]
   expect='equal' if x and y else 'old_contains' if x else 'old_contained' if y else 'nonnested'
   assert S.relation(a,b)==expect;count+=1
# Independently recursive schedule of C only; no target key/known letter arithmetic.
for p in range(2,9):
 last={};q=0;out=[]
 for i,c in enumerate(S.C):
  out.append(q);q=(q+(i-last[c] if c in last else 1))%p;last[c]=i
 assert S.canon(out)==S.schedule(p)
# Published generator-count cross-checks require no key/crib-value calculation.
r=json.loads((S.ROOT/'structural-results.json').read_text())
assert r['summary']['E122_numeric']['crib_unique']==21627
assert r['summary']['E122_signal']['crib_unique']==878
assert sum(v['raw'] for k,v in r['summary'].items() if k.startswith('Barney'))==48411
out={'binary_complete_partition_relation_cases':count,'candidate_recursive_telescoped_agreement':7,'published_count_checks':3,'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'all_passed':True}
(S.ROOT/'structural-validation.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
