"""Read completed historical outcomes and reconstruct structural relations only."""
import json,hashlib,time,resource
from pathlib import Path
import structural_audit as S
R=Path(__file__).parent;start=time.time();cpu=time.process_time()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=S.REPO/'results/MINIMUM-REPAIR-044-ORIGINAL.json';prior=json.loads(receipt.read_text());computed=json.loads((R/'structural-results.json').read_text())
rows=[{k:x[k] for k in ['mode','lag_or_period','alphabet','q','sigma','tau','minimum_substitutions','free_key_symbols']} for x in prior['rows'] if x['mode']=='periodic' and x['alphabet']=='AZ' and x['sigma']==1 and x['tau']==1]
transfers=[]
for m in computed['containing_matches']:
 if m['bank']=='ordinary' and m['view']=='crib':
  oldp=m['meta'][1]
  row=next((x for x in rows if x['lag_or_period']==oldp),None)
  if row and row['minimum_substitutions']>0:
   transfers.append({'recurrence_period':m['period'],'old_period':oldp,'relation':'strict crib-only containment','old_checks':m['checks'],'prior_outcome':row,'old_partition':m['partition'],'new_partition':computed['candidate_partitions'][str(m['period'])]['crib']})
(R/'local-negative-transfers.json').write_text(json.dumps({'receipt_path':str(receipt.relative_to(S.REPO)),'sha256':sha(receipt),'receipt_id':prior['id'],'started_at_utc':prior['started_at_utc'],'finished_at_utc':prior['finished_at_utc'],'transfers':transfers,'no_new_compatibility_computation':True},indent=2)+'\n')
a=S.schedule(5);ac=S.canon([a[i] for i in S.POS]);p5=[]
for bank,meta,lab,partial in S.banks():
 full=None if partial else S.canon(lab);crib=S.canon(lab if partial else [lab[i] for i in S.POS]);rel=S.relation(crib,ac)
 if rel not in ['old_contains','equal']:continue
 checks=24-len(set(crib))
 entry={'bank':bank,'parameters':meta,'crib_relation':rel,'crib_checks':checks,'crib_partition':crib,'full_relation':'not_defined_by_published_partial_mask' if partial else S.relation(full,a),'full_partition':full}
 if bank=='ordinary':
  row=next((x for x in rows if x['lag_or_period']==meta[1]),None)
  entry['retained_result']='zero-repair underconstrained' if row and row['minimum_substitutions']==0 else 'message-length free-key tautology' if meta[1]==97 else 'unknown'
  entry['source']='local MINIMUM-REPAIR-044' if row else 'structural no-equalities proof'
 elif bank.startswith('Barney'):
  entry['retained_result']='SKIPPED by MIN8 original AND MIN6 clue-alphabet thresholds' if checks<6 else 'needs result review'
  entry['source']='pinned scripts/fe_common.py Engine; results/fe_results.out'
 elif bank.startswith('E122'):
  entry['retained_result']='SKIPPED by fixed-table MIN6 and arbitrary-alphabet MIN10 thresholds' if checks<6 else 'needs result review'
  entry['source']='pinned src/s93_interrupted.py and s93b_interrupted_arb.py; corrected RB source separately'
 p5.append(entry)
from collections import Counter
summary={'count':len(p5),'counts_by_bank':dict(Counter(x['bank'] for x in p5)),'counts_by_checks':dict(Counter(x['crib_checks'] for x in p5)),'counts_by_full_relation':dict(Counter(x['full_relation'] for x in p5)),'exact_crib_equal':sum(x['crib_relation']=='equal' for x in p5),'exact_full_equal':sum(x['full_relation']=='equal' for x in p5),'all_nonordinary_containers_documentedly_skipped':all(x['crib_checks']<6 for x in p5 if x['bank']!='ordinary')}
(R/'p5-all-containing-domains.json').write_text(json.dumps({'summary':summary,'domains':p5,'no_new_compatibility_computation':True},indent=2)+'\n')
(R/'receipt-review-resources.json').write_text(json.dumps({'cpu_seconds':time.process_time()-cpu,'elapsed_seconds':time.time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
print(json.dumps(summary,indent=2));print('transfer periods',sorted({x['recurrence_period'] for x in transfers}))
