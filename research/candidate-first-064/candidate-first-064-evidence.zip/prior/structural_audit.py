"""Independent structural reconstruction; no external imports, key fitting or decryptions."""
import ast,bisect,hashlib,itertools,json,resource,time
from pathlib import Path
ROOT=Path(__file__).parent
REPO=Path('/workspace/shared/k4-ledger-reorg')
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; KA='KRYPTOSABCDEFGHIJLMNQUVWXZ'
POS=list(range(21,34))+list(range(63,74))
C=json.loads((REPO/'data/k4.json').read_text())['ciphertext']
# Parse selected literals, never evaluate executable expressions/import the source.
def literal(name,assignment):
    tree=ast.parse((ROOT/name).read_text())
    nodes=[n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==assignment for t in n.targets)]
    assert len(nodes)==1
    return ast.literal_eval(nodes[0])
def digit_tokens():
    tree=ast.parse((ROOT/'s93.py').read_text()); n=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DIG' for t in n.targets))
    assert isinstance(n,ast.Call) and not n.args and not n.keywords and isinstance(n.func,ast.Attribute) and n.func.attr=='split'
    return ast.literal_eval(n.func.value).split()
def canon(lab):
    seen={}; out=[]
    for i,x in enumerate(lab):
        if x is None: x=('unconstrained',i)
        out.append(seen.setdefault(x,len(seen)))
    return tuple(out)
def schedule(p):
    first={}; last={}; out=[]
    for i,c in enumerate(C):
        out.append(sum(1+last[x]-first[x] for x in first)%p)
        first.setdefault(c,i);last[c]=i
    return canon(out)
def refines(a,b):
    # Every equality in a is also in b.
    seen={}
    for x,y in zip(a,b):
        if x in seen and seen[x]!=y:return False
        seen[x]=y
    return True
def relation(old,new):
    x=refines(old,new); y=refines(new,old)
    return 'equal' if x and y else 'old_contains' if x else 'old_contained' if y else 'nonnested'
def numeric(seqs,bank):
    for name,D in seqs.items():
        for L in range(3,17):
            for lead in (0,1):
                for phi in range(sum(D)):
                    bounds=[];t=-phi;k=0
                    while t<110:bounds.append(t);t+=D[k%len(D)];k+=1
                    indices=[bisect.bisect_right(bounds,i+lead)-1 for i in range(97)]
                    yield bank,('R1',name,L,lead,phi),[(i+lead-bounds[k])%L for i,k in enumerate(indices)],False
                    yield bank,('R2',name,L,lead,phi),[k%L for k in indices],False
                for ph in range(len(D)):
                    cum=[0]
                    for i in range(110):cum.append(cum[-1]+D[(i+ph)%len(D)])
                    yield bank,('R3',name,L,lead,ph),[cum[i+lead]%L for i in range(97)],False

def banks():
    for L in range(1,98):yield 'ordinary',('period',L),[i%L for i in range(97)],False
    for L in range(1,13):
        for b in range(97):yield 'shared_reset',('reset',L,b),[(i if b==0 or i<b else i-b)%L for i in range(97)],False
    seqs={s:[10 if c=='0' else int(c) for c in s] for s in digit_tokens()};seqs.update(literal('s93.py','WORDLEN'))
    seqs.update({k+'r':v[::-1] for k,v in list(seqs.items())})
    yield from numeric(seqs,'E122_numeric')
    rank=[6,1,4,3,5,7,8,2,9,10]
    yield from numeric({'PALIMPSEST_fixed':rank,'PALIMPSEST_fixed_reverse':rank[::-1]},'E122_corrected_numeric')
    sets={c:{c} for c in AZ};sets.update({'KRYPTOS':set('KRYPTOS'),'VOWEL':set('AEIOU'),'AM':set(AZ[:13]),'NZ':set(AZ[13:]),'KA13':set(KA[:13]),'KA13b':set(KA[13:]),'X':{'X'},'W':{'W'}})
    for name,T in sets.items():
        last=-1; count=0; ra=[];rb=[];rc=[];rbfix=[]
        for i,c in enumerate(C):
            ra.append(i-last-1);rc.append(count)
            rb.append(0 if c in T else i-last)
            rbfix.append(0 if c in T else i-max(last,0))
            if c in T:last=i;count+=1
        for L in range(2,27):
            for kind,seq in [('RA',ra),('RB',rb),('RC',rc)]:yield 'E122_signal',(kind,name,L),[v%L for v in seq],False
            yield 'E122_corrected_RB',('RBfixed',name,L),[v%L for v in rbfix],False
    LS=list(range(1,27))+[None]
    for T in list(itertools.combinations(AZ,1))+list(itertools.combinations(AZ,2)):
        last=-1;ci=co=0;seqs={k:[] for k in ['restart_after','restart_at','advance','pause']}
        for i,c in enumerate(C):
            seqs['restart_after'].append(i-last-1);seqs['advance'].append(ci);seqs['pause'].append(co)
            if c in T:last=i;ci+=1
            else:co+=1
            seqs['restart_at'].append(i-last if last>=0 else i)
        for kind,seq in seqs.items():
            for L in LS:yield 'Barney_ct',(kind,''.join(T),L),[v if L is None else v%L for v in seq],False
    # Historical plaintext strings ONLY construct prior masks, never fit target key values.
    cribs=literal('barney.py','CRIBS'); letters=sorted(set(''.join(w for s,w in cribs)))
    for t in letters:
        idx={}
        for s,w in cribs:
            last=None
            for j,ch in enumerate(w):
                idx[s+j]=None if last is None else s+j-last-1
                if ch==t:last=s+j
        for L in LS:yield 'Barney_pt',('restart',t,L),[None if idx[p] is None else idx[p] if L is None else idx[p]%L for p in POS],True
    for t in letters+['*']:
        for kind in ['advance','pause']:
            if t=='*' and kind=='advance':continue
            rel={}
            for s,w in cribs:
                n=0
                for j,ch in enumerate(w):
                    rel[s+j]=n;n+=int(ch==t) if kind=='advance' else int(ch!=t)
            for L in range(1,27):
                for delta in range(L):yield 'Barney_pt',(kind,t,L,delta),[(rel[p]+(delta if p>=63 else 0))%L for p in POS],True
    for b1,b2 in itertools.product([[0,4,9],[0,4],[0]],[[0,6],[0]]):
        for known1,known2 in itertools.product([True,False],repeat=2):
            idx={}
            for (s,w),bounds,known in zip(cribs,[b1,b2],[known1,known2]):
                for j in range(len(w)):
                    b=max(x for x in bounds if x<=j);idx[s+j]=None if b==0 and not known else j-b
            for L in LS:yield 'Barney_word',(b1,b2,known1,known2,L),[None if idx[p] is None else idx[p] if L is None else idx[p]%L for p in POS],True
    starts=literal('barney.py','LINE_STARTS')
    seq=[i-max(b for b in starts if b<=i) for i in range(97)]
    for L in LS:yield 'Barney_line',('line',L),[v if L is None else v%L for v in seq],False

def run():
    start=time.time();cpu=time.process_time(); candidate={p:schedule(p) for p in range(2,9)}
    summary={};unique={};matches=[];h=hashlib.sha256()
    for bank,meta,lab,partial in banks():
        full=None if partial else canon(lab);crib=canon(lab if partial else [lab[i] for i in POS]);checks=24-len(set(crib))
        h.update(json.dumps([bank,meta,full,crib],separators=(',',':')).encode()+b'\n')
        if bank not in summary:
            summary[bank]={'raw':0,'crib_unique':0,'full_unique':0,'comparisons':{str(p):{'full':{},'crib':{}} for p in candidate}};unique[bank]={'crib':set(),'full':set()}
        summary[bank]['raw']+=1;unique[bank]['crib'].add(crib)
        if full is not None:unique[bank]['full'].add(full)
        for p,new in candidate.items():
            for view,old,tar in [('full',full,new),('crib',crib,canon([new[i] for i in POS]))]:
                if old is None:continue
                rel=relation(old,tar);d=summary[bank]['comparisons'][str(p)][view];d[rel]=d.get(rel,0)+1
                if rel in ('equal','old_contains'):matches.append({'bank':bank,'meta':meta,'period':p,'view':view,'relation':rel,'checks':checks,'partition':old})
    for bank in summary:
        for view in ['full','crib']:summary[bank][view+'_unique']=len(unique[bank][view])
    data={'target_ciphertext_sha256':hashlib.sha256(C.encode()).hexdigest(),'crib_positions_zero_based':POS,'candidate_partitions':{p:{'full':v,'crib':canon([v[i] for i in POS])} for p,v in candidate.items()},'summary':summary,'raw_bank_sha256':h.hexdigest(),'containing_matches':matches,'cpu_seconds':time.process_time()-cpu,'elapsed_seconds':time.time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'no_key_or_compatibility_computation':True}
    (ROOT/'structural-results.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:v for k,v in data.items() if k not in ['containing_matches','candidate_partitions']},indent=2))
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(3600,3600));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));run()
