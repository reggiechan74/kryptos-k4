"""Nonsearch comparison of already sealed target receipts and contradiction witness."""
import pathlib,json,hashlib,datetime,time,resource
start=time.process_time();r=pathlib.Path(__file__).resolve().parent;p=r.parent/'k4-064-production'
a=json.load(open(r/'target-output.json'));b=json.load(open(p/'target-output.json'));inp=json.load(open(r/'target-input.json'));pinp=json.load(open(p/'target-input.json'))
for k in ['ciphertext','known','periods','modulus']:assert inp[k]==pinp[k]
assert inp['periods']==[5];assert len(a['relations'])==len(b['relations'])==1
ar=a['relations'][0];br=b['relations'][0]
for k in ['period','forced','schedule','used','proper_divisors','primitive_seed_count','plaintext_count']: assert ar[k]==br[k]
assert ar['consistent']==br['forced_consistent']==False
assert a['union_status']==b['union_status']=='empty'
assert a['witnesses']==b['witnesses']==[]
# Derive a checkable contradiction from retained schedule, without solver rerun.
seen={};conflicts=[]
for i,v in inp['known']:
 q=ar['schedule'][i];required=(inp['ciphertext'][i]-v)%26
 row={'one_based_position':i+1,'ciphertext_rank':inp['ciphertext'][i],'plaintext_rank':v,'key_residue':q,'required_key_rank':required}
 if q in seen and seen[q]['required_key_rank']!=required:conflicts.append([seen[q],row])
 else:seen[q]=row
assert conflicts
result={'status':'PASS','audit_kind':'nonsearch sealed-output and direct contradiction check','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'periods':[5],'input_agreement':True,'complete_relation_agreement':True,'first_contradiction':conflicts[0],'independent_output_sha256':hashlib.sha256((r/'target-output.json').read_bytes()).hexdigest(),'production_output_sha256':hashlib.sha256((p/'target-output.json').read_bytes()).hexdigest(),'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(r/'TARGET-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
