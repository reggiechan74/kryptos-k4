import pathlib,json,hashlib,datetime
root=pathlib.Path(__file__).resolve().parent;checked=[]
for name,h in json.load(open(root/'FREEZE.json'))['files'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h;checked.append(name)
prod=root.parent/'k4-064-production'
for name,h in [('clock.py','f4bd1ce5cfa9f4bb98261a0f003203b00e9d2a6cb042118ae2d7a093894d9681'),('PROTOCOL.md','37d7b2636f5309187aa74714e5330b61cb50af639ef365d3d443abc1f7be5520')]:
 assert hashlib.sha256((prod/name).read_bytes()).hexdigest()==h;checked.append('production/'+name)
for name,h in json.load(open(root/'BANK-SEAL.json'))['hashes'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h;checked.append(name)
result=dict(status='PASS',verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=checked)
(root/'FREEZE-VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
