import json,pathlib,hashlib,collections,time,resource,datetime
import reference as r
ROOT=pathlib.Path(__file__).resolve().parent
start=time.process_time();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
inputs=json.load(open(ROOT/'blind-input.json'));expected=json.load(open(ROOT/'expected.json'));truth=json.load(open(ROOT/'secret-truth.json'))
path=ROOT.parent/'k4-064-production/blind-output.json';raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='f119fe92aec94bbd608a5851125bfb3c5662ad67126a07c01ddbc8b154417f49'
actual=json.loads(raw);assert len(actual)==len(expected)==len(inputs)==309
stats=collections.Counter();rows_checked=0;certificates=0;raw_diffs=[]
for case,a,e,t in zip(inputs,actual,expected,truth):
 assert case['id']==a['id']==e['id']==t['id']
 assert a['union_status']==e['union_status']
 kind=case['id'].split('-')[0];stats[kind+'_'+a['union_status']]+=1
 for ar,er in zip(a['relations'],e['relations']):
  for field in ['period','schedule','forced','used','proper_divisors','primitive_seed_count','plaintext_count']:
   assert ar[field]==er[field],(case['id'],field,ar[field],er[field])
  assert ar['forced_consistent']==er['consistent']
  assert ar['consistent']==bool(er['primitive_seed_count'])
  rows_checked+=1
 # Independent certificate validation does not require same seed selection.
 assert len(a['witnesses'])==min(2, {'empty':0,'unique':1,'ambiguous':2}[a['union_status']])
 assert len({tuple(w['plaintext']) for w in a['witnesses']})==len(a['witnesses'])
 for w in a['witnesses']:
  assert r.primitive(w['key']) and len(w['key'])==w['period']
  assert r.encrypt(w['plaintext'],w['key'])==case['ciphertext']
  assert all(w['plaintext'][i]==v for i,v in case['known'])
  row=e['relations'][w['period']-2]
  assert r.accepts_seed(row,w['key']);certificates+=1
 if t['truth']:
  tr=t['truth'];row=e['relations'][tr['period']-2]
  assert r.accepts_seed(row,tr['key'])
  assert r.decrypt(case['ciphertext'],tr['key'])==tr['plaintext']
  stats['plants_retained']+=1
result=dict(status='PASS',cases=len(actual),period_relations=rows_checked,independent_certificates=certificates,counts=dict(stats),complete_set_basis='same independently constructed exact cylinder-minus-period-subspaces and existential projection; tiny checks materialize complete sets',field_semantics='reference consistent = forced consistency; production forced_consistent same; production consistent = positive primitive seed count',source_review='recursive clock vs independent span sum; divisor recursion vs independent DSU inclusion-exclusion; all frozen sources unchanged',cpu_seconds=time.process_time()-start,maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,started_utc=utc,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(ROOT/'AUDIT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
