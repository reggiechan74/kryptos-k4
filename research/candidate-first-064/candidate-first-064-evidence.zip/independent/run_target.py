"""ONE p5-only target evaluation under explicit parent authorization."""
import json,pathlib,hashlib,time,resource,datetime
ROOT=pathlib.Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
freeze=json.load(open(ROOT/'TARGET-FREEZE.json'))
for name,h in freeze['local_hashes'].items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
import reference
case=json.load(open(ROOT/'target-input.json'));assert case['periods']==[5]
start=time.process_time();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
out=reference.solve_case(case)
raw=(json.dumps(out,sort_keys=True,indent=2)+'\n').encode();(ROOT/'target-output.json').write_bytes(raw)
receipt={'started_utc':utc,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_seconds':time.process_time()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'periods_evaluated':[5],'output_sha256':hashlib.sha256(raw).hexdigest(),'status':'completed','source_sha256':freeze['local_hashes']['reference.py'],'input_sha256':freeze['local_hashes']['target-input.json']}
(ROOT/'TARGET-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(out['union_status'])
