import itertools,json,time,resource,datetime
import reference as r
start=time.process_time();utc=datetime.datetime.now(datetime.timezone.utc).isoformat();cases=seeds=roundtrips=0
for n in range(7):
 for ct in itertools.product(range(2),repeat=n):
  c=list(ct)
  truths={}
  for p in range(2,5):
   truths[p]=[(key,tuple(r.decrypt(c,key,2))) for key in itertools.product(range(2),repeat=p) if r.primitive(key)]
   for key,pt in truths[p]:
    assert r.encrypt(list(pt),key,2)==c; roundtrips+=1
  # Each coordinate absent, known 0, or known 1.
  for assignments in itertools.product((None,0,1),repeat=n):
   known=[(i,v) for i,v in enumerate(assignments) if v is not None];union=set();rows=[]
   for p in range(2,5):
    row=r.solve(c,known,p,2);rows.append(row)
    exact={(k,pt) for k,pt in truths[p] if all(pt[i]==v for i,v in known)}
    represented={(k,pt) for k,pt in truths[p] if r.accepts_seed(row,k)}
    assert represented==exact
    pts={pt for k,pt in exact};union.update(pts)
    assert row['primitive_seed_count']==len(exact)
    assert row['plaintext_count']==len(pts)
    ws=r.witnesses(c,row,2)
    assert len(ws)==min(2,len(pts))
    assert all(tuple(w['plaintext']) in pts for w in ws)
    assert len({tuple(w['plaintext']) for w in ws})==len(ws)
    cases+=1;seeds+=len(truths[p])
   got=[]
   for row in rows:
    got.extend(tuple(w['plaintext']) for w in r.witnesses(c,row,2))
   assert min(2,len(set(got)))==min(2,len(union))
# independent corner truths
assert r.primitive([0,1,0]) # finite-prefix period2 is not a cyclic divisor of3
assert not r.primitive([0,1,0,1])
assert not r.primitive([13]*8)
assert r.schedule([0,1,0,2,0],3)==[0,1,2,1,2]
for c in ([],[0],[0]*97,list(range(26))*4,[0,1,0,0,1,2,1]):
 for p in range(2,9):
  key=list(range(p));plain=r.decrypt(c,key)
  assert r.encrypt(plain,key)==c
  assert r.schedule([(x+7)%26 for x in c],p)==r.schedule(c,p)
  for known in ([],list(enumerate(plain))):
   row=r.solve(c,known,p);ws=r.witnesses(c,row)
   assert all(r.encrypt(w['plaintext'],w['seed'])==c for w in ws)
result=dict(status='PASS',tiny_relations=cases,brute_seed_comparisons=seeds,roundtrips=roundtrips,cpu_seconds=time.process_time()-start,maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,started_utc=utc,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
print(json.dumps(result,indent=2))
