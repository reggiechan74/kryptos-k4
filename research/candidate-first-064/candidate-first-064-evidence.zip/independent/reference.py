"""Independent 064 reference. Span-sum schedule; equality-subspace inclusion-exclusion count.
No repository numerical code imported; no target fixtures.
"""
from itertools import product

def divisors(p): return [d for d in range(1,p+1) if p%d==0]
def primitive(key): return all(any(key[i]!=key[i%d] for i in range(len(key))) for d in divisors(len(key))[:-1])
def schedule(c,p):
    result=[]
    for i in range(len(c)):
        prefix=c[:i]
        result.append(sum(1+len(prefix)-1-prefix[::-1].index(x)-prefix.index(x) for x in set(prefix))%p)
    return result

def encrypt(plain,key,m=26):
    c=[]
    for x in plain:
        # Independently recompute span statistic on entire emitted prefix.
        s=sum(1+len(c)-1-c[::-1].index(v)-c.index(v) for v in set(c))
        c.append((x+key[s%len(key)])%m)
    return c

def decrypt(c,key,m=26): return [(x-key[r])%m for x,r in zip(c,schedule(c,len(key)))]

def count_primitive(f,m):
    """Inclusion-exclusion over all proper-period equality subspaces."""
    p=len(f); proper=divisors(p)[:-1]; answer=0
    for bits in product((0,1),repeat=len(proper)):
        root=list(range(p))
        def find(x):
            while root[x]!=x: x=root[x]
            return x
        for take,d in zip(bits,proper):
            if take:
                for i in range(p): root[find(i)]=find(i%d)
        assigned={}; valid=True
        for i,x in enumerate(f):
            if x is not None:
                r=find(i)
                if r in assigned and assigned[r]!=x: valid=False
                assigned[r]=x
        if valid: answer+=(-1)**sum(bits)*m**(len({find(i) for i in range(p)})-len(assigned))
    return answer

def solve(c,known,p,m=26):
    q=schedule(c,p); f=[None]*p; consistent=True
    for i,x in known:
        v=(c[i]-x)%m; r=q[i]
        if f[r] is not None and f[r]!=v: consistent=False
        f[r]=v
    u=sorted(set(q)); n=count_primitive(f,m) if consistent else 0
    # Completion theorem holds when alphabet exceeds number of maximal proper divisors.
    proper=divisors(p)[:-1]
    maximal=[d for d in proper if not any(e>d and e%d==0 for e in proper)]
    assert m>len(maximal)
    projection=(m**sum(f[r] is None for r in u) if len(u)<p else n) if n else 0
    return dict(period=p,schedule=q,forced=f,used=u,proper_divisors=proper,consistent=consistent,primitive_seed_count=n,plaintext_count=projection)

def accepts_seed(row,key):
    return row['consistent'] and len(key)==row['period'] and primitive(key) and all(x is None or x==y for x,y in zip(row['forced'],key))

def primitive_completion(f,m):
    if not count_primitive(f,m): return None
    seed=[0 if v is None else v for v in f]
    if primitive(seed): return seed
    # If free, varying any one free coordinate avoids every proper-period subspace.
    for i,x in enumerate(f):
        if x is None:
            for value in range(m):
                candidate=seed.copy();candidate[i]=value
                if primitive(candidate): return candidate
    raise AssertionError('count/completion mismatch')

def witnesses(c,row,m=26):
    if not row['primitive_seed_count']: return []
    a=primitive_completion(row['forced'],m); out=[dict(seed=a,plaintext=decrypt(c,a,m))]
    if row['plaintext_count']>1:
        for r in row['used']:
            if row['forced'][r] is None:
                for value in range(m):
                    if value==a[r]: continue
                    f=row['forced'].copy();f[r]=value
                    b=primitive_completion(f,m)
                    if b is not None:
                        out.append(dict(seed=b,plaintext=decrypt(c,b,m)));return out
        raise AssertionError('missing second plaintext')
    return out

def solve_case(case):
    c=case['ciphertext'];m=case.get('modulus',26)
    rows=[solve(c,case['known'],p,m) for p in case.get('periods',range(2,9))]
    examples=[]
    for row in rows:
        for w in witnesses(c,row,m):
            if not any(w['plaintext']==e['plaintext'] for e in examples): examples.append(dict(period=row['period'],**w))
            if len(examples)==2: break
        if len(examples)==2: break
    return dict(id=case['id'],relations=rows,union_status=['empty','unique','ambiguous'][len(examples)],witnesses=examples)
