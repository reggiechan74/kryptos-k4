"""Frozen independent synthetic generator; use only after production freeze."""
import hashlib,json,random,resource,time,datetime,pathlib
import reference as r
ROOT=pathlib.Path(__file__).resolve().parent
FIXED=list(range(21,34))+list(range(63,74))
def write(name,data):
 b=(json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode();(ROOT/name).write_bytes(b);return hashlib.sha256(b).hexdigest()
def generate(master):
 start=time.process_time();utc=datetime.datetime.now(datetime.timezone.utc).isoformat();inputs=[];secrets=[];expected=[]
 def rng(name): return random.Random(int.from_bytes(hashlib.sha256((master+name).encode()).digest(),'big'))
 def add(name,c,known,truth=None):
  case=dict(id=name,ciphertext=c,known=known,periods=list(range(2,9)),modulus=26)
  inputs.append(case);expected.append(r.solve_case(case));secrets.append(dict(id=name,truth=truth))
 for p in range(2,9):
  for j in range(32):
   name=f'plant-p{p}-{j:02}';g=rng(name)
   while True:
    key=[g.randrange(26) for _ in range(p)]
    if r.primitive(key): break
   pt=[g.randrange(26) for _ in range(97)];c=r.encrypt(pt,key);q=r.schedule(c,p)
   mask=FIXED if j%4==0 else ([q.index(v) for v in sorted(set(q))] if j%4 in (1,2) else sorted(g.sample(range(97),24)))
   if j%4==2:mask=mask[:-1]
   add(name,c,[[i,pt[i]] for i in mask],dict(period=p,key=key,plaintext=pt,mask_style=j%4))
 for j in range(64):
  name=f'null-{j:02}';g=rng(name)
  add(name,[g.randrange(26) for _ in range(97)],[[i,g.randrange(26)] for i in FIXED])
 for p in range(2,9):
  add(f'diagnostic-p{p}-empty',[],[])
  add(f'diagnostic-p{p}-unused',[p],[[0,p]])
  add(f'diagnostic-p{p}-two',[p,p],[])
 hashes={name:write(name,data) for name,data in [('blind-input.json',inputs),('secret-truth.json',secrets),('expected.json',expected)]}
 write('BANK-SEAL.json',dict(hashes=hashes,main_cases=288,diagnostic_cases=21,started_utc=utc,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_seconds=time.process_time()-start,maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
if __name__=='__main__':generate((ROOT/'secret-master.txt').read_text().strip())
