# Study 056 original held-out run — independent audit

## Disposition

**Numerical/scientific gates 1–4 and 6 PASS; learning-specific gate 5 FAIL. Operational resource certification is INCONCLUSIVE, so this original run alone does not admit the target stage.** No target ciphertext was read or evaluated. The parent authorized a resource-only recovery with a fresh holdout; this original run remains immutable numerical-only evidence.

## Frozen inputs and chronology

- Protocol v2 SHA-256: `58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea`.
- Final manifest SHA-256: `19e2fb273d88a97d15223773b03920ea3aa1585cb21854564bd18372fc3d1410`, created 2026-10-31 02:25:36 UTC. All 31 public hashes independently verified before solving and again unchanged afterward.
- At auditor verification 02:25:55 UTC, no held-out solver outputs existed. W=S had already been selected using finalized end-to-end development batches; the earlier tentative solver-only P choice was explicitly superseded before holdout.
- Held-out result seal: 02:32:29.710031 UTC; 256 output hashes, manifest digest `639c7cfccb8ae4bf8417d4c46b53b09e94ef5d5a8b133985867b52c22d7439a4`. Answers were opened only after seal verification. The blind harness prohibited answer/seed opening. Blinding is procedural, not cryptographic isolation in the shared workspace.
- Final generation used v2 rules. No v1 benchmark execution appears in inspected records. This is not a claim about undisclosed off-workspace experiments.

## Independent correctness evidence

The frozen main and supplemental rectangular tiny suites cover 288,363 fixtures and 1,153,452 E/P/S/L calls, including all ciphertext/partial-clue assignments in the declared N=5 grid and exhaustive keys/routes for additional masks. There were 2,277,336 witness re-encryptions. The auditor independently exhaustively checked all **24,780 learned clauses against 697,472 concrete premise completions**, plus 3,040 recorded tiny cross-branch activations. Zero unsound exclusions or complete-set discrepancies.

For the holdout, a separately written direct row-matrix reference performed **732,856,320 route/period trials** (2,862,720 × 256), independently reproducing every complete raw solution set. All four methods' raw descriptions, canonical operators, full plaintexts, aliases, forced positions and set hashes matched. All 1,564 returned witness records re-encrypted exactly. Both held-out learned clauses also had independent static arc-consistency contradiction proofs and excluded no valid reference completion.

Each method returned 163 uniquely identified plaintexts, 9 ambiguous cases and 84 complete UNSAT cases. Summed across fixtures: 391 raw compatible descriptions, 237 canonical operators and 237 plaintexts; these are separate quantities. All 128 in-family planted operators/plaintexts were included. The 128 planted routes were all outside the prior 050 permutation projection in this sample; the independent ciphertext-free domain certificate conservatively establishes at least 408,946 of 408,960 routes outside that projection.

## Frozen numerical gates

| Gate | Requirement | Independently replayed result | Decision |
|---|---|---|---|
| 1 Correctness | Zero errors/unsound exclusions | Zero | PASS |
| 2 Completion | W all 256; E at least 244 | E=P=S=L=256 complete | PASS |
| 3 Identifiability | U+J+L ≥80/84; literal ≥26/28 | 83/84; 28/28 | PASS |
| 4 Representation | E/W GM ≥2; bootstrap lower >1.25 | E/S 60.408981×; 95% [59.352329,61.371853] | PASS for frozen inner metric |
| 5 Learning | S/L ≥1.20; lower >1; ≥50 reused clauses in ≥10 fixtures | 0.992819×; [0.977251,1.008985]; 2 learned, 0 reused | FAIL |
| 6 Uniform calibration | ≤1/56 unique fit | 0/56 SAT or unique | PASS |

Independent deterministic paired bootstrap: 10,000 resamples, seed 56003110. Exact Clopper–Pearson intervals and all per-class/pooled counts were independently reproduced. U+J+L recovery CI is [0.935448,0.999699]; literal CI [0.876564,1].

The 56 uniform controls were all UNSAT (exact 95% SAT/unique rate interval [0,0.0637501]). All 16 mismatch plants were UNSAT ([0,0.205907]). The 56 corruption diagnostics comprised **44 noncrib hits, each retaining its original operator with the exactly modified plaintext and uniquely solving**, plus 12 crib hits, all UNSAT. Their SAT/unique rate is 44/56, interval [0.655605,0.884078]. These legitimate modified-plaintext fits are NOT false positives and are excluded from gate 6.

## Timing scope and sensitivity

The frozen inner metric includes solver process startup/input/output, all 28 cells, preprocessing, per-repeat projection and comparisons. It excludes outer worker import/setup/monitor work. That excluded work was charged to the global CPU ledger: inner totals 308.231943 CPU s; full benchmark 372.940364 CPU s; difference 64.708421 s.

A post-hoc conservative sensitivity assigns **all** that overhead to S, with arbitrary nonnegative allocation among fixtures. Weighted AM–GM bounds even an adversarial allocation chosen separately for each bootstrap resample. The resulting E/S geometric-mean lower bound is **4.208945×**, and the lower 95% paired-bootstrap bound is **2.208133×**. Thus timing-scope overhead cannot explain away the representation gate. This sensitivity is not a replacement or retrospective alteration of the frozen metric.

## Resource defect: exact disposition

The sandbox exposes `/proc/PID/stat` but not `/proc/PID/task/PID/children`. The frozen watchdog caught the missing children file and returned zero, so every saved aggregate RSS sample is zero. These zeros are not measurements. The external live aggregate watchdog was ineffective. OS per-process solver CPU limits and worker/solver address-space limits did apply.

**Actual CPU compliance is established independently despite the live-monitor defect.** Each progress interval sums outer-driver self CPU and waited-child CPU after each worker has waited its solver. Descendant CPU is accumulated once, not counted twice. An interval contains all four method batches and their wrapper/monitor overhead. The largest such interval was only **1.795413646 CPU s**, so every individual method/fixture batch including excluded inner-timing overhead was below 20 s. Interval sums are 372.938938634 s; final seal 372.940364161 s.

**Actual aggregate memory compliance is not established.** Solver RSS peaks are recorded and at most 9,956 KiB; the outer driver peak is 15,276 KiB. The Python worker's actual peak was not recorded. Its 2 GiB per-process address-space cap plus the measured solver peak gives an upper bound slightly above 2 GiB, not the required ≤2 GiB combined cap. No surviving launcher or receipt closes that gap. Low observed runtime, likely low memory, or a later resource replay cannot retroactively prove the original missing peak.

Accordingly, do not reinterpret passing numerical gates as complete operational admission. Preserve the frozen sources, outputs, answers, seals and failed monitor diagnosis. Recovery must be separately preregistered, validate genuine aggregate accounting/hard bounds, use a fresh holdout, and charge all original costs against the same global budget. The target remains unrun until the replacement independent audit passes and the parent explicitly authorizes it.
