import runpy, itertools, json, math, hashlib
from pathlib import Path
x=runpy.run_path(str(Path(__file__).with_name('k4-056-permutation-novelty-certificate.py')));N=97; col=x['col'];inv=x['inv'];closure=x['closure'];old=x['old'];result=x['result']
def is_col(p,w):
 lengths=[len(range(c,N,w)) for c in range(w)]
 order=[];i=0
 while i<N:
  c=p[i]
  if c>=w or c in order:return None
  order.append(c);i+=lengths[c]
 return order if len(order)==w and col(w,order)==p else None
result['full_column_order_domain_counts']={str(w):math.factorial(w) for w in (6,7,8,9)}
result['column_order_permutation_intersection050']={str(w):[is_col(p,w) for p in sorted(closure) if is_col(p,w) is not None] for w in (6,7,8,9)}
result['column_order_permutation_intersection_route001']={str(w):[is_col(p,w) for p in sorted(old) if is_col(p,w) is not None] for w in (6,7,8,9)}
# Independent symbolic reconstruction of other audited route sets; ciphertext absent.
def up(w):return bytes(r*w+c for c in range(w) for r in reversed(range((N+w-1)//w)) if r*w+c<N)
a,b=up(42),up(14);k3=bytes(a[j] for j in b)
clock={bytes(24*r+c for c in [(s+d*q)%24 for q in range(24)] for r in (range(4,-1,-1) if desc else range(5)) if 24*r+c<N) for s,d,desc in itertools.product(range(24),(1,-1),(False,True))}
clock.add(k3)
mask=[(r,c) for r in range(4) for c in range(31) if r>0 or c>=27];ix={v:i for i,v in enumerate(mask)}
occupied=set()
for hor,ver in itertools.product((1,-1),repeat=2):
 p=bytes(ix[r,c] for c in (range(31) if hor==1 else range(30,-1,-1)) for r in (range(4) if ver==1 else range(3,-1,-1)) if (r,c) in ix);occupied.update([p,inv(p)])
def ene(w,start,kind):
 h=(N+w-1)//w;used=[False]*N;out=[];root=start;smallest=0
 while len(out)<N:
  r,c=divmod(root,w);j=0;v=root
  while not used[v]:
   used[v]=True;out.append(v);j+=1
   if kind==1:
    while True:
     c=(c+2)%w;r=(r-1)%h;v=r*w+c
     if v<N:break
   else:
    rr,cc=(r-j,c+2*j) if kind==0 else (r-(math.isqrt(2*j*j)-j),c+j)
    if not (0<=rr<h and 0<=cc<w) or rr*w+cc>=N:break
    v=rr*w+cc
  while smallest<N and used[smallest]:smallest+=1
  if smallest<N:root=smallest
 return bytes(out)
enes=set()
for kind,w,start in itertools.product(range(3),range(1,98),range(97)):
 p=ene(w,start,kind);enes.update([p,inv(p)])
assert len(enes)==34569 and len(clock)==97 and len(occupied)==8
result['extra_audited_route_sets']={label:{'count':len(ps),'sorted_permutation_sha256':hashlib.sha256(b''.join(sorted(ps))).hexdigest()} for label,ps in [('k3_clock',clock),('occupied_cell',occupied),('ene049',enes)]}
for row in result['witnesses']:
 p=bytes(row['encryption_output_to_input'])
 for label,ps in [('k3_clock',clock),('occupied_cell',occupied),('ene049',enes)]:
  row['in_'+label]=p in ps;row['inverse_in_'+label]=inv(p) in ps
  assert p not in ps and inv(p) not in ps
result['column_order_permutation_intersection049']={str(w):[is_col(p,w) for p in sorted(enes) if is_col(p,w) is not None] for w in (6,7,8,9)}
with open('/workspace/shared/candidate-first-056-audit/replayed-coverage.json','w') as f:json.dump(result,f,indent=2);f.write('\n')
print('INTERSECTIONS',json.dumps({k:v for k,v in result.items() if 'intersection' in k}))
