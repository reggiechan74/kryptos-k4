"""Independent no-cipher verification of replacement resource boundaries."""
import sys,os,json,resource,time,hashlib
from pathlib import Path
sys.dont_write_bytecode=True;os.environ['PYTHONDONTWRITEBYTECODE']='1'
R=Path('/workspace/shared/candidate-first-056/recovery-v2');A=Path('/workspace/shared/candidate-first-056-audit/recovery-v2');sys.path.insert(0,str(R/'source'))
from resource_supervisor import supervise,proc_stat
freeze=R/'freeze/recovery-code-freeze.json';manifest=json.loads(freeze.read_text())
for p,h in manifest['hashes'].items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h,p
start=time.process_time();rows=[]
def probe(label,payload,cap=20,mem=2*1024**3):
 r=supervise([sys.executable,str(R/'source/resource_probe_worker.py')],json.dumps(payload),cap,mem);rows.append({'label':label,**r});return r
r=probe('normal_reaped_pair',{'child_cpu':.05,'worker_cpu':.03,'child_bytes':32*1024**2,'worker_bytes':16*1024**2})
assert r['failure'] is None and r['returncode']==0 and r['known_child_live_samples']>0 and r['sample_peak_tree_rss_bytes']>0
v=json.loads(r['stdout']);assert v['child_exit']==0 and v['worker_as']==[1024**3]*2 and v['worker_cpu_limit']==[2,2]
assert r['cpu_accounting']=='EXACT_WAITED_WORKER_AND_REAPED_CHILD' and r['unreaped_cpu_reserve_seconds']==0
assert r['outer_child_cpu_seconds']>=v['child_cpu'] and r['conservative_pair_peak_rss_upper_bytes']>=1024*(v['worker_peak_rss_kib']+v['child_peak_rss_kib'])
assert r['hard_additive_as_cap_bytes']==2*1024**3
r=probe('aggregate_cpu_not_individual_cpu',{'child_cpu':.3,'worker_cpu':.3},cap=.32)
assert r['failure']=='Aggregate CPU cap reached' and r['abnormal_group_cleanup_confirmed']
assert any(s['child_live'] and s['worker_cpu']<.32 and s['cpu_seconds']-s['worker_cpu']<.32 and s['cpu_seconds']>=.32 for s in r['samples'])
assert r['charged_cpu_seconds']>=20 and r['unreaped_cpu_reserve_seconds']>0
r=probe('child_cannot_exceed_half_memory',{'child_bytes':80*1024**2},mem=128*1024**2)
assert r['hard_additive_as_cap_bytes']==128*1024**2
assert r['returncode']!=0 or json.loads(r['stdout'])['child_exit']!=0
r=probe('worker_cannot_exceed_half_memory',{'child_cpu':.02,'worker_bytes':80*1024**2},mem=128*1024**2)
assert r['returncode']!=0 and r['abnormal_group_cleanup_confirmed'] and r['charged_cpu_seconds']>=20
r=probe('duplicate_announcement_cleanup',{'child_cpu':.3,'duplicate_announcement':True})
assert r['returncode']!=0 and r['abnormal_group_cleanup_confirmed'] and r['charged_cpu_seconds']>=20
r=probe('descendant_peak_survives_wait',{'child_bytes':64*1024**2,'child_cpu':.02})
assert r['failure'] is None and r['returncode']==0
v=json.loads(r['stdout']);assert r['waited_children_maxrss_kib']>=v['child_peak_rss_kib']>=64*1024
for row in rows:
 if row['failure']:
  try:assert proc_stat(row['solver_pid'])['state']=='Z'
  except FileNotFoundError:pass
assert hashlib.sha256(freeze.read_bytes()).hexdigest()=='c9f6d54a3f9fccf48ba4e22cb54d69b974d1bc3f6215a26145aa6d0bc58f182e'
receipt={'status':'PASS','no_cipher_inputs':True,'freeze_sha256':hashlib.sha256(freeze.read_bytes()).hexdigest(),'hard_additive_memory_bound_bytes':2*1024**3,'primary_topology':'one worker plus one persistent solver for all20repetitions; no other children in frozen code','primary_cpu_hard_limits':[2,16],'all_abnormal_groups_stopped':True,'self_cpu_seconds':time.process_time()-start,'waited_children_cpu_seconds':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,'conservative_failure_reserve_seconds':sum(r['unreaped_cpu_reserve_seconds'] for r in rows),'charged_cpu_seconds':sum(r['charged_cpu_seconds'] for r in rows),'peak_self_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'peak_children_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'probes':rows}
(A/'independent-resource-probe.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='probes'},indent=2))
