"""Post-seal independent resource/timing reconciliation for replacement holdout."""
from pathlib import Path
import json,math,hashlib,time,resource
R=Path('/workspace/shared/candidate-first-056/recovery-v2');A=Path('/workspace/shared/candidate-first-056-audit/recovery-v2');start=time.process_time()
seal=json.loads((R/'audit/benchmark-seal.json').read_text());freeze=json.loads((R/'freeze/manifest.json').read_text());rows=[json.loads(p.read_text()) for p in (R/'results').glob('*.json')];assert len(rows)==256
assert hashlib.sha256((R/'freeze/manifest.json').read_bytes()).hexdigest()==seal['freeze_sha256']
for id,h in seal['output_hashes'].items():assert hashlib.sha256((R/'results'/f'{id}.json').read_bytes()).hexdigest()==h
for name,h in freeze['hashes'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==h,name
reps=freeze['execution']['fixed_batch_repeats'];assert reps==20
recorded_cpu=0;max_cpu=max_rss=max_sample=0;positive=live=complete=failed=0;reserves=0
for row in rows:
 for method,x in row['methods'].items():
  r=x['resource_receipt'];b=x['batch'];assert r['process_as_cap_bytes']==1024**3 and r['hard_additive_as_cap_bytes']==2*1024**3
  assert r['worker_cpu_hard_seconds']==2 and r['solver_cpu_hard_seconds']==16 and r['exactly_one_child_announced']
  assert r['abnormal_group_cleanup_confirmed']
  reserves+=r['unreaped_cpu_reserve_seconds'];recorded_cpu+=r['outer_total_cpu_seconds']+r['unreaped_cpu_reserve_seconds']
  if x['complete']:
   complete+=1;assert r['failure'] is None and r['returncode']==0
   assert r['cpu_accounting']=='EXACT_WAITED_WORKER_AND_REAPED_CHILD' and r['unreaped_cpu_reserve_seconds']==0
   assert r['outer_total_cpu_seconds']<=20
   assert r['conservative_pair_peak_rss_upper_bytes']<=2*1024**3
   assert math.isclose(b['normalized_end_to_end_cpu_seconds'],r['outer_total_cpu_seconds']/reps,rel_tol=1e-12)
   assert math.isclose(b['end_to_end_cpu_seconds'],r['outer_total_cpu_seconds'],rel_tol=1e-12)
   assert b['repeats_completed']==20 and b['repeats_planned']==20
   assert r['waited_children_maxrss_kib']*2048==r['conservative_pair_peak_rss_upper_bytes']
  else:
   failed+=1;assert b['censored'] and b['normalized_end_to_end_cpu_seconds'] is None
  positive+=r['sample_peak_tree_rss_bytes']>0;live+=r['known_child_live_samples']>0
  max_cpu=max(max_cpu,r['outer_total_cpu_seconds']);max_rss=max(max_rss,r['conservative_pair_peak_rss_upper_bytes'] or 0);max_sample=max(max_sample,r['sample_peak_tree_rss_bytes'])
assert seal['cpu_seconds']+1e-8>=recorded_cpu
assert math.isclose(seal.get('unreaped_failure_cpu_reserve_seconds',0),reserves,abs_tol=1e-9)
progress=json.loads((R/'audit/benchmark-progress.json').read_text());last=0;intervals=[]
for d in progress:intervals.append(d['cumulative_cpu_seconds']-last);last=d['cumulative_cpu_seconds']
report={'status':'PASS','method_fixture_batches':len(rows)*4,'complete_batches':complete,'failed_batches':failed,'fixed_repetitions_per_batch':reps,'all_completed_calls_meet_actual_aggregate_CPU_and_memory_caps':True,'hard_AS_pair_limit_bytes':2*1024**3,'maximum_inclusive_batch_cpu_seconds':max_cpu,'maximum_measured_pair_peak_upper_bytes':max_rss,'maximum_sampled_pair_rss_bytes':max_sample,'batches_with_positive_RSS_samples':positive,'batches_with_known_live_solver_sample':live,'summed_primary_batch_charge_seconds':recorded_cpu,'global_benchmark_charge_seconds':seal['cpu_seconds'],'additional_global_controller_and_output_cpu_seconds':seal['cpu_seconds']-recorded_cpu,'failure_upper_bound_reserves_seconds':reserves,'maximum_all_four_batches_fixture_interval_cpu_seconds':max(intervals),'postrun_frozen_hashes_unchanged':True,'cpu_seconds':time.process_time()-start,'peak_self_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(A/'resource-receipt-replay.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
