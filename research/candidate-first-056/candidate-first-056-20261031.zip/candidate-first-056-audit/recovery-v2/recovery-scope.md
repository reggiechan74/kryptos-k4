# Authorized resource-only recovery scope

Parent authorization received 2026-10-31 02:37 UTC. Original run and its numerical/operational caveats are preserved. Recovery is confined to aggregate resource supervision/accounting and an explicitly fresh namespace/seed. Same solver source/binary, family, width/period union, W=S, fixture rules, all numeric gates, fixed twenty repeats and shared eight-CPU-hour budget. The replacement metric consistently includes outer waited worker/solver CPU and monitoring CPU; original inner timing remains descriptive. No target execution.

Before generation: independently verify hard additive address-space limits on exactly one worker plus one persistent solver; probe normal/reaped paths, combined CPU limit, partitioned memory rejection, duplicate child rejection, and every abnormal-exit cleanup/accounting path. No missing `/proc` observation may be interpreted as zero usage. Interrupted orphaned child CPU must either be reaped or conservatively charged.

A replacement full solution-set and numerical audit will occur only after immutable outputs are sealed and before target admission. Original costs remain charged. The auditor writes only in candidate-first-056-audit.
