"""Independent direct-route enumeration of the complete 28-cell union, after seal only."""
from pathlib import Path
import hashlib,json,resource,subprocess,time,sys,math
A=Path('/workspace/shared/candidate-first-056-audit/recovery-v2');R=Path('/workspace/shared/candidate-first-056/recovery-v2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def serial(x):return json.dumps(x,separators=(',',':'))
def raw(s):return (s['width'],s['period'],tuple(s['order']),tuple(s['key']),tuple(s['plaintext']))
def convert(x):return (x[0],x[1],tuple(x[2]),tuple(x[3]),tuple(x[4]))
def project(s):
 w,p,o,k,pt=s;n=len(pt)
 rows=[list(range(i,min(i+w,n))) for i in range(0,n,w)]
 route=tuple(row[c] for c in o for row in rows if c<len(row))
 return route,tuple(k[i%p] for i in range(n))
def check_witness(f,s):
 w,p,order,key,plain=s
 assert len(plain)==97 and sorted(order)==list(range(w)) and w in range(6,10) and p in range(2,9) and len(key)==p
 assert all(plain[i]==v for i,v in f['clues'])
 shifted=[(v+key[i%p])%26 for i,v in enumerate(plain)]
 rows=[shifted[i:i+w] for i in range(0,97,w)]
 cipher=[row[c] for c in order for row in rows if c<len(row)]
 assert cipher==f['ciphertext']

def bounds():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(20,21))
start=time.process_time();ch0=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.monotonic();dev='--dev' in sys.argv
if not dev:
 seal=json.loads((R/'audit/benchmark-seal.json').read_text());assert seal['fixtures']==256
 assert seal['freeze_sha256']==sha(R/'freeze/manifest.json')
 for id,h in seal['output_hashes'].items():assert sha(R/'results'/f'{id}.json')==h
 fixtures=[json.loads(x) for x in (R/'fixtures/heldout-inputs.jsonl').read_text().splitlines()]
 assert len(fixtures)==256
else:fixtures=[json.loads(x) for x in (R/'development/inputs.jsonl').read_text().splitlines()];results={x['id']:x for x in json.loads((R/'development/results.json').read_text())['results']}
assert all(set(x)=={'id','ciphertext','clues'} for x in fixtures)
checked=ngcount=trial_total=0;details=[];digest=hashlib.sha256()
for index,f in enumerate(fixtures):
 payload=' '.join(map(str,f['ciphertext']+[v for pair in f['clues'] for v in pair]))+'\n'
 proc=subprocess.run([str(A/'independent_full_reference')],input=payload,text=True,capture_output=True,preexec_fn=bounds,check=True)
 ref=json.loads(proc.stdout);assert ref['trials']==2862720;trial_total+=ref['trials'];expect=set(map(convert,ref['solutions']));assert len(expect)==len(ref['solutions'])
 result=results[f['id']] if dev else json.loads((R/'results'/f"{f['id']}.json").read_text())
 for name,x in result['methods'].items():
  got=set(map(raw,x['solutions']));assert len(got)==len(x['solutions'])
  assert got==expect if x['complete'] else got<=expect,('different complete raw set',f['id'],name,len(got),len(expect))
  for s in got:check_witness(f,s);checked+=1
  ops={project(s) for s in got};pts={s[4] for s in got};projection=x['projection']
  assert projection['canonical_operator_count']==len(ops) and projection['distinct_plaintext_count']==len(pts) and projection['raw_compatible_descriptions']==len(got)
  assert projection['operator_set_sha256']==hashlib.sha256(serial(sorted(ops)).encode()).hexdigest()
  assert projection['plaintext_set_sha256']==hashlib.sha256(serial(sorted(pts)).encode()).hexdigest()
  op_raw={op:{s[:4] for s in got if project(s)==op} for op in ops}
  if x['complete']:
   for op,aliases in op_raw.items():
    stream=op[1];example=next(s for s in got if project(s)==op);w,_,order,_,_=example
    expected_aliases={(w,p,order,tuple(stream[:p])) for p in range(2,9) if all(stream[i]==stream[i%p] for i in range(97))}
    assert aliases==expected_aliases,('incomplete aliases',f['id'],name)
  assert projection['alias_multiplicities']==sorted(map(len,op_raw.values()))
  assert projection['operators_per_plaintext']==sorted(len({project(s) for s in got if s[4]==pt}) for pt in pts)
  assert projection['forced_positions']==([len({p[i] for p in pts})==1 for i in range(97)] if pts else [False]*97)
  for ng in x['nogoods']:
   w,p=ng['width'],ng['period'];lengths=[len(range(c,97,w)) for c in range(w)];starts=[]
   for c in range(w):
    poss={0}
    for d,l in enumerate(lengths):
     if c!=d:poss|={s+l for s in list(poss)}
    starts.append(sorted(poss))
   premises=[(c,starts[c][i]) for c,i in ng['clause_placement_indices']]
   for s in expect:
    if s[0]!=w or s[1]!=p:continue
    offset=0;actual={}
    for c in s[2]:actual[c]=offset;offset+=lengths[c]
    assert not all(actual[c]==off for c,off in premises),('unsound nogood',f['id'],ng,s)
   ngcount+=1
 digest.update(serial([f['id'],sorted(expect)]).encode())
 details.append({'id':f['id'],'raw_count':len(expect),'canonical_operator_count':len({project(s) for s in expect}),'plaintext_count':len({s[4] for s in expect}),'reference_trials':ref['trials']})
 if not dev and (index+1)%32==0:print('independent full-set replay',index+1,flush=True)
ch=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'status':'PASS','label':'development' if dev else 'sealed_heldout','fixtures':len(fixtures),'all_completed_methods_match_independent_reference':True,'direct_reference_route_period_trials':trial_total,'witness_reencryptions':checked,'learned_clauses_checked_against_complete_reference_set':ngcount,'complete_raw_sets_sha256':digest.hexdigest(),'self_cpu_seconds':time.process_time()-start,'child_cpu_seconds':ch.ru_utime+ch.ru_stime-ch0.ru_utime-ch0.ru_stime,'peak_self_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'peak_child_rss_kib':ch.ru_maxrss,'wall_seconds':time.monotonic()-wall,'details':details}
(A/('development-reference-replay.json' if dev else 'full-reference-replay.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='details'},indent=2))
