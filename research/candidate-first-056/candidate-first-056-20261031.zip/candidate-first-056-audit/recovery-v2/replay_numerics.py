"""Independent post-seal gate arithmetic and answer/learning provenance audit."""
from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib,math,random,resource,time
R=Path('/workspace/shared/candidate-first-056/recovery-v2');A=Path('/workspace/shared/candidate-first-056-audit/recovery-v2')
start=time.process_time()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(k,n):
 def root(fn,target,increasing):
  low,high=0.,1.
  for _ in range(80):
   mid=(low+high)/2
   if (fn(mid)<target)==increasing:low=mid
   else:high=mid
  return (low+high)/2
 lo=0. if k==0 else root(lambda p:sum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k,n+1)),.025,True)
 hi=1. if k==n else root(lambda p:sum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k+1)),.025,False)
 return [lo,hi]
def close(x,y):assert abs(x-y)<1e-10,(x,y)
def encode(plain,key,w,order):
 shifted=[(v+key[i%len(key)])%26 for i,v in enumerate(plain)];rows=[shifted[i:i+w] for i in range(0,97,w)]
 return [row[c] for c in order for row in rows if c<len(row)]
def operator(s):return (tuple(i for c in s['order'] for i in range(c,97,s['width'])),tuple(s['key'][i%len(s['key'])] for i in range(97)))
seal=json.loads((R/'audit/benchmark-seal.json').read_text());assert seal['fixtures']==256
assert seal['freeze_sha256']==sha(R/'freeze/manifest.json')
for id,h in seal['output_hashes'].items():assert sha(R/'results'/f'{id}.json')==h
freeze=json.loads((R/'freeze/manifest.json').read_text());generation=json.loads((R/'fixtures/heldout-generation-receipt.json').read_text())
assert generation['protocol_sha256']=='58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea'
for name,h in generation['hashes'].items():assert sha(R/name)==h
answers={x['id']:x for x in map(json.loads,(R/'answers/heldout-answers.jsonl').read_text().splitlines())};inputs={x['id']:x for x in map(json.loads,(R/'fixtures/heldout-inputs.jsonl').read_text().splitlines())};rows=[json.loads(p.read_text()) for p in sorted((R/'results').glob('*.json'))]
assert len(rows)==256 and set(inputs)==set(answers)=={r['id'] for r in rows}
W=freeze['execution']['selected_method'];analysis=json.loads((R/'audit/analysis.json').read_text());assert W==analysis['selected_method'];groups=defaultdict(list);records=[];noncrib=crib=preserved=0;reuses=0;reuse_cases=0;all_witnesses=0
for row in rows:
 id=row['id'];ans=answers[id];f=inputs[id];x=row['methods'][W];plains={tuple(s['plaintext']) for s in x['solutions']};ops={operator(s) for s in x['solutions']};plant=ans.get('plant');unique=x['complete'] and len(plains)==1;truth=bool(plant and tuple(plant['plaintext']) in plains)
 record={'category':ans['category'],'class':ans['class'],'unique':unique,'sat':bool(plains),'complete':x['complete'],'truth':truth};records.append(record);groups[ans['category']+'/'+str(ans['class'])].append(record)
 if ans.get('expected_truth_inclusion'):
  assert encode(plant['plaintext'],plant['key'],plant['width'],plant['order'])==f['ciphertext']
  assert operator(plant) in ops and truth
 if ans['category']=='corruption_control':
  original=encode(plant['plaintext'],plant['key'],plant['width'],plant['order']);assert original==plant['ciphertext'];changes=[i for i in range(97) if original[i]!=f['ciphertext'][i]];assert len(changes)==1
  change=ans['corruption'];i=changes[0];assert i==change['ciphertext_position'];delta=(f['ciphertext'][i]-original[i])%26;assert delta==change['modular_increment'] and delta!=0
  target=operator(plant)[0][i];assert target==change['mapped_plaintext_position'];is_noncrib=target not in dict(f['clues']);assert is_noncrib==change['mapped_position_is_noncrib']
  modified=plant['plaintext'].copy();modified[target]=(modified[target]+delta)%26;assert encode(modified,plant['key'],plant['width'],plant['order'])==f['ciphertext']
  if is_noncrib:
   noncrib+=1;assert all(modified[j]==v for j,v in f['clues']);assert tuple(modified) in plains and operator(plant) in ops;preserved+=1
  else:crib+=1;assert ans['guaranteed_corrupted_witness'] is None
 l=row['methods']['L'];events=l.get('nogood_reuses',[]);assert len(events)==l['metrics'].get('cross_branch_unique_nogoods',0)
 seen=set()
 for event in events:
  signature=(event['width'],event['period'],tuple(map(tuple,event['clause_placement_indices'])));assert signature not in seen;seen.add(signature)
  assert any(event['width']==ng['width'] and event['period']==ng['period'] and event['clause_placement_indices']==ng['clause_placement_indices'] and event['discovery_decisions']==ng['discovery_decisions'] for ng in l['nogoods'])
  old=event['discovery_decisions'];now=event['reuse_decisions'];n=0
  while n<min(len(old),len(now)) and old[n]==now[n]:n+=1
  assert n<len(old) and n<len(now)
  domains=event['domains_before_reuse'];unfixed=0
  for c,v in event['clause_placement_indices']:
   assert v in domains[c];unfixed+=len(domains[c])!=1
  assert unfixed<=1
  for c,v in now:assert domains[c]==[v]
  reuses+=1
 reuse_cases+=bool(events)
groups['pooled/random_control']=[r for r in records if r['category']=='random_control'];groups['pooled/corruption_control']=[r for r in records if r['category']=='corruption_control'];groups['pooled/mismatch']=[r for r in records if r['category'].startswith('mismatch_')];groups['pooled/primary_UJL']=[r for r in records if r['category']=='primary' and r['class'] in 'UJL']
for label,g in groups.items():
 got=analysis['groups'][label];n=len(g);sat=sum(r['sat'] for r in g);unique=sum(r['unique'] for r in g)
 assert got['n']==n and got['sat']==sat and got['unique']==unique and got['complete']==sum(r['complete'] for r in g)
 for x,y in zip(cp(unique,n),got['unique_95_exact']):close(x,y)
 for x,y in zip(cp(sat,n),got['sat_95_exact']):close(x,y)
effects={}
for name,effect in analysis['effects'].items():
 num,den=name.split('/');paired=[r for r in rows if r['methods'][num]['complete'] and r['methods'][den]['complete']];assert effect['n']==len(paired)
 logs=[math.log(r['methods'][num]['batch']['normalized_end_to_end_cpu_seconds']/r['methods'][den]['batch']['normalized_end_to_end_cpu_seconds']) for r in paired]
 if logs:
  rng=random.Random(56003110);n=len(logs);samples=sorted(math.exp(sum(logs[rng.randrange(n)] for _ in range(n))/n) for _ in range(10000));gm=math.exp(sum(logs)/n);ci=[samples[249],samples[9749]]
  close(gm,effect['geometric_mean']);close(ci[0],effect['bootstrap_95'][0]);close(ci[1],effect['bootstrap_95'][1]);effects[name]={'geometric_mean':gm,'bootstrap_95':ci,'pairs':n}
complete={m:sum(r['methods'][m]['complete'] for r in rows) for m in 'EPSL'};assert complete==analysis['completion'];primary=groups['pooled/primary_UJL'];literal=[r for r in primary if r['class']=='L'];recovered=sum(r['unique'] and r['truth'] for r in primary);literal_recovered=sum(r['unique'] and r['truth'] for r in literal);uniform_unique=sum(r['unique'] for r in groups['pooled/random_control']);rep=effects[f'E/{W}'];learning=effects['S/L']
gates={'correctness_cross_method':json.loads((A/'full-reference-replay.json').read_text())['status']=='PASS','completion':complete[W]==256 and complete['E']>=244,'identifiability':recovered>=80 and literal_recovered>=26,'representation_value':rep['geometric_mean']>=2 and rep['bootstrap_95'][0]>1.25,'learning_value':learning['geometric_mean']>=1.2 and learning['bootstrap_95'][0]>1 and reuses>=50 and reuse_cases>=10,'uniform_false_fit':uniform_unique<=1}
assert gates==analysis['gates'];assert reuses==analysis['learning_cross_branch_unique'] and reuse_cases==analysis['learning_cross_branch_cases']
report={'status':'PASS','selected_method':W,'gates':gates,'completion':complete,'ordinary_unique_recovered':recovered,'ordinary_n':84,'literal_unique_recovered':literal_recovered,'literal_n':28,'uniform_unique':uniform_unique,'uniform_n':56,'corruption_noncrib':noncrib,'corruption_crib':crib,'guaranteed_modified_plants_verified':preserved,'independently_demonstrated_cross_branch_nogoods':reuses,'cross_branch_fixtures':reuse_cases,'effects':effects,'all_reported_group_counts_and_exact_intervals_match':True,'cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(A/'numerical-replay.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
