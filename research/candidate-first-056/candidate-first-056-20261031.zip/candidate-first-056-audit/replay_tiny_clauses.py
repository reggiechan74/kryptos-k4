"""Second independently written audit of EVERY recorded tiny learned clause."""
from pathlib import Path
from itertools import permutations,product
from collections import Counter
import json,hashlib,resource,time,sys
resource.setrlimit(resource.RLIMIT_CPU,(600,601));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
start=time.process_time();src=Path('/workspace/shared/candidate-first-056/audit/'+('tiny-rectangle-nogoods.jsonl' if '--rectangle' in sys.argv else 'tiny-nogoods.jsonl'));h=hashlib.sha256(src.read_bytes()).hexdigest();checked=clauses=0;counts=Counter()
for line in src.open():
 d=json.loads(line);n=len(d['ciphertext']);a=d['alphabet'];w=d['receipt']['width'];p=d['receipt']['period'];C=d['ciphertext'];clues=d['clues']
 # Independently enumerate routes before translating solver's placement indices.
 routes=[];allowed=[set() for _ in range(w)]
 for order in permutations(range(w)):
  route=[];starts={}
  for c in order:
   starts[c]=len(route);route.extend(range(c,n,w));allowed[c].add(starts[c])
  routes.append((route,starts))
 starts_sorted=[sorted(x) for x in allowed]
 premises=[(c,starts_sorted[c][index]) for c,index in d['receipt']['clause_placement_indices']]
 assert [list(x) for x in premises]==d['premises']
 local=0
 for route,starts in routes:
  if not all(starts[c]==s for c,s in premises):continue
  shifted=[None]*n
  for output,input_index in enumerate(route):shifted[input_index]=C[output]
  for key in product(range(a),repeat=p):
   plaintext=[(x-key[i%p])%a for i,x in enumerate(shifted)]
   local+=1
   assert any(plaintext[i]!=v for i,v in clues),('UNSOUND',d,route,key)
 assert local==d['concrete_completions_checked']
 checked+=local;clauses+=1;counts[d['grid']]+=1
report={'status':'PASS','nogood_receipts_sha256':h,'learned_clauses_independently_verified':clauses,'all_concrete_premise_completions':checked,'clauses_by_grid':dict(counts),'cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
out=Path('/workspace/shared/candidate-first-056-audit/'+('tiny-rectangle-clause-replay.json' if '--rectangle' in sys.argv else 'tiny-clause-replay.json'));out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
