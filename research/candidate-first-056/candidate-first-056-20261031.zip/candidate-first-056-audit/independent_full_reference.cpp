// Independent exhaustive synthetic reference for audit of study 056.
// No target loader. Input: 97 ciphertext values then 24 (position,value) pairs.
// Literal ragged row matrix determines each route. No production helpers or placement pruning.
#include <algorithm>
#include <array>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);array<int,97>C;while(cin>>C[0]){for(int i=1;i<97;i++)cin>>C[i];array<int,24>I,V;for(int t=0;t<24;t++)cin>>I[t]>>V[t];long long trials=0,count=0;cout<<"{\"solutions\":[";
for(int w=6;w<=9;w++){vector<vector<int>>rows;for(int i=0;i<97;){vector<int>row;for(int c=0;c<w&&i<97;c++,i++)row.push_back(i);rows.push_back(row);}vector<int>order(w);iota(order.begin(),order.end(),0);
do{array<int,97>inverse;int offset=0;for(int col:order)for(const auto&row:rows)if(col<(int)row.size())inverse[row[col]]=offset++;
for(int p=2;p<=8;p++){trials++;array<int,8>key;key.fill(-1);bool good=true;for(int t=0;t<24;t++){int slot=I[t]%p,k=(C[inverse[I[t]]]-V[t]+26)%26;if(key[slot]>=0&&key[slot]!=k){good=false;break;}key[slot]=k;}if(!good)continue;for(int k=0;k<p;k++)if(key[k]<0)return 4;
if(count++)cout<<',';cout<<"["<<w<<','<<p<<",[";for(int j=0;j<w;j++){if(j)cout<<',';cout<<order[j];}cout<<"],[";for(int j=0;j<p;j++){if(j)cout<<',';cout<<key[j];}cout<<"],[";for(int i=0;i<97;i++){if(i)cout<<',';cout<<(C[inverse[i]]-key[i%p]+26)%26;}cout<<"]]";
}}while(next_permutation(order.begin(),order.end()));}
cout<<"],\"trials\":"<<trials<<"}\n";cout.flush();}return 0;}
