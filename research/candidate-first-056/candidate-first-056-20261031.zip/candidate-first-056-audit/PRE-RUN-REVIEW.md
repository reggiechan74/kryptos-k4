# Study 056 independent pre-run review

This review is synthetic-only. No target ciphertext was read or evaluated. The primary implementation and answer files were not edited. Held-out answers remain unread by this auditor until a result seal is verified.

## Established before held-out solving

- **PASS — conventions/domain.** The protocol hash is `58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea`. Standard A–Z addition occurs at plaintext indices, followed by unpadded row-filled column concatenation. Widths 6–9 and nominal periods 2–8 are inferred by searching all 28 cells. The reference enumerates 2,862,720 route/period combinations, not 26^p seeds.
- **PASS — placement equivalence.** Candidate starts are exact subset sums of other column lengths, including ragged length offsets. Unary residue consistency, pairwise shared-residue consistency and nonoverlap exactly characterize legal placements. Every interval is inside the message; selected lengths sum to 97, so nonoverlap implies a complete tiling. Complete leaves infer the full key; tiny empty masks explicitly enumerate unobserved slots.
- **PASS — learned-clause soundness review.** Learned decision conjunctions arise after domain wipeout, with minimization by static no-learning propagation replay. Timeouts prevent clause admission. Nogoods are cleared per width/period/fixture. Later unit application uses singleton domain truth and removes only the final unassigned literal. A second independent script exhaustively checked every one of 24,492 tiny clauses against all 696,320 concrete premise completions, with zero unsound exclusions. These counts alone are not proof of useful cross-branch learning on the holdout.
- **PASS — complete projected outputs.** Raw descriptions, full dependency/shift operators, full plaintexts, aliases, and forced positions are separate. A timeout is INCONCLUSIVE, not UNSAT or unique. The independent direct row-matrix enumerator exactly matched every E/P/S/L complete raw set on all eight development fixtures (22,901,760 independent route/period trials, 292 witness re-encryptions, 40 clause checks).
- **PASS — coverage replay.** The ciphertext-free certificate was reproduced exactly: 27,323 prior 050 operators, 7,985 permutation projections, only 14 overlaps among the 408,960 new routes, hence at least 408,946 routes outside 050. This is a conservative model-coverage statement, not worldwide algorithm novelty or evidence that the historical target uses the family.
- **PASS — fixture specification review.** 112 positives, 32 diagnostics, 56 independently uniform-ciphertext controls and 56 one-symbol corruption diagnostics total 256. The generator uses opaque random IDs, shuffled input order, no solvability/runtime filtering, and a schema containing only ID, ciphertext and clues. Primitive-period key rejection is the only selection. Noncrib corruptions retain the exact original operator with a one-letter-modified plaintext; they are not false positives. Only the uniform 56 enter the ≤1 unique-fit threshold.
- **PASS — development choice.** P is fastest in both geometric mean and aggregate development CPU. The learning and deployment gates remain distinct.

## Pre-freeze changes requested and implemented/reviewed

The worker added resource enforcement outside cooperative solver checks, included comparison and canonical projection work in measured timing, prevented any answer/seed opening by the blind harness, corrected live-child CPU accounting in the tiny guard, and bound final tiny evidence to the exact final binary. Per-repeat projection and cross-branch first-use provenance were requested before final freeze. These are measurement/provenance changes, not changes to the mathematical family or held-out fixtures.

## Still required before final certification

1. Verify final manifest and code hashes after cross-branch receipt instrumentation and tiny rerun.
2. Wait for all immutable held-out outputs and verify their seal before opening answers.
3. Independently enumerate all full-union solution sets and replay numerical gates, witnesses, aliases, corruption assertions and learning receipts.
4. Reconcile summed CPU and memory accounting including development, repeated tiny runs, compilation, fixed timing batches, independent audits and analysis.

Blinding is procedural in a shared workspace, not cryptographic isolation. The v2 generation receipt binds the final v2 protocol before fixture generation; no v1 benchmark execution appears in inspected receipts. This audit cannot establish the nonexistence of undisclosed off-workspace experiments.

## Final pre-run amendments, 2026-10-31 02:25 UTC

The initial solver-only P selection above is superseded **before any held-out solving**. The finalized end-to-end wrapper was run on the same eight development fixtures, under a rule frozen first: smallest complete aggregate CPU, exact ties prefer P then S then L. **W = S**, with aggregate fixed-20 batches S 0.198207368 s, P 0.212622530 s, L 0.218808982 s. No new full-length development fixtures were created.

The original tiny grid contained only ragged geometries. A separately frozen rectangular supplement (alphabet 2, N=9, width 3, periods 1 and 3, empty/partial/full masks) closed that gap: 20,992 fixtures, 83,968 solver calls, 368,640 re-encryptions, 288 clauses and 1,152 concrete premise completions, all PASS. The independent auditor separately replayed all 288 clauses. Main plus supplement: **288,363 fixtures; 1,153,452 calls; 2,277,336 witness re-encryptions; 24,780 clauses over 697,472 concrete completions**, no errors.

Final solver instrumentation records a clause's first cross-branch activation, the discovery and reuse paths, and domains immediately before activation. The full main tiny suite was rerun against the exact final source/binary. All 3,040 recorded tiny cross-branch activations were independently checked for branch divergence and actual clause activation. This establishes receipt fidelity, not held-out learning benefit.

The final tiny source hash is `625739e4d4e5a4e0052de4069563319b1a0c13e7b1c82cb0cf2751c09f657573`; binary hash `e9f86df41dec1f3e8289d9e04d8c3faaf80a79ff8ea5188b38ce136bd7bb6b65`. The current timing wrapper projects every repetition and verifies deterministic repeated outputs/projections/receipts.

**Pre-run code/method review: CLEAR**, subject to checking the final manifest commitment. Held-out correctness, timing, identifiability and calibration gates remain PENDING. The target gate is not opened by this review.
