"""Post-hoc conservative sensitivity, NOT a replacement of frozen timing metric.
All globally charged wrapper/monitor/import overhead is assigned to S.
For each bootstrap resample, weighted AM-GM bounds the maximum denominator
under ANY nonnegative per-fixture allocation of this overhead (even one
adversarially chosen separately for each resample). This relaxes the actual
per-fixture lower bounds, so the resulting speedup/interval bounds are safe.
"""
from pathlib import Path
from collections import Counter
import json,math,random,time,resource
R=Path('/workspace/shared/candidate-first-056');A=Path('/workspace/shared/candidate-first-056-audit');start=time.process_time()
rows=[json.loads(p.read_text()) for p in sorted((R/'results').glob('*.json'))];N=len(rows);assert N==256
sumtime={m:sum(r['methods'][m]['batch']['end_to_end_cpu_seconds'] for r in rows) for m in 'EPSL'}
whole=json.loads((R/'audit/benchmark-seal.json').read_text())['cpu_seconds'];overhead=whole-sum(sumtime.values());assert overhead>=0
repeats=json.loads((R/'freeze/manifest.json').read_text())['execution']['fixed_batch_repeats'];assert repeats==20
E=[r['methods']['E']['batch']['normalized_end_to_end_cpu_seconds'] for r in rows];S=[r['methods']['S']['batch']['normalized_end_to_end_cpu_seconds'] for r in rows];total_denominator=sum(S)+overhead/repeats
# Ordinary (equal-weight) case: product is maximized by equalizing all S times.
level=total_denominator/N;assert level>=max(S)
gm_bound=math.exp(sum(map(math.log,E))/N)/level
rng=random.Random(56003110);bounds=[]
for _ in range(10000):
 ids=[rng.randrange(N) for _ in range(N)];counts=Counter(ids)
 log_num=sum(math.log(E[i]) for i in ids)/N
 # max product(y_i^weight_i) given sum(y_i)=T is T*product(weight_i^weight_i).
 log_max_den=math.log(total_denominator)+sum((n/N)*math.log(n/N) for n in counts.values())
 bounds.append(math.exp(log_num-log_max_den))
bounds.sort();ci=[bounds[249],bounds[9749]]
report={'label':'POST_HOC_CONSERVATIVE_OVERHEAD_SENSITIVITY','global_benchmark_cpu_seconds':whole,'timed_inner_batch_cpu_seconds':sum(sumtime.values()),'outside_metric_but_globally_charged_cpu_seconds':overhead,'all_overhead_assigned_to':'S','allocation':'arbitrary nonnegative across256fixtures; weighted AM-GM bound allows adversarial allocation separately for each bootstrap sample','geometric_mean_speedup_lower_bound':gm_bound,'paired_bootstrap_95_bounds_for_speedup_lower_bound':ci,'representation_gate_still_passes':gm_bound>=2 and ci[0]>1.25,'bootstrap_seed':56003110,'bootstrap_replicates':10000,'cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(A/'timing-overhead-sensitivity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
