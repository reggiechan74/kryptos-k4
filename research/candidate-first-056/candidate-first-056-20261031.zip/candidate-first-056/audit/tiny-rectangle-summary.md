# Study 056 supplemental rectangular audit

**PASS.** Added before held-out benchmarking in response to the review finding that the original tiny grids were all ragged. This supplements rather than replaces the preserved main audit.

The frozen domain is alphabet 2, length 9, width 3, nominal periods 1 and 3. Every ciphertext, column order and key was enumerated: 30,720 concrete tuples. Empty, positions 0/4/8, and full clue masks retain every generated distinct clue assignment. All 20,992 distinct resulting inputs were passed to E/P/S/L, for 83,968 solver calls.

There were zero missing or extra raw descriptions, canonical operators or complete plaintexts. All 368,640 witnesses independently re-encrypted and satisfied their clues. All 288 learned nogoods were checked against their 1,152 premise-containing concrete completions; none was a satisfying completion. No cross-branch reuse occurred in this rectangular supplement; the main suite independently checked 3,040 such receipts.

The fixture labels comprised 16,640 unique-plaintext and 4,352 multiple-plaintext inputs. This generative supplement does not create UNSAT inputs; the main exhaustive partial-clue grid already tested 932 UNSAT inputs.

Measured resources: 7.468346 CPU seconds including child execution, 7.891774 wall seconds, 12,288 KiB self and 11,136 KiB child peak RSS. Charge 10 CPU seconds including short helper operations. Combined audit task charge is now 220 CPU seconds; measured total is 210.514766 CPU seconds across the three full main passes and rectangular supplement.

- Source: `source/test_tiny_rectangle.py`.
- Frozen spec and identities: `development/tiny-rectangle-grid.json` and `development/tiny-rectangle-prefreeze.sha256`.
- Final binary SHA-256: `e9f86df41dec1f3e8289d9e04d8c3faaf80a79ff8ea5188b38ce136bd7bb6b65`.
- Solution-set stream SHA-256: `bcfcf844257cc7cad172892f2afc4b867bd0db91bc5b13e387fe76efb781f7d3`.

No 97-letter fixtures were created, no target ciphertext was loaded, and no main-suite files were overwritten.
