# Study 056: ciphertext-free coverage audit

2026-10-31 02:05 UTC. Read-only public repository inspection plus symbolic permutation/operator reconstruction. No K4 ciphertext read, supplied to a solver, decrypted, scored, or searched in this audit. No repository changes, installs, paid services, settings changes, or desktop retries.

## Decision

**Unknown short periodic Vigenere key followed by a freely ordered ragged columnar transposition is not fully covered by the inspected local studies.** But arbitrary keys and exact residue elimination are already present; neither is new. The substantive added model domain is arbitrary column order, and the proposed methodological addition must be reusable conflict learning on *partial* column/order assignments, benchmarked against completed-order enumeration with exact key elimination.

Widths alone do not certify novelty. Depth-three 050 compositions produce some direct columnar permutations even at widths 6 and 9 although their explicit columnar primitives have widths 7, 8, and 10.

## Pin and primary inspected sources

Current public main is [`5b6cd7ac47d35a7afdd26a9d0109d95a726b2067`](https://github.com/reggiechan74/kryptos-k4/commit/5b6cd7ac47d35a7afdd26a9d0109d95a726b2067), verified through GitHub's commits API. This is the archive-only strategy-review commit; algorithm research snapshot remains `de3654a098162185d47b7c14ee1eef1631ab1804`.

Source paths below are relative to [the pinned tree](https://github.com/reggiechan74/kryptos-k4/tree/5b6cd7ac47d35a7afdd26a9d0109d95a726b2067):

- `experiments/finite_hand_operators.py`, Git blob `dbe68d5e0834b9c64ce3805a951b3221b53005f3`.
- `experiments/hand_grammar_050.py`, blob `e8ec2c67443134cdd2208ad0d9a44cda7b81a61d`.
- `experiments/bounded_models.py`, blob `a6daad22fefffb70834689521b6735fb5f08367e`.
- `experiments/route_key_graph.py`, blob `0cd22a7a5739d65dee127cc2dc1f8c1dbc04c092`.
- `experiments/k3_clock_routes.py`, blob `a425a46646ccc7872fc2a4f09e55625c9f921220`.
- `experiments/occupied_cell_routes.py`, blob `cd95a88996332d57a8fb0b182a2d0f2b3e0ae992`.
- `experiments/ene_route_049.py`, blob `3a7bd5258bfce301d37c9c4934b369b338343adf`.
- `research/HAND-GRAMMAR-050-SPEC.md`, `HAND-GRAMMAR-050-FINDINGS.md`, `048-050-PRIOR-COVERAGE.md`, `BOUNDED-SPEC.md`, `BOUNDED-FINDINGS.md`, `AUTOKEY-CONSTRAINT-FINDINGS.md`, `ENE-ROUTE-049-SPEC.md`.
- `research/specifications/K3-CLOCK-ROUTES-001.json`, `OCCUPIED-CELL-ROUTES-001.json`.

## Exact prior scopes

### ROUTE-001 — generic keys were already tested

66 fixed complete permutations, generated from ragged row-major fills at widths `7,14,21,24,31,42`, row/column-major traversal, each row/column direction, inverses, and identity, then deduplicated. Nonidentity route periods `1..16`; identity periods `1..96`. A–Z and KRYPTOS alphabets; addition, subtraction, Beaufort; both substitution-before-route and route-before-substitution (identity order deduplicated).

The key is an arbitrary vector of residues, **not** one of three words. `constrain()` computes the required key residue at each known plaintext position, rejects when two requirements for a phase differ, and returns unobserved phase values as `None`. Thus it represents the whole `26^period` key domain without enumeration. Completed-route scans already eliminate generic keys exactly. A 056 brute-force-key baseline would be an artificially weak comparator.

### 050 — fixed-key finite affine grammar

The only alphabet is KRYPTOS. Exactly 38 primitive descriptions:

- 6 columnar maps: row-major ragged keyword columns, stable ordinary A–Z keyword sort, direct/inverse for `KRYPTOS`, `PALIMPSEST`, `ABSCISSA` (widths 7,10,8).
- 22 skip maps: steps 2..12 and modular inverses, fixed origin 0.
- 1 reversal.
- 9 arithmetic maps: each of those three repeated literal keys, `x+k`, `x-k`, `k-x`, phase zero.

All words of depth 0..3: 56,355 descriptions, canonical `(p,s,b)` operator equality, 27,323 unique operators. No arbitrary keys, phases, additional alphabets, or arbitrary column permutations. The receipt explicitly sets `unrestricted_keys_tested=False`. Its conservative old overlaps were 470 operators in ROUTE-001 and 89 in 049; these marginal sets are not disjoint evidence counts.

### 049 — wide route set but fixed keys

34,569 distinct routes from three fully defined ENE-like read procedures, widths 1..97, 97 starts, both inverses. 19 arithmetic variants: identity/no arithmetic, or 2 alphabets × 3 equations × 3 literal keys. Only decoding route-then-arithmetic order. `free_key_family_tested=False`.

### K3/clock and the graph solver

KRYPTOS alphabet, addition only. Fixed K3-like route `T = U14 after U42`, with `U` meaning ragged row fill followed by columns left-to-right and rows bottom-to-top. Periods 8 or 10, arbitrary key, both orders: 4 structures. Clock family: 96 formal width-24 column routes (24 rotations × 2 cyclic directions × 2 row directions), same periods/orders: 384 formal structures, 16 previous-route aliases, 368 new. It also tested **two generic periodic keys around a fixed T**, with period pairs (8,10) and (10,8).

`route_key_graph.py` already solves this sandwich's modular equations using component potentials, cycle conflicts, free offsets, exact key counts `26^c`, and plaintext-relevant component freedoms. It does not make the route/order unknown; the graph is built after the structural choice. Rebranding modular graph elimination as new would be wrong.

### Occupied-cell routes

Eight fixed routes from a 4×31 physical transcription occupancy mask (first row occupied only in its final four cells), four columnwise direction pairs and inverses. Only literal PALIMPSEST/ABSCISSA with all 18 cyclic phases, both stage orders; 288 fixed branches. Not a free-order columnar family.

### Autokey

1,152 direct forward fixed-alignment configurations: 2 alphabets × 3 equations × 2 feedback modes × lags 1..96. Initial lag-many symbols are arbitrary independent primer entries, **not periodic**; afterward key is previous plaintext or ciphertext at the lag. No transposition included. Propagates constraints through unknown plaintext chains. This is not the proposed repeating-key/unknown-column-order composition.

## Executed symbolic novelty certificate

Artifacts:

- `/workspace/shared/k4-056-permutation-novelty-certificate.json`
- `/workspace/shared/k4-056-permutation-novelty-certificate.py`
- `/workspace/shared/k4-056-permutation-novelty-extra.py`

Run the extra script to reconstruct the combined certificate. It reads no repository data and contains no ciphertext. This is a coverage calculation, not a target experiment.

The reconstruction independently generates all 27,323 canonical 050 operators and confirms the permutation-only reconstruction matches their projection. There are 7,985 distinct permutations. It also reproduces the published cardinalities 66 ROUTE-001 routes, 34,569 049 routes, 97 K3/clock routes, and 8 occupied-cell routes.

Direct arbitrary column orders at widths 6..9 give `6!+7!+8!+9! = 408,960` distinct permutations. Different widths cannot alias here: the first two entries within the first column differ by width (each column has at least 10 entries). At a fixed width the complete source permutation identifies column order.

050 permutation intersections number 2,4,6,2 respectively at widths 6,7,8,9: 14 in total. Therefore **at least 408,946 direct permutations, and every key attached to those permutations, are outside 050's operator closure**. This is a conservative lower bound: sharing one of the 14 permutations does not imply its arbitrary key is covered by 050. ROUTE-001 has exactly two overlaps, width-7 ascending and descending columns. 049 has zero direct-columnar permutation overlap at these four widths.

Explicit witness orders, zero-based original columns:

| Width | Output column order |
|---|---|
| 6 | 2,0,5,1,4,3 |
| 7 | 2,0,5,1,6,4,3 |
| 8 | 2,0,5,1,7,6,4,3 |
| 9 | 2,0,5,1,8,7,6,4,3 |

Each witness's direct and inverse permutation is absent from all five reconstructed sets. The JSON retains full source-index lists and SHA-256s. This proves the proposal is not merely a rename of a previously exhaustively tested local operator family. It does **not** prove the whole proposal is disjoint from all prior models, does not claim worldwide novelty, and does not imply K4 belongs to the family.

### Why permutation nonmembership proves operator nonmembership

Each fixed affine/periodic substitution plus transposition is coordinatewise: output coordinate j depends bijectively on exactly one input coordinate p(j). If two operators use different p at any output j, vary only the input coordinate p(j); one output changes and the other's does not. Thus they cannot be identical on all 97-symbol inputs, irrespective of key vector or alphabet renaming. This proof does not rely on equality on a single ciphertext or on plaintext assumptions.

### Aliases and fair comparison

For eventual operator-level overlap compare full `(p,s,b)` in the same alphabet coordinates; where alphabets differ use the full 26-symbol per-coordinate lookup table or the above permutation nonmembership proof, not a false affine-coordinate identification. For generic keys, canonicalize the equality partition of key phases together with complete p; retain key-period divisibility aliases and offsets explicitly. Addition versus subtracting arbitrary keys is a key-negation alias, not new evidence. A fixed phase is also redundant when the full key is arbitrary.

Retain prior overlaps inside the benchmark if desired so both algorithms solve the same full preregistered domain, but report old/new classes separately. Never treat the mere number of descriptions or a SAT witness as distinct recovered keys or plaintexts.
