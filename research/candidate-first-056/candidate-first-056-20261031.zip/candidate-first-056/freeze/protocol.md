# Study 056: bounded periodic substitution and ragged columnar transposition

**Design decision, version 2, 2026-10-31. Status: approved for a bounded, synthetic-only implementation pilot; not approved for target cryptanalysis.**

Select one order only: standard-alphabet periodic Vigenère, followed by row-filled, unpadded, top-to-bottom keyed columnar transposition. Freeze width 6–9 and nominal key period 2–8. Unknown column order, width, period and all key letters must be inferred jointly. Do not add the reverse stage order, different alphabets, Beaufort variants, extra routes, offsets, padding, plaintext themes or longer keys after seeing results.

The reason to select this family is not a claim that Sanborn used it. It is a historically ordinary, hand-executable composition with a genuinely new bounded operator domain, useful cross-stage consistency constraints, and an exact enumerative reference small enough to audit. Its principal risk is that ordinary propagation may already solve almost everything, leaving no useful role for learned conflicts. That is a legitimate negative result for the proposed method, not grounds to make the problem harder after the fact.

### Pre-score correction from version 1

Version 1 (SHA-256 `06bbf6d078d7fdb99ca8b2f97c01886e8fd494b16ce1043a298b474f0489b141`) is preserved as `k4-056-family-protocol-v1-superseded.md`. Before any benchmark run or scores, review identified an invalid pooled false-fit gate: changing a ciphertext symbol whose source is a noncrib plaintext position preserves the original route/key and every clue. Such corruptions are often deliberately in-family, not false-positive examples. Version 2 restricts the uniform-reference unique-fit threshold to 56 independently generated uniform-ciphertext cases and treats all 56 corruption cases as correctness/sensitivity diagnostics. Fixture counts and all other gates remain unchanged. The revised manifest/hash must be frozen before generating the held-out inputs.

## 1. Authority and boundaries

The user approved selecting/specifying one bounded multi-stage family and benchmarking joint constraints against the existing approach. This document implements the strategy report's priority-two design. During this design phase: public-repository reads, scratch documents, tiny synthetic design probes and ciphertext-free coverage calculations are allowed; no repository mutation, actual K4 solver run, paid checker, package installation, settings change or retry of the usage-blocked desktop service. The implementation phase may operate in the current authorized cloud execution workspace. No actual K4 ciphertext is an input to development, fixture generation, solver tuning or the benchmark.

A passed benchmark earns a recommendation for one narrowly bounded target experiment, not automatic permission to execute it. Stop at that gate and present the evidence/next action to the parent/user. The strategy report explicitly says a passed pilot does not itself establish the historical family.

## 2. Historical rationale and limits

Friedman's *Military Cryptanalysis, Part IV*, section 36 (printed p. 96 in the 1941 edition), describes applying transposition after polyalphabetic substitution and records a historical system combining four standard alphabets with keyed columnar transposition in incomplete rectangles. The source also warns about practical complexity and discusses the importance of the relationship between the two key lengths. This supports the **general manual composition**, not these exact bounds, periodicity, alphabet convention or any attribution to Kryptos. Width/period bounds are deliberately small engineering limits, not historical evidence.

Primary source: [NSA-hosted Part IV, section 36](https://www.nsa.gov/portals/75/documents/news-features/declassified-documents/friedman-documents/publications/folder_263/41761079080022.pdf). An [alternative NSA edition, section 36, printed p. 112](https://www.nsa.gov/portals/75/documents/news-features/declassified-documents/friedman-documents/publications/FOLDER_452/41749819078904.pdf) corroborates the passage. Search extraction supplied the section text; a whole-PDF open was size-limited. No claim is made that this source specifies our exact cipher.

This is not pure transposition or a direct fixed monoalphabetic map. Those direct K4 models are already structurally contradicted; their contradictions do not transfer unchanged through this separately specified position-dependent substitution plus permutation.

## 3. Exact mathematical family

- Length `N = 97`; alphabet `A..Z = 0..25`; arithmetic modulo 26.
- Plaintext `P[0..96]` is any 97-symbol string. No language model, candidate bank, dictionary or per-letter exception is part of this experiment.
- Width `w ∈ {6,7,8,9}`.
- Nominal period `p ∈ {2,3,4,5,6,7,8}`; seed `K ∈ Z_26^p`, unrestricted. Key phase is fixed at plaintext index zero. No independent phase parameter.
- Intermediate `S_i = P_i + K_(i mod p) mod 26`.
- Write `S` left-to-right across rows of width `w`, starting at row zero/column zero, with no padding. Physical column `c` contains indices `c, c+w, c+2w, ... <97`; its length is `L_c = floor((96-c)/w)+1`.
- The column key is a permutation `π` of `0..w-1` in **emission order**, not rank labels. Emit each column top-to-bottom in that order. This numerical order is the key; keyword spelling is not searched.
- If column `c=π_j` begins at ciphertext offset `s_j = Σ_(h<j) L_(π_h)`, then `C_(s_j+r) = P_(rw+c) + K_((rw+c) mod p)` for every existing row `r`.
- Decryption splits ciphertext into these known column lengths in emission order, puts the symbols into their physical columns, reads rows, then subtracts the periodic key. This inverse is global, with no resets at cribs, row boundaries or gaps.

Every primary fixture supplies only ciphertext and 24 `(plaintext_position, literal_plaintext_symbol)` pairs. The fixed mask is zero-based `21..33` and `63..73` (one-based 22–34 and 64–74). The solver is **not** handed the generating width or period. It searches the entire frozen union for every fixture. Known-width or known-period experiments, if any, are labeled diagnostics and excluded from the main performance/recovery claim.

## 4. Domain, aliases and completeness

There are `6!+7!+8!+9! = 408,960` distinct routes and `7 × 408,960 = 2,862,720` completed nominal `(w,p,π)` trials. The fair reference does **not** enumerate `26^p` keys: each route transports the 24 clues and derives the key slots directly. A 13-position contiguous clue block covers every residue for every allowed `p`, so a compatible completed trial fixes every key symbol. At most one seed survives each completed trial. All 97 plaintext symbols then follow exactly; none are filled by prose generation or a free running key.

Raw descriptions: `408,960 × Σ_(p=2..8)26^p = 88,817,992,971,102,720`. This is a mathematical domain count, not the number of loop iterations or independently tested keys. Key elimination is the completeness-preserving reason the reference needs only 2,862,720 route/period trials.

Canonical operator: retain the output-to-input permutation `τ` and the 97-position plaintext-indexed shift stream `H_i=K_(i mod p)` (equivalently the exact affine operator after transport). Repeated shorter seeds are aliases, not discoveries. Minimal effective period `d=1..8` has primitive stream counts:

| d | Primitive seeds | Nominal-period aliases in 2..8 |
|---|---:|---:|
|1|26|7|
|2|650|4|
|3|17,550|2|
|4|456,300|2|
|5|11,881,350|1|
|6|308,897,550|1|
|7|8,031,810,150|1|
|8|208,826,607,600|1|

The primitive count is `M(d)=26^d−Σ_(e|d,e<d)M(e)`. For d≥2 aliases are nominal multiples of d through 8; a constant seed has all seven nominal descriptions. Length 97 is sufficient to avoid different short-period streams agreeing merely because the observation is too short. Distinct routes have distinct input dependency permutations; widths also differ because adjacent entries within the first emitted column have index gap w. Thus the canonical domain has `217,179,671,176` shift streams and **88,817,798,324,136,960 distinct operators**. Keep raw descriptions, canonical operators and distinct plaintexts as separate counts.

All methods may run the nominal domain and deduplicate outputs. If an implementation canonicalizes the domain before search instead, prove equivalence and apply the same convention to every method. Aliases must remain reconstructible.

## 5. Prior coverage audit and positive novelty certificate

Audit base: algorithm snapshot `de3654a098162185d47b7c14ee1eef1631ab1804`; current main observed `5b6cd7ac47d35a7afdd26a9d0109d95a726b2067`, whose later strategy-report publication does not change the audited algorithms. Claims are about inspected code/records, not every possible off-repository experiment.

- **ROUTE-001 already used arbitrary periodic keys.** It tested 66 fixed routes, both operation orders, periods 1–16 (identity route through 96), two alphabets and three arithmetic equations. Its `constrain()` derives residues and rejects repeated-phase contradictions. Generic unknown keys are not new.
- **K3/clock graph work already inferred unrestricted periodic keys around fixed routes**, using modular components/cycles. Graph elimination, exact propagation and arbitrary keys are not new algorithm categories here.
- **050** used 38 fixed primitives and words of depth 0–3: fixed keyword columnars/inverses for KRYPTOS/PALIMPSEST/ABSCISSA; fixed skip operators/inverses 2–12; reversal; fixed-key arithmetic. It canonicalized 56,355 words into 27,323 affine operators. Its receipt says unrestricted keys were not tested. Primitive/key details and historical scope are retained in the companion coverage notes.
- **049** has 34,569 route permutations and fixed-key arithmetic, not arbitrary column-order inference.
- Autokey's symbolic unknown-gap propagation is not a test of this periodic-key-plus-unknown-column-order composition. Its scope is separately recorded in the coverage notes; do not describe all autokey or all compositions as excluded.

The scratch certificate independently recompiles all 27,323 canonical 050 operators and obtains **7,985 distinct permutation components**. Among all 408,960 new routes, only 14 permutations occur in that projection: 2 width-6, 4 width-7, 6 width-8 and 2 width-9. Hence **at least 408,946 routes, with every permitted key on each, are outside 050** solely by their input dependencies. The 14 overlaps are retained in the family and must not be counted as wholly new operators without comparing offsets/alphabet semantics. ROUTE-001 overlaps two width-7 routes; the audited 049 set overlaps none.

Explicit new emission orders (also absent in inverse direction):

- w6: `2,0,5,1,4,3`
- w7: `2,0,5,1,6,4,3`
- w8: `2,0,5,1,7,6,4,3`
- w9: `2,0,5,1,8,7,6,4,3`

Different input dependencies prove operator inequality independently of shifts and alphabet names. Certificate artifacts: `/workspace/shared/k4-056-permutation-novelty-certificate.json`, matching `.py`, and `k4-056-permutation-novelty-extra.py`; these calculations read no target ciphertext. They are positive witnesses of new coverage, not an assertion that every new description is novel.

Source anchors: [finite operators](https://github.com/reggiechan74/kryptos-k4/blob/de3654a098162185d47b7c14ee1eef1631ab1804/experiments/finite_hand_operators.py), [050](https://github.com/reggiechan74/kryptos-k4/blob/de3654a098162185d47b7c14ee1eef1631ab1804/experiments/hand_grammar_050.py), [route graph](https://github.com/reggiechan74/kryptos-k4/blob/de3654a098162185d47b7c14ee1eef1631ab1804/experiments/route_key_graph.py), [audit](./k4-repo-algorithm-audit.md), [published strategy report](https://github.com/reggiechan74/kryptos-k4/blob/5b6cd7ac47d35a7afdd26a9d0109d95a726b2067/research/strategy-review-20261031/REPORT.md).

## 6. Shared placement constraints

For fixed w,p, a placement literal `X(c,s)` says physical column c starts at ciphertext offset s. Every clue `i=rw+c` derives a local requirement `K_(i mod p)=C_(s+r)−P_i mod26`. Store its provenance `(i,c,s,residue,value)`.

- **Unary conflict:** two clues within the same placement demand different values for one residue. Learn `not X(c,s)`.
- **Binary conflict:** placements `X(c,s)` and `X(d,t)` demand different values for the same residue. Learn `not X(c,s) OR not X(d,t)`.
- Placements for distinct columns must have disjoint half-open ciphertext intervals `[s,s+L_c)`. Selecting all columns then covers exactly 97 positions; overlap is forbidden and the total length is 97.
- A candidate start s is permitted only if it is a subset sum of lengths of other columns (a possible preceding set). Keep the exact s, not merely the rank. Ragged lengths mean a rank alone does not determine the mapped ciphertext letters.
- Assignment/domain propagation enforces one placement per column, non-overlap and shared-residue agreement; require all supports for every remaining placement, not just agreement with one greedily selected key.

These unary/binary exclusions are genuinely reusable across different prefix orders or search branches because each is implied solely by its literal placements and fixed instance data. They are not general across changed ciphertext, crib values/mask, alphabet, width, period or stage order. Cache namespace includes a hash of all those semantics. Never carry a learned cipher-dependent conflict from one synthetic fixture to another or to K4.

For a prefix-search implementation, `(used_column_bitset, partial_key_vector)` completely specifies the future feasibility subproblem: the next offset is the sum of used-column lengths. An **exhaustively failed** such state can be cached and reused under another prefix order. Do not cache a merely interrupted or unsearched state as failed. Do not skip satisfiable repeated states when enumerating distinct full outputs, since different prefixes can give different plaintexts. Every failed-state receipt must identify the exhaustive children/reasons; a cache key with only the used subset is unsound.

## 7. Required comparison: four exact methods

All four receive identical sanitized inputs and search the full unknown-width/unknown-period family. All use the same implementation language/runtime where practical, ordering policy, CPU/memory limits and static placement tables. Output canonical solutions, not only best guesses.

1. **E — completed-candidate enumeration.** Generate each full π; transport cribs; perform direct key-residue elimination/consistency as ROUTE-001 already did. Do not deliberately handicap this baseline with `26^p` seed brute force, plaintext enumeration, disabled early rejection or a slower language.
2. **P — prefix propagation.** Build π incrementally, propagate forced key residues immediately and backtrack on conflict; no learned-conflict/failed-state caches. This measures the benefit from not waiting for a completed route.
3. **S — shared placement CSP without learning.** Use the same placement representation, variable ordering and support propagation as L, but recompute exact compatibility tests instead of retaining learned modular conflicts or failed-search states. Static geometry/alphabet bookkeeping may be shared by both; label preprocessing costs.
4. **L — same CSP with learned exclusions.** Keep static placement compatibility identical to S. In addition, track decision explanations for domain deletions: a decision explains its eliminated alternatives; when a value loses every support in a neighbor, union the explanations for those lost supports; a domain wipeout yields an impossible conjunction of decisions. Store that conjunction as a learned nogood, with its derivation, and apply it on later branches (including last-literal propagation). Optional deletion minimization must replay sound propagation. Unary/binary modular conflicts may also be cached, but distinguish those analytic relations from dynamically derived conflicts and from full failed-state certificates. Retain a cache only after its reason is established. Report later cross-branch hits separately; initial compatibility-table construction is not learned-conflict novelty.

If failed-state caching is implemented in the prefix representation rather than the CSP, also run a P-with-cache ablation; do not compare unlike search orders and attribute all gain to learning. Implementation details freeze after development and before blind testing.

Report preprocessing plus solving CPU/wall time, peak memory, completed route trials, placement/support checks, visited states, conflict discoveries, later hits (excluding discovery), hits from a different prefix/branch, first-witness time and time to complete the projected solution set. Count unique certified prunes, not the number of syntactic descriptions under a pruned prefix as if they were individually evaluated. Use no solver-brand novelty claim.

## 8. Exact output and identifiability

Return one of `UNSAT_COMPLETE`, `SAT_COMPLETE_UNIQUE_PLAINTEXT`, `SAT_COMPLETE_MULTIPLE_PLAINTEXTS`, or `INCONCLUSIVE` with a partial witness/count lower bound. An early first witness is never a complete result. Report separately:

- raw compatible descriptions and canonical operator/key count;
- distinct complete plaintext count;
- whether the planted canonical operator and full 97-letter plaintext are recovered;
- whether each of the 73 noncrib positions is forced across all completions;
- two explicit unequal plaintext witnesses whenever ambiguity exists;
- aliases associated with each operator, and different operators yielding the same particular plaintext.

Full enumeration is feasible in principle because only 2,862,720 nominal route/period trials exist. If a solver uses a second-witness query, separately block the complete plaintext and separately block the canonical operator; these are different uniqueness questions. Do not equate no second witness before a timeout with uniqueness. Every returned witness must independently re-encrypt all 97 symbols and satisfy all 24 supplied clues.

All physical columns have at least two cribs for these widths, and all key slots are observed. However that does not prove route uniqueness. Common factors of w,p can split incidence components, and repeated/equal crib patterns can preserve column ambiguity. This must be measured, not concealed by language scoring.

## 9. Independent oracle and tiny exhaustive soundness gate

The reference encryptor must be independently written from a literal row matrix and column concatenation, not call production placement/index routines. Its inverse independently splits columns, reconstructs rows and subtracts the key. Known-answer vectors must include each width, both long/short columns, identity/reversal/irregular orders, constant keys and repeated-period aliases.

Before 97-letter benchmarking, exhaust tiny generalized alphabets A={0,1} and A={0,1,2}, lengths 5–9, widths 2–4 and periods 1–3. Freeze a finite grid small enough to finish inside the phase cap: enumerate every ciphertext and every partial-clue assignment for A=2,N=5,w∈{2,3},p∈{1,2}; enumerate all keys/routes/plaintexts with fixed full/partial/empty masks for additional N=7,9 cases. Document exact counts and masks before execution. Empty/missing-residue cases deliberately test free-key handling, even though those cases cannot arise under the primary 97-letter mask.

Compare complete projected operator and plaintext sets against independent brute force. Include UNSAT, unique, ambiguous, aliases, ragged-length boundary cases and invalid-placement conflicts. For every learned nogood in the tiny suite, independently enumerate every concrete completion containing its premises and verify none is a solution. Check the failure-state cache against an uncached exact traversal. Required tolerance: **zero missing/extra solutions and zero unsound exclusions**. Any discrepancy blocks the benchmark until fixed and the full tiny suite is rerun. A fixed benchmark bug after unblinding requires a newly generated holdout; preserve the failed run.

## 10. Blinded 97-letter fixture plan

No target ciphertext, crib-derived target key fragment or target output is used. An independent fixture author owns the generator and answer manifest. It emits random opaque fixture IDs, ciphertext, mask and literal clues only. Generating w,p,key,π,plaintext,class,seed and expected assertions remain in an answer file unavailable to the solving harness until outputs/timings are finalized. The solver always searches all 28 (w,p) cells, never learns the generating cell from a filename/function argument. This is procedural blinding in a shared workspace, not a claim of cryptographic access isolation.

Use separate development and held-out namespaces/seeds. Commit hashes of the generator, independent encryptor, fixture-input manifest and answer manifest before the held-out run; reveal answer seeds only afterward. Choose seeds with the operating system random source, not by retaining easy instances. No fixture rejection on solver runtime, uniqueness or whether a plant lies in the older operator overlap.

### Primary positives: 112 fixtures

One independently keyed fixture for each of 28 (w,p) generating cells in each of four classes. Generate a random primitive seed of that exact p for stratification and a uniform column order. Generate the full plaintext first, then apply the stated crib-pattern construction before encryption:

- **U (28):** independent uniform A–Z plaintext at all 97 positions; varied unrestricted literal/equality patterns.
- **R (28):** outside-clue letters uniform; at the 24 clues, choose eight distinct letters uniformly and place each three times in a uniformly shuffled order. This repeated-symbol challenge is reported separately for identifiability.
- **J (28):** outside-clue letters uniform; at the mask use the equality pattern of `EASTNORTHEAST` / `BERLINCLOCK`. Apply one uniformly random bijection of A–Z to this complete 24-letter literal reference, preserving its equality pattern but changing actual symbols.
- **L (28):** outside-clue letters uniform; at the mask insert the exact literal reference `EASTNORTHEAST` (13 letters) / `BERLINCLOCK` (11 letters). Assert both lengths and all 24 coordinate assignments before encryption. These are explicitly artificial fixed-pattern stress fixtures, not English prose or new K4 evidence.

Literal reference validation: `len("EASTNORTHEAST")==13`, `len("BERLINCLOCK")==11`; the two blocks occupy exactly the declared mask. Neither ciphertext nor target-derived key fragments accompany these plaintext-only stress patterns.

Because no language scoring is used, random noncrib text is a deliberate clean test of arithmetic recovery rather than a weakness repaired by prose. Optional source-prose diagnostics can be added only before holdout freeze, with separate document/source manifests, and do not replace these declared controls.

### Additional diagnostics: 32 fixtures

- **16 alias/degeneracy positives:** eight constant/short-period alias cases and eight highly repetitive or constant-crib cases, balanced over widths. Retain and count all aliases/ambiguities; do not require these to identify a unique plaintext.
- **16 model-mismatch plants:** eight reverse-order compositions (columnar then periodic substitution), four width-5/10 cases, four effective-period-9 cases. These are outside-family generators, **not automatically negative inputs**: an in-family explanation may coincidentally exist. The reference solution set is authoritative.

### Uniform-reference controls and corruption diagnostics: 112 fixtures

- **56 uniform-reference controls:** independently uniform ciphertexts with independently sampled clue literals, preserving the same 24-position mask, balanced across U/R/J/L clue-pattern classes. Only these 56 cases enter the unique-fit calibration threshold in gate 6.
- **56 corruption diagnostics:** corrupted in-family plants, balanced across classes; change one uniformly selected ciphertext symbol to a different symbol without changing clues. Preserve the original ciphertext/plaintext/key/order, modified ciphertext index, nonzero modular change and corresponding underlying plaintext index in the withheld answer manifest. If that plaintext index is outside the 24-position crib mask, the original route/key is guaranteed compatible: changing just that plaintext letter by the same modular increment exactly re-encrypts the modified ciphertext and leaves every clue unchanged. The expected fraction is 73/97 under uniform index selection, but do not condition or resample to force that count. Independently verify this retained operator and modified plaintext in every such fixture. If the affected plaintext index is a crib, the original operator no longer satisfies the unchanged clues; use the exact reference for any alternative solutions. These are sensitivity/correctness tests, **not false-fit controls**, and they have no low-SAT or low-uniqueness-rate acceptance threshold.

Total held-out input count: **256**. Report compatible and unique-fit rates separately for the 56 uniform-reference controls, 56 corruption diagnostics and 16 model-mismatch plants; never pool them into a false-fit rate. Report exact confidence intervals for each stratum. No “success” based on fluent output is possible because there is no LM. A method must agree with exact compatibility even when an intended mismatch admits an in-family solution.

## 11. Resource policy and frozen acceptance numbers

The entire pilot shares **8 CPU-hours and 8 GiB peak memory**, including development, preprocessing, repeated timing runs and all four benchmark methods. CPU is summed across processes/agents, not wall time multiplied away by parallelism. No package installs or paid infrastructure. Record runtime/compiler/library versions and hardware; use already available tools only.

- Initial soundness/development tranche: at most **45 CPU-minutes**, at most 12 new 97-letter development fixtures, and the declared tiny suite. Existing exploratory design probes are disclosed separately and never called blind tests.
- Each primary engine/fixture call: **20 CPU-seconds and 2 GiB**. Stop that call cleanly at the limit; incomplete is not UNSAT. Maximal 256×4×20-second calls consume about 5.69 CPU-hours, leaving room under the shared cap for development and audit. Timing repetitions, if used, must fit the same total cap; freeze their rule before holdout.
- If the initial tranche shows the full declared benchmark cannot be run under these limits, stop and report feasibility. Do not selectively shrink the hard cells or secretly move to longer budgets. Any revised protocol is a new pre-unblinding version; preserve this one.

Preregister these gates before opening held-out answers. Designate the deployment method W from {P,S,L} **on development data only**, using smallest complete end-to-end CPU time, with ties favoring the simpler method. Freeze W before the holdout. Method admission and a positive claim about learning are separate decisions; failure of the learning-specific gate does not undo a verified propagation gain.

1. **Correctness:** zero tiny-suite errors/unsound exclusions; zero full-fixture mismatches among completed methods; every witness independently re-encrypts exactly.
2. **Completion:** W completes all 256 full-union fixtures under per-case/global limits. E completes at least 95% (244/256); otherwise useful speed claims require only the censored completion comparison and the target gate remains closed in this pilot.
3. **Identifiability:** in U+J+L (84 ordinary/equality-matched/literal-pattern positives), at least **80/84** have a unique complete plaintext equal to the plant; at least **26/28 literal L** are uniquely recovered. R and degeneracy fixtures are correctness/ambiguity diagnostics, not quietly dropped failures. Report exact binomial confidence intervals, all per-class counts and full-key/operator uniqueness separately. Report compatibility with the plant even when uniqueness fails.
4. **New representation value:** paired end-to-end geometric-mean CPU speedup W/E ≥ **2.0**, and deterministic paired bootstrap 95% lower bound > **1.25** on common completed instances; include preprocessing and all width/period choices. Also report capped all-case times and completion rates to avoid survivor-only timing claims.
5. **Learning-specific claim, not a target-admission condition:** L/S speedup ≥ **1.20** with paired-bootstrap lower bound > **1.00**, and at least **50 demonstrably cross-branch reused dynamically derived nogoods or exhaustive failed-state certificates** across at least **10 held-out fixtures**. Analytic compatibility-table entries, aliases and same-branch repeated checks do not qualify. If this fails, report no demonstrated learning benefit and prefer the simpler method. Gates 1–4 and 6 may still support proposing the bounded new-family target test; do not relax or rewrite this distinction after seeing results.
6. **Uniform-reference calibration:** at most **1/56** independently generated uniform-ciphertext controls may have a unique in-family plaintext if proposing a target uniqueness claim. This is a preregistered engineering policy, not a project-wide p-value or proof of Sanborn intent. Corruption diagnostics and mismatch plants are excluded from this denominator and threshold. Their SAT/unique rates are reported separately without treating valid in-family fits as false positives. Every noncrib corruption must include the guaranteed retained original operator and the corresponding one-letter-modified plaintext; all other solution-set assertions must agree with the exact reference.

The timing bootstrap resamples paired fixture IDs 10,000 times with a preregistered fixed analysis seed and computes the geometric mean ratio on each sample. Sub-millisecond tests are timed as fixed batches under the same rule for both methods; never divide rounded zeros. Timeouts are censored, not filled with invented completion times. Both the numerical gates and the no-expansion rule are deliberately conservative. Their failure is useful evidence about this design, not exclusion of wider classical ciphers.

## 12. Existing exploratory observations and stopping rule

A theory reviewer made a small **nonblind synthetic-only design probe** before this protocol: 18 single-cell fixtures over six (w,p) combinations; pairwise placement propagation solved 17 at the root, while a constant-crib w=p=8 case had 12 witnesses. No target ciphertext was used. These are a tractability warning and a concrete ambiguity example, not held-out evidence, full-union recovery rates or timing claims. Preserve the probe source/seed receipt with the implementation record.

This observation is why the learning ablation is compulsory. Do not widen widths/periods, change clue strength, hide baseline optimizations or add extra stages to obtain impressive learned-conflict numbers. If S is already sufficient and L adds no measured value, conclude precisely that the new family has a tractable shared-constraint representation but the pilot did not justify learned-conflict machinery. A verified P/S method with material benefit over E may still pass the separate method-admission gates; this distinction is frozen before benchmarking.

## 13. Required deliverables and target gate

Implementation deliverables: frozen machine-readable family/benchmark manifest; two independent encrypt/decrypt implementations; E/P/S/L code; tiny exhaustive solution-set and nogood-verification receipts; complete blinded-input/answer hashes; per-instance raw metrics and complete solution-set hashes; canonical/alias projections; independent replay report; CPU/memory accounting; coverage certificate; explicit pass/fail table for every gate.

Before any target run, independently review literal conventions, novelty, soundness, full-domain completion and identifiability. Present whether each gate passed and propose exactly one bounded full-family run if warranted. A later target witness would require full re-encryption, all public cribs, a compact reproducible procedure, operator/plaintext uniqueness checks and independent validation; even then it is only model-conditional compatibility. Exhaustive UNSAT would exclude only the frozen family. Timeouts, weak uniqueness, insufficient method lift or excessive synthetic false fits keep the target gate closed. Failure of learning lift alone bars the learning claim, not a target proposal supported by a verified simpler shared-constraint method.
