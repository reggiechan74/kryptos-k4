import itertools, json, hashlib
N=97
I=bytes(range(N))
def inv(p):
 o=[0]*len(p)
 for i,j in enumerate(p):o[j]=i
 return bytes(o)
def col(w,order):return bytes(i for c in order for i in range(c,N,w))
prims=[]
for key in ('KRYPTOS','PALIMPSEST','ABSCISSA'):
 p=col(len(key),sorted(range(len(key)),key=lambda i:(key[i],i)));prims.extend([p,inv(p)])
for s in range(2,13):prims.extend([bytes(i*s%N for i in range(N)),bytes(i*pow(s,-1,N)%N for i in range(N))])
prims.append(bytes(reversed(range(N))))
prims.extend([I]*9)
levels=[{I}]
for depth in range(3): levels.append({bytes(p[j] for j in r) for p in levels[-1] for r in set(prims)})
closure=set.union(*levels)
old={I}
for w in (7,14,21,24,31,42):
 h=(N+w-1)//w
 for major,rr,cc in itertools.product(('rows','columns'),(False,True),(False,True)):
  rows=list(range(h))[::-1 if rr else 1];cols=list(range(w))[::-1 if cc else 1]
  cells=itertools.product(rows,cols) if major=='rows' else ((r,c) for c in cols for r in rows)
  p=bytes(r*w+c for r,c in cells if r*w+c<N);old.update([p,inv(p)])
witnesses=[]
for w,order in [(6,(2,0,5,1,4,3)),(7,(2,0,5,1,6,4,3)),(8,(2,0,5,1,7,6,4,3)),(9,(2,0,5,1,8,7,6,4,3))]:
 p=col(w,order);ip=inv(p)
 witnesses.append(dict(width=w,column_order=list(order),encryption_output_to_input=list(p),encryption_permutation_sha256=hashlib.sha256(p).hexdigest(),decryption_permutation_sha256=hashlib.sha256(ip).hexdigest(),in050=p in closure,in_route001=p in old,inverse_in050=ip in closure,inverse_in_route001=ip in old))
assert len(old)==66
assert all(not r['in050'] and not r['in_route001'] and not r['inverse_in050'] and not r['inverse_in_route001'] for r in witnesses)
result=dict(no_ciphertext_read=True,N=N,old050_raw_primitive_count=len(prims),old050_distinct_permutation_primitives=len(set(prims)),old050_depth_permutation_counts=[len(x) for x in levels],old050_permutation_union_count=len(closure),old050_permutation_union_sha256=hashlib.sha256(b''.join(sorted(closure))).hexdigest(),old_route001_count=len(old),old_route001_sorted_permutation_sha256=hashlib.sha256(b''.join(sorted(old))).hexdigest(),witnesses=witnesses)
print(json.dumps(result,indent=2))
A='KRYPTOSABCDEFGHIJLMNQUVWXZ'
zero=bytes(N)
ops=[(p,1,zero) for p in prims[:29]]
for key in ('KRYPTOS','PALIMPSEST','ABSCISSA'):
 k=[A.index(key[i%len(key)]) for i in range(N)]
 for s,t in ((1,1),(1,-1),(-1,1)):ops.append((I,s,bytes(t*v%26 for v in k)))
def sig(op):p,s,b=op;return p+bytes([s%26])+b
def compose(x,y):
 p,s,b=x;r,t,c=y
 return bytes(p[j] for j in r),s*t,bytes((t*b[j]+c[i])%26 for i,j in enumerate(r))
allops={};previous=[(I,1,zero)]
for d in range(4):
 for op in previous:allops[sig(op)]=op
 if d<3:previous=[compose(x,y) for x in previous for y in ops]
assert len(allops)==27323
perms={p for p,s,b in allops.values()}
assert perms==closure
result['full050_canonical_operator_count']=len(allops)
result['full050_canonical_operator_sorted_bytes_sha256']=hashlib.sha256(b''.join(sorted(allops))).hexdigest()
result['full050_permutation_projection_equals_independent_projection']=True
with open('/workspace/shared/k4-056-permutation-novelty-certificate.json','w') as f:json.dump(result,f,indent=2);f.write('\n')
print('Full 050 operator count independently compiled:',len(allops))
