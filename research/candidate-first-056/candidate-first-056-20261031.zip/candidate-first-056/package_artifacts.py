#!/usr/bin/env python3
"""Build/validate the compact study archive without executing any solver."""
import hashlib,json,shutil,subprocess,tempfile,zipfile
from pathlib import Path
STUDY=Path(__file__).resolve().parent
COMMON=STUDY.parent
ROOTS=[STUDY,COMMON/'candidate-first-056-audit']
OUT=COMMON/'candidate-first-056-20261031.zip'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files():return sorted((p for root in ROOTS for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('OMISSIONS.json','ARCHIVE-CONTENTS.json')),key=lambda p:(len(p.parts),str(p)))
allfiles=files();seen={};omissions=[]
for p in allfiles:
    if p.stat().st_size<128*1024:continue
    h=sha(p)
    if h in seen:
        omissions.append({'path':str(p.relative_to(COMMON)),'copy_from':str(seen[h].relative_to(COMMON)),'size_bytes':p.stat().st_size,'sha256':h,'reason':'Byte-identical bulky derivative; retained once. Reconstruct by exact copy, not a target search.'})
    else:seen[h]=p
(STUDY/'OMISSIONS.json').write_text(json.dumps({'version':1,'omitted_exact_duplicates':omissions,'excluded_disposable_paths':['**/__pycache__/**'],'reconstruction_command':'python3 candidate-first-056/reconstruct_omissions.py','cipher_replay_required':False,'all_distinct_benchmark_inputs_answers_results_and_target_results_included':True},indent=2)+'\n')
allfiles+= [STUDY/'OMISSIONS.json'];omit={x['path'] for x in omissions}
inventory={'version':1,'files':{str(p.relative_to(COMMON)):{'size_bytes':p.stat().st_size,'sha256':sha(p),'archive_storage':'omitted_exact_duplicate' if str(p.relative_to(COMMON)) in omit else 'included'} for p in sorted(allfiles)},'inventory_self_hash':'Provided by the enclosing archive SHA-256; this file is not self-listed.'}
(STUDY/'ARCHIVE-CONTENTS.json').write_text(json.dumps(inventory,indent=2)+'\n')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(allfiles+[STUDY/'ARCHIVE-CONTENTS.json']):
        relative=str(p.relative_to(COMMON))
        if relative not in omit:z.write(p,relative)
extracted=Path(tempfile.mkdtemp(prefix='validate-056-archive-',dir=COMMON))
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None;z.extractall(extracted)
r=subprocess.run(['python3',str(extracted/'candidate-first-056/reconstruct_omissions.py')],check=True,capture_output=True,text=True)
for relative,item in inventory['files'].items():
    p=extracted/relative;assert p.stat().st_size==item['size_bytes'];assert sha(p)==item['sha256'],relative
freeze_counts={}
for relative in ['candidate-first-056/freeze/manifest.json','candidate-first-056/recovery-v2/freeze/manifest.json']:
    path=extracted/relative;root=path.parent.parent;m=json.loads(path.read_text())
    for p,h in m['hashes'].items():assert sha(root/p)==h,(relative,p)
    freeze_counts[relative]=len(m['hashes'])
path=extracted/'candidate-first-056/target/freeze/target-manifest.json';m=json.loads(path.read_text());root=extracted/'candidate-first-056'
for p,h in m['hashes'].items():assert sha(root/p)==h,p
freeze_counts[str(path.relative_to(extracted))]=len(m['hashes'])
report={'status':'PASS','archive':str(OUT),'size_bytes':OUT.stat().st_size,'sha256':sha(OUT),'payload_files_verified':len(inventory['files']),'omitted_exact_duplicates':len(omissions),'omitted_uncompressed_bytes':sum(x['size_bytes'] for x in omissions),'reconstruction':json.loads(r.stdout),'final_freeze_hash_counts_verified':freeze_counts,'extraction_directory':str(extracted),'zip_crc_errors':0,'target_searches_during_validation':0}
(COMMON/'candidate-first-056-archive-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
