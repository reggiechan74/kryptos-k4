#!/usr/bin/env python3
"""Restore exact duplicate artifact bytes. Does not run any cipher/target search."""
import hashlib,json,shutil
from pathlib import Path
STUDY=Path(__file__).resolve().parent
BUNDLE=STUDY.parent
manifest=json.loads((STUDY/'OMISSIONS.json').read_text())
restored=[]
for item in manifest['omitted_exact_duplicates']:
    for key in ('path','copy_from'):
        p=Path(item[key]);assert not p.is_absolute() and '..' not in p.parts
    src=BUNDLE/item['copy_from'];dst=BUNDLE/item['path']
    assert hashlib.sha256(src.read_bytes()).hexdigest()==item['sha256'],str(src)
    if dst.exists():
        assert hashlib.sha256(dst.read_bytes()).hexdigest()==item['sha256'],str(dst)
    else:
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);restored.append(item['path'])
    assert dst.stat().st_size==item['size_bytes']
print(json.dumps({'restored':len(restored),'verified':len(manifest['omitted_exact_duplicates']),'target_searches':0}))
