# Study 056: frozen synthetic benchmark outcome

## Decision

**The shared placement solver passed the preregistered numerical method gates, but target admission is not yet operationally cleared. Learned conflicts showed no benefit. No actual K4 ciphertext was loaded or tested.**

An aggregate resource-watchdog assumption failed on this cloud runtime: `/proc/PID/task/PID/children` is absent, and the monitor returned zero instead of traversing the process tree. All measured summed batch CPU times were well below the limit, but zero RSS observations are not memory measurements. The independent parent review must resolve this limitation; no source has been silently repaired or holdout rerun after unblinding. See `audit/resource-monitor-limitation.json`.

## Main results

All four exact methods completed all 256 held-out fixtures and returned identical full nominal solution sets. A separate row-matrix reference independently enumerated all 732,856,320 route/period trials across the fixtures and reproduced every result.

- Unique planted plaintext on ordinary/equality/literal positives: **83/84**, exact 95% binomial interval **93.54%–99.97%**.
- Literal-pattern positives: **28/28**, exact interval **87.66%–100%**.
- Every one of **128 in-family planted operators and plaintexts** was included, including ambiguous and alias fixtures.
- Independent uniform-ciphertext controls: **0/56 compatible**, exact two-sided 95% upper bound **6.38%** for this synthetic sampling process, not a project-wide p-value.
- Outside-model generators: **0/16 compatible** in this sample; the labels were not assumed negative in advance.
- Corruptions: **44 unique compatible / 12 UNSAT**. All 44 changes transported from noncrib positions retained the original operator and its modified plaintext, exactly as predicted. These are sensitivity diagnostics, not accidental-fit negatives.
- Across all strata: **163 unique plaintexts, 9 ambiguous cases, 84 complete UNSAT cases**. All 163 uniquely identified plaintexts also had one canonical operator. Nominal aliases were retained separately.

Nine ambiguity cases are explicitly recorded with two different full plaintext witnesses in `audit/ambiguity-witnesses.json`. The guaranteed constant-crib cases include 12 and 48 distinct plaintexts; no ambiguous result was called unique. Every result contains its full 97-position forced mask and separate raw/canonical/plaintext counts.

## Frozen methods and ablations

The family is standard A–Z periodic Vigenere followed by unpadded ragged columnar transposition, widths 6–9 and nominal periods 2–8, with arbitrary seed and column order. Every method searched all 28 width/period cells; generating metadata was withheld.

| Method | Meaning | Mean timed CPU per full solve | Complete |
|---|---|---:|---:|
| E | Complete routes, direct unrestricted-key inference | 57.300 ms | 256/256 |
| P | Prefix search with immediate key propagation | 0.974 ms | 256/256 |
| S | Placement CSP with exact arc consistency, no learning | 0.960 ms | 256/256 |
| L | Same CSP plus proved dynamic decision nogoods | 0.967 ms | 256/256 |

S was selected before held-out solving using the smallest summed end-to-end CPU on the same eight nonblind development fixtures, with exact ties favoring simpler methods. The earlier internal-solver-only tentative choice of P is preserved as superseded before holdout.

Frozen paired geometric-mean comparisons, 10,000 deterministic bootstrap samples:

| Comparison | Speedup | 95% interval |
|---|---:|---:|
| S over E | 60.409× | 59.352–61.372× |
| P over E | 59.443× | 58.431–60.401× |
| L over E | 59.975× | 58.958–60.911× |
| L over S | 0.993× | 0.977–1.009× |

L learned only two sound clauses and had **zero later hits, zero cross-branch reuse and zero verified modular cross-branch reuse**. It explored exactly the same 7,296 states as S, while performing 491,034 support checks versus 489,622 for S. Therefore this study supports early/shared constraint propagation, not a benefit from dynamic learning. P is nearly as fast as S; the improvement over E is not uniquely attributable to the CSP representation.

### Timing scope

Each method/fixture used a fixed batch of 20 full repetitions, no warmup. The frozen per-solve timing includes preprocessing, solver-process startup, serialization, driver parsing, repeat equality checks and canonical projection on every repetition. Outer Python worker import/setup and monitor overhead were charged globally rather than included in the per-method timer. Timed batches summed to 308.232 CPU seconds; the entire benchmark consumed 372.940 CPU seconds. This distinction must accompany the 60.409× figure. The parent auditor is computing a conservative overhead sensitivity; no timing metric is retroactively substituted for the frozen one.

## Numerical gate table

| Gate | Requirement | Observed | Result |
|---|---|---|---|
| Exactness | Zero discrepancies or unsound exclusions | Zero; independent full-union replay | Pass |
| Completion | S 256/256; E at least 244/256 | Every method 256/256 | Pass |
| Identifiability | At least 80/84 and 26/28 literal | 83/84 and 28/28 | Pass |
| Representation | At least 2×; bootstrap lower bound >1.25× | 60.409×; lower 59.352× in frozen timing scope | Pass numerically |
| Learning claim | At least 1.2×; lower >1; 50 modular reuses in 10 fixtures | 0.993×; lower 0.977×; zero reuse | Fail |
| Uniform false fits | At most 1/56 unique compatible | 0/56 compatible | Pass |
| Operational resource verification | Effective declared aggregate limits | CPU observed below cap; tree watchdog ineffective | Unresolved; target held |

The corrected protocol separates method admission from the learning-specific claim. The failed learning gate does not erase the propagation result, but neither numerical result authorizes target work by itself.

## Verification and commitments

Main and supplemental tiny suites cover binary/ternary alphabets, missing key residues, all partial clue assignments in the smallest grid, rectangular and ragged routes, and full raw/operator/plaintext projections:

- **288,363 fixtures; 1,153,452 solver calls; 2,277,336 witness re-encryptions.**
- **24,780 learned clauses**, verified against **697,472 concrete premise-containing completions**.
- **3,040 tiny cross-branch reuse receipts** independently validated. This demonstrates the mechanism can work on tiny cases, not that it helped held-out cases.
- Held-out independent witness audit: **1,564 witnesses**, all nominal aliases complete; **5,120 projection checks** passed.
- Seed replay reproduced input and answer manifests byte for byte.

| Commitment | SHA-256 |
|---|---|
| Final protocol v2 | `58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea` |
| Freeze manifest | `19e2fb273d88a97d15223773b03920ea3aa1585cb21854564bd18372fc3d1410` |
| Solver source | `625739e4d4e5a4e0052de4069563319b1a0c13e7b1c82cb0cf2751c09f657573` |
| Solver executable | `e9f86df41dec1f3e8289d9e04d8c3faaf80a79ff8ea5188b38ce136bd7bb6b65` |
| Held-out input | `83546f4719f90a12ab1600b930434ef1c23bbc2dc8bb9fd47d0195d63d801bca` |
| Committed answer | `0fdb1c1ed3c297240537382ce8ea34606779152099f5cb3b68406d094b12d0b4` |
| Immutable output hash manifest | `639c7cfccb8ae4bf8417d4c46b53b09e94ef5d5a8b133985867b52c22d7439a4` |

The freeze committed 31 public files; private answer/seed bytes were not opened by the solving harness. Answers were revealed only after all outputs/timings were sealed. Sources and outputs remain unchanged after the resource-monitor finding.

## Resource observations and limits

The benchmark used **372.940 CPU seconds**, **361.481 wall seconds** and fixed 20-repetition batches. The largest measured summed batch was **1.430 CPU seconds**, below its 20-second cap. The solver's maximum recorded per-process RSS was **9956 KiB**; this is not an aggregate tree peak. The driver's recorded peak was 15,276 KiB. The tree RSS monitor's zero values are invalid measurements and are explicitly disclaimed.

All development, old probes, independent audits and helper work are charged in the final resource ledger, with conservative allowances where not individually metered. No packages, paid compute, account changes, external contacts, repository writes, publication or Site changes occurred. Studies 053–055 and repository originals were preserved.

## Scope and stop

At least 408,946 of this family's 408,960 routes lie outside the inspected Study 050 permutation projection; the certificate is independent of target ciphertext. Arbitrary periodic-key elimination and fixed-route modular propagation were already used in earlier work and are not claimed as new.

This is a bounded synthetic result, not evidence that the historical cipher uses this family. No family expansion, actual target score or target exclusion has been made. The next action belongs to the independent parent review of the resource-verification limitation.
