# Study 056 — synthetic benchmark only

**Post-run verification warning:** numerical method gates passed, but an aggregate resource-watchdog assumption was invalid on this cloud runtime. `audit/resource-monitor-limitation.json` records the issue. All measured batch CPU times were below the limit, but zero watchdog RSS values are not memory measurements. Target admission awaits independent parent disposition; no target run occurred.

The experiment is standard A–Z periodic Vigenere followed by unpadded ragged columnar transposition, with unknown width 6–9, nominal period 2–8 and arbitrary column order. Every solver searches the complete bounded union using all 97 symbols and 24 supplied plaintext clues.

This artifact contains no actual K4 target run. It is private scratch research, not a repository publication or Site update. The benchmark result, when available, is conditional on this one frozen family and does not establish historical applicability.

## Layout

- `freeze/`: final protocol, algorithm/source hashes, runtime, budget and coverage commitments.
- `source/`: E/P/S/L solvers, independent matrix oracle, fixture author, benchmark runner and exact analysis.
- `development/`: eight explicitly nonblind development fixtures, tuning and smoke records; earlier tiny receipts and the disclosed design probe.
- `fixtures/`: sanitized opaque held-out inputs and public generation commitment.
- `answers/`: independently authored withheld answers and seeds; never read by the solving harness before its output seal.
- `results/`: full raw nominal descriptions, projected counts/hashes, witness sets, timing repetitions and conflict receipts for every held-out fixture.
- `audit/`: exhaustive tiny checks, independent witness/proof replay, output seal, statistics and resource ledger.

Nominal aliases, canonical operators and distinct plaintexts are counted separately. Every returned witness has a complete plaintext and key, not guessed fill outside the clues. Timeout is never an exclusion or uniqueness claim.

After the held-out benchmark is complete, independent parent review is required before any target experiment. A speed benefit from prefix propagation is not automatically a benefit from learned conflicts; both comparisons are retained.
