# Development record

Study 056 implementation began in the independent cloud workspace. No target loader is present. No canonical K4 ciphertext is an input or is read for implementation.

The pre-existing design probe is preserved verbatim as `design_probe.py`; it is exploratory, single-cell and nonblind, not held-out evidence.

The solver is implemented using the installed GCC and Python standard library only. No dependencies are installed. New implementation lives only in this directory; earlier studies and repository originals remain unchanged.

## Pre-freeze review and corrections

The root repository's AGENTS.md at pinned commit 5b6cd7ac47d35a7afdd26a9d0109d95a726b2067 returned GitHub 404. No local AGENTS.md was found in the selected workspace or inspected related study directories. This is a standalone scratch implementation, not a repository edit.

Protocol v1 was superseded before held-out execution: ciphertext corruption at a transported noncrib location is guaranteed to preserve an in-family explanation, so it cannot belong to an accidental-fit low-rate threshold. Version 2 separates 56 uniform ciphertext controls from 56 corruption diagnostics. No held-out outcome was observed before correction.

The first baseline used a linear lookup for placement starts. It was replaced by an indexed lookup before held-out timing to avoid handicapping complete-route enumeration. Both complete tiny audits passed and the original receipt is preserved.

An independent parent reviewer requested full CPU/memory process-tree caps, private-answer byte-open prevention, per-repeat projection timing, and independently verifiable cross-branch learning receipts. All were implemented before held-out execution. No cipher-family domain or gate was widened. The final instrumentation adds receipt data only and receives another full tiny rerun.

The extra batch smoke tests reuse the first of the original eight development fixtures. They are development only, not additional independent fixtures or blinded evidence. The internal-CPU comparison tentatively favored P. Before any held-out solve, the independent reviewer required the protocol's end-to-end metric. A preregistered fixed-20 rerun on the same eight fixtures selected S; the earlier P designation is preserved as superseded. No method is reselected after the held-out outcome.
