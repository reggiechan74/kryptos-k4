# Study 056 independent tiny audit

## Result

PASS on the final solver source and executable. All four exact methods agreed with an independently written literal-row-matrix brute-force oracle on every tested raw description, canonical operator and complete plaintext set. There were zero missing or extra solutions and zero unsound learned exclusions.

- 267,371 distinct input fixtures and 1,069,484 solver calls.
- 144,210 concrete ciphertext/route/key tuples enumerated by the oracle. For a fixed route/key, encryption is bijective, so these exhaust the same plaintext/route/key domain.
- 1,908,696 returned witnesses independently re-encrypted and checked against every supplied clue.
- 24,492 learned nogood receipts checked against all 696,320 concrete completions containing their placement premises. No such completion satisfied the clues.
- Input classes: 932 UNSAT, 235,138 unique-plaintext, 31,301 multiple-plaintext. Operator aliases are retained in the exact raw comparison and separately projected by complete route and full shift stream.
- The tiny suite contains empty masks, missing key residues, ragged grids, key aliases, invalid placements and genuine cross-branch nogood reuse. No 97-letter fixtures or target ciphertext were created or loaded by this auditor.

## Frozen grids

| Grid | Domain | Clue assignments | Distinct fixtures | Concrete tuples |
|---|---|---|---:|---:|
| all-partial-5 | Alphabet 2, length 5, widths 2 and 3, periods 1 and 2 | All absent/0/1 assignments at every position | 7,776 | 1,536 |
| generative-7 | Alphabet 2, length 7, width 4, period 3 | Empty, positions 1/5, full; every generated assignment | 10,304 | 24,576 |
| generative-9 | Alphabet 3, length 9, width 2, period 1 | Empty, positions 0/4/8, full; every generated assignment | 249,291 | 118,098 |

The exact grid was committed to `development/tiny-grid.json` before any test. The final-source test hash and executable hashes were recorded in `development/tiny-final-prefreeze.sha256` before the final run.

## Independence and soundness

`source/test_tiny.py` implements its own forward and inverse using literal ragged row matrices. It exhausts all keys and column permutations; it does not call production placement or key-inference routines. Raw descriptions are compared before deduplication. Each clause's placement indices are translated to offsets using independently enumerated permutations, not the solver's placement table. Every concrete route/key completion containing the clause premises is tested directly against the clues. Receipts are retained in `audit/tiny-nogoods.jsonl`.

The solver learns conservative decision-context conflicts from domain wipeout and minimizes them with uncached propagation replay. The audit confirms these concrete tiny exclusions and end-to-end sets; it is not a formal proof covering arbitrary future source modifications. The final binary must remain hash-identical for this receipt to apply.

## Resources and preservation

Final run: 66.161934 CPU seconds including the reaped solver child; 69.537746 wall seconds; self peak RSS 12,672 KiB and child peak RSS 11,008 KiB. The run enforced a 2 GiB address-space limit inherited by the solver. During execution its CPU guard included the accumulated internal CPU of the still-live child, rather than relying only on `RUSAGE_CHILDREN` before reaping.

An earlier complete audit of the pre-lookup-optimization executable also passed and is explicitly nonfinal. Its test source, logs, report and receipts are preserved under `development/pre-lookup-audit/`. The final full suite was rerun after the direct lookup optimization, not inferred equivalent from the prior pass. The two measured runs consumed 136.712795 CPU seconds; charge 140 CPU seconds for this audit task, including a conservative allowance for short file/hash helper operations.

## Final identity

- Solver source SHA-256: `4c9d0911114698d5be08cfbe255320617ff8ab9b4532ad5b460ca39d5a0430a8`.
- Executable SHA-256: `172c3c5ac33aa2a8f3234f26c7dadec14c64e94fc0450802ef969d479cdc2397`.
- Complete solution-set stream SHA-256: `fa40e84d0f855ca7ad78dc422176e588432d84ade0448f041b969dcab5a80e22` (identical before and after the lookup optimization).

This clears only the tiny correctness gate. It does not assert held-out speed, identifiability, false-fit performance, historical relevance or permission to run the K4 target.
