"""Independent exhaustive synthetic-only matrix oracle and solution-set audit."""
import hashlib, itertools, json, os, resource, sys, time
from collections import Counter
from pathlib import Path
from engine_api import Engine
ROOT=Path(__file__).resolve().parents[1]

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def encrypt(plain, width, key, order, alphabet):
    shifted=[(v+key[i%len(key)])%alphabet for i,v in enumerate(plain)]
    rows=[shifted[i:i+width] for i in range(0,len(shifted),width)]
    return tuple(row[col] for col in order for row in rows if col<len(row))
def decrypt(cipher, width, key, order, alphabet):
    n=len(cipher); rows=[[None]*min(width,n-i) for i in range(0,n,width)]
    offset=0
    for col in order:
        for row in rows:
            if col<len(row): row[col]=cipher[offset];offset+=1
    flat=[v for row in rows for v in row]
    return tuple((v-key[i%len(key)])%alphabet for i,v in enumerate(flat))
def route_indices(n,width,order):
    rows=[list(range(i,min(i+width,n))) for i in range(0,n,width)]
    return tuple(row[c] for c in order for row in rows if c<len(row))
def starts_of(n,width,order):
    rows=[list(range(i,min(i+width,n))) for i in range(0,n,width)]
    starts={};offset=0
    for c in order:
        starts[c]=offset;offset+=sum(c<len(row) for row in rows)
    return starts

def universe(cipher,a,widths,periods):
    out=[]
    for w in widths:
        for order in itertools.permutations(range(w)):
            starts=starts_of(len(cipher),w,order)
            for p in periods:
                for key in itertools.product(range(a),repeat=p):
                    plain=decrypt(cipher,w,key,order,a)
                    assert encrypt(plain,w,key,order,a)==cipher
                    raw=(w,p,order,key,plain)
                    op=(route_indices(len(cipher),w,order),tuple(key[i%p] for i in range(len(cipher))))
                    out.append((raw,op,plain,starts))
    return out

def canonical_solution(s,n):
    w,p=s['width'],s['period'];o=tuple(s['order']);k=tuple(s['key']);pt=tuple(s['plaintext'])
    raw=(w,p,o,k,pt)
    return raw,(route_indices(n,w,o),tuple(k[i%p] for i in range(n))),pt

def elapsed():
    me=resource.getrusage(resource.RUSAGE_SELF);ch=resource.getrusage(resource.RUSAGE_CHILDREN)
    return me.ru_utime+me.ru_stime+ch.ru_utime+ch.ru_stime

def main():
    start_cpu=elapsed();start_wall=time.time();spec=json.loads((ROOT/'development/tiny-grid.json').read_text())
    report={'status':'RUNNING','grid_sha256':sha(ROOT/'development/tiny-grid.json'),'solver_cpp_sha256':sha(ROOT/'source/solver.cpp'),'solver_binary_sha256':sha(ROOT/'source/solver'),'test_source_sha256':sha(Path(__file__)),'grids':[],'errors':[], 'learned_nogoods_checked':0,'concrete_premise_completions_checked':0,'witnesses_checked':0,'solver_calls':0,'solution_class_counts':Counter(),'metric_totals':Counter()}
    eng=Engine();digest=hashlib.sha256();clause_file=open(ROOT/'audit/tiny-nogoods.jsonl','w')
    def check(cipher,clues,a,widths,periods,all_raw,grid_id,index):
        expected=[x for x in all_raw if all(x[2][i]==v for i,v in clues)]
        exp_raw={x[0] for x in expected};exp_op={x[1] for x in expected};exp_pt={x[2] for x in expected}
        kind='UNSAT' if not exp_pt else 'UNIQUE' if len(exp_pt)==1 else 'MULTIPLE';report['solution_class_counts'][kind]+=1
        for mode in range(4):
            result=eng.solve(mode,cipher,clues,widths=widths,periods=periods,alphabet=a,limit=20)
            report['solver_calls']+=1;report['metric_totals'].update(result['metrics'])
            assert result['complete'], ('incomplete',grid_id,index,mode)
            got=[canonical_solution(s,len(cipher)) for s in result['solutions']]
            assert len(got)==len({x[0] for x in got}),('duplicate raw',grid_id,index,mode)
            assert {x[0] for x in got}==exp_raw,('raw mismatch',grid_id,index,mode,cipher,clues,len(got),len(exp_raw))
            assert {x[1] for x in got}==exp_op,('operator mismatch',grid_id,index,mode)
            assert {x[2] for x in got}==exp_pt,('plaintext mismatch',grid_id,index,mode)
            for raw,op,plain in got:
                w,p,order,key,_=raw
                assert encrypt(plain,w,key,order,a)==cipher,('reencrypt mismatch',grid_id,index,mode)
                assert all(plain[i]==v for i,v in clues),('clue mismatch',grid_id,index,mode)
            report['witnesses_checked']+=len(got)
            for ng in result['nogoods']:
                w,p=ng['width'],ng['period'];positions={c:set() for c in range(w)}
                for order in itertools.permutations(range(w)):
                    for c,s in starts_of(len(cipher),w,order).items():positions[c].add(s)
                positions={c:sorted(v) for c,v in positions.items()}
                premises=[(c,positions[c][j]) for c,j in ng['clause_placement_indices']]
                concrete=0
                for raw,op,plain,starts in all_raw:
                    if raw[0]!=w or raw[1]!=p:continue
                    if all(starts[c]==s for c,s in premises):
                        concrete+=1
                        assert not all(plain[i]==v for i,v in clues),('unsound nogood',grid_id,index,cipher,clues,ng,raw)
                report['learned_nogoods_checked']+=1;report['concrete_premise_completions_checked']+=concrete
                clause_file.write(json.dumps({'grid':grid_id,'fixture_index':index,'alphabet':a,'ciphertext':cipher,'clues':clues,'receipt':ng,'premises':premises,'concrete_completions_checked':concrete},separators=(',',':'))+'\n')
            # Committing expected raw data binds audit to complete solution sets, not just counts.
            digest.update(json.dumps([grid_id,index,mode,sorted(exp_raw)],separators=(',',':')).encode())
    try:
        for grid in spec['grids']:
            a,n=grid['alphabet'],grid['length'];widths,periods=grid['widths'],grid['periods'];count=0;tuples=0;cpu0=elapsed();solver_cpu0=report['metric_totals'].copy()
            for cipher in itertools.product(range(a),repeat=n):
                all_raw=universe(cipher,a,widths,periods);tuples+=len(all_raw)
                if grid['id']=='all-partial-5':
                    patterns=([(i,v-1) for i,v in enumerate(values) if v] for values in itertools.product(range(a+1),repeat=n))
                else:
                    patterns=[]
                    for mask in grid['masks']:
                        patterns.extend([list(zip(mask,values)) for values in sorted({tuple(x[2][i] for i in mask) for x in all_raw})])
                for clues in patterns:
                    check(cipher,clues,a,widths,periods,all_raw,grid['id'],count);count+=1
                if count and count%1000<max(1,len(patterns) if isinstance(patterns,list) else 243):
                    print(grid['id'],count,'fixtures',round(elapsed()-start_cpu,3),'parent+reaped-child CPU seconds',flush=True)
                if elapsed()-start_cpu>spec['max_cpu_seconds_including_child']:raise RuntimeError('tiny audit CPU guard reached')
            assert tuples==grid['concrete_route_key_ciphertext_tuples'],(grid['id'],tuples)
            if 'expected_fixtures' in grid:assert count==grid['expected_fixtures']
            report['grids'].append({'id':grid['id'],'fixtures':count,'concrete_route_key_ciphertext_tuples':tuples,'audit_cpu_seconds_before_child_reap':elapsed()-cpu0})
            print('GRID COMPLETE',grid['id'],count,tuples,flush=True)
        report['status']='PASS';report['complete_solution_sets_sha256']=digest.hexdigest()
    except Exception as ex:
        report['status']='FAIL';report['errors'].append(repr(ex));raise
    finally:
        clause_file.close();eng.close();report['cpu_seconds_including_child']=elapsed()-start_cpu;report['wall_seconds']=time.time()-start_wall
        report['peak_self_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;report['peak_child_rss_kib']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        report['nogood_receipts_sha256']=sha(ROOT/'audit/tiny-nogoods.jsonl');report['solution_class_counts']=dict(report['solution_class_counts']);report['metric_totals']=dict(report['metric_totals'])
        (ROOT/'audit/tiny-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
