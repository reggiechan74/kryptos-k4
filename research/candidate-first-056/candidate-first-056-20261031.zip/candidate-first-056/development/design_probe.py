import random
N=97; MASK=list(range(21,34))+list(range(63,74))
def inspect(w,p,seed,style='random'):
 R=random.Random(seed); P=[R.randrange(26) for _ in range(N)]
 if style=='k4':
  for i,c in zip(MASK,'EASTNORTHEASTBERLINCLOCK'): P[i]=ord(c)-65
 elif style=='constant':
  for i in MASK:P[i]=0
 K=[R.randrange(26) for _ in range(p)]; X=[(v+K[i%p])%26 for i,v in enumerate(P)]
 order=list(range(w));R.shuffle(order);C=[X[i] for j in order for i in range(j,N,w)]
 q,r=divmod(N,w);lengths=[q+(j<r) for j in range(w)]
 domains=[]; maps=[]
 for j in range(w):
  starts=sorted({q*k+h for k in range(w) for h in range(k+1) if h<=r-(j<r) and k-h<=w-r-(j>=r)})
  m={}
  for s in starts:
   v={};ok=True
   for i in MASK:
    if i%w!=j:continue
    a=i%p;k=(C[s+i//w]-P[i])%26
    if a in v and v[a]!=k:ok=False;break
    v[a]=k
   if ok:m[s]=v
  maps.append(m);domains.append(set(m))
 n0=[len(v) for v in domains]
 compat={}
 for j in range(w):
  for h in range(w):
   if j==h:continue
   for s in maps[j]:
    compat[j,h,s]={t for t in maps[h] if (s+lengths[j]<=t or t+lengths[h]<=s) and all(a not in maps[h][t] or b==maps[h][t][a] for a,b in maps[j][s].items())}
 calls=0;fails=0;solutions=0;maxd=0
 def solve(D,depth):
  nonlocal calls,fails,solutions,maxd
  calls+=1;maxd=max(maxd,depth)
  change=True
  while change:
   change=False
   for j in range(w):
    for h in range(w):
     if j==h:continue
     bad={s for s in D[j] if not compat[j,h,s]&D[h]}
     if bad:D[j]-=bad;change=True
     if not D[j]:fails+=1;return
  if all(len(x)==1 for x in D):solutions+=1;return
  j=min((j for j in range(w) if len(D[j])>1),key=lambda j:len(D[j]))
  for s in sorted(D[j]):
   E=[set(x) for x in D];E[j]={s};solve(E,depth+1)
 solve(domains,0)
 return {'w':w,'p':p,'seed':seed,'style':style,'pre':n0,'calls':calls,'fails':fails,'depth':maxd,'solutions':solutions}
if __name__=='__main__':
 for w,p in [(6,5),(7,8),(8,7),(9,7),(9,8),(8,8)]:
  for style in ['random','k4','constant']:
   print(inspect(w,p,1000+10*w+p,style))
