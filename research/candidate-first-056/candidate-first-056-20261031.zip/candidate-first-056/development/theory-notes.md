# Study 056: independent model / identifiability / propagation notes

Design review, 2026-10-31. No K4 ciphertext was evaluated. A small development-only synthetic probe is explicitly described below; it is not a blinded benchmark or implementation acceptance test.

## Exact family and inversion

Let N=97, alphabet integers 0..25, width w in {6,7,8,9}, nominal key period p in {2,...,8}, and seed K in (Z/26Z)^p. Encrypt X_i=P_i+K_(i mod p) mod26. Row-fill X left to right in width w with no padding. Let q=floor(97/w), r=97 mod w, and L_j=q+1[j<r]. An arbitrary permutation pi of physical columns specifies left-to-right ciphertext block order; within each column read top to bottom. If column j begins at ciphertext index s_j, then

C_(s_j+floor(i/w))=P_i+K_(i mod p), for i mod w=j.

Crib mask is I={21,...,33} union {63,...,73}, zero based. A complete route fixes every key coordinate because the first 13 positions are contiguous and p<=8. Thus there is no unexplored/free plaintext outside the cribs once a route and consistent key are fixed: reconstruct all 97 letters exactly. The solver may not report arbitrary values of unconstrained P as if recovered. This particular domain has none conditional on a complete consistent route.

## Key aliases and operator domain

Nominal p is not effective period. Preserve all nominal descriptions; canonicalize on the complete 97-coordinate key stream and full affine route operator. For effective d=1,...,8, primitive seed counts are recursively a_d=26^d-sum_(e|d,e<d) a_e. Nominal alias multiplicity is m_d=#{p in 2..8 : d|p}.

| d | a_d | m_d |
|---|---:|---:|
|1|26|7|
|2|650|4|
|3|17,550|2|
|4|456,300|2|
|5|11,881,350|1|
|6|308,897,550|1|
|7|8,031,810,150|1|
|8|208,826,607,600|1|

There are 408,960 routes (=720+5,040+40,320+362,880), 217,180,147,132 raw nominal seeds, and 217,179,671,176 distinct 97-coordinate periodic streams. Hence 88,817,992,971,102,720 raw descriptions and 88,817,798,324,136,960 distinct affine operators before crib constraints.

Why these canonical counts are exact: two streams with periods <=8 agreeing on 97 positions obey the Fine-Wilf common-period condition and have the same least period. Each width/order gives a different position permutation: within the first output block, the first two source positions differ by w; the first block always has >=10 letters, so widths cannot alias. For fixed w, disjoint labeled columns make the order injective. Distinct operators can nonetheless agree on one repetitive input and produce the same plaintext for a fixed C. Therefore count (i) raw descriptions, (ii) canonical keys/operators, and (iii) distinct full plaintexts separately. Nominal aliases are not failure of canonical key identifiability; multiple canonical keys with the same full plaintext are.

## Fair completed-candidate baseline

Do not enumerate 26^p seeds. Enumerate each complete column order, infer K from cribs, reject the first inconsistent residue, and independently re-encrypt any survivor. This makes exactly 7*408,960=2,862,720 (width,nominal-period,route) trials per fixture. It is a fair exact baseline with arbitrary keys, not a keyword-list baseline, and already algebraically eliminates keys. If canonical periods are used for speed, preserve equivalent raw counts/aliases. The optimized method receives exactly the same domains, crib values, ciphertext, and resource caps.

## Placement CSP without unsound prefix caching

Use variable A_j=s_j for each physical column. Candidate starts are

S_j={q*k+h : 0<=k<w, 0<=h<=k, h<=r-1[j<r], k-h<=w-r-1[j>=r]}.

Here k is the number of columns before j and h is the number of long columns before j. A rank alone does not fix a ragged start; do not learn a clause on rank while silently using one prefix's long-column count.

For each candidate placement (j,s), all cribs in column j imply a partial residue-to-value map M_(j,s): a=i mod p -> (C_(s+floor(i/w))-P_i) mod26. Reject the placement if this map assigns two different values to one residue. For any pair (j,s),(h,t), a binary incompatibility is certified if their intervals overlap, or their maps disagree on a shared residue. Each such relation is independent of other placements and is reusable in every branch of this fixture. These are analytic nogoods, not dynamically learned clauses.

Assign exactly one placement per column, enforcing every pair's compatibility. Every interval lies in [0,97), intervals are disjoint, and their lengths sum to97; therefore they tile [0,97) without gaps. Sorting starts recovers a genuine column order. Pairwise map agreement gives one common key on all observed residues. This proves equivalence to the route model, not just necessity of filters.

Implement bitset arc consistency plus fixed deterministic MRV/ascending-start branching. A useful ablation is (B) completed-route baseline, (P) placement propagation without learned cache, (L) identical placement propagation with learned nogoods. Include preprocessing in end-to-end timings.

## Sound dynamic nogoods (if they actually help)

Track a set of decision literals explaining every eliminated candidate. A decision A_j=s removes alternatives with that decision as explanation. When arc consistency removes candidate a because all its original supports b in another column have been removed, union the explanations for those supports. Static invalid candidates have an empty explanation. A domain wipeout's union is an impossible conjunction of decision literals. Store its sorted literals as a nogood; optionally minimize by deletion and replay of the same sound propagation. A learned nogood may prune any later assignment containing its literals, regardless of the other prefix decisions, or remove its last unassigned literal when all the others hold. Record derivation antecedents and independent proof checks.

The cache key must include exact ciphertext, literal crib map, N,w,p,alphabet,model version. Do not share literal nogoods between fixtures merely because equality pattern or width is the same. Distinguish nogoods fired outside their discovery subtree from repeated checks at the same state. If there are no such reuses or no end-to-end gain over P, report that learned conflicts added no measured value. Root arc consistency alone can legitimately be the successful method.

Tiny exhaustive validation should enumerate all C and crib assignments for a genuinely tiny alphabet/length domain, independently enumerate complete keys and routes, and compare all canonical keys/operators and plaintexts with P and L. Check every learned clause against the complete tiny witness set, not merely final SAT/UNSAT counts. Include rectangular and ragged geometries and period/width gcd cases. This validates both no false negatives and no false unique classifications.

## Identifiability hazards

The mask covers every physical column at least twice:

- w6: [4,4,3,5,4,4]
- w7: [4,4,4,4,3,3,2]
- w8: [4,4,2,2,2,3,3,4]
- w9: [3,3,2,3,3,3,3,2,2]

The bipartite column/residue graph may split when gcd(w,p)>1, but splitting is not by itself a nonidentifiability proof: column-internal crib differences constrain placements. The important exact symmetry is that columns with equal lengths, equal crib row sets, and equal known-plaintext vectors up to an additive constant can be swapped and their independent key slots adjusted when p=w. This creates different canonical operators and usually different full plaintexts, not nominal aliases. For the literal EASTNORTHEAST / BERLINCLOCK values no such equal-length/same-rowset/additive-pattern duplicate was found at w=6,7,8 (the p=w cases in domain). This is only one structural check, not a uniqueness proof for all ciphertexts.

Under constant crib values, w7,p7 has a guaranteed subgroup of 4!*2!=48 same-length column permutations (columns0..3 share one crib rowset; columns4,5 another), and w8,p8 has 3!*2!=12 (columns2,3,4 and columns5,6). Random key values do not remove this because the independent column key slots shift with the permutation. Such cases must be classified ambiguous, not scored as failed plaintext recovery. More generic equality patterns may have additional accidental ambiguities.

Full-family uniqueness requires completing all widths and periods, canonicalizing aliases, and checking every alternative canonical key and plaintext. First SAT is not recovery. At a cap report UNKNOWN/incomplete, even if the true fixture witness was found. A practical exact output can retain witnesses until two plaintexts are found for a nonuniqueness certificate, but complete counts still require exhaustive completion or a sound projected-counting proof.

## Development-only synthetic probe, not a gate result

A one-off scratch probe `/tmp/k4_056_theory_probe.py` generated one 97-letter uniform random plaintext/key/order at each (w,p) in {(6,5),(7,8),(8,7),(9,7),(9,8),(8,8)}. For each it used either random crib values, forced literal K4 crib values, or all-A crib values. It evaluated only the generating w,p, not the whole family, and used an unaudited small Python placement CSP. All 18 recovered at least the planted route; 17 collapsed to one placement at root arc consistency. The constant-crib w8,p8 case yielded12 solutions without any contradiction/backtrack failure. This supports tractability but warns that dynamic conflict learning may have no opportunity to help. It is not independently verified, blinded, timed rigorously, or sufficient for any K4 gate. No real K4 ciphertext was read or passed to this probe.

## Recommended gate interpretation

Freeze held-out fixtures with uniform, repeated-symbol, alphabet-relabelled crib-pattern, and fixed-literal-pattern strata. Do not require all positives to be unique: equality-stress cases can be provably ambiguous. Require exact truth inclusion and correct unique/ambiguous/UNSAT/UNKNOWN labeling; measure full recovery only on independently established unique cases. Separate the model's identifiability gate from optimizer speed and from dynamic-learning benefit. Synthetic success says nothing by itself about historical applicability or probability K4 belongs to the family.

## Four-method implementation refinement (parent's latest freeze)

Use B0 = complete-route enumeration with generic key-residue inference; B1 = prefix search with immediate key-residue propagation; B2 = common-placement CSP with the same exact unary/pair constraints and no learned cache; B3 = the identical CSP with sound derived nogoods / UNSAT memoization. A B3 speed claim is versus B2, not only versus B0; B1 exposes how much improvement comes from ordinary early checking. No widening to create hard examples after seeing these development probes.

A binary learned receipt identifies both exact placement literals (physical column, ciphertext start), the two forcing crib indices and literal values, their mapped ciphertext indices/values, shared residue a, and conflicting computed values u != v. The clause is `not(A_j=s and A_h=t)` and is independent of all other prefix decisions. A local repeated-residue mismatch gives a unary clause. Structural overlap receipts give the two intervals. Prefix UNSAT memoization can use (used-column bitmask, partial key vector including unknown entries) within the exact context guard: current ciphertext position is determined by the used-set lengths, and only those state values affect remaining feasibility. A same-state hit with a different predecessor prefix is genuine reusable work; zero such hits remains a valid negative result. This state compression is safe for UNSAT, not automatic deduplication of all plaintext witnesses.

No additional exploratory fixtures were run after the 18 cases above. The synthetic seed/style list is fixed and exposed and must never be relabeled held-out.
