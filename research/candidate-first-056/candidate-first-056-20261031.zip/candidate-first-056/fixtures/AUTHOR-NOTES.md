# Independent fixture authorship

The fixture author wrote `source/independent_oracle.py`, `source/generate_fixtures.py`, `source/independent_audit.py`, and `source/replay_fixture_generation.py` without reading production solver source. The independent oracle constructs literal row matrices; its inverse fills blank matrix cells in emitted column order.

The generator is synthetic only and has no target ciphertext loader. The public clue text is used only to construct the declared artificial literal and equality-pattern strata. All 97 plaintext symbols are generated before the clue-pattern modification and encryption.

## Frozen inputs

The final protocol is version 2 with SHA-256 `58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea`. The exact allocation is in `fixture-specification.json`. The generator, oracle, exact allocation, sanitized inputs, withheld answers, and withheld seeds have hashes in `heldout-generation-receipt.json`.

Each sanitized line has only an opaque random identifier, 97 integer ciphertext symbols, and 24 sorted pairs of position and known plaintext symbol. Width, period, order, seed, plaintext, category, and expected assertions occur only in the separate answer file. The solving harness must always search the entire prescribed width and period union.

Blinding is procedural in a shared workspace, not cryptographic file isolation. The solver author has been instructed not to open `answers/` until all result and timing files are finalized and sealed. The author did not disclose any held-out labels or planted parameters.

## Development and revision history

Eight separately seeded development cases are available under `development/`, with answers deliberately disclosed. They are not held-out evidence. Four hand-calculated short known answers and 36 full-length matrix vectors are in `audit/independent-known-answers.json`.

The first, unrun generator specification is preserved under `prefreeze/fixture-v1/`. Before any fixture generation or solver outcome, protocol version 2 corrected the false-fit interpretation of corruption cases. A changed ciphertext symbol that maps to a noncrib plaintext position preserves a valid in-family explanation using the original key and route. The answer file therefore records the changed ciphertext index, nonzero modular increment, mapped plaintext index, original plant, and guaranteed altered witness when applicable. Locations were not resampled. Only the 56 independent uniform-ciphertext controls enter the false-fit gate; all 56 corruption cases remain sensitivity and correctness diagnostics.

The eight degeneracy cases use random noncrib letters and constant clue letters. There are two cases per width: period 3 and period equal to width, except width 9 uses period 8. This allocation was specified before generation, within the protocol's constant-crib diagnostic category. It preserves the guaranteed ambiguity stress at width and period 7 or 8 without requiring the much larger all-constant-plaintext output sets.

## Post-benchmark verification

After every result is finalized, run:

```bash
python3 source/independent_audit.py --seal
```

Then, only after the benchmark owner authorizes answer reveal, run:

```bash
python3 source/independent_audit.py --audit
python3 source/replay_fixture_generation.py --namespace heldout
```

The audit verifies unchanged sealed results before opening answers. It independently re-encrypts and decrypts every witness, checks every clue, deduplicates complete operators and plaintexts, checks nominal-period alias completeness, compares completed solver sets, verifies planted and guaranteed corruption witnesses, and proves learned clauses through an independent placement constraint implementation. Arc-consistency wipeout is a sound certificate; an exact recursive completion check is the fallback. Neither pass can authorize actual target cryptanalysis.
