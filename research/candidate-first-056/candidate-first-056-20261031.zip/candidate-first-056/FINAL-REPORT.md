# Study 056 completed

**The frozen family is excluded for the canonical target: complete UNSAT, independently verified.**

A fresh, resource-corrected blind benchmark first justified the exact nonlearning method: all 256 cases completed, 83/84 ordinary-pattern plants and 28/28 literal-pattern plants were uniquely recovered, and no random control fit (0/56). S was **17.33× faster** than the fair complete-route baseline on fully inclusive CPU, with 95% paired-bootstrap interval **17.13–17.52×**.

Learned conflicts did **not** earn a benefit claim: L/S was about 1.002×, its interval crossed 1, and only two distinct modular clauses were reused across one fixture. S also did not materially outperform simpler prefix propagation P.

After independent benchmark review and explicit parent authorization, S and a separately written exhaustive reference each evaluated the canonical target once. Both returned an empty complete solution set. The reference completed all **2,862,720 route/period trials**.

**Exact excluded scope:** standard A–Z periodic Vigenere with arbitrary nominal-period 2–8 seed, followed by unpadded ragged columnar transposition of width 6–9, all column emission orders, top-to-bottom reads, fixed alignment and the 24 public literal clues. Nothing broader is excluded.

The original benchmark's resource-monitor defect was disclosed and preserved. Only the resource harness was repaired; a fresh independent holdout was generated and the same algorithms, W=S, domain, fixture rules and gates were retained. Both runs and all corrections are in this artifact.

## Read next

- [Corrected benchmark report](recovery-v2/REPORT.md)
- [Final target report](target/REPORT.md)
- [Original limited-run report](REPORT.md)
- [Independent corrected-benchmark audit](../candidate-first-056-audit/recovery-v2/FINAL-AUDIT.md)
- [Independent target audit](../candidate-first-056-audit/target/FINAL-TARGET-AUDIT.md)
- [All-study resource ledger](audit/final-resource-ledger.json)

Total charged compute, including conservative reserves, is about **1,490 CPU seconds (24.8 minutes)** of the original eight-hour cap. Every corrected benchmark and target call stayed inside its resource envelope. The target stage is finished; no model expansion, further search or GitHub/Site publication occurred.
