# Study 056 — resource-corrected fresh holdout

This recovery keeps the original solver source/executable, E/P/S/L algorithms, W=S, cipher domain, fixture rules and numerical gates unchanged. It repairs only resource enforcement/accounting and includes all worker startup/serialization in primary timing.

Original experiment, sealed results, discovered limitation and evidence remain one directory above. This directory uses a fresh OS-random seed namespace after independent validation of the repaired harness. No target ciphertext is present or loaded.

The approved resource amendment and exact commitments are in `freeze/resource-recovery-amendment.md`, `freeze/recovery-code-freeze.json` and `freeze/manifest.json`. No actual target work is authorized by these artifacts; independent parent review is still required after the replacement result.
