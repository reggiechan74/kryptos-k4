# Study 056 resource-only recovery amendment

Authorized by the parent after the original held-out benchmark had been sealed and unblinded. This is correctness recovery in the same study and shared eight CPU-hour budget, not a new cipher family or a new hypothesis.

## Preserved experiment

The original freeze is `19e2fb273d88a97d15223773b03920ea3aa1585cb21854564bd18372fc3d1410`. Original sources, inputs, answers, outputs and seals remain in the parent `candidate-first-056` directory. The original numerical result is retained as resource-certification-limited and not silently replaced.

The original protocol v2 remains unchanged at SHA-256 `58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea`. The exact solver source and executable, E/P/S/L algorithms, domains, clue masks, aliases, generator allocation and rules, all numerical gates, batch size 20 and selected method W=S are unchanged. No algorithm or threshold is retuned. The existing development fixture is used only for a resource-harness smoke test.

## Defect

The first watchdog attempted `/proc/PID/task/PID/children`, which is unavailable on this cloud runtime. Its error path returned zero for the entire process tree. Thus the planned aggregate monitor was ineffective, although measured batch CPU was below limits and individual process limits applied. Zero values were not valid RSS observations. No target work followed.

## Repair and guarantee

The amended harness launches exactly one worker and exactly one persistent solver per method/fixture batch. Both have hard and soft address-space limits of 1 GiB. Their additive permitted address spaces cannot exceed the original 2 GiB aggregate limit, independently of sampling gaps.

The worker announces its sole child PID through an inherited pipe. The parent reads `/proc/PID/stat` for these known PIDs, verifies identity/start time and ownership, and samples summed live/reaped CPU and RSS. Missing live worker information fails closed. There is no dependency on the missing children API. Exactly one child is allowed and no solver relaunch occurs inside a batch.

The solver has a 16 CPU-second hard limit; the worker is tightened to a 2 CPU-second hard limit after spawning that child. This conservative 18-second partition leaves two seconds of enforcement granularity/headroom under the original 20-second aggregate cap. Sampled aggregate violations terminate the process group, and final exact waited CPU plus parent CPU is checked against 20 seconds. A resource failure produces INCONCLUSIVE, never UNSAT or uniqueness.

Each complete batch records worker peak RSS, solver peak RSS, their conservative summed peak upper bound, positive sampled process-tree observations, enforced address-space partitions, process identities and exact total CPU. The same limits apply to every method.

## Timing amendment

Primary timing now includes outer waited worker-and-descendant CPU plus parent monitoring CPU, covering worker import/setup and serialization in addition to the original solver/driver metric. The original inner metric is retained as descriptive only. All methods receive identical timing and fixed 20 repetitions. W remains S; no reselection is allowed from recovery data. The same bootstrap seed, sample count and speed gates apply.

## Fresh evidence and ordering

After independent validation of the resource-only probes, freeze amended code and this document. Then generate a fresh 256-case holdout under the OS-random namespace `study056-resource-recovery-v2`, using exactly the original fixture rules and allocations. Commit input/answer/seed hashes before solving. Withhold answers until every replacement output and timing is finalized and sealed. Any subsequent algorithm or benchmark bug requires another explicit disposition; no widening is permitted.

The original and recovery computations are both charged to the same eight CPU-hour budget. Target access remains blocked until the independent parent review of the replacement benchmark.

Abnormal exit accounting is conservative rather than falsely exact: simultaneous process-group termination can prevent a worker from reaping its killed solver. Every failure/nonzero worker exit triggers process-group cleanup. Confirmed abnormal cases are charged the enforced worker-plus-solver CPU hard budgets plus two seconds headroom, less already observed usage, and that reserve is added to the global ledger. Normal completed batches use exact waited usage. The final receipt also records twice the outer waited-child maximum RSS as a conservative two-process peak bound that includes exit/serialization; a large-child probe validates descendant accounting on this runtime.

The worker tightens its CPU hard limit before publishing the child PID. An abnormal exit without a PID announcement is charged both inherited 16-second budgets plus headroom, since the smaller worker budget cannot be certified. Unconfirmed process-group cleanup aborts the entire benchmark. After an abnormal orphan path, a waited RSS value is not labelled a measured pair upper bound; only the guaranteed additive address-space bound is reported.
