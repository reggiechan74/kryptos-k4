"""Labelled development timing, never held-out evidence."""
import json, resource, sys, time
from pathlib import Path
from engine_api import Engine, projection, ROOT
path=Path(sys.argv[1]); fixtures=[json.loads(x) for x in path.read_text().splitlines()]
assert len(fixtures)<=12
start=time.process_time();e=Engine();rows=[]
for f in fixtures:
    row={'id':f['id'],'methods':{}}
    for mode,name in enumerate('EPSL'):
        r=e.solve(mode,f['ciphertext'],f['clues'])
        r['projection']=projection(r,97);row['methods'][name]=r
        print(f['id'],name,r['cpu_seconds'],r['projection']['status'],r['metrics'],flush=True)
    rows.append(row)
e.close()
out={'label':'NONBLIND_DEVELOPMENT_ONLY','input_path':str(path),'results':rows,'python_cpu':time.process_time()-start,'children_cpu':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime}
(ROOT/'development/results.json').write_text(json.dumps(out,indent=2)+'\n')
