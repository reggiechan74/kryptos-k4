"""Study 056 fixed-batch blind benchmark. Never opens the answer manifest."""
import argparse, hashlib, json, os, resource, signal, statistics, subprocess, sys, time
from pathlib import Path
from engine_api import ROOT, Engine, projection

from resource_supervisor import supervise, announce_child
NAMES='EPSL'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def usage():
    r=resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime+r.ru_stime

def check_freeze():
    manifest=json.loads((ROOT/'freeze/manifest.json').read_text())
    for relative,expected in manifest['hashes'].items():
        if Path(relative).is_absolute() or '..' in Path(relative).parts or relative.startswith('answers/') or 'seeds' in Path(relative).name:
            raise RuntimeError('Forbidden private/escaping verification path')
        if sha(ROOT/relative)!=expected: raise RuntimeError('Frozen file changed: '+relative)
    return manifest

def batch_inner(fixture,name,repeats,cap):
    # One process per method/fixture batch. All repetitions share the same caps.
    def bounds():
        as_cap=int(os.environ['STUDY056_PROCESS_AS']);cpu_cap=int(os.environ['STUDY056_SOLVER_CPU'])
        resource.setrlimit(resource.RLIMIT_AS,(as_cap,as_cap))
        resource.setrlimit(resource.RLIMIT_CPU,(cpu_cap,cpu_cap))
    from engine_api import request
    child0=usage(); own0=time.process_time(); wall0=time.perf_counter()
    process=subprocess.Popen([str(ROOT/'source/solver')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1,preexec_fn=bounds)
    announce_child(process.pid,int(os.environ['STUDY056_WORKER_CPU']))
    outputs=[];failure=None
    try:
        for rep in range(repeats):
            # The OS cap includes startup, input parsing, output and prior reps.
            remain=max(0.001,cap-sum(x['cpu_seconds'] for x in outputs))
            process.stdin.write(request(NAMES.index(name),fixture['ciphertext'],fixture['clues'],limit=remain));process.stdin.flush()
            line=process.stdout.readline()
            if not line: failure='engine process ended before fixed batch completion';break
            result=json.loads(line);result['projection']=projection(result,97);outputs.append(result)
            if not result['complete']: failure='internal CPU limit';break
        process.stdin.close();process.wait()
    except (BrokenPipeError,ValueError) as error:
        failure=type(error).__name__+': '+str(error);process.wait()
    wall=time.perf_counter()-wall0;child=usage()-child0;own=time.process_time()-own0
    complete=len(outputs)==repeats and all(x['complete'] for x in outputs) and not failure and child+own<=cap
    if outputs:
        result=outputs[0]
        for other in outputs[1:]:
            if result['solutions']!=other['solutions'] or result['metrics']!=other['metrics'] or result['nogoods']!=other['nogoods'] or result['projection']!=other['projection'] or result.get('nogood_reuses',[])!=other.get('nogood_reuses',[]):
                raise RuntimeError('Nondeterministic repeated solution/metrics')
    else:
        result={'solutions':[],'nogoods':[],'metrics':{},'cpu_seconds':0,'first_witness_cpu_seconds':-1,'preprocessing_cpu_seconds':0,'peak_rss_kib':0}
    result['complete']=complete
    result['batch']={'repeats_planned':repeats,'repeats_completed':len(outputs),'cpu_cap_seconds':cap,'child_cpu_seconds':child,'driver_cpu_seconds':own,'end_to_end_cpu_seconds':child+own,'wall_seconds':wall,'normalized_end_to_end_cpu_seconds':(child+own)/repeats if complete else None,'normalized_wall_seconds':wall/repeats if complete else None,'per_repeat_solver_cpu_seconds':[x['cpu_seconds'] for x in outputs],'per_repeat_preprocessing_cpu_seconds':[x['preprocessing_cpu_seconds'] for x in outputs],'per_repeat_first_witness_cpu_seconds':[x['first_witness_cpu_seconds'] for x in outputs],'exit_code':process.returncode,'failure':failure,'censored':not complete}
    if 'projection' not in result:result['projection']=projection(result,97)
    if not complete:result['projection']['status']='INCONCLUSIVE'
    # Include output canonicalization and hashing in end-to-end timing/caps.
    own=time.process_time()-own0;wall=time.perf_counter()-wall0
    if child+own>cap:
        result['complete']=False;result['projection']['status']='INCONCLUSIVE'
    result['batch']['worker_peak_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    result['batch']['solver_peak_rss_kib']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    result['batch']['conservative_pair_peak_rss_upper_bytes']=1024*(result['batch']['worker_peak_rss_kib']+result['batch']['solver_peak_rss_kib'])
    result['batch'].update(driver_cpu_seconds=own,end_to_end_cpu_seconds=child+own,wall_seconds=wall,normalized_end_to_end_cpu_seconds=(child+own)/repeats if result['complete'] else None,normalized_wall_seconds=wall/repeats if result['complete'] else None,censored=not result['complete'])
    return result

def batch(fixture,name,repeats,cap):
    payload=json.dumps({'fixture':fixture,'name':name,'repeats':repeats,'cap':cap})
    observed=supervise([sys.executable,str(Path(__file__).resolve()),'--worker'],payload,cap)
    failure=observed['failure']
    if not observed['abnormal_group_cleanup_confirmed']:
        (ROOT/'audit'/('resource-abort-'+fixture['id']+'-'+name+'.json')).write_text(json.dumps(observed,indent=2)+'\n')
        raise RuntimeError('Resource cleanup cannot be certified; entire benchmark stopped')
    if failure or observed['returncode']:
        result={'complete':False,'solutions':[],'nogoods':[],'nogood_reuses':[],'metrics':{},'cpu_seconds':0,'peak_rss_kib':0,'batch':{'repeats_planned':repeats,'repeats_completed':0,'cpu_cap_seconds':cap,'normalized_end_to_end_cpu_seconds':None,'censored':True,'failure':failure or observed['stderr'][-500:],'exit_code':observed['returncode']}}
        result['projection']=projection(result,97)
    else:
        result=json.loads(observed['stdout'])
        result['batch']['inner_normalized_cpu_seconds']=result['batch']['normalized_end_to_end_cpu_seconds']
        result['batch']['inner_batch_cpu_seconds']=result['batch']['end_to_end_cpu_seconds']
        result['batch']['end_to_end_cpu_seconds']=observed['outer_total_cpu_seconds']
        result['batch']['normalized_end_to_end_cpu_seconds']=observed['outer_total_cpu_seconds']/repeats if result['complete'] else None
        result['batch']['wall_seconds']=observed['outer_wall_seconds']
        result['batch']['normalized_wall_seconds']=observed['outer_wall_seconds']/repeats if result['complete'] else None
    result['resource_receipt']={k:v for k,v in observed.items() if k not in ('stdout','stderr','samples')}
    result['resource_receipt']['first_sample']=observed['samples'][0] if observed['samples'] else None
    result['resource_receipt']['last_sample']=observed['samples'][-1] if observed['samples'] else None
    result['resource_receipt']['exactly_one_child_announced']=observed['solver_pid'] is not None
    return result

def forbid_private_answers(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).resolve()
        if str(p).startswith(str(ROOT/'answers')+'/') or (p.parent==ROOT/'development' and ('answers' in p.name or 'seeds' in p.name)):
            raise RuntimeError('Blind harness forbidden from opening answer or seed bytes')

def main():
    sys.addaudithook(forbid_private_answers)
    args=argparse.ArgumentParser();args.add_argument('--run',action='store_true');args.add_argument('--worker',action='store_true');a=args.parse_args()
    if a.worker:
        payload=json.load(sys.stdin); result=batch_inner(**payload);print(json.dumps(result,separators=(',',':')));return
    if not a.run: raise SystemExit('Explicit --run required; no target interface exists.')
    manifest=check_freeze();spec=manifest['execution'];path=ROOT/spec['input_file'];fixtures=[json.loads(x) for x in path.read_text().splitlines()]
    assert len(fixtures)==256
    output=ROOT/'results';output.mkdir(exist_ok=True)
    if any(output.glob('*.json')):raise RuntimeError('Refusing to overwrite existing held-out outputs')
    own0=time.process_time();child0=usage();wall0=time.perf_counter();log=[];failure_reserves=0.0
    for index,f in enumerate(fixtures):
        assert set(f)=={'id','ciphertext','clues'} and len(f['ciphertext'])==97
        assert [x[0] for x in f['clues']]==list(range(21,34))+list(range(63,74))
        shift=int(f['id'][:8],16)%4;order=list(NAMES[shift:]+NAMES[:shift])
        if int(f['id'][-1],16)%2:order.reverse()
        row={'id':f['id'],'input_sha256':hashlib.sha256(json.dumps(f,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'method_order':order,'methods':{}}
        for name in order:
            row['methods'][name]=batch(f,name,spec['fixed_batch_repeats'],spec['engine_fixture_cpu_cap_seconds'])
            failure_reserves+=row['methods'][name]['resource_receipt']['unreaped_cpu_reserve_seconds']
        path=output/(f['id']+'.json');path.write_text(json.dumps(row,separators=(',',':'))+'\n')
        used=usage()-child0+time.process_time()-own0+failure_reserves
        log.append({'fixture':f['id'],'cumulative_cpu_seconds':used,'wall_seconds':time.perf_counter()-wall0,'sha256':sha(path)})
        (ROOT/'audit/benchmark-progress.json').write_text(json.dumps(log,indent=2)+'\n')
        print(index+1,f['id'],round(used,3),{m:row['methods'][m]['projection']['status'] for m in NAMES},flush=True)
        if used>spec['benchmark_global_cpu_cap_seconds']:raise RuntimeError('Benchmark phase cap reached; no target advance')
    receipt={'status':'FIXED_BATCHES_FINALIZED_ANSWERS_UNOPENED','fixtures':len(log),'cpu_seconds':usage()-child0+time.process_time()-own0+failure_reserves,'unreaped_failure_cpu_reserve_seconds':failure_reserves,'wall_seconds':time.perf_counter()-wall0,'driver_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'output_hashes':{x['fixture']:x['sha256'] for x in log},'freeze_sha256':sha(ROOT/'freeze/manifest.json')}
    (ROOT/'audit/benchmark-seal.json').write_text(json.dumps(receipt,indent=2)+'\n')
if __name__=='__main__':main()
