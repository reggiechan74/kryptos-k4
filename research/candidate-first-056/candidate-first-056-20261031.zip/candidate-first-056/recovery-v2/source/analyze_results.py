"""Preregistered gate analysis; run only after sealed independent answer audit."""
import hashlib, json, math, random, statistics
from pathlib import Path
from engine_api import ROOT
BOOTSTRAP_SEED=56003110
BOOTSTRAP_REPLICATES=10000

def interval(k,n,alpha=.05):
    if not n:return [None,None]
    # Exact Clopper-Pearson bounds by binomial tail inversion.
    def cdf(x,limit):return sum(math.comb(n,j)*x**j*(1-x)**(n-j) for j in range(limit+1))
    def bisect(target,limit):
        lo,hi=0.,1.
        for _ in range(70):
            mid=(lo+hi)/2
            if cdf(mid,limit)>target:lo=mid
            else:hi=mid
        return (lo+hi)/2
    return [0. if k==0 else bisect(1-alpha/2,k-1),1. if k==n else bisect(alpha/2,k)]

def ratio(rows,numerator,denominator):
    logs=[];ids=[]
    for row in rows:
        x=row['methods'][numerator];y=row['methods'][denominator]
        if x['complete'] and y['complete']:
            tx=x['batch']['normalized_end_to_end_cpu_seconds'];ty=y['batch']['normalized_end_to_end_cpu_seconds']
            assert tx>0 and ty>0
            logs.append(math.log(tx/ty));ids.append(row['id'])
    if not logs:return {'n':0,'geometric_mean':None,'bootstrap_95':None}
    rng=random.Random(BOOTSTRAP_SEED);n=len(logs);est=[]
    for _ in range(BOOTSTRAP_REPLICATES):est.append(math.exp(sum(logs[rng.randrange(n)] for j in range(n))/n))
    est.sort();return {'n':n,'geometric_mean':math.exp(sum(logs)/n),'bootstrap_95':[est[249],est[9749]],'paired_ids':ids}

def main():
    replay=json.loads((ROOT/'audit/independent-replay.json').read_text())
    if not replay.get('passed') or replay.get('errors'):raise RuntimeError('Independent audit has errors')
    freeze=json.loads((ROOT/'freeze/manifest.json').read_text());W=freeze['execution']['selected_method']
    rows=[json.loads(p.read_text()) for p in sorted((ROOT/'results').glob('*.json'))]
    answers={a['id']:a for a in map(json.loads,(ROOT/'answers/heldout-answers.jsonl').read_text().splitlines())}
    # Answer schema is frozen by independent fixture author; class details below
    # use the explicit category and class fields, never infer truth from outputs.
    records=[]
    for row in rows:
        a=answers[row['id']];r=row['methods'][W];s=r['projection'];plant=a.get('plant')
        truths=set(tuple(z['plaintext']) for z in r['solutions'])
        truth=tuple(plant['plaintext']) in truths if plant else None
        records.append({'id':row['id'],'category':a['category'],'class':a.get('class'),'complete':r['complete'],'status':s['status'],'unique':r['complete'] and s['distinct_plaintext_count']==1,'plant_plaintext_included':truth,'operator_count':s['canonical_operator_count'],'plaintext_count':s['distinct_plaintext_count']})
    groups={}
    for x in records:
        label=x['category']+('/'+str(x['class']) if x['class'] is not None else '')
        groups.setdefault(label,[]).append(x)
    groups['pooled/random_control']=[x for x in records if x['category']=='random_control']
    groups['pooled/corruption_control']=[x for x in records if x['category']=='corruption_control']
    groups['pooled/mismatch']=[x for x in records if x['category'].startswith('mismatch_')]
    groups['pooled/primary_UJL']=[x for x in records if x['category']=='primary' and x['class'] in ('U','J','L')]
    stats={}
    for label,g in groups.items():
        unique=sum(x['unique'] for x in g);sat=sum(x['plaintext_count']>0 for x in g)
        stats[label]={'n':len(g),'complete':sum(x['complete'] for x in g),'unique':unique,'sat':sat,'unique_95_exact':interval(unique,len(g)),'sat_95_exact':interval(sat,len(g)),'plant_plaintext_included':sum(x['plant_plaintext_included'] is True for x in g)}
    completion={m:sum(x['methods'][m]['complete'] for x in rows) for m in 'EPSL'}
    effects={f'{a}/{b}':ratio(rows,a,b) for a,b in [('E',W),('E','P'),('E','S'),('E','L'),('S','L'),('P','S')]}
    positives=[x for x in records if x['category']=='primary' and x['class'] in ('U','J','L')]
    literals=[x for x in positives if x['class']=='L']
    recovery=sum(x['unique'] and x['plant_plaintext_included'] for x in positives)
    literal_recovery=sum(x['unique'] and x['plant_plaintext_included'] for x in literals)
    random_controls=[x for x in records if x['category']=='random_control']
    assert len(positives)==84 and len(literals)==28 and len(random_controls)==56
    cross=replay['cross_branch_reuses']['modular']
    cross_cases=replay['cross_branch_reuses']['fixtures_with_modular_reuse']
    cross_all=replay['cross_branch_reuses']['verified']
    rep=effects[f'E/{W}'];learn=effects['S/L']
    tiny=json.loads((ROOT/'audit/tiny-report.json').read_text())
    rectangle=json.loads((ROOT/'audit/tiny-rectangle-report.json').read_text())
    correctness=tiny.get('status')=='PASS' and rectangle.get('status')=='PASS' and replay.get('passed') and not replay.get('errors') and all(len({x['methods'][m]['projection']['operator_set_sha256'] for m in 'EPSL' if x['methods'][m]['complete']})<=1 for x in rows)
    gates={'correctness_cross_method':correctness,'completion':completion[W]==256 and completion['E']>=244,'identifiability':recovery>=80 and literal_recovery>=26,'representation_value':rep['n']>0 and rep['geometric_mean']>=2 and rep['bootstrap_95'][0]>1.25,'learning_value':learn['n']>0 and learn['geometric_mean']>=1.2 and learn['bootstrap_95'][0]>1 and cross>=50 and cross_cases>=10,'uniform_false_fit':sum(x['unique'] for x in random_controls)<=1}
    totals={m:{'batch_cpu_seconds':sum(x['methods'][m]['batch'].get('end_to_end_cpu_seconds',20) for x in rows),'capped_average_seconds':sum(x['methods'][m]['batch'].get('normalized_end_to_end_cpu_seconds') or (20/freeze['execution']['fixed_batch_repeats']) for x in rows)/len(rows),'metrics':{k:sum(x['methods'][m]['metrics'].get(k,0) for x in rows) for k in rows[0]['methods'][m]['metrics']}} for m in 'EPSL'}
    report={'selected_method':W,'gates':gates,'method_target_admission_numerical':all(v for k,v in gates.items() if k!='learning_value'),'target_executed':False,'independent_parent_review_required':True,'recovery_unique':{'ordinary':recovery,'n':84,'exact95':interval(recovery,84),'literal':literal_recovery,'literal_n':28,'literal_exact95':interval(literal_recovery,28)},'completion':completion,'effects':effects,'groups':stats,'learning_cross_branch_unique':cross,'learning_cross_branch_all_verified':cross_all,'learning_cross_branch_cases':cross_cases,'totals':totals,'records':records,'bootstrap_seed':BOOTSTRAP_SEED,'bootstrap_replicates':BOOTSTRAP_REPLICATES}
    (ROOT/'audit/analysis.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('selected_method','gates','method_target_admission_numerical','completion','recovery_unique','learning_cross_branch_unique','learning_cross_branch_cases')},indent=2))
if __name__=='__main__':main()
