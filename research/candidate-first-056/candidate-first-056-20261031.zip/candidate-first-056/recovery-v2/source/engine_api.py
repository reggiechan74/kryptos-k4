"""Numeric transport and exact projections. Deliberately has no target loader."""
import hashlib, json, os, subprocess, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def request(mode, ciphertext, clues, widths=(6,7,8,9), periods=range(2,9), alphabet=26, limit=20):
    v=[mode,len(ciphertext),alphabet,limit,len(widths),*widths,len(periods),*periods,len(clues),*ciphertext]
    v.extend(x for pair in clues for x in pair)
    return ' '.join(map(str,v))+'\n'

class Engine:
    def __init__(self):
        self.process=subprocess.Popen([str(ROOT/'source/solver')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
    def solve(self,*args,**kw):
        line=request(*args,**kw); t=time.perf_counter()
        self.process.stdin.write(line); self.process.stdin.flush()
        out=self.process.stdout.readline()
        if not out: raise RuntimeError('Solver exited without result')
        obj=json.loads(out);obj['request_wall_seconds']=time.perf_counter()-t
        return obj
    def close(self):
        self.process.stdin.close();self.process.wait()
        if self.process.returncode: raise RuntimeError(self.process.returncode)

def projection(result,n):
    operators={}; plains={}
    for s in result['solutions']:
        route=tuple(i for c in s['order'] for i in range(c,n,s['width']))
        stream=tuple(s['key'][i%s['period']] for i in range(n))
        op=(route,stream);pt=tuple(s['plaintext'])
        operators.setdefault(op,[]).append((s['width'],s['period'],tuple(s['order']),tuple(s['key'])))
        plains.setdefault(pt,set()).add(op)
    canonical=sorted((r,k) for r,k in operators)
    ph=hashlib.sha256(json.dumps(sorted(plains),separators=(',',':')).encode()).hexdigest()
    oh=hashlib.sha256(json.dumps(canonical,separators=(',',':')).encode()).hexdigest()
    forced=[len({pt[i] for pt in plains})==1 for i in range(n)] if plains else [False]*n
    status='INCONCLUSIVE'
    if result['complete']:
        status='UNSAT_COMPLETE' if not plains else ('SAT_COMPLETE_UNIQUE_PLAINTEXT' if len(plains)==1 else 'SAT_COMPLETE_MULTIPLE_PLAINTEXTS')
    return {'status':status,'raw_compatible_descriptions':len(result['solutions']),'canonical_operator_count':len(operators),'distinct_plaintext_count':len(plains),'operator_set_sha256':oh,'plaintext_set_sha256':ph,'forced_positions':forced,'plaintext_witnesses':[list(x) for x in sorted(plains)[:2]],'alias_multiplicities':sorted(len(v) for v in operators.values()),'operators_per_plaintext':sorted(len(v) for v in plains.values())}

def encrypt(plaintext,key,width,order,alphabet=26):
    return [(plaintext[i]+key[i%len(key)])%alphabet for c in order for i in range(c,len(plaintext),width)]

def decrypt(ciphertext,key,width,order,alphabet=26):
    output=[None]*len(ciphertext);offset=0
    for c in order:
        for i in range(c,len(ciphertext),width):
            output[i]=(ciphertext[offset]-key[i%len(key)])%alphabet;offset+=1
    return output
