"""No-cipher resource probes. Never used by the benchmark solver path."""
import json,os,resource,subprocess,sys,time
from resource_supervisor import announce_child

def burn(seconds):
    start=time.process_time()
    while time.process_time()-start<seconds:pass

def main():
    x=json.load(sys.stdin)
    code='import time,sys,resource,json; n=int(sys.argv[1]); t=float(sys.argv[2]); s=time.process_time(); b=bytearray(n);\nwhile time.process_time()-s<t: pass\nprint(json.dumps({"self_peak":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))'
    def bounds():
        c=int(os.environ['STUDY056_SOLVER_CPU']);resource.setrlimit(resource.RLIMIT_CPU,(c,c))
    p=subprocess.Popen([sys.executable,'-c',code,str(x.get('child_bytes',0)),str(x.get('child_cpu',0))],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,preexec_fn=bounds)
    announce_child(p.pid,int(os.environ['STUDY056_WORKER_CPU']))
    if x.get('duplicate_announcement'):announce_child(p.pid)
    try:
        b=bytearray(x.get('worker_bytes',0));burn(x.get('worker_cpu',0));out,err=p.communicate()
        print(json.dumps({'child_exit':p.returncode,'worker_as':resource.getrlimit(resource.RLIMIT_AS),'worker_cpu_limit':resource.getrlimit(resource.RLIMIT_CPU),'worker_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'child_peak_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'child_cpu':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,'child_out':out,'child_err':err}))
    except MemoryError:
        p.wait();raise
if __name__=='__main__':main()
