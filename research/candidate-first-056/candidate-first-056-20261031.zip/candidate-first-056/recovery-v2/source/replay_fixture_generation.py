"""Byte-for-byte deterministic replay from withheld generation seeds.

Held-out replay is forbidden until the complete benchmark result seal exists.
No fixture selection or solver is used.
"""
from pathlib import Path
import argparse
import hashlib
import json
import random
import time
from generate_fixtures import dumps, make_case, specification


def replay(root, namespace):
    start = time.process_time()
    heldout = namespace in ('heldout', 'study056-resource-recovery-v2')
    if heldout:
        seal = json.loads((root / 'audit/results-seal.json').read_text())
        assert seal['result_count'] == 256
        for relative, expected in seal['hashes'].items():
            assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected
    base = 'answers/heldout-' if heldout else 'development/'
    seed_path = root / (base + 'seeds.json')
    seed_bytes = bytes.fromhex(json.loads(seed_path.read_text())['root_seed_hex'])
    rng = random.Random(int.from_bytes(seed_bytes, 'big'))
    id_rng = random.Random(int.from_bytes(hashlib.sha256(b'056-opaque-ids' + seed_bytes).digest(), 'big'))
    spec = specification()
    assignments = spec['assignments' if heldout else 'development_assignments']
    paired = []
    for assignment in assignments:
        case_seed = rng.getrandbits(256)
        instance, answer = make_case(random.Random(case_seed), assignment)
        opaque_id = f'{id_rng.getrandbits(128):032x}'
        instance['id'] = opaque_id
        answer.update({'id': opaque_id, 'case_seed_hex': f'{case_seed:064x}', 'namespace': namespace})
        paired.append((instance, answer))
    rng.shuffle(paired)
    input_bytes = ''.join(dumps(instance) + '\n' for instance, _ in paired).encode()
    answer_bytes = ''.join(dumps(answer) + '\n' for _, answer in paired).encode()
    input_path = root / ('fixtures/heldout-inputs.jsonl' if heldout else 'development/inputs.jsonl')
    answer_path = root / ('answers/heldout-answers.jsonl' if heldout else 'development/answers.jsonl')
    assert input_bytes == input_path.read_bytes()
    assert answer_bytes == answer_path.read_bytes()
    result = {'namespace': namespace, 'count': len(paired), 'input_byte_match': True, 'answer_byte_match': True,
              'inputs_sha256': hashlib.sha256(input_bytes).hexdigest(),
              'answers_sha256': hashlib.sha256(answer_bytes).hexdigest(),
              'cpu_seconds': time.process_time() - start}
    (root / 'audit' / (namespace + '-generation-replay.json')).write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--namespace', choices=['development', 'heldout', 'study056-resource-recovery-v2'], required=True)
    args = parser.parse_args()
    print(json.dumps(replay(args.root, args.namespace), indent=2))
