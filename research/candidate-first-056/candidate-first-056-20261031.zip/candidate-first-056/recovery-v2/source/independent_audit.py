"""Post-seal independent verification for study 056.

Written without reading production solver source. Does not perform target work.
Answers may be read only by --audit after every sanitized result is sealed.
"""
from pathlib import Path
import argparse
from collections import Counter, deque
import datetime
import hashlib
import itertools
import json
import resource
import time
from independent_oracle import (MASK, canonical_operator, canonical_digest,
                                decrypt, encrypt, validate_witness)

VERSION = '056-independent-audit-v2'
METHODS = ('E', 'P', 'S', 'L')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line]


def raw_signature(witness):
    return (witness['width'], witness['period'], tuple(witness['order']), tuple(witness['key']))


class IndependentPlacementVerifier:
    """Literal-matrix pair constraints plus independent AC/DFS proof checker."""
    def __init__(self, instance, width, period):
        self.width, self.period = width, period
        self.ciphertext = instance['ciphertext']
        known = dict(instance['clues'])
        rows = [list(range(k, min(k + width, len(self.ciphertext))))
                for k in range(0, len(self.ciphertext), width)]
        columns = [[row[c] for row in rows if c < len(row)] for c in range(width)]
        self.lengths = list(map(len, columns))
        self.starts, self.maps, self.valid = [], [], []
        for column in range(width):
            others = [self.lengths[c] for c in range(width) if c != column]
            sums = {0}
            for length in others:
                sums |= {s + length for s in list(sums)}
            starts = sorted(sums)
            maps, valid = [], 0
            for index, start in enumerate(starts):
                requirements = {}
                okay = True
                for row_index, original_position in enumerate(columns[column]):
                    if original_position in known:
                        slot = original_position % period
                        value = (self.ciphertext[start + row_index] - known[original_position]) % 26
                        if slot in requirements and requirements[slot] != value:
                            okay = False
                        requirements[slot] = value
                maps.append(requirements)
                if okay:
                    valid |= 1 << index
            self.starts.append(starts)
            self.maps.append(maps)
            self.valid.append(valid)
        self.supports = {}
        for c in range(width):
            for d in range(width):
                if c == d:
                    continue
                table = []
                for a, s in enumerate(self.starts[c]):
                    support = 0
                    if self.valid[c] & (1 << a):
                        for b, t in enumerate(self.starts[d]):
                            if not (self.valid[d] & (1 << b)):
                                continue
                            if max(s, t) < min(s + self.lengths[c], t + self.lengths[d]):
                                continue
                            left, right = self.maps[c][a], self.maps[d][b]
                            if any(left[slot] != right[slot] for slot in left.keys() & right.keys()):
                                continue
                            support |= 1 << b
                    table.append(support)
                self.supports[c, d] = table
        self.nodes = 0
        self.root_ac = self.propagate(list(self.valid))

    def propagate(self, domains):
        if any(x == 0 for x in domains):
            return None
        queue = deque((c, d) for c in range(self.width) for d in range(self.width) if c != d)
        while queue:
            c, d = queue.popleft()
            previous = domains[c]
            surviving = 0
            bits = previous
            while bits:
                bit = bits & -bits
                index = bit.bit_length() - 1
                bits -= bit
                if self.supports[c, d][index] & domains[d]:
                    surviving |= bit
            if surviving != previous:
                domains[c] = surviving
                if not surviving:
                    return None
                queue.extend((other, c) for other in range(self.width) if other != c and other != d)
        return domains

    def has_completion(self, domains):
        self.nodes += 1
        domains = self.propagate(domains)
        if domains is None:
            return False
        branch = min((c for c in range(self.width) if domains[c].bit_count() > 1),
                     key=lambda c: (domains[c].bit_count(), c), default=None)
        if branch is None:
            return True
        choices = domains[branch]
        while choices:
            bit = choices & -choices
            choices -= bit
            child = list(domains)
            child[branch] = bit
            if self.has_completion(child):
                return True
        return False

    def geometry_has_completion(self, literals):
        """Independent subset-DP: can any complete route realize these starts?"""
        fixed = {}
        for column, index in literals:
            start = self.starts[column][index]
            if column in fixed and fixed[column] != start:
                return False
            fixed[column] = start
        memo = {}
        full = (1 << self.width) - 1
        def visit(used):
            if used in memo:
                return memo[used]
            offset = sum(self.lengths[c] for c in range(self.width) if used & (1 << c))
            if any(not (used & (1 << c)) and start < offset for c, start in fixed.items()):
                memo[used] = False
                return False
            if used == full:
                return True
            for column in range(self.width):
                if used & (1 << column):
                    continue
                if column in fixed and fixed[column] != offset:
                    continue
                if visit(used | (1 << column)):
                    memo[used] = True
                    return True
            memo[used] = False
            return False
        return visit(0)

    def prove_nogood(self, literals):
        domains = list(self.valid)
        assigned = {}
        for column, index in literals:
            assert 0 <= column < self.width
            assert 0 <= index < len(self.starts[column])
            if column in assigned and assigned[column] != index:
                return {'sound': True, 'proof': 'contradictory_literal_assignments', 'nodes': 0}
            assigned[column] = index
            domains[column] &= 1 << index
        before = self.nodes
        reduced = self.propagate(domains)
        if reduced is None:
            return {'sound': True, 'proof': 'independent_arc_consistency_wipeout', 'nodes': 0}
        exists = self.has_completion(reduced)
        return {'sound': not exists, 'proof': 'independent_exact_completion_search',
                'nodes': self.nodes - before}


def seal(root):
    instances = read_jsonl(root / 'fixtures/heldout-inputs.jsonl')
    assert len(instances) == 256 and len({x['id'] for x in instances}) == 256
    path = root / 'audit/results-seal.json'
    if path.exists():
        raise FileExistsError('Existing seal must not be overwritten')
    hashes = {}
    for instance in instances:
        result_path = root / 'results' / (instance['id'] + '.json')
        data = json.loads(result_path.read_text())
        assert data['id'] == instance['id']
        assert set(data['methods']) == set(METHODS)
        hashes[str(result_path.relative_to(root))] = digest(result_path)
    receipt = {'version': VERSION, 'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'result_count': len(hashes), 'answers_read': False,
               'inputs_sha256': digest(root / 'fixtures/heldout-inputs.jsonl'),
               'hashes': hashes, 'result_hash_manifest_sha256': json_digest(hashes)}
    path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    return receipt


def audit(root):
    start_cpu = time.process_time()
    receipt = json.loads((root / 'audit/results-seal.json').read_text())
    assert receipt['result_count'] == 256
    assert receipt['inputs_sha256'] == digest(root / 'fixtures/heldout-inputs.jsonl')
    for relative, expected in receipt['hashes'].items():
        assert digest(root / relative) == expected, 'Result changed after sealing: ' + relative
    instances = {x['id']: x for x in read_jsonl(root / 'fixtures/heldout-inputs.jsonl')}
    answers = {x['id']: x for x in read_jsonl(root / 'answers/heldout-answers.jsonl')}
    generation = json.loads((root / 'fixtures/heldout-generation-receipt.json').read_text())
    for relative, expected in generation['hashes'].items():
        assert digest(root / relative) == expected, 'Frozen source/fixture changed: ' + relative
    assert set(instances) == set(answers)
    summary = {'version': VERSION, 'results_sealed_before_answer_read': True,
               'result_manifest_sha256': receipt['result_hash_manifest_sha256'],
               'fixture_count': len(instances), 'errors': [], 'methods': {}, 'fixtures': [],
               'nogoods': {'checked': 0, 'independent_ac_wipeouts': 0, 'exact_fallbacks': 0,
                           'fallback_nodes': 0, 'unsound': 0},
               'cross_branch_reuses': {'verified': 0, 'modular': 0, 'structural_only': 0,
                                       'fixtures_with_modular_reuse': 0}, 'witnesses_checked': 0}
    for method in METHODS:
        summary['methods'][method] = {'complete': 0, 'statuses': Counter(), 'primary_classes': {},
                                     'plant_operators_found': 0, 'plant_plaintexts_found': 0,
                                     'guaranteed_corruption_witnesses_found': 0}
    corruption_count = Counter()
    for fixture_id, instance in instances.items():
        answer = answers[fixture_id]
        data = json.loads((root / 'results' / (fixture_id + '.json')).read_text())
        fixture_report = {'id': fixture_id, 'category': answer['category'], 'class': answer['class'],
                          'methods': {}, 'pairwise_complete_set_agreement': True}
        guaranteed = answer.get('guaranteed_corrupted_witness')
        plant = answer.get('plant')
        if answer['category'] == 'corruption_control':
            corruption = answer['corruption']
            original_c = encrypt(plant['plaintext'], plant['key'], plant['width'], plant['order'])
            assert original_c == plant['ciphertext']
            changed = [i for i, (a, b) in enumerate(zip(original_c, instance['ciphertext'])) if a != b]
            assert changed == [corruption['ciphertext_position']]
            index = changed[0]
            assert (instance['ciphertext'][index] - original_c[index]) % 26 == corruption['modular_increment']
            mapped = canonical_operator(plant['width'], plant['order'], plant['key'])[0][index]
            assert mapped == corruption['mapped_plaintext_position']
            noncrib = mapped not in MASK
            assert noncrib == corruption['mapped_position_is_noncrib']
            assert bool(guaranteed) == noncrib
            corruption_count['noncrib' if noncrib else 'crib'] += 1
            if guaranteed:
                validate_witness(instance, guaranteed)
        if answer.get('expected_truth_inclusion'):
            validate_witness(instance, plant)
        complete_sets = {}
        proof_cache = {}
        for method in METHODS:
            result = data['methods'][method]
            complete = result['complete']
            witnesses = result['solutions']
            raw, operators, plaintexts = set(), {}, set()
            for witness in witnesses:
                identity = validate_witness(instance, witness)
                sig = raw_signature(witness)
                assert sig not in raw, 'Duplicate raw description'
                raw.add(sig)
                entry = operators.setdefault(identity, {'witness': witness, 'raw': set()})
                entry['raw'].add(sig)
                plaintexts.add(tuple(witness['plaintext']))
                summary['witnesses_checked'] += 1
            if complete:
                for entry in operators.values():
                    witness = entry['witness']
                    stream = canonical_operator(witness['width'], witness['order'], witness['key'])[1]
                    expected_aliases = set()
                    for period in range(2, 9):
                        if all(stream[i] == stream[i % period] for i in range(len(stream))):
                            expected_aliases.add((witness['width'], period, tuple(witness['order']), tuple(stream[:period])))
                    assert entry['raw'] == expected_aliases, 'Nominal aliases incomplete or incorrect'
                complete_sets[method] = raw
            distinct = len(plaintexts)
            if not complete:
                status = 'INCONCLUSIVE'
            elif not distinct:
                status = 'UNSAT_COMPLETE'
            elif distinct == 1:
                status = 'SAT_COMPLETE_UNIQUE_PLAINTEXT'
            else:
                status = 'SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
            forced = [i for i in range(97) if plaintexts and len({p[i] for p in plaintexts}) == 1]
            method_report = {'complete': complete, 'status': status, 'raw_count': len(raw),
                             'operator_count': len(operators), 'plaintext_count': distinct,
                             'raw_solution_hash': json_digest(sorted(raw)),
                             'operator_set_hash': json_digest(sorted(operators)),
                             'plaintext_set_hash': json_digest(sorted(plaintexts)),
                             'forced_positions': forced,
                             'forced_noncrib_count': sum(i not in MASK for i in forced)}
            if distinct > 1:
                method_report['two_unequal_plaintext_witnesses'] = [list(p) for p in sorted(plaintexts)[:2]]
            if plant:
                if plant.get('stage_order') == 'transposition_then_substitution':
                    route, _ = canonical_operator(plant['width'], plant['order'], [0])
                    stream = [None] * 97
                    for output_index, plaintext_index in enumerate(route):
                        stream[plaintext_index] = plant['key'][output_index % len(plant['key'])]
                    planted_operator = json_digest((route, stream))
                else:
                    planted_operator = canonical_digest(plant['width'], plant['order'], plant['key'])
                method_report['plant_operator_found'] = planted_operator in operators
                method_report['plant_plaintext_found'] = tuple(plant['plaintext']) in plaintexts
                if answer.get('expected_truth_inclusion') and complete:
                    assert method_report['plant_operator_found'] and method_report['plant_plaintext_found'], 'Plant missing'
                summary['methods'][method]['plant_operators_found'] += int(method_report['plant_operator_found'])
                summary['methods'][method]['plant_plaintexts_found'] += int(method_report['plant_plaintext_found'])
            if guaranteed:
                found = raw_signature(guaranteed) in raw and tuple(guaranteed['plaintext']) in plaintexts
                method_report['guaranteed_corruption_witness_found'] = found
                if complete:
                    assert found, 'Guaranteed noncrib corruption witness missing'
                summary['methods'][method]['guaranteed_corruption_witnesses_found'] += int(found)
            nogood_identities = {}
            for nogood in result.get('nogoods', []):
                width, period = nogood['width'], nogood['period']
                literals = tuple(tuple(lit) for lit in nogood['clause_placement_indices'])
                identity_key = (width, period, tuple(sorted(literals)))
                nogood_identities[identity_key] = tuple(tuple(x) for x in nogood.get('discovery_decisions', []))
                cache_key = (width, period)
                if cache_key not in proof_cache:
                    proof_cache[cache_key] = IndependentPlacementVerifier(instance, width, period)
                proof = proof_cache[cache_key].prove_nogood(literals)
                summary['nogoods']['checked'] += 1
                if proof['proof'] == 'independent_arc_consistency_wipeout':
                    summary['nogoods']['independent_ac_wipeouts'] += 1
                elif proof['proof'] == 'independent_exact_completion_search':
                    summary['nogoods']['exact_fallbacks'] += 1
                    summary['nogoods']['fallback_nodes'] += proof['nodes']
                if not proof['sound']:
                    summary['nogoods']['unsound'] += 1
                    raise AssertionError('Unsound learned nogood')
            verified_reuse, modular_reuse, structural_reuse = set(), set(), set()
            for reuse in result.get('nogood_reuses', []):
                width, period = reuse['width'], reuse['period']
                literals = tuple(tuple(x) for x in reuse['clause_placement_indices'])
                identity_key = (width, period, tuple(sorted(literals)))
                assert identity_key in nogood_identities, 'Reuse has no learned-clause receipt'
                assert identity_key not in verified_reuse, 'Unique reuse counted twice'
                discovery = tuple(tuple(x) for x in reuse['discovery_decisions'])
                current = tuple(tuple(x) for x in reuse['reuse_decisions'])
                assert discovery == nogood_identities[identity_key], 'Discovery path mismatch'
                common = 0
                while common < min(len(discovery), len(current)) and discovery[common] == current[common]:
                    common += 1
                assert common < min(len(discovery), len(current)), 'Paths are equal or ancestor-related, not divergent'
                domains = reuse['domains_before_reuse']
                assert len(domains) == width
                checker = proof_cache[width, period]
                for column, domain in enumerate(domains):
                    assert domain and len(domain) == len(set(domain))
                    assert all(0 <= value < len(checker.starts[column]) for value in domain)
                unmatched = 0
                for column, index in literals:
                    assert index in domains[column], 'Clause candidate absent, so reuse is not active'
                    unmatched += int(domains[column] != [index])
                assert unmatched <= 1, 'Clause cannot prune this domain snapshot'
                for column, index in current:
                    assert domains[column] == [index], 'Decision path not reflected in domains'
                verified_reuse.add(identity_key)
                if checker.geometry_has_completion(literals):
                    modular_reuse.add(identity_key)
                else:
                    structural_reuse.add(identity_key)
            claimed = result.get('metrics', {}).get('cross_branch_unique_nogoods', 0)
            assert claimed == len(verified_reuse), 'Cross-branch metric disagrees with unique evidence'
            method_report['verified_cross_branch_reuses'] = len(verified_reuse)
            method_report['verified_modular_cross_branch_reuses'] = len(modular_reuse)
            method_report['verified_structural_cross_branch_reuses'] = len(structural_reuse)
            summary['cross_branch_reuses']['verified'] += len(verified_reuse)
            summary['cross_branch_reuses']['modular'] += len(modular_reuse)
            summary['cross_branch_reuses']['structural_only'] += len(structural_reuse)
            if method == 'L' and modular_reuse:
                summary['cross_branch_reuses']['fixtures_with_modular_reuse'] += 1
            summary['methods'][method]['complete'] += int(complete)
            summary['methods'][method]['statuses'][status] += 1
            fixture_report['methods'][method] = method_report
        complete_values = list(complete_sets.values())
        if complete_values:
            assert all(s == complete_values[0] for s in complete_values), 'Completed solver set mismatch'
        summary['fixtures'].append(fixture_report)
    summary['corruption_mapping_counts'] = dict(corruption_count)
    summary['cpu_seconds'] = time.process_time() - start_cpu
    summary['maxrss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    summary['passed'] = not summary['errors'] and summary['nogoods']['unsound'] == 0
    output = root / 'audit/independent-replay.json'
    output.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    return {k: v for k, v in summary.items() if k != 'fixtures'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--seal', action='store_true')
    choice.add_argument('--audit', action='store_true')
    args = parser.parse_args()
    print(json.dumps(seal(args.root) if args.seal else audit(args.root), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
