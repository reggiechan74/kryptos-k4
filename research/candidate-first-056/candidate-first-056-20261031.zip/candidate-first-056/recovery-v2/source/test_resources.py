"""Independent of cipher inputs: validates actual runtime resource primitives."""
import hashlib,json,resource,sys,time
from pathlib import Path
from resource_supervisor import supervise,proc_stat
ROOT=Path(__file__).resolve().parents[1]
start=time.process_time();reports=[]

def probe(label,payload,cap=20,memory=2*1024**3):
    r=supervise([sys.executable,str(ROOT/'source/resource_probe_worker.py')],json.dumps(payload),cap,memory)
    reports.append({'label':label,**r});return r
normal=probe('normal_single_child_and_reap',{'child_cpu':.03,'worker_cpu':.02,'child_bytes':2**20,'worker_bytes':2**20})
assert normal['returncode']==0 and normal['failure'] is None
n=json.loads(normal['stdout']);assert n['child_exit']==0 and n['worker_as']==[1024**3,1024**3]
assert normal['solver_pid'] and normal['sample_count']>0 and normal['sample_peak_tree_rss_bytes']>0
assert normal['outer_child_cpu_seconds']>=n['child_cpu'] and normal['hard_additive_as_cap_bytes']==2*1024**3
cpu=probe('aggregate_cpu_forced_failure',{'child_cpu':.16,'worker_cpu':.16},cap=.24)
assert cpu['failure']=='Aggregate CPU cap reached',cpu
assert any(x['child_live'] and x['worker_cpu']<.24 and x['cpu_seconds']>=.24 and x['cpu_seconds']-x['worker_cpu']<.24 for x in cpu['samples']),cpu
memory=probe('hard_additive_memory_partition_failure',{'child_bytes':45*1024**2,'worker_bytes':0},memory=128*1024**2)
# Baseline Python AS plus45MiB may fit64MiB; use a guaranteed individual request below total but over half.
if memory['returncode']==0 and json.loads(memory['stdout'])['child_exit']==0:
    memory=probe('hard_additive_memory_partition_failure_strong',{'child_bytes':80*1024**2,'worker_bytes':0},memory=128*1024**2)
assert memory['hard_additive_as_cap_bytes']==128*1024**2
assert memory['returncode']!=0 or json.loads(memory['stdout'])['child_exit']!=0
both=probe('aggregate_memory_normal_with_additive_bound',{'child_bytes':10*1024**2,'worker_bytes':10*1024**2},memory=128*1024**2)
assert both['returncode']==0 and both['failure'] is None
b=json.loads(both['stdout']);assert b['worker_as']==[64*1024**2,64*1024**2]
assert 1024*(b['worker_peak_rss_kib']+b['child_peak_rss_kib'])<128*1024**2
peak=probe('waited_descendant_peak_includes_large_child',{'child_bytes':40*1024**2,'child_cpu':.03,'worker_bytes':0})
assert peak['returncode']==0 and peak['failure'] is None
pk=json.loads(peak['stdout']);assert peak['waited_children_maxrss_kib']>=pk['child_peak_rss_kib']
assert peak['waited_children_maxrss_kib']>=40*1024
assert peak['conservative_pair_peak_rss_upper_bytes']>=1024*(pk['worker_peak_rss_kib']+pk['child_peak_rss_kib'])
repeated=probe('duplicate_child_announcement_rejected',{'child_cpu':.01,'duplicate_announcement':True})
assert repeated['failure']=='Nonzero worker exit'
assert repeated['cpu_accounting']=='CONSERVATIVE_HARD_BOUND_AFTER_ABNORMAL_EXIT'
assert cpu['charged_cpu_seconds']>=cpu['sample_max_tree_cpu_seconds']
assert cpu['unreaped_cpu_reserve_seconds']>0
assert cpu['conservative_pair_peak_rss_upper_bytes'] is None
assert repeated['conservative_pair_peak_rss_upper_bytes'] is None
assert cpu['abnormal_group_cleanup_confirmed'] and repeated['abnormal_group_cleanup_confirmed']
for abnormal in (cpu,repeated):
    try:
        state=proc_stat(abnormal['solver_pid'])['state']
        assert state=='Z',state
    except FileNotFoundError:pass
assert repeated['returncode']!=0 and 'Exactly one solver child permitted' in repeated['stderr']
receipt={'status':'PASS','no_cipher_inputs':True,'reports':reports,'self_cpu_seconds':time.process_time()-start,'children_cpu_seconds':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'source/resource_supervisor.py',ROOT/'source/resource_probe_worker.py',Path(__file__)]}}
(ROOT/'audit/resource-selftest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='reports'},indent=2))
