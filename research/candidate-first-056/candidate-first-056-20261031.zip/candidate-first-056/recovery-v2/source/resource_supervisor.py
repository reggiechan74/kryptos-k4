"""Fail-closed two-process resource supervision for study056 recovery.
Exactly one worker and one persistent solver; no /proc children API needed.
"""
import json, os, resource, signal, subprocess, time
from pathlib import Path

ANNOUNCED=False

def announce_child(pid, worker_cpu_hard=2):
    global ANNOUNCED
    if ANNOUNCED:raise RuntimeError('Exactly one solver child permitted')
    ANNOUNCED=True
    fd=int(os.environ['STUDY056_PID_FD'])
    resource.setrlimit(resource.RLIMIT_CPU,(worker_cpu_hard,worker_cpu_hard))
    os.write(fd,(str(pid)+'\n').encode());os.close(fd)

def proc_stat(pid):
    text=Path(f'/proc/{pid}/stat').read_text();f=text[text.rfind(')')+2:].split()
    return {'pid':pid,'state':f[0],'ppid':int(f[1]),'cpu':sum(float(f[i]) for i in (11,12))/os.sysconf('SC_CLK_TCK'),'reaped_cpu':sum(float(f[i]) for i in (13,14))/os.sysconf('SC_CLK_TCK'),'start_ticks':int(f[19]),'rss_bytes':int(f[21])*os.sysconf('SC_PAGE_SIZE')}

def child_usage():
    r=resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime+r.ru_stime

def supervise(command,payload,cpu_cap=20,memory_cap=2*1024**3,worker_cpu_hard=2,solver_cpu_hard=16):
    """OS AS partition gives hard summed bound independent of sampled RSS.
    Primary CPU hard limits sum18s, leaving two seconds for enforcement granularity.
    Exact outer waited CPU includes all descendants, import/startup and serialization.
    """
    half=memory_cap//2
    read_fd,write_fd=os.pipe();os.set_blocking(read_fd,False)
    env=os.environ.copy();env.update(STUDY056_PID_FD=str(write_fd),STUDY056_PROCESS_AS=str(half),STUDY056_WORKER_CPU=str(worker_cpu_hard),STUDY056_SOLVER_CPU=str(solver_cpu_hard))
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(half,half))
        resource.setrlimit(resource.RLIMIT_CPU,(solver_cpu_hard,solver_cpu_hard))
    child0=child_usage();own0=time.process_time();wall0=time.perf_counter()
    p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,preexec_fn=limits,pass_fds=(write_fd,),env=env)
    os.close(write_fd);failure=None;sent=False;buffer=b'';solver_pid=None;identities={};samples=[];peak_rss=0;max_cpu=0
    def read_announcement():
        nonlocal buffer,solver_pid
        try:buffer+=os.read(read_fd,1024)
        except BlockingIOError:pass
        lines=buffer.splitlines()
        if len(lines)>1:raise RuntimeError('Multiple solver announcements')
        if buffer.endswith(b'\n') and lines:
            new=int(lines[0])
            if solver_pid is not None and solver_pid!=new:raise RuntimeError('Solver identity changed')
            solver_pid=new
    def sample():
        nonlocal peak_rss,max_cpu
        read_announcement()
        try:w=proc_stat(p.pid)
        except FileNotFoundError:
            if p.poll() is None:raise RuntimeError('Live worker /proc stat unavailable')
            return
        if p.pid in identities and identities[p.pid]!=w['start_ticks']:raise RuntimeError('Worker PID reused')
        identities[p.pid]=w['start_ticks'];total=w['cpu']+w['reaped_cpu'];rss=w['rss_bytes'];live_child=False
        if solver_pid is not None:
            try:c=proc_stat(solver_pid)
            except FileNotFoundError:c=None
            if c:
                if c['ppid']!=p.pid:raise RuntimeError('Announced child not owned by worker')
                if solver_pid in identities and identities[solver_pid]!=c['start_ticks']:raise RuntimeError('Solver PID reused')
                identities[solver_pid]=c['start_ticks'];total+=c['cpu']+c['reaped_cpu'];rss+=c['rss_bytes'];live_child=True
        peak_rss=max(peak_rss,rss);max_cpu=max(max_cpu,total)
        samples.append({'cpu_seconds':total,'rss_bytes':rss,'worker_cpu':w['cpu'],'child_live':live_child})
        if total>=cpu_cap:raise RuntimeError('Aggregate CPU cap reached')
        if rss>=memory_cap:raise RuntimeError('Aggregate RSS cap reached')
    try:
        while True:
            try:
                out,err=p.communicate(input=payload if not sent else None,timeout=.005);break
            except subprocess.TimeoutExpired:
                sent=True;sample()
        read_announcement()
    except Exception as error:
        failure=str(error)
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        out,err=p.communicate()
    finally:os.close(read_fd)
    # A nonzero worker can leave its announced solver alive. Always terminate
    # the whole group on an abnormal exit, even if the worker already exited.
    if p.returncode!=0:
        failure=failure or 'Nonzero worker exit'
    if solver_pid is None:
        failure=failure or 'Worker did not announce exactly one child'
    cleanup_confirmed=True
    if failure is not None:
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        if solver_pid is None:cleanup_confirmed=False
        if solver_pid is not None:
            deadline=time.monotonic()+1.0;cleanup_confirmed=False
            while time.monotonic()<deadline:
                try:state=proc_stat(solver_pid)['state']
                except FileNotFoundError:cleanup_confirmed=True;break
                if state=='Z':cleanup_confirmed=True;break
                time.sleep(.005)
    waited=child_usage()-child0;own=time.process_time()-own0;wall=time.perf_counter()-wall0
    waited_maxrss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    if solver_pid is None and failure is None:failure='Worker did not announce exactly one child'
    if waited+own>cpu_cap:failure=failure or 'Exact waited summed CPU exceeded cap'
    # Simultaneous group termination can orphan a killed solver before reaping.
    # Never label the resulting waited usage exact; charge the full CPU hard
    # partition plus two seconds granularity, irrespective of observed usage.
    failure_hard_bound=(worker_cpu_hard if solver_pid is not None else solver_cpu_hard)+solver_cpu_hard+2
    reserve=max(0.0,failure_hard_bound-waited) if failure is not None else 0.0
    accounting='CONSERVATIVE_HARD_BOUND_AFTER_ABNORMAL_EXIT' if failure is not None else 'EXACT_WAITED_WORKER_AND_REAPED_CHILD'
    return {'stdout':out,'stderr':err,'returncode':p.returncode,'failure':failure,'outer_child_cpu_seconds':waited,'outer_monitor_cpu_seconds':own,'outer_total_cpu_seconds':waited+own,'unreaped_cpu_reserve_seconds':reserve,'charged_cpu_seconds':waited+own+reserve,'cpu_accounting':accounting,'abnormal_group_cleanup_confirmed':cleanup_confirmed,'outer_wall_seconds':wall,'sample_peak_tree_rss_bytes':peak_rss,'sample_max_tree_cpu_seconds':max_cpu,'sample_count':len(samples),'known_child_live_samples':sum(x['child_live'] for x in samples),'proc_start_identities':identities,'waited_children_maxrss_kib':waited_maxrss,'conservative_pair_peak_rss_upper_bytes':2*1024*waited_maxrss if failure is None else None,'pair_peak_upper_bound_kind':'MEASURED_WAITED_MAXRSS_SUM_BOUND' if failure is None else 'HARD_ADDITIVE_AS_CAP_ONLY','samples':samples,'worker_pid':p.pid,'solver_pid':solver_pid,'process_as_cap_bytes':half,'hard_additive_as_cap_bytes':2*half,'worker_cpu_hard_seconds':worker_cpu_hard,'solver_cpu_hard_seconds':solver_cpu_hard}
