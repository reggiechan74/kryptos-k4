"""Study 056 independent, literal-row-matrix reference; no target loader.

This module was written by the fixture author without viewing production
solver source. Every function takes explicit synthetic data. Only stdlib.
"""
from itertools import permutations, product
import hashlib
import json

VERSION = '056-independent-row-matrix-v1'
MASK = tuple(range(21, 34)) + tuple(range(63, 74))
LITERAL_BLOCKS = ('EASTNORTHEAST', 'BERLINCLOCK')
assert tuple(map(len, LITERAL_BLOCKS)) == (13, 11)
LITERAL = tuple(ord(x) - 65 for x in ''.join(LITERAL_BLOCKS))


def _validate(symbols, key, width, order, alphabet):
    if not (isinstance(width, int) and 1 <= width <= len(symbols)):
        raise ValueError('width outside message')
    if sorted(order) != list(range(width)):
        raise ValueError('order is not a permutation of physical columns')
    if not key or alphabet < 2:
        raise ValueError('nonempty key and alphabet >= 2 required')
    if any(not isinstance(x, int) or not 0 <= x < alphabet for x in list(symbols) + list(key)):
        raise ValueError('symbol outside alphabet')


def encrypt(plaintext, key, width, order, alphabet=26):
    """Shift plaintext, construct ragged rows, then concatenate named columns."""
    _validate(plaintext, key, width, order, alphabet)
    shifted = [(letter + key[index % len(key)]) % alphabet
               for index, letter in enumerate(plaintext)]
    rows = [shifted[start:start + width] for start in range(0, len(shifted), width)]
    ciphertext = []
    for column in order:
        for row in rows:
            if column < len(row):
                ciphertext.append(row[column])
    return ciphertext


def decrypt(ciphertext, key, width, order, alphabet=26):
    """Make blank row matrix, fill emitted columns, flatten and subtract key."""
    _validate(ciphertext, key, width, order, alphabet)
    rows = []
    remaining = len(ciphertext)
    while remaining:
        rows.append([None] * min(width, remaining))
        remaining -= len(rows[-1])
    cursor = 0
    for column in order:
        for row in rows:
            if column < len(row):
                row[column] = ciphertext[cursor]
                cursor += 1
    assert cursor == len(ciphertext)
    shifted = [letter for row in rows for letter in row]
    return [(letter - key[index % len(key)]) % alphabet
            for index, letter in enumerate(shifted)]


def transpose(plaintext, width, order):
    return encrypt(plaintext, [0], width, order)


def encrypt_reverse(plaintext, key, width, order, alphabet=26):
    """Outside-family diagnostic: transpose first, shift at output indices."""
    transposed = encrypt(plaintext, [0], width, order, alphabet)
    return [(letter + key[index % len(key)]) % alphabet
            for index, letter in enumerate(transposed)]


def effective_period(key):
    for size in range(1, len(key) + 1):
        if len(key) % size == 0 and all(x == key[i % size] for i, x in enumerate(key)):
            return size
    raise AssertionError('unreachable')


def canonical_operator(width, order, key, length=97):
    """Canonical route dependency and complete plaintext-indexed shift stream."""
    rows = [list(range(start, min(start + width, length)))
            for start in range(0, length, width)]
    dependency = tuple(row[column] for column in order for row in rows if column < len(row))
    shifts = tuple(key[index % len(key)] for index in range(length))
    return dependency, shifts


def canonical_digest(width, order, key, length=97):
    payload = canonical_operator(width, order, key, length)
    return hashlib.sha256(json.dumps(payload, separators=(',', ':')).encode()).hexdigest()


def validate_witness(instance, witness, alphabet=26, enforce_primary_domain=True):
    width = witness['width']
    key = witness['key']
    order = witness['order']
    plaintext = witness['plaintext']
    if witness.get('period', len(key)) != len(key):
        raise AssertionError('period/key-length mismatch')
    if enforce_primary_domain:
        assert len(plaintext) == 97 and width in (6, 7, 8, 9) and 2 <= len(key) <= 8
    assert len(plaintext) == len(instance['ciphertext'])
    assert encrypt(plaintext, key, width, order, alphabet) == instance['ciphertext']
    assert decrypt(instance['ciphertext'], key, width, order, alphabet) == plaintext
    assert all(plaintext[i] == v for i, v in instance['clues'])
    return canonical_digest(width, order, key, len(plaintext))


def brute_force(ciphertext, clues, widths, periods, alphabet):
    """Tiny independent oracle: complete keys and routes, no placement pruning."""
    operators = {}
    for width in widths:
        for order in permutations(range(width)):
            for period in periods:
                for key in product(range(alphabet), repeat=period):
                    plaintext = decrypt(ciphertext, key, width, order, alphabet)
                    if all(plaintext[i] == value for i, value in clues):
                        canonical = canonical_operator(width, order, key, len(ciphertext))
                        record = operators.setdefault(canonical, {'plaintext': tuple(plaintext), 'aliases': []})
                        record['aliases'].append((width, period, order, key))
    return operators


def self_test():
    """Literal hand-calculated small known-answer vectors plus matrix roundtrips."""
    letters = lambda x: [ord(c) - 65 for c in x]
    p = letters('ABCDEFGHI')
    k = letters('BC')
    vectors = [(2, [0, 1], 'BDFHJDFHJ'),
               (3, [0, 1, 2], 'BFHDFJDHJ'),
               (4, [0, 1, 2, 3], 'BFJDHDHFJ'),
               (4, [3, 2, 1, 0], 'FJDHDHBFJ')]
    for width, order, expected in vectors:
        assert encrypt(p, k, width, order) == letters(expected)
        assert decrypt(letters(expected), k, width, order) == p
    cases = []
    plain = [(7 * i + 3) % 26 for i in range(97)]
    for width in (6, 7, 8, 9):
        irregular = list(range(width))
        irregular = irregular[2::2] + irregular[1::2] + [0]
        assert sorted(irregular) == list(range(width))
        for name, order in [('identity', list(range(width))),
                            ('reversal', list(reversed(range(width)))),
                            ('irregular', irregular)]:
            for key in ([4, 4], [3, 8, 3, 8], [1, 5, 8, 2, 13, 21, 3]):
                c = encrypt(plain, key, width, order)
                assert decrypt(c, key, width, order) == plain
                assert len(c) == 97
                assert canonical_operator(width, order, key) == canonical_operator(width, order, key * 2)
                cases.append({'width': width, 'order_name': name, 'order': order,
                              'key': key, 'plaintext': plain, 'ciphertext': c})
    return {'version': VERSION, 'hand_known_answer_count': len(vectors),
            'full_length_vector_count': len(cases), 'vectors': cases}


if __name__ == '__main__':
    print(json.dumps(self_test(), indent=2))
