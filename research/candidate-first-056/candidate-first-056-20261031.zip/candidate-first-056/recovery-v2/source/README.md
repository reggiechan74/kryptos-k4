# Study 056 implementation

This directory implements only synthetic Study 056. It does not contain a canonical target ciphertext or target loader.

## Algorithms

All methods use C++17 and the same full unknown-width/period union, modulo arithmetic, column geometry and local crib maps. No width, period, key, order, class, seed or plaintext plant is passed by the benchmark harness.

- E enumerates every complete column order, infers unrestricted key slots directly and rejects at the first contradiction. It makes 2,862,720 route/period trials per complete full-length fixture, not 26-to-the-period seed trials.
- P builds an emission-order prefix, propagates key slots immediately and backtracks without memoization.
- S represents each physical column by an exact ciphertext start. Unary crib consistency, interval nonoverlap, and shared-residue agreement are enforced by iterative arc consistency. Branching is deterministic smallest domain, then smallest column, with ascending starts.
- L is S plus genuinely dynamic failed-decision nogoods. An AC wipeout proves the decision conjunction impossible. Deletion minimization replays ordinary AC from the original unary-valid domains with no learned clauses. Later clauses can prune or unit-propagate only when their literal premises hold. L and S have the same static constraints, ordering and runtime. There is no prefix failure-state cache or analytic compatibility memoization. Every learned clause carries its width, period, full placement-index conjunction and discovery decision path.

Placement indices are positions in the complete sorted subset-sum start table for that physical column, including unary-invalid placements. Instance-local caches are destroyed at each width/period change and each solver run. A cache is never reused between fixtures or timing repetitions. Cross-branch reuse requires a later decision path to diverge from the discovery path; root and ancestor/descendant reuse does not count. A distinct reused clause is counted only once.

Raw solutions include all nominal-period aliases. Canonical operator projection uses the complete output-to-input route and 97-position shift stream. Plaintext projection is separate. Unobserved key slots are fully enumerated in tiny generic tests; all primary slots are constrained by the 13-position contiguous crib.

## Build and verification

Use the installed compiler, without dependencies:

```
g++ -O3 -std=c++17 -Wall -Wextra -pedantic source/solver.cpp -o source/solver
python3 source/test_tiny.py
```

The primary frozen executable and compiler version are committed in the local freeze manifest. The independent matrix oracle does not call solver indexing or placement routines. The full tiny suite exhausts 267,371 fixtures across binary/ternary alphabets, free/partial/full clues, lengths 5, 7, 9, and widths 2, 3, 4. It checks raw, operator and plaintext sets, every witness and every learned clause against concrete independent completions.

The held-out generator and independent auditing files are independent-author code. Their private answer and seed bytes are never opened by the solving harness. The public commitment hashes do not imply cryptographic filesystem isolation; blinding is procedural and also guarded by a Python audit hook in the harness.

## Timing and limits

The selected method is S, designated from eight nonblind development fixtures before held-out solving. Each method/fixture runs a fixed batch of 20 complete repetitions, without warmup. Timing includes preprocessing, solver-process startup, input/output, driver parsing, equality validation and canonical projection on every repetition. Reported normalized time divides total batch CPU by 20 only when the whole batch completes. All repetitions together receive 20 summed CPU seconds and 2 GiB; a process-tree watchdog and OS limits enforce these bounds. The global benchmark reserve is 21,600 CPU seconds, within the shared eight-hour pilot ceiling.

There are no language scores, word candidates, key dictionaries, plaintext completion heuristics or fixture rejection by difficulty. Incomplete searches are labelled INCONCLUSIVE, never exact exclusions. The protocol's method admission and learning claim gates are distinct, and neither authorizes an actual K4 run without independent parent review.
