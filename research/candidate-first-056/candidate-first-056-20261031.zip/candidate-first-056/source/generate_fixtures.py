"""Frozen synthetic-only fixture generator for study 056.

Answers are deliberately separate from sanitized input. No solver import,
selection by solvability, target loader, external data, or language score.
"""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import os
import platform
import random
import resource
import secrets
import time

from independent_oracle import MASK, LITERAL, effective_period, encrypt, encrypt_reverse, decrypt, self_test, canonical_operator

VERSION = '056-fixture-generator-v2'
PROTOCOL_SHA256 = '58cf2196845555b7355f7b6c7f59b11033c462832ad7c1e9ceff79a1ad61d6ea'
WIDTHS = (6, 7, 8, 9)
PERIODS = tuple(range(2, 9))
CELLS = [(width, period) for width in WIDTHS for period in PERIODS]
CLASSES = ('U', 'R', 'J', 'L')


def dumps(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def specification():
    assignments = []
    for cls in CLASSES:
        for width, period in CELLS:
            assignments.append({'category': 'primary', 'class': cls, 'width': width, 'period': period,
                                'key_rule': 'primitive', 'stage_order': 'substitution_then_transposition'})
    for width in WIDTHS:
        assignments.append({'category': 'alias', 'class': 'U', 'width': width, 'period': 6,
                            'key_rule': 'constant', 'stage_order': 'substitution_then_transposition'})
        assignments.append({'category': 'alias', 'class': 'U', 'width': width, 'period': 8,
                            'key_rule': 'primitive_2_repeated', 'stage_order': 'substitution_then_transposition'})
    for width in WIDTHS:
        for period in (3, min(width, 8)):
            assignments.append({'category': 'degeneracy', 'class': 'CONSTANT_CRIB', 'width': width, 'period': period,
                                'key_rule': 'primitive', 'stage_order': 'substitution_then_transposition'})
    for width in WIDTHS:
        for period in (2, 7):
            assignments.append({'category': 'mismatch_reverse', 'class': 'U', 'width': width, 'period': period,
                                'key_rule': 'primitive', 'stage_order': 'transposition_then_substitution'})
    for width in (5, 10):
        for period in (3, 7):
            assignments.append({'category': 'mismatch_width', 'class': 'U', 'width': width, 'period': period,
                                'key_rule': 'primitive', 'stage_order': 'substitution_then_transposition'})
    for width in WIDTHS:
        assignments.append({'category': 'mismatch_period', 'class': 'U', 'width': width, 'period': 9,
                            'key_rule': 'primitive', 'stage_order': 'substitution_then_transposition'})
    for cls in CLASSES:
        for index in range(14):
            assignments.append({'category': 'random_control', 'class': cls, 'ordinal': index})
    for class_index, cls in enumerate(CLASSES):
        for index in range(14):
            width, period = CELLS[(2 * index + class_index) % len(CELLS)]
            assignments.append({'category': 'corruption_control', 'class': cls, 'width': width, 'period': period,
                                'key_rule': 'primitive', 'stage_order': 'substitution_then_transposition'})
    assert len(assignments) == 256
    return {
        'version': VERSION, 'protocol_sha256': PROTOCOL_SHA256,
        'length': 97, 'alphabet': list(range(26)), 'mask': list(MASK),
        'literal_blocks': ['EASTNORTHEAST', 'BERLINCLOCK'],
        'literal_block_lengths': [13, 11],
        'input_schema': {'id': 'opaque 32 lowercase hex characters', 'ciphertext': '97 integers in0..25',
                         'clues': '24 [position, symbol] integer pairs sorted by position'},
        'generation': {
            'entropy': 'secrets.token_bytes(32), one new root seed per namespace',
            'per_case_seed': '256 bits drawn from root-seeded random.Random',
            'ids': '128 random bits from independent root-seeded ID stream; no parameter encoding',
            'input_order': 'root-seeded uniform shuffle after all cases generated',
            'key': 'IID uniform letters, rejection only until required exact primitive period',
            'order': 'uniform shuffle of physical columns',
            'U': 'IID uniform letters in all97 positions',
            'R': 'uniform noncrib; eight uniformly sampled distinct letters, each repeated3 times, uniformly shuffled at mask',
            'J': 'uniform noncrib; one uniformly shuffled alphabet bijection applied to all24 literal reference symbols',
            'L': 'uniform noncrib; fixed24 literal reference letters at mask',
            'CONSTANT_CRIB': 'uniform noncrib; one independent uniform letter repeated at all24 clues',
            'random_control': 'IID uniform ciphertext independent of generated clue values; L values fixed and independent',
            'corruption_control': 'one uniform ciphertext position, uniform nonzero additive change1..25; original plant, mapped plaintext index, and guaranteed altered witness when noncrib retained; no location resampling',
            'gate6_population': '56 independent uniform-ciphertext controls only; corruption cases are sensitivity/correctness diagnostics',
            'diagnostic_note': 'Constant-clue rather than fully constant plaintext degeneration was specified before generation to keep exact output enumeration bounded; no fixture filtering.',
            'expected_assertions': 'in-family positives require planted truth inclusion; controls/mismatches never presupposed UNSAT; full reference set determines labels',
            'selection_rejection': 'none except primitive seed stratification; no solve/time/uniqueness/old-overlap rejection'
        },
        'assignments': assignments,
        'counts': dict(collections.Counter(x['category'] for x in assignments)),
        'development_assignments': [
            {'category': 'development', 'class': cls, 'width': width, 'period': period,
             'key_rule': 'primitive', 'stage_order': 'substitution_then_transposition'}
            for width in WIDTHS for period, cls in [(3, 'U'), (min(width, 8), 'CONSTANT_CRIB')]
        ]
    }


def primitive_key(rng, period):
    while True:
        key = [rng.randrange(26) for _ in range(period)]
        if effective_period(key) == period:
            return key


def plaintext_for(rng, cls):
    text = [rng.randrange(26) for _ in range(97)]
    if cls == 'U':
        return text
    if cls == 'R':
        vals = rng.sample(range(26), 8) * 3
        rng.shuffle(vals)
    elif cls == 'J':
        bijection = list(range(26))
        rng.shuffle(bijection)
        vals = [bijection[v] for v in LITERAL]
    elif cls == 'L':
        vals = LITERAL
    elif cls == 'CONSTANT_CRIB':
        vals = [rng.randrange(26)] * 24
    else:
        raise ValueError(cls)
    assert len(vals) == len(MASK) == 24
    for position, value in zip(MASK, vals):
        text[position] = value
    return text


def make_case(rng, assignment):
    text = plaintext_for(rng, assignment['class'])
    clues = [[position, text[position]] for position in MASK]
    answer = dict(assignment)
    if assignment['category'] == 'random_control':
        ciphertext = [rng.randrange(26) for _ in range(97)]
        answer.update({'plant': None, 'expected_truth_inclusion': False,
                       'expected_solution_status': 'not_assumed', 'clue_values': clues})
    else:
        width, period = assignment['width'], assignment['period']
        rule = assignment['key_rule']
        if rule == 'primitive':
            key = primitive_key(rng, period)
        elif rule == 'constant':
            key = [rng.randrange(26)] * period
        elif rule == 'primitive_2_repeated':
            key = primitive_key(rng, 2) * (period // 2)
        else:
            raise ValueError(rule)
        order = list(range(width))
        rng.shuffle(order)
        reverse = assignment['stage_order'] == 'transposition_then_substitution'
        ciphertext = (encrypt_reverse if reverse else encrypt)(text, key, width, order)
        plant = {'width': width, 'period': period, 'key': key, 'order': order, 'plaintext': text,
                 'ciphertext': list(ciphertext), 'stage_order': assignment['stage_order']}
        if not reverse:
            assert decrypt(ciphertext, key, width, order) == text
        valid_plant = not reverse and width in WIDTHS and period in PERIODS
        answer.update({'plant': plant, 'effective_period': effective_period(key),
                       'expected_truth_inclusion': valid_plant, 'expected_solution_status': 'not_assumed'})
        if assignment['category'] == 'corruption_control':
            position, shift = rng.randrange(97), rng.randrange(1, 26)
            old = ciphertext[position]
            ciphertext[position] = (old + shift) % 26
            mapped_position = canonical_operator(width, order, key)[0][position]
            altered = list(text)
            altered[mapped_position] = (altered[mapped_position] + shift) % 26
            assert encrypt(altered, key, width, order) == ciphertext
            preserved = {'width': width, 'period': period, 'key': key, 'order': order, 'plaintext': altered}
            is_noncrib = mapped_position not in MASK
            if is_noncrib:
                assert all(altered[i] == v for i, v in clues)
            answer.update({'corruption': {'ciphertext_position': position, 'old': old,
                                          'new': ciphertext[position], 'modular_increment': shift,
                                          'mapped_plaintext_position': mapped_position,
                                          'mapped_position_is_noncrib': is_noncrib},
                           'guaranteed_corrupted_witness': preserved if is_noncrib else None,
                           'expected_truth_inclusion': False})
    assert len(ciphertext) == 97
    return {'ciphertext': ciphertext, 'clues': clues}, answer


def generate(root, namespace, protocol, overwrite=False):
    start_cpu = time.process_time()
    if sha(protocol) != PROTOCOL_SHA256:
        raise RuntimeError('Protocol hash does not match final preregistration')
    spec_path = root / 'fixture-specification.json'
    expected_spec = dumps(specification()) + '\n'
    if not spec_path.exists() or spec_path.read_text() != expected_spec:
        raise RuntimeError('Write and approve exact fixture specification before generation')
    spec = specification()
    is_holdout = namespace == 'heldout'
    assignments = spec['assignments'] if is_holdout else spec['development_assignments']
    input_path = root / ('fixtures/heldout-inputs.jsonl' if is_holdout else 'development/inputs.jsonl')
    answer_path = root / ('answers/heldout-answers.jsonl' if is_holdout else 'development/answers.jsonl')
    seed_path = root / ('answers/heldout-seeds.json' if is_holdout else 'development/seeds.json')
    receipt_path = root / ('fixtures/heldout-generation-receipt.json' if is_holdout else 'development/generation-receipt.json')
    for path in (input_path, answer_path, seed_path, receipt_path):
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and not overwrite:
            raise FileExistsError('Never silently overwrite generated fixtures: ' + str(path))
    seed_bytes = secrets.token_bytes(32)
    seed = int.from_bytes(seed_bytes, 'big')
    rng = random.Random(seed)
    id_rng = random.Random(int.from_bytes(hashlib.sha256(b'056-opaque-ids' + seed_bytes).digest(), 'big'))
    paired = []
    for assignment in assignments:
        case_seed = rng.getrandbits(256)
        instance, answer = make_case(random.Random(case_seed), assignment)
        opaque_id = f'{id_rng.getrandbits(128):032x}'
        instance['id'] = opaque_id
        answer.update({'id': opaque_id, 'case_seed_hex': f'{case_seed:064x}', 'namespace': namespace})
        paired.append((instance, answer))
    rng.shuffle(paired)
    input_path.write_text(''.join(dumps(instance) + '\n' for instance, _ in paired))
    answer_path.write_text(''.join(dumps(answer) + '\n' for _, answer in paired))
    seed_path.write_text(dumps({'namespace': namespace, 'root_seed_hex': seed_bytes.hex(),
                                'source': 'secrets.token_bytes(32)', 'python': platform.python_version()}) + '\n')
    receipt = {
        'version': VERSION, 'namespace': namespace, 'count': len(paired),
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'procedural_blinding': is_holdout,
        'answers_revealed_to_solver_author': False if is_holdout else True,
        'protocol_sha256': PROTOCOL_SHA256,
        'hashes': {str(path.relative_to(root)): sha(path) for path in
                   (spec_path, root / 'source/independent_oracle.py', root / 'source/generate_fixtures.py', input_path, answer_path, seed_path)},
        'python_version': platform.python_version(), 'cpu_seconds': time.process_time() - start_cpu,
        'maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'generation_filters': 'primitive period only; no solving performed',
        'sanitized_schema_keys': ['id', 'ciphertext', 'clues']}
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, indent=2, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--protocol', type=Path, default=Path('/workspace/shared/k4-056-family-protocol.md'))
    parser.add_argument('--write-spec', action='store_true')
    parser.add_argument('--namespace', choices=['development', 'heldout'])
    args = parser.parse_args()
    if args.write_spec:
        path = args.root / 'fixture-specification.json'
        if path.exists():
            raise FileExistsError(path)
        path.write_text(dumps(specification()) + '\n')
        print(json.dumps({'specification': str(path), 'sha256': sha(path)}))
    if args.namespace:
        generate(args.root, args.namespace, args.protocol)


if __name__ == '__main__':
    main()
