"""Study 056 fixed-batch blind benchmark. Never opens the answer manifest."""
import argparse, hashlib, json, os, resource, signal, statistics, subprocess, sys, time
from pathlib import Path
from engine_api import ROOT, Engine, projection

NAMES='EPSL'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def usage():
    r=resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime+r.ru_stime

def check_freeze():
    manifest=json.loads((ROOT/'freeze/manifest.json').read_text())
    for relative,expected in manifest['hashes'].items():
        if Path(relative).is_absolute() or '..' in Path(relative).parts or relative.startswith('answers/') or 'seeds' in Path(relative).name:
            raise RuntimeError('Forbidden private/escaping verification path')
        if sha(ROOT/relative)!=expected: raise RuntimeError('Frozen file changed: '+relative)
    return manifest

def batch_inner(fixture,name,repeats,cap):
    # One process per method/fixture batch. All repetitions share the same caps.
    def bounds():
        resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
        resource.setrlimit(resource.RLIMIT_CPU,(int(cap),int(cap)+1))
    from engine_api import request
    child0=usage(); own0=time.process_time(); wall0=time.perf_counter()
    process=subprocess.Popen([str(ROOT/'source/solver')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1,preexec_fn=bounds)
    outputs=[];failure=None
    try:
        for rep in range(repeats):
            # The OS cap includes startup, input parsing, output and prior reps.
            remain=max(0.001,cap-sum(x['cpu_seconds'] for x in outputs))
            process.stdin.write(request(NAMES.index(name),fixture['ciphertext'],fixture['clues'],limit=remain));process.stdin.flush()
            line=process.stdout.readline()
            if not line: failure='engine process ended before fixed batch completion';break
            result=json.loads(line);result['projection']=projection(result,97);outputs.append(result)
            if not result['complete']: failure='internal CPU limit';break
        process.stdin.close();process.wait()
    except (BrokenPipeError,ValueError) as error:
        failure=type(error).__name__+': '+str(error);process.wait()
    wall=time.perf_counter()-wall0;child=usage()-child0;own=time.process_time()-own0
    complete=len(outputs)==repeats and all(x['complete'] for x in outputs) and not failure and child+own<=cap
    if outputs:
        result=outputs[0]
        for other in outputs[1:]:
            if result['solutions']!=other['solutions'] or result['metrics']!=other['metrics'] or result['nogoods']!=other['nogoods'] or result['projection']!=other['projection'] or result.get('nogood_reuses',[])!=other.get('nogood_reuses',[]):
                raise RuntimeError('Nondeterministic repeated solution/metrics')
    else:
        result={'solutions':[],'nogoods':[],'metrics':{},'cpu_seconds':0,'first_witness_cpu_seconds':-1,'preprocessing_cpu_seconds':0,'peak_rss_kib':0}
    result['complete']=complete
    result['batch']={'repeats_planned':repeats,'repeats_completed':len(outputs),'cpu_cap_seconds':cap,'child_cpu_seconds':child,'driver_cpu_seconds':own,'end_to_end_cpu_seconds':child+own,'wall_seconds':wall,'normalized_end_to_end_cpu_seconds':(child+own)/repeats if complete else None,'normalized_wall_seconds':wall/repeats if complete else None,'per_repeat_solver_cpu_seconds':[x['cpu_seconds'] for x in outputs],'per_repeat_preprocessing_cpu_seconds':[x['preprocessing_cpu_seconds'] for x in outputs],'per_repeat_first_witness_cpu_seconds':[x['first_witness_cpu_seconds'] for x in outputs],'exit_code':process.returncode,'failure':failure,'censored':not complete}
    if 'projection' not in result:result['projection']=projection(result,97)
    if not complete:result['projection']['status']='INCONCLUSIVE'
    # Include output canonicalization and hashing in end-to-end timing/caps.
    own=time.process_time()-own0;wall=time.perf_counter()-wall0
    if child+own>cap:
        result['complete']=False;result['projection']['status']='INCONCLUSIVE'
    result['batch'].update(driver_cpu_seconds=own,end_to_end_cpu_seconds=child+own,wall_seconds=wall,normalized_end_to_end_cpu_seconds=(child+own)/repeats if result['complete'] else None,normalized_wall_seconds=wall/repeats if result['complete'] else None,censored=not result['complete'])
    return result

def process_tree_usage(pid):
    """Linux proc accounting includes exited descendants via cutime/cstime."""
    try:
        text=Path(f'/proc/{pid}/stat').read_text(); fields=text[text.rfind(')')+2:].split()
        cpu_ticks=sum(float(fields[i]) for i in (11,12,13,14))
        rss=int(fields[21])*os.sysconf('SC_PAGE_SIZE')
        children=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
    except (FileNotFoundError,ProcessLookupError):return 0.0,0
    seconds=cpu_ticks/os.sysconf('SC_CLK_TCK')
    for child in children:
        c,r=process_tree_usage(int(child));seconds+=c;rss+=r
    return seconds,rss

def batch(fixture,name,repeats,cap):
    # External watchdog sees the worker, live solver, and reaped solver CPU.
    # Monitoring overhead is charged globally, not to cryptanalytic timing.
    def bounds():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
    p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,preexec_fn=bounds)
    payload=json.dumps({'fixture':fixture,'name':name,'repeats':repeats,'cap':cap})
    failure=None;sent=False;peak=0
    while True:
        try:
            out,err=p.communicate(input=payload if not sent else None,timeout=0.01);break
        except subprocess.TimeoutExpired:
            sent=True;used,rss=process_tree_usage(p.pid);peak=max(peak,rss)
            if used>=cap or rss>=2*1024**3:
                failure='external aggregate CPU/memory cap';os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate();break
    if failure or p.returncode:
        result={'complete':False,'solutions':[],'nogoods':[],'metrics':{},'cpu_seconds':0,'peak_rss_kib':peak//1024,'batch':{'repeats_planned':repeats,'repeats_completed':0,'cpu_cap_seconds':cap,'normalized_end_to_end_cpu_seconds':None,'censored':True,'failure':failure or err[-500:],'exit_code':p.returncode},'projection':{}}
        result['projection']=projection(result,97);return result
    result=json.loads(out);result['batch']['watchdog_peak_tree_rss_bytes']=peak
    return result

def forbid_private_answers(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).resolve()
        if str(p).startswith(str(ROOT/'answers')+'/') or (p.parent==ROOT/'development' and ('answers' in p.name or 'seeds' in p.name)):
            raise RuntimeError('Blind harness forbidden from opening answer or seed bytes')

def main():
    sys.addaudithook(forbid_private_answers)
    args=argparse.ArgumentParser();args.add_argument('--run',action='store_true');args.add_argument('--worker',action='store_true');a=args.parse_args()
    if a.worker:
        payload=json.load(sys.stdin); result=batch_inner(**payload);print(json.dumps(result,separators=(',',':')));return
    if not a.run: raise SystemExit('Explicit --run required; no target interface exists.')
    manifest=check_freeze();spec=manifest['execution'];path=ROOT/spec['input_file'];fixtures=[json.loads(x) for x in path.read_text().splitlines()]
    assert len(fixtures)==256
    output=ROOT/'results';output.mkdir(exist_ok=True)
    if any(output.glob('*.json')):raise RuntimeError('Refusing to overwrite existing held-out outputs')
    own0=time.process_time();child0=usage();wall0=time.perf_counter();log=[]
    for index,f in enumerate(fixtures):
        assert set(f)=={'id','ciphertext','clues'} and len(f['ciphertext'])==97
        assert [x[0] for x in f['clues']]==list(range(21,34))+list(range(63,74))
        shift=int(f['id'][:8],16)%4;order=list(NAMES[shift:]+NAMES[:shift])
        if int(f['id'][-1],16)%2:order.reverse()
        row={'id':f['id'],'input_sha256':hashlib.sha256(json.dumps(f,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'method_order':order,'methods':{}}
        for name in order:
            row['methods'][name]=batch(f,name,spec['fixed_batch_repeats'],spec['engine_fixture_cpu_cap_seconds'])
        path=output/(f['id']+'.json');path.write_text(json.dumps(row,separators=(',',':'))+'\n')
        used=usage()-child0+time.process_time()-own0
        log.append({'fixture':f['id'],'cumulative_cpu_seconds':used,'wall_seconds':time.perf_counter()-wall0,'sha256':sha(path)})
        (ROOT/'audit/benchmark-progress.json').write_text(json.dumps(log,indent=2)+'\n')
        print(index+1,f['id'],round(used,3),{m:row['methods'][m]['projection']['status'] for m in NAMES},flush=True)
        if used>spec['benchmark_global_cpu_cap_seconds']:raise RuntimeError('Benchmark phase cap reached; no target advance')
    receipt={'status':'FIXED_BATCHES_FINALIZED_ANSWERS_UNOPENED','fixtures':len(log),'cpu_seconds':usage()-child0+time.process_time()-own0,'wall_seconds':time.perf_counter()-wall0,'driver_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'output_hashes':{x['fixture']:x['sha256'] for x in log},'freeze_sha256':sha(ROOT/'freeze/manifest.json')}
    (ROOT/'audit/benchmark-seal.json').write_text(json.dumps(receipt,indent=2)+'\n')
if __name__=='__main__':main()
