# Candidate 055: forced-fragment diagnostic — protocol review

**Status: design only; no new fragments derived, language scores computed, calibration run, target evaluated, or repository files modified.** Review dated 2026-10-31. This is a candidate protocol for an engineering child to freeze, not an execution receipt.

## Verdict and necessary corrections

The proposed synthetic-ciphertext design is sound for a **bounded research-priority screen**. It cannot establish that English running keys are possible or impossible. Its defensible question is: “Do any of these 12 forced pairs survive a fixed language screen that retains the specified held-out English references while rejecting specified scrambled/random references?”

Three important corrections:

1. Measure retention of the **true generating key/tableau**, not only survival of the maximum over 12. A wrong tableau can rescue a positive case while the true English key is rejected. Calibrate a common threshold on true fragment scores; use the 12-way maximum for negative-case acceptance and target selection.
2. Author/source independence is different from window independence. Hundreds of windows from a few books are not hundreds of independent styles. Encrypting one key under 12 conventions does not supply 12 independent keys. Preserve source groups in uncertainty calculations and show the small group counts.
3. Domain-shift English is a positive stress test. Word-order scrambling, pairing English fragments from different sources, or using an out-of-model cipher does not certify that every derived key is non-English. Call these reference mechanisms or stress controls, not logically incompatible negatives.

The target fragments and 053/054 outcomes are already known. Say **“frozen before this new evaluation”**, not “prospectively registered before seeing K4.” No global confirmatory p-value is available from this adaptively motivated study.

## 1. Scope and immutable arithmetic

- Only direct, position-aligned 97-letter running keys; no unknown alphabets, rotations, key relabelings, transposition, additional layers, spelling variants of cribs, or decoder search.
- Literal plaintext cribs: `EASTNORTHEAST` at zero-based `[21:34]`, `BERLINCLOCK` at `[63:74]`. Two key blocks have lengths 13 and 11; their starts differ by 42 and the unobserved interior gap has length 29.
- Alphabet axes: `AZ=ABCDEFGHIJKLMNOPQRSTUVWXYZ`; `KR=KRYPTOSABCDEFGHIJLMNQUVWXZ`. All 2×2×3 conventions are retained, even if some cases give coincident scores. Key residues are spelled in the plaintext-axis alphabet exactly as in 054.
- For plaintext residue `p`, key residue `k` and ciphertext residue `c`, all modulo 26: Vigenère `c=p+k`, Beaufort `c=k-p`, variant Beaufort `c=p-k`; inverse key formulas are `c-p`, `c+p`, `p-c` respectively.
- Only the 24 ciphertext positions enter the diagnostic. No fabricated full English plaintext is necessary: the fixed literal cribs are sufficient to generate synthetic ciphertext at those positions. Synthetic keys are actual contiguous 97-letter reference windows, not separately chosen 13/11-letter strings.
- Verify the published 054 pairs independently only in the later authorized implementation. This review merely read the existing boundary table.

## 2. Freeze one language model and one score

**Simplest recommended implementation: reuse the unchanged 053 model, not train or tune a new one.** Its training receipt records order 4, 1,600,000 letters from eight documents by Jane Austen, G. K. Chesterton, Maria Edgeworth and Herman Melville; smoothing is `[0.5,5,10,20]`. Its `model/log_tables.bin` recorded SHA-256 is `cf21822e9078c9a9d810cbd5ea57db4f4fd440db793c7f5dd4c3cecf49f1212b`. Verify bytes and provenance before reuse. Exclude **all works by those four author groups**, not merely the eight training files, from development/test.

For a fragment `f`, let `L(f)` be the model's sum of base-two log conditional probabilities, starting with a unigram, then bigram, trigram and thereafter four-gram probabilities. No start-of-sentence token is implied: these are arbitrary substring boundaries. Define

`S(f13,f11) = [L(f13) + L(f11)] / 24` (higher is more English-like).

Reset context at the beginning of **each** fragment. Do not concatenate the fragments, score the 29 missing letters, borrow known surrounding letters from positive keys, or use contexts across the gap. Decode all key strings to literal A–Z before LM lookup. The 42-letter spacing is preserved by sampling, but this additive order-4 score does **not** test long-range coherence or whether one natural source can bridge the gap. Say so explicitly.

For a ciphertext case, derive and score all 12 pairs and retain `T=max_t S_t` and every individual score. A tableau survives when `S_t >= tau`; the case survives when `T >= tau`. No 053 73-letter MDL penalty, 053 full-key entropy ceiling, 053 p-value or 054 exact-lookup gate is reusable for this new statistic. Omit a word model from 055: optional segmentation diagnostics add choices without repairing the main limitation.

## 3. Feasible pinned source plan

Use already available 053/054 public-source assets and their provenance. No assistant-authored key documents, candidate-bank messages, K4-themed prose, new target-driven corpus selection, or new downloads are needed. Materialization/checksum recovery from existing pinned assets is engineering, not a license to expand the source universe.

Candidate source-disjoint roles, using 054 normalized bodies where available:

| Reference stratum | Development author/source groups | Held-out test author/source groups |
|---|---|---|
| Fiction | Bryant, Burgess, Carroll, H. G. Wells, Stevenson, Mark Twain | Mary Shelley, Dickens, Wilde, Stowe, Conrad, Stoker, Emily Brontë, Charlotte Brontë, Conan Doyle |
| Nonfiction / public addresses | 053 `calibration` inaugural speaker groups intersected with the 054 accepted list; Swift | 053 `published_prose_control` inaugural speaker groups intersected with the 054 accepted list; Thoreau; Machiavelli/identified translation group |
| Archaic / verse stress | King James Bible translation tradition; Milton | Blake; Shakespeare; Whitman |

All works/editions/translations attributed to a shared author or source tradition stay in one role. Preserve conservative existing speaker groups (including same-surname groupings) rather than attempting score-driven refinements. Resolve translator/compilation attribution and duplicates before freezing; exclude unresolved cross-role overlap. The archaic split has **only two development and three test groups**: it cannot support a population-wide English guarantee. If source bytes or attribution cannot be verified, stop with an input-provenance blocker; do not substitute a favorable book.

Freeze the full path/hash/author/genre/role table before scoring. Audit exact normalized document duplication and sampled 97-letter-window duplication across training, development and test; remove duplicated references by a fixed role-priority rule before sampling replacement windows, never using target scores. Use the 054 ASCII-letter normalization and existing body boundaries, with no invented cross-document joins. Inspect retained compilation boundaries and prohibit windows crossing a known internal work boundary. Reuse of sources previously examined in 053/054 must be disclosed: these are out-of-training-source controls for this scorer, not sources never previously seen anywhere in the project.

Sample **100 distinct nonoverlapping 97-letter windows per stratum per role**: 300 development and 300 test keys. Select roughly equal numbers per source group, then documents within group, then eligible starts using a fixed seed. Freeze the exact allocation and the deterministic no-overlap sampling algorithm before any score; report any insufficiency rather than duplicating windows. Use label-separated SHA-256-derived seeds from `candidate-first-055-v1`; record the PRNG implementation/version. Nonoverlap reduces dependence but does not remove author effects.

Names and spelling need an explicit stress manifest, not an unsupported assertion that the references cover every case. Before scores, annotate 20 distinct preselected test windows containing genuine proper names and 20 containing genuine historical spellings from these test sources (raw offsets and rationale retained; the two subsets may overlap and do not add independent keys). Use the first qualifying windows in frozen fixture-ID order, not examples chosen for their scores; if either subset is unavailable, record inadequate stress coverage. Also prespecify a **descriptive-only** typo/abbreviation stress set, e.g. one seeded adjacent-letter transposition in each 97-letter window and deterministic removal of listed function words before window extraction. These are altered-text stresses, not samples of ordinary prose. If authentic compressed writing is absent from the existing assets, record that coverage gap; do not claim compression robustness from deleting spaces, since all references are already normalized.

## 4. Synthetic cases and null/reference controls

### English positives

For each reference key, encrypt the fixed crib letters at their 24 positions under each of the 12 true conventions; derive all 12 candidate pairs from each resulting ciphertext. Verify the generating candidate equals the two literal key slices. This produces 12 correlated cases per key. Report true-tableau retention once per distinct key and case-max survival stratified by generating convention. Never count the resulting 3,600 cases as 3,600 independent English keys.

### Required calibration references

- **Uniform-ciphertext reference:** generate 200 independent fresh 24-letter uniform ciphertext cases for test, 200 separately seeded cases for development. Keep the literal plaintext cribs. Derive all 12 candidates jointly from each case. This is a generative reference distribution, not “randomize each tableau independently.” Never preserve the actual K4 crib ciphertext, which makes every forced fragment invariant.
- **Letter-scrambled-key reference:** separately sample 200 held-out source windows per role, outside the positive windows where feasible; permute all 97 letters of each window with a seeded permutation, encrypt under a balanced preassigned true convention, then derive all 12 jointly. Preserve author grouping for analysis. Do not reject/retry a permutation because its score is unexpectedly high. These strings may occasionally retain language-like structure; “acceptance of letter-scrambled references” is the precise metric.

### Descriptive stress references, not mandatory negative truth

Prespecify 100 word-order-scrambled key cases and 100 independently paired-source fragment cases using held-out sources. They can remain locally English-like and are expected limitations of a short character score. An “incompatible-key” control can deliberately pair one English key with ciphertext produced from a different key, but that only disproves the asserted pairing; it does not disprove an English key under another convention. Similarly, a fixed out-of-12 construction is out-of-model, not a certified no-English instance. If included, specify the one construction before scoring and report its 12-way acceptance without treating it as a theorem-level false positive. No additional construction is selected after seeing results.

## 5. Concrete operational gate (freeze before test/target)

The following numbers are **research-budget policy choices**, not universal standards or established English error guarantees.

1. On development positives only, compute each stratum's fifth-smallest true-key score among its 100 windows. Set `tau` to the **minimum** of these three scores. Ties survive. This deliberately protects difficult English styles and does not optimize target separation.
2. Freeze `tau`, code/model/source hashes and all seeds before exposing test scores. No threshold or model selection using test, stress or target scores.
3. Test-calibration admission requires all of:
   - At least 90/100 true-key survivors in each reference stratum; at least 80% retention within every test author/source group having at least ten windows.
   - A one-sided 95% exact binomial upper bound of at most 0.15 for the **uniform-case** acceptance probability (200 genuinely independent generated cases).
   - Letter-scrambled-key case acceptance at most 20% by equal-source-group weighting; its 95th-percentile author-cluster-bootstrap upper sensitivity limit at most 30%.
   - For natural English references, the 2.5th-percentile author-cluster-bootstrap retention sensitivity limit is at least 80% in each stratum. Use 10,000 fixed-seed resamples of whole source groups within stratum, retain their complete fixture blocks, and use equal-source-group weights. Also report leave-one-source-group-out rates. With only three hard-style groups these are descriptive sensitivity checks, not reliable population confidence bounds.
   - At least 18/20 survivors in each authentic name and historical-spelling stress subset. Missing qualifying subsets mean inadequate stress coverage and INCONCLUSIVE calibration. Report altered-text stress results descriptively, without making them a post-hoc veto. No unresolved arithmetic, leakage, normalization, attribution or independent-verifier failure.
4. Any failed/underpowered/unavailable admission item yields **INCONCLUSIVE CALIBRATION**. Do not evaluate the target under a revised threshold. Retain the failed controls and stop 055; a redesigned scorer is a different future experiment.
5. Only after admission, evaluate the **already known** target once with the frozen implementation and independently repeat the same computation. If no tableau survives: **NO DIRECT-ENGLISH-KEY CONTINUATION UNDER THIS SCREEN**. If one or more survive: **FRAGMENT SCREEN SURVIVED**, not “English key found.” List all survivors, all 12 scores, margins to `tau`, and source-stratified empirical reference ranks. A pass earns consideration of a separate decoder benchmark, not an automatic target decoder run.

For target ranks, distinguish the true-key positive reference distribution from the 12-max positive-case distribution and from the 12-max uniform distribution. Report all conventions' case-max reference comparisons or the least adverse one, not a retrospectively favorable generating convention. Zero exceedances among 200 uniform controls is not probability zero; if quoting a Monte Carlo rank use the explicit `(1+# >= target)/(201)` convention and describe it as a uniform-reference tail rank, never probability that English is impossible or that K4 is solved. No project-wide error guarantee follows.

## 6. Verification, budget and stopping

- Before calibration, independently implement alphabet indexing/inversion and the fragment scorer without importing the same arithmetic helper. Exhaustively check all 26×26 plaintext/key residue pairs for all 12 conventions; check exact generated fragment recovery and probability-row normalization; compare scores to tolerance `1e-10` bits/letter on fixed non-target fixtures. Check block reset, arbitrary word-boundary starts, off-by-one coordinates, and failure on malformed inputs.
- Keep target loading behind an explicit admitted gate. The reviewer/verifier may later compare target strings with the committed 054 receipt, but must not use target scores to tune anything.
- Frozen budget: **at most 1 CPU hour and 8 GB peak RAM for 055**, within the report's broader 8-CPU-hour pilot ceiling. Reusing the model should make this inexpensive. No neural model, beam search, gap completion, source hunt or payment/checker submission. If the agreed dataset/verification cannot complete within the cap, save partial receipts and mark **INCONCLUSIVE/BUDGET**; do not extend silently.
- Correctness bugs may be fixed within the cap; retain the failed run and a change log. If discovered after test/target exposure, invalidate dependent results, rerun the identical frozen data and threshold rule, and label the correction. Do not disguise a new scoring/model decision as a bug fix.
- Deliver manifest and hashes; exact score specification; source/split leakage audit; sampled-window offsets; all 12 scores per case; true-key and case-max tables; source-group counts; uncertainty and stress outputs; compute receipt; independent-verification receipt; and a short result with the exact outcome labels above. Keep 053/054 historical findings unchanged.

## Interpretation and simplest fallback

This protocol can justify **resource allocation**, not a mathematical feasibility verdict. Twenty-four letters under a short-context model cannot establish syntax, 29-letter bridge existence, full 97-letter key coherence, source provenance, or artist intent. A fixed low score is evidence of atypicality relative to these references, not an impossibility certificate.

If the engineering child cannot support the proposed admission gate with the available sources, the simplest better alternative is **descriptive-only 055**: unchanged 053 scorer; out-of-author reference score distributions; all 12 target scores only if separately authorized despite inconclusive calibration; clear “not admitted for continuation” outcome. Do not invent population probabilities, add models or expand alphabets until something passes. A genuinely rigorous English impossibility test would require an explicitly finite language definition; that would merely replace the broad English claim with another bounded-domain claim.

## Inputs read for this review

- `/workspace/shared/k4-forced-key-fragment-boundary.md`
- `/workspace/shared/k4-repo-algorithm-audit.md`
- `/workspace/scratch/a41fb414fc4e/k4_report_content.json`
- Existing 053 `reference.py`, `config.json`, `CONTROL_SOURCE_PLAN.json`, `data/SOURCE_RECEIPTS.json`, and `model/training_receipt.json`; existing 054 `corpus_manifest.json`.

All findings above concerning previous experiments are from recorded artifacts, not fresh reproduction. Candidate 055 remains **not run**.
