"""Restore omitted derived arrays from checksum-pinned original 054 raw assets.

Does not download, choose sources, score text, change manifests, or overwrite a
mismatched existing file. This is a packaging/reproduction utility, not study code.
"""
import argparse, hashlib, json, re, struct
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def install(path,data,expected):
    if sha(data)!=expected:raise RuntimeError('Reconstructed checksum mismatch: '+str(path))
    if path.exists():
        if path.read_bytes()!=data:raise RuntimeError('Refusing to overwrite different bytes: '+str(path))
        return
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
def main():
    p=argparse.ArgumentParser();p.add_argument('--raw-asset-root',type=Path,default=Path('/workspace/shared/candidate-first-054'));a=p.parse_args()
    documents=json.loads((ROOT/'source/source_manifest.json').read_text())['documents']
    for d in documents:
        original=Path(d['raw_path']);relative=original.relative_to('/workspace/shared/candidate-first-054');raw=(a.raw_asset_root/relative).read_bytes()
        if sha(raw)!=d['raw_sha256']:raise RuntimeError('Wrong original raw bytes: '+str(relative))
        positions=[d['body_start']+m.start() for m in re.finditer(rb'[A-Za-z]',raw[d['body_start']:d['body_end']])]
        norm=bytes(raw[i] for i in positions).upper();offsets=struct.pack('<'+'I'*len(positions),*positions)
        install(ROOT/d['normalized_path'],norm,d['normalized_sha256']);install(ROOT/d['raw_offsets_path'],offsets,d['offsets_uint32_le_sha256'])
    print('Restored or verified derived arrays for',len(documents),'pinned documents; no scores computed.')
if __name__=='__main__':main()
