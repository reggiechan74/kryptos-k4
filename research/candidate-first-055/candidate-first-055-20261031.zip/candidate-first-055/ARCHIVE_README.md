# Compact archive and reproduction contract

This package preserves the completed study and is **not permission to resume a new search**. Study 055 stopped with no target tableau surviving its fixed screen. No target score was recomputed during archive validation.

## Included

All code, protocol/criteria, frozen manifests, exact fixtures, all calibration and target scores, authentic annotation ledgers, pre-score correction histories, threshold, authorization, compute receipts and independent audit reports are included. The five unchanged 053 model/count binaries are included under sibling `candidate-first-053/model/`; these are byte-identical dependencies, not a new model. Small original receipts, corpus metadata and NLTK license metadata are included for provenance.

## Deliberately omitted

The large normalized corpus copies and uint32 offset arrays under `source/normalized/` and `source/offsets/` are omitted because they are deterministic derivatives of already archived 053/054 source assets. The original raw corpora are not duplicated. `OMITTED_FILES_INVENTORY.json` lists every omitted derived file and raw dependency, its exact byte size, checksum and reconstruction/source reference. Python bytecode caches are also excluded; they are not research inputs.

This is a **dependency-backed reproducible package**, not a self-contained copy of every original corpus. A current download at the same URL is not interchangeable with the pinned bytes: reject a checksum mismatch rather than silently substituting a newer transcription.

## Check the archive without any source downloads or scoring

Extract the ZIP into a fresh directory, keeping both sibling study directories, then run:

```sh
python candidate-first-055/verify_package.py
```

This verifies every included file against `CHECKSUMS.json`. It does not check omitted raw corpora and does not compute a target score. The package itself was independently extracted and checksum-verified before delivery.

## Restore the full historical input layout

For the unchanged historical code, the recorded original paths are `/workspace/shared/candidate-first-053` and `/workspace/shared/candidate-first-054`, with study 055 under `/workspace/shared/candidate-first-055`. In an isolated reproduction environment, extract/mount the package there and materialize the original 054 raw assets to their exact manifest paths. Do not overwrite an existing research workspace. The archive includes their provenance, original acquisition URLs, raw hashes and byte counts. It does not automatically fetch mutable remote sources.

Then restore only the omitted deterministic arrays:

```sh
cd /workspace/shared/candidate-first-055
python restore_omitted_sources.py
```

The restoration helper verifies every raw hash and every resulting normalized/offset hash. It refuses to overwrite mismatched bytes and never changes source roles, boundaries, fixtures or frozen receipts. `--raw-asset-root` allows a different raw directory for reconstruction, but the unchanged frozen historical audits still validate the recorded absolute paths.

## Independent score reproduction, only when separately requested

After all dependencies are available, the unchanged independent audit scripts can repeat calibration or target verification into **new output files**:

```sh
python independent_analysis.py --output /tmp/055-calibration-replay.json
python independent_target.py --output /tmp/055-target-replay.json
```

These commands preserve the original receipts and validate the original freezes. They are documented for future reproducibility, not executed again for this archive. The completed run contains exactly one primary target computation and one independent target repeat. A fresh reproduction's CPU accounting must be recorded separately; do not rewrite the original budget ledger or claim a new run was part of the historical execution.
