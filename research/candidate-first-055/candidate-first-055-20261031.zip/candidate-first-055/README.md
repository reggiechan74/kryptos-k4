# Kryptos K4 study 055 — forced-fragment screen

**NO DIRECT-ENGLISH-KEY CONTINUATION UNDER THIS SCREEN.**

All 17 frozen calibration checks passed, but **0 of 12 target conventions survived**. The independently confirmed best convention was **AZ plaintext / KR ciphertext / variant Beaufort**:

- Best target score: **−7.992897 bits/letter**.
- Frozen threshold: **−4.385648 bits/letter**.
- Margin: **−3.607249 bits/letter**.

This is a bounded research-priority screen—not proof that English running keys are impossible, not a recovered key and not a decipherment. **Study 055 stopped; no decoder, new hypothesis, GitHub publication or Site change followed.**

## Calibration and verification

| Held-out control | Result |
|---|---:|
| True English keys: archaic / fiction / nonfiction | 96/100 · 98/100 · 100/100 |
| Authentic proper-name / historical-spelling windows | 18/20 · 18/20 |
| Uniform / letter-scrambled cases accepted | 0/200 · 0/200 |
| Frozen admission checks | 17/17 passed |
| Independently replayed calibration cases / tableau scores | 8,600 / 103,200 |
| Target calculations | One primary + one independent repeat |

The target maximum was below every held-out true-key score and every positive case maximum, under all 12 generating conventions. Its separate uniform-reference tail rank was **87/201 = 0.432835821**; this is not an English-impossibility probability.

Charged experimental CPU was **120.880 seconds**, including conservative preparation allowances, against a 3,600-second cap. Peak observed RSS was **0.617 GiB**, below 8 GiB. Original 053/054 artifacts are unchanged.

## Read and reproduce

- **`REPORT.md`**: complete findings, all 12 target scores/margins, exact scope and limitations.
- **`PROTOCOL.md`, `IMPLEMENTATION_SPEC.json`, `freeze.json`, `threshold.json`**: criteria and immutable pre-score/pre-test receipts.
- **`source/`, `fixtures/`, `stress_manifest.json`**: source roles, offsets, seeds, authentic annotations and leakage checks.
- **`results/`**: every calibration/target score, gates, reference ranks, compute and independent-verification receipts.
- **`results/external_audit/`**: independent calibration and target audit reports, included with reviewer consent.
- **`ARCHIVE_README.md`, `OMITTED_FILES_INVENTORY.json`, `CHECKSUMS.json`**: compact-package verification and dependency/reconstruction instructions.

The original 314-file freeze was issued before new scores. The target was already known in the project; no blind preregistration is claimed. Target scoring began only after calibration and independent review admitted it, with an additional target-stage freeze.

## Essential limitations

Only three archaic test source groups were available. The name/spelling subsets are entirely archaic; only 10/20 name tokens and 5/20 spelling tokens intersect the scored letters. This additive 13+11-letter character score does not test semantic coherence, sentence order, a shared source, the 29-letter bridge or a coherent full 97-letter key. Word-order-scrambled controls passed 100/100, illustrating that limitation. No broader cipher family is excluded.
