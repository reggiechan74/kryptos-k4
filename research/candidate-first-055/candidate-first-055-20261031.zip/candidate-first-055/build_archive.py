"""Build and validate a compact historical delivery ZIP. No language scoring."""
from pathlib import Path
import hashlib,json,zipfile,subprocess,sys,time,resource
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent
OUT=PARENT/'candidate-first-055-20261031.zip'
VALIDATE=PARENT/'validate-055-archive-20261031'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def omitted(p):
    rel=p.relative_to(ROOT)
    return '__pycache__' in rel.parts or rel.parts[:2] in [('source','normalized'),('source','offsets')]
def main():
    start=time.process_time();records=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and omitted(p) and '__pycache__' not in p.parts:
            records.append(dict(path=str(p.relative_to(ROOT)),sha256=sha(p),size_bytes=p.stat().st_size,
                reason='Deterministic large source derivative; restore from pinned 054 raw bytes with restore_omitted_sources.py.'))
    manifest=json.loads((ROOT/'source/source_manifest.json').read_text())
    raw=[]
    for d in manifest['documents']:
        raw.append(dict(document_id=d['document_id'],path=d['raw_path'],sha256=d['raw_sha256'],size_bytes=d['raw_bytes'],source_url=d['source_url'],
                        reason='Unchanged previously archived 054 raw source, not duplicated in 055 compact delivery.'))
    save(ROOT/'OMITTED_FILES_INVENTORY.json',dict(derived_files=records,raw_dependencies=raw,excluded_nonresearch_files='Python __pycache__ files',
        omitted_derived_bytes=sum(r['size_bytes'] for r in records),omitted_raw_bytes=sum(r['size_bytes'] for r in raw),
        dependency_note='The small unchanged model/count binaries are included as sibling candidate-first-053/model files. Full source provenance and hashes remain in source/source_manifest.json and original public receipts.'))
    included={}
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and not omitted(p) and p.name!='CHECKSUMS.json':included['candidate-first-055/'+str(p.relative_to(ROOT))]=p
    for p in sorted((PARENT/'candidate-first-053/model').glob('*.bin')):included['candidate-first-053/model/'+p.name]=p
    for relative in ['CONTROL_SOURCE_PLAN.json','model/training_receipt.json','data/SOURCE_RECEIPTS.json','data/raw/DATASET-LICENSES.md']:
        included['candidate-first-053/'+relative]=PARENT/'candidate-first-053'/relative
    included['candidate-first-054/corpus_manifest.json']=PARENT/'candidate-first-054/corpus_manifest.json'
    save(ROOT/'CHECKSUMS.json',dict(included_files={name:dict(sha256=sha(path),size_bytes=path.stat().st_size) for name,path in included.items()},
         self_note='CHECKSUMS.json is protected by the externally recorded ZIP hash and ZIP integrity; it cannot hash itself.',
         no_language_scores_computed_for_packaging=True))
    included['candidate-first-055/CHECKSUMS.json']=ROOT/'CHECKSUMS.json'
    with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in included.items():z.write(path,name)
    if VALIDATE.exists():raise RuntimeError('Validation directory already exists; use a fresh destination instead of overwriting.')
    VALIDATE.mkdir()
    with zipfile.ZipFile(OUT) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))==len(included)
        for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
        z.extractall(VALIDATE)
    checks=json.loads((VALIDATE/'candidate-first-055/CHECKSUMS.json').read_text())['included_files']
    assert all(sha(VALIDATE/p)==row['sha256'] and (VALIDATE/p).stat().st_size==row['size_bytes'] for p,row in checks.items())
    assert all(sha(VALIDATE/n)==sha(p) for n,p in included.items())
    run=subprocess.run([sys.executable,str(VALIDATE/'candidate-first-055/verify_package.py')],capture_output=True,text=True,check=True)
    result=dict(status='PASS',zip_path=str(OUT),zip_sha256=sha(OUT),zip_bytes=OUT.stat().st_size,
        included_files=len(included),included_payload_bytes=sum(p.stat().st_size for p in included.values()),
        omitted_derived_files=len(records),omitted_derived_bytes=sum(r['size_bytes'] for r in records),omitted_raw_dependencies=len(raw),
        extracted_to=str(VALIDATE),crc_passed=True,path_safety_passed=True,all_included_bytes_roundtrip_identical=True,
        verify_package_stdout=run.stdout.strip(),cpu_seconds=time.process_time()-start,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        no_additional_target_computation=True)
    save(PARENT/'candidate-first-055-archive-validation.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
