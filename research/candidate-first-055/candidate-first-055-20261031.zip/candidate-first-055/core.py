"""Study 055 fixed fragment statistic. Contains no target ciphertext or target loader."""
from pathlib import Path
from array import array
import hashlib, itertools, math, sys
AZ = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
ALPHABETS = {'AZ': AZ, 'KR': 'KRYPTOSABCDEFGHIJLMNQUVWXZ'}
OPERATIONS = ('vigenere', 'beaufort', 'variant_beaufort')
TABLEAUX = tuple(itertools.product(ALPHABETS, ALPHABETS, OPERATIONS))
CRIB = 'EASTNORTHEASTBERLINCLOCK'
MODEL_SHA256 = 'cf21822e9078c9a9d810cbd5ea57db4f4fd440db793c7f5dd4c3cecf49f1212b'

def check_text(s, size=None):
    if not isinstance(s, str) or not s or (size is not None and len(s) != size) or any(c not in AZ for c in s):
        raise ValueError('Expected nonempty literal A-Z text of the specified length')
    return s

def check_tableau(t):
    if t not in TABLEAUX:
        raise ValueError('Unknown fixed tableau')
    return t

def encrypt_text(plaintext, key, t):
    check_tableau(t); check_text(plaintext); check_text(key, len(plaintext))
    pa, ca, op = t; p_axis, c_axis = ALPHABETS[pa], ALPHABETS[ca]
    result = []
    for x, y in zip(plaintext, key):
        p, k = p_axis.index(x), p_axis.index(y)
        c = p + k if op == 'vigenere' else k - p if op == 'beaufort' else p - k
        result.append(c_axis[c % 26])
    return ''.join(result)

def derive_text(plaintext, ciphertext, t):
    check_tableau(t); check_text(plaintext); check_text(ciphertext, len(plaintext))
    pa, ca, op = t; p_axis, c_axis = ALPHABETS[pa], ALPHABETS[ca]
    result = []
    for x, y in zip(plaintext, ciphertext):
        p, c = p_axis.index(x), c_axis.index(y)
        k = c - p if op == 'vigenere' else c + p if op == 'beaufort' else p - c
        result.append(p_axis[k % 26])
    return ''.join(result)

def key_pair(key):
    check_text(key, 97)
    return key[21:34], key[63:74]

def encrypt_pair(key, t):
    return encrypt_text(CRIB, ''.join(key_pair(key)), t)

def derive_pair(ciphertext, t):
    check_text(ciphertext, 24)
    k = derive_text(CRIB, ciphertext, t)
    return k[:13], k[13:]

class Model:
    def __init__(self, path):
        raw = Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest() != MODEL_SHA256:
            raise ValueError('Model bytes do not match the unchanged 053 model')
        self.tables = []; offset = 0
        for order in range(1, 5):
            size = 8 * 26 ** order
            table = array('d'); table.frombytes(raw[offset:offset + size])
            if sys.byteorder != 'little': table.byteswap()
            if len(table) != 26 ** order: raise ValueError('Wrong table length')
            self.tables.append(table); offset += size
        if offset != len(raw): raise ValueError('Unexpected trailing model bytes')

    def fragment_log(self, fragment):
        check_text(fragment)
        total = 0.0; context = 0
        for pos, char in enumerate(fragment):
            order = min(pos + 1, 4)
            index = context * 26 + ord(char) - 65
            total += self.tables[order - 1][index]
            context = index % 17576
        return total

    def score(self, pair):
        if not isinstance(pair, (tuple, list)) or len(pair) != 2: raise ValueError('Expected two fragments')
        check_text(pair[0], 13); check_text(pair[1], 11)
        return (self.fragment_log(pair[0]) + self.fragment_log(pair[1])) / 24

    def case(self, ciphertext):
        return [dict(tableau='-'.join(t), fragments=list(derive_pair(ciphertext, t)),
                     score=self.score(derive_pair(ciphertext, t))) for t in TABLEAUX]
