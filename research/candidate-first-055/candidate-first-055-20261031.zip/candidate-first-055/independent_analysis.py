#!/usr/bin/env python3
"""Independent post-calibration audit. No target input or target loader.

Reads frozen fixtures and saved outputs, reconstructs each non-target case with
independent_verify.py, and independently recomputes threshold and all gates.
Must be run through execution_receipt.py to enforce the aggregate study budget.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import resource
import sys
import time
import traceback
from independent_verify import IndependentScorer, TABLEAUX, CRIB_PLAINTEXT, independent_encrypt, inverse_lookup

ROOT = Path(__file__).resolve().parent
STRATA = ('archaic', 'fiction', 'nonfiction')
IDS = ['-'.join(t) for t in TABLEAUX]


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def lines(path):
    with Path(path).open() as f:
        return [json.loads(line) for line in f]


def seeded(label):
    digest = hashlib.sha256(('candidate-first-055-v1|' + label).encode()).digest()
    return random.Random(int.from_bytes(digest, 'big'))


def near(a, b, tolerance=1e-10):
    assert math.isfinite(a) and math.isfinite(b) and abs(a - b) <= tolerance, (a, b)


def quantile(values, probability):
    return sorted(values)[math.ceil(len(values) * probability) - 1]


def summary(fixtures, decisions):
    groups = defaultdict(list)
    for row in fixtures:
        groups[row['group']].append(decisions[row['id']])
    return {g: {'n': len(v), 'survivors': sum(v), 'rate': sum(v) / len(v)}
            for g, v in sorted(groups.items())}


def bootstrap(group_rows, label):
    r = seeded(label)
    groups = list(sorted(group_rows))
    rates = [group_rows[g]['rate'] for g in groups]
    n = len(rates)
    # Each selected source group contributes its entire fixture block's retention
    # rate. Equal group weighting does not inflate large sources' influence.
    draws = []
    for _ in range(10000):
        sample = [rates[r.randrange(n)] for _ in range(n)]
        draws.append(sum(sample) / n)
    return {'equal_group_rate': sum(rates) / n,
            'lower_2_5_percentile': quantile(draws, .025),
            'upper_95_percentile': quantile(draws, .95),
            'leave_one_group_out': {g: sum(group_rows[h]['rate'] for h in groups if h != g) / (n - 1)
                                   if n > 1 else None for g in groups},
            'bootstrap_mean_values': draws}


def binomial_upper(k, n):
    """One-sided Clopper-Pearson bound, log-gamma summands and bisection."""
    assert 0 <= k <= n
    if k == n:
        return 1.
    low, high = 0., 1.
    logarithmic_coefficients = [math.lgamma(n + 1) - math.lgamma(j + 1) - math.lgamma(n - j + 1)
                                for j in range(k + 1)]
    for _ in range(120):
        midpoint = (low + high) / 2
        cdf = math.fsum(math.exp(coefficient + j * math.log(midpoint) + (n - j) * math.log1p(-midpoint))
                        for j, coefficient in enumerate(logarithmic_coefficients))
        if cdf < .05:
            high = midpoint
        else:
            low = midpoint
    return (low + high) / 2


class Auditor:
    def __init__(self, root):
        self.root = root
        self.scorer = IndependentScorer(root.parent / 'candidate-first-053/model/log_tables.bin')
        self.inverses = [inverse_lookup(t) for t in TABLEAUX]
        self.cases = 0
        self.individual_scores = 0
        self.max_score_difference = 0.

    def case(self, record):
        cipher = record['ciphertext']
        assert len(cipher) == 24 and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' for c in cipher)
        assert len(record['scores']) == 12
        reconstructed = []
        for expected_id, inv, saved in zip(IDS, self.inverses, record['scores']):
            assert saved['tableau'] == expected_id
            key = ''.join(inv[p, c] for p, c in zip(CRIB_PLAINTEXT, cipher))
            pair = (key[:13], key[13:])
            assert tuple(saved['fragments']) == pair
            calculated = self.scorer.score(pair)
            near(saved['score'], calculated)
            self.max_score_difference = max(self.max_score_difference, abs(saved['score'] - calculated))
            reconstructed.append(calculated)
            self.individual_scores += 1
        near(record['case_max'], max(reconstructed))
        self.cases += 1
        return reconstructed

    def positives(self, role, tau=None):
        fixtures = load(self.root / f'fixtures/positive_{role}.json')
        assert len(fixtures) == 300 and len({f['id'] for f in fixtures}) == 300
        by_id = {f['id']: f for f in fixtures}
        keys = load(self.root / f'results/positive_keys_{role}.json')
        assert len(keys) == 300 and {r['id'] for r in keys} == set(by_id)
        key_by_id = {r['id']: r for r in keys}
        seen = set()
        for record in lines(self.root / f'results/positive_cases_{role}.jsonl'):
            f = by_id[record['fixture_id']]
            tableau_index = IDS.index(record['generating_tableau'])
            identifier = (f['id'], tableau_index)
            assert identifier not in seen
            seen.add(identifier)
            pair = (f['key'][21:34], f['key'][63:74])
            expected_cipher = independent_encrypt(CRIB_PLAINTEXT, ''.join(pair), TABLEAUX[tableau_index])
            assert record['ciphertext'] == expected_cipher
            expected_score = self.scorer.score(pair)
            scores = self.case(record)
            near(record['true_score'], expected_score)
            near(scores[tableau_index], expected_score)
            row = key_by_id[f['id']]
            assert row['group'] == f['group'] and row['stratum'] == f['stratum']
            near(row['true_score'], expected_score)
            near(row['case_max_by_generating_tableau'][tableau_index], max(scores))
            if tau is not None:
                assert row['true_survived'] is (row['true_score'] >= tau)
        assert len(seen) == 3600
        for s in STRATA:
            assert sum(f['stratum'] == s for f in fixtures) == 100
        return fixtures, keys

    def references(self, role, kind, tau):
        fixtures = load(self.root / f'fixtures/{kind}_{role}.json')
        records = lines(self.root / f'results/{kind}_{role}.jsonl')
        assert len(fixtures) == len(records) == 200
        assert [f['id'] for f in fixtures] == [r['id'] for r in records]
        uniform_rng = seeded('uniform-ciphertext|' + role)
        convention_rng = seeded('scramble-convention|' + role)
        conventions = [i % 12 for i in range(200)]
        convention_rng.shuffle(conventions)
        for position, (f, r) in enumerate(zip(fixtures, records)):
            if kind == 'uniform':
                cipher = ''.join('ABCDEFGHIJKLMNOPQRSTUVWXYZ'[uniform_rng.randrange(26)] for _ in range(24))
                assert f['ciphertext'] == cipher
            else:
                letters = list(f['base_key'])
                seeded('letter-permutation|' + f['id']).shuffle(letters)
                assert ''.join(letters) == f['key']
                assert f['generating_tableau_index'] == conventions[position]
                pair = f['key'][21:34] + f['key'][63:74]
                cipher = independent_encrypt(CRIB_PLAINTEXT, pair, TABLEAUX[f['generating_tableau_index']])
                assert r['group'] == f['group']
            assert r['ciphertext'] == cipher
            self.case(r)
            assert r['survived'] is (r['case_max'] >= tau)
        return fixtures, records

    def stress(self, tau):
        fixtures = load(self.root / 'fixtures/descriptive_stress.json')
        records = lines(self.root / 'results/descriptive_stress.jsonl')
        assert len(fixtures) == len(records)
        counts = defaultdict(lambda: {'n': 0, 'true_survivors': 0, 'case_survivors': 0, 'mandatory_gate': False})
        for f, r in zip(fixtures, records):
            assert f['id'] == r['id'] and f['kind'] == r['kind']
            pair = tuple(f['fragments']) if 'fragments' in f else (f['key'][21:34], f['key'][63:74])
            cipher = independent_encrypt(CRIB_PLAINTEXT, ''.join(pair), TABLEAUX[f['generating_tableau_index']])
            assert r['ciphertext'] == cipher
            self.case(r)
            near(r['true_score'], self.scorer.score(pair))
            assert r['true_survived'] is (r['true_score'] >= tau)
            assert r['case_survived'] is (r['case_max'] >= tau)
            group = counts[f['kind']]
            group['n'] += 1
            group['true_survivors'] += r['true_survived']
            group['case_survivors'] += r['case_survived']
        return dict(counts)


def check_bootstrap(expected, saved):
    for field in ('equal_group_rate', 'lower_2_5_percentile', 'upper_95_percentile'):
        near(expected[field], saved[field], 1e-12)
    assert expected['bootstrap_mean_values'] == saved['bootstrap_mean_values']
    assert expected['leave_one_group_out'] == saved['leave_one_group_out']


def run(root):
    freeze = load(root / 'freeze.json')
    assert all(sha(root / p) == h for p, h in freeze['files'].items()), 'A frozen input changed'
    threshold = load(root / 'threshold.json')
    assert threshold['freeze_sha256'] == sha(root / 'freeze.json')
    result = load(root / 'results/calibration_gate.json')
    assert result['target_computed'] is False
    verifier = load(root / 'results/independent_verification.json')
    assert verifier['status'] == 'PASS' and verifier['target_scored'] is False
    auditor = Auditor(root)
    dev_fixtures, dev_keys = auditor.positives('development')
    fifth = {s: sorted(r['true_score'] for r in dev_keys if r['stratum'] == s)[4] for s in STRATA}
    tau = min(fifth.values())
    assert threshold['stratum_fifth_smallest'] == fifth
    assert threshold['tau'] == result['tau'] == tau
    dev_uniform = auditor.references('development', 'uniform', tau)[1]
    dev_scrambled = auditor.references('development', 'letter_scrambled', tau)[1]
    dev_summary = load(root / 'results/development_summary.json')
    assert dev_summary['uniform_case_survivors'] == sum(r['survived'] for r in dev_uniform)
    assert dev_summary['letter_scrambled_case_survivors'] == sum(r['survived'] for r in dev_scrambled)
    for s in STRATA:
        assert dev_summary['true_key_survivors'][s] == sum(r['true_score'] >= tau for r in dev_keys if r['stratum'] == s)
    test_fixtures, test_keys = auditor.positives('test', tau)
    test_decisions = {r['id']: r['true_score'] >= tau for r in test_keys}
    gates = {}
    positive_counts = {}
    for s in STRATA:
        fixtures = [f for f in test_fixtures if f['stratum'] == s]
        groups = summary(fixtures, test_decisions)
        uncertainty = bootstrap(groups, 'bootstrap|positive|' + s)
        saved = result['true_key_strata'][s]
        survivors = sum(test_decisions[f['id']] for f in fixtures)
        assert saved['n'] == len(fixtures) == 100 and saved['survivors'] == survivors
        assert saved['groups'] == groups
        check_bootstrap(uncertainty, saved['sensitivity'])
        for i, t in enumerate(IDS):
            assert saved['case_max_survivors_by_generating_tableau'][t] == sum(
                r['case_max_by_generating_tableau'][i] >= tau for r in test_keys if r['stratum'] == s)
        gates['positive_stratum_' + s] = len(fixtures) == 100 and survivors >= 90
        gates['positive_groups_' + s] = all(v['rate'] >= .8 for v in groups.values() if v['n'] >= 10)
        gates['positive_cluster_' + s] = uncertainty['lower_2_5_percentile'] >= .8
        positive_counts[s] = survivors
    uniform_fixtures, uniform = auditor.references('test', 'uniform', tau)
    k = sum(r['survived'] for r in uniform)
    upper = binomial_upper(k, len(uniform))
    near(upper, result['uniform_reference']['one_sided_exact_binomial_upper_95'], 1e-12)
    assert result['uniform_reference']['n'] == 200 and result['uniform_reference']['survivors'] == k
    gates['uniform_case_acceptance'] = len(uniform) == 200 and upper <= .15
    scrambled_fixtures, scrambled = auditor.references('test', 'letter_scrambled', tau)
    sg = summary(scrambled_fixtures, {r['id']: r['survived'] for r in scrambled})
    ss = bootstrap(sg, 'bootstrap|letter-scrambled|test')
    assert result['letter_scrambled_reference']['groups'] == sg
    check_bootstrap(ss, result['letter_scrambled_reference']['sensitivity'])
    gates['scrambled_equal_group_rate'] = len(scrambled) == 200 and ss['equal_group_rate'] <= .20
    gates['scrambled_cluster_upper'] = ss['upper_95_percentile'] <= .30
    authentic = load(root / 'stress_manifest.json')
    stress_counts = {}
    for label in ('proper_names', 'historical_spellings'):
        ids = [r['fixture_id'] for r in authentic[label]]
        survivors = [identifier for identifier in ids if test_decisions[identifier]]
        expected = {'n': len(ids), 'survivors': len(survivors), 'survivor_ids': survivors,
                    'failed_ids': [identifier for identifier in ids if identifier not in survivors]}
        assert result['authentic_stress'][label] == expected
        gates[label] = len(ids) == 20 and len(set(ids)) == 20 and len(survivors) >= 18
        stress_counts[label] = len(survivors)
    assert auditor.stress(tau) == result['descriptive_stress']
    gates['independent_verification'] = True
    source_audit = load(root / 'source/document_leakage_audit.json')
    source_verification = load(root / 'source/source_verification.json')
    gates['source_provenance_and_leakage'] = (source_verification['all_passed'] and not source_audit['cross_role_group_overlap']
        and not source_audit['translator_audit']['cross_role_conflict']
        and not source_audit['compiler_attribution_audit']['training_or_test_author_name_matches'])
    sampling = load(root / 'fixtures/sampling_receipt.json')
    gates['sampled_window_leakage'] = sampling['cross_role_sampled_window_duplicate_remaining'] == 0 and sampling['training_window_duplicate_remaining'] == 0
    assert gates == result['gates'], {'independent': gates, 'reported': result['gates']}
    assert result['passed_gates'] == sum(gates.values()) and result['total_gates'] == len(gates)
    expected_status = 'CALIBRATION ADMITTED; PAUSED BEFORE TARGET' if all(gates.values()) else 'INCONCLUSIVE CALIBRATION'
    assert result['status'] == expected_status
    return {'status': 'PASS', 'calibration_status': expected_status, 'tau': tau,
            'gates': gates, 'passed_gates': sum(gates.values()), 'total_gates': len(gates),
            'true_key_test_survivors': positive_counts, 'uniform_test_survivors': k,
            'independent_uniform_exact_upper_95': upper, 'authentic_stress_survivors': stress_counts,
            'case_records_recomputed': auditor.cases, 'individual_tableau_scores_recomputed': auditor.individual_scores,
            'maximum_score_difference_bits_per_letter': auditor.max_score_difference,
            'target_loaded': False, 'target_scored': False,
            'independence': 'Independent inverse lookup and scorer; separate seeded bootstrap and log-gamma exact-binomial bound; no main runner import.',
            'source_audit_scope': 'This audit verifies source-audit gates from their separately frozen evidence; it does not reinterpret author attribution.',
            'freeze_sha256': sha(root / 'freeze.json'), 'threshold_sha256': sha(root / 'threshold.json'),
            'calibration_gate_sha256': sha(root / 'results/calibration_gate.json')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=ROOT / 'results/independent_analysis.json')
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Refusing to overwrite an independent audit receipt')
    start = time.monotonic()
    cpu = time.process_time()
    result = {'status': 'FAILED', 'target_loaded': False, 'target_scored': False}
    exit_code = 1
    try:
        result = run(args.root)
        exit_code = 0
    except Exception as exc:
        result.update({'error_type': type(exc).__name__, 'error': str(exc), 'traceback': traceback.format_exc()})
    usage = resource.getrusage(resource.RUSAGE_SELF)
    result.update({'cpu_seconds': time.process_time() - cpu, 'wall_seconds': time.monotonic() - start,
                   'peak_rss_bytes': usage.ru_maxrss * 1024, 'python_version': sys.version,
                   'analysis_code_sha256': sha(__file__)})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'cpu_seconds', 'peak_rss_bytes', 'target_scored')}, sort_keys=True))
    raise SystemExit(exit_code)


if __name__ == '__main__':
    main()
