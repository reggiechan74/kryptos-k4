"""Validate manually reviewed, score-free authentic stress annotations.

The decision ledger records every inspected prefix window, including rejections.
This script neither imports a language model nor reads any target or score file.
"""
from array import array
from pathlib import Path
from bisect import bisect_left
import hashlib, json, re, sys
ROOT = Path(__file__).resolve().parent

def read(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def ascii_letter(x): return 65 <= x <= 90 or 97 <= x <= 122

def main():
    fixtures_path = ROOT/'fixtures/positive_test.json'
    fixtures = sorted(read(fixtures_path), key=lambda x: x['id'])
    sources = {x['document_id']: x for x in read(ROOT/'source/source_manifest.json')['documents']}
    decisions = read(ROOT/'stress_decisions.json')
    categories = {}
    review = {}
    for category in ('proper_name', 'historical_spelling'):
        ledger = decisions[category]
        chosen = []
        reviewed = []
        for fixture in fixtures:
            fid = fixture['id']
            if len(chosen) == 20: break
            if fid not in ledger: raise ValueError(f'Missing ordered review decision for {category}: {fid}')
            decision = ledger[fid]
            doc = sources[fixture['document_id']]
            raw = Path(doc['raw_path']).read_bytes()
            a = array('I'); a.frombytes((ROOT/doc['raw_offsets_path']).read_bytes())
            if sys.byteorder != 'little': a.byteswap()
            entry = dict(fixture_id=fid, document_id=fixture['document_id'],
                         normalized_window_offset=fixture['normalized_offset'],
                         normalized_window_end=fixture['normalized_end'],
                         raw_window_start=fixture['raw_start'], raw_window_end=fixture['raw_end'],
                         raw_window_excerpt=fixture['raw_excerpt'], decision=decision)
            reviewed.append(entry)
            if decision is None: continue
            token = decision['token'].encode('utf-8')
            # Match the first complete occurrence of the annotated literal token.
            matches = []
            position = fixture['raw_start']
            while True:
                index = raw.find(token, position, fixture['raw_end'])
                if index < 0: break
                stop = index + len(token)
                if (index == 0 or not ascii_letter(raw[index-1])) and (stop == len(raw) or not ascii_letter(raw[stop])):
                    matches.append((index,stop))
                position = index+1
            if not matches: raise ValueError(f'No complete literal token for {fid}: {decision}')
            start, end = matches[0]
            normalized_start = bisect_left(a, start)
            normalized_end = bisect_left(a, end)
            if not fixture['normalized_offset'] <= normalized_start < normalized_end <= fixture['normalized_end']:
                raise ValueError(f'Incomplete token in normalized window: {fid}')
            start_relative = normalized_start - fixture['normalized_offset']
            end_relative = normalized_end - fixture['normalized_offset']
            if category == 'historical_spelling':
                historical = re.sub('[^A-Z]', '', decision['token'].upper())
                modern = re.sub('[^A-Z]', '', decision['modern_form'].upper())
                if historical == modern: raise ValueError(f'Only a punctuation difference: {fid}')
            chosen.append(dict(entry, raw_token_start=start, raw_token_end=end,
                               normalized_token_start=normalized_start, normalized_token_end=normalized_end,
                               normalized_token_window_span=[start_relative, end_relative],
                               intersects_scored_fragment=any(start_relative < b and end_relative > aa for aa,b in [(21,34),(63,74)]),
                               selected_in_fixture_order=len(chosen)+1))
        review[category] = reviewed
        categories[category] = dict(count=len(chosen), coverage_adequate=len(chosen)==20,
                                    required_survivors=18, fixtures=chosen)
    result = dict(version='candidate-first-055-authentic-stress-v1',
                  positive_test_sha256=digest(fixtures_path), source_manifest_sha256=digest(ROOT/'source/source_manifest.json'),
                  annotation_policy_sha256=digest(ROOT/'STRESS_ANNOTATION_POLICY.md'),
                  annotation_decisions_sha256=digest(ROOT/'stress_decisions.json'),
                  selection='First qualifying distinct test windows in ascending fixture-ID order; raw text inspected without language scores.',
                  category_selection=categories,
                  proper_names=categories['proper_name']['fixtures'], historical_spellings=categories['historical_spelling']['fixtures'],
                  coverage_adequate=all(x['coverage_adequate'] for x in categories.values()),
                  overlap_fixture_ids=sorted(set(x['fixture_id'] for x in categories['proper_name']['fixtures']) & set(x['fixture_id'] for x in categories['historical_spelling']['fixtures'])),
                  caveat='Window-level subsets may contain an annotated name or spelling outside both scored fragments. Intersections are explicitly recorded; no broad robustness claim follows.',
                  scores_read=False, target_read=False)
    (ROOT/'stress_manifest.json').write_text(json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True)+'\n')
    (ROOT/'stress_review_ledger.json').write_text(json.dumps(review, indent=2, ensure_ascii=False, sort_keys=True)+'\n')
    print(json.dumps({k:{'count':v['count'],'intersects_scored_fragment':sum(x['intersects_scored_fragment'] for x in v['fixtures'])} for k,v in categories.items()}))

if __name__ == '__main__': main()
