"""Outer process budget accounting, including failed or resource-killed child runs."""
import argparse, json, math, os, resource, subprocess, sys, time
from pathlib import Path
from common import ROOT, load, save, utc

def main():
    parser=argparse.ArgumentParser();parser.add_argument('label');parser.add_argument('command',nargs=argparse.REMAINDER);a=parser.parse_args()
    directory=ROOT/'results/execution';directory.mkdir(exist_ok=True)
    output=directory/(a.label+'.json')
    if output.exists():raise RuntimeError('Cannot overwrite execution receipt')
    previous=sum(load(p)['cpu_seconds'] for p in directory.glob('*.json'))
    remaining=math.floor(3600-previous)
    if remaining<1:raise RuntimeError('Study CPU budget exhausted before new process')
    before=resource.getrusage(resource.RUSAGE_CHILDREN);started=utc();wall=time.monotonic()
    def limits():
        resource.setrlimit(resource.RLIMIT_CPU,(remaining,remaining))
        resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3))
    process=subprocess.run(a.command,cwd=ROOT,preexec_fn=limits)
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu=(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime)
    result=dict(label=a.label,command=a.command,started_utc=started,ended_utc=utc(),wall_seconds=time.monotonic()-wall,
                cpu_seconds=cpu,cumulative_scoring_verification_cpu_seconds=previous+cpu,
                peak_rss_bytes=after.ru_maxrss*1024,returncode=process.returncode,
                imposed_remaining_cpu_limit_seconds=remaining,ram_limit_bytes=8*1024**3,
                within_budget=previous+cpu<=3600 and after.ru_maxrss*1024<=8*1024**3)
    save(output,result);print(json.dumps(result));raise SystemExit(process.returncode)
if __name__=='__main__':main()
