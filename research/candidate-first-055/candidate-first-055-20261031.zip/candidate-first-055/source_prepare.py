"""Prepare candidate 055 source roles, unchanged 054 normalization and boundaries.

No scorer, target ciphertext, or target-dependent operation is present. The
input universe is exactly the already pinned 053/054 public-source assets.
"""
from pathlib import Path
from array import array
from bisect import bisect_left
from collections import Counter, defaultdict
import hashlib, json, re, resource, sys, time
ROOT=Path(__file__).resolve().parent
OLD=Path('/workspace/shared/candidate-first-054')
OLD53=Path('/workspace/shared/candidate-first-053')

def sha(b): return hashlib.sha256(b).hexdigest()
def write_json(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
def normalized(raw,a,b):
    letters=bytearray(); offsets=array('I')
    for i in range(a,b):
        v=raw[i]
        if 65<=v<=90 or 97<=v<=122:
            letters.append(v-32 if v>=97 else v);offsets.append(i)
    return bytes(letters),offsets

def stable_u32(a):
    a=array('I',a)
    if a.itemsize!=4: raise ValueError('uint32 array required')
    if sys.byteorder!='little':a.byteswap()
    return a.tobytes()

PG={
35:('H. G. Wells','fiction','development'),36:('H. G. Wells','fiction','development'),
43:('Robert Louis Stevenson','fiction','development'),120:('Robert Louis Stevenson','fiction','development'),
74:('Mark Twain','fiction','development'),76:('Mark Twain','fiction','development'),
84:('Mary Shelley','fiction','test'),98:('Charles Dickens','fiction','test'),1400:('Charles Dickens','fiction','test'),
174:('Oscar Wilde','fiction','test'),203:('Harriet Beecher Stowe','fiction','test'),219:('Joseph Conrad','fiction','test'),
345:('Bram Stoker','fiction','test'),768:('Emily Bronte','fiction','test'),1260:('Charlotte Bronte','fiction','test'),1661:('Arthur Conan Doyle','fiction','test'),
205:('Henry David Thoreau','nonfiction','test'),1080:('Jonathan Swift','nonfiction','development'),
1232:('Niccolo Machiavelli / W. K. Marriott translation tradition','nonfiction','test')}
ARCHAIC_DEV={'King James Bible translation tradition','John Milton'}
ARCHAIC_TEST={'William Blake','William Shakespeare','Walt Whitman'}
TRAINING_GROUPS={'Jane Austen','G K Chesterton','Maria Edgeworth','Herman Melville'}

def role_for(d,plan):
    did=d['document_id']
    if did.startswith('pg/'):
        n=int(did.split('/')[1])
        if n==1342:return None
        return PG[n]
    p=plan[did.removeprefix('nltk/')];g=p['attribution_group']
    if g in TRAINING_GROUPS:return g,'training','training'
    if '/inaugural/' in did:return g,'nonfiction',{'calibration':'development','published_prose_control':'test'}[p['role']]
    if g in ARCHAIC_DEV:return g,'archaic','development'
    if g in ARCHAIC_TEST:return g,'archaic','test'
    if g=='Sarah Cone Bryant':g='Sarah Cone Bryant compilation tradition'
    return g,'fiction','development'


def get_boundaries(d,raw,offsets):
    """Freeze source-only boundary rules, never sampling/scoring-dependent."""
    a,b=d['body_start'],d['body_end'];did=d['document_id'];evidence={}
    def add(at,label,rule):
        if a<=at<b:
            evidence[at]={'raw_offset':at,'normalized_offset':bisect_left(offsets,at),'heading':label,'rule':rule}
    lines=list(re.finditer(rb'(?m)^[^\r\n]*\r?$',raw))
    if did.endswith(('blake-poems.txt','bryant-stories.txt')):
        for m in lines:
            s=m.group().strip()
            if len(s)>2 and s.upper()==s and re.search(rb'[A-Z]{2}',s):
                add(m.start(),s.decode('ascii','replace'),'Every all-uppercase heading-like line; conservative extra subdivisions retained')
        if did.endswith('blake-poems.txt'):
            # Case-sensitive all-uppercase detection missed mixed-case Thel
            # title/front-matter lines. These exact pinned source markers are
            # independent of window scores and define real internal work joins.
            markers={b"and THE BOOK of THEL",b"William Blake's",b"THE BOOK of THEL",b"THEL'S Motto",b"The Author & Printer Willm. Blake. 1780",b"I"}
            for m in lines:
                s=m.group().strip()
                if s in markers or s.startswith(b'NOTE:  Though written and engraved by Blake'):
                    add(m.start(),s.decode('ascii'),'Explicit mixed-case Blake work/title/editorial marker, corrected before scoring')
            if not any(x['raw_offset']==30535 for x in evidence.values()):
                raise ValueError('Songs/Book of Thel join is unprotected')
        if did.endswith('bryant-stories.txt'):
            # Two distinct riddles share one heading; the poem My Kingdom follows
            # Bryant's prose introduction. Both joins are known from raw text.
            for marker,label in ((b'     From house to house he goes,','Second of Two Little Riddles in Rhyme'),(b'     A little kingdom I possess,','Start of Louisa Alcott poem following prose introduction')):
                at=raw.find(marker)
                if at<0 or raw.find(marker,at+1)>=0:raise ValueError('Expected unique Bryant internal-work marker')
                add(at,label,'Manually identified distinct piece within a titled Bryant section')
    elif did.endswith('whitman-leaves.txt'):
        for m in lines:
            s=m.group().strip()
            if s.startswith(b'}') or s.startswith(b'[BOOK'):
                add(m.start(),s.decode('ascii','replace'),'Explicit Whitman poem marker or book heading')
    elif did.endswith('bible-kjv.txt'):
        short_names={b'Ezra',b'Ecclesiastes',b'Hosea',b'Joel',b'Amos',b'Obadiah',b'Jonah',b'Micah',b'Nahum',b'Habakkuk',b'Zephaniah',b'Haggai',b'Zechariah',b'Malachi'}
        prefixes=(b'The Old Testament',b'The New Testament',b'The First Book',b'The Second Book',b'The Third Book',b'The Fourth Book',b'The Fifth Book',b'The Book of',b'The Proverbs',b'The Preacher',b'The Song of Solomon',b'The Lamentations',b'The Gospel',b'The Acts',b'The Epistle',b'The First Epistle',b'The Second Epistle',b'The Third Epistle',b'The First General Epistle',b'The Second General Epistle',b'The General Epistle',b'The Revelation')
        for m in lines:
            s=m.group().strip()
            if s in short_names or s.startswith(prefixes):
                add(m.start(),s.decode('ascii'),'KJV book/testament heading (including supplied aliases)')
        firsts=list(re.finditer(rb'(?m)^1:1 ',raw[a:b]))
        if len(firsts)!=66:raise ValueError('Expected 66 KJV first verses')
        verse_starts=list(re.finditer(rb'\b\d+:\d+\b',raw[a:b]))
        for m in firsts:
            pos=a+m.start();previous=max((a+v.start() for v in verse_starts if v.start()<m.start()),default=a)
            if not any(previous<=x<pos for x in evidence):raise ValueError('Unprotected KJV book boundary')
    elif did.endswith('milton-paradise.txt'):
        for m in lines:
            s=m.group().strip()
            if re.fullmatch(rb'Book [IVX]+',s):add(m.start(),s.decode(),'Milton book heading, conservative subdivision of one work')
    elif did=='pg/01661':
        for m in lines:
            s=m.group().strip()
            if re.match(rb'^[IVX]+\. [A-Z]',s) and s.upper()==s:
                add(m.start(),s.decode('utf8'),'Doyle numbered story heading')
        if len(evidence)!=12:raise ValueError('Expected 12 Doyle story headings')
    elif did=='pg/00205':
        for x in d['uncertified_compilation_boundaries']:add(x['raw_offset'],x['description'],'Existing 054 declared work boundary')
    elif did=='pg/01232':
        for m in lines:
            s=m.group().strip()
            if m.group().startswith(b' '):continue # exclude indented contents entries
            if s in (b'INTRODUCTION',b'DEDICATION',b'THE PRINCE',b'THE LIFE OF CASTRUCCIO CASTRACANI OF LUCCA') or s.startswith(b'DESCRIPTION OF THE METHODS ADOPTED BY THE DUKE VALENTINO'):
                add(m.start(),s.decode(),'Machiavelli/Marriott introduction, dedication, main work and supplemental works')
    for x in d.get('uncertified_compilation_boundaries',[]):
        add(x['raw_offset'],x['description'],'Pinned 054 declared compilation boundary')
    points=sorted({0,len(offsets)}|{x['normalized_offset'] for x in evidence.values()})
    return [[a,b] for a,b in zip(points,points[1:]) if b>a],sorted(evidence.values(),key=lambda x:x['raw_offset'])


def main():
    cpu0=time.process_time();wall0=time.monotonic()
    source=ROOT/'source';(source/'normalized').mkdir(exist_ok=True);(source/'offsets').mkdir(exist_ok=True)
    old=json.loads((OLD/'corpus_manifest.json').read_text());plan=json.loads((OLD53/'CONTROL_SOURCE_PLAN.json').read_text());plan={x['document_id']:x for x in plan['documents']}
    docs=[];excluded=[];verification=[]
    for d in old['accepted_documents']:
        rawpath=OLD/d['raw_path'];raw=rawpath.read_bytes();norm,offs=normalized(raw,d['body_start'],d['body_end']);ob=stable_u32(offs)
        observed={'raw_sha256':sha(raw),'raw_bytes':len(raw),'body_sha256':sha(raw[d['body_start']:d['body_end']]),'normalized_sha256':sha(norm),'normalized_letters':len(norm),'offsets_uint32_le_sha256':sha(ob)}
        for k,v in observed.items():
            if d[k]!=v:raise ValueError(f"Pinned 054 mismatch {d['document_id']} {k}")
        verification.append({'document_id':d['document_id'],'checks':list(observed),'all_passed':True})
        role=role_for(d,plan)
        if role is None:
            excluded.append({'document_id':d['document_id'],'reason':'All works by Jane Austen excluded from evaluation because author is in 053 model training; this PG work is not one of the eight actual training documents.','raw_sha256':d['raw_sha256']});continue
        group,stratum,role=role
        safe=d['document_id'].replace('/','__')
        np=f'source/normalized/{safe}.az';op=f'source/offsets/{safe}.u32'
        (ROOT/np).write_bytes(norm);(ROOT/op).write_bytes(ob)
        segments,evidence=get_boundaries(d,raw,offs)
        attribution='attributed author'
        notes=[];related=[]
        if '/inaugural/' in d['document_id']:
            attribution='speaker group, not verified writer or ghostwriter';notes.append('Conservative same-surname 053 group preserved; speaker-disjointness is not writer-disjointness.')
        if 'bryant-stories' in d['document_id']:
            attribution='compilation/retelling source; not sole authorship';related=['Louisa Alcott','Hans Christian Andersen','King James Bible translation tradition']
            notes.append('Pinned title credits Sara Cone Bryant. 053 attribution spelling Sarah Cone Bryant retained in group identity. Raw body explicitly mentions Louisa Alcott and adaptation of Hans Christian Andersen; biblical retellings and Psalm material share the development KJV source tradition. Original contributors are incompletely credited; no verified global writer independence is claimed.')
        if d['document_id']=='pg/01232':
            attribution='Machiavelli works / W. K. Marriott translation and editorial tradition';related=['W. K. Marriott','Niccolo Machiavelli','Edward Dacre','Petrarch']
            if b'Translator: W. K. Marriott' not in raw:raise ValueError('Translator evidence absent')
            notes.append('Pinned raw title explicitly identifies W. K. Marriott. Introduction speaks as translator. Main work, dedication and supplements stay in one test group; quoted Petrarch and Edward Dacre verse is within that aggregate source group. Exact PG historical edition is not certified.')
        if d['document_id']=='pg/01080':notes.append('A Modest Proposal is a satirical essay, classified as nonfiction/public-essay form, not as factual reporting.')
        rec={'document_id':d['document_id'],'group':group,'stratum':stratum,'role':role,'attribution_kind':attribution,'related_contributors_or_traditions':related,'notes':notes,'normalized_path':np,'raw_offsets_path':op,'raw_path':str(rawpath),'segments':segments,'boundary_evidence':evidence,'boundary_count':len(evidence),'eligible_97_starts':sum(max(0,b-a-96) for a,b in segments),'nonoverlap_97_capacity':sum((b-a)//97 for a,b in segments),'body_start':d['body_start'],'body_end':d['body_end'],**observed,'source_url':d['source_url'],'original_manifest_path':str(OLD/'corpus_manifest.json'),'original_manifest_document_id':d['document_id'],'historical_transcription_uncertainty':d['historical_transcription_uncertainty']}
        if role=='training':
            p=plan[d['document_id'].removeprefix('nltk/')];rec['training_letters_used']=p['training_letters_used'];rec['actual_training_prefix_sha256']=sha(norm[:p['training_letters_used']])
            if len(norm)!=p['normalized_letters'] or sha(norm)!=p['normalized_sha256']:raise ValueError('053 and 054 training normalization mismatch')
        docs.append(rec)
    # Fixed priority resolves exact full normalized duplicates before later window sampling.
    priorities={'training':0,'development':1,'test':2};seen={};retained=[];removed=[]
    for d in sorted(docs,key=lambda x:(priorities[x['role']],x['document_id'])):
        if d['normalized_sha256'] in seen:
            removed.append({'document_id':d['document_id'],'role':d['role'],'retained_document_id':seen[d['normalized_sha256']]['document_id'],'reason':'Exact normalized full-document duplicate; fixed training > development > test then document-ID priority'})
        else:seen[d['normalized_sha256']]=d;retained.append(d)
    docs=sorted(retained,key=lambda x:x['document_id'])
    groups=defaultdict(set)
    for d in docs:groups[d['group']].add(d['role'])
    cross={g:sorted(rs) for g,rs in groups.items() if len(rs)>1}
    if cross:raise ValueError('Cross-role group overlap')
    counts={}
    for role in ('training','development','test'):
        counts[role]={}
        for stratum in ('training','fiction','nonfiction','archaic'):
            rows=[d for d in docs if d['role']==role and d['stratum']==stratum]
            if rows:counts[role][stratum]={'documents':len(rows),'groups':len({d['group'] for d in rows}),'normalized_letters':sum(d['normalized_letters'] for d in rows),'nonoverlap_capacity':sum(d['nonoverlap_97_capacity'] for d in rows)}
    notes=['References are out of training author/source groups for the unchanged 053 scorer, not sources never previously examined by this project.',
        'Normalization preserves exactly the existing 054 ASCII-letter bodies and original raw-byte offsets. No cross-document join is made.',
        'Source group labels denote attributed authors, conservative speakers, translators or compilation traditions. No universal writer/ghostwriter independence is asserted.',
        'Known compilation headings are hard sampling boundaries. Extra conservative subdivisions do not remove/rewrite normalized letters.',
        'Frozen role priority is training > development > test, then document ID; exact duplicate windows are audited by the separate sampler before scoring.',
        'All works by the four training authors are excluded from development/test, including PG Pride and Prejudice.',
        'Historical spelling stress means authentic spellings present in pinned transcriptions, not proof of exact pre-1990 edition wording. Authentic compressed-writing coverage is absent.',
        'No language scores or target fragments are computed by source preparation.']
    manifest={'version':'candidate-first-055-source-v1','documents':docs,'excluded_documents':excluded,'duplicate_document_removals':removed,'counts':counts,'source_plan_sha256':sha((OLD53/'CONTROL_SOURCE_PLAN.json').read_bytes()),'corpus_manifest_sha256':sha((OLD/'corpus_manifest.json').read_bytes()),'normalization':'ASCII A-Z and a-z bytes only; lowercase mapped to uppercase; body spans copied unchanged from 054','raw_offsets_format':'uint32 little-endian; zero-based absolute raw-byte offsets, one per normalized letter','segments_format':'[inclusive normalized start, exclusive normalized end]; all 97-letter windows must fit in one segment','notes':notes}
    write_json(source/'source_manifest.json',manifest)
    write_json(source/'source_verification.json',{'pinned_documents_verified':len(verification),'verification':verification,'all_passed':True,'cpu_seconds':time.process_time()-cpu0,'wall_seconds':time.monotonic()-wall0,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    write_json(source/'document_leakage_audit.json',{'full_document_duplicates_removed':removed,'cross_role_group_overlap':cross,'training_author_exclusions':sorted(TRAINING_GROUPS),'role_priority':['training','development','test'],'sampled_window_audit':'Not performed here; required before scoring by sampler.','compiler_attribution_audit':{'source':'nltk/gutenberg/bryant-stories.txt','explicit_mentions':['Louisa Alcott','Hans Christian Andersen'],'training_or_test_author_name_matches':[],'same_role_related_tradition':'King James Bible translation tradition','limitation':'Original retellings and embedded verse are incompletely credited; source-disjointness, not a claim of verified writer-disjointness.'},'translator_audit':{'source':'pg/01232','translator':'W. K. Marriott','evidence':'Raw header Translator: W. K. Marriott; grouped with Machiavelli and associated introduction/supplements in test only.','cross_role_conflict':False},'source_roles_frozen_before_scoring':True})
    print(json.dumps({'counts':counts,'documents':len(docs),'boundary_count':sum(x['boundary_count'] for x in docs),'duplicate_removals':len(removed),'manifest_sha256':sha((source/'source_manifest.json').read_bytes())},indent=2))

if __name__=='__main__':main()
