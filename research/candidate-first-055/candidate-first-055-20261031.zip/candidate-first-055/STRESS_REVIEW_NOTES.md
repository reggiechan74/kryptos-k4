# Authentic stress subset review

**Coverage: 20 proper-name windows and 20 historical-spelling windows. No scores or target inputs were read.**

Selections follow ascending test fixture ID under the recorded annotation policy. Every preceding window is retained in the review ledger, including rejected windows. The two subsets can overlap and do not add independent keys.

## Important limitations

- These are window-level stress subsets: the marked token intersects the scored positions in only 10/20 name windows and 5/20 historical-spelling windows. Passing these gates cannot establish robustness to difficult tokens inside every scored fragment.
- The names subset intentionally excludes generic religious titles and personified common nouns. The spelling subset excludes archaic vocabulary alone, ordinary regional variants and ambiguous apparent errors; it includes genuine poetic elisions in the original pinned text.
- Spelling forms are verified directly in the pinned raw bytes. This does not repair the source manifest’s caveat that precise historical transcription/edition identity is not verified for every work.
- Initial inspection of the first unscored fixture set identified an actual Blake compilation-boundary defect: former TA053 spanned the end of Songs of Experience and the opening of The Book of Thel. The source-preparation agent corrected the boundary rules, and the parent regenerated all fixtures before this final annotation. No earlier subset was locked, and no scores had run.

## Selected windows

### Proper names

| Fixture | Literal raw token | Modern form / referent rationale | In scored fragment? |
|---|---|---|---|
| TA011 | `Roanoke` | Named river/valley in the geographical enumeration; followed by Delaware and the Adirondacks. | Yes |
| TA027 | `Europe` | The named continent, explicitly paired with Asia and Africa. | Yes |
| TA031 | `Rome` | Named city/state in the phrase about Rome’s wars; not a capitalized common noun. | Yes |
| TA057 | `Thel` | The explicitly named central character of Blake’s The Book of Thel. | No |
| TA067 | `Romans` | Proper collective name of the Roman people addressed in Julius Caesar. | Yes |
| TA070 | `Decius` | Named character Decius Brutus, introduced by the stage direction and then named in full. | No |
| TA071 | `Decius` | Named character Decius, addressed in the dialogue of Julius Caesar. | Yes |
| TA072 | `Cassius` | Named character Cassius, explicitly instructed to go into the other street. | Yes |
| TA074 | `Antony` | Named character Antony, addressed by the crowd. | No |
| TA075 | `Antony` | Named character Antony, addressed as noble Antony. | No |
| TA076 | `Cassius` | Named character Cassius in the invitation to enlarge his grievances in the speaker’s tent. | No |
| TA077 | `Brutus` | Named character Brutus in the stage direction introducing Brutus and Messala. | No |
| TA078 | `Denmarke` | The historical spelling of the place name Denmark, here used metonymically of the buried Danish king. | Yes |
| TA079 | `Guildensterne` | Named character Guildenstern in the edition’s historical spelling; fully present after a clipped preceding name. | Yes |
| TA080 | `Fortinbras` | Named character Fortinbras, recipient of the arrests/order in the dialogue. | No |
| TA086 | `Horatio` | Named character Horatio in the stage direction. | No |
| TA088 | `Alexander` | Alexander the Great, explicitly considered in the burial-to-dust passage of Hamlet. | No |
| TA089 | `Roman` | Proper name for a member of the Roman people, used as a noun in “an Antike Roman”, not merely an adjective. | Yes |
| TA093 | `Heccats` | Historical possessive form of Hecate’s name in the witchcraft passage of Macbeth; not a generic supernatural title. | No |
| TA094 | `England` | Named country in the speaker’s stated destination, followed by Ireland. | Yes |

### Historical spellings

| Fixture | Literal raw token | Modern form / referent rationale | In scored fragment? |
|---|---|---|---|
| TA007 | `accomplish'd` | accomplished | No |
| TA018 | `clutch'd` | clutched | No |
| TA020 | `fill'd` | filled | No |
| TA022 | `look'd` | looked | Yes |
| TA024 | `chain'd` | chained | No |
| TA027 | `join'd` | joined | No |
| TA030 | `measur'd` | measured | No |
| TA043 | `where'er` | wherever | Yes |
| TA056 | `thro` | through | No |
| TA058 | `reclind` | reclined | No |
| TA059 | `rais'd` | raised | No |
| TA061 | `wip'd` | wiped | No |
| TA062 | `complaind` | complained | No |
| TA064 | `listning` | listening | No |
| TA065 | `showring` | showering | Yes |
| TA067 | `heare` | hear | Yes |
| TA068 | `wonderfull` | wonderful | Yes |
| TA069 | `Haue` | Have | No |
| TA070 | `Heere's` | Here's | No |
| TA071 | `sicke` | sick | No |

