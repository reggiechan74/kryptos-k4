#!/usr/bin/env python3
"""Candidate 055 independent verifier. No target ciphertext or target path exists here.

This implementation does not import core arithmetic or scoring helpers to implement
its reference computations. Core is imported only by run() for comparison.
The inverse lookup is constructed by exhaustive forward enumeration rather than
using the main inverse formula. Scoring reconstructs each n-gram separately from
literal letters and sums its table entries, not a rolling-context helper.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import resource
import struct
import sys
import time
import traceback

AZ = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
KR = 'KRYPTOSABCDEFGHIJLMNQUVWXZ'
AXES = {'AZ': AZ, 'KR': KR}
OPS = ('vigenere', 'beaufort', 'variant_beaufort')
TABLEAUX = tuple(itertools.product(('AZ', 'KR'), ('AZ', 'KR'), OPS))
CRIB_PLAINTEXT = 'EASTNORTHEASTBERLINCLOCK'
MODEL_SHA256 = 'cf21822e9078c9a9d810cbd5ea57db4f4fd440db793c7f5dd4c3cecf49f1212b'
PROTOCOL_SHA256 = '793e4aea979227eb6b1bc12f2a490712b2db8f26c276c01c69878c1773a71f0d'
COUNT_HASHES = {1: '39ed6966a5975e538753166b08cf88ba95af36f412ee95f1dc49a05217523f0c',
                2: '5a54cf8464a88d201e8442946cc02106cfe4550bd31ecc71917f99e280dfce5e',
                3: '628e5c3321676fdebd26726302dcea0f66dec6c7d9b1e34117b66ecf3ba7db55',
                4: 'd5a020682262b1a223149939549abddb39690cf898f52c7bda56e0c0a54c7b97'}
GRAM_OFFSETS = (0, 26, 26 + 26**2, 26 + 26**2 + 26**3)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def forward_residue(p, k, op):
    if op == 'vigenere':
        result = p + k
    elif op == 'beaufort':
        result = k - p
    elif op == 'variant_beaufort':
        result = p - k
    else:
        raise ValueError('Unrecognized operation')
    return result % 26


def independent_encrypt(plaintext, key, tableau):
    pa, ca, op = tableau
    if len(plaintext) != len(key):
        raise ValueError('Plaintext and key lengths differ')
    pi = {letter: value for value, letter in enumerate(AXES[pa])}
    return ''.join(AXES[ca][forward_residue(pi[p], pi[k], op)] for p, k in zip(plaintext, key))


def inverse_lookup(tableau):
    pa, ca, op = tableau
    table = {}
    for p in range(26):
        for k in range(26):
            c = forward_residue(p, k, op)
            pair = (AXES[pa][p], AXES[ca][c])
            assert pair not in table, 'Forward operation is not invertible'
            table[pair] = AXES[pa][k]
    return table


def independent_derive(plaintext, ciphertext, tableau):
    if len(plaintext) != len(ciphertext):
        raise ValueError('Plaintext and ciphertext lengths differ')
    inv = inverse_lookup(tableau)
    return ''.join(inv[p, c] for p, c in zip(plaintext, ciphertext))


def independent_pair(cipher24, tableau):
    if len(cipher24) != 24 or any(c not in AZ for c in cipher24):
        raise ValueError('Expected 24 literal A-Z ciphertext letters')
    key = independent_derive(CRIB_PLAINTEXT, cipher24, tableau)
    return key[:13], key[13:]


class IndependentScorer:
    def __init__(self, path):
        raw = Path(path).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == MODEL_SHA256, 'Wrong frozen 053 model hash'
        count = sum(26**n for n in range(1, 5))
        assert len(raw) == count * 8, 'Wrong model byte count'
        self.values = struct.unpack('<' + 'd' * count, raw)
        assert all(math.isfinite(x) and x <= 0 for x in self.values)

    def fragment(self, text):
        if not text or any(c not in AZ for c in text):
            raise ValueError('Expected nonempty literal A-Z fragment')
        summands = []
        for endpoint in range(1, len(text) + 1):
            gram = text[max(0, endpoint - 4):endpoint]
            gram_id = sum((ord(c) - 65) * 26**power for power, c in enumerate(reversed(gram)))
            summands.append(self.values[GRAM_OFFSETS[len(gram) - 1] + gram_id])
        return math.fsum(summands)

    def score(self, pair):
        if len(pair) != 2 or len(pair[0]) != 13 or len(pair[1]) != 11:
            raise ValueError('Expected two blocks of lengths 13 and 11')
        return (self.fragment(pair[0]) + self.fragment(pair[1])) / 24

    def normalization(self):
        errors = []
        row_count = 0
        for n, offset in enumerate(GRAM_OFFSETS, 1):
            for start in range(offset, offset + 26**n, 26):
                errors.append(abs(math.fsum(2**v for v in self.values[start:start + 26]) - 1))
                row_count += 1
        return {'row_count': row_count, 'maximum_absolute_row_error': max(errors)}

    def compare_reconstructed_probabilities(self, model_dir):
        """Independently reconstruct fixed smoothing from saved integer counts."""
        count_rows = []
        for n in range(1, 5):
            raw = (Path(model_dir) / ('counts%d.bin' % n)).read_bytes()
            assert len(raw) == 26**n * 8
            assert hashlib.sha256(raw).hexdigest() == COUNT_HASHES[n], 'Count-table hash mismatch'
            count_rows.append(struct.unpack('<' + 'Q' * 26**n, raw))
        total = sum(count_rows[0])
        previous = [(v + .5) / (total + 13) for v in count_rows[0]]
        largest = max(abs(math.log2(p) - q) for p, q in zip(previous, self.values[:26]))
        for n, smoothing in ((2, 5), (3, 10), (4, 20)):
            current = []
            counts = count_rows[n - 1]
            for history in range(26**(n - 1)):
                row = counts[history * 26:(history + 1) * 26]
                denominator = sum(row) + smoothing
                suffix = history % 26**(n - 2)
                current.extend((v + smoothing * previous[suffix * 26 + symbol]) / denominator
                               for symbol, v in enumerate(row))
            offset = GRAM_OFFSETS[n - 1]
            largest = max(largest, max(abs(math.log2(p) - self.values[offset + i])
                                       for i, p in enumerate(current)))
            previous = current
        return {'entries_checked': len(self.values), 'maximum_log2_difference': largest,
                'smoothing': [.5, 5, 10, 20]}


def synthetic_test_keys():
    """Fixed non-corpus testing data; never positive calibration references."""
    keys = [
        (AZ * 4)[:97],
        (KR * 4)[:97],
        ('THEQUICKBROWNFOXJUMPSOVERTHELAZYDOG' * 3)[:97],
        'A' * 97,
        'Z' * 97,
        ('XQZ' * 33)[:97],
    ]
    for i in range(32):
        digest = hashlib.shake_256(('candidate-first-055-verifier-fixture-' + str(i)).encode()).digest(97)
        keys.append(''.join(AZ[b % 26] for b in digest))
    assert all(len(k) == 97 for k in keys)
    return keys


def expect_rejection(fn, *args):
    try:
        fn(*args)
    except (ValueError, TypeError, KeyError, IndexError):
        return
    raise AssertionError('Malformed input was accepted: ' + repr(args))


def import_core(path):
    spec = importlib.util.spec_from_file_location('core055_for_independent_comparison', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def run(core_path, model_path):
    core = import_core(core_path)
    assert tuple(core.TABLEAUX) == TABLEAUX, 'Tableau enumeration mismatch'
    scorer = IndependentScorer(model_path)
    primary = core.Model(model_path)
    receipt = {'status': 'RUNNING', 'core_sha256': sha256(core_path),
               'verifier_sha256': sha256(__file__), 'model_sha256': sha256(model_path),
               'target_loaded': False, 'target_scored': False,
               'independence': 'Separate lookup inverse and per-position n-gram construction; no implementation calls to core arithmetic or scorer.'}
    exhaustive_count = 0
    for tableau in TABLEAUX:
        pa, ca, op = tableau
        inverse = inverse_lookup(tableau)
        for p in range(26):
            for k in range(26):
                plain, key = AXES[pa][p], AXES[pa][k]
                cipher = independent_encrypt(plain, key, tableau)
                assert core.encrypt_text(plain, key, tableau) == cipher
                assert inverse[plain, cipher] == key
                assert core.derive_text(plain, cipher, tableau) == key
                exhaustive_count += 1
    receipt['exhaustive_plain_key_tableau_checks'] = exhaustive_count
    maximum_difference = 0.
    pair_recoveries = 0
    reset_differences = []
    fixture_records = []
    for fixture_number, key in enumerate(synthetic_test_keys(), 1):
        pair = (key[21:34], key[63:74])
        expected = scorer.score(pair)
        actual = primary.score(pair)
        for block in pair:
            assert abs(primary.fragment_log(block) - scorer.fragment(block)) <= 1e-9
        difference = abs(expected - actual)
        assert difference <= 1e-10, (fixture_number, expected, actual)
        maximum_difference = max(maximum_difference, difference)
        # Context resets are genuine: a concatenated score is not used.
        reset_differences.append(abs(expected - scorer.fragment(''.join(pair)) / 24))
        for tableau in TABLEAUX:
            cipher = independent_encrypt(CRIB_PLAINTEXT, ''.join(pair), tableau)
            assert core.encrypt_pair(key, tableau) == cipher
            assert tuple(core.derive_pair(cipher, tableau)) == pair
            assert independent_pair(cipher, tableau) == pair
            # Changing every unobserved letter cannot change ciphertext or score.
            altered = list(key)
            for i in range(97):
                if not (21 <= i < 34 or 63 <= i < 74):
                    altered[i] = AZ[(AZ.index(key[i]) + 7) % 26]
            assert core.encrypt_pair(''.join(altered), tableau) == cipher
            pair_recoveries += 1
        fixture_records.append({'fixture_id': 'IV%03d' % fixture_number,
                                'key_sha256': hashlib.sha256(key.encode()).hexdigest(),
                                'pair': pair, 'independent_score': expected,
                                'primary_score': actual, 'absolute_difference': difference})
    assert max(reset_differences) > 1e-6, 'Reset-specific fixtures were ineffective'
    receipt['synthetic_key_fixture_count'] = len(fixture_records)
    receipt['generated_pair_recovery_checks'] = pair_recoveries
    receipt['maximum_score_difference_bits_per_letter'] = maximum_difference
    receipt['largest_concat_vs_reset_difference'] = max(reset_differences)
    receipt['score_fixtures'] = fixture_records
    # Boundary score reference is independently computed on arbitrary substring starts,
    # including starts inside words and highly non-English fixtures.
    receipt['arbitrary_substring_boundary_tests'] = 'Synthetic keys include normalized pangram slices starting inside words; positions 21:34 and 63:74 checked literally.'
    rejection_count = 0
    t = TABLEAUX[0]
    for key in ('', 'A' * 96, 'A' * 98, 'a' * 97, 'A' * 96 + ' ', 'A' * 96 + 'É'):
        expect_rejection(core.encrypt_pair, key, t); rejection_count += 1
    for cipher in ('', 'A' * 23, 'A' * 25, 'a' * 24, 'A' * 23 + ' ', 'A' * 23 + 'É'):
        expect_rejection(core.derive_pair, cipher, t); rejection_count += 1
    for pair in (('', ''), ('A' * 12, 'A' * 11), ('A' * 13, 'A' * 12),
                 ('a' * 13, 'A' * 11), ('A' * 13, 'A' * 10 + ' '),
                 ('A' * 13, 'A' * 10 + 'É'), ('A' * 13,), ('A' * 13, 'A' * 11, 'A')):
        expect_rejection(primary.score, pair); rejection_count += 1
    for fn, plain, other in ((core.encrypt_text, 'A', 'AA'), (core.derive_text, 'AA', 'A'),
                             (core.encrypt_text, 'a', 'A'), (core.derive_text, 'A', 'a'),
                             (core.encrypt_text, '', ''), (core.derive_text, '', '')):
        expect_rejection(fn, plain, other, t); rejection_count += 1
    receipt['malformed_input_rejection_checks'] = rejection_count
    receipt['probability_normalization'] = scorer.normalization()
    assert receipt['probability_normalization']['maximum_absolute_row_error'] <= 1e-12
    receipt['count_table_reconstruction'] = scorer.compare_reconstructed_probabilities(Path(model_path).parent)
    assert receipt['count_table_reconstruction']['maximum_log2_difference'] <= 1e-12
    receipt['status'] = 'PASS'
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--core', type=Path, default=Path(__file__).with_name('core.py'))
    parser.add_argument('--model', type=Path, default=Path('/workspace/shared/candidate-first-053/model/log_tables.bin'))
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('independent_verification.json'))
    parser.add_argument('--freeze', type=Path, required=True,
                        help='An existing frozen-input receipt is required before any model scores are computed.')
    parser.add_argument('--cpu-limit-seconds', type=int, default=3600)
    args = parser.parse_args()
    if not args.freeze.is_file():
        raise SystemExit('Scoring prohibited: the supplied freeze receipt does not exist.')
    if args.output.exists():
        raise SystemExit('Refusing to overwrite a retained verification receipt.')
    outer_hard = resource.getrlimit(resource.RLIMIT_CPU)[1]
    effective_limit = args.cpu_limit_seconds if outer_hard == resource.RLIM_INFINITY else min(args.cpu_limit_seconds, outer_hard)
    resource.setrlimit(resource.RLIMIT_CPU, (effective_limit, effective_limit))
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
    start_wall = time.monotonic()
    start_usage = resource.getrusage(resource.RUSAGE_SELF)
    receipt = {'status': 'FAILED', 'target_loaded': False, 'target_scored': False}
    code = 1
    try:
        frozen = json.loads(args.freeze.read_text())
        root = args.freeze.parent
        changed = [name for name, digest in frozen['files'].items() if sha256(root / name) != digest]
        assert not changed, 'Frozen input hashes changed: ' + repr(changed)
        assert sha256(root / 'PROTOCOL.md') == PROTOCOL_SHA256, 'Wrong final reviewed protocol'
        assert sha256(args.model) == MODEL_SHA256, 'Wrong fixed 053 model'
        assert args.core.resolve() == (root / 'core.py').resolve(), 'Unexpected core outside frozen input root'
        assert frozen['files']['core.py'] == sha256(args.core)
        assert frozen['files']['independent_verify.py'] == sha256(__file__)
        receipt = run(args.core, args.model)
        receipt['frozen_file_hashes_checked'] = len(frozen['files'])
        receipt['protocol_sha256'] = PROTOCOL_SHA256
        code = 0
    except Exception as exc:
        receipt.update({'error_type': type(exc).__name__, 'error': str(exc), 'traceback': traceback.format_exc()})
    end_usage = resource.getrusage(resource.RUSAGE_SELF)
    receipt.update({'freeze_receipt': str(args.freeze), 'freeze_sha256': sha256(args.freeze),
                    'python_version': sys.version, 'started_at_utc_epoch': time.time() - (time.monotonic() - start_wall),
                    'wall_seconds': time.monotonic() - start_wall,
                    'cpu_seconds': end_usage.ru_utime + end_usage.ru_stime - start_usage.ru_utime - start_usage.ru_stime,
                    'peak_rss_bytes': end_usage.ru_maxrss * 1024,
                    'requested_cpu_limit_seconds': args.cpu_limit_seconds, 'effective_cpu_limit_seconds': effective_limit, 'address_space_limit_bytes': 8 * 1024**3,
                    'budget_note': 'Parent must aggregate this receipt with all other scoring and verification CPU usage.'})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: receipt[k] for k in ('status', 'cpu_seconds', 'peak_rss_bytes', 'target_scored')}, sort_keys=True))
    raise SystemExit(code)


if __name__ == '__main__':
    main()
