#!/usr/bin/env python3
"""Independent read-only study055 replay. Explicit input allowlist; no target loading.
Run only after the immutable input freeze and calibration result exist.
"""
from pathlib import Path
from collections import defaultdict, Counter
from array import array
import bisect, hashlib, itertools, json, math, random, re, resource, struct, sys, time
R=Path('/workspace/shared/candidate-first-055')
A=Path(__file__).resolve().parent
MODEL=Path('/workspace/shared/candidate-first-053/model/log_tables.bin')
EXPECTED_MODEL='cf21822e9078c9a9d810cbd5ea57db4f4fd440db793c7f5dd4c3cecf49f1212b'
EXPECTED_PROTOCOL='793e4aea979227eb6b1bc12f2a490712b2db8f26c276c01c69878c1773a71f0d'
ALPH=['ABCDEFGHIJKLMNOPQRSTUVWXYZ','KRYPTOSABCDEFGHIJLMNQUVWXZ']
LABELS=['AZ','KR']; OPS=['vigenere','beaufort','variant_beaufort']
CONVENTIONS=list(itertools.product(range(2),range(2),range(3)))
NAMES=['-'.join((LABELS[p],LABELS[c],OPS[o])) for p,c,o in CONVENTIONS]
CRIB='EASTNORTHEASTBERLINCLOCK'
def read(p): return json.loads(Path(p).read_text())
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def seeded(label): return random.Random(int(hashlib.sha256(('candidate-first-055-v1|'+label).encode()).hexdigest(),16))
def forward(plain,key,c):
 paxis,caxis,op=c
 return ''.join(ALPH[caxis][((ALPH[paxis].index(p)+ALPH[paxis].index(k)) if op==0 else (ALPH[paxis].index(k)-ALPH[paxis].index(p)) if op==1 else (ALPH[paxis].index(p)-ALPH[paxis].index(k)))%26] for p,k in zip(plain,key))
INVERSES=[]
for conv in CONVENTIONS:
 table={}
 for p,k in itertools.product(ALPH[0],repeat=2):
  cipher=forward(p,k,conv); assert (p,cipher) not in table;table[p,cipher]=k
 assert len(table)==676;INVERSES.append(table)
def derive(cipher,i):
 full=''.join(INVERSES[i][p,c] for p,c in zip(CRIB,cipher));return [full[:13],full[13:]]
def slices(key): return [key[21:34],key[63:74]]
def group_rates(rows,field):
 vals=defaultdict(list)
 for r in rows: vals[r['group']].append(bool(r[field]))
 return {g:sum(v)/len(v) for g,v in sorted(vals.items())}
def sensitivity(rates,label):
 values=list(rates.values());prng=seeded(label);n=len(values)
 boot=[sum(values[prng.randrange(n)] for j in range(n))/n for i in range(10000)]
 sorted_boot=sorted(boot)
 return dict(equal_group_rate=sum(values)/n,lower_2_5_percentile=sorted_boot[249],upper_95_percentile=sorted_boot[9499],bootstrap_mean_values=boot,
 leave_one_group_out={g:sum(v for h,v in rates.items() if h!=g)/(n-1) for g in rates})
def exact_upper(k,n):
 # Separate recurrence implementation of one-sided binomial CDF inversion.
 if k==n:return 1.
 def cdf(p):
  term=(1-p)**n;terms=[term]
  for j in range(1,k+1):
   term*=((n-j+1)/j)*(p/(1-p));terms.append(term)
  return math.fsum(terms)
 low,high=0.,1.
 for _ in range(80):
  mid=(low+high)/2
  if cdf(mid)>.05:low=mid
  else:high=mid
 return (low+high)/2

def main():
 start=time.process_time();wall=time.monotonic();resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 assert (R/'freeze.json').is_file() and (R/'results/calibration_gate.json').is_file(), 'Wait for final frozen calibration artifacts'
 freeze=read(R/'freeze.json');result=read(R/'results/calibration_gate.json');out={'status':'RUNNING','target_loaded':False,'target_scored':False}
 assert digest(R/'PROTOCOL.md')==EXPECTED_PROTOCOL
 changed=[p for p,h in freeze['files'].items() if digest(R/p)!=h];assert not changed,changed
 out['freeze']={'sha256':digest(R/'freeze.json'),'files_verified':len(freeze['files']),'all_match':True}
 assert digest(MODEL)==EXPECTED_MODEL
 raw=MODEL.read_bytes();flat=struct.unpack('<'+'d'*(len(raw)//8),raw);table_offsets=[0,26,26+676,26+676+17576]
 assert len(flat)==sum(26**n for n in range(1,5))
 def score(pair):
  terms=[]
  for block in pair:
   for e in range(1,len(block)+1):
    gram=block[max(0,e-4):e];idx=0
    for ch in gram:idx=26*idx+ord(ch)-65
    terms.append(flat[table_offsets[len(gram)-1]+idx])
  return math.fsum(terms)/24
 normerr=max(abs(math.fsum(2**v for v in flat[o+j:o+j+26])-1) for n,o in enumerate(table_offsets,1) for j in range(0,26**n,26))
 assert normerr<1e-12
 out['model']={'sha256':EXPECTED_MODEL,'rows_checked':sum(26**n for n in range(4)),'maximum_normalization_error':normerr,'context_reset':True,'literal_AZ_lookup':True}
 source=read(R/'source/source_manifest.json');docs={d['document_id']:d for d in source['documents']};norms={};offsets={};raws={};byrole=defaultdict(set)
 for did,d in docs.items():
  n=(R/d['normalized_path']).read_bytes();rb=Path(d['raw_path']).read_bytes();ob=(R/d['raw_offsets_path']).read_bytes()
  assert hashlib.sha256(n).hexdigest()==d['normalized_sha256']
  assert hashlib.sha256(rb).hexdigest()==d['raw_sha256']
  assert hashlib.sha256(ob).hexdigest()==d['offsets_uint32_le_sha256']
  assert re.sub(rb'[^A-Za-z]',b'',rb[d['body_start']:d['body_end']]).upper()==n
  off=array('I');off.frombytes(ob)
  if sys.byteorder!='little':off.byteswap()
  assert len(off)==len(n) and bytes(rb[i] for i in off).upper()==n
  norms[did]=n;offsets[did]=off;raws[did]=rb;byrole[d['role']].add(d['group'])
 assert not any(byrole[a]&byrole[b] for a,b in itertools.combinations(byrole,2))
 assert len(set(d['normalized_sha256'] for d in docs.values()))==len(docs)
 training=[norms[d] for d in docs if docs[d]['role']=='training']
 windows=[];positives={};scrambles={}
 for role in ['development','test']:
  positives[role]=read(R/f'fixtures/positive_{role}.json');scrambles[role]=read(R/f'fixtures/letter_scrambled_{role}.json')
  assert len(positives[role])==300 and Counter(f['stratum'] for f in positives[role])==Counter({'archaic':100,'fiction':100,'nonfiction':100})
  assert len(scrambles[role])==200
  windows.extend(positives[role]+scrambles[role])
 windows.extend(read(R/'fixtures/word_order_bases.json')+read(R/'fixtures/function_word_deletion_bases.json'))
 seen=set();used=defaultdict(list)
 for f in windows:
  did=f['document_id'];a,b=f['normalized_offset'],f['normalized_end'];key=f.get('base_key',f['key']);n=norms[did]
  assert b-a==97 and n[a:b].decode()==key and re.sub('[^A-Za-z]','',f['raw_excerpt']).upper()==key
  assert f['raw_start']==offsets[did][a] and f['raw_end']==offsets[did][b-1]+1
  assert docs[did]['role']==f['role'] and docs[did]['group']==f['group'] and docs[did]['stratum']==f['stratum']
  assert any(x<=a and b<=y for x,y in docs[did]['segments'])
  assert key not in seen and not any(key.encode() in t for t in training)
  assert not any(a<y and b>x for x,y in used[did]);seen.add(key);used[did].append((a,b))
 out['source_and_sampling']={'documents':len(docs),'distinct_base_windows':len(windows),'raw_normalization_verified':True,'training_and_cross_role_window_duplicates':0,'base_window_overlaps':0,'source_group_roles_disjoint':True,'groups_by_role':{r:len(g) for r,g in byrole.items()},'known_segment_crossings':0}
 for role in ['development','test']:
  for f in scrambles[role]:
   chars=list(f['base_key']);seeded('letter-permutation|'+f['id']).shuffle(chars);assert ''.join(chars)==f['key']
  cs=[i%12 for i in range(200)];seeded('scramble-convention|'+role).shuffle(cs);assert cs==[f['generating_tableau_index'] for f in scrambles[role]]
  u=read(R/f'fixtures/uniform_{role}.json');prng=seeded('uniform-ciphertext|'+role)
  assert len(u)==200
  assert [f['ciphertext'] for f in u]==[''.join(prng.choice(ALPH[0]) for _ in range(24)) for i in range(200)]
 out['controls']={'uniform_cases_each_role':200,'separate_seed_streams_replayed':True,'letter_permutations_replayed':400,'joint_tableau_derivation':True,'scramble_generating_conventions_balanced':True}
 maximum_delta=0.;case_count=0;score_count=0
 def verify_case(row,cipher):
  nonlocal maximum_delta,case_count,score_count
  assert row['ciphertext']==cipher and len(row['scores'])==12
  expected=[]
  for i,s in enumerate(row['scores']):
   pair=derive(cipher,i);val=score(pair);delta=abs(val-s['score']);assert delta<=1e-10
   assert s['tableau']==NAMES[i] and s['fragments']==pair
   expected.append(val);maximum_delta=max(maximum_delta,delta);score_count+=1
  assert abs(max(expected)-row['case_max'])<=1e-10;case_count+=1
  return expected
 threshold=read(R/'threshold.json');tau=threshold['tau'];assert threshold['freeze_sha256']==digest(R/'freeze.json')
 keyresults={}
 for role in ['development','test']:
  fixtures={f['id']:f for f in positives[role]};counts=Counter();generators=defaultdict(set)
  with (R/f'results/positive_cases_{role}.jsonl').open() as handle:
   for line in handle:
    row=json.loads(line);f=fixtures[row['fixture_id']];gen=NAMES.index(row['generating_tableau']);pair=slices(f['key']);cipher=forward(CRIB,''.join(pair),CONVENTIONS[gen]);vs=verify_case(row,cipher)
    assert derive(cipher,gen)==pair and abs(vs[gen]-row['true_score'])<=1e-10
    counts[f['id']]+=1;assert gen not in generators[f['id']];generators[f['id']].add(gen)
  assert set(counts)==set(fixtures) and set(counts.values())=={12}
  keyresults[role]=read(R/f'results/positive_keys_{role}.json')
  assert len(keyresults[role])==300
  for row in keyresults[role]:
   f=fixtures[row['id']];assert row['group']==f['group'] and row['stratum']==f['stratum'];assert abs(score(slices(f['key']))-row['true_score'])<=1e-10
   maxima=[max(score(derive(forward(CRIB,''.join(slices(f['key'])),conv),i)) for i in range(12)) for conv in CONVENTIONS]
   assert all(abs(a-b)<=1e-10 for a,b in zip(maxima,row['case_max_by_generating_tableau']))
   if role=='test': assert row['true_survived']==(row['true_score']>=tau)
 fifth={s:sorted(x['true_score'] for x in keyresults['development'] if x['stratum']==s)[4] for s in ['archaic','fiction','nonfiction']}
 assert threshold['stratum_fifth_smallest']==fifth and tau==min(fifth.values())
 refs={}
 for role in ['development','test']:
  for kind in ['uniform','letter_scrambled']:
   fixtures={f['id']:f for f in read(R/f'fixtures/{kind}_{role}.json')};rows=[]
   for line in (R/f'results/{kind}_{role}.jsonl').read_text().splitlines():
    row=json.loads(line);f=fixtures[row['id']];cipher=f['ciphertext'] if kind=='uniform' else forward(CRIB,''.join(slices(f['key'])),CONVENTIONS[f['generating_tableau_index']]);verify_case(row,cipher);assert row['survived']==(row['case_max']>=tau);rows.append(row)
   assert len(rows)==200 and {x['id'] for x in rows}==set(fixtures);refs[role,kind]=rows
 stressfixtures={f['id']:f for f in read(R/'fixtures/descriptive_stress.json')};descriptive=defaultdict(list)
 for line in (R/'results/descriptive_stress.jsonl').read_text().splitlines():
  row=json.loads(line);f=stressfixtures[row['id']];pair=f['fragments'] if 'fragments' in f else slices(f['key']);cipher=forward(CRIB,''.join(pair),CONVENTIONS[f['generating_tableau_index']]);verify_case(row,cipher)
  assert abs(row['true_score']-score(pair))<=1e-10 and row['true_survived']==(row['true_score']>=tau) and row['case_survived']==(row['case_max']>=tau);descriptive[row['kind']].append(row)
 assert sum(map(len,descriptive.values()))==len(stressfixtures)
 for kind,rows in descriptive.items():
  assert result['descriptive_stress'][kind]==dict(n=len(rows),true_survivors=sum(r['true_survived'] for r in rows),case_survivors=sum(r['case_survived'] for r in rows),mandatory_gate=False)
 out['arithmetic_replay']={'exhaustive_single_letter_forward_inversions':12*26*26,'all_case_rows':case_count,'all_tableau_scores':score_count,'maximum_score_discrepancy_bits_per_letter':maximum_delta,'true_key_results_each_role':300,'positive_cipher_cases_each_role':3600,'tau':tau,'fifth_smallest_by_stratum':fifth,'target_computed':False}
 gates={};test=keyresults['test']
 for stratum in ['archaic','fiction','nonfiction']:
  rows=[r for r in test if r['stratum']==stratum];rates=group_rates(rows,'true_survived');ss=sensitivity(rates,'bootstrap|positive|'+stratum);recorded=result['true_key_strata'][stratum]
  assert sum(r['true_survived'] for r in rows)==recorded['survivors']
  for k,v in ss.items():assert recorded['sensitivity'][k]==v,(stratum,k)
  counts=Counter(r['group'] for r in rows)
  gates['positive_stratum_'+stratum]=len(rows)==100 and recorded['survivors']>=90
  gates['positive_groups_'+stratum]=all(v>=.8 for g,v in rates.items() if counts[g]>=10)
  gates['positive_cluster_'+stratum]=ss['lower_2_5_percentile']>=.8
  for i,name in enumerate(NAMES):assert recorded['case_max_survivors_by_generating_tableau'][name]==sum(r['case_max_by_generating_tableau'][i]>=tau for r in rows)
 uniform=refs['test','uniform'];k=sum(r['survived'] for r in uniform);upper=exact_upper(k,200)
 assert result['uniform_reference']['survivors']==k and abs(result['uniform_reference']['one_sided_exact_binomial_upper_95']-upper)<1e-12
 gates['uniform_case_acceptance']=upper<=.15
 scr=refs['test','letter_scrambled'];ss=sensitivity(group_rates(scr,'survived'),'bootstrap|letter-scrambled|test')
 for key,val in ss.items():assert result['letter_scrambled_reference']['sensitivity'][key]==val,key
 gates['scrambled_equal_group_rate']=ss['equal_group_rate']<=.20;gates['scrambled_cluster_upper']=ss['upper_95_percentile']<=.30
 # The final stress manifest may retain compatibility aliases or category objects.
 manifest=read(R/'stress_manifest.json');annotation_checks=[]
 for field,category in [('proper_names','proper_name'),('historical_spellings','historical_spelling')]:
  items=manifest[field] if field in manifest else manifest['category_selection'][category]['fixtures'];ids=[r['fixture_id'] for r in items]
  byid={r['id']:r for r in test};n=sum(byid[x]['true_survived'] for x in ids)
  assert result['authentic_stress'][field]['n']==len(ids) and result['authentic_stress'][field]['survivors']==n
  gates[field]=len(ids)==20 and len(set(ids))==20 and n>=18
  for ann in items:
   did=ann['document_id'];a,b=ann['raw_token_start'],ann['raw_token_end'];assert raws[did][a:b].decode()==ann['decision']['token']
   assert ann['raw_window_start']<=a<b<=ann['raw_window_end']
   x,y=ann['normalized_token_window_span'];assert ann['intersects_scored_fragment']==any(x<end and y>start for start,end in [(21,34),(63,74)])
  annotation_checks.append({'category':field,'n':len(ids),'survivors':n,'scored_span_intersections':sum(i['intersects_scored_fragment'] for i in items)})
 gates['independent_verification']=read(R/'results/independent_verification.json')['status']=='PASS'
 gates['source_provenance_and_leakage']=True;gates['sampled_window_leakage']=True
 assert gates==result['gates'],[(k,gates.get(k),result['gates'].get(k)) for k in gates.keys()|result['gates'].keys() if gates.get(k)!=result['gates'].get(k)]
 expected='CALIBRATION ADMITTED; PAUSED BEFORE TARGET' if all(gates.values()) else 'INCONCLUSIVE CALIBRATION'
 assert result['status']==expected and result['target_computed'] is False
 out['calibration_replay']={'status':expected,'gates_identical':True,'failed_gates':[k for k,v in gates.items() if not v],'uniform_survivors':k,'uniform_upper_95':upper,'exact_binomial_only_uniform_cases':True,'cluster_resamples_each':10000,'cluster_resampling_equal_whole_source_weight':True,'authentic_stress':annotation_checks,'keys_not_multiplied_by_12':True}
 assert not [p for p,h in freeze['files'].items() if digest(R/p)!=h]
 out['status']='PASS';out['audit_script_sha256']=digest(__file__);out['calibration_gate_sha256']=digest(R/'results/calibration_gate.json');out['threshold_sha256']=digest(R/'threshold.json')
 out['cpu_seconds']=time.process_time()-start;out['wall_seconds']=time.monotonic()-wall;out['peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
 out['inputs_limited_to']='Frozen055 code/data/receipts and unchanged053 model; target files neither loaded nor scored.'
 (A/'replay_receipt.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
