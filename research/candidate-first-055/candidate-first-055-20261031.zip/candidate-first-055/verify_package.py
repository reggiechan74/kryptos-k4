"""Verify the compact archive's included-file checksums; no target scoring."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'CHECKSUMS.json').read_text())
for path,expected in manifest['included_files'].items():
    p=ROOT.parent/path
    assert p.is_file(),f'Missing included file: {path}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256'],f'Checksum mismatch: {path}'
print('PASS:',len(manifest['included_files']),'included file checksums. Omitted source assets require separate reconstruction; no language score computed.')
