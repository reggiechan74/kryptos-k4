"""Unscored data and reproducibility utilities."""
from pathlib import Path
import datetime, hashlib, json, random, resource, sys, time
ROOT = Path(__file__).resolve().parent
SEED_PREFIX = 'candidate-first-055-v1'
MODEL = ROOT.parent / 'candidate-first-053/model/log_tables.bin'
SEEDS = {}
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rng(label):
    hexdigest = hashlib.sha256((SEED_PREFIX + '|' + label).encode('ascii')).hexdigest()
    SEEDS[label] = hexdigest
    return random.Random(int(hexdigest, 16))
def load(path): return json.loads(Path(path).read_text())
def save(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + '\n')
def normalized(raw):
    return bytes(b - 32 if 97 <= b <= 122 else b for b in raw if 65 <= b <= 90 or 97 <= b <= 122)
def set_limits():
    hard = resource.getrlimit(resource.RLIMIT_CPU)[1]
    cap = 3400 if hard == resource.RLIM_INFINITY else min(3400, hard)
    resource.setrlimit(resource.RLIMIT_CPU, (cap, cap))
    resource.setrlimit(resource.RLIMIT_AS, (8*1024**3, 8*1024**3))
def receipt(start, cpu):
    r = resource.getrusage(resource.RUSAGE_SELF)
    return dict(started_utc=start, ended_utc=utc(), cpu_seconds=time.process_time()-cpu,
                peak_rss_bytes=r.ru_maxrss*1024, python=sys.version,
                budget_cpu_seconds=3600, budget_ram_bytes=8*1024**3)
def check_freeze():
    f = load(ROOT/'freeze.json')
    errors = [p for p,h in f['files'].items() if sha(ROOT/p) != h]
    if errors: raise RuntimeError('Frozen files changed: ' + ', '.join(errors))
    return f
