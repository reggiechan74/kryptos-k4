"""Independent score-free integrity assertions on final source fixtures and annotations."""
from collections import Counter, defaultdict
from array import array
import hashlib, json, pathlib, re, sys, time
from common import ROOT, load, normalized, save, sha, utc

def main():
    started=utc();cpu=time.process_time()
    manifest=load(ROOT/'source/source_manifest.json');docs={d['document_id']:d for d in manifest['documents']}
    norm={did:(ROOT/d['normalized_path']).read_bytes() for did,d in docs.items()}
    all_refs=[];counts={}
    for role in ['development','test']:
        for kind,n in [('positive',300),('letter_scrambled',200)]:
            rows=load(ROOT/f'fixtures/{kind}_{role}.json');assert len(rows)==n
            counts[kind+'|'+role]=len(rows)
            assert len({f['id'] for f in rows})==n
            if kind=='positive':assert Counter(f['stratum'] for f in rows)=={'archaic':100,'fiction':100,'nonfiction':100}
            for f in rows:
                did=f['document_id'];d=docs[did];start=f['normalized_offset'];end=f['normalized_end'];base=f.get('base_key',f['key'])
                assert d['role']==role and d['group']==f['group'] and d['stratum']==f['stratum']
                assert end-start==97 and len(base)==97 and base.encode()==norm[did][start:end]
                assert hashlib.sha256(base.encode()).hexdigest()==f['key_sha256']
                assert any(a<=start and end<=b for a,b in d['segments'])
                raw=pathlib.Path(d['raw_path']).read_bytes()[f['raw_start']:f['raw_end']]
                assert normalized(raw)==base.encode()
                if kind=='letter_scrambled':assert Counter(f['key'])==Counter(base)
                all_refs.append(f)
        uniforms=load(ROOT/f'fixtures/uniform_{role}.json');assert len(uniforms)==200
        assert all(len(f['ciphertext'])==24 and re.fullmatch('[A-Z]{24}',f['ciphertext']) for f in uniforms)
    for name in ['word_order_bases','function_word_deletion_bases']:
        rows=load(ROOT/f'fixtures/{name}.json');assert len(rows)==100;all_refs.extend(rows)
    seen={};intervals=defaultdict(list);duplicates=[]
    training=[norm[d['document_id']] for d in docs.values() if d['role']=='training']
    for f in all_refs:
        key=f.get('base_key',f['key']);did=f['document_id'];a=f['normalized_offset'];b=a+97
        assert key not in seen,(f['id'],seen.get(key));seen[key]=f['id']
        assert not any(key.encode() in t for t in training)
        assert not any(a<y and b>x for x,y in intervals[did]);intervals[did].append((a,b))
    annotations=load(ROOT/'stress_manifest.json')
    ids={f['id']:f for f in load(ROOT/'fixtures/positive_test.json')}
    for name in ['proper_names','historical_spellings']:
        records=annotations[name];assert len(records)<=20
        assert len({r['fixture_id'] for r in records})==len(records)
        assert [r['fixture_id'] for r in records]==sorted(r['fixture_id'] for r in records)
        assert all(r['fixture_id'] in ids for r in records)
    stress=load(ROOT/'fixtures/descriptive_stress.json')
    assert Counter(f['kind'] for f in stress)==dict(adjacent_transposition=300,word_order_scrambled=100,independently_paired_source=100,function_word_deletion=100)
    for f in stress:
        if 'key' in f:assert re.fullmatch('[A-Z]{97}',f['key'])
        else:assert [len(p) for p in f['fragments']]==[13,11]
    save(ROOT/'results/input_validation.json',dict(status='PASS',started_utc=started,ended_utc=utc(),cpu_seconds=time.process_time()-cpu,
        fixture_counts=counts,distinct_source_windows=len(all_refs),nonoverlap_passed=True,
        cross_role_window_duplicate_remaining=0,training_window_duplicate_remaining=0,
        annotation_counts={k:len(annotations[k]) for k in ['proper_names','historical_spellings']},
        source_manifest_sha256=sha(ROOT/'source/source_manifest.json'),target_loaded=False,language_scoring_performed=False))
    print('Input integrity checks passed.')
if __name__=='__main__':main()
