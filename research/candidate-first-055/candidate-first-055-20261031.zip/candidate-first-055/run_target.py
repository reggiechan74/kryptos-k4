"""Post-admission orchestration only. Uses the unchanged frozen scorer exactly once.

Written after calibration admission, before target scoring. No parameters, sources,
criteria or mathematical functions in the original freeze are modified here.
"""
import json, time
from common import ROOT, MODEL, load, save, sha, utc, receipt, check_freeze, set_limits
from core import Model, TABLEAUX

def ranks(value, references):
    n=len(references);le=sum(v<=value for v in references);ge=sum(v>=value for v in references)
    return dict(n=n,count_at_or_below_target=le,count_at_or_above_target=ge,
                empirical_cdf_at_target=le/n,empirical_upper_tail_at_target=ge/n)

def comparisons(value, keys, uniforms):
    strata=sorted(set(k['stratum'] for k in keys));groups=sorted(set(k['group'] for k in keys))
    true_strata={s:ranks(value,[k['true_score'] for k in keys if k['stratum']==s]) for s in strata}
    true_groups={g:ranks(value,[k['true_score'] for k in keys if k['group']==g]) for g in groups}
    case_max={}
    for i,t in enumerate(TABLEAUX):
        case_max['-'.join(t)]={s:ranks(value,[k['case_max_by_generating_tableau'][i] for k in keys if k['stratum']==s]) for s in strata}
    uniform=ranks(value,[r['case_max'] for r in uniforms])
    uniform['monte_carlo_upper_tail_rank']=(1+uniform['count_at_or_above_target'])/(len(uniforms)+1)
    uniform['rank_convention']='(1 + number of independent uniform-case maxima >= value) / (n + 1)'
    return dict(true_key_positive_by_stratum=true_strata,true_key_positive_by_source_group=true_groups,
                positive_case_max_by_generating_convention_and_stratum=case_max,
                uniform_case_max_reference=uniform)

def main():
    set_limits();started=utc();cpu=time.process_time();check_freeze()
    if (ROOT/'results/target_result.json').exists():raise RuntimeError('Target already evaluated; no second primary run authorized')
    gate=load(ROOT/'results/calibration_gate.json')
    assert gate['status']=='CALIBRATION ADMITTED; PAUSED BEFORE TARGET' and all(gate['gates'].values())
    assert load(ROOT/'results/independent_analysis.json')['status']=='PASS'
    assert load(ROOT/'results/external_audit/replay_receipt.json')['status']=='PASS'
    authorization=load(ROOT/'target_authorization.json');assert authorization['authorized'] is True
    stage=load(ROOT/'target_stage_freeze.json')
    assert all(sha(ROOT/p)==h for p,h in stage['files'].items()),'Target-stage dependency changed'
    assert sha(ROOT/'freeze.json')==authorization['calibration_freeze_sha256']
    source=load(ROOT/'provenance/public-054-target_result.json');ciphertext=source['ciphertext']
    assert len(ciphertext)==97 and all('A'<=c<='Z' for c in ciphertext)
    target_cipher=ciphertext[21:34]+ciphertext[63:74]
    scores=Model(MODEL).case(target_cipher)  # Exactly one primary twelve-tableau score evaluation.
    tau=load(ROOT/'threshold.json')['tau'];published={q['tableau_id']:q for q in source['result']['queries']}
    keys=load(ROOT/'results/positive_keys_test.json')
    uniforms=[json.loads(l) for l in (ROOT/'results/uniform_test.jsonl').read_text().splitlines()]
    for score in scores:
        q=published[score['tableau']]
        assert score['fragments']==[q['first_fragment'],q['second_fragment']]
        score['margin_to_tau']=score['score']-tau;score['survived']=score['score']>=tau
        score['reference_comparisons']=comparisons(score['score'],keys,uniforms)
    maximum=max(s['score'] for s in scores);survivors=[s['tableau'] for s in scores if s['survived']]
    result=dict(status='FRAGMENT SCREEN SURVIVED' if survivors else 'NO DIRECT-ENGLISH-KEY CONTINUATION UNDER THIS SCREEN',
                target_ciphertext_sha256=source['ciphertext_sha256'],crib_ciphertext=target_cipher,
                tau=tau,case_max=maximum,maximum_margin_to_tau=maximum-tau,surviving_tableaux=survivors,
                best_tableaux=[s['tableau'] for s in scores if s['score']==maximum],scores=scores,
                target_case_max_reference_comparisons=comparisons(maximum,keys,uniforms),
                primary_target_evaluation_count=1,calibration_freeze_sha256=sha(ROOT/'freeze.json'),
                target_stage_freeze_sha256=sha(ROOT/'target_stage_freeze.json'),threshold_sha256=sha(ROOT/'threshold.json'),
                original_054_fragments_match=True,calibration_passed_gates=gate['passed_gates'],
                scope='Direct position-aligned English running keys under exactly twelve fixed conventions and this unchanged local character screen.',
                interpretation='A research-priority screen, not proof that English keys are impossible, a decipherment, a global p-value, or a source-provenance test.',
                limitations=['Only three archaic held-out source groups.',
                            'Authentic name/spelling subsets are all archaic; only 10/20 name tokens and 5/20 spelling tokens intersect scored fragments.',
                            'Two short additive fragments cannot establish semantics, syntax, the 29-letter bridge, or full 97-letter key coherence.',
                            'Uniform-reference tail ranks are not probabilities that English is impossible or that K4 is solved.'],
                continuation='Stop study 055 if no tableau survives. No decoder, new hypothesis, model change, source hunt, publication or Site modification authorized.')
    save(ROOT/'results/target_result.json',result);save(ROOT/'results/compute_target.json',receipt(started,cpu))
    print(json.dumps({k:result[k] for k in ['status','tau','case_max','maximum_margin_to_tau','surviving_tableaux','best_tableaux']}))
    for s in scores: print(s['tableau'],s['score'],s['margin_to_tau'])
if __name__=='__main__':main()
