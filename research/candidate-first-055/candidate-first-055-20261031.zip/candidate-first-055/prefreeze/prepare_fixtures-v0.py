"""Deterministic, score-free fixture sampler. No model or target inputs."""
from array import array
from collections import Counter, defaultdict
from pathlib import Path
import bisect, hashlib, json, platform, re, sys
from common import ROOT, SEEDS, load, normalized, rng, save, sha, utc

class Sampler:
    def __init__(self, manifest):
        self.documents = manifest['documents']
        self.norm = {}; self.offsets = {}; self.raw = {}; self.used = defaultdict(list)
        self.seen = {}; self.rejections = Counter(); self.rejected_duplicates = []
        for d in self.documents:
            did = d['document_id']
            self.norm[did] = (ROOT/d['normalized_path']).read_bytes()
            self.raw[did] = Path(d['raw_path']).read_bytes()
            a = array('I'); a.frombytes((ROOT/d['raw_offsets_path']).read_bytes())
            if sys.byteorder != 'little': a.byteswap()
            self.offsets[did] = a
        self.training = [(d['document_id'], self.norm[d['document_id']]) for d in self.documents if d['role']=='training']

    def draw(self, role, stratum, n, kind, prefix, minimum_segment_length=97):
        docs = [d for d in self.documents if d['role']==role and (stratum is None or d['stratum']==stratum)]
        by_group = defaultdict(list)
        for d in docs: by_group[d['group']].append(d)
        groups = sorted(by_group)
        if not groups: raise RuntimeError('No groups for '+str((role,stratum)))
        group_rng = rng('allocation|'+kind+'|'+role+'|'+str(stratum)); group_rng.shuffle(groups)
        quotas = {g:n//len(groups)+(i<n%len(groups)) for i,g in enumerate(groups)}
        out = []
        for g in sorted(groups):
            ds = sorted(by_group[g], key=lambda d:d['document_id'])
            random = rng('sample|'+kind+'|'+role+'|'+str(stratum)+'|'+g)
            random.shuffle(ds)
            for local in range(quotas[g]):
                accepted = False
                for attempt in range(100000):
                    # Balanced document turns; only exhaustion retries change the selected document.
                    d = ds[(local + attempt//1000) % len(ds)]
                    did = d['document_id']; segments = [s for s in d['segments'] if s[1]-s[0]>=minimum_segment_length]
                    choices = [b-a-minimum_segment_length+1 for a,b in segments]
                    if not choices: continue
                    ticket = random.randrange(sum(choices))
                    for segment,count in zip(segments,choices):
                        if ticket < count: break
                        ticket -= count
                    start = segment[0]+ticket; end = start+97
                    if any(start<b and end>a for a,b in self.used[did]):
                        self.rejections['overlapping_reference_window']+=1; continue
                    key = self.norm[did][start:end].decode('ascii')
                    if key in self.seen:
                        self.rejections['duplicate_reference_window']+=1
                        self.rejected_duplicates.append(dict(role=role,document_id=did,offset=start,prior=self.seen[key])); continue
                    training_hits = [(tid, t.find(key.encode('ascii'))) for tid,t in self.training]
                    training_hits = [(tid,o) for tid,o in training_hits if o>=0]
                    if training_hits:
                        self.rejections['training_window_duplicate']+=1
                        self.rejected_duplicates.append(dict(role=role,document_id=did,offset=start,training_hits=training_hits)); continue
                    self.used[did].append((start,end)); self.seen[key]=dict(role=role,document_id=did,offset=start,kind=kind)
                    offsets = self.offsets[did]; raw_start = offsets[start]; raw_end = offsets[end-1]+1
                    out.append(dict(role=role,stratum=d['stratum'],group=g,document_id=did,
                                    normalized_offset=start, normalized_end=end, segment=segment,
                                    raw_start=raw_start,raw_end=raw_end,
                                    raw_excerpt=self.raw[did][raw_start:raw_end].decode('utf-8','replace'),
                                    key=key,key_sha256=hashlib.sha256(key.encode()).hexdigest(),kind=kind))
                    accepted=True; break
                if not accepted: raise RuntimeError('Insufficient eligible unique nonoverlapping windows: '+g)
        out.sort(key=lambda f:(f['stratum'],f['group'],f['document_id'],f['normalized_offset']))
        for i,f in enumerate(out,1): f['id']=prefix+f'{i:03d}'
        return out,dict(quotas=quotas,groups=len(groups),count=n)

    def word_tokens(self, fixture):
        did=fixture['document_id']; start=fixture['normalized_offset']; end=min(start+300,fixture['segment'][1])
        offsets=self.offsets[did]; raw=self.raw[did]
        raw_start=offsets[start]; raw_end=offsets[end-1]+1
        # Exclude possibly cut edge words; select complete ASCII-letter words, retaining original spellings.
        matches=list(re.finditer(rb'[A-Za-z]+',raw[raw_start:raw_end]))
        if matches and matches[0].start()==0: matches=matches[1:]
        if matches and matches[-1].end()==raw_end-raw_start: matches=matches[:-1]
        return [m.group().decode('ascii').upper() for m in matches], [raw_start,raw_end]

def main():
    manifest=load(ROOT/'source/source_manifest.json'); sampler=Sampler(manifest)
    allocations={}; fixture_counts={}; positives={}; scrambled={}
    for role in ('development','test'):
        combined=[]
        for stratum in ('archaic','fiction','nonfiction'):
            rows,a=sampler.draw(role,stratum,100,'positive',('D' if role=='development' else 'T')+stratum[0].upper())
            allocations[role+'|positive|'+stratum]=a; combined.extend(rows)
        positives[role]=sorted(combined,key=lambda x:x['id'])
        save(ROOT/f'fixtures/positive_{role}.json',positives[role]);fixture_counts['positive_'+role]=len(combined)
    for role in ('development','test'):
        rows,a=sampler.draw(role,None,200,'letter_scrambled',('DS' if role=='development' else 'TS'))
        allocations[role+'|letter_scrambled']=a
        rr=rng('scramble-convention|'+role); conventions=[i%12 for i in range(200)];rr.shuffle(conventions)
        for f,t in zip(rows,conventions):
            letters=list(f['key']);rng('letter-permutation|'+f['id']).shuffle(letters)
            f['base_key']=f.pop('key'); f['key']=''.join(letters); f['generating_tableau_index']=t
        scrambled[role]=rows;save(ROOT/f'fixtures/letter_scrambled_{role}.json',rows);fixture_counts['letter_scrambled_'+role]=len(rows)
        uniforms=[];random=rng('uniform-ciphertext|'+role)
        for i in range(200): uniforms.append(dict(id=('DU' if role=='development' else 'TU')+f'{i+1:03d}',ciphertext=''.join(random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(24))))
        save(ROOT/f'fixtures/uniform_{role}.json',uniforms);fixture_counts['uniform_'+role]=len(uniforms)
    descriptions=[]
    # All test positives receive exactly one seeded adjacent-letter transposition; no retries.
    for f in positives['test']:
        k=list(f['key']); pos=rng('typo|'+f['id']).randrange(96);k[pos],k[pos+1]=k[pos+1],k[pos]
        descriptions.append(dict(id='TYPO-'+f['id'],kind='adjacent_transposition',base_fixture_id=f['id'],
                                 group=f['group'],stratum=f['stratum'],key=''.join(k),edited_position=pos,
                                 no_op=k[pos]==k[pos+1],generating_tableau_index=(len(descriptions)%12)))
    # Separate sampled source windows anchor full-word fragments. No word/case score can affect them.
    bases,a=sampler.draw('test',None,100,'word_order','WO',minimum_segment_length=300)
    allocations['test|word_order']=a
    for i,f in enumerate(bases):
        words,raw_range=sampler.word_tokens(f);rng('word-order|'+f['id']).shuffle(words)
        k=''.join(words)[:97]
        if len(k)!=97: raise RuntimeError('Insufficient full words for word-order stress')
        descriptions.append(dict(id=f['id'],kind='word_order_scrambled',key=k,group=f['group'],stratum=f['stratum'],
                                 document_id=f['document_id'],base_normalized_offset=f['normalized_offset'],
                                 raw_source_range=raw_range,generating_tableau_index=i%12))
    save(ROOT/'fixtures/word_order_bases.json',bases)
    # Independently paired source fragments deliberately preserve local English; never called negative truth.
    p=positives['test'];random=rng('independently-paired-source');pairs=[]
    for i in range(100):
        a=random.choice(p);b=random.choice([x for x in p if x['group']!=a['group']])
        pairs.append(dict(id=f'PAIR{i+1:03d}',kind='independently_paired_source',
                          fragments=[a['key'][21:34],b['key'][63:74]],source_fixture_ids=[a['id'],b['id']],
                          source_groups=[a['group'],b['group']],generating_tableau_index=i%12))
    descriptions.extend(pairs)
    # Deterministic function-word deletion is altered-text stress, not authentic compressed writing.
    deletion_words=['A','AN','AND','AS','AT','BY','FOR','IN','OF','ON','OR','THE','TO']
    bases,a=sampler.draw('test',None,100,'function_word_deletion','FD',minimum_segment_length=300)
    allocations['test|function_word_deletion']=a
    for i,f in enumerate(bases):
        words,raw_range=sampler.word_tokens(f);retained=[w for w in words if w not in deletion_words]
        k=''.join(retained)[:97]
        if len(k)!=97:raise RuntimeError('Insufficient words after deterministic function-word deletion')
        descriptions.append(dict(id=f['id'],kind='function_word_deletion',key=k,group=f['group'],stratum=f['stratum'],
                                 document_id=f['document_id'],base_normalized_offset=f['normalized_offset'],
                                 raw_source_range=raw_range,generating_tableau_index=i%12))
    save(ROOT/'fixtures/function_word_deletion_bases.json',bases)
    save(ROOT/'fixtures/descriptive_stress.json',descriptions)
    save(ROOT/'fixtures/allocations.json',allocations)
    save(ROOT/'fixtures/sampling_receipt.json',dict(created_utc=utc(),prng='Python random.Random, MT19937',python=sys.version,
        seed_prefix='candidate-first-055-v1',seeds=SEEDS,counts=fixture_counts,
        role_priority=['training','development','test'],
        sampling_order='Development positives, test positives, development scrambled, test scrambled, test word-order, test deletion.',
        document_allocation='Equal group quotas; seeded permutation assigns remainder. Seeded document order, round-robin draws within group.',
        start_allocation='Uniform over valid starts within chosen document segments; reject overlaps and literal 97-letter duplicates without scores.',
        rejection_counts=dict(sampler.rejections),rejected_duplicates=sampler.rejected_duplicates,
        sampled_windows=len(sampler.seen),all_sampled_reference_windows_distinct=True,
        training_window_membership_checked_documents=len(sampler.training),training_window_duplicate_remaining=0,
        cross_role_sampled_window_duplicate_remaining=0,
        authentic_compressed_writing_coverage='Absent from the frozen source plan; function-word deletion is descriptive altered text only.',
        deletion_words=deletion_words,
        boundary_note='Reference windows do not cross audited segment boundaries. Word stresses use whole ASCII words from a 300-letter same-segment region.'))
    print(json.dumps(dict(counts=fixture_counts,rejections=dict(sampler.rejections),sampled_windows=len(sampler.seen))))

if __name__=='__main__':main()
