# Candidate 055 source preparation

Source bytes are unchanged. All 89 accepted 054 raw files, body hashes, normalized-letter hashes and raw-offset hashes match the pinned 054 receipt. One additional Austen work is excluded by training-author policy, leaving eight actual training documents, 44 development documents and 36 test documents. No normalized full-document duplicates or cross-role author/source-group intersections were found.

The final `source_manifest.json` SHA-256 is `56b6f50d5552c90d8152e23e812e80df588434bcd2a512289b92be79510d4c80`. It gives normalized file paths, uint32 little-endian raw-byte offset paths, source roles, groups, strata, original provenance and complete half-open sampling segments. No window may cross a segment boundary.

## Group counts

| Role | Fiction | Nonfiction / public essay | Archaic / verse |
|---|---:|---:|---:|
| Development | 6 | 22 | 2 |
| Test | 9 | 13 | 3 |

Training contains four author groups and eight documents. Each trained prefix has 200,000 letters; full source bodies are retained for stronger source leakage checks.

## Boundaries and attribution

There are 640 recorded conservative heading boundaries: KJV 73, Blake 54, Bryant 59, Milton 12, Whitman 424, Thoreau 1, Machiavelli/Marriott 5, Doyle 12. KJV book aliases account for more than 66 headings; an independent construction assertion checks that all 66 first verses have protected book boundaries. Poetry/book headings deliberately retain some conservative extra subdivisions. Bryant has extra boundaries between its two opening riddles and between the prose introduction and Alcott's poem.

Bryant is a compilation/retelling source group, not uniformly sole-authored prose. Raw text explicitly mentions Alcott and Andersen, with no explicit training/test author-name credit detected by the recorded check. Biblical retellings share a development-role tradition with KJV. This is not a claim of globally verified contributor independence. Inaugural sources preserve speaker/same-surname groups, not verified ghostwriter groups.

The pinned Machiavelli raw header explicitly names W. K. Marriott as translator. Translation, introduction, dedication and supplements remain one test group. A Modest Proposal is classified as a nonfiction/public-essay form while explicitly recognized as satire, not factual reporting. Exact historical editions of modern electronic transcriptions are not certified.

## Verification and exposure

`test_source_manifest.py` independently normalizes with byte regular expressions, checks every raw-byte offset, checks the segment partitions, checks that all recorded boundaries are protected, and checks role/group disjointness. All 88 documents pass. It reads no language model, ciphertext or target fragments. The scorer and sampler are separate; sampled-window leakage checks remain mandatory before scoring.

Source-preparation runs and independent normalization verification used under 20 CPU seconds combined, conservatively budgeted at 30 seconds because the first preparation run was not separately resource-receipted. Final independent verification recorded 3.144454123 CPU seconds and 647,208 KiB peak RSS. No source score was computed, no target was loaded, and 053/054 files were not modified.

Before the final freeze, boundary QA added the two Bryant internal splits; the preliminary manifest hash was `671a67c30b4afba2bd62174e2ef561f7f7fdc7bc8ab9af629fc769d45f4e87cc`. The final manifest supersedes this unscored preparation draft.
