"""Independent, scorer-free source/offset/boundary checks."""
from pathlib import Path
import json, hashlib, struct, re, time,resource
R=Path(__file__).resolve().parent.parent
cpu=time.process_time();m=json.loads((R/'source/source_manifest.json').read_text());errors=[];tests=[]
for d in m['documents']:
    raw=Path(d['raw_path']).read_bytes();n=(R/d['normalized_path']).read_bytes();o=(R/d['raw_offsets_path']).read_bytes()
    # Independently reconstruct normalization using bytes regex and .upper().
    expected=re.sub(rb'[^A-Za-z]',b'',raw[d['body_start']:d['body_end']]).upper()
    assert expected==n
    offsets=struct.unpack('<'+'I'*(len(o)//4),o)
    assert len(offsets)==len(n)
    assert all(x<y for x,y in zip(offsets,offsets[1:]))
    assert bytes(raw[i] for i in offsets).upper()==n
    assert d['segments'][0][0]==0 and d['segments'][-1][1]==len(n)
    assert all(a[1]==b[0] for a,b in zip(d['segments'],d['segments'][1:]))
    cuts={a for a,b in d['segments']}|{len(n)}
    assert all(x['normalized_offset'] in cuts for x in d['boundary_evidence'])
    tests.append({'document_id':d['document_id'],'independent_normalization':True,'all_raw_offsets_round_trip':True,'segment_partition':True,'all_recorded_boundaries_protected':True})
byrole={r:{d['group'] for d in m['documents'] if d['role']==r} for r in ('training','development','test')}
assert not(byrole['training']&byrole['development'] or byrole['training']&byrole['test'] or byrole['development']&byrole['test'])
out={'all_passed':True,'documents_verified':len(tests),'checks':tests,'cross_role_group_disjoint':True,'cpu_seconds':time.process_time()-cpu,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'target_loaded':False,'language_model_loaded':False}
(R/'source/independent_source_verification.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
