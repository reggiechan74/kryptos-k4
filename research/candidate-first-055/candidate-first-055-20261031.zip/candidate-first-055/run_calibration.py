"""Frozen study 055 development and test runner. No target loader exists."""
import argparse, hashlib, json, math, resource, statistics, time
from collections import Counter, defaultdict
from pathlib import Path
from common import ROOT, MODEL, SEEDS, check_freeze, load, rng, save, set_limits, sha, utc, receipt
from core import CRIB, TABLEAUX, Model, derive_pair, encrypt_pair, encrypt_text, key_pair

STRATA=('archaic','fiction','nonfiction')

def score_positives(model, role, tau=None):
    rows=load(ROOT/f'fixtures/positive_{role}.json'); output=[]
    with open(ROOT/f'results/positive_cases_{role}.jsonl','x') as handle:
        for f in rows:
            true_score=model.score(key_pair(f['key'])); maxima=[]
            for ti,t in enumerate(TABLEAUX):
                ciphertext=encrypt_pair(f['key'],t)
                recovered=derive_pair(ciphertext,t)
                if recovered!=key_pair(f['key']):raise AssertionError('True fragment recovery failed')
                scores=model.case(ciphertext); max_score=max(x['score'] for x in scores)
                if abs(scores[ti]['score']-true_score)>1e-10:raise AssertionError('Generating score mismatch')
                maxima.append(max_score)
                handle.write(json.dumps(dict(fixture_id=f['id'],group=f['group'],stratum=f['stratum'],
                    generating_tableau='-'.join(t),ciphertext=ciphertext,true_score=true_score,
                    case_max=max_score,scores=scores),sort_keys=True)+'\n')
            output.append(dict(id=f['id'],group=f['group'],stratum=f['stratum'],true_score=true_score,
                               case_max_by_generating_tableau=maxima,
                               true_survived=None if tau is None else true_score>=tau))
    save(ROOT/f'results/positive_keys_{role}.json',output)
    return output

def score_references(model, role, kind, tau):
    rows=load(ROOT/f'fixtures/{kind}_{role}.json'); output=[]
    with open(ROOT/f'results/{kind}_{role}.jsonl','x') as handle:
        for f in rows:
            if kind=='uniform': ciphertext=f['ciphertext']
            else: ciphertext=encrypt_pair(f['key'],TABLEAUX[f['generating_tableau_index']])
            scores=model.case(ciphertext); maximum=max(x['score'] for x in scores)
            r=dict(id=f['id'],ciphertext=ciphertext,case_max=maximum,survived=maximum>=tau,scores=scores)
            for field in ('group','stratum','generating_tableau_index'):
                if field in f:r[field]=f[field]
            handle.write(json.dumps(r,sort_keys=True)+'\n');output.append(r)
    return output

def group_summary(rows, field):
    groups=defaultdict(list)
    for row in rows:groups[row['group']].append(bool(row[field]))
    return {g:dict(n=len(v),survivors=sum(v),rate=sum(v)/len(v)) for g,v in sorted(groups.items())}

def quantile_nearest_rank(values,q):return sorted(values)[max(0,math.ceil(q*len(values))-1)]

def cluster_sensitivity(groups,label):
    rates=[v['rate'] for g,v in sorted(groups.items())];r=rng(label);n=len(rates)
    bootstrap=[sum(r.choice(rates) for _ in rates)/n for _ in range(10000)]
    mean=sum(rates)/n
    return dict(equal_group_rate=mean,groups=n,resamples=10000,
        lower_2_5_percentile=quantile_nearest_rank(bootstrap,.025),
        upper_95_percentile=quantile_nearest_rank(bootstrap,.95),
        leave_one_group_out={g:sum(v['rate'] for h,v in groups.items() if h!=g)/(n-1) if n>1 else None for g in groups},
        bootstrap_mean_values=bootstrap,
        interpretation='Descriptive source-group sensitivity, not a population-level English confidence guarantee.')

def binomial_upper_95(k,n):
    if k==n:return 1.
    lo,hi=0.,1.
    for _ in range(100):
        p=(lo+hi)/2
        cdf=sum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k+1))
        if cdf>.05:lo=p
        else:hi=p
    return (lo+hi)/2

def score_stress(model,tau):
    out=[]
    with open(ROOT/'results/descriptive_stress.jsonl','x') as handle:
        for f in load(ROOT/'fixtures/descriptive_stress.json'):
            t=TABLEAUX[f['generating_tableau_index']]
            pair=tuple(f['fragments']) if 'fragments' in f else key_pair(f['key'])
            c=encrypt_text(CRIB,''.join(pair),t);scores=model.case(c)
            r=dict(id=f['id'],kind=f['kind'],generating_tableau='-'.join(t),true_score=model.score(pair),
                   true_survived=model.score(pair)>=tau,case_max=max(s['score'] for s in scores),
                   case_survived=max(s['score'] for s in scores)>=tau,ciphertext=c,scores=scores)
            handle.write(json.dumps(r,sort_keys=True)+'\n');out.append(r)
    summary={}
    for kind in sorted(set(r['kind'] for r in out)):
        rows=[r for r in out if r['kind']==kind]
        summary[kind]=dict(n=len(rows),true_survivors=sum(r['true_survived'] for r in rows),case_survivors=sum(r['case_survived'] for r in rows),mandatory_gate=False)
    return summary

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['development','calibration']);args=parser.parse_args()
    set_limits();started=utc();cpu=time.process_time();freeze=check_freeze()
    verification=load(ROOT/'results/independent_verification.json')
    # Verifier schema is frozen before running; any non-pass stops admission.
    if not verification.get('passed',verification.get('status')=='PASS'):raise RuntimeError('Independent verification has not passed')
    model=Model(MODEL)
    if args.stage=='development':
        if (ROOT/'threshold.json').exists():raise RuntimeError('Threshold already frozen; retain receipts, no silent rerun')
        positives=score_positives(model,'development')
        fifth={s:sorted(r['true_score'] for r in positives if r['stratum']==s)[4] for s in STRATA}
        tau=min(fifth.values())
        threshold=dict(tau=tau,stratum_fifth_smallest=fifth,created_utc=utc(),rule='Minimum across strata of the fifth-smallest true-key score among each 100 development keys; ties survive.',
                       freeze_sha256=sha(ROOT/'freeze.json'),frozen_files=freeze['files'],test_scores_exposed=False,
                       positive_case_file_sha256=sha(ROOT/'results/positive_cases_development.jsonl'),
                       positive_key_file_sha256=sha(ROOT/'results/positive_keys_development.json'))
        save(ROOT/'threshold.json',threshold)
        uniform=score_references(model,'development','uniform',tau)
        scrambled=score_references(model,'development','letter_scrambled',tau)
        result=dict(tau=tau,stratum_fifth_smallest=fifth,true_key_survivors={s:sum(r['true_score']>=tau for r in positives if r['stratum']==s) for s in STRATA},
                    uniform_case_survivors=sum(r['survived'] for r in uniform),letter_scrambled_case_survivors=sum(r['survived'] for r in scrambled),
                    no_threshold_selection_using_references=True,target_computed=False)
        save(ROOT/'results/development_summary.json',result)
    else:
        if (ROOT/'results/calibration_gate.json').exists():raise RuntimeError('Calibration already completed; no silent rerun')
        threshold=load(ROOT/'threshold.json')
        if threshold['freeze_sha256']!=sha(ROOT/'freeze.json'):raise RuntimeError('Threshold freeze mismatch')
        tau=threshold['tau'];positives=score_positives(model,'test',tau)
        uniform=score_references(model,'test','uniform',tau)
        scrambled=score_references(model,'test','letter_scrambled',tau)
        strata={};gates={}
        for s in STRATA:
            rows=[r for r in positives if r['stratum']==s];groups=group_summary(rows,'true_survived')
            sensitivity=cluster_sensitivity(groups,'bootstrap|positive|'+s)
            strata[s]=dict(n=len(rows),survivors=sum(r['true_survived'] for r in rows),groups=groups,sensitivity=sensitivity,
                case_max_survivors_by_generating_tableau={'-'.join(t):sum(r['case_max_by_generating_tableau'][i]>=tau for r in rows) for i,t in enumerate(TABLEAUX)})
            gates['positive_stratum_'+s]=len(rows)==100 and strata[s]['survivors']>=90
            gates['positive_groups_'+s]=all(v['rate']>=.8 for v in groups.values() if v['n']>=10)
            gates['positive_cluster_'+s]=sensitivity['lower_2_5_percentile']>=.8
        k=sum(r['survived'] for r in uniform); upper=binomial_upper_95(k,len(uniform))
        uniform_summary=dict(n=len(uniform),survivors=k,rate=k/len(uniform),one_sided_exact_binomial_upper_95=upper)
        gates['uniform_case_acceptance']=len(uniform)==200 and upper<=.15
        sg=group_summary(scrambled,'survived');ss=cluster_sensitivity(sg,'bootstrap|letter-scrambled|test')
        scramble_summary=dict(n=len(scrambled),survivors=sum(r['survived'] for r in scrambled),groups=sg,sensitivity=ss)
        gates['scrambled_equal_group_rate']=len(scrambled)==200 and ss['equal_group_rate']<=.20
        gates['scrambled_cluster_upper']=ss['upper_95_percentile']<=.30
        stress=load(ROOT/'stress_manifest.json');by_id={r['id']:r for r in positives};authentic={}
        for key in ('proper_names','historical_spellings'):
            items=stress[key];ids=[r['fixture_id'] for r in items]
            retained=[fid for fid in ids if by_id[fid]['true_survived']]
            authentic[key]=dict(n=len(ids),survivors=len(retained),survivor_ids=retained,
                                failed_ids=[fid for fid in ids if fid not in retained])
            gates[key]=len(ids)==20 and len(set(ids))==20 and len(retained)>=18
        descriptive=score_stress(model,tau)
        gates['independent_verification']=True
        audit=load(ROOT/'source/document_leakage_audit.json')
        source_verification=load(ROOT/'source/source_verification.json')
        gates['source_provenance_and_leakage']=source_verification['all_passed'] and not audit['cross_role_group_overlap'] and not audit['translator_audit']['cross_role_conflict'] and not audit['compiler_attribution_audit']['training_or_test_author_name_matches']
        sampling=load(ROOT/'fixtures/sampling_receipt.json')
        gates['sampled_window_leakage']=sampling['cross_role_sampled_window_duplicate_remaining']==0 and sampling['training_window_duplicate_remaining']==0
        all_pass=all(gates.values())
        result=dict(status='CALIBRATION ADMITTED; PAUSED BEFORE TARGET' if all_pass else 'INCONCLUSIVE CALIBRATION',
                    tau=tau,threshold_sha256=sha(ROOT/'threshold.json'),gates=gates,
                    passed_gates=sum(gates.values()),total_gates=len(gates),failed_gates=[k for k,v in gates.items() if not v],
                    true_key_strata=strata,uniform_reference=uniform_summary,letter_scrambled_reference=scramble_summary,
                    authentic_stress=authentic,descriptive_stress=descriptive,target_computed=False,
                    target_authorization='Parent independent audit and explicit continuation required. There is no target loader in this implementation.',
                    no_model_or_source_or_gate_changes_after_scores=True,analysis_seeds=SEEDS,
                    interpretation='Research-budget screen only; no conclusion that English keys are possible or impossible.')
        save(ROOT/'results/calibration_gate.json',result)
    r=receipt(started,cpu);r['stage']=args.stage;save(ROOT/f'results/compute_{args.stage}.json',r)
    print(json.dumps({k:v for k,v in result.items() if k in ('status','tau','true_key_survivors','uniform_case_survivors','letter_scrambled_case_survivors','passed_gates','total_gates','failed_gates')}))
    print(json.dumps(r))

if __name__=='__main__':main()
