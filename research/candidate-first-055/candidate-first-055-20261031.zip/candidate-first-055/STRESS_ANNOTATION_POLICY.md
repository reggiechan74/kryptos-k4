# Study 055: authentic stress annotation policy

This policy is recorded before any new study 055 scores. Annotating natural source windows does not make them sources never seen in the project.

## Selection

Inspect the frozen positive test fixtures in ascending fixture-ID order. A window qualifies only when it contains a complete qualifying raw token: all of that token's ASCII letters lie within the original 97-letter normalized source window. Retain the first 20 qualifying distinct windows for each category, with the first qualifying token by raw byte offset as evidence. Categories may overlap. Do not change the fixed windows or sample replacements to obtain coverage. If fewer than 20 qualify, retain the available annotations and report inadequate coverage.

## Proper names

Require a genuine named person, fictional or religious character, named place, people, institution or unique named entity, established from source context. Initial capitalization alone, a sentence-initial common noun, speaker abbreviations, titles such as King or Lord without a name, and metaphorical capitalization are insufficient. Generic religious designations (`God`, `Lord`) and personified natural/common-noun designations (`Earth`, `Nature`, `Mother of All`) are not treated as personal or geographic proper names for this annotation rule; explicit personal or geographic names are required. Retain the literal spelling, referent rationale, document ID, normalized offset and raw byte span. Possessive suffixes may follow the name; the annotated name itself must be complete.

## Historical spellings

Require an attested historical orthographic form with an explicit modern expansion or spelling, such as `haue` → `have`, `vpon` → `upon`, `selfe` → `self`, `shew` → `show`, or a poetic elision such as `fill'd` → `filled` or `o'er` → `over`. The normalized ASCII letters must differ from the modern form. Exclude merely archaic vocabulary or inflection (for example, `thou`, `doth`, `hath`), ordinary contemporary contractions, ordinary British/American variants, and punctuation-only differences removed by normalization. Document the actual original token rather than inventing a normalized historical variant.

## Scope caveat

These are window-level subsets as specified in the protocol. A name or spelling may fall outside the 24 scored letters. Each annotation separately records whether its normalized letter span intersects either scored fragment. Passing a window-level subset is not proof of robustness to names or historical spellings inside the scored fragments, much less all names or historical varieties.
