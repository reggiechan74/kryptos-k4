"""Transcribe the score-free manual prefix review into a reproducible decision ledger."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parent

def name(token, rationale): return dict(token=token,rationale=rationale)
def spelling(token, modern, rationale): return dict(token=token,modern_form=modern,rationale=rationale)
proper = {
11: name('Roanoke', 'Named river/valley in the geographical enumeration; followed by Delaware and the Adirondacks.'),
27: name('Europe', 'The named continent, explicitly paired with Asia and Africa.'),
31: name('Rome', 'Named city/state in the phrase about Rome’s wars; not a capitalized common noun.'),
57: name('Thel', 'The explicitly named central character of Blake’s The Book of Thel.'),
67: name('Romans', 'Proper collective name of the Roman people addressed in Julius Caesar.'),
70: name('Decius', 'Named character Decius Brutus, introduced by the stage direction and then named in full.'),
71: name('Decius', 'Named character Decius, addressed in the dialogue of Julius Caesar.'),
72: name('Cassius', 'Named character Cassius, explicitly instructed to go into the other street.'),
74: name('Antony', 'Named character Antony, addressed by the crowd.'),
75: name('Antony', 'Named character Antony, addressed as noble Antony.'),
76: name('Cassius', 'Named character Cassius in the invitation to enlarge his grievances in the speaker’s tent.'),
77: name('Brutus', 'Named character Brutus in the stage direction introducing Brutus and Messala.'),
78: name('Denmarke', 'The historical spelling of the place name Denmark, here used metonymically of the buried Danish king.'),
79: name('Guildensterne', 'Named character Guildenstern in the edition’s historical spelling; fully present after a clipped preceding name.'),
80: name('Fortinbras', 'Named character Fortinbras, recipient of the arrests/order in the dialogue.'),
86: name('Horatio', 'Named character Horatio in the stage direction.'),
88: name('Alexander', 'Alexander the Great, explicitly considered in the burial-to-dust passage of Hamlet.'),
89: name('Roman', 'Proper name for a member of the Roman people, used as a noun in “an Antike Roman”, not merely an adjective.'),
93: name('Heccats', 'Historical possessive form of Hecate’s name in the witchcraft passage of Macbeth; not a generic supernatural title.'),
94: name('England', 'Named country in the speaker’s stated destination, followed by Ireland.'),
}
historical = {
7: spelling("accomplish'd", 'accomplished', 'Printed poetic elision omits the e of the past-participle suffix; the normalized letters differ.'),
18: spelling("clutch'd", 'clutched', 'Printed poetic elision of e before the final d.'),
20: spelling("fill'd", 'filled', 'Printed poetic elision of e before the final d.'),
22: spelling("look'd", 'looked', 'Printed poetic elision of e before the final d.'),
24: spelling("chain'd", 'chained', 'Printed poetic elision of e before the final d.'),
27: spelling("join'd", 'joined', 'Printed poetic elision of e before the final d.'),
30: spelling("measur'd", 'measured', 'Printed poetic elision of e before the final d.'),
43: spelling("where'er", 'wherever', 'Historical poetic elision omits v in the middle of wherever.'),
56: spelling('thro', 'through', 'Historical poetic abbreviated spelling of through in the original verse; not supplied by the experiment.'),
58: spelling('reclind', 'reclined', 'Original Blake text omits e in the past-tense spelling of reclined, without an apostrophe.'),
59: spelling("rais'd", 'raised', 'Printed poetic elision of e before the final d.'),
61: spelling("wip'd", 'wiped', 'Printed poetic elision of e before the final d.'),
62: spelling('complaind', 'complained', 'Original Blake text omits e in the past-tense spelling of complained, without an apostrophe.'),
64: spelling('listning', 'listening', 'Historical poetic elision of medial e in listening, retained in the source text.'),
65: spelling('showring', 'showering', 'Historical poetic elision of medial e in showering, retained in the source text.'),
67: spelling('heare', 'hear', 'Early Modern spelling with an additional terminal e. Earlier loose is not used because its status as orthography versus lexical/semantic choice is ambiguous.'),
68: spelling('wonderfull', 'wonderful', 'Early Modern spelling with doubled final l.'),
69: spelling('Haue', 'Have', 'Early Modern u/v spelling interchange; literal u occupies the modern v position.'),
70: spelling("Heere's", "Here's", 'Early Modern heere/here spelling; the ordinary possessive/contraction apostrophe is not the reason for qualification.'),
71: spelling('sicke', 'sick', 'Early Modern spelling with an additional terminal e.'),
}
result = {'proper_name': {f'TA{i:03d}':proper.get(i) for i in range(1,95)},
          'historical_spelling': {f'TA{i:03d}':historical.get(i) for i in range(1,72)},
          'review_method': 'Every excerpt in each consecutive prefix was manually read without language scores. Null means no complete unambiguous token satisfying the recorded policy.',
          'ambiguous_exclusions': {
              'proper_names': 'Generic/personified Earth, Nature, God, Mother of All, Garden of Love, Lily, Cloud, Clod of Clay and Worm were not taken as explicit personal/geographic names. Spanish/Italian/English adjectival uses, generic titles and abbreviated speaker labels were excluded.',
              'historical_spellings': 'Archaic vocabulary and inflections alone (thou, thee, thy, dost, doth, furl’st), ordinary modern regional variants (gayly, plow/plough, humor), ambiguous meekin, and punctuation-only word separations (to day) were not used. Confirmed old letter spellings and poetic elisions with an explicit modern expansion were used.'}}
(ROOT/'stress_decisions.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
