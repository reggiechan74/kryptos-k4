#!/usr/bin/env python3
"""Post-admission independent target repeat, with the unchanged frozen verifier.

This new orchestration does not alter any calibrated arithmetic, model, threshold,
fixture, criterion, or previously frozen implementation. It is executed once,
after the authorized primary target evaluation. No decoder exists in this file.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import resource
import sys
import time
import traceback
from independent_verify import IndependentScorer, TABLEAUX, CRIB_PLAINTEXT, inverse_lookup

ROOT = Path(__file__).resolve().parent
SOURCE_SHA256 = '8442e40d50c5f2a5b12414692130f9c11b63381fb1a8eca82af60c1e2fe7ea14'
IDS = ['-'.join(t) for t in TABLEAUX]


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def near(a, b):
    assert math.isfinite(a) and math.isfinite(b) and abs(a - b) <= 1e-10, (a, b)


def empirical_ranks(value, distribution):
    total = len(distribution)
    assert total > 0
    lower = len([item for item in distribution if item <= value])
    upper = len([item for item in distribution if item >= value])
    return {'n': total, 'count_at_or_below_target': lower,
            'count_at_or_above_target': upper, 'empirical_cdf_at_target': lower / total,
            'empirical_upper_tail_at_target': upper / total}


def reference_comparisons(value, positives, uniform_maxima):
    strata = sorted({r['stratum'] for r in positives})
    groups = sorted({r['group'] for r in positives})
    true_strata = {s: empirical_ranks(value, [r['true_score'] for r in positives if r['stratum'] == s])
                   for s in strata}
    true_groups = {g: empirical_ranks(value, [r['true_score'] for r in positives if r['group'] == g])
                   for g in groups}
    convention_comparisons = {}
    for convention, identifier in enumerate(IDS):
        convention_comparisons[identifier] = {
            s: empirical_ranks(value, [r['case_max_by_generating_tableau'][convention]
                                      for r in positives if r['stratum'] == s])
            for s in strata}
    uniform = empirical_ranks(value, uniform_maxima)
    assert uniform['n'] == 200
    uniform['monte_carlo_upper_tail_rank'] = (uniform['count_at_or_above_target'] + 1) / 201
    uniform['rank_convention'] = '(1 + number of independent uniform-case maxima >= value) / (n + 1)'
    return {'true_key_positive_by_stratum': true_strata,
            'true_key_positive_by_source_group': true_groups,
            'positive_case_max_by_generating_convention_and_stratum': convention_comparisons,
            'uniform_case_max_reference': uniform}


def run(root):
    freeze = load(root / 'freeze.json')
    assert all(sha(root / p) == h for p, h in freeze['files'].items()), 'A calibration-frozen file changed'
    gate = load(root / 'results/calibration_gate.json')
    assert gate['status'] == 'CALIBRATION ADMITTED; PAUSED BEFORE TARGET'
    assert all(gate['gates'].values()) and gate['passed_gates'] == gate['total_gates']
    analysis = load(root / 'results/independent_analysis.json')
    assert analysis['status'] == 'PASS' and analysis['calibration_status'] == gate['status']
    assert analysis['calibration_gate_sha256'] == sha(root / 'results/calibration_gate.json')
    assert analysis['freeze_sha256'] == sha(root / 'freeze.json')
    authorization = load(root / 'target_authorization.json')
    assert authorization['authorized'] is True
    assert authorization['calibration_freeze_sha256'] == sha(root / 'freeze.json')
    assert authorization['authorized_utc'] == '2026-10-31T01:53:35Z'
    stage = load(root / 'target_stage_freeze.json')
    assert all(sha(root / p) == h for p, h in stage['files'].items()), 'A target-stage-frozen file changed'
    assert stage['files']['independent_target.py'] == sha(__file__)
    assert 'target_authorization.json' in stage['files']
    assert 'run_target.py' in stage['files']
    assert sha(root / 'provenance/public-054-target_result.json') == SOURCE_SHA256
    source = load(root / 'provenance/public-054-target_result.json')
    cipher = source['ciphertext']
    assert len(cipher) == 97 and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' for c in cipher)
    assert hashlib.sha256(cipher.encode()).hexdigest() == source['ciphertext_sha256']
    selected_cipher = cipher[21:34] + cipher[63:74]
    threshold = load(root / 'threshold.json')
    assert analysis['threshold_sha256'] == sha(root / 'threshold.json')
    tau = threshold['tau']
    assert tau == gate['tau'] == analysis['tau']
    primary = load(root / 'results/target_result.json')
    assert primary['primary_target_evaluation_count'] == 1
    assert primary['target_ciphertext_sha256'] == source['ciphertext_sha256']
    assert primary['crib_ciphertext'] == selected_cipher
    assert primary['calibration_freeze_sha256'] == sha(root / 'freeze.json')
    assert primary['target_stage_freeze_sha256'] == sha(root / 'target_stage_freeze.json')
    assert primary['threshold_sha256'] == sha(root / 'threshold.json')
    assert primary['tau'] == tau and primary['original_054_fragments_match'] is True
    assert len(primary['scores']) == 12 and [r['tableau'] for r in primary['scores']] == IDS
    published = {r['tableau_id']: (r['first_fragment'], r['second_fragment'])
                 for r in source['result']['queries']}
    assert set(published) == set(IDS)
    positives = load(root / 'results/positive_keys_test.json')
    assert len(positives) == 300
    uniforms = [json.loads(line) for line in (root / 'results/uniform_test.jsonl').read_text().splitlines()]
    uniform_maxima = [r['case_max'] for r in uniforms]
    assert len(uniform_maxima) == 200
    # All gate, source and hash checks precede loading or applying the model.
    scorer = IndependentScorer(root.parent / 'candidate-first-053/model/log_tables.bin')
    independent_rows = []
    largest_difference = 0.
    for tableau, saved in zip(TABLEAUX, primary['scores']):
        lookup = inverse_lookup(tableau)
        key24 = ''.join(lookup[p, c] for p, c in zip(CRIB_PLAINTEXT, selected_cipher))
        pair = (key24[:13], key24[13:])
        identifier = '-'.join(tableau)
        assert pair == published[identifier] == tuple(saved['fragments'])
        value = scorer.score(pair)  # Exactly one independent score per target tableau.
        near(value, saved['score'])
        near(value - tau, saved['margin_to_tau'])
        survived = value >= tau
        assert saved['survived'] is survived
        comparisons = reference_comparisons(value, positives, uniform_maxima)
        assert comparisons == saved['reference_comparisons'], 'Per-tableau reference-rank discrepancy'
        largest_difference = max(largest_difference, abs(value - saved['score']))
        independent_rows.append({'tableau': identifier, 'fragments': pair, 'score': value,
                                 'margin_to_tau': value - tau, 'survived': survived,
                                 'reference_comparisons': comparisons})
    maximum = max(row['score'] for row in independent_rows)
    survivors = [row['tableau'] for row in independent_rows if row['survived']]
    best = [row['tableau'] for row in independent_rows if row['score'] == maximum]
    near(maximum, primary['case_max'])
    near(maximum - tau, primary['maximum_margin_to_tau'])
    assert survivors == primary['surviving_tableaux'] and best == primary['best_tableaux']
    maximum_comparisons = reference_comparisons(maximum, positives, uniform_maxima)
    assert maximum_comparisons == primary['target_case_max_reference_comparisons']
    status = 'FRAGMENT SCREEN SURVIVED' if survivors else 'NO DIRECT-ENGLISH-KEY CONTINUATION UNDER THIS SCREEN'
    assert primary['status'] == status
    return {'status': 'PASS', 'target_outcome': status, 'tau': tau, 'case_max': maximum,
            'maximum_margin_to_tau': maximum - tau, 'surviving_tableaux': survivors,
            'best_tableaux': best, 'scores': independent_rows,
            'target_case_max_reference_comparisons': maximum_comparisons,
            'maximum_primary_independent_score_difference': largest_difference,
            'independent_target_evaluation_count': 1, 'target_tableau_scores_computed': 12,
            'original_054_fragments_match': True, 'all_reference_ranks_match': True,
            'calibration_freeze_sha256': sha(root / 'freeze.json'),
            'target_stage_freeze_sha256': sha(root / 'target_stage_freeze.json'),
            'primary_target_result_sha256': sha(root / 'results/target_result.json'),
            'unchanged_independent_verifier_sha256': sha(root / 'independent_verify.py'),
            'independence': 'Frozen independent inverse lookup and per-position n-gram scorer; separate rank-count implementation; no primary target-module import.',
            'interpretation': 'Research-priority screen only. Uniform-reference ranks are not probabilities that English is impossible or that K4 is solved.',
            'next_action': 'Stop study 055 if no tableau survives; no decoder, new hypothesis, model change, publication, or Site modification.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=ROOT / 'results/independent_target.json')
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Refusing a second independent target evaluation or receipt overwrite')
    started = time.monotonic()
    cpu = time.process_time()
    output = {'status': 'FAILED', 'target_outcome': 'INCONCLUSIVE/VERIFICATION'}
    exit_code = 1
    try:
        output = run(args.root)
        exit_code = 0
    except Exception as exc:
        output.update({'error_type': type(exc).__name__, 'error': str(exc), 'traceback': traceback.format_exc()})
    usage = resource.getrusage(resource.RUSAGE_SELF)
    output.update({'cpu_seconds': time.process_time() - cpu, 'wall_seconds': time.monotonic() - started,
                   'peak_rss_bytes': usage.ru_maxrss * 1024, 'python_version': sys.version,
                   'independent_target_code_sha256': sha(__file__)})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: output[k] for k in ('status', 'target_outcome', 'cpu_seconds', 'peak_rss_bytes')}, sort_keys=True))
    raise SystemExit(exit_code)


if __name__ == '__main__':
    main()
