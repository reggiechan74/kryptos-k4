# Study 061: sum-locked block rotations

**Result: exact bounded exclusion.** Both independently implemented K4 evaluations completed all 160 structural cases and returned zero compatible key cylinders. This does not exclude nonlinear block ciphers generally.

## Frozen model

AZ or KRYPTOS ranks; arbitrary periodic additive key of nominal period 1–8, indexed by original plaintext position; consecutive blocks of width 3–12. Rotate each block RIGHT by its post-addition rank sum modulo its actual length. The last block is ragged, without padding. Decode using the rotation-invariant ciphertext block sum. No alternate checksum, phase, direction, reset or additional layer.

Target domains exclude the all-zero vector, already contradicted by the local pure-transposition E-count proof. No nonzero constant-key domain was assumed excluded. Period aliases are descriptive; 160 structural cases do not mean 160 independent keyed functions.

## Evidence map

- `freeze/protocol.md`, `freeze/manifest.json`: exact rules, gates and 70-file pre-holdout freeze.
- `audit/tiny-result.json`, `audit/production-comparison-result.json`: independent reference and production versus exhaustive forward truth.
- `eligibility/`: actual target-route comparisons, source pins/hashes, prior-domain decisions and resource receipts. These are membership checks, not millions of new cipher trials.
- `benchmark/`: 416 fixtures, original seed/answers, two sealed outputs, resources and analysis.
- `audit/postbenchmark/FINAL-AUDIT.json`: independent seed replay and all complete benchmark sets.
- `target/`: canonical source/input, separate target approval, additive transport freeze, original outputs and resources.
- `audit/target/FINAL-AUDIT.json`: final independent non-search target audit.
- `METHOD-LEARNING.md`, `resource-ledger.json`: reusable checks, measured costs and explicit conservative reserves.

## Validation summary

Both implementations pass 19,656 tiny roundtrips and 137,268 complete cylinder comparisons, including free-key cases. The blind benchmark recovered all 352 plants: all 320 full-mask plants uniquely determined plaintext, while all 32 deliberately sparse planted settings correctly retained seven free key residues. Both engines agreed on all 416 complete sets; none of 64 random controls fit. Independent audit checked 79,865 full/representative-variable roundtrips. Cylinder completeness comes from exact residue equations and exhaustive tiny truth, not those sampled completions alone.

## Reproduction and provenance

Python 3.12 and its standard library suffice for cipher engines. From an extracted study directory, create a new output directory and run `python freeze/production.py benchmark/inputs.json new/production.jsonl` or `python freeze/reference_adapter.py benchmark/inputs.json new/reference.jsonl`. Preserve original receipts. Target reproduction requires a deliberate new request: this archive records exactly one original production and one original reference evaluation, with no target reruns.

Own route-membership code and original receipts are retained. Some historical scripts retain their original shared-workspace paths; adjust a copied script's input/output paths, not the sealed originals, when reproducing elsewhere. C++ membership comparators are source-only; compiled binaries are omitted. Third-party source code/prose is not redistributed without a verified license: URL/commit/hash inventories identify the exact reviewed files, which can be obtained from their public repositories. Source-inventory hashes may therefore refer to deliberately omitted provenance inputs; the archive payload manifest lists only included files.

The unavailable old EXT012 executable revision is disclosed. Its historical 484-specification universe was independently reconstructed with an identical full SHA256 and every per-spec hash/cardinality. This validates the inspected declared bounds, not that researcher's numerical cryptanalytic outcome. No worldwide novelty or historical-design claim is made.
