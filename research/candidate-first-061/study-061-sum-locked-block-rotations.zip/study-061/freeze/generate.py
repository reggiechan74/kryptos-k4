import json,random,sys,pathlib
import reference
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def generate(seed):
 rng=random.Random(seed);items=[]
 def text():return ''.join(rng.choice(reference.AZ) for _ in range(97))
 def plant(cfg,kind,mask):
  plain=list(text())
  if kind=='literal':
   for i,c in zip(mask,LITERAL):plain[i]=c
  plain=''.join(plain);key=[rng.randrange(26) for _ in range(cfg['period'])]
  cipher=reference.encrypt(plain,cfg['alphabet'],cfg['width'],key)
  items.append(({'ciphertext':cipher,'cribs':{str(i):plain[i] for i in mask}}, {'kind':kind,'config':cfg['id'],'key':key,'plaintext':plain}))
 for cfg in reference.configurations():
  for kind in ['uniform','literal']:plant(cfg,kind,MASK)
 for a,A in enumerate((reference.AZ,reference.KR)):
  for k in range(16):plant({'id':f'B:{a}:{3+k%10}:8','alphabet':A,'width':3+k%10,'period':8},'sparse',[0,8,16,24])
 for k in range(64):
  letters=LITERAL if k>=32 else ''.join(rng.choice(reference.AZ) for _ in MASK)
  items.append(({'ciphertext':text(),'cribs':dict(zip(map(str,MASK),letters))},{'kind':'null_literal' if k>=32 else 'null_uniform'}))
 rng.shuffle(items);inputs=[];answers=[]
 for k,(x,y) in enumerate(items):
  ID=f'case-{k:04d}';inputs.append({'id':ID,**x});answers.append({'id':ID,**y})
 return inputs,answers
if __name__=='__main__':
 dest=pathlib.Path(sys.argv[1]);seed=int((dest/'seed.txt').read_text(),16);inputs,answers=generate(seed)
 for name,data in [('inputs.json',inputs),('answers.json',answers)]:(dest/name).write_text(json.dumps(data,indent=2)+'\n')
