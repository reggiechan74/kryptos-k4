"""Study 061 finite sum-locked block rotation; no target literal or loader."""
import json,sys
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'
ALPHABETS=(AZ,KR)
def encrypt(plaintext,alphabet,width,key):
 n=len(alphabet);values=[(alphabet.index(c)+key[i%len(key)])%n for i,c in enumerate(plaintext)];out=[]
 for start in range(0,len(values),width):
  b=values[start:start+width];r=sum(b)%len(b);out.extend(b[-r:]+b[:-r] if r else b)
 return ''.join(alphabet[v] for v in out)
def unrotate(ciphertext,alphabet,width):
 out=[]
 for start in range(0,len(ciphertext),width):
  b=[alphabet.index(c) for c in ciphertext[start:start+width]];r=sum(b)%len(b);out.extend(b[r:]+b[:r])
 return out
def decrypt(ciphertext,alphabet,width,key):
 return ''.join(alphabet[(v-key[i%len(key)])%len(alphabet)] for i,v in enumerate(unrotate(ciphertext,alphabet,width)))
def cylinder(ciphertext,cribs,alphabet,width,period):
 values=unrotate(ciphertext,alphabet,width);key=[None]*period
 items=cribs.items() if isinstance(cribs,dict) else cribs
 for pos,char in items:
  pos=int(pos);res=pos%period;required=(values[pos]-alphabet.index(char))%len(alphabet)
  if key[res] is not None and key[res]!=required:return None
  key[res]=required
 free=[i for i,k in enumerate(key) if k is None]
 return {'key_residues':key,'free_residues':len(free),'key_count':len(alphabet)**len(free)}
def configurations():
 for a,alphabet in enumerate(ALPHABETS):
  for width in range(3,13):
   for period in range(1,9):yield {'id':f'B:{a}:{width}:{period}','alphabet':alphabet,'width':width,'period':period}
def solve(case):
 out=[]
 for c in configurations():
  fit=cylinder(case['ciphertext'],case['cribs'],c['alphabet'],c['width'],c['period'])
  if fit is not None:out.append({'id':c['id'],**fit})
 return out
if __name__=='__main__':
 cases=json.load(open(sys.argv[1]))
 with open(sys.argv[2],'w') as f:
  for case in cases:f.write(json.dumps({'id':case['id'],'complete':True,'structural_cases_examined':160,'cylinders':solve(case)},sort_keys=True)+'\n')
