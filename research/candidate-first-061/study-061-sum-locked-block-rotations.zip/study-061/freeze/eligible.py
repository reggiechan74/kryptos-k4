"""Eligibility restriction: do not recount the previously excluded zero-key subdomain.
The generic benchmark deliberately validates the full mathematical model.
Target adapter requires all key residues observed, so only singleton cylinders occur.
"""
def restrict(case,hits):
 positions=[int(i) for i in case['cribs']]
 assert all({i%p for i in positions}==set(range(p)) for p in range(1,9))
 out=[];excluded=[]
 for hit in hits:
  assert hit['free_residues']==0 and hit['key_count']==1
  if any(hit['key_residues']):out.append(hit)
  else:excluded.append(hit)
 return out,excluded
