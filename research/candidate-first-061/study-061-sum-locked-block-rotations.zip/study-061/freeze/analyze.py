import json,pathlib,sys,time
import production

def analyze(root):
 started=time.process_time();configs={x['id']:x for x in production.configurations()}
 inputs=json.loads((root/'inputs.json').read_text());answers={x['id']:x for x in json.loads((root/'answers.json').read_text())}
 first=[json.loads(x) for x in (root/'production.jsonl').read_text().splitlines()];second=[json.loads(x) for x in (root/'reference.jsonl').read_text().splitlines()]
 assert len(inputs)==len(first)==len(second)==416
 assert first==second
 plants=0;sparse=0;nullfits=0;roundtrips=0;full_unique=0;full_ambiguous=0;free_cylinders=0;max_free=0
 for case,result in zip(inputs,first):
  assert case['id']==result['id'] and result['complete'] and result['structural_cases_examined']==160
  answer=answers[case['id']];hits=result['cylinders'];plains=set();contains_free=False
  for hit in hits:
   cfg=configs[hit['id']];digits=hit['key_residues'];free=[i for i,v in enumerate(digits) if v is None]
   assert hit['free_residues']==len(free) and hit['key_count']==26**len(free)
   max_free=max(max_free,len(free));free_cylinders+=bool(free);contains_free|=bool(free)
   representative=[0 if k is None else k for k in digits]
   probes=[representative]
   for pos in free:
    for value in range(1,26):
     k=representative.copy();k[pos]=value;probes.append(k)
   for key in probes:
    plain=production.decrypt(case['ciphertext'],cfg['alphabet'],cfg['width'],key)
    assert all(plain[int(i)]==v for i,v in case['cribs'].items())
    assert production.encrypt(plain,cfg['alphabet'],cfg['width'],key)==case['ciphertext'];roundtrips+=1
    if not free:plains.add(plain)
  if answer['kind'].startswith('null'):
   nullfits+=bool(hits);continue
  plants+=1;matching=[h for h in hits if h['id']==answer['config']];assert len(matching)==1;h=matching[0]
  assert all(v is None or v==answer['key'][i] for i,v in enumerate(h['key_residues']))
  cfg=configs[answer['config']]
  assert production.decrypt(case['ciphertext'],cfg['alphabet'],cfg['width'],answer['key'])==answer['plaintext']
  if answer['kind']=='sparse':assert h['free_residues']==7;sparse+=1
  else:
   assert not contains_free and answer['plaintext'] in plains
   if len(plains)==1:full_unique+=1
   else:full_ambiguous+=1
 assert plants==352 and sparse==32 and full_unique+full_ambiguous==320
 assert nullfits<=1
 return {'status':'PASS','complete_set_agreement_cases':416,'plants_included':plants,'sparse_plants_seven_free':sparse,'fullmask_unique_plaintext':full_unique,'fullmask_ambiguous_plaintexts':full_ambiguous,'null_any_fits':nullfits,'null_count':64,'returned_free_cylinders':free_cylinders,'max_free_residues':max_free,'checked_roundtrips':roundtrips,'roundtrip_note':'Full candidates and every one-coordinate alternate of canonical free completion; cylinder completeness separately justified by exact equations and tiny exhaustive oracle. Union counts for ambiguous cylinders not asserted.','cpu_seconds':time.process_time()-started}
if __name__=='__main__':
 root=pathlib.Path(sys.argv[1]);result=analyze(root);(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
