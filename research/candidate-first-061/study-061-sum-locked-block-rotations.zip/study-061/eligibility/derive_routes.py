"""Target-permutation audit only: never loads clues or solves key constraints."""
import pathlib,json,hashlib,gzip,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCES=ROOT/'eligibility/local-sources'
A={'AZ':'ABCDEFGHIJKLMNOPQRSTUVWXYZ','KR':'KRYPTOSABCDEFGHIJLMNQUVWXZ'}
C=json.loads((SOURCES/'k4.json').read_text())['ciphertext']
assert len(C)==97
out=[]
for label,alphabet in A.items():
 for width in range(3,13):
  p=[];rot=[]
  for start in range(0,len(C),width):
   block=C[start:start+width];length=len(block);r=sum(alphabet.index(x) for x in block)%length;rot.append(r)
   p.extend(start+(j-r)%length for j in range(length))
  assert sorted(p)==list(range(97))
  out.append({'alphabet':label,'width':width,'output_to_input':p,'right_rotations':rot,'key_periods':list(range(1,9)),'key_domain':'all Z26^p; input position phase 0; additive before permutation'})
(ROOT/'eligibility/target-routes.json').write_text(json.dumps({'ciphertext_sha256':hashlib.sha256(C.encode()).hexdigest(),'crib_constraints_evaluated':False,'routes':out},indent=2)+'\n')

def inv(p):
 q=[0]*len(p)
 for i,x in enumerate(p):q[x]=i
 return tuple(q)
checks=[];column_positive_checks=0
for name in ['ROUTE-001.json.gz','ENE-ROUTE-049-CATALOGUE.json.gz','HAND-GRAMMAR-050-CATALOGUE.json.gz']:
 raw=(SOURCES/name).read_bytes();d=json.loads(gzip.decompress(raw));cat=d['route_catalogue'] if isinstance(d,dict) else d
 routes={tuple(e['permutation']) if 'permutation' in e else tuple(bytes.fromhex(e['signature_hex'])[:97]) for e in cat}
 # Include inverses conservatively, even when not in original source domain.
 routes|={inv(p) for p in routes}
 hits=[{'alphabet':x['alphabet'],'width':x['width']} for x in out if tuple(x['output_to_input']) in routes]
 checks.append({'source':name,'source_sha256':hashlib.sha256(raw).hexdigest(),'distinct_routes_with_inverse_superset':len(routes),'matches':hits})
# All ragged column permutations can be recognized by contiguous column chunks;
# avoids enumerating factorial orders, exactly checks every possible order.
for width in range(2,98):
 columns=[tuple(range(c,97,width)) for c in range(width)]
 def member(p):
  unused=set(range(width));at=0
  while at<97:
   possible=[c for c in unused if p[at:at+len(columns[c])]==columns[c]]
   if len(possible)!=1:return False
   c=possible[0];unused.remove(c);at+=len(columns[c])
  return not unused
 for order in [list(range(width)),list(reversed(range(width)))]:
  planted=tuple(i for col in order for i in columns[col]);assert member(planted);column_positive_checks+=1
 hits=[{'alphabet':x['alphabet'],'width':x['width'],'direction':direction} for x in out for direction,p in [('forward',tuple(x['output_to_input'])),('inverse',inv(x['output_to_input']))] if member(p)]
 if hits:checks.append({'source':'ragged-columnar-superset','column_width':width,'matches':hits})
# Reimplemented route-only functions from pinned local source, not crib scorers.
mask=[(0,c) for c in range(27,31)]+[(r,c) for r in range(1,4) for c in range(31)]
lookup={cell:i for i,cell in enumerate(mask)}
occupied=[tuple(lookup[r,c] for c in list(range(31))[::h] for r in list(range(4))[::v] if (r,c) in lookup) for h in (1,-1) for v in (1,-1)]
def up(w):return [r*w+c for c in range(w) for r in reversed(range((97+w-1)//w)) if r*w+c<97]
a,b=up(42),up(14)
for name,routes in [('occupied-cell',occupied),('k3-clock',[tuple(a[i] for i in b)])]:
 routes=set(routes)|{inv(p) for p in routes}
 checks.append({'source':name,'distinct_routes_with_inverse_superset':len(routes),'matches':[{'alphabet':x['alphabet'],'width':x['width']} for x in out if tuple(x['output_to_input']) in routes]})
(ROOT/'eligibility/local-route-comparison.json').write_text(json.dumps({'scope':'Permutation nonmembership is sufficient regardless of key domain; no target key constraints used. Ragged columns checked at every width2..97 both directions, stronger than completed local widths6..9. Other catalogs retain exact source hashes.','column_membership_positive_controls':column_positive_checks,'checks':checks},indent=2)+'\n')
print(json.dumps(checks,indent=2))
