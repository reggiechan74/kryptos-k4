// Necessary-condition superset: any three missing output cells, not merely valid orbit blanks.
// Fill holes row-major each turn, read columns; within each turn row-major cell IDs increase.
#include <array>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc,char**argv){vector<array<int,97>> maps;array<int,97>q;ifstream in(argc>1?argv[1]:"/workspace/shared/k4-route-source-audit/maps.txt");while(in>>q[0]){for(int i=1;i<97;i++)in>>q[i];array<int,97>m;for(int i=0;i<97;i++)m[q[i]]=i;maps.push_back(m);maps.push_back(q);}long long tests=0;int hits=0;for(int a=0;a<98;a++)for(int b=a+1;b<99;b++)for(int c=b+1;c<100;c++){int cell[97],j=0;for(int i=0;i<100;i++)if(i!=a&&i!=b&&i!=c)cell[j++]=(i%10)*10+i/10;for(int t=0;t<(int)maps.size();t++)for(int pad=0;pad<2;pad++){tests++;bool ok=true;int start=0;for(int group=0;group<4&&ok;group++){int len=((pad==0&&group==3)||(pad==1&&group==0))?22:25;for(int k=start+1;k<start+len;k++)if(cell[maps[t][k-1]]>=cell[maps[t][k]]){ok=false;break;}start+=len;}if(ok){hits++;cout<<"SURVIVOR map="<<t<<" pads="<<pad<<" missing="<<a<<","<<b<<","<<c<<"\n";}}}cout<<"superset_cases "<<tests<<" survivors "<<hits<<"\n";}
