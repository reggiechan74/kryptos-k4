import json,subprocess,itertools,random
from pathlib import Path
r=Path('/workspace/shared/k4-route-source-audit')
def rotate(x):a,b=divmod(x,10);return b*10+9-a
seen=set();orbits=[]
for i in range(100):
 if i not in seen:
  orbit=[i]
  for _ in range(3):orbit.append(rotate(orbit[-1]))
  seen.update(orbit);orbits.append(orbit)
rng=random.Random(6100);maps=[]
for sample in range(4):
 holes=[o[rng.randrange(4)] for o in orbits]
 for direction in [1,-1]:
  full=[];cur=holes[:]
  for _ in range(4):
   full+=sorted(cur)
   for _ in range(direction%4):cur=[rotate(x) for x in cur]
  for pad in [0,1]:
   fill=full[:97] if not pad else full[3:];pos={cell:i for i,cell in enumerate(fill)}
   read=sorted(pos,key=lambda x:(x%10,x//10));maps.append(tuple(pos[cell] for cell in read))
(r/'grille-control-maps.txt').write_text('\n'.join(' '.join(map(str,m)) for m in maps)+'\n')
res=subprocess.check_output([str(r/'column_grille'),str(r/'grille-control-maps.txt')],text=True)
(r/'column-grille-controls.txt').write_text(res)
found=set(int(line.split('map=')[1].split()[0])//2 for line in res.splitlines() if line.startswith('SURVIVOR'))
assert found==set(range(len(maps))),found
# Independent positive interrupted-grid map construction, all gap modes and representative orders.
Dmaps=[]
for w in [5,7,10]:
 for gap in [0,1]:
  order=list(range(w));rng.shuffle(order);rows=(97+w-1)//w;blocked=set();row=0
  for col in order:
   if row>=rows:break
   for delta in range(w-col):
    for x in range(col+delta,w):blocked.add((row+delta,x))
   row+=w-col+gap
  cells=[divmod(i,w) for i in range(97)];fill=[c for c in cells if c not in blocked]+[c for c in cells if c in blocked];pos={c:i for i,c in enumerate(fill)}
  Dmaps.append(tuple(pos[(row,c)] for c in order for row in range(rows) if row*w+c<97))
(r/'disrupted-control-maps.txt').write_text('\n'.join(' '.join(map(str,m)) for m in Dmaps)+'\n')
res=subprocess.check_output([str(r/'disrupted'),str(r/'disrupted-control-maps.txt')],text=True);(r/'disrupted-controls.txt').write_text(res)
found=set(int(line.split()[1]) for line in res.splitlines() if line.startswith('MATCH'));assert found==set(range(6))
(r/'membership-validation.json').write_text(json.dumps({'grille_positive_maps':len(maps),'grille_positive_maps_recognized':len(maps),'disrupted_positive_maps':6,'disrupted_recognized':6,'no_ciphertext_or_crib_values_used':True},indent=2)+'\n')
print('PASS 16 grille, 6 disrupted positive controls')
