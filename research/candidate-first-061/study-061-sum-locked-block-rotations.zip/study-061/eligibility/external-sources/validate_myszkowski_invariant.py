"""Check the necessary column/rank-group invariant on complete tiny weak-order domains."""
import itertools,json,time,resource
from pathlib import Path
t0=time.process_time();cases=0
for n in range(2,9):
 for w in range(2,min(n,5)+1):
  for ranks in itertools.product(range(w),repeat=w):
   # Repeated rank labels/unused levels intentionally retained; this contains every weak order.
   p=sorted(range(n),key=lambda i:(ranks[i%w],i));pos=[0]*n
   for j,i in enumerate(p):pos[i]=j
   desc=[j for j in range(n-1) if p[j]>p[j+1]]
   rejected=any(any(min(pos[i] for i in range(c,n,w))<=j<max(pos[i] for i in range(c,n,w)) for j in desc) for c in range(w))
   assert not rejected,(n,w,ranks,p)
   cases+=1
out={'cases':cases,'result':'PASS: no valid weak-order output rejected','cpu_seconds':time.process_time()-t0,'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'target_data_read':False};Path('/workspace/shared/k4-route-source-audit/myszkowski-invariant-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
