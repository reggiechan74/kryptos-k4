# Independent prefreeze review

Production was first inspected after independent reference and exhaustive forward-oracle controls were written and passed. Production uses slice rotations; reference uses index scatter/gather. No discrepancy or necessary model/protocol correction was identified.

## Mathematical completeness

For a block of actual length l, let T(x) rotate x right by s(x)=sum(integer ranks x) mod l. Since every rotation preserves the integer sum, s(T(x))=s(x). Therefore rotating the observed block left by its observed sum is an inverse for every block. This includes l=1 and all ragged lengths. Addition modulo alphabet size by the original-position periodic key is independently bijective. Given ciphertext, the inverse block ranks do not depend on the key. Each known plaintext position imposes precisely one key-residue equation modulo alphabet size. Conflicting equations give an empty set; otherwise unconstrained residues vary independently, yielding exactly n^free keys. This is a proof of represented cylinder completeness, not a sampling inference.

## Protocol and generator

416 fixtures: 320 complete-mask plants spanning all 160 structural descriptions in each uniform/literal category; 32 deliberately ambiguous period-eight plants; 64 independent full-mask nulls. No outcome filtering or regeneration. Sparse positions 0,8,16,24 constrain exactly one residue under the planted period-eight setting and hence leave seven free. Full public mask covers all residues for periods1–8. Nominal-period aliases are explicitly permitted, and no sum of overlapping cylinder cardinalities is presented as a union count. False-fit gate applies to any full-mask compatible setting per null fixture. Literal fixtures do not test English recovery.

Representative plus all single-coordinate alternatives are useful roundtrip controls, not claimed exhaustive checks of huge cylinders. The proof above and exhaustive tiny forward truth supply completeness. Frozen code, fixtures and output seals must be independently checked after benchmark. Eligibility remains a separate required gate; this review does not authorize target solving.
