import sys,json,hashlib,random,time,resource,datetime,collections
from pathlib import Path
base=Path(__file__).resolve().parents[2];sys.path.insert(0,str(base/'audit'));import reference as r
t=time.process_time()
def read(p):return json.loads((base/p).read_text())
def sha(p):return hashlib.sha256((base/p).read_bytes()).hexdigest()
assert sha('freeze/manifest.json')=='05be2644387a92cb3610123d566dc325f9526a164701a36ee05d6924e7bdc719'
assert sha('benchmark/seal.json')=='0b5dc00619be43349f6f3ac074fc66a260491b24d2e3872b79a1b899dbb5d515'
manifest=read('freeze/manifest.json');seal=read('benchmark/seal.json')
for prefix,doc in [('',manifest),('benchmark/',seal)]:
 for path,record in doc['files'].items():assert sha(prefix+path)==record['sha256'] and (base/(prefix+path)).stat().st_size==record['bytes']
assert seal['outputs_sealed_before_answers_inspected'] and manifest['created_utc']<seal['created_utc']
cases=read('benchmark/inputs.json');answers=read('benchmark/answers.json')
outputs=[[json.loads(s) for s in (base/f'benchmark/{engine}.jsonl').read_text().splitlines()] for engine in ['production','reference']]
assert outputs[0]==outputs[1] and len(cases)==len(answers)==len(outputs[0])==416
rng=random.Random(int((base/'benchmark/seed.txt').read_text(),16));pairs=[];mask=[*range(21,34),*range(63,74)];literal='EASTNORTHEASTBERLINCLOCK'
def text():return ''.join(rng.choice(r.AZ) for _ in range(97))
configs=list(r.configurations());lookup={x['id']:x for x in configs}
settings=[(c,kind,mask) for c in configs for kind in ('uniform','literal')]
settings += [(dict(id=f'B:{a}:{3+k%10}:8',alphabet=A,width=3+k%10,period=8),'sparse',[0,8,16,24]) for a,A in enumerate((r.AZ,r.KR)) for k in range(16)]
for cfg,kind,positions in settings:
 p=list(text())
 if kind=='literal':
  for i,c in zip(positions,literal):p[i]=c
 p=''.join(p);key=[rng.randrange(26) for _ in range(cfg['period'])]
 pairs.append((dict(ciphertext=r.encrypt(p,cfg['alphabet'],cfg['width'],key),cribs={str(i):p[i] for i in positions}),dict(kind=kind,config=cfg['id'],key=key,plaintext=p)))
for i in range(64):
 values=literal if i>=32 else ''.join(rng.choice(r.AZ) for _ in mask)
 pairs.append((dict(ciphertext=text(),cribs=dict(zip(map(str,mask),values))),dict(kind='null_literal' if i>=32 else 'null_uniform')))
rng.shuffle(pairs)
assert cases==[dict(id=f'case-{i:04d}',**x) for i,(x,y) in enumerate(pairs)]
assert answers==[dict(id=f'case-{i:04d}',**y) for i,(x,y) in enumerate(pairs)]
counts=collections.Counter();strata=collections.Counter();plantcells=collections.Counter()
for case,answer,out in zip(cases,answers,outputs[0]):
 assert case['id']==answer['id']==out['id'] and out['complete'] and out['structural_cases_examined']==160
 hits=r.solve(case);assert hits==out['cylinders'];counts['complete_sets']+=1
 fullplaintexts=set()
 for hit in hits:
  cfg=lookup[hit['id']];digits=hit['key_residues'];free=[i for i,v in enumerate(digits) if v is None]
  assert hit['free_residues']==len(free) and hit['key_count']==26**len(free)
  counts['free_cylinders']+=bool(free)
  representative=[0 if v is None else v for v in digits];probes=[representative]
  for i in free:
   for v in range(1,26):
    k=representative.copy();k[i]=v;probes.append(k)
  for k in probes:
   p=r.decrypt(case['ciphertext'],cfg['alphabet'],cfg['width'],k)
   assert all(p[int(i)]==v for i,v in case['cribs'].items())
   assert r.encrypt(p,cfg['alphabet'],cfg['width'],k)==case['ciphertext'];counts['roundtrips']+=1
   if not free:fullplaintexts.add(p)
 if answer['kind'].startswith('null'):
  counts['nulls']+=1;counts['null_fits']+=bool(hits)
 else:
  counts['plants']+=1;plantcells[(answer['config'],answer['kind'])]+=1
  hit=next(x for x in hits if x['id']==answer['config'])
  assert all(v is None or v==answer['key'][i] for i,v in enumerate(hit['key_residues']))
  cfg=lookup[answer['config']];assert r.decrypt(case['ciphertext'],cfg['alphabet'],cfg['width'],answer['key'])==answer['plaintext']
  if answer['kind']=='sparse':assert hit['free_residues']==7;counts['sparse_seven_free']+=1
  else:assert answer['plaintext'] in fullplaintexts;counts['full_unique']+=len(fullplaintexts)==1
assert counts['plants']==352 and counts['sparse_seven_free']==32 and counts['nulls']==64 and counts['null_fits']<=1
assert all(plantcells[(c['id'],kind)]==1 for c in configs for kind in ('uniform','literal'))
resources=[read(f'benchmark/{engine}-resource.json') for engine in ['production','reference']]
for rec in resources:
 assert rec['status']=='completed' and rec['returncode']==0 and rec['stderr']==''
 assert rec['child_cpu_seconds']<rec['cpu_limit_seconds']==120 and rec['wall_seconds']<rec['wall_limit_seconds']==300
 assert rec['child_max_rss_kib']*1024<rec['as_limit_bytes']==536870912
receipt=dict(status='PASS_FOR_PARENT_TARGET_REVIEW',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),freeze_sha256=sha('freeze/manifest.json'),seal_sha256=sha('benchmark/seal.json'),frozen_files_verified=len(manifest['files']),fixture_replay_exact=True,counts=dict(counts),benchmark_cpu_seconds=sum(x['child_cpu_seconds']+x['parent_cpu_seconds'] for x in resources),audit_cpu_seconds=time.process_time()-t,audit_max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False,target_authorized=False,limitation='Single-coordinate free-key probes are controls, not exhaustive cylinder enumeration; completeness follows from residue equations and tiny forward truth. No union count across overlapping cylinders.')
(base/'audit/postbenchmark/FINAL-AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
