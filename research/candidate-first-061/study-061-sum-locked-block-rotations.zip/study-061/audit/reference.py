"""Independent study061 reference; written from frozen proposal before production inspection.
Cribs map zero-based plaintext positions to letters. Keys are rank integers.
A cylinder has exactly alphabet_size**free_residues keys; no completion is chosen.
"""
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'

def encrypt(plaintext, alphabet, width, key):
    n=len(alphabet)
    ranks=[(alphabet.index(c)+key[i%len(key)])%n for i,c in enumerate(plaintext)]
    out=[]
    for start in range(0,len(ranks),width):
        block=ranks[start:start+width];length=len(block);shift=sum(block)%length
        # Independent scatter representation of right rotation.
        rotated=[None]*length
        for j,value in enumerate(block):rotated[(j+shift)%length]=value
        out.extend(rotated)
    return ''.join(alphabet[v] for v in out)

def inverse_ranks(ciphertext, alphabet, width):
    out=[]
    for start in range(0,len(ciphertext),width):
        values=[alphabet.index(c) for c in ciphertext[start:start+width]]
        shift=sum(values)%len(values)
        out.extend(values[(j+shift)%len(values)] for j in range(len(values)))
    return out

def decrypt(ciphertext, alphabet, width, key):
    return ''.join(alphabet[(v-key[i%len(key)])%len(alphabet)] for i,v in enumerate(inverse_ranks(ciphertext,alphabet,width)))

def cylinder(ciphertext, cribs, alphabet, width, period):
    ranks=inverse_ranks(ciphertext,alphabet,width)
    requirements={}
    for pos,letter in cribs.items():
        pos=int(pos);residue=pos%period
        value=(ranks[pos]-alphabet.index(letter))%len(alphabet)
        if residue in requirements and requirements[residue]!=value:return None
        requirements[residue]=value
    digits=[requirements.get(i) for i in range(period)]
    free=digits.count(None)
    return {'key_residues':digits,'free_residues':free,'key_count':len(alphabet)**free}

def configurations(alphabets=(AZ,KR), widths=range(3,13), periods=range(1,9)):
    for a,alphabet in enumerate(alphabets):
        for width in widths:
            for period in periods:
                yield {'id':f'B:{a}:{width}:{period}','alphabet':alphabet,'width':width,'period':period}

def solve(case,alphabets=(AZ,KR),widths=range(3,13),periods=range(1,9)):
    result=[]
    for cfg in configurations(alphabets,widths,periods):
        hit=cylinder(case['ciphertext'],case['cribs'],cfg['alphabet'],cfg['width'],cfg['period'])
        if hit is not None:result.append({'id':cfg['id'],**hit})
    return result
