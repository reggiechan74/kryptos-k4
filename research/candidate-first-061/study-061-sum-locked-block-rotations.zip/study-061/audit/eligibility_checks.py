import sys,json,subprocess,tempfile,time,hashlib
from pathlib import Path
base=Path(__file__).resolve().parents[1];sys.path.insert(0,str(base/'freeze'))
import eligible,reference
start=time.process_time();mask=list(range(21,34))+list(range(63,74));case={'id':'synthetic-eligibility','ciphertext':'A'*97,'cribs':{str(i):'A' for i in mask}};n=0
for period in range(1,9):
 for key in [[0]*period]+[[v]*period for v in range(1,26)]+[[v if i==j else 0 for i in range(period)] for j in range(period) for v in range(1,26)]:
  hit={'id':f'B:0:3:{period}','key_residues':key,'free_residues':0,'key_count':1}
  kept,excluded=eligible.restrict(case,[hit]);assert (kept,excluded)==(([hit],[]) if any(key) else ([],[hit]));n+=1
for invalid in [{'cribs':{'0':'A'}},case]:
 try:
  eligible.restrict(invalid,[{'key_residues':[None]*8,'free_residues':8,'key_count':26**8}])
 except AssertionError:pass
 else:raise AssertionError('invalid free/missing mask accepted')
with tempfile.TemporaryDirectory() as tmp:
 inp=Path(tmp)/'input.json';inp.write_text(json.dumps([case]));expected,excluded=eligible.restrict(case,reference.solve(case));outputs=[]
 for engine in ['production','reference']:
  out=Path(tmp)/(engine+'.jsonl');subprocess.run([sys.executable,str(base/'freeze'/f'target_{engine}.py'),str(inp),str(out)],check=True,cwd=base/'freeze');result=json.loads(out.read_text());assert result['cylinders']==expected and result['prior_covered_zero_key_candidates_not_counted']==excluded;outputs.append(result)
 assert outputs[0]==outputs[1]
receipt={'status':'PASS','singleton_filter_cases':n,'periods_checked':8,'nonzero_constant_and_coordinate_keys_retained':True,'all_zero_singletons_excluded':True,'free_or_missing_mask_rejected':True,'wrapper_outputs_agree_on_synthetic_case':True,'target_constraints_evaluated':False,'audit_cpu_seconds':time.process_time()-start}
(base/'audit/eligibility-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
