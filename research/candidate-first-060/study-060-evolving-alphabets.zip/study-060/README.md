# Study 060 Evolving alphabet mechanisms

**Result: exact bounded exclusion.** Both independently implemented target evaluations returned zero compatible descriptions or plaintexts. The 208 distinct functions consist of 104 ciphertext-driven alphabet-exchange settings and 104 fixed-reference prefix-reversal settings. This does not exclude arbitrary evolving alphabets, other starting alphabets or different state-update rules.

The two proposals were deliberately small and mechanically distinct from the inspected move-to-front, tree-path, CONDI and Chaocipher implementations. No matching exact K4 test was found in the reviewed public work; this is not a worldwide novelty claim or evidence that Sanborn used either system. Related stateful cipher traditions are acknowledged in the source proposal.

## Evidence

- `freeze/protocol.md`: exact rules, finite bounds, predeclared gates and resources.
- `freeze/manifest.json`: 26-file pre-benchmark freeze.
- `audit/PREFLIGHT-AUDIT.json`: tiny exhaustive correctness and pairwise operator separation.
- `benchmark/`: all480 inputs, hidden-answer material, seed, sealed full outputs and receipts.
- `audit/postbenchmark/FINAL-AUDIT.json`: independently replayed fixtures and complete result sets.
- `target/`: canonical input/source, parent stage approval, additive transport freeze, two original outputs and resources.
- `audit/target/FINAL-AUDIT.json`: final independent target audit.
- `METHOD-LEARNING.md`: reusable validation capability and explicit absence of an optimization bottleneck.
- `resource-ledger.json`: conservative CPU charges, including original audits and preparation reserve.

## Numerical summary

Preflight checked 5,832 tiny forward/inverse cases and 6,561 complete ciphertext/crib solution sets. All 208 full-alphabet first-step maps were bijections. Every one of 21,528 pairs of configurations has a short separating plaintext, independently replayed in production, proving 208 distinct encryption functions.

The blind benchmark contained 416 plants (uniform and literal-clue random texts for every configuration) and 64 random-ciphertext controls. Both implementations completed and agreed on all 480 full sets. Every plant was included and uniquely identified; no random control fit. This is an implementation/recovery benchmark, not a natural-English evaluation or posterior probability of a historical cipher choice.

The target used the canonical 97 letters and 24 fixed clue positions, continuously from message start. Both engines exhausted all 208 settings and returned zero. No rule, gate, alphabet or offset range was enlarged after this outcome.

## Reproduction

Python 3.12 and the standard library suffice. Work from the extracted study directory. To preserve original receipts, write new outputs to a separate reproduction directory rather than overwrite archive files.

- Development: run `python audit/tiny_reference_checks.py` and `python audit/production_comparison.py` in a copied directory if reproducing those receipts.
- Production benchmark: `python freeze/production.py benchmark/inputs.json reproduction/production.jsonl`.
- Independent benchmark: `python freeze/reference_adapter.py benchmark/inputs.json reproduction/reference.jsonl`.
- Target reproduction, only when deliberately requested: pass `target/input.json` to either of those engines with a new output filename. This archive records exactly one original production and one original reference target evaluation.

Publication and subsequent queue decisions are recorded in the repository's canonical ledgers, not inferred from this directory's timestamps. No live Site changes or paid submissions were made.
