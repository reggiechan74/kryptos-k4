import json,sys
import reference
cases=json.load(open(sys.argv[1]))
with open(sys.argv[2],'w') as out:
    for case in cases:
        matches=reference.solve(case['ciphertext'],{int(i):v for i,v in case['cribs'].items()})
        result={'id':case['id'],'complete':True,'descriptions_examined':208,'matches':matches,'plaintexts':sorted({m['plaintext'] for m in matches})}
        out.write(json.dumps(result,sort_keys=True)+'\n');out.flush()
