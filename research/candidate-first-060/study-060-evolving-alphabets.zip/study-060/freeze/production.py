import itertools, json, sys
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'

def crypt(text, family, R, initial, parameter, decrypt=False):
    state=list(initial); n=len(R); ri={c:i for i,c in enumerate(R)}; q=parameter; out=[]
    for symbol in text:
        if decrypt:
            j=state.index(symbol)
            plain=R[j if family=='exchange' else (j-parameter)%n]
            cipher=symbol
            out.append(plain)
        else:
            j=(ri[symbol] + (parameter if family=='prefix' else 0))%n
            cipher=state[j]
            out.append(cipher)
        if family=='exchange':
            state[j],state[q]=state[q],state[j]
            q=(q+ri[cipher]+1)%n
        elif family=='prefix':
            size=ri[cipher]+1
            state[:size]=state[:size][::-1]
        else: raise ValueError(family)
    return ''.join(out)

def configurations(alphabets=(AZ,KR)):
    for f in ('exchange','prefix'):
        for r,R in enumerate(alphabets):
            for s,S in enumerate(alphabets):
                for k in range(len(R)):
                    yield {'id':f"{'A' if f=='exchange' else 'B'}:{r}:{s}:{k}", 'family':f,'reference':R,'initial':S,'parameter':k}

def solve(case, alphabets=(AZ,KR)):
    hits=[]
    for config in configurations(alphabets):
        p=crypt(case['ciphertext'], config['family'],config['reference'],config['initial'],config['parameter'],True)
        if all(p[int(i)]==c for i,c in case['cribs'].items()):
            hits.append({'id':config['id'],'plaintext':p})
    return {'id':case['id'],'complete':True,'descriptions_examined':len(list(configurations(alphabets))), 'matches':sorted(hits,key=lambda x:x['id']), 'plaintexts':sorted({h['plaintext'] for h in hits})}

if __name__=='__main__':
    cases=json.load(open(sys.argv[1]))
    with open(sys.argv[2],'w') as out:
        for case in cases:
            out.write(json.dumps(solve(case),sort_keys=True)+'\n'); out.flush()
