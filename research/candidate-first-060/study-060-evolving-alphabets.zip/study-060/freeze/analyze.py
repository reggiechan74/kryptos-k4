import json,sys,time
from pathlib import Path

def readl(p):return [json.loads(x) for x in Path(p).read_text().splitlines()]
if __name__=='__main__':
    inputs,answers,prod,ref,output=sys.argv[1:];start=time.process_time()
    I=json.load(open(inputs));A={x['id']:x for x in json.load(open(answers))};P=readl(prod);R=readl(ref)
    assert len(I)==len(A)==len(P)==len(R)==480
    assert [x['id'] for x in P]==[x['id'] for x in R]==[x['id'] for x in I]
    assert P==R
    counts={'complete':0,'exact_agreement':0,'plants':0,'plants_included':0,'random_controls':0,'random_fits':0};strata={}
    for p in P:
        assert p['complete'] and p['descriptions_examined']==208
        assert p['plaintexts']==sorted({x['plaintext'] for x in p['matches']})
        counts['complete']+=1;counts['exact_agreement']+=1
        a=A[p['id']];cat=a['category'];st=strata.setdefault(cat,{'total':0,'empty':0,'unique':0,'multiple':0});st['total']+=1;st['empty' if not p['plaintexts'] else 'unique' if len(p['plaintexts'])==1 else 'multiple']+=1
        if cat=='random-control':
            counts['random_controls']+=1;counts['random_fits']+=bool(p['plaintexts'])
        else:
            counts['plants']+=1
            assert {'id':a['configuration']['id'],'plaintext':a['plaintext']} in p['matches']
            counts['plants_included']+=1
    passed=counts['plants_included']==416 and counts['random_fits']<=1
    result={'status':'PASS_NUMERICAL_GATES' if passed else 'FAIL_NUMERICAL_GATES','counts':counts,'descriptive_strata':strata,'analysis_cpu_seconds':time.process_time()-start,'target_run':False}
    Path(output).write_text(json.dumps(result,indent=2));print(json.dumps(result))
