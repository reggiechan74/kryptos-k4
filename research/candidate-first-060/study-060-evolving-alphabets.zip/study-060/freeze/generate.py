import hashlib,json,random,sys
from production import configurations,crypt,AZ
MASK=list(range(21,34))+list(range(63,74))
CLUES={**dict(zip(range(21,34),'EASTNORTHEAST')),**dict(zip(range(63,74),'BERLINCLOCK'))}
assert len(CLUES)==24

def generate(seed):
    rng=random.Random(int(seed,16)); pairs=[]
    for conf in configurations():
        for mode in ('uniform','literal'):
            p=[rng.choice(AZ) for _ in range(97)]
            if mode=='literal':
                for i,c in CLUES.items():p[i]=c
            p=''.join(p)
            c=crypt(p,conf['family'],conf['reference'],conf['initial'],conf['parameter'])
            inp={'ciphertext':c,'cribs':{str(i):p[i] for i in MASK}}
            ans={'category':mode,'configuration':conf,'plaintext':p}
            pairs.append((inp,ans))
    for j in range(64):
        c=''.join(rng.choice(AZ) for _ in range(97))
        crib={str(i):(CLUES[i] if j>=32 else rng.choice(AZ)) for i in MASK}
        pairs.append(({'ciphertext':c,'cribs':crib},{'category':'random-control','literal_crib':j>=32}))
    rng.shuffle(pairs)
    inputs=[]; answers=[]
    for j,(inp,ans) in enumerate(pairs):
        ident=f'060-B{j:04d}';inputs.append({'id':ident,**inp});answers.append({'id':ident,**ans})
    return inputs,answers
if __name__=='__main__':
    seed=open(sys.argv[1]).read().strip();i,a=generate(seed)
    json.dump(i,open(sys.argv[2],'w'),sort_keys=True,indent=2)
    json.dump(a,open(sys.argv[3],'w'),sort_keys=True,indent=2)
