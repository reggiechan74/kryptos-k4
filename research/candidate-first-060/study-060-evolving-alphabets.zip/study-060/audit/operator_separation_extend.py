import itertools,json,time,hashlib,resource
from pathlib import Path
import reference as r
p=Path(__file__).parent; start=time.process_time()
base=json.loads((p/'operator-separation-length2.json').read_text()); seps=json.loads((p/'operator-separators.json').read_text()); configs={x['id']:x for x in r.configurations()}; remaining=[]; encryptions=0
for a,b in base['unresolved_pairs']:
    found=False
    for values in itertools.product(r.AZ,repeat=3):
        word=''.join(values); c=configs[a]; d=configs[b]
        x=r.encrypt(word,c['family'],c['reference'],c['initial'],c['parameter']); y=r.encrypt(word,d['family'],d['reference'],d['initial'],d['parameter']);encryptions+=2
        if x!=y:
            seps.append({'a':a,'b':b,'plaintext':word,'a_cipher':x,'b_cipher':y});found=True;break
    if not found: remaining.append([a,b])
(p/'operator-separators-final.json').write_text(json.dumps(seps,separators=(',',':'))+'\n')
result={'status':'ALL_PAIRS_DISTINGUISHED' if not remaining else 'PARTIAL_NON_EQUIVALENCE_CERTIFICATE','raw_configurations':208,'pairs':21528,'separated_pairs':len(seps),'unresolved_pairs':remaining,'max_probe_length':3,'length2_probe_count':676,'extra_encryptions':encryptions,'total_encryptions':base['encryptions']+encryptions,'distinct_operators_certified':208 if not remaining else None,'separator_file_sha256':hashlib.sha256((p/'operator-separators-final.json').read_bytes()).hexdigest(),'cpu_seconds':time.process_time()-start,'prior_cpu_seconds':base['cpu_seconds'],'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'Each listed pair has an explicit plaintext with unequal ciphertext. Unresolved pairs are not claimed equivalent. No target used.'}
(p/'operator-separation-final.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
