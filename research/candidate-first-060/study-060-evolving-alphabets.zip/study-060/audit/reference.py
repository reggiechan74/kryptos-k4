"""Independent literal-symbol reference for study 060, written before production inspection."""
import itertools
AZ = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
KR = 'KRYPTOSABCDEFGHIJLMNQUVWXZ'

def _check(reference, initial, parameter):
    if len(reference)!=len(set(reference)) or sorted(reference)!=sorted(initial):
        raise ValueError('alphabets must be permutations of the same distinct symbols')
    if not 0 <= parameter < len(reference): raise ValueError('parameter outside alphabet')

def configurations(alphabets=(AZ,KR)):
    for family, ri, si in itertools.product(('A','B'),range(len(alphabets)),range(len(alphabets))):
        for parameter in range(len(alphabets[ri])):
            yield {'id':f'{family}:{ri}:{si}:{parameter}', 'family':family,'reference':alphabets[ri], 'initial':alphabets[si], 'parameter':parameter}

def encrypt(text, family, reference, initial, parameter):
    _check(reference, initial, parameter)
    n=len(reference); row={i:c for i,c in enumerate(initial)}; cursor=parameter; result=[]
    for plain in text:
        place=reference.index(plain)
        if family=='B': place=(place+parameter)%n
        elif family!='A': raise ValueError('family')
        cipher=row[place]; result.append(cipher)
        if family=='A':
            old=row[place]; row[place]=row[cursor]; row[cursor]=old
            cursor=(cursor+reference.index(cipher)+1)%n
        else:
            stop=reference.index(cipher)
            previous=row.copy()
            for i in range(stop+1): row[i]=previous[stop-i]
    return ''.join(result)

def decrypt(text, family, reference, initial, parameter):
    _check(reference, initial, parameter)
    n=len(reference); inverse={c:i for i,c in enumerate(initial)}; cursor=parameter; result=[]
    for cipher in text:
        place=inverse[cipher]
        if family=='A':
            result.append(reference[place])
            at_cursor=next(c for c,p in inverse.items() if p==cursor)
            inverse[cipher],inverse[at_cursor]=cursor,place
            cursor=(cursor+reference.index(cipher)+1)%n
        elif family=='B':
            result.append(reference[(place-parameter)%n])
            stop=reference.index(cipher)
            inverse={c:(stop-p if p<=stop else p) for c,p in inverse.items()}
        else: raise ValueError('family')
    return ''.join(result)

def solve(ciphertext, cribs, alphabets=(AZ,KR)):
    answers=[]
    for config in configurations(alphabets):
        plain=decrypt(ciphertext,config['family'],config['reference'],config['initial'],config['parameter'])
        if all(plain[int(i)]==c for i,c in cribs.items()):
            answers.append({'id':config['id'],'plaintext':plain})
    return sorted(answers,key=lambda a:a['id'])
