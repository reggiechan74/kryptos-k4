"""Finite witness certificate of non-equivalence, never equivalence from finite agreement."""
import hashlib,itertools,json,time,resource
from pathlib import Path
import reference as r
start=time.process_time(); configs=list(r.configurations()); words=[''.join(x) for x in itertools.product(r.AZ,repeat=2)]
outputs={c['id']:[r.encrypt(w,c['family'],c['reference'],c['initial'],c['parameter']) for w in words] for c in configs}
separators=[]; unresolved=[]
for i,a in enumerate(configs):
    for b in configs[i+1:]:
        a_id,b_id=a['id'],b['id']; witness=next((j for j,(x,y) in enumerate(zip(outputs[a_id],outputs[b_id])) if x!=y),None)
        if witness is None: unresolved.append([a_id,b_id])
        else: separators.append({'a':a_id,'b':b_id,'plaintext':words[witness],'a_cipher':outputs[a_id][witness],'b_cipher':outputs[b_id][witness]})
p=Path(__file__).parent
(p/'operator-separators.json').write_text(json.dumps(separators,separators=(',',':'))+'\n')
result={'status':'ALL_PAIRS_DISTINGUISHED' if not unresolved else 'PARTIAL_NON_EQUIVALENCE_CERTIFICATE','raw_configurations':len(configs),'pairs':len(configs)*(len(configs)-1)//2,'separated_pairs':len(separators),'unresolved_pairs':unresolved,'probe_length':2,'probe_count':len(words),'encryptions':len(configs)*len(words),'distinct_operators_certified':len(configs) if not unresolved else None,'separator_file_sha256':hashlib.sha256((p/'operator-separators.json').read_bytes()).hexdigest(),'cpu_seconds':time.process_time()-start,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'Each distinct pair is disproved equivalent by explicit plaintext witness. Any unresolved pair is NOT claimed equivalent. No target ciphertext used.'}
(p/'operator-separation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
