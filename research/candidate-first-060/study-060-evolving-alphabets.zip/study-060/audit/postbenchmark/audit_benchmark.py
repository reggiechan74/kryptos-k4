import sys,json,hashlib,time,resource,datetime,random,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'audit'))
import reference as ref
start=time.process_time()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def readj(path):return json.loads(Path(path).read_text())
def readl(path):return [json.loads(x) for x in Path(path).read_text().splitlines()]
manifest=readj(ROOT/'freeze/manifest.json');seal=readj(ROOT/'benchmark/seal.json')
assert sha(ROOT/'freeze/manifest.json')=='6e825558692b49bcb1b41cc11cec86d217e56c174a0c2c28867fe7bf6dbc6439'
assert sha(ROOT/'benchmark/seal.json')=='8ee57cb7ac77c68fb15f2a298caecb7c22c3338d850fbe9937ca1a8bd9beafcb'
for path,info in manifest['files'].items():
    assert sha(ROOT/path)==info['sha256'] and (ROOT/path).stat().st_size==info['bytes'],path
for path,digest in seal['files'].items():assert sha(ROOT/path)==digest,path
assert manifest['created_utc']<seal['created_utc'] and seal['answers_inspected'] is False
I=readj(ROOT/'benchmark/inputs.json');A=readj(ROOT/'benchmark/answers.json');P=readl(ROOT/'benchmark/production.jsonl');R=readl(ROOT/'benchmark/reference.jsonl')
assert len(I)==len(A)==len(P)==len(R)==480 and P==R
assert len({x['id'] for x in I})==480
# Reconstruct all fixtures from the seed using independent reference encryption.
seed=(ROOT/'benchmark/seed.txt').read_text().strip();rng=random.Random(int(seed,16));mask=list(range(21,34))+list(range(63,74));literal=dict(zip(mask,'EASTNORTHEASTBERLINCLOCK')); pairs=[]
for c in ref.configurations():
    for mode in ('uniform','literal'):
        plain=[rng.choice(ref.AZ) for _ in range(97)]
        if mode=='literal':
            for i,ch in literal.items():plain[i]=ch
        plain=''.join(plain);cipher=ref.encrypt(plain,c['family'],c['reference'],c['initial'],c['parameter'])
        conf=dict(c);conf['family']='exchange' if c['family']=='A' else 'prefix'
        pairs.append(({'ciphertext':cipher,'cribs':{str(i):plain[i] for i in mask}},{'category':mode,'configuration':conf,'plaintext':plain}))
for j in range(64):
    cipher=''.join(rng.choice(ref.AZ) for _ in range(97));cribs={str(i):(literal[i] if j>=32 else rng.choice(ref.AZ)) for i in mask}
    pairs.append(({'ciphertext':cipher,'cribs':cribs},{'category':'random-control','literal_crib':j>=32}))
rng.shuffle(pairs)
RI=[{'id':f'060-B{j:04d}',**x} for j,(x,y) in enumerate(pairs)];RA=[{'id':f'060-B{j:04d}',**y} for j,(x,y) in enumerate(pairs)]
assert RI==I and RA==A
configs={c['id']:c for c in ref.configurations()};counts=collections.Counter();strata={};coverage=collections.Counter()
for inp,ans,prod,rout in zip(I,A,P,R):
    assert inp['id']==ans['id']==prod['id']==rout['id']
    assert len(inp['ciphertext'])==97 and set(inp['ciphertext'])<=set(ref.AZ) and sorted(map(int,inp['cribs']))==mask
    expected=ref.solve(inp['ciphertext'],inp['cribs'])
    assert prod['complete'] and prod['descriptions_examined']==208 and prod['matches']==expected
    ps=sorted({x['plaintext'] for x in expected}); assert ps==prod['plaintexts']
    counts['complete_exact_sets']+=1
    for hit in expected:
        c=configs[hit['id']]
        assert ref.encrypt(hit['plaintext'],c['family'],c['reference'],c['initial'],c['parameter'])==inp['ciphertext']
        assert all(hit['plaintext'][int(i)]==v for i,v in inp['cribs'].items())
        counts['independent_reencryptions']+=1
    if ans['category']=='random-control':counts['random_controls']+=1;counts['random_fits']+=bool(ps)
    else:
        counts['plants']+=1;coverage[(ans['configuration']['id'],ans['category'])]+=1
        assert {'id':ans['configuration']['id'],'plaintext':ans['plaintext']} in expected
        counts['plants_included']+=1
    s=strata.setdefault(ans['category'],collections.Counter());s['total']+=1;s['empty' if not ps else 'unique' if len(ps)==1 else 'multiple']+=1
assert len(coverage)==416 and set(coverage.values())=={1} and counts['plants_included']==416 and counts['random_controls']==64 and counts['random_fits']<=1
resources=[]
for name in ('production','reference'):
    r=readj(ROOT/f'benchmark/{name}-resource.json');assert r['status']=='completed' and r['returncode']==0 and r['stderr']==''
    assert r['child_cpu_seconds']<=120 and r['wall_seconds']<=300 and r['child_max_rss_kib']*1024<512*1024**2
    assert (r['child_max_rss_kib']+r['parent_max_rss_kib'])*1024<8*1024**3
    resources.append(r)
report={'status':'PASS_FOR_PARENT_TARGET_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeze_sha256':sha(ROOT/'freeze/manifest.json'),'seal_sha256':sha(ROOT/'benchmark/seal.json'),'frozen_files_verified':len(manifest['files']),'independent_fixture_replay_exact':True,'counts':dict(counts),'descriptive_strata':{k:dict(v) for k,v in strata.items()},'unique_plant_config_category_cells':len(coverage),'benchmark_engine_cpu_seconds':sum(x['child_cpu_seconds']+x['parent_cpu_seconds'] for x in resources),'max_conservative_worker_child_rss_bytes':max((x['child_max_rss_kib']+x['parent_max_rss_kib'])*1024 for x in resources),'audit_cpu_seconds':time.process_time()-start,'audit_max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'target_evaluated':False,'target_authorized':False,'limitations':['Procedural synthetic blinding; historically public clues are known.','Literal-clue plants are random text outside the clues, not natural-language recovery tests.','No matching prior experiment found is a bounded survey conclusion, not global invention.','The two state-update rules and104 parameters each define the complete tested family, not arbitrary evolving alphabets.']}
(ROOT/'audit/postbenchmark/FINAL-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
