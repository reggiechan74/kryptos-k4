"""Independent exhaustive encryption-table oracle and reference decryption checks."""
import itertools,json,time,hashlib,platform,resource
from pathlib import Path
import reference as r
ROOT=Path(__file__).parent
start=time.process_time()
alpha=('ABC','ACB'); configs=list(r.configurations(alpha)); words=[''.join(x) for x in itertools.product('ABC',repeat=5)]
# Oracle constructs forward complete table; never invokes decrypt to generate truth.
table={c:[] for c in words}; encryptions=0; roundtrips=0
for config in configs:
    seen=set()
    for plain in words:
        cipher=r.encrypt(plain,config['family'],config['reference'],config['initial'],config['parameter'])
        assert cipher not in seen
        seen.add(cipher); encryptions+=1
        table[cipher].append({'id':config['id'],'plaintext':plain})
        assert r.decrypt(cipher,config['family'],config['reference'],config['initial'],config['parameter'])==plain
        roundtrips+=1
    assert len(seen)==len(words)
mask=(0,2,4); cases=0; truth_hash=hashlib.sha256(); solution_count=0; projections={'empty':0,'unique':0,'multiple':0}
for cipher in words:
    for values in itertools.product('ABC',repeat=len(mask)):
        cribs=dict(zip(mask,values))
        truth=sorted((row for row in table[cipher] if all(row['plaintext'][i]==v for i,v in cribs.items())),key=lambda x:x['id'])
        got=r.solve(cipher,cribs,alpha)
        assert truth==got
        cases+=1; solution_count+=len(truth)
        count=len({x['plaintext'] for x in truth}); projections['empty' if count==0 else 'unique' if count==1 else 'multiple']+=1
        truth_hash.update(json.dumps([cipher,values,truth],sort_keys=True,separators=(',',':')).encode()+b'\n')
full_bijections=0
for config in r.configurations():
    encrypted=[r.encrypt(ch,config['family'],config['reference'],config['initial'],config['parameter']) for ch in r.AZ]
    assert len(set(encrypted))==26
    for p,c in zip(r.AZ,encrypted): assert r.decrypt(c,config['family'],config['reference'],config['initial'],config['parameter'])==p
    full_bijections+=1
out={'status':'PASS_INDEPENDENT_REFERENCE_PREFLIGHT','tiny_alphabets':alpha,'tiny_length':5,'tiny_configurations':len(configs),'tiny_plaintexts':len(words),'forward_encryptions':encryptions,'roundtrips':roundtrips,'complete_ciphertext_crib_cases':cases,'total_raw_solutions':solution_count,'projection_counts':projections,'truth_digest_sha256':truth_hash.hexdigest(),'full_alphabet_one_step_bijections':full_bijections,'cpu_seconds':time.process_time()-start,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':platform.python_version(),'independence':'Reference written from supplied mathematical specification before production inspection. Complete tiny truth table built by forward encryption, then compared to reference inverse enumeration. Production comparison is pending.','target_evaluated':False}
(ROOT/'tiny-reference-result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
