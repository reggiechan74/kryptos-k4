import itertools,json,time,hashlib,resource,importlib.util
from pathlib import Path
import reference as ref
ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('production',ROOT.parent/'freeze/production.py');prod=importlib.util.module_from_spec(spec);spec.loader.exec_module(prod)
start=time.process_time();alpha=('ABC','ACB');words=[''.join(x) for x in itertools.product('ABC',repeat=5)];configs=list(ref.configurations(alpha)); pc={x['id']:x for x in prod.configurations(alpha)};table={c:[] for c in words};encryptions=0; decryptions=0
for conf in configs:
    c=pc[conf['id']]
    for p in words:
        expected=ref.encrypt(p,conf['family'],conf['reference'],conf['initial'],conf['parameter'])
        got=prod.crypt(p,c['family'],c['reference'],c['initial'],c['parameter'])
        assert got==expected
        table[expected].append({'id':conf['id'],'plaintext':p});encryptions+=1
        assert prod.crypt(expected,c['family'],c['reference'],c['initial'],c['parameter'],True)==ref.decrypt(expected,conf['family'],conf['reference'],conf['initial'],conf['parameter'])==p;decryptions+=1
cases=0;digest=hashlib.sha256();mask=(0,2,4)
for cipher in words:
    for values in itertools.product('ABC',repeat=3):
        crib=dict(zip(mask,values));truth=sorted((x for x in table[cipher] if all(x['plaintext'][i]==v for i,v in crib.items())),key=lambda x:x['id'])
        out=prod.solve({'id':'tiny','ciphertext':cipher,'cribs':crib},alpha)
        assert out['complete'] and out['descriptions_examined']==24 and out['matches']==truth
        assert out['plaintexts']==sorted({x['plaintext'] for x in truth})
        digest.update(json.dumps([cipher,values,truth],sort_keys=True,separators=(',',':')).encode()+b'\n');cases+=1
assert digest.hexdigest()==json.loads((ROOT/'tiny-reference-result.json').read_text())['truth_digest_sha256']
seps=json.loads((ROOT/'operator-separators-complete.json').read_text());pc={x['id']:x for x in prod.configurations()};expected_pairs={tuple(sorted((a,b))) for a,b in itertools.combinations(pc,2)};actual=[]
for s in seps:
    outs=[]
    for key in ('a','b'):
        c=pc[s[key]]; out=prod.crypt(s['plaintext'],c['family'],c['reference'],c['initial'],c['parameter']); assert out==s[key+'_cipher'];outs.append(out)
    assert outs[0]!=outs[1];actual.append(tuple(sorted((s['a'],s['b']))))
assert len(actual)==len(set(actual))==len(expected_pairs)==21528 and set(actual)==expected_pairs
bijections=0
for c in pc.values():
    outs=[prod.crypt(ch,c['family'],c['reference'],c['initial'],c['parameter']) for ch in ref.AZ]
    assert len(set(outs))==26
    for p,cipher in zip(ref.AZ,outs): assert prod.crypt(cipher,c['family'],c['reference'],c['initial'],c['parameter'],True)==p
    bijections+=1
result={'status':'PASS_PRODUCTION_REFERENCE_COMPARISON','tiny_forward_agreements':encryptions,'tiny_inverse_agreements':decryptions,'complete_ciphertext_crib_sets':cases,'truth_digest_sha256':digest.hexdigest(),'full_alphabet_bijections':bijections,'pairwise_separator_witnesses_verified':len(actual),'distinct_encryption_functions_proven':208,'max_separator_length':max(len(s['plaintext']) for s in seps),'cpu_seconds':time.process_time()-start,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'target_evaluated':False,'limitations':'Synthetic tiny-domain completeness and exact pair non-equivalence; no guarantee of historical applicability or broad cipher-family coverage.'}
(ROOT/'production-comparison-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
