"""Independent study057 target transport/result audit, no solver rerun."""
import hashlib,json,pathlib,time
R=pathlib.Path('/workspace/shared/candidate-first-057');T=R/'target';start=time.process_time()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'freeze/manifest.json').read_text());tf=json.loads((T/'target-freeze.json').read_text())
assert sha(T/'target-freeze.json')=='c23afa9037bcbc1b12d0cc5f189e203db0b6007fd50d69514af53b40a29dc07d'
for p,h in m['files'].items():assert sha(R/p)==h,p
for p,h in tf['files'].items():assert sha(R/p)==h,p
source=pathlib.Path('/workspace/scratch/a41fb414fc4e/k4-tracker-repo/data/k4.json');d=json.loads(source.read_text());i=json.loads((T/'input.jsonl').read_text());ir=json.loads((T/'input-receipt.json').read_text())
assert sha(source)==ir['canonical_source_sha256'];assert d['length']==len(i['ciphertext'])==97 and d['ciphertext']==i['ciphertext']
assert hashlib.sha256(i['ciphertext'].encode()).hexdigest()==ir['ciphertext_sha256']=='eea813570c7f1fd3b34674e47b5c3da8948026f5cefee612a0b38ffaa515ceab'
assert i['clues']==[[j,c] for start,txt in [(21,'EASTNORTHEAST'),(63,'BERLINCLOCK')] for j,c in enumerate(txt,start)]
assert sha(T/'input.jsonl')==ir['target_input_sha256'];counts={};cpus={};rss={}
for engine in ['production','reference']:
 out=json.loads((T/f'{engine}.jsonl').read_text());rec=json.loads((T/f'{engine}.receipt.json').read_text())
 assert out['id']==i['id'] and out['complete'] and out['solutions']==[] and out['projection']['status']=='UNSAT_COMPLETE'
 assert out['projection']['raw_descriptions']==out['projection']['canonical_operators']==out['projection']['distinct_plaintexts']==0
 assert rec['status']=='completed' and rec['count']==1 and rec['failure'] is None
 assert sha(T/f'{engine}.jsonl')==rec['output_sha256'];assert rec['input_sha256']==sha(T/'input.jsonl')
 assert out['input_sha256']==hashlib.sha256((T/'input.jsonl').read_bytes().rstrip(b'\n')).hexdigest()
 assert rec['hard_worker_address_space_bytes']==rec['hard_child_address_space_bytes']==1024**3
 cpus[engine]=rec['inclusive_cpu_seconds'];rss[engine]=(rec['worker_peak_rss_kib']+rec['max_child_rss_kib'])*1024
 if engine=='production':
  assert len(out['receipts'])==8
  assert {tuple(v['convention']) for v in out['receipts']}=={(a,b,s) for a in ('AZ','KR') for b in ('AZ','KR') for s in (1,-1)}
  assert all(v['complete'] and v['cpu_seconds']<20 for v in out['receipts'])
 else:
  assert out['routes']==408960 and out['route_period_convention_trials']==22901760 and out['cpu_seconds']<65
ledger=json.loads((R/'results/resource-ledger.json').read_text());assert ledger['charged_cpu_seconds']<28800
result={'status':'PASS_EXACT_BOUNDED_EXCLUSION','canonical_source_url':'https://github.com/reggiechan74/kryptos-k4/blob/e589286feedd6c3b52959418acd848f0a54a62b5/data/k4.json','remote_source_read_verified':True,'target_freeze_sha256':sha(T/'target-freeze.json'),'ciphertext_sha256':ir['ciphertext_sha256'],'target_input_sha256':sha(T/'input.jsonl'),'crib_indexing':'zero-based21:34 and63:74;24letters','unchanged_frozen_files':len(m['files']),'production_conventions_completed':8,'independent_routes':408960,'independent_route_period_convention_trials':22901760,'solutions':0,'outcome':'UNSAT_COMPLETE in both engines','scope':'AZ/KRYPTOS plaintext and ciphertext roles,sign+/-;arbitraryperiodic numeric keys nominal2–8;arithmetic then unpadded top-down columnar widths6–9,all emissionorders,fixedalignment. BaselineAZ/AZ/+ repeated ascontrol;zero-key KR/KR/+ identity overlapdeduplicated.','outside_scope':['Other alphabets','Other key periods or widths','Reverse stage order','Autokey/feedback','Padding/noise/reversals/extra layers'],'target_inclusive_cpu_seconds':cpus,'target_conservative_worker_child_rss_bytes':rss,'ledger_charged_cpu_seconds_before_this_audit':ledger['charged_cpu_seconds'],'audit_cpu_seconds':time.process_time()-start,'target_rerun_by_auditor':False}
(R/'audit/FINAL-TARGET-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
(R/'audit/FINAL-TARGET-AUDIT.md').write_text('# Study 057 independent target audit\n\n**PASS: exact bounded exclusion.** Both unchanged engines returned `UNSAT_COMPLETE`, with zero compatible descriptions, canonical operators or plaintexts. The direct reference completed 408,960 routes and 22,901,760 route/period/convention trials across eight alphabet-role/sign combinations.\n\nThe canonical ciphertext and 24 crib letters were checked against the pinned repository source, including a fresh read of that source. All 22 frozen files and the additive target freeze hashes match. Production completed all eight conventions; the reference covered the full union. Resource receipts are complete and below frozen caps. No target rerun was performed by the auditor.\n\nThe exclusion applies only to the declared AZ/KRYPTOS alphabet roles, arithmetic signs, nominal periods 2–8, widths 6–9, arithmetic-before-columnar order, zero alignment, and unpadded top-down reads. It does not exclude reversed stages, feedback, other alphabets, larger bounds or other layers. Variant Beaufort/key phase are aliases; the all-zero KR/KR/+ identity stream is already in the baseline. This is new bounded coverage, not a new algorithm or evidence of the artist’s mechanism.\n\nSee the accompanying JSON for source and artifact hashes, trial counts, resource accounting and exact audit scope.\n')
print(json.dumps(result,indent=2))
