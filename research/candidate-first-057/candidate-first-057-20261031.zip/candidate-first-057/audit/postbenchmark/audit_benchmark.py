"""Independent post-seal study057 audit. Does not import production model/analyzer."""
import collections,hashlib,json,pathlib,resource,subprocess,time,sys
from independent import encrypt,canonical,equivalence_certificate
ROOT=pathlib.Path('/workspace/shared/candidate-first-057');OUT=ROOT/'audit/postbenchmark';OUT.mkdir(exist_ok=True)
start=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(path):
 vals=[json.loads(x) for x in (ROOT/path).read_text().splitlines()];d={x['id']:x for x in vals};assert len(d)==len(vals);return d
manifest=json.loads((ROOT/'freeze/manifest.json').read_text());seal=json.loads((ROOT/'results/seal.json').read_text())
for p,h in manifest['files'].items():assert sha(ROOT/p)==h,p
for p,h in seal['hashes'].items():assert sha(ROOT/p)==h,p
assert sha(ROOT/'freeze/manifest.json')=='d49542e537fa6ae1c731e16ec73fff12c9d390d9d9ac0bcc98542c3aad3cc39f'
generation=json.loads((ROOT/'fixtures/generation-receipt.json').read_text());assert generation['freeze_sha256']==sha(ROOT/'freeze/manifest.json')
assert sha(ROOT/'fixtures/inputs.jsonl')==generation['input_sha256'];assert sha(ROOT/'fixtures/answers.jsonl')==generation['answers_sha256']
seed=json.loads((ROOT/'fixtures/seed.json').read_text())['seed_hex'];assert hashlib.sha256(seed.encode()).hexdigest()==generation['seed_sha256']
replay=OUT/'fixture-replay';subprocess.run([sys.executable,str(ROOT/'source/generate_fixtures.py'),'--out',str(replay),'--freeze',str(ROOT/'freeze/manifest.json'),'--seed',seed],check=True,capture_output=True)
for n in ['inputs.jsonl','answers.jsonl']:assert sha(replay/n)==sha(ROOT/'fixtures'/n),n
I,A,P,R=[read(p) for p in ['fixtures/inputs.jsonl','fixtures/answers.jsonl','results/production.jsonl','results/reference.jsonl']];assert len(I)==520 and I.keys()==A.keys()==P.keys()==R.keys()
def convindex(c):return (0 if c[0]=='AZ' else 4)+(0 if c[1]=='AZ' else 2)+(0 if c[2]==1 else 1)
def normalize(w):return dict(w,convention=convindex(w['convention']),plaintext=[ord(x)-65 for x in w['plaintext']])
def raws(o):return {(convindex(w['convention']),w['width'],w['period'],tuple(w['order']),tuple(w['key']),w['plaintext']) for w in o['solutions']}
def proj(o):
 ops={canonical(normalize(w),97) for w in o['solutions']};plains={w['plaintext'] for w in o['solutions']}
 # Production's canonical digest uses physical mapping strings; convert independent numeric maps only for digest comparison.
 encoded=[(route,tuple(''.join(chr(x+65) for x in m) for m in maps)) for route,maps in ops]
 digest=lambda x:hashlib.sha256(json.dumps(sorted(x),separators=(',',':')).encode()).hexdigest()
 result={'raw_descriptions':len(o['solutions']),'canonical_operators':len(ops),'distinct_plaintexts':len(plains),'operator_sha256':digest(encoded),'plaintext_sha256':digest(plains),'status':'UNSAT_COMPLETE' if not plains else 'SAT_COMPLETE_UNIQUE_PLAINTEXT' if len(plains)==1 else 'SAT_COMPLETE_MULTIPLE_PLAINTEXTS'}
 assert result==o['projection'];return ops,plains
counter=collections.Counter();strata=collections.Counter();cases=[];maximum_prod_cpu=0;maximum_ref_cpu=0
for ident,c in I.items():
 p,r,a=P[ident],R[ident],A[ident];assert p['complete'] and r['complete'];assert raws(p)==raws(r);assert len(raws(p))==len(p['solutions'])
 assert r['route_period_convention_trials']==22901760 and r['routes']==408960
 po,pp=proj(p);ro,rp=proj(r);assert po==ro and pp==rp
 line=json.dumps(c,separators=(',',':'));assert p['input_sha256']==hashlib.sha256(line.encode()).hexdigest()==r['input_sha256']
 for w in p['solutions']:
  wn=normalize(w);cipher=encrypt(wn['plaintext'],wn['key'],wn['width'],wn['order'],wn['convention'])
  assert ''.join(chr(x+65) for x in cipher)==c['ciphertext'];assert all(w['plaintext'][j]==x for j,x in c['clues']);counter['independent_reencryptions']+=1
 assert len(p['receipts'])==8
 for rec in p['receipts']:
  assert rec['complete'] and rec['cpu_seconds']<=20 and rec['peak_rss_kib']*1024<1024**3;maximum_prod_cpu=max(maximum_prod_cpu,rec['cpu_seconds'])
 assert r['cpu_seconds']<=65 and r['peak_rss_kib']*1024<1024**3;maximum_ref_cpu=max(maximum_ref_cpu,r['cpu_seconds'])
 cat=a['category'];counter[cat]+=1;truth=a['truth']
 if truth:
  assert canonical(normalize(truth),97) in po and truth['plaintext'] in pp;counter['plant_included']+=1
  assert encrypt([ord(x)-65 for x in truth['plaintext']],truth['key'],truth['width'],truth['order'],convindex(truth['convention']))==[ord(x)-65 for x in c['ciphertext']]
  if cat in ('uniform-positive','literal-positive'):
   strata[(cat,convindex(truth['convention']),truth['width'],truth['period'])]+=1;counter[cat+'-unique']+=len(pp)==1
 else:assert cat=='random-control';counter['control_fits']+=bool(pp)
 cases.append({'id':ident,'category':cat,'raw_descriptions':len(p['solutions']),'canonical_operators':len(po),'distinct_plaintexts':len(pp)})
assert len(strata)==448 and set(strata.values())=={1}
assert counter['uniform-positive']==224 and counter['literal-positive']==224 and counter['random-control']==56 and counter['constant-alias']==8 and counter['period-two-alias']==8
assert counter['plant_included']==464 and counter['uniform-positive-unique']>=213 and counter['literal-positive-unique']>=202 and counter['control_fits']<=1
cert=equivalence_certificate();assert cert['unique_maps']==207 and len(cert['cross_family_overlaps'])==1
benchmark=json.loads((ROOT/'results/benchmark.json').read_text());assert all(benchmark['gates'].values());assert benchmark['counts']['uniform_unique']==counter['uniform-positive-unique'];assert benchmark['counts']['literal_unique']==counter['literal-positive-unique'];assert benchmark['counts']['control_fits']==counter['control_fits'];assert benchmark['counts']['reencryptions']==counter['independent_reencryptions']
ledger=json.loads((ROOT/'results/resource-ledger.json').read_text());assert ledger['charged_cpu_seconds']<28800;cpu=600;maxpair=0
for engine in ('production','reference'):
 rec=json.loads((ROOT/f'results/{engine}.receipt.json').read_text());assert rec['status']=='completed' and rec['count']==520
 assert rec['input_sha256']==sha(ROOT/'fixtures/inputs.jsonl') and rec['output_sha256']==sha(ROOT/f'results/{engine}.jsonl')
 assert rec['hard_worker_address_space_bytes']==rec['hard_child_address_space_bytes']==1024**3
 maxpair=max(maxpair,(rec['worker_peak_rss_kib']+rec['max_child_rss_kib'])*1024);cpu+=rec['inclusive_cpu_seconds']
assert abs(cpu-ledger['charged_cpu_seconds'])<1e-6
r1=resource.getrusage(resource.RUSAGE_CHILDREN);auditcpu=time.process_time()-start+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime
result={'status':'PASS_FOR_PARENT_TARGET_REVIEW','freeze_sha256':sha(ROOT/'freeze/manifest.json'),'seal_sha256':sha(ROOT/'results/seal.json'),'verified_frozen_files':len(manifest['files']),'independently_replayed_fixture_generation':True,'counts':dict(counter),'unique_full_generating_cells':len(strata),'complete_set_agreement':520,'reference_trial_total':520*22901760,'new_operator_scope':'Seven nonbaseline convention loops, excluding all-zero KR/KR/+ maps already in baseline; variantBeaufort and phase are aliases. This is not a new algorithm.','resource_audit':{'prior_charged_cpu_seconds':ledger['charged_cpu_seconds'],'audit_inclusive_cpu_seconds':auditcpu,'max_production_child_cpu_seconds':maximum_prod_cpu,'max_reference_child_cpu_seconds':maximum_ref_cpu,'conservative_max_worker_child_rss_bytes':maxpair},'limitations':['Procedural synthetic blinding; K4 clues are historically known.','Literal-clue fixtures are random text with inserted crib letters, not natural-language plaintext.','Uniform controls do not imply a posterior historical model probability.','No target was evaluated by this audit.'],'cases':cases}
(OUT/'FINAL-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
