# Study 057 independent model review

This is a pre-target mathematical review, not a K4 run receipt.

## Exact equation and safe reuse

Let A and B independently be the ordinary alphabet AZ or the fixed KRYPTOS alphabet `KRYPTOSABCDEFGHIJLMNQUVWXZ`. Let A⁻¹ and B⁻¹ denote physical-letter index lookup. For plaintext position i, use the intermediate physical letter B[(s A⁻¹(P_i)+k_(i mod p)) mod 26], where s is +1 or −1. Fill rows left to right without padding, and emit complete physical columns top to bottom in an arbitrary order. Width is 6–9; nominal key period is 2–8; fixed plaintext key phase is zero. No reverse stage order or feedback is introduced.

Transforming the ciphertext to B indices and each crib value to s A⁻¹(P_i) makes the equation exactly the original numeric additive model. Recover physical plaintext from returned numeric u as A[(s u) mod 26]. This is valid because s²=1. Reusing the numeric solver is therefore a representation change, while the additional alphabet/equation combinations expand the tested physical-letter operators.

An independent reference directly constructs the ragged row matrix, fills it from physical ciphertext, and infers key residues with B⁻¹(D_i) − s A⁻¹(P_i). It does not call the transformed solver. Every actual solution re-encrypts using a separate direct physical-letter implementation.

## Equivalences and coverage counts

The eight alphabet-role/sign combinations have 208 one-letter map descriptions (26 keys each), but only 207 distinct permutations. Exhaustive comparison of the full 26-letter maps finds exactly one overlap: AZ/AZ/+ with key zero and KR/KR/+ with key zero both give the identity map. For a complete 97-letter operator this overlaps only when every key value is zero. All other cross-family maps are disjoint. The full certificate enumerates all maps and the sole overlap.

A canonical complete operator must contain the full output-to-input route dependency plus the full 97-position physical-letter mapping stream. Counting only convention names, nominal periods or key strings is insufficient. Repeating a shorter key gives an alias. Changing the phase of an arbitrary key is a rotation alias. Variant Beaufort (subtracting an arbitrary key) has exactly the Vigenère domain after key negation and is not another family. The original AZ/AZ/+ domain was study056; it may be run as a control but must not be advertised as new coverage. Zero-key KR/KR/+ also belongs to that baseline.

The first two output dependencies of a columnar route differ by its width (each first column here has at least ten letters), so equal complete dependencies imply equal widths. The dependency ordering then uniquely identifies the emitted column permutation. Each fixed route and convention has all key residues constrained by the thirteen consecutive known positions for every period ≤8. Thus a route/period/convention trial either contradicts a crib or yields a single complete key; no free key guessing is needed in the primary domain.

## Frozen proposed controls

Use all eight conventions per input, not the generating convention supplied by the fixture author. Generate 224 uniform positives and 224 literal-crib positives, each covering every convention × width × nominal period cell once. Literal positives insert the 24 crib letters into otherwise uniform text; they test equality geometry, not natural-English recovery. Add sixteen explicit constant/repeated-key alias cases and 56 independently uniform ciphertext controls, half with uniform independent clue values and half with literal clue values. Do not select or reject fixtures based on solvability.

Required gates: all planted operators included; all complete raw solution sets equal the independent reference; every witness independently re-encrypts; every run completes under the frozen resource caps. At least 95% of uniform positives and 90% of literal positives must have a unique plaintext under the complete searched union. Alias cases have no uniqueness gate. At most one of 56 uniform ciphertext controls may fit. These operational thresholds are not a posterior probability of K4's family. Multiple solutions are valid outcomes; do not discard them to improve recovery.

Before these held-out cases, exhaustively compare the independent reference to brute-force complete-key enumeration in a tiny four-letter domain, and test the production adapter against independent full-alphabet examples. Uniform targets that fail the controls do not warrant a target run. No target input is embedded in the independent code or fixtures.
