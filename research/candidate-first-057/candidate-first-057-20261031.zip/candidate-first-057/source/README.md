# Reproduction

Compile `solver_056.cpp` and `reference.cpp` using `g++ -O3 -std=c++17`, naming binaries `solver` and `reference` in this folder. The production numeric solver source is unchanged from 056; model.py performs the frozen physical alphabet transformation. No target data is embedded in these engines.

The independent fixture generator is invoked only after freezing the protocol/code: `python3 source/generate_fixtures.py --out fixtures --freeze freeze/manifest.json`. Keep answers and seeds separate from solver inputs. Preserve original files. Replay seeds only to reproduce the same fixture set, never to select a favorable new set.

Run production then reference sequentially with `python3 source/run_batch.py production fixtures/inputs.jsonl results/production.jsonl`, then equivalent `reference` command. Seal the output hashes before opening answers. Calculate gates with `python3 source/analyze.py fixtures/inputs.jsonl fixtures/answers.jsonl results/production.jsonl results/reference.jsonl results/benchmark.json`.

The tiny test production adapter script uses a fixed production binary path from its original environment; replace that path with this folder's solver for portable reproduction, documenting the change. No logical code change is needed. Neither tiny script contains K4 ciphertext.
