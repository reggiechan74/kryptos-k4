"""Independent study057 blind fixture generation, only invoke after protocol/code freeze.
No production solver import. Public inputs omit generating family, key, route and plaintext.
"""
import argparse,hashlib,json,pathlib,random,secrets,time
from independent import encrypt
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--freeze',required=True);ap.add_argument('--seed',help='Replay only: hexadecimal seed from prior generation receipt');args=ap.parse_args()
 freeze=pathlib.Path(args.freeze);assert freeze.is_file(),'Existing freeze manifest required';out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True)
 assert not (out/'inputs.jsonl').exists(),'Never silently replace heldout fixtures'
 seed=args.seed or secrets.token_hex(32);rng=random.Random(int(seed,16));items=[]
 def add(category,conv=None,width=None,period=None,key=None,literal=False):
  if category=='random-control':
   cipher=[rng.randrange(26) for _ in range(97)]
   clues=[(i,ord(v)-65) for i,v in zip(MASK,LITERAL)] if literal else [(i,rng.randrange(26)) for i in MASK]
   truth=None
  else:
   plain=[rng.randrange(26) for _ in range(97)]
   if literal:
    for i,v in zip(MASK,LITERAL):plain[i]=ord(v)-65
   key=list(key) if key is not None else [rng.randrange(26) for _ in range(period)]
   order=list(range(width));rng.shuffle(order);cipher=encrypt(plain,key,width,order,conv)
   clues=[(i,plain[i]) for i in MASK]
   truth={'convention':['AZ' if conv//4==0 else 'KR','AZ' if (conv//2)%2==0 else 'KR',1 if conv%2==0 else -1],'convention_index':conv,'width':width,'period':period,'order':order,'key':key,'plaintext':''.join(chr(x+65) for x in plain)}
  items.append(({'ciphertext':''.join(chr(x+65) for x in cipher),'clues':[[i,chr(x+65)] for i,x in clues]}, {'category':category,'literal_clues':literal,'truth':truth}))
 for category,literal in [('uniform-positive',False),('literal-positive',True)]:
  for conv in range(8):
   for width in (6,7,8,9):
    for period in range(2,9):add(category,conv,width,period,literal=literal)
 for conv in range(8):
  # Include two explicit identity-alias cases, all remaining constants randomized.
  value=0 if conv in (0,6) else rng.randrange(26)
  add('constant-alias',conv,7,6,[value]*6)
  a=rng.randrange(26);b=(a+1+rng.randrange(25))%26
  add('period-two-alias',conv,8,8,[a,b]*4)
 for literal in (False,True):
  for _ in range(28):add('random-control',literal=literal)
 assert len(items)==520;rng.shuffle(items)
 public=[];answers=[]
 for j,(p,a) in enumerate(items):
  ident=f'057-B{j:04d}';public.append({'id':ident,**p});answers.append({'id':ident,**a})
 def write(name,values):
  p=out/name;p.write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in values));return hashlib.sha256(p.read_bytes()).hexdigest()
 receipt={'version':'057-independent-fixtures-v1','created_unix':time.time(),'freeze_sha256':hashlib.sha256(freeze.read_bytes()).hexdigest(),'seed_sha256':hashlib.sha256(seed.encode()).hexdigest(),'count':520,'input_sha256':write('inputs.jsonl',public),'answers_sha256':write('answers.jsonl',answers),'counts':{'uniform-positive':224,'literal-positive':224,'constant-alias':8,'period-two-alias':8,'random-control':56}}
 (out/'seed.json').write_text(json.dumps({'seed_hex':seed,'namespace':'057-independent-blind-v1'},indent=2)+'\n')
 (out/'generation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
