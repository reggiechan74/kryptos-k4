"""Frozen blind transport: reads sanitized inputs, never answers."""
import argparse,json,hashlib,time,resource,subprocess,sys
from pathlib import Path
from model import ROOT,solve,projection,CONVENTIONS

def reflimits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(65,65))
def reference(case):
 c=case['ciphertext'];q=case['clues'];v=[len(c),26,60,4,6,7,8,9,7,*range(2,9),len(q),*[ord(x)-65 for x in c]]
 v += [z for i,x in q for z in (i,ord(x)-65)]
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.process_time();wall=time.monotonic()
 r=subprocess.run([str(ROOT/'source/reference')],input=' '.join(map(str,v))+'\n',text=True,capture_output=True,timeout=90,preexec_fn=reflimits)
 if r.returncode:raise RuntimeError(('reference',r.returncode,r.stderr))
 o=json.loads(r.stdout)
 if not o['complete']:raise RuntimeError('INCONCLUSIVE: reference incomplete')
 for x in o['solutions']:
  x['convention']=CONVENTIONS[x['convention']]
  x['plaintext']=''.join(chr(65+v) for v in x['plaintext'])
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 o['inclusive_cpu_seconds']=time.process_time()-start+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
 o['wall_seconds']=time.monotonic()-wall
 return o

def main():
 ap=argparse.ArgumentParser();ap.add_argument('engine',choices=['production','reference']);ap.add_argument('inputs');ap.add_argument('output');a=ap.parse_args()
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
 inp=Path(a.inputs);out=Path(a.output);ledger=ROOT/'results/resource-ledger.json'
 if out.exists():raise FileExistsError(out)
 budget=json.loads(ledger.read_text());prior=budget['charged_cpu_seconds']
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.process_time();wall=time.monotonic();total=0;status='running';failure=None
 def used():
  now=resource.getrusage(resource.RUSAGE_CHILDREN)
  return time.process_time()-start+now.ru_utime+now.ru_stime-before.ru_utime-before.ru_stime
 try:
  with out.open('x') as f:
   for line in inp.read_text().splitlines():
    if prior+used()+180>28800:raise RuntimeError('Study CPU budget exhausted; INCONCLUSIVE')
    case=json.loads(line)
    assert set(case)=={'id','ciphertext','clues'}
    try:
     o=solve(case['ciphertext'],case['clues']) if a.engine=='production' else reference(case)
     o['projection']=projection(o,len(case['ciphertext']));o['id']=case['id'];o['input_sha256']=hashlib.sha256(line.encode()).hexdigest();o['engine']=a.engine
     f.write(json.dumps(o,separators=(',',':'))+'\n');f.flush();total+=1
    except Exception as e:
     f.write(json.dumps({'id':case['id'],'complete':False,'error':repr(e),'engine':a.engine})+'\n');f.flush();raise
    if total%25==0:print(a.engine,total,flush=True)
  status='completed'
 except BaseException as e:
  status='failed_inconclusive';failure=repr(e);raise
 finally:
  after=resource.getrusage(resource.RUSAGE_CHILDREN)
  charged=used()
  receipt={'engine':a.engine,'status':status,'failure':failure,'count':total,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None,'inclusive_cpu_seconds':charged,'wall_seconds':time.monotonic()-wall,'worker_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'max_child_rss_kib':after.ru_maxrss,'hard_worker_address_space_bytes':1024**3,'hard_child_address_space_bytes':1024**3}
  out.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
  budget['charged_cpu_seconds']=prior+charged;budget['entries'].append(receipt);ledger.write_text(json.dumps(budget,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
