"""Frozen gate calculation; answers are opened only after result files sealed."""
import argparse,json,hashlib,math
from pathlib import Path
from model import ROOT,projection,canonical,encrypt,CONVENTIONS

def wilson(k,n):
 z=1.959963984540054;d=1+z*z/n;center=(k/n+z*z/(2*n))/d;h=z*math.sqrt((k/n)*(1-k/n)/n+z*z/(4*n*n))/d;return [center-h,center+h]
def read(p):return {o['id']:o for o in map(json.loads,Path(p).read_text().splitlines())}
def raw(o):return set((tuple(x['convention']),x['width'],x['period'],tuple(x['order']),tuple(x['key']),x['plaintext']) for x in o['solutions'])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('inputs');ap.add_argument('answers');ap.add_argument('production');ap.add_argument('reference');ap.add_argument('output');a=ap.parse_args()
 I,A,P,R=map(read,[a.inputs,a.answers,a.production,a.reference]);assert I.keys()==A.keys()==P.keys()==R.keys()
 counters={'uniform_total':0,'uniform_unique':0,'literal_total':0,'literal_unique':0,'alias_total':0,'plant_total':0,'plant_included':0,'control_total':0,'control_fits':0,'complete':0,'set_agreement':0,'reencryptions':0};cases=[]
 for id,i in I.items():
  p,r,ans=P[id],R[id],A[id];ok=p['complete'] and r['complete'];counters['complete']+=ok
  match=raw(p)==raw(r) and projection(p,97)==projection(r,97);counters['set_agreement']+=match
  for s in p['solutions']:
   assert encrypt(s['plaintext'],s['convention'],s['width'],s['order'],s['key'])==i['ciphertext'];assert all(s['plaintext'][j]==x for j,x in i['clues']);counters['reencryptions']+=1
  cat={'uniform-positive':'uniform','literal-positive':'literal','constant-alias':'alias','period-two-alias':'alias','random-control':'control'}[ans['category']];pr=projection(p,97)
  plant=ans.get('truth');included=None
  if plant:plant=dict(plant,convention=tuple(plant['convention']))
  if plant:
   counters['plant_total']+=1
   op=canonical(97,plant['convention'],plant['width'],plant['order'],plant['key'])
   included=any(s['plaintext']==plant['plaintext'] and canonical(97,s['convention'],s['width'],s['order'],s['key'])==op for s in p['solutions']);counters['plant_included']+=included
  if cat in ('uniform','literal'):
   counters[cat+'_total']+=1;counters[cat+'_unique']+=pr['distinct_plaintexts']==1
  elif cat=='alias':counters['alias_total']+=1
  elif cat=='control':counters['control_total']+=1;counters['control_fits']+=pr['distinct_plaintexts']>0
  else:raise ValueError(cat)
  cases.append({'id':id,'category':cat,'complete':ok,'set_agreement':match,'plant_included':included,'projection':pr})
 gates={'all_complete':counters['complete']==520,'all_set_agreement':counters['set_agreement']==520,'all_plants':counters['plant_total']==464 and counters['plant_included']==464,'uniform_unique':counters['uniform_total']==224 and counters['uniform_unique']/224>=.95,'literal_unique':counters['literal_total']==224 and counters['literal_unique']/224>=.90,'random_fits':counters['control_total']==56 and counters['control_fits']<=1}
 o={'gates':gates,'all_numeric_gates_pass':all(gates.values()),'counts':counters,'uniform_unique_wilson95':wilson(counters['uniform_unique'],224),'literal_unique_wilson95':wilson(counters['literal_unique'],224),'control_fit_wilson95':wilson(counters['control_fits'],56),'cases':cases,'input_hashes':{k:hashlib.sha256(Path(getattr(a,k)).read_bytes()).hexdigest() for k in ('inputs','answers','production','reference')},'limitation':'Numeric gates do not substitute for independent freeze/resource/tiny-proof audit or parent target approval.'}
 Path(a.output).write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({k:v for k,v in o.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
