import hashlib,itertools,json,pathlib,subprocess,time
from independent import *
ROOT=pathlib.Path(__file__).parent
start=time.process_time();cases=0;witnesses=0;dig=hashlib.sha256();known=0
for cipher in itertools.product(range(4),repeat=4):
 for mask in ([0,2],[0,1,2,3]):
  clues=[(i,(cipher[i]+i+1)%4) for i in mask]
  expected=brute(list(cipher),clues,[2,3],[1,2])
  output=json.loads(subprocess.check_output([str(ROOT/'reference')],input=line(cipher,clues,[2,3],[1,2],m=4).encode()))
  assert output['complete']
  actual={signature(w) for w in output['solutions']}
  assert actual==expected,(cipher,clues,len(actual),len(expected))
  for w in output['solutions']:
   assert encrypt(w['plaintext'],w['key'],w['width'],w['order'],w['convention'],4)==list(cipher)
  dig.update(repr((cipher,clues,sorted(actual))).encode());cases+=1;witnesses+=len(actual)
for conv in range(8):
 for width in (6,7,8,9):
  order=list(reversed(range(width)));p=[(i*17+3)%26 for i in range(97)]
  for key in ([0,0],[1,3,1,3],[2,4,7,15,1,0,6]):
   c=encrypt(p,key,width,order,conv)
   assert decrypt(c,key,width,order,conv)==p;known+=1
cert=equivalence_certificate();assert cert['unique_maps']==207
assert len(cert['cross_family_overlaps'])==1 and cert['cross_family_overlaps'][0]['conventions']==[0,6] and cert['cross_family_overlaps'][0]['keys']==[0,0]
(ROOT/'equivalence-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
r={'status':'PASS','tiny_complete_set_cases':cases,'tiny_witnesses_reencrypted':witnesses,'full_length_roundtrips':known,'tiny_result_digest':dig.hexdigest(),'python_cpu_seconds':time.process_time()-start}
(ROOT/'tiny-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
