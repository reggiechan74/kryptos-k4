// Study 056 synthetic-only exact solvers. No target ciphertext or loader.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <ctime>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <string>
#include <vector>
#include <sys/resource.h>
using namespace std;
using VI=vector<int>;
using Lit=pair<int,int>;
double cpu(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
struct Metrics{long long routes=0,states=0,placements=0,support=0,conflicts=0,learned=0,hits=0,cross_hits=0,cross_unique=0,proof_checks=0;};
struct Placement{int c,s,len; VI vals; bool valid=true;};
struct Nogood{vector<Lit> clause,path; bool reused=false;};
struct Witness{int w,p; VI order,key,plain;};
struct Receipt{int w,p; vector<Lit> clause,path;};
struct Reuse{int w,p;vector<Lit> clause,discovery,current;vector<VI> domains;};
struct Solver{
 int n,a,mode,w,p; VI C,widths,periods,lens; vector<Lit> clues; vector<vector<Placement>> table; vector<VI> start_index; vector<Nogood> nogoods; vector<Witness> answers; vector<Receipt> receipts; vector<Reuse> reuses; Metrics m; double begin,limit,first=-1,preprocess=0; bool complete=true; long long ticks=0;
 bool expired(){if((++ticks&1023)!=0)return !complete; if(cpu()-begin>limit)complete=false;return !complete;}
 int mod(int x){x%=a;return x<0?x+a:x;}
 void prepare(){double t=cpu();lens.assign(w,0);table.assign(w,{});start_index.assign(w,VI(n,-1));nogoods.clear();for(int c=0;c<w;c++)lens[c]=(n-1-c)/w+1;
  for(int c=0;c<w;c++){set<int> starts{0};for(int d=0;d<w;d++)if(d!=c){auto old=starts;for(int s:old)starts.insert(s+lens[d]);}
   for(int s:starts){Placement q{c,s,lens[c],VI(p,-1),true};for(auto [i,v]:clues)if(i%w==c){int k=i%p,x=mod(C[s+i/w]-v);if(q.vals[k]>=0&&q.vals[k]!=x)q.valid=false;q.vals[k]=x;}start_index[c][s]=table[c].size();table[c].push_back(q);}}
  preprocess+=cpu()-t;
 }
 void emit(const VI& order,VI key){if(expired())return;int free=-1;for(int k=0;k<p;k++)if(key[k]<0){free=k;break;}if(free>=0){for(int v=0;v<a;v++){key[free]=v;emit(order,key);}return;}
  VI inter(n),plain(n);int off=0;for(int c:order){for(int i=c;i<n;i+=w)inter[i]=C[off++];}for(int i=0;i<n;i++)plain[i]=mod(inter[i]-key[i%p]);
  answers.push_back({w,p,order,key,plain});if(first<0)first=cpu()-begin;
 }
 bool merge(VI& key,const Placement& q){m.placements++;if(!q.valid)return false;for(int k=0;k<p;k++)if(q.vals[k]>=0){if(key[k]>=0&&key[k]!=q.vals[k])return false;key[k]=q.vals[k];}return true;}
 const Placement& at(int c,int s){int i=start_index[c][s];if(i<0)throw runtime_error("impossible start");return table[c][i];}
 void enumeration(){VI order(w);iota(order.begin(),order.end(),0);do{if(expired())return;m.routes++;VI key(p,-1);int s=0;bool ok=true;for(int c:order){if(!merge(key,at(c,s))){ok=false;break;}s+=lens[c];}if(ok)emit(order,key);}while(next_permutation(order.begin(),order.end()));}
 void prefix(VI& order,int used,int off,const VI& key){if(expired())return;m.states++;if((int)order.size()==w){m.routes++;emit(order,key);return;}for(int c=0;c<w;c++)if(!(used&(1<<c))){VI next=key;if(merge(next,at(c,off))){order.push_back(c);prefix(order,used|(1<<c),off+lens[c],next);order.pop_back();}}}
 bool compatible(int c,int i,int d,int j){m.support++;auto &x=table[c][i],&y=table[d][j];if(max(x.s,y.s)<min(x.s+x.len,y.s+y.len))return false;for(int k=0;k<p;k++)if(x.vals[k]>=0&&y.vals[k]>=0&&x.vals[k]!=y.vals[k])return false;return true;}
 using Domains=vector<VI>;
 bool diverged(const vector<Lit>& x,const vector<Lit>& y){size_t z=0;while(z<x.size()&&z<y.size()&&x[z]==y[z])z++;return z<x.size()&&z<y.size();}
 bool propagate(Domains& dom,bool learning,const vector<Lit>& path){bool changed=true;while(changed){if(expired())return false;changed=false;
   if(learning){for(auto &ng:nogoods){int unfixed=0;Lit rem{-1,-1};bool inactive=false;for(auto [c,i]:ng.clause){if(find(dom[c].begin(),dom[c].end(),i)==dom[c].end()){inactive=true;break;}if(dom[c].size()!=1){unfixed++;rem={c,i};}}if(inactive||unfixed>1)continue;m.hits++;if(diverged(path,ng.path)){m.cross_hits++;if(!ng.reused){ng.reused=true;m.cross_unique++;reuses.push_back({w,p,ng.clause,ng.path,path,dom});}}if(unfixed==0)return false;auto &v=dom[rem.first];v.erase(find(v.begin(),v.end(),rem.second));changed=true;if(v.empty())return false;}}
   for(int c=0;c<w;c++)for(int d=0;d<w;d++)if(c!=d){auto &v=dom[c];for(size_t x=0;x<v.size();){bool support=false;for(int j:dom[d])if(compatible(c,v[x],d,j)){support=true;break;}if(!support){v.erase(v.begin()+x);changed=true;if(v.empty())return false;}else x++;}}
  }return true;}
 Domains initial(){Domains d(w);for(int c=0;c<w;c++)for(int i=0;i<(int)table[c].size();i++)if(table[c][i].valid)d[c].push_back(i);return d;}
 bool prove(const vector<Lit>& clause){m.proof_checks++;auto d=initial();for(auto [c,i]:clause){if(find(d[c].begin(),d[c].end(),i)==d[c].end())return true;d[c]={i};}for(auto &v:d)if(v.empty())return true;return !propagate(d,false,{});}
 void learn(const vector<Lit>& path){if(path.empty()||!complete)return;vector<Lit> clause=path;for(size_t i=0;i<clause.size();){auto trial=clause;trial.erase(trial.begin()+i);if(prove(trial)&&complete)clause=trial;else i++;if(!complete)return;}sort(clause.begin(),clause.end());for(auto &ng:nogoods)if(ng.clause==clause)return;nogoods.push_back({clause,path,false});receipts.push_back({w,p,clause,path});m.learned++;}
 void csp(Domains dom,vector<Lit>& path,bool learning){if(expired())return;m.states++;for(auto &v:dom)if(v.empty()){m.conflicts++;if(learning)learn(path);return;}if(!propagate(dom,learning,path)){if(complete){m.conflicts++;if(learning)learn(path);}return;}
  int branch=-1;for(int c=0;c<w;c++)if(dom[c].size()>1&&(branch<0||dom[c].size()<dom[branch].size()))branch=c;
  if(branch<0){VI order(w),key(p,-1);iota(order.begin(),order.end(),0);sort(order.begin(),order.end(),[&](int c,int d){return table[c][dom[c][0]].s<table[d][dom[d][0]].s;});for(int c:order)if(!merge(key,table[c][dom[c][0]]))throw runtime_error("CSP inconsistent leaf");m.routes++;emit(order,key);return;}
  auto values=dom[branch];for(int i:values){auto child=dom;child[branch]={i};path.push_back({branch,i});csp(child,path,learning);path.pop_back();if(!complete)return;}
 }
 void run(){begin=cpu();for(int ww:widths)for(int pp:periods){if(!complete)break;w=ww;p=pp;prepare();if(mode==0)enumeration();if(mode==1){VI o;prefix(o,0,0,VI(p,-1));}if(mode>=2){auto d=initial();vector<Lit> path;csp(d,path,mode==3);}}}
 void arr(const VI& v){cout<<'[';for(size_t i=0;i<v.size();i++){if(i)cout<<',';cout<<v[i];}cout<<']';}
 void lits(const vector<Lit>& v){cout<<'[';for(size_t i=0;i<v.size();i++){if(i)cout<<',';cout<<'['<<v[i].first<<','<<v[i].second<<']';}cout<<']';}
 void output(){double elapsed=cpu()-begin;rusage r;getrusage(RUSAGE_SELF,&r);cout.precision(12);cout<<"{\"complete\":"<<(complete?"true":"false")<<",\"cpu_seconds\":"<<elapsed<<",\"preprocessing_cpu_seconds\":"<<preprocess<<",\"first_witness_cpu_seconds\":"<<first<<",\"peak_rss_kib\":"<<r.ru_maxrss<<",\"metrics\":{";
 cout<<"\"completed_route_trials\":"<<m.routes<<",\"visited_states\":"<<m.states<<",\"placement_checks\":"<<m.placements<<",\"support_checks\":"<<m.support<<",\"conflicts\":"<<m.conflicts<<",\"dynamic_nogoods\":"<<m.learned<<",\"later_nogood_hits\":"<<m.hits<<",\"cross_branch_hits\":"<<m.cross_hits<<",\"cross_branch_unique_nogoods\":"<<m.cross_unique<<",\"proof_replays\":"<<m.proof_checks<<"},\"solutions\":[";
 for(size_t z=0;z<answers.size();z++){if(z)cout<<',';auto &v=answers[z];cout<<"{\"width\":"<<v.w<<",\"period\":"<<v.p<<",\"order\":";arr(v.order);cout<<",\"key\":";arr(v.key);cout<<",\"plaintext\":";arr(v.plain);cout<<'}';}cout<<"],\"nogoods\":[";
 // Literal receipt indices refer to the deterministic ascending subset-sum start table.
 for(size_t z=0;z<receipts.size();z++){if(z)cout<<',';auto &v=receipts[z];cout<<"{\"width\":"<<v.w<<",\"period\":"<<v.p<<",\"clause_placement_indices\":";lits(v.clause);cout<<",\"discovery_decisions\":";lits(v.path);cout<<'}';}cout<<"],\"nogood_reuses\":[";
 for(size_t z=0;z<reuses.size();z++){if(z)cout<<',';auto &v=reuses[z];cout<<"{\"width\":"<<v.w<<",\"period\":"<<v.p<<",\"clause_placement_indices\":";lits(v.clause);cout<<",\"discovery_decisions\":";lits(v.discovery);cout<<",\"reuse_decisions\":";lits(v.current);cout<<",\"domains_before_reuse\":[";for(size_t c=0;c<v.domains.size();c++){if(c)cout<<',';arr(v.domains[c]);}cout<<"]}";}cout<<"]}\n";
 }
};
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);while(true){Solver s;int nw,np,nc;if(!(cin>>s.mode>>s.n>>s.a>>s.limit>>nw))break;s.widths.resize(nw);for(int&x:s.widths)cin>>x;cin>>np;s.periods.resize(np);for(int&x:s.periods)cin>>x;cin>>nc;s.C.resize(s.n);for(int&x:s.C)cin>>x;for(int j=0;j<nc;j++){int i,v;cin>>i>>v;s.clues.push_back({i,v});}if(!cin||s.n<1||s.n>100||s.a<2||s.a>26)return 2;for(int w:s.widths)if(w<1||w>s.n||w>10)return 2;for(int p:s.periods)if(p<1||p>9)return 2;s.run();s.output();cout.flush();}}
