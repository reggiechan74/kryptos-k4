// Study 057 independent literal row-matrix exhaustive reference.
// Explicit physical-letter alphabet arithmetic. No 056 solver or transformed wrapper reused.
#include <algorithm>
#include <array>
#include <ctime>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
#include <functional>
#include <sys/resource.h>
using namespace std;
using VI=vector<int>;
double cpu(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
struct W{int convention,width,period;VI order,key,plaintext;};
void arr(const VI& a){cout<<'[';for(size_t j=0;j<a.size();++j){if(j)cout<<',';cout<<a[j];}cout<<']';}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);int n,m,nw,np,nc;double limit;while(cin>>n>>m>>limit>>nw){VI widths(nw);for(int&v:widths)cin>>v;cin>>np;VI periods(np);for(int&v:periods)cin>>v;cin>>nc;VI C(n);for(int&v:C)cin>>v;vector<pair<int,int>> clues(nc);for(auto&[i,v]:clues)cin>>i>>v;if(!cin||n<1||n>100||(m!=4&&m!=26)||limit<=0)return 2;
 vector<VI>A(2,VI(m)),I(2,VI(m));iota(A[0].begin(),A[0].end(),0);string kr=m==26?"KRYPTOSABCDEFGHIJLMNQUVWXZ":"ACDB";for(int j=0;j<m;++j)A[1][j]=kr[j]-'A';for(int a=0;a<2;++a)for(int j=0;j<m;++j)I[a][A[a][j]]=j;
 for(int x:C)if(x<0||x>=m)return 2;for(auto[i,v]:clues)if(i<0||i>=n||v<0||v>=m)return 2;
 double start=cpu();bool complete=true;long long trials=0,routes=0;vector<W>solutions;
 auto mod=[&](int x){x%=m;return x<0?x+m:x;};
 for(int width:widths){if(width<1||width>n||width>10)return 2;VI order(width);iota(order.begin(),order.end(),0);do{if(!complete)break;++routes;
  // Independently construct blank rows and fill their physical columns from ciphertext.
  vector<VI> rows;for(int off=0;off<n;off+=width)rows.push_back(VI(min(width,n-off),-1));int cursor=0;for(int column:order)for(auto& row:rows)if(column<(int)row.size())row[column]=C[cursor++];VI intermediate;for(auto&row:rows)for(int x:row)intermediate.push_back(x);if(cursor!=n)return 3;
  for(int period:periods){if(period<1||period>9)return 2;for(int pa=0;pa<2;++pa)for(int ca=0;ca<2;++ca)for(int sign: {1,-1}){if((trials++&1023)==0&&cpu()-start>limit){complete=false;break;}VI key(period,-1);bool valid=true;
   for(auto[position,plain]:clues){int residue=position%period;int inferred=mod(I[ca][intermediate[position]]-sign*I[pa][plain]);if(key[residue]!=-1&&key[residue]!=inferred){valid=false;break;}key[residue]=inferred;}
   if(!valid)continue;int convention=pa*4+ca*2+(sign==-1);
   function<void(int)>emit=[&](int slot){if(slot==period){VI plain(n);for(int i=0;i<n;++i)plain[i]=A[pa][mod(sign*(I[ca][intermediate[i]]-key[i%period]))];solutions.push_back({convention,width,period,order,key,plain});return;}if(key[slot]>=0){emit(slot+1);return;}for(int x=0;x<m;++x){key[slot]=x;emit(slot+1);}key[slot]=-1;};emit(0);
  }if(!complete)break;}
 }while(complete&&next_permutation(order.begin(),order.end()));if(!complete)break;}
 rusage usage;getrusage(RUSAGE_SELF,&usage);cout.precision(12);cout<<"{\"complete\":"<<(complete?"true":"false")<<",\"cpu_seconds\":"<<cpu()-start<<",\"peak_rss_kib\":"<<usage.ru_maxrss<<",\"routes\":"<<routes<<",\"route_period_convention_trials\":"<<trials<<",\"solutions\":[";
 for(size_t j=0;j<solutions.size();++j){if(j)cout<<',';auto &v=solutions[j];cout<<"{\"convention\":"<<v.convention<<",\"width\":"<<v.width<<",\"period\":"<<v.period<<",\"order\":";arr(v.order);cout<<",\"key\":";arr(v.key);cout<<",\"plaintext\":";arr(v.plaintext);cout<<'}';}cout<<"]}\n";cout.flush();}}
