"""Study 057: exact alphabet-role adapter. No target ciphertext or target loader."""
import hashlib,json,itertools,subprocess,resource,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ALPHABETS={'AZ':'ABCDEFGHIJKLMNOPQRSTUVWXYZ','KR':'KRYPTOSABCDEFGHIJLMNQUVWXZ'}
CONVENTIONS=[(p,c,s) for p in ALPHABETS for c in ALPHABETS for s in (1,-1)]
MASK=list(range(21,34))+list(range(63,74))
LITERAL='EASTNORTHEASTBERLINCLOCK'

def mapping(conv,k):
 p,c,s=conv;return tuple(ALPHABETS[c][(s*ALPHABETS[p].index(x)+k)%26] for x in ALPHABETS['AZ'])
def route(n,w,order):return tuple(i for col in order for i in range(col,n,w))
def canonical(n,conv,w,order,key):
 r=route(n,w,order);maps=tuple(''.join(mapping(conv,key[i%len(key)])) for i in range(n))
 return r,maps

def encrypt(plain,conv,w,order,key):
 p,c,s=conv;inter=[ALPHABETS[c][(s*ALPHABETS[p].index(x)+key[i%len(key)])%26] for i,x in enumerate(plain)]
 return ''.join(inter[i] for i in route(len(plain),w,order))
def transformed(cipher,clues,conv):
 p,c,s=conv
 return [ALPHABETS[c].index(x) for x in cipher],[(i,(s*ALPHABETS[p].index(x))%26) for i,x in clues]
def inverse_plain(nums,conv):
 p,c,s=conv;return ''.join(ALPHABETS[p][(s*x)%26] for x in nums)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(20,20))
def request(cipher,clues,conv,widths=(6,7,8,9),periods=tuple(range(2,9)),mode=2):
 C,Q=transformed(cipher,clues,conv)
 vals=[mode,len(C),26,15,len(widths),*widths,len(periods),*periods,len(Q),*C]
 vals += [z for pair in Q for z in pair]
 return ' '.join(map(str,vals))+'\n'
def solve(cipher,clues,widths=(6,7,8,9),periods=tuple(range(2,9))):
 out=[];receipts=[];before=resource.getrusage(resource.RUSAGE_CHILDREN);t=time.process_time()
 for conv in CONVENTIONS:
  start=time.monotonic();r=subprocess.run([str(ROOT/'source/solver')],input=request(cipher,clues,conv,widths,periods),capture_output=True,text=True,timeout=30,preexec_fn=limits)
  if r.returncode:raise RuntimeError((conv,r.returncode,r.stderr))
  obj=json.loads(r.stdout)
  if not obj['complete']:raise RuntimeError('INCONCLUSIVE: solver incomplete')
  receipts.append({'convention':conv,'wall_seconds':time.monotonic()-start,'cpu_seconds':obj['cpu_seconds'],'peak_rss_kib':obj['peak_rss_kib'],'complete':obj['complete'],'metrics':obj['metrics']})
  for sol in obj['solutions']:
   sol['plaintext']=inverse_plain(sol['plaintext'],conv);sol['convention']=conv
   assert all(sol['plaintext'][i]==x for i,x in clues)
   assert encrypt(sol['plaintext'],conv,sol['width'],sol['order'],sol['key'])==cipher
   out.append(sol)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 return {'complete':True,'solutions':out,'receipts':receipts,'inclusive_cpu_seconds':time.process_time()-t+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'worker_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
def projection(obj,n):
 ops=set();plains=set()
 for x in obj['solutions']:
  ops.add(canonical(n,x['convention'],x['width'],x['order'],x['key']));plains.add(x['plaintext'])
 def digest(v):return hashlib.sha256(json.dumps(sorted(v),separators=(',',':')).encode()).hexdigest()
 return {'raw_descriptions':len(obj['solutions']),'canonical_operators':len(ops),'distinct_plaintexts':len(plains),'operator_sha256':digest(ops),'plaintext_sha256':digest(plains),'status':'UNSAT_COMPLETE' if not plains else 'SAT_COMPLETE_UNIQUE_PLAINTEXT' if len(plains)==1 else 'SAT_COMPLETE_MULTIPLE_PLAINTEXTS'}
