"""Independent tiny all-convention test of unchanged numeric056 core +057 adapter formulas."""
import hashlib,itertools,json,pathlib,subprocess,time,resource
from independent import *
ROOT=pathlib.Path(__file__).parent;SOLVER=pathlib.Path('/workspace/shared/candidate-first-057/source/solver')
start=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN);cases=0;calls=0;witnesses=0;digest=hashlib.sha256();aa=alphabets(4)
for cipher in itertools.product(range(4),repeat=4):
 for mask in ([0,2],[0,1,2,3]):
  clues=[(i,(cipher[i]+i+1)%4) for i in mask];expected=brute(cipher,clues,[2,3],[1,2]);actual=set()
  for conv in range(8):
   pa,ca,sign=parse_convention(conv);ai={x:j for j,x in enumerate(aa[pa])};bi={x:j for j,x in enumerate(aa[ca])}
   transformed=[bi[x] for x in cipher];cq=[(i,(sign*ai[v])%4) for i,v in clues]
   request=' '.join(map(str,[2,4,4,10,2,2,3,2,1,2,len(cq),*transformed,*itertools.chain.from_iterable(cq)]))+'\n'
   out=json.loads(subprocess.check_output([str(SOLVER)],input=request.encode()));assert out['complete'];calls+=1
   for w in out['solutions']:
    w['plaintext']=[aa[pa][(sign*x)%4] for x in w['plaintext']];w['convention']=conv
    assert encrypt(w['plaintext'],w['key'],w['width'],w['order'],conv,4)==list(cipher)
    actual.add(signature(w))
  assert actual==expected,(cipher,clues,len(actual),len(expected))
  cases+=1;witnesses+=len(actual);digest.update(repr((cipher,clues,sorted(actual))).encode())
r1=resource.getrusage(resource.RUSAGE_CHILDREN);r={'status':'PASS','complete_set_cases':cases,'numeric_solver_calls':calls,'witnesses_reencrypted':witnesses,'result_digest':digest.hexdigest(),'inclusive_cpu_seconds':time.process_time()-start+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'scope':'numeric core and same alphabet adapter formulas in four-letter domain; actual production wrapper gets independent full26 benchmark'}
(ROOT/'production-tiny-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
