"""Study 057 independent physical-letter encryption, canonicalization, and tiny oracle."""
import hashlib, itertools, json
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'

def alphabets(m=26):
    return [list(range(m)),[ord(x)-65 for x in (KR if m==26 else 'ACDB')]]

def parse_convention(conv):
    return conv//4,(conv//2)%2,1 if conv%2==0 else -1

def encrypt(plain,key,width,order,conv,m=26):
    aa=alphabets(m);pa,ca,sign=parse_convention(conv);inv={x:j for j,x in enumerate(aa[pa])}
    substituted=[aa[ca][(sign*inv[v]+key[i%len(key)])%m] for i,v in enumerate(plain)]
    rows=[substituted[j:j+width] for j in range(0,len(plain),width)]
    return [row[col] for col in order for row in rows if col<len(row)]

def decrypt(cipher,key,width,order,conv,m=26):
    aa=alphabets(m);pa,ca,sign=parse_convention(conv);inv={x:j for j,x in enumerate(aa[ca])}
    rows=[[None]*min(width,len(cipher)-j) for j in range(0,len(cipher),width)]
    it=iter(cipher)
    for col in order:
        for row in rows:
            if col<len(row):row[col]=next(it)
    return [aa[pa][(sign*(inv[x]-key[i%len(key)]))%m] for i,x in enumerate(itertools.chain.from_iterable(rows))]

def canonical(w,n,m=26):
    aa=alphabets(m);pa,ca,sign=parse_convention(w['convention']);inv={x:j for j,x in enumerate(aa[pa])}
    rows=[list(range(j,min(n,j+w['width']))) for j in range(0,n,w['width'])]
    dependencies=tuple(row[col] for col in w['order'] for row in rows if col<len(row))
    maps=tuple(tuple(aa[ca][(sign*inv[x]+w['key'][i%len(w['key'])])%m] for x in range(m)) for i in range(n))
    return dependencies,maps

def signature(w):
    return (w['convention'],w['width'],w['period'],tuple(w['order']),tuple(w['key']),tuple(w['plaintext']))

def brute(cipher,clues,widths,periods,m=4):
    answers=set()
    for width in widths:
      for order in itertools.permutations(range(width)):
       for period in periods:
        for conv in range(8):
         for key in itertools.product(range(m),repeat=period):
          plain=decrypt(cipher,key,width,order,conv,m)
          if all(plain[i]==v for i,v in clues):
           answers.add((conv,width,period,tuple(order),tuple(key),tuple(plain)))
    return answers

def line(cipher,clues,widths,periods,m=26,limit=20):
    return ' '.join(map(str,[len(cipher),m,limit,len(widths),*widths,len(periods),*periods,len(clues),*cipher,*itertools.chain.from_iterable(clues)]))+'\n'

def equivalence_certificate():
    aa=alphabets();maps={}
    for conv in range(8):
      pa,ca,sign=parse_convention(conv);inv={x:j for j,x in enumerate(aa[pa])}
      maps[conv]={tuple(aa[ca][(sign*inv[x]+k)%26] for x in range(26)):k for k in range(26)}
    overlaps=[]
    for a in range(8):
      for b in range(a+1,8):
       for mapping in set(maps[a])&set(maps[b]):
        overlaps.append({'conventions':[a,b],'keys':[maps[a][mapping],maps[b][mapping]],'mapping':mapping})
    return {'map_descriptions':208,'unique_maps':len(set().union(*(set(x) for x in maps.values()))),'cross_family_overlaps':overlaps,'all_maps':{str(c):[{'key':k,'mapping':s} for s,k in family.items()] for c,family in maps.items()}}
