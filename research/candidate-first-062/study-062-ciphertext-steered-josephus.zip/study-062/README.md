# Study 062: ciphertext-steered Josephus

**Result: exact bounded exclusion.** One production and one independent reference K4 evaluation both completed all 3,104 structural descriptions and returned zero compatible key cylinders. This is not an exclusion of message-dependent transpositions generally.

## Frozen rule

Choose AZ or KRYPTOS alphabet, initial slot 0–96 and one fixed direction. Remove the cursor slot and emit its plaintext rank plus an emission-index periodic key, period 1–8. Move to the next surviving slot in the fixed direction, then advance another 1+rank(ciphertext letter) surviving slots. No reset, direction alternation, padding or alternate step rule.

There are 388 target-induced permutations and 3,104 route/period descriptions, not that many independent keyed functions. Target domains exclude the already-covered all-zero key vector. Free key residues are represented exactly; when necessary, zero is removed symbolically from a cylinder rather than pretending the remainder is an unrestricted Cartesian product.

## Evidence

- `freeze/protocol.md` and `freeze/manifest.json`: exact finite rule, gates and 115-file pre-holdout freeze.
- `audit/`: independent linked-circle reference, complete tiny forward truth, all-configuration synthetic comparisons, zero-excision tests and source-correction review.
- `eligibility/`: 388 actual route maps, local/external membership comparisons, source URL/hash inventories, original prefreeze correction and measured resource receipts.
- `benchmark/`: all 872 fresh fixtures, seed/answers, original sealed outputs, resource receipts and analysis.
- `audit/postbenchmark/FINAL-AUDIT.json`: independent fixture replay, complete sets and roundtrips.
- `target/`: canonical source, separate approval, additive transport freeze, two original outputs and seals.
- `audit/target/FINAL-AUDIT.json`: final independent non-search audit.
- `REPORT.md`, `METHOD-LEARNING.md`, `resource-ledger.json`: interpretation, reusable lessons, all execution costs and conservative reserves.

## Controls and ambiguity

51,012 tiny forward/inverse/route checks and 365,616 complete cylinder comparisons passed; all 3,104 full-size configurations also passed deterministic prefreeze checks. The held-out benchmark spans every route in uniform and literal-clue form with a frozen balanced period allocation, plus sparse plants and nulls.

All 808 plants were included. Among 776 full-mask plants, 656 recovered uniquely and 120 remained ambiguous/free—correctly retained, not falsely reported as unique. All 32 deliberately sparse planted settings retained seven free residues. All 872 complete sets agreed, 85,924 roundtrip probes passed, and none of 64 null controls fit. Sampling free completions is a control; exact residue equations and exhaustive tiny truth establish cylinder completeness.

## Reproduction and provenance

Python 3.12 standard library suffices for cipher engines. Create a new output directory, then run `python freeze/production.py benchmark/inputs.json new/production.jsonl` or `python freeze/reference_adapter.py benchmark/inputs.json new/reference.jsonl`. Do not overwrite original receipts. The archive records exactly one production and one reference target evaluation; deliberate future reproduction is separate.

Membership code is our independently written code; some scripts preserve original shared-workspace paths, which must be adjusted in copies for another environment. C++ comparators are source-only. Third-party source/code prose is omitted without verified redistribution rights; URL/commit/hash inventories identify reviewed public inputs. Provenance manifests can reference omitted reviewed inputs, whereas the publication manifest lists only actual archive files. No external source program was executed.

The artifact-literal E→A transcription correction was made and independently checked against the pinned primary source before freeze; wrong original code/results remain preserved. Historical EXT012 executable availability limits remain explicit; the declared historical universe was hash-reconstructed exactly. No worldwide novelty or Sanborn-design claim is made.
