import json,random,pathlib,sys
import reference
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def generate(seed):
 rng=random.Random(seed);items=[]
 def text():return ''.join(rng.choice(reference.AZ) for _ in range(97))
 def plant(a,s,d,p,kind):
  A=(reference.AZ,reference.KR)[a];plain=list(text())
  if kind=='literal':
   for i,c in zip(MASK,LITERAL):plain[i]=c
  plain=''.join(plain);key=[rng.randrange(26) for _ in range(p)];C=reference.encrypt(plain,A,s,d,key)
  mask=[reference.route(C,A,s,d)[t] for t in [0,8,16,24]] if kind=='sparse' else MASK
  items.append(({'ciphertext':C,'cribs':{str(i):plain[i] for i in mask}}, {'kind':kind,'config':f'J:{a}:{s}:{d}:{p}','key':key,'plaintext':plain}))
 for a in range(2):
  for s in range(97):
   for j,d in enumerate([1,-1]):
    for b,kind in enumerate(['uniform','literal']):plant(a,s,d,1+(s+3*j+5*a+4*b)%8,kind)
 for a in range(2):
  for k in range(16):plant(a,7*k%97,1 if k%2==0 else -1,8,'sparse')
 for k in range(64):
  letters=LITERAL if k>=32 else ''.join(rng.choice(reference.AZ) for _ in MASK)
  items.append(({'ciphertext':text(),'cribs':dict(zip(map(str,MASK),letters))},{'kind':'null_literal' if k>=32 else 'null_uniform'}))
 rng.shuffle(items);inputs=[];answers=[]
 for k,(x,y) in enumerate(items):
  ID=f'case-{k:04d}';inputs.append({'id':ID,**x});answers.append({'id':ID,**y})
 return inputs,answers
if __name__=='__main__':
 dest=pathlib.Path(sys.argv[1]);inputs,answers=generate(int((dest/'seed.txt').read_text(),16))
 for name,data in [('inputs.json',inputs),('answers.json',answers)]:(dest/name).write_text(json.dumps(data,indent=2)+'\n')
