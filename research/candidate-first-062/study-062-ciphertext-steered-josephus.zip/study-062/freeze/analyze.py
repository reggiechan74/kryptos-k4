import json,pathlib,sys,time
import production

def probes(digits):
 base=[0 if v is None else v for v in digits];free=[i for i,v in enumerate(digits) if v is None];out=[base]
 if free:
  out.append([1 if v is None else v for v in digits])
  for i in free:k=base.copy();k[i]=1;out.append(k)
 return [list(x) for x in dict.fromkeys(tuple(x) for x in out)]
def analyze(root):
 started=time.process_time();configs={x['id']:x for x in production.configurations()};inputs=json.loads((root/'inputs.json').read_text());answers={x['id']:x for x in json.loads((root/'answers.json').read_text())}
 first=[json.loads(x) for x in (root/'production.jsonl').read_text().splitlines()];second=[json.loads(x) for x in (root/'reference.jsonl').read_text().splitlines()];assert len(inputs)==len(first)==len(second)==872 and first==second
 plants=sparse=nullfits=roundtrips=full_unique=full_ambiguous=free_cylinders=max_free=0
 for case,result in zip(inputs,first):
  assert case['id']==result['id'] and result['complete'] and result['structural_cases_examined']==3104
  answer=answers[case['id']];hits=result['cylinders'];plains=set();contains_free=False
  for hit in hits:
   cfg=configs[hit['id']];digits=hit['key_residues'];free=digits.count(None);assert hit['free_residues']==free and hit['key_count']==26**free
   max_free=max(max_free,free);free_cylinders+=bool(free);contains_free|=bool(free)
   for key in probes(digits):
    plain=production.decrypt(case['ciphertext'],cfg['alphabet'],cfg['start'],cfg['direction'],key)
    assert all(plain[int(i)]==v for i,v in case['cribs'].items());assert production.encrypt(plain,cfg['alphabet'],cfg['start'],cfg['direction'],key)==case['ciphertext'];roundtrips+=1
    if not free:plains.add(plain)
  if answer['kind'].startswith('null'):nullfits+=bool(hits);continue
  plants+=1;matching=[h for h in hits if h['id']==answer['config']];assert len(matching)==1;h=matching[0];assert all(v is None or v==answer['key'][i] for i,v in enumerate(h['key_residues']))
  cfg=configs[answer['config']];assert production.decrypt(case['ciphertext'],cfg['alphabet'],cfg['start'],cfg['direction'],answer['key'])==answer['plaintext']
  if answer['kind']=='sparse':assert h['free_residues']==7;sparse+=1
  elif not contains_free and len(plains)==1:assert answer['plaintext'] in plains;full_unique+=1
  else:full_ambiguous+=1
 assert plants==808 and sparse==32 and full_unique+full_ambiguous==776 and nullfits<=1
 return {'status':'PASS','complete_set_agreement_cases':872,'plants_included':plants,'sparse_plants_seven_free':sparse,'fullmask_unique_plaintext':full_unique,'fullmask_ambiguous_or_free':full_ambiguous,'null_any_fits':nullfits,'null_count':64,'returned_free_cylinders':free_cylinders,'max_free_residues':max_free,'checked_roundtrips':roundtrips,'roundtrip_note':'All singleton candidates; canonical/all-ones/single-free-digit1 completions for each free cylinder. Completeness derives from exact equations and tiny forward truth. No summed union volume.','cpu_seconds':time.process_time()-started}
if __name__=='__main__':
 root=pathlib.Path(sys.argv[1]);result=analyze(root);(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
