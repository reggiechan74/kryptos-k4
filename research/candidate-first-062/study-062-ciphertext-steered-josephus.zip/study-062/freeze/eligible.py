def restrict(hits):
 out=[];removed=[]
 for hit in hits:
  zero_possible=all(v in (None,0) for v in hit['key_residues'])
  count=hit['key_count']-int(zero_possible)
  if count:
   out.append({**hit,'cartesian_key_count':hit['key_count'],'key_count':count,'excluded_zero_key':zero_possible})
  else:removed.append(hit)
 return out,removed
