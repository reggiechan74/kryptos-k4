import runpy,sys
if __name__=='__main__':
 sys.argv.insert(1,'reference')
 runpy.run_module('target_adapter',run_name='__main__')
