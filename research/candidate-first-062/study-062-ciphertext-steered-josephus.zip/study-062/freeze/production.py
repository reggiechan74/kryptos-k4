"""Study062 ciphertext-steered Josephus; sorted alive-list implementation."""
import json,sys
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KR='KRYPTOSABCDEFGHIJLMNQUVWXZ';ALPHABETS=(AZ,KR)
def route(ciphertext,alphabet,start,direction):
 alive=list(range(len(ciphertext)));cursor=start;out=[]
 for char in ciphertext:
  out.append(alive.pop(cursor))
  if alive:cursor=(cursor+(0 if direction==1 else -1)+direction*(1+alphabet.index(char)))%len(alive)
 return out
def encrypt(plaintext,alphabet,start,direction,key):
 alive=list(range(len(plaintext)));cursor=start;out=[]
 for t in range(len(plaintext)):
  i=alive.pop(cursor);value=(alphabet.index(plaintext[i])+key[t%len(key)])%len(alphabet);out.append(alphabet[value])
  if alive:cursor=(cursor+(0 if direction==1 else -1)+direction*(1+value))%len(alive)
 return ''.join(out)
def decrypt(ciphertext,alphabet,start,direction,key):
 plain=['']*len(ciphertext)
 for t,i in enumerate(route(ciphertext,alphabet,start,direction)):plain[i]=alphabet[(alphabet.index(ciphertext[t])-key[t%len(key)])%len(alphabet)]
 return ''.join(plain)
def requirements(ciphertext,cribs,alphabet,route_map):
 known={int(i):alphabet.index(c) for i,c in cribs.items()};return [(t,(alphabet.index(ciphertext[t])-known[i])%len(alphabet)) for t,i in enumerate(route_map) if i in known]
def from_requirements(reqs,period,n=26):
 digits=[None]*period
 for t,k in reqs:
  j=t%period
  if digits[j] is not None and digits[j]!=k:return None
  digits[j]=k
 free=digits.count(None);return {'key_residues':digits,'free_residues':free,'key_count':n**free}
def cylinder(ciphertext,cribs,alphabet,start,direction,period):return from_requirements(requirements(ciphertext,cribs,alphabet,route(ciphertext,alphabet,start,direction)),period,len(alphabet))
def configurations(length=97):
 for a,alphabet in enumerate(ALPHABETS):
  for start in range(length):
   for direction in [1,-1]:
    for period in range(1,9):yield {'id':f'J:{a}:{start}:{direction}:{period}','alphabet':alphabet,'start':start,'direction':direction,'period':period}
def solve(case):
 C=case['ciphertext'];out=[]
 for a,A in enumerate(ALPHABETS):
  for start in range(len(C)):
   for d in [1,-1]:
    req=requirements(C,case['cribs'],A,route(C,A,start,d))
    for p in range(1,9):
     fit=from_requirements(req,p)
     if fit is not None:out.append({'id':f'J:{a}:{start}:{d}:{p}',**fit})
 return out
if __name__=='__main__':
 with open(sys.argv[2],'w') as f:
  for case in json.load(open(sys.argv[1])):f.write(json.dumps({'id':case['id'],'complete':True,'structural_cases_examined':32*len(case['ciphertext']),'cylinders':solve(case)},sort_keys=True)+'\n')
