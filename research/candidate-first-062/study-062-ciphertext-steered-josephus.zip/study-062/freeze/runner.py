import json,sys,subprocess,time,resource,pathlib,os

def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(180,180))
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
if __name__=='__main__':
    script,inputs,output,receipt=sys.argv[1:]
    start=time.monotonic(); own=time.process_time();before=resource.getrusage(resource.RUSAGE_CHILDREN);status='not-started';err=None;code=None
    try:
        p=subprocess.run([sys.executable,script,inputs,output],capture_output=True,text=True,timeout=300,preexec_fn=limits)
        code=p.returncode;status='completed' if code==0 else 'failed';err=p.stderr
    except BaseException as e:
        status='failed';err=repr(e)
    finally:
        after=resource.getrusage(resource.RUSAGE_CHILDREN)
        record={'status':status,'returncode':code,'stderr':err,'wall_seconds':time.monotonic()-start,'child_cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'parent_cpu_seconds':time.process_time()-own,'child_max_rss_kib':after.ru_maxrss,'parent_max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'command':[sys.executable,script,inputs,output],'cpu_limit_seconds':180,'as_limit_bytes':512*1024**2,'wall_limit_seconds':300}
        pathlib.Path(receipt).write_text(json.dumps(record,indent=2))
    if status!='completed':sys.exit(1)
