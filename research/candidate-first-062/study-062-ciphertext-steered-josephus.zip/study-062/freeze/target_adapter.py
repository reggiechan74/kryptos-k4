import json,sys,production,reference,eligible
if __name__=='__main__':
 engine,path,out=sys.argv[1:];assert engine in ('production','reference')
 solver=production.solve if engine=='production' else reference.solve
 with open(out,'w') as f:
  for case in json.load(open(path)):
   hits,excluded=eligible.restrict(solver(case))
   f.write(json.dumps({'id':case['id'],'complete':True,'structural_cases_examined':3104,'eligible_key_domain':'Z26^p excluding all-zero vector; emission-index phase0','cylinders':hits,'prior_covered_zero_key_candidates_not_counted':excluded},sort_keys=True)+'\n')
