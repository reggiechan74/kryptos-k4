"""Study062 eligibility only; never reads plaintext clues or solves keys."""
import json,pathlib,hashlib,gzip,time,resource
ROOT=pathlib.Path(__file__).resolve().parents[1];SOURCES=ROOT/'eligibility/local-sources'
A={'AZ':'ABCDEFGHIJKLMNOPQRSTUVWXYZ','KR':'KRYPTOSABCDEFGHIJLMNQUVWXZ'}
def route(C,alphabet,start,d):
 alive=list(range(len(C)));cursor=start;out=[]
 for char in C:
  out.append(alive.pop(cursor))
  if alive:cursor=(cursor+(0 if d==1 else -1)+d*(1+alphabet.index(char)))%len(alive)
 return out

def inv(p):
 q=[0]*len(p)
 for j,i in enumerate(p):q[i]=j
 return tuple(q)
if __name__=='__main__':
 started=time.process_time();C=json.loads((SOURCES/'k4.json').read_text())['ciphertext'];out=[]
 for label,alphabet in A.items():
  for start in range(len(C)):
   for d in [1,-1]:
    p=route(C,alphabet,start,d);assert sorted(p)==list(range(97))
    out.append({'alphabet':label,'start':start,'direction':d,'output_to_input':p,'key_periods':list(range(1,9)),'key_domain':'allZ26^p exceptzero; emission-index phase0; additive after selectedplaintext'})
 (ROOT/'eligibility/target-routes.json').write_text(json.dumps({'ciphertext_sha256':hashlib.sha256(C.encode()).hexdigest(),'crib_constraints_evaluated':False,'routes':out},indent=2)+'\n')
 checks=[]
 for name in ['ROUTE-001.json.gz','ENE-ROUTE-049-CATALOGUE.json.gz','HAND-GRAMMAR-050-CATALOGUE.json.gz']:
  raw=(SOURCES/name).read_bytes();d=json.loads(gzip.decompress(raw));cat=d['route_catalogue'] if isinstance(d,dict) else d
  routes={tuple(e['permutation']) if 'permutation' in e else tuple(bytes.fromhex(e['signature_hex'])[:97]) for e in cat};routes|={inv(p) for p in routes}
  hits=[{k:x[k] for k in ['alphabet','start','direction']} for x in out if tuple(x['output_to_input']) in routes]
  checks.append({'source':name,'source_sha256':hashlib.sha256(raw).hexdigest(),'distinct_routes_with_inverse_superset':len(routes),'matches':hits})
 positives=0
 for width in range(2,98):
  columns=[tuple(range(c,97,width)) for c in range(width)]
  def member(p):
   unused=set(range(width));at=0
   while at<97:
    possible=[c for c in unused if p[at:at+len(columns[c])]==columns[c]]
    if len(possible)!=1:return False
    c=possible[0];unused.remove(c);at+=len(columns[c])
   return not unused
  for order in [list(range(width)),list(reversed(range(width)))]:assert member(tuple(i for c in order for i in columns[c]));positives+=1
  hits=[{**{k:x[k] for k in ['alphabet','start','direction']},'map_orientation':orientation} for x in out for orientation,p in [('forward',tuple(x['output_to_input'])),('inverse',inv(x['output_to_input']))] if member(p)]
  if hits:checks.append({'source':'all-order-columnar-superset','column_width':width,'matches':hits})
 mask=[(0,c) for c in range(27,31)]+[(r,c) for r in range(1,4) for c in range(31)];lookup={cell:i for i,cell in enumerate(mask)}
 occupied=[tuple(lookup[r,c] for c in list(range(31))[::h] for r in list(range(4))[::v] if (r,c) in lookup) for h in (1,-1) for v in (1,-1)]
 def up(w):return [r*w+c for c in range(w) for r in reversed(range((97+w-1)//w)) if r*w+c<97]
 a,b=up(42),up(14)
 for name,routes in [('occupied-cell',occupied),('k3-clock',[tuple(a[i] for i in b)])]:
  routes=set(routes)|{inv(p) for p in routes};checks.append({'source':name,'matches':[{k:x[k] for k in ['alphabet','start','direction']} for x in out if tuple(x['output_to_input']) in routes]})
 prior=json.loads((SOURCES/'061-target-routes.json').read_text())['routes'];priorroutes={tuple(x['output_to_input']) for x in prior};checks.append({'source':'study061targetmaps','matches':[{k:x[k] for k in ['alphabet','start','direction']} for x in out if tuple(x['output_to_input']) in priorroutes]})
 result={'checks':checks,'column_positive_checks':positives,'distinct_target_permutations':len({tuple(x['output_to_input']) for x in out}),'cpu_seconds':time.process_time()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'target_key_constraints_evaluated':False}
 (ROOT/'eligibility/local-route-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='checks'}));print([(x['source'],x.get('column_width'),len(x['matches'])) for x in checks])
