# Study 062 EXT012 route-domain check

The unchanged independently authored 061 comparator was adapted only to the new target-route file and start/orientation metadata. All 388 Josephus target routes and their inverses are absent from the 18,225 convention-robust single/two-route compositions (13,199 distinct) in the declared EXT012 domain. No crib equations or cipher candidate was evaluated.

Comparison receipt and target hash: `comparison.json`. Measured CPU 0.11480153 seconds, wall 0.11693627 seconds, maximum RSS 25,718,784 bytes. Source-domain proof is retained in `HISTORICAL-061-SOURCE-AUDIT.md` and `universe-reconstruction.json`; full 484-spec historical universe hash matches its recorded receipt. The historical executable revision remains unavailable and code-semantic uncertainty is explicitly retained. Third-party source content is not bundled; historical source manifest and pinned links identify it.

A coordination race caused another worker to perform the same route-only comparison. Both receipts and CPU charges are retained as redundant confirmation; they do not add model coverage and are not K4 cipher-search trials.
