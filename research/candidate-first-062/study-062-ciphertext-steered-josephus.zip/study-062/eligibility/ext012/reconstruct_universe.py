"""Own declarative serialization reconstruction; external modules not imported."""
import json,hashlib,itertools,math,time,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024));t=time.monotonic();c=time.process_time();root=Path(__file__).parent
hist=json.loads((root/'historical-summary.json').read_text());words=hist['keywords']
def param(n,v):return dict(name=n,values=v,start=None,stop=None,source_corpus=None,cardinality_cap=10000)
def layer(k,a='AZ',params=[]):return dict(kind=k,alphabet=a,params=params,recipe_id=None)
trans={'columnar':layer('columnar',params=[param('keyword',words)]),'rail_fence':layer('rail_fence',params=[param('depth',[3,4,5,7])]),'reverse_blocks':layer('reverse_blocks',params=[param('block_size',[4,6,7,9])]),'route_boustrophedon':layer('route_boustrophedon',params=[param('width',[6,7,8,9,10,11])]),'route_diagonal':layer('route',params=[param('variant',['diagonal_canonical']),param('width',[6,7,8,9,10,11])]),'skip_route':layer('skip_route',params=[param('step',[2,3,5,7,9,11,13]),param('offset',[0,1,2,3,4])])}
subs=[(f,a,layer(f,a,[param('keyword',words)])) for f in ['vigenere','beaufort','variant_beaufort'] for a in ['AZ','KA']]+[('atbash','AZ',layer('atbash')),('caesar','AZ',layer('caesar',params=[param('shift',list(range(1,26)))]))]
def card(pipe):return math.prod(len(p['values']) for l in pipe for p in l['params'])
specs=[]
def add(name,pipe):
 if card(pipe)>2000:return
 specs.append(dict(hypothesis_id=name,pipeline=pipe,crib_alignment='free',scoring='crib_plus_bean',null_baseline=dict(method='shuffled_ct',n_samples=64,cache_key=None),information_gain_bits_estimate=0.0,success_criteria={},kill_criteria={},compute_budget_cpu_minutes=10,checkpoint_every_sec=60,assumption_bundle=['az_a0','transposed','no_null_mask','non_direct_alignment','crib_alignment_free_detection_level','fixed_len_97_stream'],notes='',override_exhaustion=False,override_justification=''))
for tf,tl in trans.items():
 for sf,alph,sl in subs:
  tag=f'{tf}-{sf}-{alph}'.lower();add(f'solver-{tag}-subfirst-free',[sl,tl]);add(f'solver-{tag}-transfirst-free',[tl,sl])
n0=len(specs);c0=sum(card(s['pipeline']) for s in specs)
for t1,t2 in itertools.permutations(trans,2):
 for sf,alph,sl in subs:
  tag=f'{t1}-{t2}-{sf}-{alph}'.lower();add(f'solver3-{tag}-subouter-free',[sl,trans[t1],trans[t2]]);add(f'solver3-{tag}-submid-free',[trans[t1],sl,trans[t2]])
h=hashlib.sha256(json.dumps(specs,sort_keys=True).encode()).hexdigest()
index={s['hypothesis_id']:s for s in specs};mismatch=[]
for old in hist['per_spec']:
 s=index.get(old['hypothesis_id']);digest=hashlib.sha256(json.dumps(s,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:16]
 if not s or digest!=old['spec_hash'] or card(s['pipeline'])!=old['tested']:mismatch.append(old['hypothesis_id'])
r=dict(status='PASS_HISTORICAL_UNIVERSE_EXACT' if h==hist['universe_sha256'] and not mismatch else 'MISMATCH',round0_specs=n0,round0_configs=c0,round1_specs=len(specs)-n0,round1_configs=sum(card(s['pipeline']) for s in specs)-c0,n_specs=len(specs),total_configs=sum(card(s['pipeline']) for s in specs),universe_sha256=h,historical_universe_sha256=hist['universe_sha256'],per_spec_mismatches=mismatch,cpu_seconds=time.process_time()-c,wall_seconds=time.monotonic()-t,max_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,external_code_executed=False,target_cipher_trials=0)
(root/'universe-reconstruction.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
