# EXT-012 route-domain audit for study 061

Date: 31 October 2026. **PASS_ROUTE_DISJOINT** for the documented default route universe. This is independently implemented permutation membership, not a K4 cipher/key/crib test and not external-code execution.

## Source scope

Repository `jcolinpatrick/kryptos`, inspected immutable public pin `6dfc420d65432988be524e0992c1735a4c466b1e`. Source copies retained here:

- `kryptosbot/solver.py`: `_k4_ingredients` uses 12 named keywords, no number hints; `_trans_layer` selects defaults; `_three_layer_specs` composes two distinct transposition families, with substitution outer/middle. Cardinality filtering removes some specifications.
- `kryptosbot/job_dispatcher.py`: exact keyword-columnar ranking, default partial-block reversal, horizontal ragged boustrophedon, modular skip mapping and canonical diagonal translation.
- `src/kryptos/kernel/transforms/transposition.py`: explicit rail, column and diagonal definitions.
- `scripts/campaigns/f_solver_free_alignment_2026_06_11.py`: real-K4 campaign builds rounds 0 and 1 with 12 keywords and the free matcher.
- `docs/campaigns/solver_free_alignment_2026_06_11.md`: dated preregistered scope.

Primary URLs use `https://github.com/jcolinpatrick/kryptos/blob/6dfc420d65432988be524e0992c1735a4c466b1e/` plus each path above. The published final receipt reports run shortref `f98ce14`, but retrieving that ref returned HTTP404/no commit found. Thus this audit pins the inspectable source and its documented defaults; it does not claim byte-for-byte recovery of the unavailable historical execution revision or independently endorse every reported exclusion. No external source was executed.

## Exact reconstructed domains

At length 97, the 67 primitive descriptions are:

- Columnar from KRYPTOS, PALIMPSEST, ABSCISSA, BERLIN, CLOCK, LANGLEY, NORTHEAST, SHADOW, FORCES, LUCID, MEMORY, IQLUSION; stable letter/index ranking.
- Zigzag rail fence depths 3,4,5,7.
- Reverse consecutive blocks of sizes 4,6,7,9, including ragged tail.
- Horizontal boustrophedon widths 6,7,8,9,10,11; reverse odd-indexed rows.
- Canonical anti-diagonal widths 6,7,8,9,10,11; sort occupied cells by increasing row+column, then increasing row.
- Skip step 2,3,5,7,9,11,13 and offset 0,1,2,3,4; map j to (j-offset)/step modulo97.

The independently authored comparator deliberately checks a **superset**: every primitive and its inverse, plus identity (135 labelled maps), and every ordered pair, including same-family pairs and any specifications removed by the source cardinality limit. This covers single routes and every documented two-route composition without needing to reproduce their key scoring or substitution-position choices.

Each route is represented by output-to-input indices. Composition is q[i]=a[b[i]]. Both target orientations are checked. Every generated permutation passes exact bijectivity/inverse checks; elementary columnar, rail and diagonal hand vectors are checked in code. No target crib values or key consistency constraints are loaded.

## Result and resource accounting

`comparison.json`: 18,225 descriptive route-composition checks, 13,199 distinct maps, **zero matches** to any of the 20 target-induced maps or their inverses. Target-source SHA256 `3606b95519a72700f199fb25483070a39df968e776dff1478131895241065c6b`. Therefore no route-plus-key-domain overlap with the documented EXT-012 default two/three-layer campaign is located; its finite 12-keyword/constant-shift subset cannot supply an identical route cell here. This does not mean unrelated plaintext coincidences are impossible or that all other transposition campaigns are covered.

Measured process CPU 0.112183859 seconds, monotonic wall 0.115676609 seconds, peak RSS 23,724,032 bytes. Hard CPU cap120seconds, address-space cap512MiB. These are membership checks, not cipher trial totals. Only one comparator run was executed. Source retrieval/read preparation is separate non-search work.

Reproduce with `python3 compare.py` while the study061 target-route file remains at the recorded location. The file is a route artifact, not secret data. The receipt hashes all read Python sources and the independent comparator. The source map and original report should remain alongside the frozen061 evidence.

## Historical-universe reconstruction supplement

The retained `historical-summary.json` gives the full old commit `f98ce14435d0f7c025e89bebcbf1e393c34ac4aa`, also unavailable by public retrieval. Crucially, it contains the full universe digest and all484 per-spec identifiers/hashes/tested counts. The independently written `reconstruct_universe.py` rebuilds the declared serialized specifications from the inspected schema/defaults WITHOUT importing or executing external modules. It obtains:

- Round0:96 specifications,13,132 configurations.
- Round1:388 specifications,237,216 configurations.
- Total484/250,348, every per-spec hash and cardinality identical.
- Full universe SHA256 `468923810eab9775145281e8e9a3eb470f4211589bfe691e2bdd249c58c2300a`, **exactly identical to the historical frozen receipt**.

Therefore the historical parameter values, keywords, family/order/default selection and cardinality gates are hash-confirmed, rather than a speculative inference from matching totals. The route-disjointness superset covers this precise declared universe. The unavailable historical executable revision remains a limitation on validating what that old implementation actually did; this audit does not endorse its numerical cryptanalytic result. It does not leave an unexplained larger historical parameter range.

One supplementary metadata-reconstruction run used0.021116924 CPU seconds,0.022214512 wall seconds and12,189,696 peak RSS bytes, under the same120CPU-second/512MiB limits. Combined independently measured comparator+metadata CPU is0.133300783seconds. No target cipher/crib trial occurred in either run. Both original receipts remain separate; the initial comparator was not rerun.
