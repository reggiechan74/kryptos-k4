"""Independent route-only realizations of pinned fixed and artifact deletion families."""
import json,itertools,math,time,resource,hashlib
from pathlib import Path
root=Path(__file__).parent;t0=time.process_time();w0=time.monotonic();N=97
raw=Path('/workspace/shared/candidate-first-062/eligibility/target-routes.json').read_bytes();data=json.loads(raw);targets={tuple(r['output_to_input']):(r['alphabet'],r['start'],r['direction']) for r in data['routes']};counts={};hits=[]
def inverse(q):
 p=[0]*len(q)
 for i,j in enumerate(q):p[j]=i
 return tuple(p)
def check(q,f,l):
 assert sorted(q)==list(range(N));counts[f]=counts.get(f,0)+2
 for direction,p in [('forward',tuple(q)),('inverse',inverse(q))]:
  if p in targets:hits.append({'family':f,'label':l,'direction':direction,'target':targets[p]})
def fixed(n,k,start):
 remaining=list(range(n));j=start;out=[]
 while remaining:
  j=(j+k-1)%len(remaining);out.append(remaining.pop(j))
 return out
def alternate(steps,first,n=97):
 remaining=list(range(n));j=0;out=[];right=first=='R'
 for t in range(n):
  step=steps[t%len(steps)];j=(j+step-1 if right else j-step)%len(remaining);out.append(remaining.pop(j));right=not right
  if remaining:j%=len(remaining)
 return out
def additive(steps,start,plus,n=97):
 remaining=list(range(n));j=start;out=[]
 for t in range(n):
  j=(j+steps[t%len(steps)]+plus)%len(remaining);out.append(remaining.pop(j))
 return out
# Independent linked-list control, counting through original slots rather than list-index arithmetic.
def linked_fixed(n,k,start):
 live=set(range(n));p=start;out=[]
 while live:
  for _ in range((k-1)%len(live)):
   p=(p+1)%n
   while p not in live:p=(p+1)%n
  out.append(p);live.remove(p)
  if live:
   p=(p+1)%n
   while p not in live:p=(p+1)%n
 return out
checks=0
for n in range(1,11):
 for k in range(1,15):
  for s in range(n):assert fixed(n,k,s)==linked_fixed(n,k,s);checks+=1
for k in range(2,98):
 for s in range(97):check(fixed(97,k,s),'Scott fixed Josephus',[k,s])
for a in range(2,97):
 for c in range(97):check([(a*i+c)%97 for i in range(97)],'Scott affine97',[a,c])
for n in [98,100,104]:
 for a in range(2,n):
  if math.gcd(a,n)!=1:continue
  for c in range(n):check([x for i in range(n) if (x:=(a*i+c)%n)<97],'Scott larger-circle',[n,a,c])
for length,hi in [(1,97),(2,97),(3,26),(4,12)]:
 for steps in itertools.product(range(1,hi+1),repeat=length):
  for first in ['L','R']:check(alternate(steps,first),'Zeye alternating',[steps,first])
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KA='KRYPTOSABCDEFGHIJLMNQUVWXZ'
special=[(24,0,17),(25,1,18),(2,7,1),(3,8,2),(16,20,0,4),(17,21,1,5),(11,14,4,8),(12,15,5,9),tuple(KA.index(c) for c in 'QUAE'),tuple(KA.index(c) for c in 'LOEI')]+[tuple((a.index(b)-a.index(c))%26 for c,b in [('L','Q'),('O','U'),('E','A'),('I','E')]) for a in [AZ,KA]]
combos=set()
for t in special:
 for p in itertools.permutations(x if x>0 else 26 for x in t):
  for k in range(4):combos.add(tuple(x+26*k for x in p))
for steps in sorted(combos):
 for first in ['L','R']:check(alternate(steps,first),'Zeye literal extras',[steps,first])
word='KRYPTOS';enc=[[AZ.index(c) for c in word],[AZ.index(c)+1 for c in word],[KA.index(c)+1 for c in word],[(AZ.index(b)-AZ.index(a))%26 for a,b in zip(word,word[1:]+word[0])],[min((AZ.index(b)-AZ.index(a))%26,(AZ.index(a)-AZ.index(b))%26) for a,b in zip(word,word[1:]+word[0])],[AZ.index(c)+1 for c in KA][:7]]
for e,v in enumerate(enc):
 v=[x or 26 for x in v]
 for rv in range(2):
  b=v[::-1] if rv else v
  combos=[tuple(x+26*t for x in b) for t in range(4)]+[tuple(x+26*(len(b)-1-i) for i,x in enumerate(b)),tuple(x+26*(len(b)-i) for i,x in enumerate(b))]
  for k,steps in enumerate(combos):
   for first in ['L','R']:check(alternate(steps,first),'Zeye KRYPTOS step',[e,rv,k,first])
   remaining=list(range(97));q=[]
   for t in range(97):q.append(remaining.pop(steps[t%len(steps)]%len(remaining)))
   check(q,'Zeye KRYPTOS absolute',[e,rv,k])
seqs=[[2,1,6,3,2,2,5,3,1,1],[2,1,6,3,2,2,5,3,1],[3,8,5,7,6,5,7,7,8,4,4],[24,0,17],[25,1,18],[16,20,0],[11,14,4],[AZ.index(c) for c in word]]
for si,steps in enumerate(seqs):
 for plus in [0,1]:
  for s in range(97):check(additive(steps,s,plus),'Zeye artifact Josephus',[si,plus,s])
# All two-monotonic-run maps contain every holes-first/last mask reading regardless of artifact.
mask_survivors=[]
for q,lab in targets.items():
 for direction,p in [('forward',q),('inverse',inverse(q))]:
  if sum(a>b for a,b in zip(p,p[1:]))<=1:mask_survivors.append([lab,direction])
out={'target_routes_sha256':hashlib.sha256(raw).hexdigest(),'target_routes':len(targets),'cipher_or_crib_constraints_evaluated':False,'external_code_executed':False,'fixed_linked_list_controls':checks,'descriptive_counts_with_inverses':counts,'matches':hits,'holes_first_last_superset_survivors':mask_survivors,'cpu_seconds':time.process_time()-t0,'wall_seconds':time.monotonic()-w0,'max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024};(root/'deletion-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
