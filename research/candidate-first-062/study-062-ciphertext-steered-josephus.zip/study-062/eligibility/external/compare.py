"""Independent route-only comparison; never reads clue values or solves keys.
Source algorithms independently transcribed from pinned files named in receipt.
"""
import json,time,hashlib,itertools
from pathlib import Path
root=Path('/workspace/shared/k4-route-source-audit-062')
target=Path('/workspace/shared/candidate-first-062/eligibility/target-routes.json')
data=json.loads(target.read_text()); routes={tuple(r['output_to_input']):(r['alphabet'],r['start'],r['direction']) for r in data['routes']}
def inv(p):
 q=[0]*len(p)
 for j,i in enumerate(p):q[i]=j
 return tuple(q)
counts={};hits=[]
def check(p,f,label):
 p=tuple(p);counts[f]=counts.get(f,0)+2
 for direct,x in [('forward',p),('inverse',inv(p))]:
  if x in routes:hits.append({'family':f,'label':label,'direction':direct,'target':routes[x]})
# Scott route_perms. Each grid traversal is generated independently from coordinates.
for w in range(2,50):
 h=(97+w-1)//w
 traversals=[]
 for major,rf,cf,snake in itertools.product(range(2),repeat=4):
  cells=[]
  for o in range(w if major else h):
   inner=list(range(h if major else w))
   if snake and o%2:inner.reverse()
   for i in inner:
    y,x=(i,o) if major else (o,i)
    cells.append((h-1-y if rf else y,w-1-x if cf else x))
  traversals.append(cells)
 for blanks in ['end','start']:
  valid={(y,x) for y in range(h) for x in range(w) if (y*w+x<97 if blanks=='end' else y*w+x>=h*w-97)}
  orders=[[c for c in t if c in valid] for t in traversals]
  for a,write in enumerate(orders):
   pos={c:i for i,c in enumerate(write)}
   for b,read in enumerate(orders):
    if a!=b:check([pos[c] for c in read],'Scott grid',[w,blanks,a,b])
# Counter: a positional map p[input]=output; both orientations checked anyway.
def groups(gs,ss):
 p=list(range(97))
 for g,s in zip(gs,ss):
  for j,x in enumerate(g):p[x]=g[(j+s)%len(g)]
 return p
for split in range(30,68):
 gs=[list(range(split)),list(range(split,97))]
 for a in range(split):
  for b in range(97-split):check(groups(gs,[a,b]),'Zeye halves',[split,a,b])
gs=[list(range(0,97,2)),list(range(1,97,2))]
for a in range(49):
 for b in range(48):check(groups(gs,[a,b]),'Zeye parity',[a,b])
for w in range(2,25):
 for kind,gs in [('rows',[list(range(s,min(s+w,97))) for s in range(0,97,w)]),('cols',[list(range(c,97,w)) for c in range(w)])]:
  m=max(map(len,gs))
  for a in range(m):
   for b in range(m):check(groups(gs,[a if i%2==0 else -b for i in range(len(gs))]),'Zeye gear',[w,kind,a,b])
# Complete Myszkowski membership by partitioning columns into rank groups.
# Every group emits the row-major subsequence in those columns; group order arbitrary.
def mysz(p,w):
 from functools import lru_cache
 chunks={mask:tuple(i for i in range(97) if mask>>(i%w)&1) for mask in range(1,1<<w)}
 @lru_cache(None)
 def rec(remaining,at):
  if not remaining:return () if at==97 else None
  mask=remaining
  while mask:
   chunk=chunks[mask]
   if p[at:at+len(chunk)]==chunk:
    tail=rec(remaining^mask,at+len(chunk))
    if tail is not None:return (mask,)+tail
   mask=(mask-1)&remaining
  return None
 return rec((1<<w)-1,0)
myhits=[]
for p,label in routes.items():
 for direction,q in [('forward',p),('inverse',inv(p))]:
  for w in range(3,10):
   match=mysz(q,w)
   if match is not None:myhits.append({'target':label,'direction':direction,'width':w,'rank_groups':match})
# Tiny exhaustive membership validation, every weak order is covered by ordered set partitions.
# Generic full n97 formulas directly checked on known all-tied and distinct-ranked examples.
for w in range(3,10):
 assert mysz(tuple(range(97)),w) is not None
 assert mysz(tuple(i for c in range(w) for i in range(c,97,w)),w) is not None
out={'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'target_routes_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'crib_values_read':False,'key_constraints_evaluated':False,'target_routes':len(routes),'comparison':'Exact full97-position tuples, each prior map plus inverse; descriptive counts retain aliases','descriptive_counts':counts,'matches':hits,'myszkowski_all_weak_orders_widths':[3,9],'myszkowski_matches':myhits,'myszkowski_known_positive_checks':14,'sources_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.py')},'remaining':'Other external families not automatically covered by these comparisons; see source-map report.'}
(root/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
