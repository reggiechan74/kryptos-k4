// Independent route-membership comparison only, no ciphertext/crib/key values.
#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc,char**argv){vector<array<int,97>>ts;ifstream in(argc>1?argv[1]:"/workspace/shared/k4-route-source-audit-062/maps.txt");array<int,97>x;while(in>>x[0]){for(int i=1;i<97;i++)in>>x[i];ts.push_back(x);}long long count=0;int hits=0;
for(int w=5;w<=10;w++){vector<int>o(w);for(int i=0;i<w;i++)o[i]=i;do{for(int gap=0;gap<=1;gap++){int rows=(97+w-1)/w;bool D[100][12]={};int s=0;for(int t=0;t<w;t++){int c=o[t];if(s>=rows)break;for(int j=0;j<w-c;j++)if(s+j<rows)for(int k=c+j;k<w;k++)D[s+j][k]=true;s+=w-c+gap;}int pos[100][12],v=0;for(int dis=0;dis<=1;dis++)for(int i=0;i<97;i++)if(D[i/w][i%w]==bool(dis))pos[i/w][i%w]=v++;
array<int,97>q,m;int z=0;for(int c:o)for(int r=0;r<rows;r++)if(r*w+c<97)q[z++]=pos[r][c];for(int i=0;i<97;i++)m[q[i]]=i;count+=2;for(int t=0;t<(int)ts.size();t++){if(q==ts[t]||m==ts[t]){cout<<"MATCH "<<t<<" width "<<w<<" gap "<<gap<<"\n";hits++;}}}}while(next_permutation(o.begin(),o.end()));}
cout<<"descriptive_maps "<<count<<" matches "<<hits<<"\n";
}
