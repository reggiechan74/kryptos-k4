from pathlib import Path
import shutil,json
old=Path('/workspace/shared/k4-route-source-audit');new=Path('/workspace/shared/k4-route-source-audit-062')
for name in ['compare.py','supplement.py','disrupted.cpp','column_grille.cpp','validate_membership.py','validate_myszkowski_invariant.py']:
 s=(old/name).read_text().replace('/workspace/shared/k4-route-source-audit','/workspace/shared/k4-route-source-audit-062').replace('/workspace/shared/candidate-first-061/','/workspace/shared/candidate-first-062/').replace("(r['alphabet'],r['width'])","(r['alphabet'],r['start'],r['direction'])").replace("[r['alphabet'],r['width']]","[r['alphabet'],r['start'],r['direction']]");(new/name).write_text(s)
s=Path('/workspace/shared/k4-ext012-route-audit/compare.py').read_text().replace('/workspace/shared/candidate-first-061/','/workspace/shared/candidate-first-062/').replace("'width':r['width']","'start':r['start'],'removal_direction':r['direction']").replace("root/'comparison.json'","root/'ext012-comparison.json'");(new/'compare_ext012.py').write_text(s)
r=json.load(open('/workspace/shared/candidate-first-062/eligibility/target-routes.json'))['routes'];(new/'maps.txt').write_text('\n'.join(' '.join(map(str,x['output_to_input'])) for x in r)+'\n')
