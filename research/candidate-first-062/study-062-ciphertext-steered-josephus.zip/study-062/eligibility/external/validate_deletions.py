"""Independent direct-index versus circular-link removal truth checks, synthetic only."""
import itertools,json,time,resource
from pathlib import Path
start=time.process_time();cases=0

def by_list(n,steps,first,mode):
 ring=list(range(n));out=[];p=0;d=first
 for t in range(n):
  v=steps[t%len(steps)]
  p=(p+v-1 if d else p-v)%len(ring) if mode=='alternate' else (p+v)%len(ring)
  out.append(ring.pop(p));d=not d
  if ring:p%=len(ring)
 return out

def by_links(n,steps,first,mode):
 nxt=[(i+1)%n for i in range(n)];prev=[(i-1)%n for i in range(n)];out=[];p=0;d=first
 for t in range(n):
  v=steps[t%len(steps)];remaining=n-t
  if mode=='alternate':
   links=nxt if d else prev;advance=(v-1 if d else v)%remaining
  else:links=nxt;advance=v%remaining
  for _ in range(advance):p=links[p]
  out.append(p);a,b=prev[p],nxt[p];nxt[a]=b;prev[b]=a;p=b;d=not d
 return out
for n in range(1,10):
 for length in range(1,5):
  for steps in itertools.product(range(5),repeat=length):
   for d in [False,True]:
    for mode in ['alternate','additive']:
     assert by_list(n,steps,d,mode)==by_links(n,steps,d,mode),(n,steps,d,mode)
     cases+=1
out={'status':'PASS','complete_tiny_cases':cases,'n':[1,9],'step_tuple_lengths':[1,4],'step_values':[0,4],'modes':['alternate','additive'],'target_data_read':False,'cpu_seconds':time.process_time()-start,'max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024};Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
