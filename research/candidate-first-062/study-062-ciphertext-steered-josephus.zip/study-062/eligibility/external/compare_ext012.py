"""Independent permutation-only coverage superset; no cipher or crib solver."""
import json,time,resource,hashlib
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
start=time.monotonic();cpu=time.process_time();root=Path(__file__).parent
N=97;I=tuple(range(N)); groups={}
words='KRYPTOS PALIMPSEST ABSCISSA BERLIN CLOCK LANGLEY NORTHEAST SHADOW FORCES LUCID MEMORY IQLUSION'.split()
def inv(q):
 out=[None]*len(q)
 for j,i in enumerate(q):out[i]=j
 return tuple(out)
def add(fam,label,q):
 q=tuple(q);assert sorted(q)==list(I)
 groups.setdefault(fam,[]).append((label,q))
for word in words:
 w=len(word); cols=sorted(range(w),key=lambda j:(word[j],j))
 add('columnar',word,[i for c in cols for i in range(c,N,w)])
for d in (3,4,5,7):
 cycle=2*(d-1)
 add('rail',str(d),sorted(I,key=lambda i:min(i%cycle,cycle-i%cycle)))
for m in (4,6,7,9):add('reverse',str(m),[i for b in range(0,N,m) for i in reversed(range(b,min(b+m,N)))])
for w in (6,7,8,9,10,11):
 add('boustro',str(w),[i for b in range(0,N,w) for i in (range(b,min(b+w,N)) if b//w%2==0 else reversed(range(b,min(b+w,N))))])
 add('diagonal',str(w),sorted(I,key=lambda i:(i//w+i%w,i//w)))
for step in (2,3,5,7,9,11,13):
 for offset in (0,1,2,3,4):add('skip',f'{step}/{offset}',[((j-offset)*pow(step,-1,N))%N for j in I])
# Convention-robust superset: both each primitive and its inverse; all pairs,
# even same-family pairs and cardinality-pruned specs, plus identity.
base=[('identity',I)]
for f,items in groups.items():
 for label,q in items:
  base.extend([(f+':'+label,q),(f+':'+label+':inverse',inv(q))])
assert len(base)==135
# Independent primitive checks on hand-computable small examples via direct formulas.
assert [i for c in sorted(range(3),key=lambda j:('CAB'[j],j)) for i in range(c,7,3)]==[1,4,2,5,0,3,6]
assert sorted(range(7),key=lambda i:min(i%4,4-i%4))==[0,4,1,3,5,2,6]
assert sorted(range(7),key=lambda i:(i//3+i%3,i//3))==[0,1,3,2,4,6,5]
for _,q in base:assert tuple(q[inv(q)[i]] for i in I)==I
raw=Path('/workspace/shared/candidate-first-062/eligibility/target-routes.json').read_bytes();target=json.loads(raw)
wanted={}
for r in target['routes']:
 for direction,q in [('forward',tuple(r['output_to_input'])),('inverse',inv(r['output_to_input']))]:wanted.setdefault(q,[]).append({'alphabet':r['alphabet'],'start':r['start'],'removal_direction':r['direction'],'direction':direction})
hits=[];seen=set();count=0
for la,a in base:
 for lb,b in base:
  q=tuple(a[b[i]] for i in I);count+=1;seen.add(q)
  if q in wanted:hits.append({'first':la,'second':lb,'matches':wanted[q]})
r={'status':'PASS_ROUTE_DISJOINT' if not hits else 'OVERLAP','target_source_sha256':hashlib.sha256(raw).hexdigest(),'target_crib_constraints_evaluated':False,'external_code_executed':False,'primitive_descriptions':67,'convention_superset_with_identity':len(base),'route_compositions_checked':count,'distinct_superset_routes':len(seen),'matches':hits,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-start,'max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.py')},'interpretation':'No target route equals any one or two default transposition composition, even allowing inverse primitives, same-family pairs and cardinality-pruned descriptions. Therefore no EXT012 keyword/constant-key subset intersects these target route descriptions. This is route membership only, not cryptanalysis or worldwide novelty.'}
(root/'ext012-comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
