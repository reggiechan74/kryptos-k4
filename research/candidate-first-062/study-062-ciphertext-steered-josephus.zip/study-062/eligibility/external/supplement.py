import json,itertools,hashlib,time
from pathlib import Path
root=Path('/workspace/shared/k4-route-source-audit-062');data=json.load(open('/workspace/shared/candidate-first-062/eligibility/target-routes.json'));targets={tuple(r['output_to_input']):(r['alphabet'],r['start'],r['direction']) for r in data['routes']}
def inv(p):
 q=[0]*97
 for j,i in enumerate(p):q[i]=j
 return tuple(q)
# Necessary condition for every Myszkowski map, independent of dictionary.
# All members of a column share one rank group, and each group is emitted in increasing input order.
# Thus no column's output-position interval may straddle an output descent.
my_surv=[]
for p,lab in targets.items():
 for direction,q in [('fwd',p),('inv',inv(p))]:
  pos=inv(q);desc=[j for j in range(96) if q[j]>q[j+1]]
  for w in range(2,97):
   rejected=any(any(min(pos[i] for i in range(c,97,w))<=j<max(pos[i] for i in range(c,97,w)) for j in desc) for c in range(w))
   if not rejected:my_surv.append([lab,direction,w])
# Row-read grille necessary within-turn monotonicity, both map orientations and pad positions.
grille=[]
for p,lab in targets.items():
 for direction,q in [('fwd',p),('inv',inv(p))]:
  m=inv(q)
  for lens in [(25,25,25,22),(22,25,25,25)]:
   offset=0;ok=True
   for n in lens:
    seg=m[offset:offset+n];ok &= all(a<b for a,b in zip(seg,seg[1:]));offset+=n
   if ok:grille.append([lab,direction,lens])
# Cylinder source exact independent realization; m[pt]=ct; test both directions.
hits=[];cnt=0
for w in [12,24]:
 for start in range(w):
  for step in range(1,w):
   seen=[];s=start
   while len(seen)<w:
    c=s
    while c not in seen:seen.append(c);c=(c+step)%w
    s=(s+1)%w
    while s in seen and len(seen)<w:s=(s+1)%w
   for helicity in range(w):
    cols=[[] for _ in range(w)]
    for i in range(97):cols[(i%w+(i//w)*helicity)%w].append(i)
    for mode in range(3):
     q=[]
     for j,c in enumerate(seen):q+=cols[c][::-1] if mode==1 or mode==2 and j%2 else cols[c]
     for x in [tuple(q),inv(q)]:
      cnt+=1
      if x in targets:hits.append([targets[x],w,start,step,helicity,mode])
# Irregular right/keylong row fill, all keys widths2..8 (source complete domain).
ir=[];icount=0
for w in range(2,9):
 for order in itertools.permutations(range(w)):
  for var in ['right','keylong']:
   base,rem=divmod(97,w);long=set(range(w-rem,w)) if var=='right' else set(order[:rem]);lens=[base+(c in long) for c in range(w)]
   cells=[(r,c) for r in range(base+1) for c in range(w) if r<lens[c]];rank={cell:i for i,cell in enumerate(cells)}
   p=tuple(rank[(r,c)] for c in order for r in range(lens[c]))
   for q in [p,inv(p)]:
    icount+=1
    if q in targets:ir.append([targets[q],w,order,var])
out={'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'no_crib_or_key_constraint_evaluated':True,'myszkowski_width2to96_necessary_condition_survivors':my_surv,'row_read_grille_necessary_condition_survivors':grille,'cylinder_descriptions':cnt,'cylinder_matches':hits,'irregular_descriptions':icount,'irregular_matches':ir,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(root/'supplement.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
