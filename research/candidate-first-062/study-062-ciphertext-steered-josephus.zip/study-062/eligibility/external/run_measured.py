import subprocess,time,resource,json,sys
from pathlib import Path
root=Path(__file__).parent;name=sys.argv[1];cmd=sys.argv[2:];t=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
with open(root/(name+'.stdout.txt'),'w') as o,open(root/(name+'.stderr.txt'),'w') as e:r=subprocess.run(cmd,stdout=o,stderr=e)
after=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'command':cmd,'exit_code':r.returncode,'wall_seconds':time.monotonic()-t,'cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'max_child_rss_bytes':after.ru_maxrss*1024,'target_crib_constraints_evaluated':False};(root/(name+'.resource.json')).write_text(json.dumps(report,indent=2)+'\n');print(report)
