import reference as r
import importlib.util,random,json,time,resource
from pathlib import Path
base=Path(__file__).resolve().parents[1];s=importlib.util.spec_from_file_location('production',base/'freeze/production.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
rng=random.Random(6212345);t=time.process_time();count=0
for cfg in r.configurations():
 plain=''.join(rng.choice(r.AZ) for _ in range(97));key=[rng.randrange(26) for _ in range(cfg['period'])];args=(cfg['alphabet'],cfg['start'],cfg['direction']);c=r.encrypt(plain,*args,key)
 assert c==p.encrypt(plain,*args,key)
 assert r.decrypt(c,*args,key)==p.decrypt(c,*args,key)==plain
 assert r.route(c,*args)==p.route(c,*args)
 cribs=dict(enumerate(plain));expected=dict(key_residues=key,free_residues=0,key_count=1)
 assert r.cylinder(c,cribs,*args,cfg['period'])==p.cylinder(c,cribs,*args,cfg['period'])==expected
 count+=1
receipt=dict(status='PASS',settings=count,forward_inverse_route_and_complete_cylinder_agreement=True,synthetic_seed=6212345,cpu_seconds=time.process_time()-t,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False)
(base/'audit/full-domain-comparison-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
