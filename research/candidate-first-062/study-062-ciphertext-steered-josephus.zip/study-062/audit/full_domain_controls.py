import reference as r
import time,json,resource
from pathlib import Path
start=time.process_time();n=0
for cfg in r.configurations():
 p=''.join(r.AZ[(i*i+7*i+cfg['start'])%26] for i in range(97))
 key=[(11*i+cfg['start']+cfg['direction'])%26 for i in range(cfg['period'])]
 c=r.encrypt(p,cfg['alphabet'],cfg['start'],cfg['direction'],key)
 assert r.decrypt(c,cfg['alphabet'],cfg['start'],cfg['direction'],key)==p
 order=r.route(c,cfg['alphabet'],cfg['start'],cfg['direction']);assert sorted(order)==list(range(97))
 hit=r.cylinder(c,dict(enumerate(p)),cfg['alphabet'],cfg['start'],cfg['direction'],cfg['period'])
 assert hit==dict(key_residues=key,free_residues=0,key_count=1)
 # Contradict two different emissions with same residue, leaving first unchanged.
 mask={order[0]:p[order[0]],order[cfg['period']]:cfg['alphabet'][(cfg['alphabet'].index(p[order[cfg['period']]])+1)%26]}
 assert r.cylinder(c,mask,cfg['alphabet'],cfg['start'],cfg['direction'],cfg['period']) is None
 n+=1
receipt=dict(status='PASS',full_domain_settings=n,full_key_recoveries=n,contradiction_controls=n,cpu_seconds=time.process_time()-start,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False)
Path(__file__).with_name('full-domain-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
