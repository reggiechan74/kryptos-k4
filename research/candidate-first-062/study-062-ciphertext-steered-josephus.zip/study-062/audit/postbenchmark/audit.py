import sys,json,hashlib,random,time,resource,datetime,collections
from pathlib import Path
base=Path(__file__).resolve().parents[2];sys.path.insert(0,str(base/'audit'));import reference as r
resource.setrlimit(resource.RLIMIT_CPU,(600,600));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
t=time.process_time()
def read(p):return json.loads((base/p).read_text())
def sha(p):return hashlib.sha256((base/p).read_bytes()).hexdigest()
assert sha('freeze/manifest.json')=='8538c95ffde07c6718435068c96c3d5d8c9a854723f256d08d3629043028e434'
assert sha('benchmark/seal.json')=='047b1f9c6855abb742b8f656e4c736e5e16a3b09ebcbc3d8cf392fc195022825'
manifest=read('freeze/manifest.json');seal=read('benchmark/seal.json')
for prefix,doc in [('',manifest),('benchmark/',seal)]:
 for path,record in doc['files'].items():assert sha(prefix+path)==record['sha256'] and (base/(prefix+path)).stat().st_size==record['bytes']
assert seal['outputs_sealed_before_answers_inspected'] and manifest['created_utc']<seal['created_utc']
cases=read('benchmark/inputs.json');answers=read('benchmark/answers.json')
outputs=[[json.loads(s) for s in (base/f'benchmark/{engine}.jsonl').read_text().splitlines()] for engine in ['production','reference']]
assert outputs[0]==outputs[1] and len(cases)==len(answers)==len(outputs[0])==872
rng=random.Random(int((base/'benchmark/seed.txt').read_text(),16));pairs=[];mask=[*range(21,34),*range(63,74)];literal='EASTNORTHEASTBERLINCLOCK'
def text():return ''.join(rng.choice(r.AZ) for _ in range(97))
configs=list(r.configurations());lookup={x['id']:x for x in configs}
settings=[]
for a in range(2):
 for start in range(97):
  for j,d in enumerate([1,-1]):
   for category,kind in enumerate(['uniform','literal']):
    period=1+(start+3*j+5*a+4*category)%8
    settings.append((lookup[f'J:{a}:{start}:{d}:{period}'],kind))
for a in range(2):
 for k in range(16):settings.append((lookup[f'J:{a}:{7*k%97}:{1 if k%2==0 else -1}:8'],'sparse'))
for cfg,kind in settings:
 p=list(text())
 if kind=='literal':
  for i,c in zip(mask,literal):p[i]=c
 p=''.join(p);key=[rng.randrange(26) for _ in range(cfg['period'])]
 ciphertext=r.encrypt(p,cfg['alphabet'],cfg['start'],cfg['direction'],key)
 order=r.route(ciphertext,cfg['alphabet'],cfg['start'],cfg['direction'])
 positions=[order[i] for i in [0,8,16,24]] if kind=='sparse' else mask
 pairs.append((dict(ciphertext=ciphertext,cribs={str(i):p[i] for i in positions}),dict(kind=kind,config=cfg['id'],key=key,plaintext=p)))
for i in range(64):
 values=literal if i>=32 else ''.join(rng.choice(r.AZ) for _ in mask)
 pairs.append((dict(ciphertext=text(),cribs=dict(zip(map(str,mask),values))),dict(kind='null_literal' if i>=32 else 'null_uniform')))
rng.shuffle(pairs)
assert cases==[dict(id=f'case-{i:04d}',**x) for i,(x,y) in enumerate(pairs)]
assert answers==[dict(id=f'case-{i:04d}',**y) for i,(x,y) in enumerate(pairs)]
counts=collections.Counter();strata=collections.Counter();plantcells=collections.Counter()
for case,answer,out in zip(cases,answers,outputs[0]):
 assert case['id']==answer['id']==out['id'] and out['complete'] and out['structural_cases_examined']==3104
 hits=r.solve(case);assert hits==out['cylinders'];counts['complete_sets']+=1
 fullplaintexts=set();contains_free=False
 for hit in hits:
  cfg=lookup[hit['id']];digits=hit['key_residues'];free=[i for i,v in enumerate(digits) if v is None]
  assert hit['free_residues']==len(free) and hit['key_count']==26**len(free)
  counts['free_cylinders']+=bool(free);contains_free|=bool(free)
  representative=[0 if v is None else v for v in digits];probes=[representative]
  if free:probes.append([1 if v is None else v for v in digits])
  for i in free:
   k=representative.copy();k[i]=1;probes.append(k)
  probes=[list(k) for k in dict.fromkeys(tuple(k) for k in probes)]
  for k in probes:
   p=r.decrypt(case['ciphertext'],cfg['alphabet'],cfg['start'],cfg['direction'],k)
   assert all(p[int(i)]==v for i,v in case['cribs'].items())
   assert r.encrypt(p,cfg['alphabet'],cfg['start'],cfg['direction'],k)==case['ciphertext'];counts['roundtrips']+=1
   if not free:fullplaintexts.add(p)
 if answer['kind'].startswith('null'):
  counts['nulls']+=1;counts['null_fits']+=bool(hits)
 else:
  counts['plants']+=1;plantcells[(answer['config'],answer['kind'])]+=1
  hit=next(x for x in hits if x['id']==answer['config'])
  assert all(v is None or v==answer['key'][i] for i,v in enumerate(hit['key_residues']))
  cfg=lookup[answer['config']];assert r.decrypt(case['ciphertext'],cfg['alphabet'],cfg['start'],cfg['direction'],answer['key'])==answer['plaintext']
  if answer['kind']=='sparse':assert hit['free_residues']==7;counts['sparse_seven_free']+=1
  elif not contains_free and len(fullplaintexts)==1:assert answer['plaintext'] in fullplaintexts;counts['full_unique']+=1
  else:counts['full_ambiguous_or_free']+=1
assert counts['plants']==808 and counts['sparse_seven_free']==32 and counts['nulls']==64 and counts['null_fits']<=1
assert all(plantcells[(cfg['id'],kind)]==1 for cfg,kind in settings if kind!='sparse')
assert counts['full_unique']+counts['full_ambiguous_or_free']==776
assert read('audit/eligibility-result.json')['cylinder_minus_zero_exact']
resources=[read(f'benchmark/{engine}-resource.json') for engine in ['production','reference']]
for rec in resources:
 assert rec['status']=='completed' and rec['returncode']==0 and rec['stderr']==''
 assert rec['child_cpu_seconds']<rec['cpu_limit_seconds']==180 and rec['wall_seconds']<rec['wall_limit_seconds']==300
 assert rec['child_max_rss_kib']*1024<rec['as_limit_bytes']==536870912
receipt=dict(status='PASS_FOR_PARENT_TARGET_REVIEW',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),freeze_sha256=sha('freeze/manifest.json'),seal_sha256=sha('benchmark/seal.json'),frozen_files_verified=len(manifest['files']),fixture_replay_exact=True,counts=dict(counts),benchmark_cpu_seconds=sum(x['child_cpu_seconds']+x['parent_cpu_seconds'] for x in resources),audit_cpu_seconds=time.process_time()-t,audit_max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False,target_authorized=False,limitation='Canonical, all-ones and single-one free-key probes are controls, not exhaustive cylinder enumeration; completeness follows from residue equations and tiny forward truth. No union count across overlapping cylinders.')
(base/'audit/postbenchmark/FINAL-AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
