"""Independent linked-circle study062 implementation, authored before production review.
Route lists original plaintext positions in emission order; key phase is emission index.
"""
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'
class Circle:
 def __init__(self,n):
  self.next={i:(i+1)%n for i in range(n)};self.previous={i:(i-1)%n for i in range(n)};self.remaining=n
 def remove_and_step(self,node,direction,rank):
  right=self.next[node];left=self.previous[node]
  self.next[left]=right;self.previous[right]=left
  del self.next[node];del self.previous[node];self.remaining-=1
  if not self.remaining:return None
  cursor=right if direction==1 else left
  links=self.next if direction==1 else self.previous
  for _ in range((1+rank)%self.remaining):cursor=links[cursor]
  return cursor

def route(ciphertext,alphabet,start,direction):
 ring=Circle(len(ciphertext));cursor=start;order=[]
 for c in ciphertext:
  order.append(cursor);cursor=ring.remove_and_step(cursor,direction,alphabet.index(c))
 return order

def encrypt(plaintext,alphabet,start,direction,key):
 ring=Circle(len(plaintext));cursor=start;out=[]
 for t in range(len(plaintext)):
  rank=(alphabet.index(plaintext[cursor])+key[t%len(key)])%len(alphabet)
  out.append(alphabet[rank]);cursor=ring.remove_and_step(cursor,direction,rank)
 return ''.join(out)

def decrypt(ciphertext,alphabet,start,direction,key):
 out=[None]*len(ciphertext)
 for t,position in enumerate(route(ciphertext,alphabet,start,direction)):
  out[position]=alphabet[(alphabet.index(ciphertext[t])-key[t%len(key)])%len(alphabet)]
 return ''.join(out)

def cylinder_from_route(ciphertext,cribs,alphabet,order,period):
 emission={position:t for t,position in enumerate(order)};requirements={}
 for position,letter in cribs.items():
  t=emission[int(position)];res=t%period;value=(alphabet.index(ciphertext[t])-alphabet.index(letter))%len(alphabet)
  if res in requirements and requirements[res]!=value:return None
  requirements[res]=value
 digits=[requirements.get(i) for i in range(period)];free=digits.count(None)
 return dict(key_residues=digits,free_residues=free,key_count=len(alphabet)**free)

def cylinder(ciphertext,cribs,alphabet,start,direction,period):
 return cylinder_from_route(ciphertext,cribs,alphabet,route(ciphertext,alphabet,start,direction),period)

def configurations(length=97,alphabets=(AZ,KR),periods=range(1,9)):
 for a,A in enumerate(alphabets):
  for start in range(length):
   for direction in (1,-1):
    for p in periods:yield dict(id=f'J:{a}:{start}:{direction}:{p}',alphabet=A,start=start,direction=direction,period=p)

def solve(case,alphabets=(AZ,KR),periods=range(1,9)):
 result=[];cache={}
 for cfg in configurations(len(case['ciphertext']),alphabets,periods):
  k=(cfg['alphabet'],cfg['start'],cfg['direction'])
  if k not in cache:cache[k]=route(case['ciphertext'],*k)
  hit=cylinder_from_route(case['ciphertext'],case['cribs'],cfg['alphabet'],cache[k],cfg['period'])
  if hit is not None:result.append({'id':cfg['id'],**hit})
 return result
