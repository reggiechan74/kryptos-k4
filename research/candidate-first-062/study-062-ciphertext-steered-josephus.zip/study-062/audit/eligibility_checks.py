import sys,json,itertools,time,tempfile,subprocess
from pathlib import Path
base=Path(__file__).resolve().parents[1];sys.path.insert(0,str(base/'freeze'));import eligible,reference
start=time.process_time();count=0
for p in range(1,5):
 for digits in itertools.product([None,0,1,2],repeat=p):
  free=digits.count(None);raw={k for k in itertools.product(range(3),repeat=p) if all(v is None or v==k[i] for i,v in enumerate(digits))};expected=raw-{(0,)*p}
  hit=dict(id='synthetic',key_residues=list(digits),free_residues=free,key_count=3**free);kept,dropped=eligible.restrict([hit])
  if expected:
   assert not dropped and len(kept)==1;got=kept[0]
   actual={k for k in raw if not got['excluded_zero_key'] or any(k)}
   assert actual==expected and got['key_count']==len(expected) and got['cartesian_key_count']==len(raw)
  else:assert kept==[] and dropped==[hit]
  count+=1
case=dict(id='synthetic-only',ciphertext='A'*97,cribs={str(i):'A' for i in range(97)})
expected,dropped=eligible.restrict(reference.solve(case));outputs=[]
with tempfile.TemporaryDirectory() as tmp:
 inp=Path(tmp)/'in.json';inp.write_text(json.dumps([case]))
 for engine in ['production','reference']:
  out=Path(tmp)/(engine+'.jsonl');subprocess.run([sys.executable,str(base/'freeze'/f'target_{engine}.py'),str(inp),str(out)],check=True,cwd=base/'freeze');result=json.loads(out.read_text());assert result['cylinders']==expected and result['prior_covered_zero_key_candidates_not_counted']==dropped;outputs.append(result)
assert outputs[0]==outputs[1]
receipt=dict(status='PASS',exhaustive_patterns=count,alphabet_size=3,periods=[1,2,3,4],cylinder_minus_zero_exact=True,synthetic_wrappers_agree=True,target_evaluated=False,audit_cpu_seconds=time.process_time()-start)
(base/'audit/eligibility-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
