import itertools,json,time,resource,hashlib
from pathlib import Path
import reference as original
import importlib.util
spec=importlib.util.spec_from_file_location('production',Path(__file__).resolve().parents[1]/'freeze/production.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class Compared:
 def encrypt(self,*args):
  x=original.encrypt(*args);assert x==p.encrypt(*args);return x
 def decrypt(self,*args):
  x=original.decrypt(*args);assert x==p.decrypt(*args);return x
 def route(self,*args):
  x=original.route(*args);assert x==p.route(*args);return x
 def cylinder(self,*args):
  x=original.cylinder(*args);assert x==p.cylinder(*args);return x
 def configurations(self):
  x=list(original.configurations());assert x==list(p.configurations());return x
r=Compared()
begin=time.process_time();counts=dict(forward_roundtrips=0,complete_cylinder_checks=0,empty_cylinders=0,nonempty_cylinders=0,free_cylinders=0)
digest=hashlib.sha256()
for alphabet in ('ABC','ACB'):
 for length in (1,4):
  texts=[''.join(x) for x in itertools.product(alphabet,repeat=length)]
  masks=sorted(set([(),(0,),tuple(range(0,length,2)),tuple(range(length))]))
  for start in range(length):
   for direction in (1,-1):
    for period in (1,2,3):
     keys=list(itertools.product(range(3),repeat=period));truth={}
     for key in keys:
      for plaintext in texts:
       cipher=r.encrypt(plaintext,alphabet,start,direction,key)
       assert r.decrypt(cipher,alphabet,start,direction,key)==plaintext
       assert sorted(r.route(cipher,alphabet,start,direction))==list(range(length))
       counts['forward_roundtrips']+=1
       for mask in masks:
        signature=tuple(plaintext[i] for i in mask)
        truth.setdefault((cipher,mask,signature),set()).add(key)
     for cipher in texts:
      for mask in masks:
       for signature in itertools.product(alphabet,repeat=len(mask)):
        expected=truth.get((cipher,mask,signature),set())
        got=r.cylinder(cipher,dict(zip(mask,signature)),alphabet,start,direction,period)
        actual=set() if got is None else {k for k in keys if all(x is None or k[i]==x for i,x in enumerate(got['key_residues']))}
        assert actual==expected,(alphabet,length,start,direction,period,cipher,mask,signature,expected,got)
        counts['complete_cylinder_checks']+=1
        if got is None:counts['empty_cylinders']+=1
        else:
         counts['nonempty_cylinders']+=1
         assert len(actual)==got['key_count']==3**got['free_residues']
         counts['free_cylinders']+=got['free_residues']>0
        digest.update(repr((alphabet,length,start,direction,period,cipher,mask,signature,sorted(actual))).encode())
assert len(list(r.configurations()))==3104
receipt=dict(status='PASS',counts=counts,truth_digest=digest.hexdigest(),cpu_seconds=time.process_time()-begin,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,scope='ABC/ACB; lengths1,4; all starts; directions +/-1; periods1,2,3; every key/plaintext and every ciphertext/crib assignment for empty,singleton,alternating,full masks',production_inspected=True,target_evaluated=False)
Path(__file__).with_name('production-comparison-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
