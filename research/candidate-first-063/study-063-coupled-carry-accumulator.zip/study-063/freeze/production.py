"""Study063 explicit low/high-state accumulator; no K4 literal or loader."""
import json,sys
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KR='KRYPTOSABCDEFGHIJLMNQUVWXZ';ALPHABETS=(AZ,KR)
def encrypt(plaintext,alphabet,key,state,modulus=24):
 n=len(alphabet);a=state%n;h=state//n;out=[]
 for i,char in enumerate(plaintext):
  t=a+alphabet.index(char)+key[i%len(key)];a=t%n;out.append(alphabet[(a+h)%n]);h=(h+t//n)%modulus
 return ''.join(out)
def decrypt(ciphertext,alphabet,key,state,modulus=24):
 n=len(alphabet);a=state%n;h=state//n;out=[]
 for i,char in enumerate(ciphertext):
  x=(alphabet.index(char)-h-a-key[i%len(key)])%n;out.append(alphabet[x]);t=a+x+key[i%len(key)];a=t%n;h=(h+t//n)%modulus
 return ''.join(out)
def local_keys(ciphersegment,plainsegment,offset,alphabet,period,modulus=24):
 n=len(alphabet);C=[alphabet.index(x) for x in ciphersegment];P=[alphabet.index(x) for x in plainsegment];keys=set()
 assert len(C)==len(P) and len(C)>=period
 for a0 in range(n):
  for h0 in range(modulus):
   a,h=a0,h0;key=[None]*period
   for j,(x,y) in enumerate(zip(P,C)):
    phase=(offset+j)%period;k=(y-h-a-x)%n
    if key[phase] is not None and key[phase]!=k:break
    key[phase]=k;t=a+x+k;a=t%n;h=(h+t//n)%modulus
   else:
    assert None not in key;keys.add(tuple(key))
 return keys

def solve_setting(ciphertext,cribs,blocks,alphabet,period,modulus=24):
 n=len(alphabet);known={int(i):c for i,c in cribs.items()};seeds=None
 for start,length in blocks:
  plain=''.join(known[i] for i in range(start,start+length));keys=local_keys(ciphertext[start:start+length],plain,start,alphabet,period,modulus)
  seeds=keys if seeds is None else seeds&keys
  if not seeds:return []
 assert seeds is not None
 C=[alphabet.index(c) for c in ciphertext];knownranks={i:alphabet.index(c) for i,c in known.items()};out=[]
 for key in sorted(seeds):
  for state in range(n*modulus):
   a,h=state%n,state//n;plain=[]
   for i,y in enumerate(C):
    x=(y-h-a-key[i%period])%n
    if i in knownranks and x!=knownranks[i]:break
    plain.append(alphabet[x]);t=a+x+key[i%period];a=t%n;h=(h+t//n)%modulus
   else:out.append({'key':list(key),'state':state,'plaintext':''.join(plain)})
 return out

def solve(case):
 out=[];blocks=case.get('blocks',[(21,13),(63,11)])
 for a,A in enumerate(ALPHABETS):
  for p in range(1,7):
   for fit in solve_setting(case['ciphertext'],case['cribs'],blocks,A,p):out.append({'alphabet_index':a,'period':p,**fit})
 return out
if __name__=='__main__':
 with open(sys.argv[2],'w') as f:
  for case in json.load(open(sys.argv[1])):f.write(json.dumps({'id':case['id'],'complete':True,'alphabet_period_cases':12,'solutions':solve(case)},sort_keys=True)+'\n')
