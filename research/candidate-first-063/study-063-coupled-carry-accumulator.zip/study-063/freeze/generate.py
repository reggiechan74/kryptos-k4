import json,random,pathlib,sys
import reference
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK';BLOCKS=[[21,13],[63,11]]
def generate(seed):
 rng=random.Random(seed);items=[]
 def text():return ''.join(rng.choice(reference.AZ) for _ in range(97))
 for state in range(624):
  a=state%2;p=1+(state//2)%6;kind='literal' if (state//12)%2 else 'uniform';A=(reference.AZ,reference.KR)[a];plain=list(text())
  if kind=='literal':
   for i,c in zip(MASK,LITERAL):plain[i]=c
  plain=''.join(plain);key=[rng.randrange(26) for _ in range(p)];C=reference.encrypt(plain,A,key,state)
  items.append(({'ciphertext':C,'cribs':{str(i):plain[i] for i in MASK},'blocks':BLOCKS},{'kind':kind,'alphabet_index':a,'period':p,'key':key,'state':state,'plaintext':plain}))
 for k in range(64):
  letters=LITERAL if k>=32 else ''.join(rng.choice(reference.AZ) for _ in MASK)
  items.append(({'ciphertext':text(),'cribs':dict(zip(map(str,MASK),letters)),'blocks':BLOCKS},{'kind':'null_literal' if k>=32 else 'null_uniform'}))
 rng.shuffle(items);inputs=[];answers=[]
 for k,(x,y) in enumerate(items):
  ID=f'case-{k:04d}';inputs.append({'id':ID,**x});answers.append({'id':ID,**y})
 return inputs,answers
if __name__=='__main__':
 dest=pathlib.Path(sys.argv[1]);inputs,answers=generate(int((dest/'seed.txt').read_text(),16))
 for name,data in [('inputs.json',inputs),('answers.json',answers)]:(dest/name).write_text(json.dumps(data,indent=2)+'\n')
