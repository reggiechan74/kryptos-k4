import json,pathlib,sys,time
import production

def analyze(root):
 started=time.process_time();inputs=json.loads((root/'inputs.json').read_text());answers={x['id']:x for x in json.loads((root/'answers.json').read_text())};first=[json.loads(x) for x in (root/'production.jsonl').read_text().splitlines()];second=[json.loads(x) for x in (root/'reference.jsonl').read_text().splitlines()]
 assert len(inputs)==len(first)==len(second)==688 and first==second
 plants=nullfits=roundtrips=unique=ambiguous=returned=0;max_solutions=0;states=set();alloc={}
 for case,result in zip(inputs,first):
  assert case['id']==result['id'] and result['complete'] and result['alphabet_period_cases']==12
  answer=answers[case['id']];hits=result['solutions'];plains=set();returned+=len(hits);max_solutions=max(max_solutions,len(hits))
  for hit in hits:
   A=production.ALPHABETS[hit['alphabet_index']];assert len(hit['key'])==hit['period'] and 0<=hit['state']<624
   assert all(hit['plaintext'][int(i)]==v for i,v in case['cribs'].items())
   assert production.decrypt(case['ciphertext'],A,hit['key'],hit['state'])==hit['plaintext']
   assert production.encrypt(hit['plaintext'],A,hit['key'],hit['state'])==case['ciphertext'];roundtrips+=1;plains.add(hit['plaintext'])
  if answer['kind'].startswith('null'):nullfits+=bool(hits);continue
  plants+=1;states.add(answer['state']);label=f"{answer['alphabet_index']}:{answer['period']}:{answer['kind']}";alloc[label]=alloc.get(label,0)+1
  assert any(all(hit[k]==answer[k] for k in ['alphabet_index','period','key','state','plaintext']) for hit in hits)
  assert answer['plaintext'] in plains
  if len(plains)==1:unique+=1
  else:ambiguous+=1
 assert plants==624 and len(states)==624 and len(alloc)==24 and set(alloc.values())=={26} and nullfits<=1
 return {'status':'PASS','complete_set_agreement_cases':688,'plants_included':plants,'initial_states_covered':len(states),'allocation_each_A_period_kind':alloc,'unique_plaintext_plants':unique,'ambiguous_plaintext_plants':ambiguous,'null_any_fits':nullfits,'null_count':64,'compatible_parameterizations_returned':returned,'max_parameterizations_per_case':max_solutions,'checked_full_roundtrips':roundtrips,'cpu_seconds':time.process_time()-started,'interpretation':'Complete key/start-state sets. Parameter aliases retained; distinct plaintext counts descriptive, no global operator/union volume claim.'}
if __name__=='__main__':
 root=pathlib.Path(sys.argv[1]);result=analyze(root);(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
