import reference,json,sys
if __name__=='__main__':
 with open(sys.argv[2],'w') as f:
  for case in json.load(open(sys.argv[1])):
   f.write(json.dumps({'id':case['id'],'complete':True,'alphabet_period_cases':12,'solutions':reference.solve(case)},sort_keys=True)+'\n')
