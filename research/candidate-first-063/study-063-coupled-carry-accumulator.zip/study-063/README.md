# Study 063: coupled 26/24 accumulator

**Result: exact bounded exclusion.** Both approved K 4 evaluations returned zero compatible parameterizations. This is not a recovery success: all 624 blind plants retained multiple plaintexts, and zero recovered uniquely.

## Frozen model

AZ or KRYPTOS ranks; arbitrary periodic key of nominal period 1–6; all 624 initial low/high states. Compute t=a+x+k, new a=t mod 26, output(new a+OLD h) mod 26, new h=(h+floor(t/26)) mod 24. Equivalently, T=26 h+a updates by T+x+k modulo 624 with a nonlinear old-high/new-low digit readout. No reset, route, new sign, padding or timing variant.

Each local crib is only a lossless seed filter over all entry states. Every intersected key must then survive continuous 97-letter decoding from an actual message-start state. A retained tiny reset-trap fixture demonstrates why independently restarting at both cribs would be unsound. All-zero keys remain included; they do not reduce this model to pure transposition.

## Evidence

- `freeze/protocol.md`, `freeze/manifest.json`: exact model,688-case design, gates and39-file pre-holdout freeze.
- `audit/`: independent scalar-state reference, complete tiny truth, all7,488 full-size direct settings, prior-proof reviews and reset-trap checks.
- `eligibility/`: precise local/external model equations, source pins/hashes and scoped whole-function separation arguments.
- `benchmark/`: fresh fixtures/seed/answers, original sealed outputs, resources and analysis.
- `audit/postbenchmark/FINAL-AUDIT.json`: independent complete-set replay and55,263 full roundtrips.
- `analysis/` and `audit/postbenchmark/AMBIGUITY-AUDIT.json`: separately labelled post-reveal descriptive position/state projections, with no new solver or target trial.
- `target/` and `audit/target/FINAL-AUDIT.json`: canonical input, authorization, transport freeze, original target outputs/seals and independent non-search audit.
- `resource-ledger.json`, `METHOD-LEARNING.md`: full costs/reserves and retained lessons.

## Important identification limit

All 688 complete sets agree; all 624 plants are retained; none of 64 random controls fit. But **zero plants recover uniquely**: each has 8–126 compatible plaintexts.63 plants vary only at position 0,424 additionally within the pre-crib prefix, and 137 also at later unknown positions. All 624 have same-key first-letter alternatives reaching exactly the same post-first hidden state. Parameter agreement is not identification, and an English-looking selected completion would not resolve this ambiguity.

## Reproduction and provenance

Python3.12 standard library suffices. Create a new output directory, then run `python freeze/production.py benchmark/inputs.json new/production.jsonl` or `python freeze/reference_adapter.py benchmark/inputs.json new/reference.jsonl`. Preserve original files. Full source/key/start-state sets must match; do not test only whether one planted tuple appears.

Downloaded third-party source code/prose is not redistributed without verified permission; `eligibility/external/SOURCE-INVENTORY.json` identifies exact reviewed URLs, Git blobs and SHA256. No external source program was executed. Local project source excerpts and our independent code/reports are retained. The whole-function prior distinctions do not imply all finite-message pairs are disjoint from every older set-valued model; no worldwide novelty or Sanborn-intent claim is made.
