"""Post-reveal descriptive projection; no new solver or target trial."""
import json,pathlib,time,collections
ROOT=pathlib.Path(__file__).resolve().parents[1];start=time.process_time();answers={x['id']:x for x in json.loads((ROOT/'benchmark/answers.json').read_text())};A=['ABCDEFGHIJKLMNOPQRSTUVWXYZ','KRYPTOSABCDEFGHIJLMNQUVWXZ'];rows=[];counts=collections.Counter()
def state_after(plain,key,state,alphabet,length):return (state+sum(alphabet.index(c)+key[i%len(key)] for i,c in enumerate(plain[:length])))%624
for line in (ROOT/'benchmark/production.jsonl').read_text().splitlines():
 row=json.loads(line);truth=answers[row['id']]
 if truth['kind'].startswith('null'):continue
 plains=set(h['plaintext'] for h in row['solutions']);varying=[i for i in range(97) if len({p[i] for p in plains})>1]
 category='only_position0' if varying==[0] else 'prefix_before_first_crib_only' if max(varying)<21 else 'includes_later_positions';counts[category]+=1
 groups=collections.defaultdict(list)
 for h in row['solutions']:groups[(h['alphabet_index'],h['period'],tuple(h['key']))].append(h)
 same=groups[(truth['alphabet_index'],truth['period'],tuple(truth['key']))];alphabet=A[truth['alphabet_index']]
 first_only=[h for h in same if h['plaintext'][0]!=truth['plaintext'][0] and h['plaintext'][1:]==truth['plaintext'][1:]]
 true1=state_after(truth['plaintext'],truth['key'],truth['state'],alphabet,1);true21=state_after(truth['plaintext'],truth['key'],truth['state'],alphabet,21)
 converged1=sum(state_after(h['plaintext'],h['key'],h['state'],alphabet,1)==true1 for h in first_only)
 converged21=sum(state_after(h['plaintext'],h['key'],h['state'],alphabet,21)==true21 for h in same)
 counts['plants_with_first_only_samekey_alias']+=bool(first_only);counts['plants_with_first_only_samekey_alias_and_same_postfirststate']+=bool(converged1)
 rows.append({'id':row['id'],'distinct_plaintexts':len(plains),'varying_positions':varying,'category':category,'nominal_alphabet_period_key_groups':len(groups),'start_states_per_group':sorted(len({h['state'] for h in g}) for g in groups.values()),'same_generating_key_startstates':len({h['state'] for h in same}),'samekey_first_symbol_only_aliases':len(first_only),'those_with_identical_postfirststate':converged1,'samekey_candidates_includingtruth_matching_true_state_before_firstcrib':converged21})
result={'scope':'post-reveal sealed-output projection and deterministic state sums only; not admission gate or target search','counts':dict(counts),'cases':rows,'varying_position_count_min':min(len(x['varying_positions']) for x in rows),'varying_position_count_max':max(len(x['varying_positions']) for x in rows),'cpu_seconds':time.process_time()-start,'interpretation':'Observed aliases and convergence, not universal identification theorem or arbitrary-primer exclusion.'}
(ROOT/'analysis/ambiguity-projection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
