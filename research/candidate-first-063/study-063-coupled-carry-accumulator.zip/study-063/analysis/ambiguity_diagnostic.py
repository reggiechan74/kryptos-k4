"""Post-reveal diagnostic only; reads sealed benchmark outputs, no solving/target."""
import json,pathlib,time,collections
ROOT=pathlib.Path(__file__).resolve().parents[1];start=time.process_time()
answers={x['id']:x for x in json.loads((ROOT/'benchmark/answers.json').read_text())};counts=[];same_key_first_only=0;position_counts=collections.Counter();different_key_cases=0
for line in (ROOT/'benchmark/production.jsonl').read_text().splitlines():
 row=json.loads(line);a=answers[row['id']]
 if a['kind'].startswith('null'):continue
 plains=set(x['plaintext'] for x in row['solutions']);counts.append(len(plains));first=False;otherkey=False;var=set()
 for hit in row['solutions']:
  diffs=[i for i,(p,q) in enumerate(zip(hit['plaintext'],a['plaintext'])) if p!=q];var.update(diffs)
  if diffs==[0] and hit['key']==a['key'] and hit['period']==a['period'] and hit['alphabet_index']==a['alphabet_index']:first=True
  if hit['key']!=a['key'] or hit['period']!=a['period'] or hit['alphabet_index']!=a['alphabet_index']:otherkey=True
 same_key_first_only+=first;different_key_cases+=otherkey;position_counts.update(var)
result={'scope':'post-reveal descriptive analysis of benchmark outputs only; no new solver or target trial','plants':len(counts),'distinct_plaintext_min':min(counts),'distinct_plaintext_max':max(counts),'distinct_plaintext_histogram':dict(sorted(collections.Counter(counts).items())),'plants_with_same_key_candidate_differing_only_at_position0':same_key_first_only,'plants_with_different_nominal_key_or_alphabet_candidate':different_key_cases,'plants_with_variation_by_position':dict(sorted(position_counts.items())),'cpu_seconds':time.process_time()-start}
(ROOT/'analysis/ambiguity-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
