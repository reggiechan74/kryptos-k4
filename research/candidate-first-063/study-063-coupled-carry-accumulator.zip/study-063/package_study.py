import hashlib,json,pathlib,zipfile,re
root=pathlib.Path(__file__).resolve().parent
out=root/'publication';out.mkdir(exist_ok=True)
files=sorted(p for p in root.rglob('*') if p.is_file() and 'publication' not in p.relative_to(root).parts and 'private-source-cache' not in p.relative_to(root).parts and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'))
manifest={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
for name,item in json.loads((root/'freeze/manifest.json').read_text())['files'].items():
 assert manifest[name]['sha256']==item['sha256'],name
payload=json.dumps({'study':'063','files':manifest},indent=2,sort_keys=True).encode()+b'\n'
(out/'MANIFEST.json').write_bytes(payload)
archive=out/'study-063-coupled-carry-accumulator.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in [(str(p.relative_to(root)),p.read_bytes()) for p in files]+[('MANIFEST.json',payload)]:
  info=zipfile.ZipInfo('study-063/'+name,date_time=(2026,10,31,15,17,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,item in manifest.items():
  data=z.read('study-063/'+name)
  assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],name
receipt={'status':'PASS','archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payload_files':len(files),'archive_entries':len(files)+1,'frozen_files_verified':39,'all_payload_hashes_verified':True,'excluded':['publication directory','private-source-cache (third-party code/prose, redistribution license not verified)','__pycache__','*.pyc','*.pyo'],'inventory':list(manifest)}
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='inventory'},indent=2))
