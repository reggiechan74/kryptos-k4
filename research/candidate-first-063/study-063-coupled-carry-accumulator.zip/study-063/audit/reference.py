"""Independent scalar modular accumulator reference, written before production inspection.
state = alphabet_size*high_counter + low_digit; output uses OLD high digit.
"""
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'
def encrypt(plaintext,alphabet,key,state,modulus=24):
 n=len(alphabet);out=[]
 for i,c in enumerate(plaintext):
  old_high=state//n;state=(state+alphabet.index(c)+key[i%len(key)])%(n*modulus)
  out.append(alphabet[(state%n+old_high)%n])
 return ''.join(out)
def decrypt(ciphertext,alphabet,key,state,modulus=24):
 n=len(alphabet);out=[]
 for i,c in enumerate(ciphertext):
  x=(alphabet.index(c)-state//n-state%n-key[i%len(key)])%n
  out.append(alphabet[x]);state=(state+x+key[i%len(key)])%(n*modulus)
 return ''.join(out)
def local_keys(ciphersegment,plainsegment,offset,alphabet,period,modulus=24):
 assert len(ciphersegment)==len(plainsegment)>=period
 n=len(alphabet);seeds=set()
 for initial in range(n*modulus):
  state=initial;key=[None]*period
  for j,(c,p) in enumerate(zip(ciphersegment,plainsegment)):
   x=alphabet.index(p);slot=(offset+j)%period
   forced=(alphabet.index(c)-state//n-state%n-x)%n
   if key[slot] is not None and key[slot]!=forced:break
   key[slot]=forced;state=(state+x+forced)%(n*modulus)
  else:
   assert None not in key;seeds.add(tuple(key))
 return seeds

def solve_setting(ciphertext,cribs,blocks,alphabet,period,modulus=24):
 cribs={int(i):v for i,v in cribs.items()};seeds=None
 for start,length in blocks:
  local=local_keys(ciphertext[start:start+length],''.join(cribs[i] for i in range(start,start+length)),start,alphabet,period,modulus)
  seeds=local if seeds is None else seeds & local
  if not seeds:return []
 assert seeds is not None
 hits=[]
 for key in sorted(seeds):
  for state in range(len(alphabet)*modulus):
   plain=decrypt(ciphertext,alphabet,key,state,modulus)
   if all(plain[i]==v for i,v in cribs.items()):hits.append(dict(key=list(key),state=state,plaintext=plain))
 return hits

def solve(case,alphabets=(AZ,KR),periods=range(1,7),modulus=24):
 hits=[]
 for a,A in enumerate(alphabets):
  for p in periods:
   for result in solve_setting(case['ciphertext'],case['cribs'],case.get('blocks',[(21,13),(63,11)]),A,p,modulus):
    hits.append(dict(alphabet_index=a,period=p,**result))
 return hits
