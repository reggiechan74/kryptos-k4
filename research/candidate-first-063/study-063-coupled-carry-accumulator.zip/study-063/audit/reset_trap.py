import reference as r
import itertools,json,time
from pathlib import Path
start=time.process_time();A='ABC';blocks=[(0,2),(3,2)];mask=[0,1,3,4];found=None;tested=0
for chars in itertools.product(A,repeat=5):
 c=''.join(chars)
 for letters in itertools.product(A,repeat=4):
  cribs=dict(zip(mask,letters))
  for p in [1,2]:
   seeds=[r.local_keys(c[st:st+n],''.join(cribs[i] for i in range(st,st+n)),st,A,p,2) for st,n in blocks];intersection=seeds[0]&seeds[1];tested+=1
   if intersection and not r.solve_setting(c,cribs,blocks,A,p,2):
    found=dict(ciphertext=c,cribs=cribs,blocks=blocks,alphabet=A,modulus=2,period=p,local_keysets=[sorted(x) for x in seeds],local_intersection=sorted(intersection),global_solutions=[]);break
  if found:break
 if found:break
receipt=dict(status='FOUND' if found else 'NONE_IN_DOMAIN',tested=tested,fixture=found,cpu_seconds=time.process_time()-start,target_evaluated=False)
Path(__file__).with_name('reset-trap-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
