import reference as r
import random,time,json,resource
from pathlib import Path
rng=random.Random(636363);rows=[]
for a,A in enumerate((r.AZ,r.KR)):
 for period in range(1,7):
  plain=''.join(rng.choice(r.AZ) for _ in range(97));key=[rng.randrange(26) for _ in range(period)];state=rng.randrange(624)
  case=dict(ciphertext=r.encrypt(plain,A,key,state),cribs={str(i):plain[i] for i in [*range(21,34),*range(63,74)]})
  t=time.process_time();hits=r.solve(case);elapsed=time.process_time()-t
  assert dict(alphabet_index=a,period=period,key=key,state=state,plaintext=plain) in hits
  rows.append(dict(alphabet_index=a,period=period,cpu_seconds=elapsed,matches=len(hits)))
receipt=dict(status='PASS',synthetic_seed=636363,measurements=rows,max_cpu_seconds=max(x['cpu_seconds'] for x in rows),total_cpu_seconds=sum(x['cpu_seconds'] for x in rows),max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False)
Path(__file__).with_name('calibration-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
