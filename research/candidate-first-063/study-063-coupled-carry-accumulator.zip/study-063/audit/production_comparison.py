import reference as original
import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('production',Path(__file__).resolve().parents[1]/'freeze/production.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class Compared:
 def encrypt(self,*args):
  x=original.encrypt(*args);assert x==p.encrypt(*args);return x
 def decrypt(self,*args):
  x=original.decrypt(*args);assert x==p.decrypt(*args);return x
 def solve_setting(self,cipher,cribs,blocks,A,period,modulus):
  for start,length in blocks:
   args=(cipher[start:start+length],''.join(cribs[i] for i in range(start,start+length)),start,A,period,modulus)
   assert original.local_keys(*args)==p.local_keys(*args)
  x=original.solve_setting(cipher,cribs,blocks,A,period,modulus);assert x==p.solve_setting(cipher,cribs,blocks,A,period,modulus);return x
r=Compared()
import itertools,time,json,resource,hashlib
from pathlib import Path
start=time.process_time();count={'forward_roundtrips':0,'complete_set_checks':0,'one_step_bijections':0};digest=hashlib.sha256();carries=set()
for A in ['ABC','ACB']:
 for m in [2,3]:
  for state in range(3*m):
   for k in range(3):
    images=[]
    for x in range(3):
     total=state%3+x+k;low=total%3;oldh=state//3;pairout=A[(low+oldh)%3]
     assert r.encrypt(A[x],A,[k],state,m)==pairout
     assert (state+x+k)%(3*m)==3*((oldh+total//3)%m)+low
     images.append(pairout);carries.add(total//3)
    assert len(set(images))==3;count['one_step_bijections']+=1
 for length,blocks in [(4,[(0,2),(2,2)]),(5,[(0,2),(3,2)])]:
  mask=[i for st,n in blocks for i in range(st,st+n)];texts=[''.join(v) for v in itertools.product(A,repeat=length)]
  for period in [1,2]:
   truth={}
   for key in itertools.product(range(3),repeat=period):
    for initial in range(6):
     for plain in texts:
      cipher=r.encrypt(plain,A,key,initial,2);assert r.decrypt(cipher,A,key,initial,2)==plain;count['forward_roundtrips']+=1
      signature=tuple(plain[i] for i in mask)
      truth.setdefault((cipher,signature),set()).add((key,initial,plain))
   for cipher in texts:
    for signature in itertools.product(A,repeat=len(mask)):
     expected=truth.get((cipher,signature),set())
     hits=r.solve_setting(cipher,dict(zip(mask,signature)),blocks,A,period,2)
     actual={(tuple(h['key']),h['state'],h['plaintext']) for h in hits}
     assert actual==expected,(A,length,period,cipher,signature,expected,actual)
     count['complete_set_checks']+=1;digest.update(repr((A,length,period,cipher,signature,sorted(actual))).encode())
assert carries=={0,1,2}
receipt=dict(status='PASS',counts=count,carry_values=sorted(carries),truth_digest=digest.hexdigest(),cpu_seconds=time.process_time()-start,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,production_inspected=True,target_evaluated=False,scope='ABC/ACB, n3 m2, length4/full and length5/sparse two-block masks, periods1–2, every key/start/plaintext and every ciphertext/crib assignment; one-step m2/m3 normal-form and carry controls')
Path(__file__).with_name('production-comparison-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
