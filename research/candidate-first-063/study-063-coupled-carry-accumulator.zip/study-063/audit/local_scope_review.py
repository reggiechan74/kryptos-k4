import reference as r
import json,time,hashlib
from pathlib import Path
base=Path(__file__).resolve().parents[1];start=time.process_time();source=base/'eligibility/local-model-separation.json';cert=json.loads(source.read_text());w=cert['radix_parity_witnesses'];assert len(w)==104
assert {(x['alphabet'],x['source'],x['key_digit']) for x in w}=={(a,s,k) for a in ['AZ','KR'] for s in ['plaintext','ciphertext'] for k in range(26)}
checks=0
for pair in w:
 A=r.AZ if pair['alphabet']=='AZ' else r.KR
 old=[]
 for item in pair['histories']:
  assert 0<=item['state']<624
  c=r.encrypt(A[item['x']]+A[0],A,[pair['key_digit'],0],item['state'])
  assert A.index(c[0])==item['y'] and (item['y']-item['x'])%26==item['inferred_key'] and A.index(c[1])==item['next_inferred_key_with_next_digit0']
  assert A[item['x'] if pair['source']=='plaintext' else item['y']]==pair['source_glyph'] and pair['source_glyph'] in 'ELQST'
  old.append((item['y']-item['x'])%2)
 assert old[0]==old[1]
 for nextkey in range(26):
  pars=[A.index(r.encrypt(A[h['x']]+A[0],A,[pair['key_digit'],nextkey],h['state'])[1])%2 for h in pair['histories']]
  assert pars[0]!=pars[1];checks+=1
# Explicit sum-set reachability, independent from witness enumerator.
sums={0}
for _ in range(25):sums={s+x for s in sums for x in range(26)}
assert sums==set(range(626)) and {s%624 for s in sums}==set(range(624))
nonlinear=0
for h in range(24):
 for k1 in range(26):
  state=26*h+(1-k1)%26
  for k2 in range(26):
   outputs=[r.AZ.index(r.encrypt(r.AZ[x]+'A',r.AZ,[k1,k2],state)[1]) for x in [0,1,25]]
   assert (outputs[2]-outputs[0]-25*(outputs[1]-outputs[0]))%26 in [1,3];nonlinear+=1
assert nonlinear==16224
# Zero-key member changes the symbol multiset: not a transposition.
assert r.encrypt('ZBA',r.AZ,[0],0)=='ZAB' # first example happens to share multiset
assert r.encrypt('BAA',r.AZ,[0],0)=='BBB'
receipt=dict(status='PASS_LOCAL_SCOPE',certificate_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),witness_pairs=104,next_key_extensions=checks,native_nonlinearity_checks=nonlinear,reachable_rank_sums=626,reachable_states_after25=624,zero_key_must_remain=True,target_evaluated=False,cpu_seconds=time.process_time()-start,scope='Precise local same-coordinate radix-feature recurrence, autonomous position-only schedules, and native fixed-affine maps. Arbitrary relabelings require the separate fixed-tableau proof; not a generic nonlinear-family exclusion.')
(base/'audit/local-scope-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
