import reference as r
import importlib.util,random,json,time,resource
from pathlib import Path
base=Path(__file__).resolve().parents[1];s=importlib.util.spec_from_file_location('production',base/'freeze/production.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
rng=random.Random(63123456);t=time.process_time();count=0
for A in (r.AZ,r.KR):
 for period in range(1,7):
  for state in range(624):
   plain=''.join(rng.choice(r.AZ) for _ in range(97));key=[rng.randrange(26) for _ in range(period)];c=r.encrypt(plain,A,key,state)
   assert c==p.encrypt(plain,A,key,state) and r.decrypt(c,A,key,state)==p.decrypt(c,A,key,state)==plain
   for st,n in [(21,13),(63,11)]:
    args=(c[st:st+n],plain[st:st+n],st,A,period)
    keys=r.local_keys(*args);assert keys==p.local_keys(*args) and tuple(key) in keys
   count+=1
receipt=dict(status='PASS',settings=count,forward_inverse_local_keyset_agreement=True,all_planted_keys_in_both_filters=True,synthetic_seed=63123456,cpu_seconds=time.process_time()-t,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False)
(base/'audit/full-domain-comparison-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
