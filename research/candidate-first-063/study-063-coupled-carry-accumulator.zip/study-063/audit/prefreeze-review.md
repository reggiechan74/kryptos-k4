# Independent study063 prefreeze review

PASS. All five private primary-source files match both pinned Git blob IDs and SHA256/byte counts. No external source executed. Report describes actual carry.py adjacent-pair set-valued constraints, rather than falsely treating them as a linear recurrence. The odometer's unimplemented comment is not counted as coverage.

## Fixed-alphabet argument

Every circular interval of51 states contains an aligned26-state block (independently checked for all624 interval origins). Two freely chosen input ranks attain every integer sum0..50. At the next fixed position this yields all26 conditional translations. Under an equivalent fixed input/output relabeling and fixed causal affine current-letter equation, bijectivity forces its current coefficient to be a unit. Comparing every translation with shift zero forces both relabelings to be affine units. The native nonlinearity certificate then rules out a globally affine input/output function. Scope remains fixed causal affine equations with fixed initialization; it does not license arbitrary nonlinear prefix initializers, set-valued state machines, or arbitrary nonlinear recurrences.

## Carry-noise and trace limitations

The source carry.py permits an adjacent pair of inferred key values per phase. It has neither the persistent624-state accumulator nor the exact old-high readout. Varying prefixes can reach every shift at a fixed position for a fixed proposed key; therefore no one fixed adjacent-pair schedule reproduces that whole operator. This does not prove disjointness of finite-message fits with separately fitted old-model parameters. The report states that limitation correctly. No target fit, overlap search or extra exclusion is inferred from the algebra. Zero-key members remain included.

## Protocol and implementation

688 fixtures allocate one plant to each initial state, with exactly26 in each alphabet/period/kind cell, plus64 independent nulls. Whole tuple sets, including nominal-period and state/key aliases, must agree; plaintext uniqueness remains descriptive. Both local blocks cover all key residues for periods1–6; independent block-entry enumeration is only a lossless superset. The concrete reset trap and exhaustive forward oracle validate the subsequent continuous global replay gate. Generator, analyzer and runner implement the stated allocation, gates,300CPU/600wall/512MiB batch caps. No required fixes identified. Parent benchmark review/approval is still required before target solving.
