import json,collections,time,hashlib
from pathlib import Path
base=Path(__file__).resolve().parents[2];t=time.process_time()
def read(p):return json.loads((base/p).read_text())
seal=read('benchmark/seal.json')
for p in ['answers.json','production.jsonl']:
 assert hashlib.sha256((base/'benchmark'/p).read_bytes()).hexdigest()==seal['files'][p]['sha256']
answers={a['id']:a for a in read('benchmark/answers.json')};projection=read('analysis/ambiguity-projection.json');recorded={a['id']:a for a in projection['cases']};counts=collections.Counter();minimum=100;maximum=0;vmin=100;vmax=0;diag=read('analysis/ambiguity-diagnostic.json');hist=collections.Counter();positioncounts=collections.Counter();different=0
A=['ABCDEFGHIJKLMNOPQRSTUVWXYZ','KRYPTOSABCDEFGHIJLMNQUVWXZ']
def advance(hit,n):
 low,high=hit['state']%26,hit['state']//26;alphabet=A[hit['alphabet_index']]
 for i,c in enumerate(hit['plaintext'][:n]):
  total=low+alphabet.index(c)+hit['key'][i%hit['period']];low=total%26;high=(high+total//26)%24
 return (low,high)
for line in (base/'benchmark/production.jsonl').read_text().splitlines():
 row=json.loads(line);truth=answers[row['id']]
 if truth['kind'].startswith('null'):continue
 hits=row['solutions'];plains={h['plaintext'] for h in hits};varying=[i for i in range(97) if any(p[i]!=truth['plaintext'][i] for p in plains)]
 category='only_position0' if varying==[0] else 'prefix_before_first_crib_only' if all(i<21 for i in varying) else 'includes_later_positions';counts[category]+=1
 groups=collections.defaultdict(list)
 for h in hits:groups[(h['alphabet_index'],h['period'],tuple(h['key']))].append(h)
 same=groups[(truth['alphabet_index'],truth['period'],tuple(truth['key']))];first=[h for h in same if h['plaintext'][0]!=truth['plaintext'][0] and h['plaintext'][1:]==truth['plaintext'][1:]]
 c1=sum(advance(h,1)==advance(truth,1) for h in first);c21=sum(advance(h,21)==advance(truth,21) for h in same)
 counts['plants_with_first_only_samekey_alias']+=bool(first);counts['plants_with_first_only_samekey_alias_and_same_postfirststate']+=bool(c1)
 expected=dict(id=row['id'],distinct_plaintexts=len(plains),varying_positions=varying,category=category,nominal_alphabet_period_key_groups=len(groups),start_states_per_group=sorted(len({h['state'] for h in g}) for g in groups.values()),same_generating_key_startstates=len({h['state'] for h in same}),samekey_first_symbol_only_aliases=len(first),those_with_identical_postfirststate=c1,samekey_candidates_includingtruth_matching_true_state_before_firstcrib=c21)
 assert recorded[row['id']]==expected
 minimum=min(minimum,len(plains));maximum=max(maximum,len(plains));vmin=min(vmin,len(varying));vmax=max(vmax,len(varying));hist[len(plains)]+=1;positioncounts.update(varying);different+=len(groups)>1
assert dict(counts)==projection['counts'] and vmin==projection['varying_position_count_min'] and vmax==projection['varying_position_count_max']
assert {str(k):v for k,v in hist.items()}==diag['distinct_plaintext_histogram']
assert {str(k):v for k,v in positioncounts.items()}==diag['plants_with_variation_by_position']
assert different==diag['plants_with_different_nominal_key_or_alphabet_candidate']
receipt=dict(status='PASS_DESCRIPTIVE_POST_REVEAL',counts=dict(counts),distinct_plaintexts_min=minimum,distinct_plaintexts_max=maximum,varying_positions_min=vmin,varying_positions_max=vmax,all624_projection_rows_reproduced=True,convergence_independently_checked_with_pair_state=True,additional_solver_runs=0,target_evaluated=False,cpu_seconds=time.process_time()-t,limitations='Observed sealed-fixture ambiguity only; not universal identification theorem. No admission-gate change; convergence explains some but not all observed ambiguity, including137 cases with later-position alternatives.')
(base/'audit/postbenchmark/AMBIGUITY-AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
