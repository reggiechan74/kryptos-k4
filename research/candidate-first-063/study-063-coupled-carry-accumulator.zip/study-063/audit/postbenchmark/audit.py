import sys,json,hashlib,random,time,resource,datetime,collections
from pathlib import Path
base=Path(__file__).resolve().parents[2];sys.path.insert(0,str(base/'audit'));import reference as r
resource.setrlimit(resource.RLIMIT_CPU,(600,600));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));t=time.process_time()
def read(p):return json.loads((base/p).read_text())
def sha(p):return hashlib.sha256((base/p).read_bytes()).hexdigest()
assert sha('freeze/manifest.json')=='5b0d6d5ea6e3b10f2ced28474d09bd1e475281969bb3a19ba12e82819f568827'
assert sha('benchmark/seal.json')=='cd386db9110a685c223885e7402a59c5bf465a40f9fd9132757e66915dd8ad93'
manifest=read('freeze/manifest.json');seal=read('benchmark/seal.json')
for prefix,doc in [('',manifest),('benchmark/',seal)]:
 for path,record in doc['files'].items():assert sha(prefix+path)==record['sha256'] and (base/(prefix+path)).stat().st_size==record['bytes']
assert seal['outputs_sealed_before_answers_inspected'] and manifest['created_utc']<seal['created_utc']
cases=read('benchmark/inputs.json');answers=read('benchmark/answers.json');outputs=[[json.loads(s) for s in (base/f'benchmark/{engine}.jsonl').read_text().splitlines()] for engine in ['production','reference']]
assert outputs[0]==outputs[1] and len(cases)==len(answers)==len(outputs[0])==688
rng=random.Random(int((base/'benchmark/seed.txt').read_text(),16));pairs=[];mask=[*range(21,34),*range(63,74)];literal='EASTNORTHEASTBERLINCLOCK';blocks=[[21,13],[63,11]]
def text():return ''.join(rng.choice(r.AZ) for _ in range(97))
for state in range(624):
 a=state%2;period=1+(state//2)%6;kind='literal' if (state//12)%2 else 'uniform';A=(r.AZ,r.KR)[a];plain=list(text())
 if kind=='literal':
  for i,c in zip(mask,literal):plain[i]=c
 plain=''.join(plain);key=[rng.randrange(26) for _ in range(period)];cipher=r.encrypt(plain,A,key,state)
 pairs.append((dict(ciphertext=cipher,cribs={str(i):plain[i] for i in mask},blocks=blocks),dict(kind=kind,alphabet_index=a,period=period,key=key,state=state,plaintext=plain)))
for i in range(64):
 values=literal if i>=32 else ''.join(rng.choice(r.AZ) for _ in mask)
 pairs.append((dict(ciphertext=text(),cribs=dict(zip(map(str,mask),values)),blocks=blocks),dict(kind='null_literal' if i>=32 else 'null_uniform')))
rng.shuffle(pairs)
assert cases==[dict(id=f'case-{i:04d}',**x) for i,(x,y) in enumerate(pairs)]
assert answers==[dict(id=f'case-{i:04d}',**y) for i,(x,y) in enumerate(pairs)]
counts=collections.Counter();allocation=collections.Counter();states=set();plaintext_counts=[]
for case,answer,out in zip(cases,answers,outputs[0]):
 assert case['id']==answer['id']==out['id'] and out['complete'] and out['alphabet_period_cases']==12
 hits=r.solve(case);assert hits==out['solutions'];counts['complete_sets']+=1;plains=set()
 for hit in hits:
  assert len(hit['key'])==hit['period'] and 1<=hit['period']<=6 and 0<=hit['state']<624 and all(0<=k<26 for k in hit['key'])
  A=(r.AZ,r.KR)[hit['alphabet_index']]
  assert r.decrypt(case['ciphertext'],A,hit['key'],hit['state'])==hit['plaintext']
  assert all(hit['plaintext'][int(i)]==v for i,v in case['cribs'].items())
  assert r.encrypt(hit['plaintext'],A,hit['key'],hit['state'])==case['ciphertext'];counts['roundtrips']+=1;plains.add(hit['plaintext'])
 if answer['kind'].startswith('null'):
  counts['nulls']+=1;counts['null_fits']+=bool(hits)
 else:
  expected={k:answer[k] for k in ['alphabet_index','period','key','state','plaintext']};assert expected in hits
  counts['plants']+=1;states.add(answer['state']);allocation[(answer['alphabet_index'],answer['period'],answer['kind'])]+=1
  counts['unique_plaintext_plants' if len(plains)==1 else 'ambiguous_plaintext_plants']+=1;plaintext_counts.append(len(plains))
assert counts['plants']==624 and len(states)==624 and len(allocation)==24 and set(allocation.values())=={26} and counts['nulls']==64 and counts['null_fits']<=1
resources=[read(f'benchmark/{engine}-resource.json') for engine in ['production','reference']]
for rec in resources:
 assert rec['status']=='completed' and rec['returncode']==0 and rec['stderr']==''
 assert rec['child_cpu_seconds']<rec['cpu_limit_seconds']==300 and rec['wall_seconds']<rec['wall_limit_seconds']==600
 assert rec['child_max_rss_kib']*1024<rec['as_limit_bytes']==536870912
receipt=dict(status='PASS_FOR_PARENT_TARGET_REVIEW',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),freeze_sha256=sha('freeze/manifest.json'),seal_sha256=sha('benchmark/seal.json'),frozen_files_verified=len(manifest['files']),fixture_replay_exact=True,counts=dict(counts),initial_states_covered=len(states),balanced_cells=len(allocation),plants_each_cell=26,distinct_plaintexts_per_plant_min=min(plaintext_counts),distinct_plaintexts_per_plant_max=max(plaintext_counts),benchmark_cpu_seconds=sum(x['child_cpu_seconds']+x['parent_cpu_seconds'] for x in resources),audit_cpu_seconds=time.process_time()-t,audit_max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,target_evaluated=False,target_authorized=False,limitation='All parameter tuples retained; plaintext ambiguity descriptive, not a uniqueness gate. Local entry-state intersections are only supersets; final sets require continuous global replay.')
(base/'audit/postbenchmark/FINAL-AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
