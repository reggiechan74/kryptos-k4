import json,hashlib,collections
from pathlib import Path
base=Path(__file__).resolve().parents[1];external=Path('/workspace/shared/k4-carry-prior-audit-063');inv=json.loads((external/'SOURCE-INVENTORY.json').read_text())
for entry in inv['sources']:
 b=(external/'private-sources'/entry['name']).read_bytes();assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==entry['git_blob']
allocation=collections.Counter((s%2,1+(s//2)%6,'literal' if (s//12)%2 else 'uniform') for s in range(624))
assert len(allocation)==24 and set(allocation.values())=={26}
# Any circular51 consecutive reachable states contains every low digit at one high digit.
for origin in range(624):
 reachable={(origin+i)%624 for i in range(51)}
 assert any(all(26*h+a in reachable for a in range(26)) for h in range(24))
receipt=dict(status='PASS_PREFREEZE',primary_sources_blob_sha256_verified=5,balanced_cells=24,plants_per_cell=26,circular_translation_block_checks=624,local_scope_audit='audit/local-scope-result.json',reset_trap_verified=True,target_evaluated=False,external_code_executed=False,required_model_or_protocol_fixes=[])
(base/'audit/prefreeze-review-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
