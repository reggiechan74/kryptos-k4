"""Synthetic whole-function distinction; no K4 ciphertext or crib processing."""
import json,pathlib,time,resource
ROOT=pathlib.Path(__file__).resolve().parents[1]
A={'AZ':'ABCDEFGHIJKLMNOPQRSTUVWXYZ','KR':'KRYPTOSABCDEFGHIJLMNQUVWXZ'}
start=time.process_time();witnesses=[]
# Local radix family uses even polynomial-code parity for E,L,Q,S,T at ANY base.
# Every accumulator state is reachable after25 arbitrary input symbols because
# their rank sum spans0..625, covering all residues modulo624.
for name,alphabet in A.items():
 for source in ['plaintext','ciphertext']:
  for key in range(26):
   found=None
   for glyph in 'ELQST':
    rank=alphabet.index(glyph);seen={}
    for state in range(624):
     a,h=state%26,state//26
     x=rank if source=='plaintext' else (rank-h-a-key)%26
     t=a+x+key;an=t%26;hn=(h+t//26)%24;y=(an+h)%26
     assert (x if source=='plaintext' else y)==rank
     ki=(y-x)%26;knext=(an+hn)%26 # next key digit0; any other adds same parity constant
     old=seen.get(ki%2)
     record={'state':state,'x':x,'y':y,'inferred_key':ki,'next_inferred_key_with_next_digit0':knext}
     if old and old['next_inferred_key_with_next_digit0']%2!=knext%2:
      found={'alphabet':name,'source':source,'key_digit':key,'source_glyph':glyph,'same_current_key_parity':ki%2,'histories':[old,record]};break
     seen[ki%2]=record
    if found:break
   assert found is not None,(name,source,key)
   witnesses.append(found)
# Native-coordinate third-output nonlinearity, covers any initial state/key:
# first input can arrange a1=(1-k1)%26; old high digit may be any h1.
nonlinear=0
for h1 in range(24):
 for k1 in range(26):
  a1=(1-k1)%26
  for k2 in range(26):
   ys=[]
   for x1 in [0,1,25]:
    t=a1+x1+k1;a2=t%26;h2=(h1+t//26)%24;a3=(a2+k2)%26;ys.append((a3+h2)%26)
   assert (ys[2]-ys[0]-25*(ys[1]-ys[0]))%26 in (1,3)
   nonlinear+=1
result={'status':'PASS','radix_parity_witnesses':witnesses,'radix_witness_count':len(witnesses),'native_nonlinearity_cases':nonlinear,'reachability_argument':'after25 letters rank sums0..625 cover Z624 for any fixed initialstate/keyprefix','scope':'Whole-function noncontainment in the precise local fixed-affine even-glyph-feature recurrence, both plain/cipher sources and additive/Beaufort parity. Not a K4 contradiction or universal nonlinear-family exclusion. Native nonlinearity alone does not prove arbitrary-relabeling nonequivalence.','cpu_seconds':time.process_time()-start,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'target_data_read':False}
(ROOT/'eligibility/local-model-separation.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='radix_parity_witnesses'})
