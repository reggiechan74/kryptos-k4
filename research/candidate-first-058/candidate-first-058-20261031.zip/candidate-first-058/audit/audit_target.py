"""Independent target receipt audit; does not rerun either engine."""
from pathlib import Path
import json,hashlib,time
ROOT=Path('/workspace/shared/candidate-first-058');AUDIT=Path('/workspace/shared/k4-058-audit');start=time.process_time()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((ROOT/'freeze/manifest.json').read_text());assert sha(ROOT/'freeze/manifest.json')=='0be0fee99fbbaeb8f46aaff77b9baa32964502b1ad4f55fa8518e2cbe2a318c6'
for name,h in m['files'].items():assert sha(ROOT/name)==h,name
t=json.loads((ROOT/'target/target-freeze.json').read_text());assert sha(ROOT/'target/target-freeze.json')=='074213b711fc5737ffff49ed268e8aa39b215a6a3f2b720bce3531a16e8d24a0'
for name,h in t['files'].items():assert sha(ROOT/name)==h,name
canonical=json.loads((AUDIT/'canonical-k4-pinned.json').read_text());case=json.loads((ROOT/'target/input.jsonl').read_text());assert case['ciphertext']==canonical['ciphertext'] and len(case['ciphertext'])==canonical['length']==97
clues=[]
for c in canonical['cribs']:clues += [[c['start']-1+i,x] for i,x in enumerate(c['plaintext'])]
assert case['clues']==clues and len(clues)==24
assert hashlib.sha256(case['ciphertext'].encode()).hexdigest()=='eea813570c7f1fd3b34674e47b5c3da8948026f5cefee612a0b38ffaa515ceab'
rows=[]
for engine in ('production','reference'):
 path=ROOT/'target'/f'{engine}.jsonl';o=json.loads(path.read_text());rec=json.loads((ROOT/'target'/f'{engine}.receipt.json').read_text());assert o['complete'] and o['families']==[] and o['projection']['status']=='UNSAT_COMPLETE'
 for field in ('raw_key_cylinders','distinct_plaintext_count','distinct_operator_count','plaintext_count_lower_bound','plaintext_count_upper_bound'):assert o['projection'][field]==0
 assert o['projection']['plaintext_witnesses']==[];assert rec['status']=='completed' and rec['count']==1 and rec['failure'] is None;assert rec['output_sha256']==sha(path) and rec['input_sha256']==sha(ROOT/'target/input.jsonl');assert rec['inclusive_cpu_seconds']<65 and rec['hard_worker_address_space_bytes']==rec['hard_child_address_space_bytes']==1024**3
 if engine=='reference':assert o['routes']==408960 and o['route_period_convention_trials']==22901760
 rows.append({'engine':engine,'inclusive_cpu_seconds':rec['inclusive_cpu_seconds'],'conservative_pair_peak_rss_bytes':(rec['worker_peak_rss_kib']+rec['max_child_rss_kib'])*1024,'output_sha256':sha(path)})
ledger=json.loads((ROOT/'results/resource-ledger.json').read_text());assert ledger['charged_cpu_seconds']<28800
out={'status':'PASS_EXACT_BOUNDED_EXCLUSION','frozen_files_verified':len(m['files']),'canonical_source':'https://github.com/reggiechan74/kryptos-k4/blob/e589286feedd6c3b52959418acd848f0a54a62b5/data/k4.json','canonical_ciphertext_sha256':hashlib.sha256(case['ciphertext'].encode()).hexdigest(),'target_input_sha256':sha(ROOT/'target/input.jsonl'),'target_freeze_sha256':sha(ROOT/'target/target-freeze.json'),'compatible_cylinders':0,'distinct_operators':0,'distinct_plaintexts':0,'reference_route_period_convention_trials':22901760,'engines':rows,'target_rerun':False,'scope':'Only eight AZ/KRYPTOS role/sign conventions, widths6–9, arbitrary output-index periods2–8, fixed literal cribs, unpadded ragged columnar then arithmetic. No broader exclusion.','audit_cpu_seconds':time.process_time()-start}
(ROOT/'audit/FINAL-TARGET-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
