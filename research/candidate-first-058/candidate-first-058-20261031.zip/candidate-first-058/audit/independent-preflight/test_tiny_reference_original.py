import hashlib,itertools,json,pathlib,subprocess,time,resource
from independent import *
ROOT=pathlib.Path(__file__).parent;start=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN);cases=0;witnesses=0;cylinders=0;dig=hashlib.sha256()
for cipher in itertools.product(range(4),repeat=4):
 for mask in ([0],[0,2],[0,1,2,3]):
  clues=[(i,(cipher[i]+i+1)%4) for i in mask];expected=brute(cipher,clues,[2,3],[1,2])
  output=json.loads(subprocess.check_output([str(ROOT/'reference')],input=line(cipher,clues,[2,3],[1,2],m=4).encode()));assert output['complete'];actual=set()
  for w in output['solutions']:
   cylinders+=1
   for key in expand(w,4):
    plain=decrypt(cipher,key,w['width'],w['order'],w['convention'],4)
    assert encrypt(plain,key,w['width'],w['order'],w['convention'],4)==list(cipher)
    assert all(plain[i]==v for i,v in clues)
    actual.add(signature(w,key,plain));witnesses+=1
  assert actual==expected,(cipher,clues,len(actual),len(expected));dig.update(repr((cipher,clues,sorted(actual))).encode());cases+=1
r1=resource.getrusage(resource.RUSAGE_CHILDREN);r={'status':'PASS','tiny_complete_set_cases':cases,'cylinders_checked':cylinders,'expanded_witnesses_reencrypted':witnesses,'digest':dig.hexdigest(),'inclusive_cpu_seconds':time.process_time()-start+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime}
(ROOT/'tiny-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
