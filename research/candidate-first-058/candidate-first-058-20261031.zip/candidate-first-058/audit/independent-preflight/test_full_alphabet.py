"""Pre-freeze full-alphabet controls with fixed public development seed."""
import sys,json,pathlib,random,time,resource
from independent import encrypt as iencrypt,decrypt as idecrypt,free_residues
sys.path.insert(0,'/workspace/shared/candidate-first-058/source')
import model
ROOT=pathlib.Path(__file__).parent;start=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN);rng=random.Random(580910);rows=[]
for conv in range(8):
 for width,period in [(6,8),(7,2)]:
  plain=[rng.randrange(26) for _ in range(97)];key=[rng.randrange(26) for _ in range(period)];order=list(range(width));rng.shuffle(order);cipher=iencrypt(plain,key,width,order,conv)
  case={'id':f'dev-{conv}-{width}-{period}','ciphertext':''.join(chr(x+65) for x in cipher),'clues':[[i,chr(plain[i]+65)] for i in model.MASK]}
  p=model.solve(case,'production');r=model.solve(case,'reference');assert set(map(model.signature,p['families']))==set(map(model.signature,r['families']))
  assert p['projection']['status']==r['projection']['status']
  free=free_residues(97,width,order,period,model.MASK)
  assert any(f['convention']==conv and f['width']==width and f['period']==period and f['order']==order and all(v<0 or v==key[j] for j,v in enumerate(f['key'])) for f in p['families'])
  if free:assert p['projection']['status']=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
  for f in p['families']:
   assert [i for i,v in enumerate(f['key']) if v<0]==free_residues(97,f['width'],f['order'],f['period'],model.MASK)
   k=[max(v,0) for v in f['key']];pt=idecrypt(cipher,k,f['width'],f['order'],f['convention']);assert iencrypt(pt,k,f['width'],f['order'],f['convention'])==cipher;assert all(pt[i]==ord(v)-65 for i,v in case['clues'])
  rows.append({'id':case['id'],'free':free,'family_count':len(p['families']),'projection':p['projection'],'reference_trials':r['route_period_convention_trials']})
r1=resource.getrusage(resource.RUSAGE_CHILDREN);out={'status':'PASS','count':len(rows),'inclusive_cpu_seconds':time.process_time()-start+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'cases':rows};(ROOT/'full-alphabet-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='cases'}))
