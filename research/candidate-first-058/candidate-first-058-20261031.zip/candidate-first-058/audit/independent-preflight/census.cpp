#include <algorithm>
#include <array>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;
int main(){const int n=97;long long grand[9]={};bool first=true;cout<<"{\"cells\":[";for(int w=6;w<=9;++w){vector<int>o(w),lens(w);iota(o.begin(),o.end(),0);for(int c=0;c<w;c++)lens[c]=(n-1-c)/w+1;long long hist[9][9]={};vector<vector<int>>example(9);vector<int>experiod(9);do{int map[97],j=0;for(int c:o)for(int i=c;i<n;i+=w)map[i]=j++;for(int p=2;p<=8;p++){int mask=0;for(int i=21;i<34;i++)mask|=1<<(map[i]%p);for(int i=63;i<74;i++)mask|=1<<(map[i]%p);int free=p-__builtin_popcount((unsigned)mask);hist[p][free]++;grand[free]++;if(example[free].empty()){example[free]=o;experiod[free]=p;}}}while(next_permutation(o.begin(),o.end()));for(int p=2;p<=8;p++){if(!first)cout<<',';first=false;cout<<"{\"width\":"<<w<<",\"period\":"<<p<<",\"free_histogram\":[";for(int f=0;f<=8;f++){if(f)cout<<',';cout<<hist[p][f];}cout<<"]}";}cerr<<"width "<<w<<" examples";for(int f=1;f<=8;f++)if(!example[f].empty()){cerr<<" free="<<f<<" p="<<experiod[f]<<" order=";for(int c:example[f])cerr<<c;}cerr<<'\n';}cout<<"],\"total_histogram\":[";for(int f=0;f<=8;f++){if(f)cout<<',';cout<<grand[f];}cout<<"]}\n";}
