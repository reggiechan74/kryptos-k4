"""Ciphertext-free operator novelty witness against study057's periodic family."""
from independent import route
from pathlib import Path
import json
n=97;width=6;order=list(range(6));key=list(range(7));r=route(n,width,order);inverse={i:j for j,i in enumerate(r)};stream=[key[inverse[i]%7] for i in range(n)];fails={p:next(i for i in range(p,n) if stream[i]!=stream[i%p]) for p in range(2,9)}
assert all(stream[i]!=stream[i%p] for p,i in fails.items())
o={'status':'PASS_NEW_OPERATOR_EXISTS','reverse_convention':'AZ/AZ/+','width':width,'order':order,'output_phase_key':key,'pulled_back_plaintext_position_key_stream':stream,'period2_to8_contradiction_positions':fails,'argument':'Same complete dependency route forces width and order equality. Nonzero AZ/AZ/+ letter maps occur; the207-map certificate excludes other convention representations except isolated zero identity. Thus a057 representation would require this stream to repeat with a nominal period2–8, contradicted at the listed positions. This proves new operator coverage, not that every reverse description is new.','known_overlap':'Constant keys commute with any transposition; other route/key alignments may also overlap. No exact total overlap count claimed.'}
Path(__file__).with_name('novelty-certificate.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({k:v for k,v in o.items() if k!='pulled_back_plaintext_position_key_stream'}))
