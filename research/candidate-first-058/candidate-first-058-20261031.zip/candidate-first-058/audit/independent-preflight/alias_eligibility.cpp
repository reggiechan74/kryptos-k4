#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;
int main(){cout<<"{\"cells\":[";bool first=true;for(int w=6;w<=9;w++){vector<int>o(w);iota(o.begin(),o.end(),0);long long count[9][2]={};do{int inv[97],j=0;for(int c:o)for(int i=c;i<97;i+=w)inv[i]=j++;int free[9]={};for(int q=2;q<=8;q++){int mask=0;for(int i=21;i<34;i++)mask|=1<<(inv[i]%q);for(int i=63;i<74;i++)mask|=1<<(inv[i]%q);free[q]=q-__builtin_popcount((unsigned)mask);}for(int p=2;p<=8;p++){bool eligible=true;for(int q=p;q<=8;q+=p)if(free[q])eligible=false;count[p][eligible]++;}}while(next_permutation(o.begin(),o.end()));for(int p=2;p<=8;p++){if(!first)cout<<',';first=false;cout<<"{\"width\":"<<w<<",\"primitive_period\":"<<p<<",\"guaranteed_ambiguous_routes\":"<<count[p][0]<<",\"eligible_routes\":"<<count[p][1]<<'}';}}cout<<"]}\n";}
