"""Independent subset-DP proof of output-key residue coverage, without ciphertext."""
from collections import defaultdict,Counter
from pathlib import Path
import json,time,math
ROOT=Path(__file__).parent;start=time.process_time();mask=list(range(21,34))+list(range(63,74));cells=[]
for width in range(6,10):
 lens=[len(range(c,97,width)) for c in range(width)]
 for period in range(2,9):
  dp={0:{0:1}}
  for used in range(1<<width):
   states=dp.get(used,{})
   off=sum(lens[c] for c in range(width) if used>>c&1)
   for c in range(width):
    if used>>c&1:continue
    bits=sum(0 for _ in [])
    for i in mask:
     if i%width==c:bits|=1<<((off+i//width)%period)
    out=dp.setdefault(used|(1<<c),{})
    for old,count in states.items():out[old|bits]=out.get(old|bits,0)+count
  hist=[0]*9
  for bits,count in dp[(1<<width)-1].items():hist[period-bits.bit_count()]+=count
  assert sum(hist)==math.factorial(width);cells.append({'width':width,'period':period,'free_histogram':hist})
expected=json.loads((ROOT/'census.json').read_text());assert cells==expected['cells'];r={'status':'PASS','method':'Independent subset DP, no ciphertext','cells':cells,'max_free_residues':max(j for c in cells for j,n in enumerate(c['free_histogram']) if n),'inclusive_cpu_seconds':time.process_time()-start};(ROOT/'census-independent.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='cells'}))
