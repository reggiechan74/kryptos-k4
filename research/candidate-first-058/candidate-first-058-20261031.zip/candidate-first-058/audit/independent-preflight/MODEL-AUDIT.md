# Study 058 independent model and identifiability review

## Exact model

Fill the 97 physical plaintext letters left to right in an unpadded ragged rectangle of width 6–9, emit physical columns in any permutation top to bottom, and then apply periodic arithmetic at output position j. The equation is C_j = B[(s index_A(P_route[j]) + K_(j mod p)) mod 26], with A and B independently ordinary AZ or KRYPTOS, sign ±, and nominal period 2–8. This differs from 057, where the key phase attaches to original plaintext position. Keys, alphabets and sign are global, not fitted separately by position.

## Missing key residues are structural, not a solver failure

For a fixed route and period, each known plaintext letter constrains one output key residue. The exact ciphertext-independent census over 2,862,720 route/period descriptions gives free-residue counts:

- 0 free: 2,736,856
- 1 free: 83,912
- 2 free: 29,472
- 3 free: 10,680
- 4 free: 1,800

The census was independently reproduced by subset dynamic programming, rather than replaying the same permutation enumeration. All width 6/period 8 routes and width 7/period 7 routes leave 3–4 free residues; all width 8/period 6 routes leave 1–3. No benchmark should require 95% uniqueness across equally weighted cells: this information is structurally insufficient in entire cells.

A compatible fixed-route key cylinder is a period-length vector whose -1 entries are independent unconstrained values. It exactly represents 26^f seeds for f free entries, not a guessed or selected witness. Because every output residue occurs at least once and each letter map is bijective, changing any free residue changes at least one noncrib plaintext letter. Each compatible cylinder with f>0 therefore proves multiple plaintexts, even with the route known. The maximum single-cylinder multiplicity is 456,976. Preserve that ambiguity rather than filling with English.

A union of cylinders may overlap across nominal periods and the zero-key identity alphabet alias. The sum of 26^f over cylinders counts descriptions with multiplicity; it is not the number of distinct operators or plaintexts. Exact emptiness is still decided by zero cylinders. Exact uniqueness is decided by: any free cylinder implies multiple plaintexts; otherwise decode every fixed cylinder and compare complete plaintexts. Full route and 97 output-index letter maps canonicalize fixed operators. When free cylinders exist, report exact cylinder sets and conservative per-cylinder lower bounds, not a fabricated aggregate unique count.

## Independent engines and tiny proof

The independent reference constructs literal ragged rows of original position numbers and inverts the emitted route. It tests every route/period/convention directly and infers key values from physical alphabet-index equations. The separate production engine prunes while choosing columns. Both emit the complete compatible key-cylinder set; no free-key expansion is needed for the real 97-letter domain.

Tiny four-letter tests exhaust every 4-letter ciphertext with three clue masks, widths 2–3 and periods 1–2. All 768 cases give exactly equal compressed production/reference cylinder sets. Expanding every free key and comparing to an independent brute-force key enumeration gives exact complete solution-set equality:49,780 cylinders and 103,156 re-encryptions. Every free-cylinder case is correctly multiple-plaintext. The small-domain reference-only pass is preserved separately; the final joint test passes with inclusiveCPU 8.617 seconds.

## Appropriate benchmark gates

Before target use, freeze the exact arithmetic, bounds, seed policy, resource budget and complete blind evaluation. Require all 520 inputs to complete, all raw cylinders to agree independently, all 464 plants to lie in a returned cylinder, and all inferred forced positions and ambiguity claims to be sound. Report unique recovery for fully constrained generating routes separately from geometry-forced ambiguous routes; do not assert that a fully constrained plant guarantees globally unique recovery. A gate for uniqueness, if retained, must be conditional on eligible strata and declared before blind generation. Uniform random controls measure false compatibility, not the same thing as an out-of-family corrupted plaintext. No natural language score or source corpus is needed to decide the bounded exact model.

The test does not establish that K 4 uses this composition. A complete negative excludes only the exact domain. A compatible cylinder is not an identified plaintext. No target data was used for the geometry census or these tiny controls.

## Coverage novelty and overlap with 057

Reversing the stages does not make every description new: constant keys commute with transposition, and some nonconstant keys can remain periodic after pulling their output phase back along a route. The new certificate supplies an explicit ciphertext-free witness: width 6, natural column order 0–5, AZ/AZ/+ output-index key 0–6 with period 7. Its pulled-back 97-position key stream fails every nominal period 2–8. Equal complete operators must have the same dependency route; the 207-map certificate excludes a different alphabet/sign representation for its nonzero shift maps. Hence this operator is outside 057. This establishes genuinely new bounded coverage without asserting a count of all new operators. All 22.9 million route/period/convention descriptions remain a search count, not a novelty count.

## Pre-freeze correction: period aliases also force ambiguity

Conditioning uniqueness only on the generating nominal period having no free residues is insufficient. A period 2 seed also belongs to the nominal period 4,6,8 domains. If any such allowed multiple has an unobserved residue, that compatible larger-period cylinder permits additional plaintexts. For example, all width 6 period 2 and period 4 plants also admit the ambiguous period 8 cylinder; all width 8 period 2 and period 3 plants embed in ambiguous period 6 cylinders. This is a mathematical limitation discovered before heldout generation, not a benchmark failure to conceal.

The alias-aware route census checks every allowed multiple of the primitive key period. Only 13 cells are always eligible by this stronger criterion,7 are always ambiguous, and 8 depend on the route. With primitive keys,104 of 224 cases per positive class would be guaranteed eligible, not 152. Unfiltered shorter-period keys can weaken even that fixed minimum. Therefore either freeze primitive-key strata and correctly defined conditional recovery gates before generation, or retain full correctness/discrimination gates while reporting uniqueness descriptively. Do not apply a 95% uniqueness gate to a structurally ambiguous denominator or change it after seeing heldout results.


## Final pre-freeze decision

The parent reviewed the structural ambiguity and approved an exact-feasibility and ambiguity-diagnosis objective before any blind fixture generation. The final protocol has **no positive uniqueness-rate threshold and no minimum identifiable denominator**. All uniqueness rates are descriptive. The mandatory gates remain complete production/reference cylinder agreement, all planted keys included, exact projected empty/singleton/multiple classification, correct free-residue ambiguity, and at most one compatible result among the 56 independent random controls. The superseded conditional-threshold draft is retained for provenance; no heldout outcome caused this revision.

The final production transport also verifies that free key slots are exactly the unobserved output residues, re-encrypts both representatives of each free cylinder, checks their clues, and returns distinct plaintext witnesses. The final independent preflight passes after these corrections and the final development rerun. Freeze the reviewed files before generating the 520 heldout fixtures. This approval is for the blind benchmark only, not target evaluation.
