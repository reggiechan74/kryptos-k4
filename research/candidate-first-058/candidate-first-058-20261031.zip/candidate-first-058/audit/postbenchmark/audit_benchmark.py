"""Independent post-seal audit; invoke only after both frozen outputs are sealed."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,resource
from independent import alphabets,parse_convention,route,decrypt,encrypt,free_residues
ROOT=Path('/workspace/shared/candidate-first-058');OUT=ROOT/'audit/postbenchmark';OUT.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return {x['id']:x for x in map(json.loads,Path(p).read_text().splitlines())}
def sig(f):return (f['convention'],f['width'],f['period'],tuple(f['order']),tuple(f['key']))
start=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
manifest=json.loads((ROOT/'freeze/manifest.json').read_text());assert sha(ROOT/'freeze/manifest.json')=='0be0fee99fbbaeb8f46aaff77b9baa32964502b1ad4f55fa8518e2cbe2a318c6'
for name,h in manifest['files'].items():assert sha(ROOT/name)==h,name
seal=json.loads((ROOT/'results/seal.json').read_text())
for name,h in seal['hashes'].items():assert sha(ROOT/name)==h,name
# Recreate all fixtures from preserved seed after seal, with no solving or sample selection.
seed=json.loads((ROOT/'fixtures/seed.json').read_text())['seed_hex'];rep=OUT/'fixture-replay'
assert not rep.exists(),'No silent replay overwrite'
subprocess.check_call([sys.executable,str(ROOT/'source/generate_fixtures.py'),'--out',str(rep),'--freeze',str(ROOT/'freeze/manifest.json'),'--seed',seed],stdout=subprocess.DEVNULL)
for name in ('inputs.jsonl','answers.jsonl'):assert sha(rep/name)==sha(ROOT/'fixtures'/name)
I,A,P,R=map(read,[ROOT/'fixtures/inputs.jsonl',ROOT/'fixtures/answers.jsonl',ROOT/'results/production.jsonl',ROOT/'results/reference.jsonl']);assert len(I)==520 and I.keys()==A.keys()==P.keys()==R.keys()
ct={'complete_cases':0,'exact_cylinder_sets':0,'plants':0,'plants_included':0,'controls':0,'control_fits':0,'uniform_total':0,'uniform_unique':0,'literal_total':0,'literal_unique':0,'generating_free_plants':0,'generating_free_correctly_multiple':0,'reencrypted_representatives':0,'cylinders':0,'reference_trials':0,'generating_covered_but_multiple':0,'generating_covered_alias_forced_multiple':0};rows=[];maxrss=0;maxcpu=0
AA=alphabets()
for ident,case in I.items():
 cipher=[ord(x)-65 for x in case['ciphertext']];clues=[(i,ord(x)-65) for i,x in case['clues']];p,r,answer=P[ident],R[ident],A[ident]
 assert p['complete'] and r['complete'];ct['complete_cases']+=1
 assert r['routes']==408960 and r['route_period_convention_trials']==22901760;ct['reference_trials']+=r['route_period_convention_trials']
 assert set(map(sig,p['families']))==set(map(sig,r['families']));ct['exact_cylinder_sets']+=1
 fixed_plain=set();allzero_plain=set();representatives=set();anyfree=False;upper=0;lower=0;maxfree=0
 for f in p['families']:
  ct['cylinders']+=1;pa,ca,s=parse_convention(f['convention']);invA={x:j for j,x in enumerate(AA[pa])};invB={x:j for j,x in enumerate(AA[ca])};rr=route(97,f['width'],f['order']);ir={i:j for j,i in enumerate(rr)};key=[-1]*f['period']
  for i,x in clues:
   j=ir[i];res=j%f['period'];value=(invB[cipher[j]]-s*invA[x])%26
   assert key[res] in (-1,value);key[res]=value
  assert key==f['key'];free=[j for j,x in enumerate(key) if x<0];assert free==free_residues(97,f['width'],f['order'],f['period'],[i for i,x in clues]);maxfree=max(maxfree,len(free));assert len(free)<=4
  anyfree|=bool(free);volume=26**len(free);upper+=volume;lower=max(lower,volume)
  base=[max(v,0) for v in key];samples=[base]
  for j in free:
   k=list(base);k[j]=1;samples.append(k)
  for k in samples:
   pt=decrypt(cipher,k,f['width'],f['order'],f['convention']);assert all(pt[i]==x for i,x in clues);assert encrypt(pt,k,f['width'],f['order'],f['convention'])==cipher;representatives.add(''.join(chr(x+65) for x in pt));ct['reencrypted_representatives']+=1
  pt=''.join(chr(x+65) for x in decrypt(cipher,base,f['width'],f['order'],f['convention']));allzero_plain.add(pt)
  if not free:fixed_plain.add(pt)
 if not p['families']:status='UNSAT_COMPLETE'
 elif anyfree or len(allzero_plain)>1:status='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
 else:status='SAT_COMPLETE_UNIQUE_PLAINTEXT'
 for result in (p,r):
  pr=result['projection'];assert pr['status']==status;assert pr['contains_free_residue']==anyfree;assert pr['max_free_residues']==maxfree
  assert pr['plaintext_count_lower_bound']==max(lower,len(allzero_plain));assert pr['plaintext_count_upper_bound']==(upper if anyfree else len(allzero_plain));assert pr['distinct_plaintext_count']==(None if anyfree else len(allzero_plain));assert len(pr['plaintext_witnesses'])==len(set(pr['plaintext_witnesses']));assert set(pr['plaintext_witnesses'])<=representatives
  if status=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS':assert len(set(pr['plaintext_witnesses']))==2
  maxrss=max(maxrss,result['peak_rss_kib']);maxcpu=max(maxcpu,result['cpu_seconds']);assert result['cpu_seconds']<60
 truth=answer['truth'];included=None;alias_periods=[]
 if truth:
  ct['plants']+=1;included=any(f['convention']==truth['convention'] and f['width']==truth['width'] and f['period']==truth['period'] and f['order']==truth['order'] and all(v<0 or v==truth['key'][j] for j,v in enumerate(f['key'])) for f in p['families']);assert included;ct['plants_included']+=1
  plain=[ord(x)-65 for x in truth['plaintext']];assert encrypt(plain,truth['key'],truth['width'],truth['order'],truth['convention'])==cipher
  free=free_residues(97,truth['width'],truth['order'],truth['period'],[i for i,x in clues]);assert free==truth['free_residues'] and len(free)==truth['planted_free_residue_count']
  if free:ct['generating_free_plants']+=1;assert status=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS';ct['generating_free_correctly_multiple']+=1
  else:
   if status=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS':ct['generating_covered_but_multiple']+=1
   seedkey=truth['key'];primitive=next(d for d in range(1,len(seedkey)+1) if len(seedkey)%d==0 and all(v==seedkey[j%d] for j,v in enumerate(seedkey)))
   alias_periods=[q for q in range(2,9) if q%primitive==0 and free_residues(97,truth['width'],truth['order'],q,[i for i,x in clues])]
   if alias_periods:
    assert status=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS';ct['generating_covered_alias_forced_multiple']+=1
    for q in alias_periods:
     extended=[seedkey[j%primitive] for j in range(q)]
     assert any(f['convention']==truth['convention'] and f['width']==truth['width'] and f['period']==q and f['order']==truth['order'] and all(v<0 or v==extended[j] for j,v in enumerate(f['key'])) for f in p['families'])
  if answer['category'] in ('uniform','literal'):
   cat=answer['category'];ct[cat+'_total']+=1;ct[cat+'_unique']+=status=='SAT_COMPLETE_UNIQUE_PLAINTEXT'
 else:ct['controls']+=1;ct['control_fits']+=bool(p['families'])
 rows.append({'id':ident,'status':status,'cylinder_count':len(p['families']),'max_free':maxfree,'plant_included':included,'longer_period_alias_free_slots':alias_periods})
assert ct['plants']==ct['plants_included']==464 and ct['controls']==56 and ct['control_fits']<=1
receipts=[json.loads((ROOT/'results'/f'{engine}.receipt.json').read_text()) for engine in ('production','reference')]
for engine,rec in zip(('production','reference'),receipts):
 assert rec['status']=='completed' and rec['failure'] is None and rec['count']==520;assert rec['output_sha256']==sha(ROOT/'results'/f'{engine}.jsonl');assert rec['input_sha256']==sha(ROOT/'fixtures/inputs.jsonl');assert rec['hard_worker_address_space_bytes']==rec['hard_child_address_space_bytes']==1024**3
ledger=json.loads((ROOT/'results/resource-ledger.json').read_text());assert ledger['charged_cpu_seconds']<28800
r1=resource.getrusage(resource.RUSAGE_CHILDREN);output={'status':'PASS_FOR_PARENT_TARGET_REVIEW','frozen_files_verified':len(manifest['files']),'fixture_replay_exact':True,'counts':ct,'max_child_cpu_seconds':maxcpu,'max_child_rss_kib':maxrss,'resource_ledger_charge_before_audit':ledger['charged_cpu_seconds'],'audit_inclusive_cpu_seconds':time.process_time()-start+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'classification_note':'Uniqueness is descriptive, not a recovery gate. Exact cylinder feasibility and independent empty/unique/multiple classifications pass. Free-cylinder union counts intentionally withheld.','target_run':False,'cases':rows}
(OUT/'FINAL-AUDIT.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items() if k!='cases'},indent=2))
