# Study 058 independent benchmark audit

**PASS FOR PARENT TARGET REVIEW.** This audit does not itself authorize a K4 run.

- Verified all 34 frozen file hashes and the pre-answer result seals.
- Replayed fixture generation exactly from the preserved seed.
- All 520 production/reference runs completed with identical complete key-cylinder sets and correct independent empty/singleton/multiple-plaintext classifications.
- All 464 planted keys belong to returned cylinders; none of the 56 independent random controls has a compatible cylinder.
- Checked 893 compatible cylinders, exact observed/free residue geometry, and 1,312 physical-letter representative re-encryptions.
- All 68 plants whose generating period has free slots are correctly multiple-plaintext.
- Descriptive unique plaintexts: 156/224 uniform and 150/224 literal-clue positives. These rates are not a gate under the frozen exact-feasibility protocol.
- Among plants with a fully observed generating key, 90 nevertheless have multiple plaintexts. For 89, the audit verifies a compatible larger nominal-period cylinder with free slots; one has another compatible explanation. This validates the pre-freeze decision not to equate a fully observed generating period with global identifiability.
- All 11,908,915,200 exhaustive reference route/period/convention trials completed. Maximum child CPU was 4.608 seconds; conservative worker-plus-child peak memory was 20,742,144 bytes.
- Audit CPU: 0.315 seconds. Charge one second conservatively in the shared ledger.

The audit uses independent physical-letter encryption/decryption, explicit output routes and free-slot geometry. It does not reuse the production projection function. Cylinder volumes remain overlapping description counts; distinct union counts are not fabricated. The raw audit receipt and per-case classifications are in FINAL-AUDIT.json. No target data was evaluated.
