"""Frozen 058 benchmark gates; answers read only after both outputs are sealed."""
import argparse,json,hashlib
from pathlib import Path
from model import ROOT,signature,project,encrypt,decrypt,route

def read(p):return {x['id']:x for x in map(json.loads,Path(p).read_text().splitlines())}
def main():
 ap=argparse.ArgumentParser()
 for key in ('inputs','answers','production','reference','output'):ap.add_argument(key)
 a=ap.parse_args();I,A,P,R=map(read,[a.inputs,a.answers,a.production,a.reference]);assert I.keys()==A.keys()==P.keys()==R.keys()
 ct={'complete':0,'cylinder_agreement':0,'projection_agreement':0,'plants':0,'plants_included':0,'ambiguous_plants':0,'ambiguous_classified_multiple':0,'uniform_fully_observed':0,'uniform_unique':0,'literal_fully_observed':0,'literal_unique':0,'uniform_total':0,'uniform_total_unique':0,'literal_total':0,'literal_total_unique':0,'controls':0,'control_fits':0};cases=[]
 for ident,i in I.items():
  p,q,ans=P[ident],R[ident],A[ident];ct['complete']+=p['complete'] and q['complete'];ct['cylinder_agreement']+=set(map(signature,p['families']))==set(map(signature,q['families']))
  pp,qq=project(p,i['ciphertext']),project(q,i['ciphertext']);ct['projection_agreement']+=pp['status']==qq['status'] and pp['cylinder_set_sha256']==qq['cylinder_set_sha256'] and pp['distinct_plaintext_count']==qq['distinct_plaintext_count']
  truth=ans['truth'];included=None;free=None
  if ans['category'] in ('uniform','literal'):
   cat=ans['category'];ct[cat+'_total']+=1;ct[cat+'_total_unique']+=pp['status']=='SAT_COMPLETE_UNIQUE_PLAINTEXT'
  if truth:
   ct['plants']+=1;free=truth['planted_free_residue_count']
   # Exact generating route/period cylinder must contain the planted seed.
   included=any(f['convention']==truth['convention'] and f['width']==truth['width'] and f['period']==truth['period'] and f['order']==truth['order'] and all(v<0 or v==truth['key'][j] for j,v in enumerate(f['key'])) for f in p['families']);ct['plants_included']+=included
   assert encrypt(truth['plaintext'],truth['key'],truth['width'],truth['order'],truth['convention'])==i['ciphertext']
   rr=route(97,truth['width'],truth['order']);observed={rr.index(j)%truth['period'] for j,x in i['clues']};assert free==truth['period']-len(observed)
   if free:ct['ambiguous_plants']+=1;ct['ambiguous_classified_multiple']+=pp['status']=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
   elif ans['category'] in ('uniform','literal'):
    cat=ans['category'];ct[cat+'_fully_observed']+=1;ct[cat+'_unique']+=pp['status']=='SAT_COMPLETE_UNIQUE_PLAINTEXT'
  else:ct['controls']+=1;ct['control_fits']+=bool(p['families'])
  cases.append({'id':ident,'category':ans['category'],'plant_included':included,'planted_free_residues':free,'projection':pp})
 gates={'all_complete':ct['complete']==520,'all_cylinders_equal':ct['cylinder_agreement']==520,'all_projections_equal':ct['projection_agreement']==520,'all_plants':ct['plants']==464 and ct['plants_included']==464,'all_ambiguous_correct':ct['ambiguous_plants']==ct['ambiguous_classified_multiple'],'random_fits':ct['controls']==56 and ct['control_fits']<=1}
 out={'counts':ct,'gates':gates,'all_numeric_gates_pass':all(gates.values()),'cases':cases,'input_hashes':{k:hashlib.sha256(Path(getattr(a,k)).read_bytes()).hexdigest() for k in ('inputs','answers','production','reference')},'interpretation':'Uniqueness rates are descriptive across all fixtures and geometry strata, not a gate. Nominal-period aliases can add free slots even when the generating period is covered. All ambiguous cases retained. Complete cylinders may overlap, so their volumes are not distinct union counts.'}
 Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
