"""Pre-freeze full alphabet reverse-order controls, no target."""
import random,json,time,resource
from model import ROOT,MASK,AZ,encrypt,solve,signature
r=random.Random(580002);start=time.process_time();before=resource.getrusage(resource.RUSAGE_CHILDREN);cases=[]
for cv in range(8):
 for period in (5,7):
  plain=''.join(r.choice(AZ) for _ in range(97));order=list(range(7));r.shuffle(order);key=[r.randrange(26) for _ in range(period)]
  if cv in (0,6) and period==7:key=[0]*period
  c=encrypt(plain,key,7,order,cv);i={'id':f'dev-{cv}-{period}','ciphertext':c,'clues':[(j,plain[j]) for j in MASK]};p=solve(i,'production');q=solve(i,'reference')
  assert set(map(signature,p['families']))==set(map(signature,q['families']))
  assert p['projection']['status']==q['projection']['status']
  assert any(f['convention']==cv and f['width']==7 and f['period']==period and f['order']==order and all(x<0 or x==key[j] for j,x in enumerate(f['key'])) for f in p['families'])
  if period==7:assert p['projection']['status']=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
  cases.append({'id':i['id'],'projection':p['projection'],'production_cpu':p['inclusive_cpu_seconds'],'reference_cpu':q['inclusive_cpu_seconds']})
after=resource.getrusage(resource.RUSAGE_CHILDREN);o={'status':'PASS','cases':cases,'inclusive_cpu_seconds':time.process_time()-start+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime};(ROOT/'development/full-alphabet-controls.json').write_text(json.dumps(o,indent=2)+'\n');print(o['status'],len(cases),o['inclusive_cpu_seconds'])
