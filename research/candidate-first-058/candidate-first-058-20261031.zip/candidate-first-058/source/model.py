"""Study 058 reverse-stage physical-letter model and exact cylinder projections."""
from pathlib import Path
import hashlib,json,resource,subprocess,time
ROOT=Path(__file__).resolve().parents[1]
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KR='KRYPTOSABCDEFGHIJLMNQUVWXZ';ALPH=[AZ,KR]
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def roles(cv):return cv//4,(cv//2)%2,1 if cv%2==0 else -1
def route(n,w,order):return [i for c in order for i in range(c,n,w)]
def encrypt(plain,key,w,order,cv):
 a,b,s=roles(cv);return ''.join(ALPH[b][(s*ALPH[a].index(plain[i])+key[j%len(key)])%26] for j,i in enumerate(route(len(plain),w,order)))
def decrypt(cipher,key,w,order,cv):
 a,b,s=roles(cv);plain=['?']*len(cipher)
 for j,i in enumerate(route(len(cipher),w,order)):plain[i]=ALPH[a][s*(ALPH[b].index(cipher[j])-key[j%len(key)])%26]
 return ''.join(plain)
def canonical(f,n):
 a,b,s=roles(f['convention']);key=f['key'];rr=route(n,f['width'],f['order']);maps=[''.join(ALPH[b][(s*ALPH[a].index(x)+key[j%len(key)])%26] for x in AZ) for j in range(n)]
 return tuple(rr),tuple(maps)
def signature(f):return f['convention'],f['width'],f['period'],tuple(f['order']),tuple(f['key'])
def project(obj,cipher):
 fs=obj['families'];raw=set(map(signature,fs));anyfree=any(-1 in f['key'] for f in fs);plaintexts=set();operators=set();witnesses=[];lo=0;upper=0
 for f in fs:
  free=f['key'].count(-1);size=26**free;lo=max(lo,size);upper+=size
  key=[max(v,0) for v in f['key']];pt=decrypt(cipher,key,f['width'],f['order'],f['convention']);plaintexts.add(pt)
  if len(witnesses)<2 and pt not in witnesses:witnesses.append(pt)
  if free:
   key[f['key'].index(-1)]=1;other=decrypt(cipher,key,f['width'],f['order'],f['convention']);assert other!=pt
   witnesses=[pt,other]
  else:operators.add(canonical(f,len(cipher)))
 if not fs:status='UNSAT_COMPLETE'
 elif anyfree or len(plaintexts)>1:status='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
 else:status='SAT_COMPLETE_UNIQUE_PLAINTEXT'
 def digest(v):return hashlib.sha256(json.dumps(sorted(v),separators=(',',':')).encode()).hexdigest()
 return {'status':status,'raw_key_cylinders':len(raw),'cylinder_set_sha256':digest(raw),'contains_free_residue':anyfree,'max_free_residues':max((f['key'].count(-1) for f in fs),default=0),'distinct_plaintext_count':None if anyfree else len(plaintexts),'distinct_operator_count':None if anyfree else len(operators),'plaintext_count_lower_bound':max(lo,len(plaintexts)),'plaintext_count_upper_bound':upper if anyfree else len(plaintexts),'union_count_note':'Cylinder volumes overlap across nominal periods and conventions; sum is only an upper bound. Exact distinct counts withheld when free slots exist.','plaintext_witnesses':witnesses[:2]}
def request(case,widths=(6,7,8,9),periods=tuple(range(2,9)),limit=60):
 C=[ord(x)-65 for x in case['ciphertext']];Q=case['clues'];v=[len(C),26,limit,len(widths),*widths,len(periods),*periods,len(Q),*C]
 v += [y for i,x in Q for y in (i,ord(x)-65)]
 return ' '.join(map(str,v))+'\n'
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(65,65))
def solve(case,engine):
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.process_time();wall=time.monotonic()
 p=subprocess.run([str(ROOT/'source'/('solver' if engine=='production' else 'reference'))],input=request(case),text=True,capture_output=True,timeout=90,preexec_fn=limits)
 if p.returncode:raise RuntimeError((engine,p.returncode,p.stderr))
 o=json.loads(p.stdout)
 if not o['complete']:raise RuntimeError('INCONCLUSIVE: incomplete '+engine)
 for f in o['families']:
  rr=route(len(case['ciphertext']),f['width'],f['order']);observed={rr.index(i)%f['period'] for i,x in case['clues']}
  assert {j for j,v in enumerate(f['key']) if v<0}==set(range(f['period']))-observed
  if -1 in f['key']:
   alternative=[max(x,0) for x in f['key']];alternative[f['key'].index(-1)]=1
   altpt=decrypt(case['ciphertext'],alternative,f['width'],f['order'],f['convention'])
   assert all(altpt[i]==x for i,x in case['clues']);assert encrypt(altpt,alternative,f['width'],f['order'],f['convention'])==case['ciphertext']
  k=[max(x,0) for x in f['key']];pt=decrypt(case['ciphertext'],k,f['width'],f['order'],f['convention'])
  assert all(pt[i]==x for i,x in case['clues']);assert encrypt(pt,k,f['width'],f['order'],f['convention'])==case['ciphertext']
 after=resource.getrusage(resource.RUSAGE_CHILDREN);o['inclusive_cpu_seconds']=time.process_time()-start+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime;o['wall_seconds']=time.monotonic()-wall;o['projection']=project(o,case['ciphertext']);return o
