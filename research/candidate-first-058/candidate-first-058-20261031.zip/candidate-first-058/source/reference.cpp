// Study 058 independent direct row-matrix/key-cylinder exhaustive reference.
#include <algorithm>
#include <ctime>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
#include <sys/resource.h>
using namespace std; using VI=vector<int>;
double cpu(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
struct Family{int convention,width,period; VI order,key;};
void arr(const VI& a){cout<<'[';for(size_t i=0;i<a.size();++i){if(i)cout<<',';cout<<a[i];}cout<<']';}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);int n,m,nw,np,nc;double limit;while(cin>>n>>m>>limit>>nw){VI widths(nw);for(int&v:widths)cin>>v;cin>>np;VI periods(np);for(int&v:periods)cin>>v;cin>>nc;VI C(n);for(int&v:C)cin>>v;vector<pair<int,int>>clues(nc);for(auto&[i,v]:clues)cin>>i>>v;if(!cin||n<1||n>100||(m!=4&&m!=26)||limit<=0)return 2;
 vector<VI>A(2,VI(m)),I(2,VI(m));iota(A[0].begin(),A[0].end(),0);string kr=m==26?"KRYPTOSABCDEFGHIJLMNQUVWXZ":"ACDB";for(int j=0;j<m;++j)A[1][j]=kr[j]-'A';for(int a=0;a<2;++a)for(int j=0;j<m;++j)I[a][A[a][j]]=j;for(int x:C)if(x<0||x>=m)return 2;for(auto[i,v]:clues)if(i<0||i>=n||v<0||v>=m)return 2;
 double start=cpu();bool complete=true;long long trials=0,routes=0;vector<Family>families;auto mod=[&](int x){x%=m;return x<0?x+m:x;};
 for(int width:widths){if(width<1||width>n||width>10)return 2;VI order(width);iota(order.begin(),order.end(),0);do{if(!complete)break;++routes;
  vector<VI>rows;for(int off=0;off<n;off+=width){VI row;for(int i=off;i<min(n,off+width);++i)row.push_back(i);rows.push_back(row);}VI inverse_route(n,-1);int cursor=0;for(int col:order)for(auto&row:rows)if(col<(int)row.size())inverse_route[row[col]]=cursor++;if(cursor!=n)return 3;
  for(int period:periods){if(period<1||period>8)return 2;for(int pa=0;pa<2;++pa)for(int ca=0;ca<2;++ca)for(int sign:{1,-1}){if((trials++&1023)==0&&cpu()-start>limit){complete=false;break;}VI key(period,-1);bool valid=true;
   for(auto[position,plain]:clues){int j=inverse_route[position],residue=j%period;int inferred=mod(I[ca][C[j]]-sign*I[pa][plain]);if(key[residue]>=0&&key[residue]!=inferred){valid=false;break;}key[residue]=inferred;}
   if(valid)families.push_back({pa*4+ca*2+(sign==-1),width,period,order,key});
  }if(!complete)break;}
 }while(complete&&next_permutation(order.begin(),order.end()));if(!complete)break;}
 rusage usage;getrusage(RUSAGE_SELF,&usage);cout.precision(12);cout<<"{\"complete\":"<<(complete?"true":"false")<<",\"cpu_seconds\":"<<cpu()-start<<",\"peak_rss_kib\":"<<usage.ru_maxrss<<",\"routes\":"<<routes<<",\"route_period_convention_trials\":"<<trials<<",\"families\":[";
 for(size_t j=0;j<families.size();++j){if(j)cout<<',';auto&v=families[j];cout<<"{\"convention\":"<<v.convention<<",\"width\":"<<v.width<<",\"period\":"<<v.period<<",\"order\":";arr(v.order);cout<<",\"key\":";arr(v.key);cout<<'}';}cout<<"]}\n";cout.flush();}}
