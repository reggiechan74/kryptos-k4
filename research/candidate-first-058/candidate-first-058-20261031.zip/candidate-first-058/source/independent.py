"""Study 058 independent row-matrix encryption and tiny exhaustive oracle."""
import itertools
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'
def alphabets(m=26):return [list(range(m)),[ord(x)-65 for x in (KR if m==26 else 'ACDB')]]
def parse_convention(conv):return conv//4,(conv//2)%2,1 if conv%2==0 else -1
def route(n,width,order):
 rows=[list(range(j,min(n,j+width))) for j in range(0,n,width)]
 return [row[col] for col in order for row in rows if col<len(row)]
def encrypt(plain,key,width,order,conv,m=26):
 aa=alphabets(m);pa,ca,sign=parse_convention(conv);inv={x:j for j,x in enumerate(aa[pa])}
 transposed=[plain[i] for i in route(len(plain),width,order)]
 return [aa[ca][(sign*inv[v]+key[j%len(key)])%m] for j,v in enumerate(transposed)]
def decrypt(cipher,key,width,order,conv,m=26):
 aa=alphabets(m);pa,ca,sign=parse_convention(conv);inv={x:j for j,x in enumerate(aa[ca])}
 transposed=[aa[pa][(sign*(inv[v]-key[j%len(key)]))%m] for j,v in enumerate(cipher)]
 out=[None]*len(cipher)
 for i,v in zip(route(len(cipher),width,order),transposed):out[i]=v
 return out

def signature(w,key=None,plaintext=None):
 return (w['convention'],w['width'],w['period'],tuple(w['order']),tuple(w['key'] if key is None else key),tuple(plaintext or []))
def expand(w,m=4):
 missing=[j for j,x in enumerate(w['key']) if x<0]
 for vals in itertools.product(range(m),repeat=len(missing)):
  k=list(w['key'])
  for j,v in zip(missing,vals):k[j]=v
  yield k

def brute(cipher,clues,widths,periods,m=4):
 answers=set()
 for width in widths:
  for order in itertools.permutations(range(width)):
   for period in periods:
    for conv in range(8):
     for key in itertools.product(range(m),repeat=period):
      plain=decrypt(cipher,key,width,order,conv,m)
      if all(plain[i]==v for i,v in clues):answers.add((conv,width,period,tuple(order),tuple(key),tuple(plain)))
 return answers

def line(cipher,clues,widths,periods,m=26,limit=20):return ' '.join(map(str,[len(cipher),m,limit,len(widths),*widths,len(periods),*periods,len(clues),*cipher,*itertools.chain.from_iterable(clues)]))+'\n'
def free_residues(n,width,order,period,mask):
 inverse={i:j for j,i in enumerate(route(n,width,order))}
 return sorted(set(range(period))-{inverse[i]%period for i in mask})
