// Study 058 production: prefix column placement and periodic-key cylinder propagation.
#include <algorithm>
#include <vector>
#include <numeric>
#include <iostream>
#include <ctime>
#include <functional>
#include <sys/resource.h>
using namespace std;using V=vector<int>;
double cpu(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
void arr(const V&v){cout<<'[';for(int i=0;i<(int)v.size();i++){if(i)cout<<',';cout<<v[i];}cout<<']';}
struct Answer{int cv,w,p;V order,key;};
int main(){int n,m,nw,np,nc;double limit;while(cin>>n>>m>>limit>>nw){V widths(nw);for(int&v:widths)cin>>v;cin>>np;V periods(np);for(int&v:periods)cin>>v;cin>>nc;V C(n);for(int&v:C)cin>>v;vector<pair<int,int>>Q(nc);for(auto&[i,x]:Q)cin>>i>>x;if(!cin||n<1||n>100||(m!=4&&m!=26))return 2;V A[2],I[2];A[0].resize(m);iota(A[0].begin(),A[0].end(),0);string k=m==26?"KRYPTOSABCDEFGHIJLMNQUVWXZ":"ACDB";for(char c:k)A[1].push_back(c-'A');for(int a=0;a<2;a++){I[a].resize(m);for(int j=0;j<m;j++)I[a][A[a][j]]=j;}
 for(int x:C)if(x<0||x>=m)return 2;for(auto[i,x]:Q)if(i<0||i>=n||x<0||x>=m)return 2;
 auto mod=[&](int x){x%=m;return x<0?x+m:x;};double start=cpu();bool complete=true;long long nodes=0,leaves=0,placements=0;vector<Answer>answers;
 for(int w:widths){if(w<1||w>n||w>10)return 2;V lens(w);for(int c=0;c<w;c++)lens[c]=(n-1-c)/w+1;
  for(int p:periods){if(p<1||p>9)return 2;for(int cv=0;cv<8;cv++){int pa=cv/4,ca=(cv/2)%2,s=cv%2?-1:1;V order;
   function<void(int,int,V)> dfs=[&](int used,int off,V key){if(!complete)return;if((nodes++&1023)==0&&cpu()-start>limit){complete=false;return;}if((int)order.size()==w){leaves++;answers.push_back({cv,w,p,order,key});return;}
    for(int c=0;c<w;c++)if(!(used&(1<<c))){placements++;V next=key;bool ok=true;for(auto[i,x]:Q)if(i%w==c){int j=off+i/w,r=j%p,v=mod(I[ca][C[j]]-s*I[pa][x]);if(next[r]>=0&&next[r]!=v){ok=false;break;}next[r]=v;}if(ok){order.push_back(c);dfs(used|(1<<c),off+lens[c],next);order.pop_back();}}
   };dfs(0,0,V(p,-1));if(!complete)break;}if(!complete)break;}if(!complete)break;}
 rusage r;getrusage(RUSAGE_SELF,&r);cout.precision(12);cout<<"{\"complete\":"<<(complete?"true":"false")<<",\"cpu_seconds\":"<<cpu()-start<<",\"peak_rss_kib\":"<<r.ru_maxrss<<",\"prefix_nodes\":"<<nodes<<",\"placements\":"<<placements<<",\"compatible_route_leaves\":"<<leaves<<",\"families\":[";for(int z=0;z<(int)answers.size();z++){if(z)cout<<',';auto&a=answers[z];cout<<"{\"convention\":"<<a.cv<<",\"width\":"<<a.w<<",\"period\":"<<a.p<<",\"order\":";arr(a.order);cout<<",\"key\":";arr(a.key);cout<<'}';}cout<<"]}\n";cout.flush();}}
