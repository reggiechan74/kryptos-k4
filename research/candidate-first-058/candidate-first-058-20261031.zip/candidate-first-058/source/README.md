# Reproduction

Compile `solver.cpp` and `reference.cpp` with `g++ -O3 -std=c++17`, producing binaries named `solver` and `reference` in this folder. The production method uses prefix constraints; the independent reference enumerates all routes. Each emits exact compatible key cylinders, with -1 denoting a completely free numeric key slot.

Run the independent tiny exhaustive tests and development controls before any target use. Some retained audit scripts use their original absolute workspace paths; replace only those paths with the extracted archive location when reproducing, documenting that transport change. The mathematical algorithms do not depend on those paths.

Blind fixture generation is `python3 source/generate_fixtures.py --out fixtures --freeze freeze/manifest.json`. Do not regenerate a new sample to replace unfavorable outcomes. A seed replay is only for exact reproduction. Solver input must omit the separately retained answer and seed files.

Run `python3 source/run_batch.py production fixtures/inputs.jsonl results/production.jsonl`, then the equivalent `reference` command. Runs are sequential and charge the shared resource ledger even on failure. Seal both output hashes before opening answers. Calculate gates with `python3 source/analyze.py fixtures/inputs.jsonl fixtures/answers.jsonl results/production.jsonl results/reference.jsonl results/benchmark.json`.

A compatible cylinder is not a unique plaintext. Do not add cylinder volumes as distinct operator or plaintext counts; period and convention aliases overlap. The full compressed family set is retained. The exact empty/singleton/multiple classification and explicitly bounded counts are the relevant output.
