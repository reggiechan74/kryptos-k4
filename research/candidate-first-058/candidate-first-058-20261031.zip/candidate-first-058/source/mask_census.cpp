#include <algorithm>
#include <iostream>
#include <vector>
#include <numeric>
#include <map>
using namespace std;
int main(){cout<<"[";bool first=true;for(int w=6;w<=9;w++){vector<int>o(w);iota(o.begin(),o.end(),0);map<int,map<int,long long>> hist;long long routes=0;do{int j=0;vector<int>positions;for(int c:o)for(int i=c;i<97;i+=w){if((i>=21&&i<34)||(i>=63&&i<74))positions.push_back(j);j++;}for(int p=2;p<=8;p++){int bits=0;for(int v:positions)bits|=1<<(v%p);hist[p][p-__builtin_popcount((unsigned)bits)]++;}routes++;}while(next_permutation(o.begin(),o.end()));for(auto[p,h]:hist){if(!first)cout<<",";first=false;cout<<"{\"width\":"<<w<<",\"period\":"<<p<<",\"routes\":"<<routes<<",\"free_residue_histogram\":{";bool f=true;for(auto[k,v]:h){if(!f)cout<<",";f=false;cout<<"\""<<k<<"\":"<<v;}cout<<"}}";}}cout<<"]\n";}
