"""Study 058 independently generated blind reverse-stage fixtures. No solver imports."""
import argparse,hashlib,json,pathlib,random,secrets,time
from independent import encrypt,free_residues
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--freeze',required=True);ap.add_argument('--seed',help='Replay only: prior hexadecimal seed');args=ap.parse_args()
 freeze=pathlib.Path(args.freeze);assert freeze.is_file();out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True);assert not (out/'inputs.jsonl').exists()
 seed=args.seed or secrets.token_hex(32);rng=random.Random(int(seed,16));items=[]
 def add(category,conv=None,width=None,period=None,key=None,literal=False):
  if category=='control':
   cipher=[rng.randrange(26) for _ in range(97)];clues=[(i,ord(v)-65) for i,v in zip(MASK,LITERAL)] if literal else [(i,rng.randrange(26)) for i in MASK];truth=None
  else:
   plain=[rng.randrange(26) for _ in range(97)]
   if literal:
    for i,v in zip(MASK,LITERAL):plain[i]=ord(v)-65
   key=list(key) if key is not None else [rng.randrange(26) for _ in range(period)]
   order=list(range(width));rng.shuffle(order);cipher=encrypt(plain,key,width,order,conv);clues=[(i,plain[i]) for i in MASK]
   free=free_residues(97,width,order,period,MASK)
   truth={'convention':conv,'width':width,'period':period,'order':order,'key':key,'plaintext':''.join(chr(x+65) for x in plain),'free_residues':free,'observed_residues':sorted(set(range(period))-set(free)),'planted_free_residue_count':len(free),'planted_same_route_plaintext_count':26**len(free)}
  items.append(({'ciphertext':''.join(chr(x+65) for x in cipher),'clues':[[i,chr(x+65)] for i,x in clues]}, {'category':category,'literal_clues':literal,'truth':truth}))
 for category,literal in [('uniform',False),('literal',True)]:
  for conv in range(8):
   for width in (6,7,8,9):
    for period in range(2,9):add(category,conv,width,period,literal=literal)
 for conv in range(8):
  value=0 if conv in (0,6) else rng.randrange(26);add('alias',conv,7,6,[value]*6)
  a=rng.randrange(26);b=(a+1+rng.randrange(25))%26;add('alias',conv,8,8,[a,b]*4)
 for literal in (False,True):
  for _ in range(28):add('control',literal=literal)
 assert len(items)==520;rng.shuffle(items);public=[];answers=[]
 for j,(p,a) in enumerate(items):
  ident=f'058-B{j:04d}';public.append({'id':ident,**p});answers.append({'id':ident,**a})
 def write(name,values):
  p=out/name;p.write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in values));return hashlib.sha256(p.read_bytes()).hexdigest()
 receipt={'version':'058-independent-fixtures-v1','created_unix':time.time(),'freeze_sha256':hashlib.sha256(freeze.read_bytes()).hexdigest(),'seed_sha256':hashlib.sha256(seed.encode()).hexdigest(),'count':520,'input_sha256':write('inputs.jsonl',public),'answers_sha256':write('answers.jsonl',answers),'counts':{'uniform':224,'literal':224,'alias':16,'control':56},'filtering':'none; keys and routes unfiltered, ambiguity labels derived from geometry only'}
 (out/'seed.json').write_text(json.dumps({'seed_hex':seed,'namespace':'058-independent-blind-v1'},indent=2)+'\n');(out/'generation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
