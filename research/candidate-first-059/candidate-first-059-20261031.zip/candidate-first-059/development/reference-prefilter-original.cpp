// Study 059 independent literal row-matrix autokey reference. No target data.
#include <algorithm>
#include <ctime>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
#include <sys/resource.h>
using namespace std;using V=vector<int>;
double cpu(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
struct Cylinder{int convention,feedback,width,length;V order,primer,plaintext;};
void arr(const V&v){cout<<'[';for(size_t i=0;i<v.size();i++){if(i)cout<<',';cout<<v[i];}cout<<']';}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);int n,m,nw,nl,nc;double limit;while(cin>>n>>m>>limit>>nw){V widths(nw);for(int&x:widths)cin>>x;cin>>nl;V lengths(nl);for(int&x:lengths)cin>>x;cin>>nc;V C(n);for(int&x:C)cin>>x;vector<pair<int,int>> clues(nc);for(auto&[i,x]:clues)cin>>i>>x;
 if(!cin||n<1||n>100||(m!=4&&m!=26)||limit<=0)return 2;for(int x:C)if(x<0||x>=m)return 2;for(auto[i,x]:clues)if(i<0||i>=n||x<0||x>=m)return 2;
 vector<V>A(2,V(m)),I(2,V(m));iota(A[0].begin(),A[0].end(),0);string kr=m==26?"KRYPTOSABCDEFGHIJLMNQUVWXZ":"ACDB";for(int j=0;j<m;j++)A[1][j]=kr[j]-'A';for(int a=0;a<2;a++)for(int j=0;j<m;j++)I[a][A[a][j]]=j;
 auto mod=[&](int x){x%=m;return x<0?x+m:x;};double start=cpu();long long routes=0,trials=0;bool complete=true;vector<Cylinder> sols;
 for(int w:widths){if(w<1||w>n||w>10)return 2;V order(w);iota(order.begin(),order.end(),0);do{if(!complete)break;routes++;vector<V>rows;for(int off=0;off<n;off+=w)rows.push_back(V(min(w,n-off),-1));int cursor=0;for(int col:order)for(auto&row:rows)if(col<(int)row.size())row[col]=C[cursor++];V D;for(auto&row:rows)for(int x:row)D.push_back(x);if(cursor!=n)return 3;
 vector<V>Y(2,V(n));for(int a=0;a<2;a++)for(int i=0;i<n;i++)Y[a][i]=I[a][D[i]];
 for(int L:lengths){if(L<1||L>n||L>8)return 2;for(int pa=0;pa<2;pa++)for(int ca=0;ca<2;ca++)for(int s:{1,-1})for(int f=0;f<2;f++){
  if((trials++&1023)==0&&cpu()-start>limit){complete=false;break;}V primer(L,-1);bool ok=true;V b(n,0),coef(n,0);int computed=-1;
  for(auto[i,letter]:clues){int x=I[pa][letter];if(f==1){if(i<L){int z=mod(Y[ca][i]-s*x);if(primer[i]>=0&&primer[i]!=z){ok=false;break;}primer[i]=z;}else if(mod(s*(Y[ca][i]-Y[ca][i-L]))!=x){ok=false;break;}}
   else {while(computed<i){int j=++computed;if(j<L){b[j]=mod(s*Y[ca][j]);coef[j]=-s;}else{b[j]=mod(s*(Y[ca][j]-b[j-L]));coef[j]=-s*coef[j-L];}}
    int z=mod(coef[i]*(x-b[i])),r=i%L;if(primer[r]>=0&&primer[r]!=z){ok=false;break;}primer[r]=z;}}
  if(!ok)continue;V x(n),plain(n);for(int i=0;i<n;i++){int k=i<L?max(primer[i],0):(f==0?x[i-L]:Y[ca][i-L]);x[i]=mod(s*(Y[ca][i]-k));plain[i]=A[pa][x[i]];}
  sols.push_back({pa*4+ca*2+(s==-1),f,w,L,order,primer,plain});
 }if(!complete)break;
 }
 }while(complete&&next_permutation(order.begin(),order.end()));if(!complete)break;}
 string status="EMPTY";if(!sols.empty()){status="SINGLETON";V p=sols[0].plaintext;for(auto&q:sols){if(find(q.primer.begin(),q.primer.end(),-1)!=q.primer.end()||q.plaintext!=p){status="MULTIPLE";break;}}}if(!complete)status="INCONCLUSIVE";
 rusage u;getrusage(RUSAGE_SELF,&u);cout.precision(12);cout<<"{\"complete\":"<<(complete?"true":"false")<<",\"cpu_seconds\":"<<cpu()-start<<",\"peak_rss_kib\":"<<u.ru_maxrss<<",\"routes\":"<<routes<<",\"route_length_convention_feedback_trials\":"<<trials<<",\"classification\":\""<<status<<"\",\"cylinders\":[";
 for(size_t j=0;j<sols.size();j++){if(j)cout<<',';auto&v=sols[j];cout<<"{\"convention\":"<<v.convention<<",\"feedback\":"<<v.feedback<<",\"width\":"<<v.width<<",\"length\":"<<v.length<<",\"order\":";arr(v.order);cout<<",\"primer\":";arr(v.primer);cout<<",\"plaintext\":";arr(v.plaintext);cout<<'}';}cout<<"]}\n";cout.flush();}}
