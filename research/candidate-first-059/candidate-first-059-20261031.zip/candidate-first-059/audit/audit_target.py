"""Independent 059 target receipt audit; does not rerun either solver."""
import json,hashlib,pathlib,time,datetime
ROOT=pathlib.Path('/workspace/shared/candidate-first-059');start=time.process_time()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(ROOT/'target/target-freeze.json')=='242c9739acd86f03f17daf2ed1d0834a4e8b2ff6c2cdf42435df8fb4a009274e'
manifest=json.loads((ROOT/'freeze/manifest.json').read_text())
for n,h in manifest['files'].items():assert sha(ROOT/n)==h,n
add=json.loads((ROOT/'target/target-freeze.json').read_text())
for n,h in add['files'].items():assert sha(ROOT/n)==h,n
case=json.loads((ROOT/'target/input.jsonl').read_text())
# Independently fetched pinned source on2026-10-31, compared with the target transport.
expected='OBKRUOXOGHULBSOLIFBBWFLRVQQPRNGKSSOTWTQSJQSSEKZZWATJKLUDIAWINFBNYPVTTMZFPKWGDKZXTJCDIGKUHUAUEKCAR'
assert case['ciphertext']==expected and len(expected)==97
assert hashlib.sha256(expected.encode()).hexdigest()=='eea813570c7f1fd3b34674e47b5c3da8948026f5cefee612a0b38ffaa515ceab'
clues=[[21+i,x] for i,x in enumerate('EASTNORTHEAST')]+[[63+i,x] for i,x in enumerate('BERLINCLOCK')];assert case['clues']==clues
rows={};receipts={};pair=[]
for engine in ('production','reference'):
 o=json.loads((ROOT/f'target/{engine}.jsonl').read_text());r=json.loads((ROOT/f'target/{engine}.receipt.json').read_text());assert o['complete'] and o['families']==[] and o['projection']['status']=='UNSAT_COMPLETE';assert o['projection']['raw_primer_cylinders']==0 and o['projection']['distinct_plaintext_count']==0;assert o['projection']['plaintext_count_lower_bound']==o['projection']['plaintext_count_upper_bound']==0
 assert r['count']==1 and r['status']=='completed' and r['input_sha256']==sha(ROOT/'target/input.jsonl') and r['output_sha256']==sha(ROOT/f'target/{engine}.jsonl');assert r['hard_worker_address_space_bytes']==r['hard_child_address_space_bytes']==1024**3;assert r['inclusive_cpu_seconds']<65
 assert r['worker_peak_rss_kib']*1024<1024**3 and r['max_child_rss_kib']*1024<1024**3
 pair.append((r['worker_peak_rss_kib']+r['max_child_rss_kib'])*1024);rows[engine]=o;receipts[engine]=r
assert rows['reference']['classification']=='EMPTY';assert rows['reference']['route_length_convention_feedback_trials']==52346880 and rows['reference']['routes']==408960
assert rows['production']['projection']==rows['reference']['projection'];assert json.loads((ROOT/'audit/postbenchmark/FINAL-AUDIT.json').read_text())['status']=='PASS_FOR_PARENT_TARGET_REVIEW'
assert json.loads((ROOT/'results/resource-ledger.json').read_text())['charged_cpu_seconds']<28800
out={'status':'PASS_EXACT_BOUNDED_EXCLUSION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Eight AZ/KRYPTOS alphabet-role/sign conventions; additive +1 plaintext or intermediate-ciphertext feedback; primer lengths 1–8; ragged column widths 6–9/all emission orders; feedback before transposition. Subtractive feedback excluded.','canonical_source_url':'https://github.com/reggiechan74/kryptos-k4/blob/e589286feedd6c3b52959418acd848f0a54a62b5/data/k4.json','canonical_source_freshly_read':True,'canonical_ciphertext_sha256':hashlib.sha256(expected.encode()).hexdigest(),'frozen_files_verified':len(manifest['files']),'target_freeze_sha256':sha(ROOT/'target/target-freeze.json'),'reference_routes':408960,'reference_descriptive_trials':52346880,'compatible_primer_cylinders':0,'distinct_plaintexts':0,'production_inclusive_cpu_seconds':receipts['production']['inclusive_cpu_seconds'],'reference_inclusive_cpu_seconds':receipts['reference']['inclusive_cpu_seconds'],'max_conservative_pair_rss_bytes':max(pair),'target_rerun':False,'audit_cpu_seconds':time.process_time()-start}
(ROOT/'audit/FINAL-TARGET-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
(ROOT/'audit/FINAL-TARGET-AUDIT.md').write_text('''# Study 059 independent target audit\n\n**PASS: exact bounded exclusion.** Both frozen engines returned a complete empty compatible-primer-cylinder set. No target rerun was performed for this audit.\n\nThe reference exhausted 408,960 routes and 52,346,880 route/length/convention/feedback descriptions. Canonical 97-letter ciphertext and 24 fixed crib values match an independent fresh read of the pinned repository source. All 29 original frozen file hashes and the additive target freeze agree. Target receipts and resource limits pass.\n\nThis excludes only the explicitly frozen eight alphabet-role/sign conventions with feedback coefficient +1, primer lengths 1–8, widths 6–9 and feedback before ragged columnar transposition. Subtractive feedback, other lags/widths, reverse feedback/transposition order and arbitrary layers are not excluded. The result is not a recovered plaintext.\n\nThe ciphertext-feedback arm's free primers were retained symbolically; no English choice filled them. Cylinder counts were not summed as exact distinct operator counts. In this target, the complete cylinder set is empty, so no overlap correction can create a surviving solution.\n''')
print(json.dumps(out,indent=2))
