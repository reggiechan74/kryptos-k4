# Study 059 independent mathematical and preflight review

This review does not authorize a target run.

## Model

With physical plaintext alphabet A, intermediate ciphertext alphabet B and sign s∈{+1,−1}, use x_i=A⁻¹(P_i), y_i=B⁻¹(D_i), y_i=s*x_i+k_i modulo26. For i<L, k_i=z_i is an independent primer symbol. Later k_i=x_(i−L) for plaintext feedback or k_i=y_(i−L) for intermediate-ciphertext feedback. Only then transpose D through unpadded ragged columns, with arbitrary emission order. All alphabet roles, feedback conventions and lag bounds must be fixed before evaluation.

## Exact symbolic primer inference

For plaintext feedback, decryption satisfies x_i=s*(y_i−x_(i−L)). At initial indices, x_i=−s*z_i+s*y_i. Inductively x_i=a_i*z_(i mod L)+b_i, where a_i=±1 and b_i depends only on the known intermediate ciphertext. A clue uniquely gives z_(i mod L)=a_i*(x_i−b_i). The thirteen consecutive crib positions cover every residue for L≤8, so all primer symbols are fixed in this domain.

For ciphertext feedback, later plaintext is x_i=s*(y_i−y_(i−L)) and contains no primer variable. Since every real clue position is at least21 and L≤8, no primer symbol is constrained. Exactly26^L plaintexts occur in each compatible primitive cylinder, with the initial L plaintext symbols independently variable. It is wrong to report unique recovery for this arm.

Both statements also hold for a generic smaller alphabet, with arbitrary clue masks handled explicitly. The independent reference allows early clues to fix ciphertext-feedback primer symbols, and allows missing plaintext-feedback residues to remain free in tiny tests.

## Sound projection and overlaps

A cylinder is the exact compatible primitive description: convention, feedback mode, width, lag, column order and a primer vector with −1 for each independent free coordinate. The union is empty iff no cylinder exists. Any free primer coordinate changes an initial plaintext letter bijectively, proving MULTIPLE. If all cylinders are fixed, compare their fully decrypted plaintexts to classify SINGLETON or MULTIPLE. This classification is exact despite overlap between cylinders.

Cylinder volumes must not be added as distinct union cardinalities. The maximum volume of a single cylinder and number of distinct representative plaintexts are valid lower bounds; the sum of individual volumes is only an upper bound. Distinct complete encryption-operator counts are withheld. Repeated primer text is not generally a lag alias: changing L changes feedback dependencies.

Periodic-model positionwise-map canonicalization from057/058 is not valid for feedback. Full operators couple positions. Any overlap between feedback conventions, alphabets or descriptions must remain allowed rather than counted as independent hypotheses.

## Coverage distinction

Every057/058 operator maps each output letter from exactly one plaintext coordinate. In059, at intermediate position L, y_L depends bijectively on both x_L and x_0 (plus possibly a primer in ciphertext feedback). Changing either input with all other plaintext fixed changes that output, so no059 complete operator equals any positionwise-substitution-plus-permutation operator in057/058, regardless of routes or alphabets.

The tested ragged routes are also not direct fixed-alignment causal autokey operators: to match a direct output0, the first emitted physical column would have to be0. Its next emitted plaintext-index coordinate is then w≥6, and that output depends on P_w, while a direct output1 has no dependence on future P_w. This is a structural distinction from the prior direct-autokey test, not a claim that every historical or third-party feedback variant is novel.

## Independent implementations and checks

The C++ reference constructs literal row matrices and works directly in physical-letter alphabets. It was written without viewing the production solver source. A lossless prefilter checks y_i=s*x_i+x_(i−L) when both crib letters are known; only surviving routes need full primer-chain inference. The unoptimized reference and its earlier receipts are preserved as pre-freeze development records.

Independent Python brute force enumerates every primer, route, feedback mode and alphabet/sign convention in a four-letter domain. The final suite covers all256 length-four ciphertexts with three clue masks, totaling768 cases. It fully expands reference and production cylinders and checks all207,120 returned primitive witnesses and plaintext projections. Exact sets agree. Full-domain synthetic development completed52,346,880 trials in approximately1.97 CPU seconds after the prefilter. This is a development timing, not a cryptanalytic speedup claim.

Recommended blind design:600 cases with512 cell-covering positives,32 primer degeneracy diagnostics and56 independent random ciphertext controls, as specified in the final protocol. Unique recovery is descriptive, not a threshold; exact feasibility/ambiguity correctness, plant inclusion and random-fit calibration control target eligibility.

## Subtractive feedback is outside this pilot

The feedback coefficient is fixed to +1. In an autokey generator, negating an arbitrary primer changes only the initial segment; it does not negate later feedback from plaintext or intermediate ciphertext. Therefore variant Beaufort with subtractive feedback is not absorbed by primer negation, unlike the arbitrary periodic keys in057. Exhaustive comparison of all676 local physical-letter input pairs for each role and feedback mode finds no subtractive (+current, −feedback) rule equal to any of the eight retained additive-feedback rules at a fixed lag. The separate boundary certificate records this finite check; no claim is made of a worldwide equivalence census over arbitrary transformations. Subtractive feedback remains explicitly untested, as the parent chose before freeze.
