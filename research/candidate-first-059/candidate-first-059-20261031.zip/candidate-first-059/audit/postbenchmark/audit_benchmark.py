"""Independent post-seal study059 audit. Uses independent physical-letter model only."""
import pathlib,json,hashlib,subprocess,tempfile,time,resource,collections,datetime
from independent import encrypt,decrypt,signature
ROOT=pathlib.Path('/workspace/shared/candidate-first-059')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def read(p):
 rows=[json.loads(x) for x in pathlib.Path(p).read_text().splitlines()];d={x['id']:x for x in rows};assert len(d)==len(rows);return d

def proj(case,families):
 C=[ord(x)-65 for x in case['ciphertext']];Q=[(i,ord(x)-65) for i,x in case['clues']];reps=set();free=False;upper=0;lower=0;reencrypt=0
 for f in families:
  assert f['feedback'] in (0,1) and f['convention'] in range(8) and f['width'] in (6,7,8,9) and f['length'] in range(1,9)
  assert len(f['primer'])==f['length'] and sorted(f['order'])==list(range(f['width']))
  assert all(0<=x<26 for x in f['primer']) if f['feedback']==0 else f['primer']==[-1]*f['length']
  k=[max(x,0) for x in f['primer']];p=decrypt(C,k,f['width'],f['order'],f['convention'],f['feedback']);assert encrypt(p,k,f['width'],f['order'],f['convention'],f['feedback'])==C;assert all(p[i]==v for i,v in Q);reps.add(tuple(p));reencrypt+=1
  nfree=f['primer'].count(-1);v=26**nfree;upper+=v;lower=max(lower,v)
  if nfree:
   free=True;k[f['primer'].index(-1)]=1;q=decrypt(C,k,f['width'],f['order'],f['convention'],f['feedback']);assert p!=q;assert all(q[i]==v for i,v in Q);assert encrypt(q,k,f['width'],f['order'],f['convention'],f['feedback'])==C;reencrypt+=1
 status='UNSAT_COMPLETE' if not families else 'SAT_COMPLETE_MULTIPLE_PLAINTEXTS' if free or len(reps)>1 else 'SAT_COMPLETE_UNIQUE_PLAINTEXT'
 return status,max(lower,len(reps)),upper if free else len(reps),None if free else len(reps),reencrypt

def main():
 start=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
 manifest=json.loads((ROOT/'freeze/manifest.json').read_text())
 for n,h in manifest['files'].items():assert sha(ROOT/n)==h,n
 seal=json.loads((ROOT/'results/seal.json').read_text());hashes=seal.get('hashes',seal.get('files'))
 assert hashes is not None
 for n,h in hashes.items():assert sha(ROOT/n)==h,n
 # Read answers only after output seal verification.
 I,A,P,R=[read(ROOT/p) for p in ('fixtures/inputs.jsonl','fixtures/answers.jsonl','results/production.jsonl','results/reference.jsonl')]
 assert len(I)==600 and I.keys()==A.keys()==P.keys()==R.keys()
 gen=json.loads((ROOT/'fixtures/generation-receipt.json').read_text());assert gen['freeze_sha256']==sha(ROOT/'freeze/manifest.json');assert gen['input_sha256']==sha(ROOT/'fixtures/inputs.jsonl');assert gen['answers_sha256']==sha(ROOT/'fixtures/answers.jsonl')
 seed=json.loads((ROOT/'fixtures/seed.json').read_text())['seed_hex']
 with tempfile.TemporaryDirectory(prefix='audit-059-replay-') as tmp:
  subprocess.check_output(['python3',str(ROOT/'source/generate_fixtures.py'),'--out',tmp,'--freeze',str(ROOT/'freeze/manifest.json'),'--seed',seed])
  assert sha(pathlib.Path(tmp)/'inputs.jsonl')==gen['input_sha256'];assert sha(pathlib.Path(tmp)/'answers.jsonl')==gen['answers_sha256']
 counts=collections.Counter();strata={};maxprod=maxref=0;trials=0
 for id,case in I.items():
  p,r,ans=P[id],R[id],A[id];assert p['complete'] and r['complete'];assert r['route_length_convention_feedback_trials']==52346880;trials+=r['route_length_convention_feedback_trials'];counts['complete']+=1
  ps={signature(f) for f in p['families']};rs={signature(f) for f in r['families']};assert ps==rs;counts['set_agreement']+=1
  st,lo,hi,exact,reenc=proj(case,p['families']);counts['independent_reencryptions']+=reenc
  assert st==p['projection']['status']==r['projection']['status'];assert st=={'EMPTY':'UNSAT_COMPLETE','SINGLETON':'SAT_COMPLETE_UNIQUE_PLAINTEXT','MULTIPLE':'SAT_COMPLETE_MULTIPLE_PLAINTEXTS'}[r['classification']]
  for o in (p,r):
   q=o['projection'];assert q['plaintext_count_lower_bound']==lo and q['plaintext_count_upper_bound']==hi and q['distinct_plaintext_count']==exact and q['distinct_operator_count'] is None
  counts['projection_agreement']+=1;truth=ans['truth']
  if truth:
   counts['plants']+=1;assert any(f['convention']==truth['convention'] and f['feedback']==truth['feedback'] and f['width']==truth['width'] and f['length']==truth['length'] and f['order']==truth['order'] and all(k<0 or k==truth['primer'][i] for i,k in enumerate(f['primer'])) for f in p['families']);counts['plants_included']+=1
   C=[ord(x)-65 for x in case['ciphertext']];plain=[ord(x)-65 for x in truth['plaintext']];assert encrypt(plain,truth['primer'],truth['width'],truth['order'],truth['convention'],truth['feedback'])==C
   if truth['feedback']==1:counts['cipher_feedback_plants']+=1;assert st=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS';counts['cipher_feedback_multiple']+=1
   key=ans['category']+'-feedback-'+str(truth['feedback']);v=strata.setdefault(key,collections.Counter());v['total']+=1;v['unique']+=st=='SAT_COMPLETE_UNIQUE_PLAINTEXT';v['multiple']+=st=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
  else:counts['controls']+=1;counts['control_fits']+=bool(p['families'])
  maxprod=max(maxprod,p['cpu_seconds']);maxref=max(maxref,r['cpu_seconds']);assert p['cpu_seconds']<65 and r['cpu_seconds']<65
 assert counts['plants']==counts['plants_included']==544 and counts['cipher_feedback_plants']==272 and counts['controls']==56 and counts['control_fits']<=1
 pair_rss=[]
 for engine in ('production','reference'):
  rec=json.loads((ROOT/f'results/{engine}.receipt.json').read_text());assert rec['status']=='completed' and rec['count']==600 and rec['input_sha256']==sha(ROOT/'fixtures/inputs.jsonl') and rec['output_sha256']==sha(ROOT/f'results/{engine}.jsonl')
  assert rec['hard_worker_address_space_bytes']==rec['hard_child_address_space_bytes']==1024**3
  assert rec['worker_peak_rss_kib']*1024<1024**3 and rec['max_child_rss_kib']*1024<1024**3
  pair_rss.append((rec['worker_peak_rss_kib']+rec['max_child_rss_kib'])*1024)
 ledger=json.loads((ROOT/'results/resource-ledger.json').read_text());assert ledger['charged_cpu_seconds']<28800
 result=json.loads((ROOT/'results/benchmark.json').read_text());assert result['all_numeric_gates_pass'] and all(result['gates'].values())
 r1=resource.getrusage(resource.RUSAGE_CHILDREN);o={'status':'PASS_FOR_PARENT_TARGET_REVIEW','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeze_sha256':sha(ROOT/'freeze/manifest.json'),'frozen_files_verified':len(manifest['files']),'counts':dict(counts),'descriptive_strata':{k:dict(v) for k,v in strata.items()},'reference_trials':trials,'max_production_cpu_seconds':maxprod,'max_reference_cpu_seconds':maxref,'fixture_replay_exact':True,'operator_count_claimed':False,'target_authorized':False,'audit_inclusive_cpu_seconds':time.process_time()-start+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'limits':'Only additive-feedback eight-convention bounded family; subtractive feedback remains untested. Cylinder unions may overlap; projection classification is exact, cardinality bounds only.'}
 o['max_conservative_worker_child_rss_bytes']=max(pair_rss)
 o['novelty_scope_source_verified']='research/AUTOKEY-CONSTRAINT-FINDINGS.md explicitly excludes transposition and unspecified composite models.'
 out=ROOT/'audit/postbenchmark';out.mkdir(parents=True,exist_ok=True);(out/'FINAL-AUDIT.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
if __name__=='__main__':main()
