// Study 059 production: prefix column-placement pruning with exact autokey cylinders.
#include <algorithm>
#include <ctime>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
#include <functional>
#include <sys/resource.h>
using namespace std; using VI=vector<int>;
double cpu(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
void arr(const VI&x){cout<<'[';for(size_t j=0;j<x.size();j++){if(j)cout<<',';cout<<x[j];}cout<<']';}
struct Family{int cv,fb,w,L;VI order,key;};
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);int n,m,nw,nl,nq;double cap;
while(cin>>n>>m>>cap>>nw){VI widths(nw);for(int&x:widths)cin>>x;cin>>nl;VI lengths(nl);for(int&x:lengths)cin>>x;cin>>nq;VI C(n),Q(n,-1);for(int&x:C)cin>>x;vector<pair<int,int>> clues;for(int j=0;j<nq;j++){int i,v;cin>>i>>v;clues.push_back({i,v});Q[i]=v;}
if(!cin||n<1||n>100||(m!=4&&m!=26))return 2;
VI A[2],I[2];A[0].resize(m);iota(A[0].begin(),A[0].end(),0);string kr=m==26?"KRYPTOSABCDEFGHIJLMNQUVWXZ":"ACDB";for(char ch:kr)A[1].push_back(ch-'A');for(int a=0;a<2;a++){I[a].resize(m);for(int j=0;j<m;j++)I[a][A[a][j]]=j;}
auto mod=[&](int x){x%=m;return x<0?x+m:x;};double start=cpu();bool complete=true;long long nodes=0,full=0,checks=0;vector<Family> out;
for(int w:widths)for(int L:lengths)for(int cv=0;cv<8;cv++)for(int fb=0;fb<2;fb++){
 if(!complete)break;if(w<1||w>n||w>10||L<1||L>n)return 3;int pa=cv/4,ca=(cv/2)%2,s=cv%2?-1:1;VI d(n,-1),known(n,-1),lens(w),order;for(auto [i,v]:clues)known[i]=I[pa][v];for(int c=0;c<w;c++)lens[c]=(n-1-c)/w+1;
 function<void(int,int)> dfs=[&](int used,int offset){if(!complete)return;if((nodes++&1023)==0&&cpu()-start>cap){complete=false;return;}
  if((int)order.size()==w){full++;VI key(L,-1);bool valid=true;
   if(fb==0){VI coeff(n),base(n);for(int i=0;i<n;i++){if(i<L){coeff[i]=-s;base[i]=mod(s*d[i]);}else{coeff[i]=-s*coeff[i-L];base[i]=mod(s*d[i]-s*base[i-L]);}if(known[i]>=0){int z=mod(coeff[i]*(known[i]-base[i]));int r=i%L;if(key[r]>=0&&key[r]!=z){valid=false;break;}key[r]=z;}}}
   else{for(auto [i,v]:clues){if(i<L)key[i]=mod(d[i]-s*I[pa][v]);else if(mod(d[i]-d[i-L])!=mod(s*I[pa][v])){valid=false;break;}}}
   if(valid)out.push_back({cv,fb,w,L,order,key});return;
  }
  for(int c=0;c<w;c++)if(!(used&(1<<c))){int j=offset;for(int i=c;i<n;i+=w)d[i]=I[ca][C[j++]];bool ok=true;
   if(fb==0){for(auto [i,v]:clues)if(i>=L&&known[i-L]>=0&&d[i]>=0){checks++;if(d[i]!=mod(s*known[i]+known[i-L])){ok=false;break;}}}
   else{for(auto [i,v]:clues)if(i>=L&&d[i]>=0&&d[i-L]>=0){checks++;if(mod(d[i]-d[i-L])!=mod(s*known[i])){ok=false;break;}}}
   if(ok){order.push_back(c);dfs(used|(1<<c),j);order.pop_back();}for(int i=c;i<n;i+=w)d[i]=-1;
  }
 };dfs(0,0);
}
rusage u;getrusage(RUSAGE_SELF,&u);cout.precision(12);cout<<"{\"complete\":"<<(complete?"true":"false")<<",\"cpu_seconds\":"<<cpu()-start<<",\"peak_rss_kib\":"<<u.ru_maxrss<<",\"prefix_nodes\":"<<nodes<<",\"complete_routes_visited\":"<<full<<",\"partial_constraint_checks\":"<<checks<<",\"families\":[";
for(size_t j=0;j<out.size();j++){if(j)cout<<',';auto&f=out[j];cout<<"{\"convention\":"<<f.cv<<",\"feedback\":"<<f.fb<<",\"width\":"<<f.w<<",\"length\":"<<f.L<<",\"order\":";arr(f.order);cout<<",\"primer\":";arr(f.key);cout<<'}';}cout<<"]}\n";cout.flush();
}}
