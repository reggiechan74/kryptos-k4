"""Independent physical-letter autokey model and exhaustive tiny oracle."""
import itertools,json
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KR='KRYPTOSABCDEFGHIJLMNQUVWXZ'
def alphabets(m=26):return [list(range(m)),[ord(x)-65 for x in (KR if m==26 else 'ACDB')]]
def convention(c):return c//4,(c//2)%2,1 if c%2==0 else -1
def encrypt(plain,primer,w,order,c,f,m=26):
 A=alphabets(m);pa,ca,s=convention(c);inv={x:j for j,x in enumerate(A[pa])};x=[inv[v] for v in plain];L=len(primer);y=[]
 for i,v in enumerate(x):
  key=primer[i] if i<L else (x[i-L] if f==0 else y[i-L]);y.append((s*v+key)%m)
 D=[A[ca][v] for v in y];rows=[D[i:i+w] for i in range(0,len(D),w)];return [row[col] for col in order for row in rows if col<len(row)]
def decrypt(cipher,primer,w,order,c,f,m=26):
 A=alphabets(m);pa,ca,s=convention(c);inv={x:j for j,x in enumerate(A[ca])};rows=[[None]*min(w,len(cipher)-i) for i in range(0,len(cipher),w)];it=iter(cipher)
 for col in order:
  for row in rows:
   if col<len(row):row[col]=next(it)
 y=[inv[v] for row in rows for v in row];x=[];L=len(primer)
 for i,v in enumerate(y):
  key=primer[i] if i<L else (x[i-L] if f==0 else y[i-L]);x.append((s*(v-key))%m)
 return [A[pa][v] for v in x]
def signature(c):return (c['convention'],c['feedback'],c['width'],c['length'],tuple(c['order']),tuple(c['primer']))
def expand(cylinder,cipher,m=4):
 free=[i for i,v in enumerate(cylinder['primer']) if v<0]
 for values in itertools.product(range(m),repeat=len(free)):
  key=list(cylinder['primer'])
  for i,v in zip(free,values):key[i]=v
  p=decrypt(cipher,key,cylinder['width'],cylinder['order'],cylinder['convention'],cylinder['feedback'],m)
  yield (cylinder['convention'],cylinder['feedback'],cylinder['width'],cylinder['length'],tuple(cylinder['order']),tuple(key),tuple(p))
def brute(cipher,clues,widths,lengths,m=4):
 out=set()
 for w in widths:
  for order in itertools.permutations(range(w)):
   for L in lengths:
    for c in range(8):
     for f in (0,1):
      for primer in itertools.product(range(m),repeat=L):
       p=decrypt(cipher,primer,w,order,c,f,m)
       if all(p[i]==v for i,v in clues):out.add((c,f,w,L,tuple(order),tuple(primer),tuple(p)))
 return out
def line(cipher,clues,widths=(6,7,8,9),lengths=tuple(range(1,9)),m=26,limit=60):return ' '.join(map(str,[len(cipher),m,limit,len(widths),*widths,len(lengths),*lengths,len(clues),*cipher,*itertools.chain.from_iterable(clues)]))+'\n'
