"""Frozen 059 feasibility and ambiguity gates; answers opened after output seals."""
import argparse,json,hashlib
from pathlib import Path
from model import signature,project,encrypt,decrypt

def read(p):return {x['id']:x for x in map(json.loads,Path(p).read_text().splitlines())}
def main():
 ap=argparse.ArgumentParser()
 for x in ('inputs','answers','production','reference','output'):ap.add_argument(x)
 a=ap.parse_args();I,A,P,R=map(read,[a.inputs,a.answers,a.production,a.reference]);assert I.keys()==A.keys()==P.keys()==R.keys()
 counts={'complete':0,'cylinder_agreement':0,'projection_agreement':0,'plants':0,'plants_included':0,'cipher_feedback_plants':0,'cipher_feedback_multiple':0,'controls':0,'control_fits':0};strata={};cases=[]
 for ident,case in I.items():
  p,r,ans=P[ident],R[ident],A[ident];counts['complete']+=p['complete'] and r['complete'];counts['cylinder_agreement']+=set(map(signature,p['families']))==set(map(signature,r['families']))
  pp,rr=project(p,case['ciphertext']),project(r,case['ciphertext']);cls={'EMPTY':'UNSAT_COMPLETE','SINGLETON':'SAT_COMPLETE_UNIQUE_PLAINTEXT','MULTIPLE':'SAT_COMPLETE_MULTIPLE_PLAINTEXTS'}[r['classification']]
  counts['projection_agreement']+=pp['status']==rr['status']==cls and pp['cylinder_set_sha256']==rr['cylinder_set_sha256']
  truth=ans['truth'];included=None
  if truth:
   counts['plants']+=1;included=any(f['convention']==truth['convention'] and f['feedback']==truth['feedback'] and f['width']==truth['width'] and f['length']==truth['length'] and f['order']==truth['order'] and all(x<0 or x==truth['primer'][j] for j,x in enumerate(f['primer'])) for f in p['families']);counts['plants_included']+=included
   assert encrypt(truth['plaintext'],truth['primer'],truth['width'],truth['order'],truth['convention'],truth['feedback'])==case['ciphertext']
   if truth['feedback']==1:counts['cipher_feedback_plants']+=1;counts['cipher_feedback_multiple']+=pp['status']=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
   label=ans['category']+'-feedback-'+str(truth['feedback']);st=strata.setdefault(label,{'total':0,'unique':0,'multiple':0});st['total']+=1;st['unique']+=pp['status']=='SAT_COMPLETE_UNIQUE_PLAINTEXT';st['multiple']+=pp['status']=='SAT_COMPLETE_MULTIPLE_PLAINTEXTS'
  else:counts['controls']+=1;counts['control_fits']+=bool(p['families'])
  for f in p['families']:
   assert (-1 in f['primer']) == (f['feedback']==1)
   if f['feedback']==1:assert f['primer']==[-1]*f['length']
  cases.append({'id':ident,'category':ans['category'],'plant_included':included,'projection':pp})
 gates={'all_complete':counts['complete']==600,'all_cylinders_equal':counts['cylinder_agreement']==600,'all_projections_equal':counts['projection_agreement']==600,'all_plants':counts['plants']==544 and counts['plants_included']==544,'all_cipher_feedback_ambiguous':counts['cipher_feedback_plants']==272 and counts['cipher_feedback_multiple']==272,'random_fits':counts['controls']==56 and counts['control_fits']<=1}
 result={'gates':gates,'all_numeric_gates_pass':all(gates.values()),'counts':counts,'descriptive_strata':strata,'cases':cases,'input_hashes':{x:hashlib.sha256(Path(getattr(a,x)).read_bytes()).hexdigest() for x in ('inputs','answers','production','reference')},'interpretation':'Feasibility/ambiguity study. Unique recovery descriptive, not gated. Cylinder volumes overlap; exact operator counts withheld. Requires separate independent audit and parent target-stage review.'}
 Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
