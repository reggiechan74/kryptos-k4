import pathlib,sys,json,subprocess,random,time,resource
from independent import *
ROOT=pathlib.Path(__file__).parent;PROD=pathlib.Path('/workspace/shared/candidate-first-059/source/solver');rng=random.Random(5900011);t=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN);count=0;witnesses=0
for cv in range(8):
 for fb in (0,1):
  for w in (6,9):
   for L in (1,8):
    P=[rng.randrange(26) for _ in range(97)];primer=[rng.randrange(26) for _ in range(L)];order=list(range(w));rng.shuffle(order);C=encrypt(P,primer,w,order,cv,fb);assert decrypt(C,primer,w,order,cv,fb)==P;Q=[(i,P[i]) for i in list(range(21,34))+list(range(63,74))]
    args=line(C,Q,[w],[L]);r=json.loads(subprocess.check_output([str(ROOT/'reference')],input=args.encode()));p=json.loads(subprocess.check_output([str(PROD)],input=args.encode()));assert r['complete'] and p['complete'];assert {signature(c) for c in r['cylinders']}=={signature(c) for c in p['families']}
    assert any(c['convention']==cv and c['feedback']==fb and c['width']==w and c['length']==L and c['order']==order and all(v<0 or v==primer[i] for i,v in enumerate(c['primer'])) for c in r['cylinders'])
    for c in r['cylinders']:
     key=[max(v,0) for v in c['primer']];plain=decrypt(C,key,c['width'],c['order'],c['convention'],c['feedback']);assert encrypt(plain,key,c['width'],c['order'],c['convention'],c['feedback'])==C;assert all(plain[i]==v for i,v in Q);witnesses+=1
    count+=1
r1=resource.getrusage(resource.RUSAGE_CHILDREN);o={'status':'PASS','full_alphabet_cases':count,'representatives_reencrypted':witnesses,'inclusive_cpu_seconds':time.process_time()-t+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime};(ROOT/'full-alphabet-results.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o))
