"""059 exact physical-letter autokey model. No K4 input embedded."""
from pathlib import Path
import hashlib,json,resource,subprocess,time
ROOT=Path(__file__).resolve().parents[1]
ALPH=['ABCDEFGHIJKLMNOPQRSTUVWXYZ','KRYPTOSABCDEFGHIJLMNQUVWXZ'];MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def roles(cv):return cv//4,(cv//2)%2,1 if cv%2==0 else -1
def route(n,w,order):return [i for c in order for i in range(c,n,w)]
def encrypt(plain,primer,w,order,cv,fb):
 a,b,s=roles(cv);x=[ALPH[a].index(ch) for ch in plain];y=[];L=len(primer)
 for i,v in enumerate(x):
  k=primer[i] if i<L else x[i-L] if fb==0 else y[i-L]
  y.append((s*v+k)%26)
 return ''.join(ALPH[b][y[i]] for i in route(len(x),w,order))
def decrypt(cipher,primer,w,order,cv,fb):
 a,b,s=roles(cv);y=[None]*len(cipher)
 for j,i in enumerate(route(len(cipher),w,order)):y[i]=ALPH[b].index(cipher[j])
 x=[];L=len(primer)
 for i,v in enumerate(y):
  k=primer[i] if i<L else x[i-L] if fb==0 else y[i-L]
  x.append((s*(v-k))%26)
 return ''.join(ALPH[a][v] for v in x)
def signature(f):return f['convention'],f['feedback'],f['width'],f['length'],tuple(f['order']),tuple(f['primer'])
def project(obj,cipher):
 fs=obj['families'];raw=set(map(signature,fs));pts=set();free=any(-1 in f['primer'] for f in fs);lo=0;upper=0;witness=[]
 for f in fs:
  size=26**f['primer'].count(-1);lo=max(lo,size);upper+=size;k=[max(v,0) for v in f['primer']]
  p=decrypt(cipher,k,f['width'],f['order'],f['convention'],f['feedback']);pts.add(p)
  if len(witness)<2 and p not in witness:witness.append(p)
  if -1 in f['primer']:
   k[f['primer'].index(-1)]=1;q=decrypt(cipher,k,f['width'],f['order'],f['convention'],f['feedback']);assert q!=p;witness=[p,q]
 status='UNSAT_COMPLETE' if not fs else 'SAT_COMPLETE_MULTIPLE_PLAINTEXTS' if free or len(pts)>1 else 'SAT_COMPLETE_UNIQUE_PLAINTEXT'
 return {'status':status,'raw_primer_cylinders':len(raw),'cylinder_set_sha256':hashlib.sha256(json.dumps(sorted(raw),separators=(',',':')).encode()).hexdigest(),'contains_free_primer':free,'max_free_primer_symbols':max((f['primer'].count(-1) for f in fs),default=0),'distinct_plaintext_count':None if free else len(pts),'distinct_operator_count':None,'plaintext_count_lower_bound':max(lo,len(pts)),'plaintext_count_upper_bound':upper if free else len(pts),'count_note':'Cylinders may overlap across conventions, feedback rules, routes or lengths. The volume sum is only an upper bound; no exact distinct operator count is claimed.','plaintext_witnesses':witness[:2]}
def request(case,widths=(6,7,8,9),lengths=tuple(range(1,9)),limit=60):
 C=[ord(x)-65 for x in case['ciphertext']];Q=case['clues'];v=[len(C),26,limit,len(widths),*widths,len(lengths),*lengths,len(Q),*C]
 v += [y for i,x in Q for y in (i,ord(x)-65)]
 return ' '.join(map(str,v))+'\n'
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(65,65))
def solve(case,engine):
 before=resource.getrusage(resource.RUSAGE_CHILDREN);t=time.process_time();wall=time.monotonic()
 p=subprocess.run([str(ROOT/'source'/('solver' if engine=='production' else 'reference'))],input=request(case),text=True,capture_output=True,timeout=90,preexec_fn=limits)
 if p.returncode:raise RuntimeError((engine,p.returncode,p.stderr))
 o=json.loads(p.stdout)
 if 'cylinders' in o:o['families']=o.pop('cylinders')
 if not o['complete']:raise RuntimeError('INCONCLUSIVE: '+engine)
 for f in o['families']:
  for alt in (False,True):
   key=[max(v,0) for v in f['primer']]
   if alt:
    if -1 not in f['primer']:continue
    key[f['primer'].index(-1)]=1
   plain=decrypt(case['ciphertext'],key,f['width'],f['order'],f['convention'],f['feedback'])
   assert all(plain[i]==v for i,v in case['clues']);assert encrypt(plain,key,f['width'],f['order'],f['convention'],f['feedback'])==case['ciphertext']
 after=resource.getrusage(resource.RUSAGE_CHILDREN);o['inclusive_cpu_seconds']=time.process_time()-t+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime;o['wall_seconds']=time.monotonic()-wall;o['projection']=project(o,case['ciphertext']);return o
