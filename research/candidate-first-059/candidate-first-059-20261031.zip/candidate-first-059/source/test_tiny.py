import itertools,json,pathlib,subprocess,time,resource,hashlib
from independent import *
ROOT=pathlib.Path(__file__).parent;t=time.process_time();r0=resource.getrusage(resource.RUSAGE_CHILDREN);cnt=0;witnesses=0;dig=hashlib.sha256()
# Exhaust every four-symbol length-three ciphertext, with three different masks.
for cipher in itertools.product(range(4),repeat=3):
 for mask in ([0],[1,2],[0,1,2]):
  clues=[(i,(cipher[i]+i+1)%4) for i in mask];want=brute(cipher,clues,[2,3],[1,2]);o=json.loads(subprocess.check_output([str(ROOT/'reference')],input=line(cipher,clues,[2,3],[1,2],4).encode()));assert o['complete'];got=set()
  for c in o['cylinders']:
   for w in expand(c,cipher):
    assert encrypt(w[-1],w[-2],w[2],w[4],w[0],w[1],4)==list(cipher)
    got.add(w)
  assert want==got,(cipher,clues,len(want),len(got))
  plains={x[-1] for x in got};status='EMPTY' if not plains else 'SINGLETON' if len(plains)==1 else 'MULTIPLE';assert status==o['classification']
  dig.update(repr((cipher,clues,sorted(got),status)).encode());cnt+=1;witnesses+=len(got)
r1=resource.getrusage(resource.RUSAGE_CHILDREN);out={'status':'PASS','cases':cnt,'expanded_witnesses':witnesses,'digest':dig.hexdigest(),'inclusive_cpu_seconds':time.process_time()-t+r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime};(ROOT/'tiny-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
