"""Independent study059 generator; invoke only after code/protocol freeze."""
import argparse,json,random,secrets,hashlib,pathlib,time,resource
from independent import encrypt
MASK=list(range(21,34))+list(range(63,74));LITERAL='EASTNORTHEASTBERLINCLOCK'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--freeze',required=True);ap.add_argument('--seed',help='Replay only, prior recorded hex seed');args=ap.parse_args();start=time.process_time()
 out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True);freeze=pathlib.Path(args.freeze);assert freeze.is_file();assert not (out/'inputs.jsonl').exists(),'Do not overwrite fixtures'
 seed=args.seed or secrets.token_hex(32);rng=random.Random(int(seed,16));items=[]
 def add(category,cv=None,fb=None,w=None,L=None,primer=None,literal=False):
  if category=='random-control':
   C=[rng.randrange(26) for _ in range(97)];clues=[[i,ord(x)-65] for i,x in zip(MASK,LITERAL)] if literal else [[i,rng.randrange(26)] for i in MASK];truth=None
  else:
   P=[rng.randrange(26) for _ in range(97)]
   if literal:
    for i,x in zip(MASK,LITERAL):P[i]=ord(x)-65
   key=list(primer) if primer is not None else [rng.randrange(26) for _ in range(L)];order=list(range(w));rng.shuffle(order);C=encrypt(P,key,w,order,cv,fb);clues=[[i,P[i]] for i in MASK]
   truth={'convention':cv,'feedback':fb,'width':w,'length':L,'order':order,'primer':key,'plaintext':''.join(chr(x+65) for x in P)}
  items.append(({'ciphertext':''.join(chr(x+65) for x in C),'clues':[[i,chr(x+65)] for i,x in clues]},{'category':category,'literal_clues':literal,'truth':truth}))
 for cv in range(8):
  for fb in range(2):
   for w in (6,7,8,9):
    for L in range(1,9):
     lit=bool((cv+fb+w+L)%2);add('literal-positive' if lit else 'uniform-positive',cv,fb,w,L,literal=lit)
 for cv in range(8):
  for fb in range(2):
   add('zero-primer-diagnostic',cv,fb,6,1,[0],True)
   add('repeated-primer-diagnostic',cv,fb,9,8,[2,7]*4,True)
 for lit in (False,True):
  for _ in range(28):add('random-control',literal=lit)
 assert len(items)==600;rng.shuffle(items);public=[];answers=[]
 for i,(p,a) in enumerate(items):
  ident=f'059-B{i:04d}';public.append({'id':ident,**p});answers.append({'id':ident,**a})
 def write(name,values):
  p=out/name;p.write_text(''.join(json.dumps(v,separators=(',',':'))+'\n' for v in values));return hashlib.sha256(p.read_bytes()).hexdigest()
 receipt={'version':'059-independent-generator-v1','created_unix':time.time(),'freeze_sha256':hashlib.sha256(freeze.read_bytes()).hexdigest(),'seed_sha256':hashlib.sha256(seed.encode()).hexdigest(),'count':600,'input_sha256':write('inputs.jsonl',public),'answers_sha256':write('answers.jsonl',answers),'counts':{'uniform-positive':256,'literal-positive':256,'zero-primer-diagnostic':16,'repeated-primer-diagnostic':16,'random-control':56},'generation_cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'selection':'Unfiltered IID keys/text except declared literal clues and diagnostic primers; no solver invoked.'}
 (out/'seed.json').write_text(json.dumps({'seed_hex':seed,'namespace':'059-independent-blind-v1'},indent=2)+'\n');(out/'generation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
