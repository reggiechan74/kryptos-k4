# Study 059 reproduction

Compile `solver.cpp` and `reference.cpp` with `g++ -O3 -std=c++17`, naming binaries `solver` and `reference` beside these source files. Production uses safe partial column-placement constraints; reference enumerates every route and tests direct physical-letter equations. No target input is embedded in either.

The independent tiny tests exhaust a four-symbol alphabet and explicitly expand every free primer. Their original production-binary path refers to this study's execution workspace; adjust only that path for reproduction on a different machine, documenting the transport change. The mathematical source and hashes remain preserved.

Only after the final freeze, generate fixtures with `python3 source/generate_fixtures.py --out fixtures --freeze freeze/manifest.json`. Seed replay is for reproduction of the existing set, never selecting a more favorable set. Keep solver inputs separate from answers and seeds.

Run sequentially:

- `python3 source/run_batch.py production fixtures/inputs.jsonl results/production.jsonl`
- `python3 source/run_batch.py reference fixtures/inputs.jsonl results/reference.jsonl`

The runner refuses output overwrite, applies resource limits and records inclusive CPU charges even on failure. Seal both result hashes before using answers. Then evaluate frozen gates with `python3 source/analyze.py fixtures/inputs.jsonl fixtures/answers.jsonl results/production.jsonl results/reference.jsonl results/benchmark.json`.

A cylinder contains independent free primer symbols, not a guessed key. Raw family counts are not deduplicated encryption-operator counts. Read the protocol's exact feedback-coordinate assumption and the distinct untested subtractive-feedback boundary before interpreting results.
