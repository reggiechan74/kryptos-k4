"""Indexed E02 implementation. No target, CLI, randomness or file access."""
from bisect import bisect_left
class Cursor:
    def __init__(self, reference, alphabet):
        if not alphabet or len(set(alphabet)) != len(alphabet): raise ValueError('alphabet')
        if not reference or set(reference) != set(alphabet): raise ValueError('reference')
        self.reference, self.alphabet = reference, alphabet
        self.positions = {c: [] for c in alphabet}
        for i, c in enumerate(reference): self.positions[c].append(i)
        self.tables = []
        n = len(reference)
        for q in range(n):
            hits = []
            for c, positions in self.positions.items():
                j = bisect_left(positions, q)
                pos = positions[j] if j < len(positions) else positions[0] + n
                hits.append((pos-q, c, (pos+1) % n))
            hits.sort()
            order = ''.join(x[1] for x in hits)
            self.tables.append((order, {c: (alphabet[i], nxt) for i, (_, c, nxt) in enumerate(hits)}, {alphabet[i]: (c, nxt) for i, (_, c, nxt) in enumerate(hits)}))
    def transform(self, text, q=0, decrypt=False):
        if not isinstance(q, int) or not 0 <= q < len(self.reference): raise ValueError('cursor')
        if any(c not in self.alphabet for c in text): raise ValueError('text')
        out = []
        for c in text:
            v, q = self.tables[q][2 if decrypt else 1][c]
            out.append(v)
        return ''.join(out), q
