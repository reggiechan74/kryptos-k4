"""One granted finite synthetic-only E02 pilot; no target access."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(57,58))
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
import hashlib,json,pathlib,sys,time,traceback
D=pathlib.Path(__file__).resolve().parent
if len(sys.argv)!=4 or sys.argv[1]!='--execute-approved':raise SystemExit('grant required')
expected=sys.argv[2];out=pathlib.Path(sys.argv[3]);sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((D/'FREEZE.json').read_bytes())==expected
freeze=json.loads((D/'FREEZE.json').read_text())
for name,h in freeze['files'].items():assert sha((D/name).read_bytes())==h
contract=json.loads((D/'EXECUTION.json').read_text());assert str(out)==contract['output_directory']
assert not out.exists();out.mkdir()
start=time.monotonic();report={'status':'INCOMPLETE','scope':'DISCLOSED_SYNTHETIC_ONLY_NO_K4','freeze_sha256':expected}
try:
 sys.path.insert(0,str(D))
 from production import Cursor
 from reference import transform as oracle
 src=json.loads((D/'source-reference.json').read_text());policy=json.loads((D/'source-policy.json').read_text())
 assert src['source_policy_sha256']==sha((D/'source-policy.json').read_bytes())
 texts=[]
 for field in policy['fields']:
  sec=field.split('.')[0];t=src['source_plaintexts'][field]
  assert len(t)==policy['source_plaintext_lengths'][sec] and sha(t.encode())==policy['source_plaintext_sha256'][sec]
  texts.append(t)
 AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';raw=''.join(texts);R=raw+''.join(c for c in AZ if c not in raw)
 assert R==src['reference'] and len(R)==770 and sha(R.encode())==src['sha256_ascii']
 corpus=json.loads((D/'corpus.json').read_text());assert corpus['status']=='DISCLOSED_NOT_BLIND' and corpus['full_start']==0
 toycount=0
 for t in corpus['toy']:
  A=t['alphabet'];ref=t['reference'];p=Cursor(ref,A)
  assert ref==t['raw']+''.join(c for c in A if c not in t['raw'])
  for q in t['starts']:
   for msg in t['messages']:
    enc=p.transform(msg,q);oe=oracle(msg,ref,A,q);assert enc==oe
    dec=p.transform(enc[0],q,True);od=oracle(enc[0],ref,A,q,True)
    assert dec==od==(msg,enc[1]);toycount+=1
 assert toycount==corpus['toy_message_cases']==22230
 p=Cursor(R,AZ);cells=0
 for q in range(len(R)):
  for c in AZ:
   enc=p.transform(c,q);assert enc==oracle(c,R,AZ,q)
   assert p.transform(enc[0],q,True)==oracle(enc[0],R,AZ,q,True)==(c,enc[1]);cells+=1
 assert cells==20020
 nulls=[('reversed-reference',Cursor(R[::-1],AZ),0),('AZ-only-reference',Cursor(AZ,AZ),0),('wrong-start-one',p,1)]
 counts={k:0 for k,_,_ in nulls};records=[]
 for case in corpus['full']:
  msg=case['plaintext'];assert len(msg)==97
  enc=p.transform(msg);assert enc==oracle(msg,R,AZ)
  assert p.transform(enc[0],decrypt=True)==oracle(enc[0],R,AZ,decrypt=True)==(msg,enc[1])
  wrong=[]
  for key,model,q in nulls:
   recovered=model.transform(enc[0],q,True);same=recovered[0]==msg
   counts[key]+=int(not same);wrong.append({'control':key,'same_plaintext':same,'final_state':recovered[1]})
  records.append({'id':case['id'],'plaintext':msg,'ciphertext':enc[0],'final_state':enc[1],'nulls':wrong})
 assert len(records)==corpus['full_cases']==48
 # Sensitivity requirement is at least one detected wrong decode per control, not every null failing.
 assert all(v>0 for v in counts.values())
 assert all(sha((D/name).read_bytes())==h for name,h in freeze['files'].items())
 (out/'CASES.json').write_text(json.dumps(records,indent=2)+'\n')
 report.update(status='PASS',toy_message_cases=toycount,real_reference_one_step_cells=cells,full_size_disclosed_plants=len(records),null_plaintext_mismatches=counts,case_artifact_sha256=sha((out/'CASES.json').read_bytes()),claim='Implementation consistency and control sensitivity only; no blind recovery, novelty or target evidence.')
except BaseException as e:
 report.update(status='FAIL',error=repr(e),traceback=traceback.format_exc())
finally:
 u=resource.getrusage(resource.RUSAGE_SELF)
 report.update(wall_seconds=time.monotonic()-start,worker_cpu_before_report=u.ru_utime+u.ru_stime)
 (out/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
if report['status']!='PASS':raise SystemExit(1)
