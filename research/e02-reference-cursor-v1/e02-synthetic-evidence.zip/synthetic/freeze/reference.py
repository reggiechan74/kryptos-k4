"""Independent literal scan oracle for E02; no precomputed table or production import."""
def transform(text, reference, alphabet, q=0, decrypt=False):
    if not isinstance(alphabet, str) or not alphabet or len(set(alphabet)) != len(alphabet):
        raise ValueError('alphabet must be a nonempty string of unique symbols')
    if not isinstance(reference, str) or not reference or set(reference) != set(alphabet):
        raise ValueError('reference must contain exactly the alphabet symbols')
    if not isinstance(text, str) or any(c not in alphabet for c in text):
        raise ValueError('text contains invalid symbols')
    if type(q) is not int or not 0 <= q < len(reference):
        raise ValueError('cursor out of range')
    if type(decrypt) is not bool:
        raise ValueError('decrypt must be Boolean')
    out = []
    for symbol in text:
        encountered = []
        positions = []
        for distance in range(len(reference)):
            position = (q + distance) % len(reference)
            letter = reference[position]
            if letter not in encountered:
                encountered.append(letter)
                positions.append(position)
            if len(encountered) == len(alphabet):
                break
        if decrypt:
            rank = alphabet.index(symbol)
            out.append(encountered[rank])
        else:
            rank = encountered.index(symbol)
            out.append(alphabet[rank])
        q = (positions[rank] + 1) % len(reference)
    return ''.join(out), q
