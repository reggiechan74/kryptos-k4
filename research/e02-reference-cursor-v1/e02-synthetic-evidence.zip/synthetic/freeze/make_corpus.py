"""Plaintext-only, deterministic corpus construction; never imports cipher code."""
import itertools,json,pathlib
D=pathlib.Path(__file__).resolve().parent
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
R=json.loads((D/'source-reference.json').read_text())['reference']
toy=[]
for A in ['AB','ABC']:
 for n in range(1,5):
  for t in itertools.product(A,repeat=n):
   raw=''.join(t); ref=raw+''.join(c for c in A if c not in raw)
   toy.append({'alphabet':A,'raw':raw,'reference':ref,'starts':list(range(len(ref))),'messages':[''.join(x) for k in range(4) for x in itertools.product(A,repeat=k)]})
full=[{'id':'constant-'+c,'plaintext':c*97} for c in AZ]
full += [{'id':'cycle-AZ','plaintext':(AZ*4)[:97]},{'id':'cycle-ZA','plaintext':(AZ[::-1]*4)[:97]}]
full += [{'id':'source-window-'+str(i),'plaintext':(R+R)[i:i+97]} for i in [0,1,25,26,63,100,368,432,600,673,700,743,744,767,768,769]]
full += [{'id':'alternating-'+x,'plaintext':(x*49)[:97]} for x in ['AZ','JZ','AB','QX']]
obj={'status':'DISCLOSED_NOT_BLIND','randomness':'none','full_start':0,'toy':toy,'full':full,'null_controls':['reversed-reference','AZ-only-reference','wrong-start-one'],'toy_message_cases':sum(len(t['starts'])*len(t['messages']) for t in toy),'full_cases':len(full)}
(D/'corpus.json').write_text(json.dumps(obj,indent=2)+'\n')
print(obj['toy_message_cases'],obj['full_cases'])
