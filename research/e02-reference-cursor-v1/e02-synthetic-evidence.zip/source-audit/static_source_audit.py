"""Frozen-source transition-table audit only; no cipher/message or target input."""
import pathlib,json,hashlib,itertools,zipfile
D=pathlib.Path(__file__).resolve().parent
RDIR=pathlib.Path('/workspace/shared/k4-next-checkpoint-publisher')
H=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((D/'SOURCE-POLICY.json').read_text());AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';KA='KRYPTOSABCDEFGHIJLMNQUVWXZ'
b=(RDIR/p['artifact']).read_bytes();assert H(b)==p['artifact_sha256']
x=json.loads(b)
texts=[]
for dotted in p['fields']:
 sec,key=dotted.split('.'); v=''.join(c for c in x[sec][key] if c in AZ)
 assert len(v)==p['source_plaintext_lengths'][sec] and H(v.encode())==p['source_plaintext_sha256'][sec]
 texts.append(v)
del x,b
raw=''.join(texts); absent=''.join(c for c in AZ if c not in raw); R=raw+absent;N=len(R)
(D/'REFERENCE.json').write_text(json.dumps({'source_policy_sha256':H((D/'SOURCE-POLICY.json').read_bytes()),'source_plaintexts':dict(zip(p['fields'],texts)),'concatenated_length':len(raw),'completion':absent,'reference':R,'length':N,'sha256_ascii':H(R.encode())},indent=2)+'\n')
# Static graph labels: one row for every source position, no input word is processed.
rows=[]
for q in range(N):
 first={}
 for d in range(N):
  c=R[(q+d)%N]
  if c not in first:first[c]=d
  if len(first)==26:break
 assert len(first)==26
 A=''.join(first);rows.append({'q':q,'alphabet':A,'next_state_by_AZ':[(q+first[c]+1)%N for c in AZ],'distance_by_AZ':[first[c] for c in AZ]})
init=''.join(AZ[rows[0]['alphabet'].index(c)] for c in AZ)
local=[]
for arm,r,s,k in itertools.product(('A','B'),(AZ,KA),(AZ,KA),range(26)):
 old=''.join(s[(r.index(c)+(k if arm=='B' else 0))%26] for c in AZ)
 diffs=[c for c in AZ if old[AZ.index(c)]!=init[AZ.index(c)]]
 local.append({'arm':arm,'R':r,'S':s,'k':k,'map':old,'different_inputs':''.join(diffs)})
for size in range(1,27):
 sep=next((s for s in itertools.combinations(AZ,size) if all(any(c in r['different_inputs'] for c in s) for r in local)),None)
 if sep:break
# A single q0 transition distinguishes common update rules using matched initial alphabet.
A=rows[0]['alphabet'];updates=[]
for c in AZ:
 q1=rows[0]['next_state_by_AZ'][AZ.index(c)];actual=rows[q1]['alphabet'];i=A.index(c)
 mtf=c+A.replace(c,'');mtb=A.replace(c,'')+c;rev=A[:i+1][::-1]+A[i+1:];swap=list(A);swap[0],swap[i]=swap[i],swap[0]
 updates.append({'selected':c,'q1':q1,'actual':actual,'MTF':mtf,'MTB':mtb,'prefix_reverse':rev,'head_swap':''.join(swap)})
# Two reachable occurrences of the same previous letter with different next-state alphabet.
last_witness=None
for i in range(min(N,95)):
 for j in range(i+1,min(N,95)):
  if R[i]==R[j] and rows[(i+1)%N]['alphabet']!=rows[(j+1)%N]['alphabet']:
   last_witness={'previous_symbol':R[i],'source_occurrences':[i,j],'states':[(i+1)%N,(j+1)%N],'alphabets':[rows[(i+1)%N]['alphabet'],rows[(j+1)%N]['alphabet']],'reachability':'Selecting each current source symbol advances one position; source prefixes to these occurrences are witnesses, not a target trace.'};break
 if last_witness:break
z=RDIR/'research/candidate-first-060/study-060-evolving-alphabets.zip'
with zipfile.ZipFile(z) as ar:
 pins={n:H(ar.read(n)) for n in ['study-060/freeze/production.py','study-060/freeze/reference.py']}
cert={'status':'STATIC_SOURCE_OPERATOR_AUDIT_NO_MESSAGE_BATCH','source_policy_sha256':H((D/'SOURCE-POLICY.json').read_bytes()),'reference_length':N,'missing_letters':absent,'distinct_alphabets':len({r['alphabet'] for r in rows}),'initial_alphabet':A,'initial_emission_map_by_AZ':init,'local208_matches':sum(not r['different_inputs'] for r in local),'common_first_emission_witness':list(sep),'local208':local,'matched_initial_alphabet_update_witnesses':updates,'last_symbol_only_bank_counterexample':last_witness,'local060_archive_sha256':H(z.read_bytes()),'local060_source_pins':pins,'state_table':rows}
(D/'STATIC-CERTIFICATE.json').write_text(json.dumps(cert,indent=2)+'\n')
print(json.dumps({k:v for k,v in cert.items() if k not in ['local208','state_table','matched_initial_alphabet_update_witnesses']},indent=2))
print('B transition:',next(r for r in updates if r['selected']=='B'))
