import {CIPHER_ROWS} from './transcript.mjs';
import {screenGeometry} from './surface-profile.mjs';
// Logical text identity stays separate from the unmeasured physical layout adapter.
export function linkedLetter(selection,state){
 if(!selection?.physical)return null;
 const {row,column,char,side}=selection.physical;
 if(side!=='cipher'||!Number.isInteger(row)||!Number.isInteger(column)||CIPHER_ROWS[row]?.[column]!==char||selection.char!==char)throw Error('Invalid carved-letter linkage');
 if(state.view!=='screen')return null;
 const centered=column+Math.floor((33-CIPHER_ROWS[row].length)/2);
 return {p:screenGeometry(state.geometry).at((centered+.5)/66,1-(row+.5)/28),row,column,char,section:selection.section};
}
export function createLearningMode({mount,host,panel,controls,workbench,opticalButton,acceptedButton,guidance,onSelection,onNavigate}){
 let controller=null,active=false,selection=null;
 function navigate(next){onNavigate();active=next;panel.hidden=!active;controls.hidden=active;workbench.classList.toggle('learning',active);opticalButton.setAttribute('aria-pressed',String(!active));acceptedButton.setAttribute('aria-pressed',String(active));
  if(controller?.getState().playing)controller.seek(controller.getState().position);
  guidance.textContent=active?'Accepted K1–K3 decryptions: follow the arithmetic or tile permutation. The sculpture marker is a location aid, not an optical explanation.':'Experimental optics: adjust assumptions and inspect projected light. No K4 solution is claimed.';
  if(active&&!controller)controller=mount(host,{onSelection:value=>{selection=value;if(active)onSelection(value);}});
  else onSelection(active?selection:null);
 }
 opticalButton.onclick=()=>navigate(false);acceptedButton.onclick=()=>navigate(true);
 return {isActive:()=>active,getSelection:()=>active?selection:null,controller:()=>controller,pause(){if(controller?.getState().playing)controller.seek(controller.getState().position);},reset(){controller?.setSection('K1');},leave:()=>navigate(false)};
}
