# Kryptos accepted decryption module

Self-contained browser ES module. No framework, build step, network request, runtime dependency, image, optics implementation or global CSS. A shadow root isolates its styling. Colors and type follow the existing Kryptos Light Laboratory: dark green, mint, copper, Georgia headings, system text.

## Integration

Copy this directory into a separate subdirectory of the main Site. Serve over HTTP. Only `module.mjs`, `core.mjs` and `transcript.mjs` are needed at runtime; `index.html` is a standalone local preview. Do not replace the main Site's transcript or geometry.

```html
<div id="accepted-decryption"></div>
<script type="module">
import {mountAcceptedDecryption} from './accepted-decryption/module.mjs';
const decryption = mountAcceptedDecryption(
  document.querySelector('#accepted-decryption'),
  {onSelection(selection) {
    // selection.physical === null for the logical 2006 K2 insertion.
    // Highlight only an existing verified carved location.
    if (selection.physical) highlightCipherCell(selection.physical);
    else clearCipherHighlight();
  }}
);
</script>
```

`highlightCipherCell` and `clearCipherHighlight` are host integration placeholders, not exported functions. Add this module as an **Accepted decryption** mode alongside the existing experimental optics mode. The module does not change the camera, lighting, physical mesh, sharing, or publication.

### Selection contract

The callback and bubbling, composed `kryptos-selection` CustomEvent receive the same object:

```js
{
  section: 'K2',
  streamIndex: 361,           // zero-based current variant ciphertext position
  cipherIndex: 361,           // alias of streamIndex
  carvedIndex: null,          // original section's letter-only index; stable across variants
  globalCarvedLetterIndex: null, // original global A–Z index; excludes question marks
  physical: null,             // insertion has NO sculpture aperture
  geometryCell: null,         // do not fabricate geometry for this letter
  inserted: true,
  char: 'S', corrected: true,
  stage: null                 // K3 stage 0–5; null for K1/K2
}
```

For a carved tile, `physical` is `{id:'cipher:row:column', char, row, column, side:'cipher'}`. Both coordinates are **zero-based positions in the authoritative unpadded carved row**, retaining question marks. Status text displays one-based coordinates. `carvedIndex` is the original letter-only position **within that section**; `globalCarvedLetterIndex` adds section offsets 0 / 63 / 432. Neither changes when the inserted S is toggled. The insertion is stream index 361; original final eight indices 361–368 become stream indices 362–369 in corrected mode.

`geometryCell` is `{side:0,row,column}` for the existing candidate full-screen 33-column centered envelope: `column = physical.column + floor((33 − originalRowLength) / 2)`. This is an adapter for that model's existing layout convention, not a measured sculpture coordinate. Verify the host still uses this convention before consuming it. Prefer `physical` if host geometry changes.

Callbacks fire on mount, section changes, seek, letter selection, K2 toggle, reset and playback. K3 uses the original ciphertext tile index even after rearrangement. Clicking a plaintext letter selects its corresponding cipher tile. Callbacks must not throw; avoid feeding a selection back into the module without an equality guard.

### Controller API

- `setSection('K1' | 'K2' | 'K3')`: pauses and resets to the first step.
- `seek(step)`: pauses and chooses K1/K2 ciphertext position, or K3 stage 0–5.
- `selectCipherIndex(index)`: pauses and selects that current-variant cipher position; K3 stage stays fixed.
- `getState()`: `{section, corrected, position, selected, playing}`. `corrected` remembers the K2 preference while another section is shown.
- `destroy()`: stops playback and empties the shadow root. Remove this host and create a fresh element before remounting.

The UI provides section selection, previous, step, play/pause, reset, keyboard-operable scrubber, exact plaintext, actual tableau lookup and clickable persistent K3 tiles. Reduced-motion preference removes transitions. Wide tables and grids scroll within their panels; the outer layout stacks below 760px.

## Method and text guarantees

`transcript.mjs` was copied read-only from the builder's candidate transcript, then all 28 ciphertext rows were compared with a separate live retrieval of Dunin's canonical transcript. Original lengths and all four question marks stay intact. The included test fixture records that second retrieval. No private photographs or secrets are present.

K1/K2: keyed alphabet `KRYPTOSABCDEFGHIJLMNQUVWXZ`; decrypt by modular index subtraction. K1 uses PALIMPSEST (10), K2 ABSCISSA (8); reset at each section. Spaces and carved question marks are not cipher letters. The UI's table is a normalized algebraically equivalent 26 × 26 lookup, clearly distinguished from the exact carved tableau layout.

K2 as engraved has 369 letters and ends IDBYROWS. The separately labeled 2006 intended-text variant inserts S before the final eight letters and ends WESTXLAYERTWO. It never shifts or modifies carved geometry. Toggle retains selection of the same original carved letter when possible.

K3: 336 letters, ending DOHW before the sculpture question mark. Write 14 × 24 row-major → rotate clockwise → flatten row-major → reflow 42 × 8 → rotate clockwise → flatten row-major. The final flattened sequence is wrapped at 24 columns for reading. All stages reuse the exact same 336 tile objects and DOM buttons. Independent permutation `cipherIndex = (((plainIndex + 1) * 192) % 337) - 1` verifies every output position. The module calls this an **equivalent decryption visualization**, not every solver's exact historical procedure. Spelling IQLUSION, UNDERGRUUND, DESPARATLY and the terminal Q remain untouched.

## Verification and preview

```sh
npm install
npm test
python3 -m http.server 8175 --bind 127.0.0.1
# Open http://127.0.0.1:8175
```

Only the UI test requires the pinned happy-dom development dependency. The runtime has none. To run numeric tests alone: `node --test tests/core.test.mjs`.

Verified in this isolated workspace: complete plaintext fixtures; 28-row external transcript equality; full 336-position independent K3 equivalence; inverse roundtrips; identity bijection and no letter loss/duplication; physical mappings in both K2 modes; actual DOM controls, scrub, play/pause/reset, section switching, correction selection, callbacks and teardown. UI test uses a DOM harness and controlled interval ticks, not a rendered browser.

**Remaining visual QA:** supported browser automation reported both `iab` and `chrome` unavailable in this execution environment. No rendered screenshot or mobile/desktop browser layout verification is claimed. The local loopback preview server was successfully started for handoff; main builder should visually inspect 390px and desktop widths, scrollable K3 grids, focus states and reduced motion before publication. No production tree was edited and nothing was deployed.

## Sources and historical reading

- [Canonical carved transcript](https://www.elonka.com/kryptos/transcript.html): primary text source, retrieved 2026-10-22.
- [NSA declassified cryptanalysis](https://www.nsa.gov/portals/75/documents/news-features/declassified-documents/cia-kryptos-sculpture/doc_7.pdf): alphabet recovery and transposition work; scanned/OCR prose can normalize or misread spelling, so fixtures follow actual computed text and canonical cipher.
- [Gillogly's 1999 account](https://www.elonka.com/kryptos/mirrors/cypherpunks/1999/0930.html): explicitly says he worked from Doug Gwyn's transcription, reports keys and original spelling errors.
- [David Stein's account](https://www.elonka.com/kryptos/mirrors/daw/steinarticle.html): identifies the carved modified tableau and describes frequency and alignment work.
- [2006 K2 correction announcement](https://www.elonka.com/kryptos/CorrectedK2Announcement.html): missing ciphertext S and confirmed XLAYERTWO ending.

These accounts support substantial classical cryptanalysis using monument-provided text and tableau clues. Keyword recovery need not wait for guessing PALIMPSEST or ABSCISSA. No established sunlight/star/shadow mechanism for K1–K3 is asserted. This module supplies no optical proof for K4.
