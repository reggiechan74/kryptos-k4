import {CIPHER_ROWS} from './transcript.mjs';
export {CIPHER_ROWS};
export const ALPHABET='KRYPTOSABCDEFGHIJLMNQUVWXZ';
export const SOURCES=[
 ['Canonical carved transcript','https://www.elonka.com/kryptos/transcript.html'],
 ['NSA declassified cryptanalysis','https://www.nsa.gov/portals/75/documents/news-features/declassified-documents/cia-kryptos-sculpture/doc_7.pdf'],
 ['Gillogly’s 1999 account','https://www.elonka.com/kryptos/mirrors/cypherpunks/1999/0930.html'],
 ['Stein’s account','https://www.elonka.com/kryptos/mirrors/daw/steinarticle.html'],
 ['2006 K2 correction','https://www.elonka.com/kryptos/CorrectedK2Announcement.html']
];
// All coordinates zero-based. Never pad or reflow the carved transcript.
export const CARVED=Object.freeze(CIPHER_ROWS.flatMap((line,row)=>[...line].map((char,column)=>Object.freeze({id:`cipher:${row}:${column}`,char,row,column,side:'cipher'}))));
const letters=CARVED.filter(x=>/[A-Z]/.test(x.char));
const bounds={K1:[0,63],K2:[63,432],K3:[432,768]};
export const QUESTIONS=Object.freeze(CARVED.filter(x=>x.char==='?'));
export function stream(section='K1',corrected=false){
 if(!bounds[section])throw new RangeError('Unknown section');
 const [start,end]=bounds[section];
 const a=letters.slice(start,end).map((physical,cipherIndex)=>({id:physical.id,char:physical.char,cipherIndex,carvedIndex:cipherIndex,globalCarvedLetterIndex:start+cipherIndex,physical,inserted:false}));
 if(section==='K2'&&corrected)a.splice(a.length-8,0,{id:'K2:inserted-S-2006',char:'S',carvedIndex:null,globalCarvedLetterIndex:null,physical:null,inserted:true});
 return a.map((x,cipherIndex)=>({...x,cipherIndex}));
}
export function decrypt(cipher,key){
 return [...cipher].map((c,i)=>{
 const ci=ALPHABET.indexOf(c),ki=ALPHABET.indexOf(key[i%key.length]);
 if(ci<0||ki<0)throw new RangeError('Cipher and key must contain uppercase alphabet letters only');
 return ALPHABET[(ci-ki+26)%26];
 }).join('');
}
export function lookup(section,index,corrected=false){
 const a=stream(section,corrected),tile=a[index];
 if(!tile)throw new RangeError('Cipher index outside section');
 if(section==='K3')return {...tile,section,corrected:false};
 const key=section==='K1'?'PALIMPSEST':'ABSCISSA',keyChar=key[index%key.length];
 const cipherValue=ALPHABET.indexOf(tile.char),keyValue=ALPHABET.indexOf(keyChar),plainValue=(cipherValue-keyValue+26)%26;
 return {...tile,section,corrected,key,keyChar,keyIndex:index%key.length,cipherValue,keyValue,plainValue,plainChar:ALPHABET[plainValue]};
}
export function rotateClockwise(items,rows,cols){
 if(items.length!==rows*cols)throw new RangeError('Grid dimensions must match tile count');
 return Array.from({length:items.length},(_,i)=>items[(rows-1-i%rows)*cols+Math.floor(i/rows)]);
}
export const K3_STAGES=[
 {label:'Write ciphertext · 14 rows × 24 columns',rows:14,cols:24},
 {label:'Rotate 90° clockwise · 24 × 14',rows:24,cols:14},
 {label:'Flatten rotated grid · read rows left to right',rows:1,cols:336},
 {label:'Reflow same sequence · 42 rows × 8 columns',rows:42,cols:8},
 {label:'Rotate 90° clockwise · 8 × 42',rows:8,cols:42},
 {label:'Flatten → plaintext · wrapped for reading at 24 columns',rows:14,cols:24}
];
export function k3Stages(){
 const a=stream('K3'),b=rotateClockwise(a,14,24),c=rotateClockwise(b,42,8);
 return [a,b,b,b,c,c];
}
export const k3Permutation=Object.freeze(Array.from({length:336},(_,i)=>(((i+1)*192)%337)-1));
export function transposeDecrypt(cipher){if(cipher.length!==336)throw new RangeError('K3 requires 336 letters');return k3Permutation.map(i=>cipher[i]).join('');}
export function transposeEncrypt(plain){if(plain.length!==336)throw new RangeError('K3 requires 336 letters');const a=Array(336);k3Permutation.forEach((c,p)=>a[c]=plain[p]);return a.join('');}
export function plaintext(section,corrected=false){const c=stream(section,corrected).map(t=>t.char).join('');return section==='K3'?transposeDecrypt(c):decrypt(c,section==='K1'?'PALIMPSEST':'ABSCISSA');}
export function physicalToCipher(section,row,column,corrected=false){return stream(section,corrected).find(x=>x.physical?.row===row&&x.physical?.column===column)?.cipherIndex??null;}
// Existing full-screen geometry centers each carved row in a 33-column envelope.
export function geometryCell(physical,columns=33){if(!physical)return null;return {side:0,row:physical.row,column:physical.column+Math.floor((columns-CIPHER_ROWS[physical.row].length)/2)};}
