"""Image-only registration diagnostics. Fundamental matrix epipolar error is
not a metric reconstruction and is not a two-dimensional reprojection error.
"""
from pathlib import Path
import json,numpy as np
D=Path(__file__).parent

def norm(p):
 c=p.mean(axis=0);s=np.sqrt(2)/np.mean(np.linalg.norm(p-c,axis=1));T=np.array([[s,0,-s*c[0]],[0,s,-s*c[1]],[0,0,1]])
 return np.c_[(p-c)*s,np.ones(len(p))],T

def fitF(p,q):
 x,A=norm(p);y,B=norm(q)
 M=np.einsum('ni,nj->nij',y,x).reshape(-1,9);u,s,v=np.linalg.svd(M);F=v[-1].reshape(3,3);u,s,v=np.linalg.svd(F);s[-1]=0;F=u@np.diag(s)@v;F=B.T@F@A;F/=np.linalg.norm(F)
 return F

def errF(F,p,q):
 x=np.c_[p,np.ones(len(p))];y=np.c_[q,np.ones(len(q))];l2=x@F.T;l1=y@F;a=np.sum(y*l2,axis=1)
 return a/np.sqrt(np.sum(l1[:,:2]**2,axis=1)+np.sum(l2[:,:2]**2,axis=1))

def fitH(p,q):
 x,A=norm(p);y,B=norm(q);M=[]
 for a,b in zip(x,y):
  M.extend([np.r_[-a,np.zeros(3),b[0]*a],np.r_[np.zeros(3),-a,b[1]*a]])
 u,s,v=np.linalg.svd(M);H=np.linalg.inv(B)@v[-1].reshape(3,3)@A;H/=H[2,2];return H

if __name__=='__main__':
 a=json.load(open(D/'left-glyph-landmarks.json'));b=json.load(open(D/'middle-glyph-landmarks.json'));dd={p['id']:p for p in b['points']};pts=[p for p in a['points'] if p['id'] in dd and p.get('usable_for_fit',True) and p.get('usable_for_cross_view_check',True) and p.get('xy') is not None and not p.get('ambiguous',False) and not dd[p['id']].get('ambiguous',False)]
 x=np.array([p['xy'] for p in pts]);y=np.array([dd[p['id']]['xy'] for p in pts]);hold_ids={'cipher_r14_c04_A','cipher_r14_c08_H','cipher_r19_c05_R','cipher_r19_c09_M','cipher_r20_c04_O','cipher_r20_c08_I','cipher_r23_c03_M','cipher_r23_c07_A'};train=np.array([p['id'] not in hold_ids for p in pts])
 F=fitF(x[train],y[train]);ef=errF(F,x,y);H=fitH(x[train],y[train]);pr=np.c_[x,np.ones(len(x))]@H.T;pr=pr[:,:2]/pr[:,2,None];eh=np.linalg.norm(pr-y,axis=1)
 out={'status':'image_registration_diagnostics_only','source_files':['left-glyph-landmarks.json','middle-glyph-landmarks.json'],'feature_ids':[p['id'] for p in pts],'fit_mask':train.tolist(),'fundamental_matrix_image2_T_F_image1_zero':F.tolist(),'sampson_error_px':ef.tolist(),'fundamental_train_sampson_rms_px':float(np.sqrt(np.mean(ef[train]**2))),'fundamental_holdout_sampson_rms_px':float(np.sqrt(np.mean(ef[~train]**2))),'homography_image1_to_image2':H.tolist(),'homography_point_error_px':eh.tolist(),'homography_train_point_rms_px':float(np.sqrt(np.mean(eh[train]**2))),'homography_holdout_point_rms_px':float(np.sqrt(np.mean(eh[~train]**2))),'limitations':['A fundamental matrix maps a point to an epipolar line, not a unique point. Its low error does not validate depth, focal length, scale or contour shape.','A poor single-homography fit is evidence against planar registration over this patch, subject to correspondence error; it does not prove a particular cylinder radius.','Fourteen training and seven held-out manually labeled glyph centers, after three ambiguous points are excluded; no K4 or optical-pattern fitting.']}
 (D/'two-view-registration.json').write_text(json.dumps(out,indent=2)+'\n')
 print({k:v for k,v in out.items() if 'rms_px' in k})
