"""Derived-only scientific plot. No source image pixels are embedded."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/kryptos-matplotlib-cache')
from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).parent
m=json.load(open(D/'ruled-strip-fit.json'));c=json.load(open(D/'cross-view-fit.json'))
fig,axs=plt.subplots(1,2,figsize=(13,5),layout='constrained')
colors=['#727c87','#795aa5','#007a8f','#db7822','#b14f70','#b73131']
for x,col in zip(m['focal_scenarios'],colors):
 p=np.array(x['horizontal_profile_over_H']);axs[0].plot(p[:,0],p[:,1],'.-',label=f"f1={x['f_px_assumed']} px",color=col,lw=1.8,ms=3)
axs[0].set_aspect('equal');axs[0].grid(alpha=.2);axs[0].set_xlabel('Chord-axis position / H');axs[0].set_ylabel('Perpendicular departure / H');axs[0].set_title('Same first photo, different conditional visible strips',fontsize=11);axs[0].legend(fontsize=8,ncol=2)
y=[v['holdout_point_rms_px'] for v in c['scenarios']];xx=np.arange(len(y));axs[1].bar(xx,y,color=colors,width=.68)
for i,v in enumerate(y):axs[1].text(i,v+.5,f'{v:.2f}',ha='center',fontsize=9)
axs[1].set_xticks(xx,[str(v['f1_px_assumed']) for v in c['scenarios']]);axs[1].set_xlabel('Assumed first-camera focal length (pixels)');axs[1].set_ylabel('Second-view held-out point RMS (pixels)');axs[1].set_ylim(0,35);axs[1].grid(axis='y',alpha=.2);axs[1].set_title('Second view rejects the most stretched candidate',fontsize=11)
fig.suptitle('Kryptos: partial photo constraints, not surveyed full-panel geometry',fontsize=14)
fig.supxlabel('H=1 is a dimensionless gauge. 14 training + 7 held-out glyph centers. Camera/lens and outline assumptions remain.',fontsize=9)
fig.savefig(D/'calibration-summary-derived.png',dpi=150);fig.savefig(D/'calibration-summary-derived.svg')
