# Kryptos: source-space evidence and bounded cross-view reconstruction

Prepared 22 October 2026. This package is a reproducible measurement experiment, not an as-built survey or a solution to K4.

## Result

Real visual evidence now constrains the simulator more than a generic font and a free sine curve:

- 44 named source-pixel boundary/seam observations, with source identity and hash.
- 24 named non-K4 glyphs inspected in two photographs; 21 usable correspondences after three ambiguous observations are excluded.
- A deterministic, partial serif/stencil aperture contour from a Dunin rubbing, and an actual raised-Y alignment observation.
- An executed second-camera check which rejects one strongly stretched candidate profile, while leaving more than one shallower profile compatible with the observations.

There is **no new absolute physical size, full-panel contour, true compass bearing, exposure time, or probability interval**. The main implementation gain is a first-class evidence dataset and a falsifiable, partial photo-constrained model family, not a newly certified default sculpture.

## Sources and coordinate conventions

1. Jim Gillogly, [left view](https://voynich.net/Kryptos/full/left.jpg), 768 × 1024 pixels. SHA-256 f452df1bf527bd3d6d6aa4bd061bf5b233d77d9e5f6f48d822f34ca93b97c66c.
2. Jim Gillogly, [lower-middle cipher view](https://voynich.net/Kryptos/full/cipherlowermiddle.jpg), 1280 × 960 pixels. Exact hash is in `middle-glyph-landmarks.json`.
3. [Gillogly source index](https://voynich.net/Kryptos/) states copyright Jim Gillogly, 1999, all rights reserved. That date is not an exposure timestamp. The original image files are excluded from this package.
4. Elonka Dunin's [rubbing gallery](https://www.elonka.com/kryptos/rubbings/images1.html), [visit report](https://elonka.com/kryptos/), and [transcript](https://elonka.com/kryptos/transcript.html). Five exact raster URLs, dimensions and hashes are preserved in `rubbing-glyph-sample.json`.

Source pixels have origin at the upper left, x right and y down. Glyph row/column indices are zero-based global ciphertext indices. No K4 glyphs or cribs are used. The Highsmith/LOC2011631531 photograph is not fitted or used in model selection; it remains an optical holdout.

## What was actually fitted

### First view: conditional, visible ruled strip

The first view's copper top, lower outline and horizontal seam were manually digitized. A pinhole camera and a vertical, constant-height ruled strip were assumed. Height H=1 is a dimensionless gauge, **not one metre**. The camera was assumed to have square pixels, zero skew, no distortion, and a principal point at (384,512), except for two explicitly recorded sensitivity cases.

For each assumed focal length f1, four parameters were fitted: the two independent components of the world-up direction in camera coordinates, camera height/H, and the seam's height/H. The seam was not forced to exactly H/2. Each observed top-edge pixel was intersected with the top plane, then displaced by one H along the up direction to predict the lower edge. Intermediate displacement predicted the seam. Alternate interior samples were withheld from that first fit, but their checks use interpolated observations on the same photograph. This is an internal interpolation check, **not an independent-view validation**.

The reconstructed cross-section is a 15-point polyline. Its full modeled extent runs between observed top-edge pixels (287,199) and (674,217). This is only the visible strip in that photograph. In particular, the right visible boundary may be an occluding silhouette rather than the cipher/tableau join. Therefore its length, chord and sagitta must not be interpreted as the full cipher half, let alone used twice to manufacture a complete S-screen.

A single view is insufficient: boundary fit RMS remains about 3.1–3.3 px and seam RMS about 3.3–3.6 px across f1=400–4000 px, while the conditional visible-strip length/H ranges from 0.606 to 1.380. Those focal values are sensitivity cases, not a confidence range or a claimed lens specification.

### Second view: same physical glyph identities, new camera

Aperture bounding boxes were independently inspected in the two source images. The raw observations retain exact glyph identities, estimated pixel bounds, arithmetic box centers, per-point 2–4 px working tolerances and ambiguity/exclusion flags. These centers are not perfect perspective-invariant fiducials: the center of a projected bounding box need not equal the projection of a fixed physical center. That adds systematic error beyond manual picking.

The provisional first-view picks were refined before fitting. Several had landed on adjacent letters. The old values are retained solely as `previous_provisional_xy`; they are **superseded and not used**. The shadowed first-view r23c07 A has null coordinates and is excluded. The second-view r23c01 K and r20c02 E are also excluded as ambiguous. The resulting 21 correspondences are not a regular grid.

For each candidate first-view strip, these source points were back-projected onto its piecewise-planar ruled surface. Their 3D positions were then held fixed. A separate second-camera pose (three rotation and three translation parameters) and focal length f2 were fitted to 14 training glyphs. Its principal point was fixed at (640,480), with square pixels and no distortion. The focal search was bounded at 250–6000 px as an optimization scenario, not a physically verified lens range. Seven glyphs were held out from the second-camera optimization.

| Assumed f1 (px) | Fitted f2 (px) | Training point RMS (px) | Held-out point RMS (px) | Held-out maximum (px) | Visible-strip length/H | Sagitta/H |
|---:|---:|---:|---:|---:|---:|---:|
| 400 | 986 | 8.23 | 5.59 | 8.20 | 0.606 | 0.051 |
| 600 | 1059 | 6.48 | 4.16 | 6.15 | 0.628 | 0.077 |
| 800 | 1161 | 4.86 | 3.05 | 4.60 | 0.657 | 0.104 |
| 1200 | 1445 | 3.48 | 2.99 | 3.78 | 0.725 | 0.154 |
| 2000 | 3011 | 10.31 | 8.60 | 12.76 | 0.891 | 0.242 |
| 4000 | 6000, upper bound | 25.94 | 29.82 | 58.01 | 1.380 | 0.388 |

The second view materially distinguishes the scenarios. The most stretched candidate cannot reproduce the shared landmarks well and drives the second focal length to its bound. The 800- and 1200-px cases both predict held-out centers to about 3 px, too close to distinguish given these annotations and the box-center systematic error. Their sagitta/H still differs by about 48%. It would be misleading to choose one and label it measured.

This is an exploratory conditional comparison, not a calibrated statistical acceptance test. Held-out observations were examined to compare the family; they are not an untouched final validation set for a future refined model. Only the sampled patch is cross-checked: the usable points span source rows 14,19,20,23 and approximately columns 2–13. The strip beyond their horizontal coverage is not independently constrained by this check.

### Image-only registration check

Using the same training/held-out division, a rank-two fundamental matrix gives held-out Sampson RMS 2.17 px. A single homography gives held-out point RMS 8.97 px. These are different error definitions and must not be directly treated as the same score. The first supports usable epipolar correspondences; the poor single-plane point registration cautions against rectifying this curved patch with one homography. Neither result establishes scale or a particular radius.

## Aperture evidence and spacing

The linked rubbing rasters are 649 × 500 px, except NDY at 644 × 500. Full physical paper edges are not verified, and their JFIF density uses unit 0, not a reliable dpi unit. The reported 8.5 × 11 inch paper does not by itself turn the raster into a metric scan.

The R bowl/leg component is reproducibly segmented into 533 closed-loop raster-boundary vertices, area 5,424 pixel² and half-open bbox [297,42,403,193]. Its exact sculpture-wide occurrence is not established. It is a **partial component, not a complete R aperture or a globally valid R template**. A dark channel separating stem and bowl remains 20 pixels at the documented probe line across three thresholds, supporting a real stencil-like counter connection. Rubbing spread, incomplete graphite, filtering and scan deformation prevent calling the trace fabrication CAD.

The NDY baseline samples are D=190, Y=160, T=399, N=401 px. The difference-of-differences (Y−D)−(N−T) is −32 px, consistent with the raised Y described by Dunin. A conservative ±20 px envelope covers only the four manual ±5 px picks, not scan deformation or serif interpretation. The ratio −32/209≈−0.153 relative to the local D→T spacing can be displayed only as a rubbing-space ratio, not a surveyed panel displacement.

## Safe import into the simulator

- Import raw observation datasets in source-pixel space. Show source dimensions, hash, provenance and uncertainty flags.
- Keep conditional registration and 3D transforms separate from the raw data. Export both, including the exact selected scenario.
- A preview may show the conditional visible strip and its sparse glyph points, with H=1, focal assumptions and the sampled extent clearly labeled. Do not complete the unseen geometry by mirroring, stretching or assigning it to a whole panel without another explicit assumption.
- Do not replace all R apertures with the partial trace; display it as an evidence fixture or support partial component import with null physical scale.
- Do not silently assign metres per pixel, 3-inch cap height, a true-north heading or a date/time.
- Preserve null/excluded points. Never fall back from a missing physical coordinate to a source-pixel coordinate as though they were the same unit.
- Generic complete-screen geometry may remain an explicitly assumed scenario. These files enable real fitting and evidence inspection without falsely certifying the entire scene.

## Reproduction

Dependencies: Python, NumPy, SciPy and Pillow. Numerical fits use the recorded observations and run without the copyrighted photos:

    python fit_ruled_strip.py
    python check_two_view_registration.py
    python fit_cross_view.py

For the rubbing trace, the original scans are needed in a private source cache. The script verifies hashes; its `--download` option retrieves them from the recorded source URLs:

    python trace_rubbing_sample.py --source-dir /tmp/kryptos-rubbings --output-dir /tmp/rubbing-reproduced --download

All output residuals, cameras, conditional points and masks are preserved in JSON. The manifest records every delivered file's SHA-256. Original photographs, original rubbings and private photo-overlay annotations are excluded.

## What remains unresolved

A complete multi-view reconstruction still needs wider, well-distributed, physically stable feature correspondences, lens/crop constraints and independent view checks. A complete metric model additionally needs a defined physical scale and independent dimensional checks. True heading, finite thickness, receiver elevations, other occluders and timed illumination require their own evidence. This experiment does not reconcile published 8-foot versus approximately 3-metre height reports, quarter-inch versus half-inch thickness accounts, or an artwork bounding box with copper-sheet dimensions.
