"""Single-view, constant-height ruled-strip camera experiment, not a survey.
Run python fit_ruled_strip.py. Data in source pixels, image origin top-left.
Numerical reproduction needs no photo: source hash is preserved if the private cache is absent.
No copyrighted photographs are copied into the output directory.
"""
import json, hashlib
from pathlib import Path
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import least_squares
D=Path(__file__).parent
# Human picks at the visible edge; review annotations before adding more precision.
top=np.array([[287,199],[310,192],[340,186],[370,182],[400,180],[430,179],[460,179],[490,180],[520,181],[550,183],[580,186],[610,190],[640,197],[660,206],[674,217]],float)
bottom=np.array([[302,895],[320,901],[350,907],[380,912],[410,915],[440,916],[470,916],[500,913],[530,910],[560,905],[590,899],[620,890],[650,878],[670,869],[684,862]],float)
seam=np.array([[296,552],[320,553],[350,554],[380,554],[410,553],[440,552],[470,551],[500,549],[530,547],[560,545],[590,542],[620,539],[650,535],[679,532]],float)
# H=1 is a dimensionless gauge, not one metre; bottom plane is height zero.
# Camera ray r=((u-cx)/f,(v-cy)/f,1); unit world-up n in camera coordinates.
# Top X satisfies n.X=1-h_camera; bottom X-n and seam X-(1-q)n.
def geometry(p, f, pp=(384,512)):
 nx,nz,h,q=p
 n=np.array([nx,-np.sqrt(max(1e-9,1-nx*nx-nz*nz)),nz])
 r=np.column_stack(((top[:,0]-pp[0])/f,(top[:,1]-pp[1])/f,np.ones(len(top))))
 denom=r@n
 dist=(1-h)/denom
 X=dist[:,None]*r
 def proj(P):
  return np.column_stack((f*P[:,0]/P[:,2]+pp[0],f*P[:,1]/P[:,2]+pp[1]))
 return proj(X-n),proj(X-(1-q)*n),X,n,dist
B=PchipInterpolator(bottom[:,0],bottom[:,1],extrapolate=True)
S=PchipInterpolator(seam[:,0],seam[:,1],extrapolate=True)
def residual(p,f,pp=(384,512), train=True):
 b,s,X,n,dist=geometry(p,f,pp)
 # Withhold alternate interior samples, including seam observations; no light image used.
 ix=np.arange(len(top)); use=(ix%2==0) if train else np.ones(len(top),dtype=bool)
 res=list((b[use,1]-B(b[use,0]))/3)+list((s[use,1]-S(s[use,0]))/3)
 res += [(b[0,0]-bottom[0,0])/3,(b[-1,0]-bottom[-1,0])/5]
 # Reject behind-camera solutions smoothly.
 res += list(np.minimum(dist,0)*100)
 return np.asarray(res)
def fit(f,pp=(384,512)):
 best=None
 for nz in [-.30,-.15,-.05,.05]:
  for h in [.45,.6,.8]:
   r=least_squares(residual,[.02,nz,h,.5],args=(f,pp),bounds=([-.15,-.5,.15,.4],[.15,.3,.95,.6]),max_nfev=4000,ftol=1e-11,xtol=1e-11,gtol=1e-11)
   if best is None or np.sum(r.fun**2)<np.sum(best.fun**2):best=r
 b,s,X,n,dist=geometry(best.x,f,pp)
 # x-direction perpendicular to up, no compass orientation; project onto base plane.
 axis=np.array([1.,0,0]); axis-=n*(axis@n);axis/=np.linalg.norm(axis)
 forward=np.cross(axis,n);forward/=np.linalg.norm(forward)
 Q=X-X[0];profile=np.column_stack((Q@axis,Q@forward))
 # chord-aligned coordinates in the horizontal plane make curvature clearer.
 chordvec=profile[-1]-profile[0]; chord=np.linalg.norm(chordvec);e=chordvec/chord; en=np.array([-e[1],e[0]])
 profile=np.column_stack((profile@e,profile@en)); arc=np.linalg.norm(np.diff(profile,axis=0),axis=1).sum()
 eyb=b[:,1]-B(b[:,0]);eys=s[:,1]-S(s[:,0]);hold=np.arange(len(top))%2==1
 return {'f_px_assumed':f,'principal_point_assumed':list(pp),'parameters':dict(zip(['up_camera_x','up_camera_z','camera_height_over_H','seam_height_over_H'],map(float,best.x))), 'n_camera':n.tolist(),'cost_scaled':float(np.sum(best.fun**2)), 'boundary_fit_rms_px':float(np.sqrt(np.mean(eyb[~hold]**2))), 'seam_fit_rms_px':float(np.sqrt(np.mean(eys[~hold]**2))), 'boundary_withheld_interpolation_rms_px':float(np.sqrt(np.mean(eyb[hold]**2))), 'seam_withheld_interpolation_rms_px':float(np.sqrt(np.mean(eys[hold]**2))), 'boundary_max_abs_px':float(np.max(abs(eyb))), 'seam_max_abs_px':float(np.max(abs(eys))), 'endpoint_dx_px':[float(b[0,0]-bottom[0,0]),float(b[-1,0]-bottom[-1,0])], 'predicted_bottom_px':b.tolist(),'predicted_seam_px':s.tolist(),'horizontal_profile_over_H':profile.tolist(),'visible_strip_chord_over_H':float(chord),'visible_strip_polyline_length_over_H':float(arc),'max_sagitta_over_H':float(np.max(abs(profile[:,1]))),'positive_depth':bool(np.all(dist>0))}
if __name__=='__main__':
 src=Path('/tmp/kryptos-calibration-review/gillogly-left.jpg')
 meta={'status':'uncalibrated_conditional_reconstruction_not_as_built','source':{'id':'gillogly_left_1999','url':'https://voynich.net/Kryptos/full/left.jpg','source_index':'https://voynich.net/Kryptos/','dimensions_px':[768,1024],'sha256':('f452df1bf527bd3d6d6aa4bd061bf5b233d77d9e5f6f48d822f34ca93b97c66c' if not src.exists() else hashlib.sha256(src.read_bytes()).hexdigest()),'rights':'Copyright Jim Gillogly 1999, all rights reserved; image not redistributed'},'coordinate_system':'source pixels, origin top left; x right, y down; pixel-center convention approximate human annotations','annotations':{'top_edge':top.tolist(),'bottom_edge':bottom.tolist(),'horizontal_seam_center':seam.tolist()},'annotation_tolerance_scenarios_px':{'top':2,'bottom':3,'seam':3,'right_endpoint_x':5},'assumptions':['Pinhole camera; zero skew; square pixels; no lens distortion; uncropped principal point at image center unless scenario states otherwise','Copper cross-section constant with height; top and bottom level and separated by H=1 dimensionless','Horizontal seam constant height fraction, fitted independently, not forced to half height','Top/bottom endpoint identity is hypothetical: the right visible boundary may be a view-dependent occluding silhouette, not the physical cipher/tableau join; its x residual is weighted at 5 pixels','A fitted visible-strip length is not necessarily the full cipher-half developed width','A single view cannot validate these assumptions; focal sweep values are sensitivity scenarios, not a probability interval','Even-index top picks fitted; odd-index predictions tested against interpolated observed bottom/seam curves. This is an internal interpolation holdout, not an independent image holdout.'],'focal_scenarios':[fit(f) for f in [400,600,800,1200,2000,4000]],'principal_point_scenarios':[fit(800,pp) for pp in [(340,480),(420,550)]]}
 (D/'ruled-strip-fit.json').write_text(json.dumps(meta,indent=2)+'\n')
 for r in meta['focal_scenarios']+meta['principal_point_scenarios']:
  print('f',r['f_px_assumed'],'pp',r['principal_point_assumed'],'params',r['parameters'],'RMS',r['boundary_fit_rms_px'],r['seam_fit_rms_px'],'hold',r['boundary_withheld_interpolation_rms_px'],r['seam_withheld_interpolation_rms_px'],'L/H',r['visible_strip_polyline_length_over_H'],'C/H',r['visible_strip_chord_over_H'],'sag/H',r['max_sagitta_over_H'])
