# Kryptos physical-evidence import

## Import raw observations, not a new supposedly measured sculpture

This package supplies real source-pixel observations and a reproducible partial aperture trace. It deliberately separates these from conditional camera/shape experiments. It does not resolve copper height, whole-sheet developed width, true heading, thickness, water elevation or photo exposure time.

### Ready source-space inputs

- `boundary-observations.json`: 44 named outline/seam picks from Jim Gillogly's 768 × 1024 left view. The source URL and SHA-256 are recorded. The rightmost outline is not a verified physical corner and may be a view-dependent occluding silhouette.
- `rubbing-glyph-sample.json`: five linked rubbing originals with URL/dimensions/hash; one 533-vertex, partial R bowl/leg contour; four NDY baseline landmarks; deterministic algorithm and brightness-threshold sensitivity. Physical scale is null, deliberately.
- `left-glyph-landmarks.json` and `middle-glyph-landmarks.json`: corresponding named non-K4 glyph observations in two photographs. These are approximate aperture bounding-box centers with per-feature working tolerances and ambiguity flags, not precise physical fiducials. Keep any `usable_for_fit: false` or ambiguity/exclusion flags.

### Keep hypothetical transforms separate

- `ruled-strip-fit.json` and `fit_ruled_strip.py`: a dimensionless H=1 conditional visible-strip reconstruction for several assumed focal lengths. These are not interchangeable with full panel dimensions. The camera principal point, square pixels, no distortion, constant height/profile and boundary correspondence are assumptions.
- `cross-view-fit.json` and `fit_cross_view.py`, when present: a second-camera test of the conditional family using shared glyph observations, with held-out points.
- `two-view-registration.json` and `check_two_view_registration.py`, when present: an image-only fundamental matrix/homography comparison. Epipolar-line error is not point reprojection error, and neither is physical calibration.

### Safe application behavior

1. Show observation datasets in a source-space evidence layer with source dimensions and links; do not silently rescale to meters.
2. Preserve raw pixels, feature identity, source hash, all flags, and any chosen transform in exports. Re-importing the export should reproduce both evidence and choices.
3. Label the partial R as "uncalibrated rubbing segmentation, one component only." It is not a complete aperture or a template proven identical for every R. It demonstrates a physical stencil-like bridge and serifed outline.
4. A user-selected local scale or registration should produce a separate, explicitly assumed transform. Keep units null until that transform exists. Reject non-finite coordinates, mismatched source IDs, malformed polygons, and nonexistent glyph IDs.
5. The NDY image-space baseline difference-of-differences is −32 px. If displaying its ratio to the D→T baseline spacing, −32/209 ≈ −0.153, label this a local rubbing-space ratio, not a surveyed panel offset or a centimeter measurement.
6. All single-view conditional profiles must remain sensitivity scenarios; none should replace the default as "measured geometry" based merely on a low pixel residual.
7. Highsmith/LOC2011631531 is not used in fitting and remains available as an independent optical holdout. No K4 crib enters any geometry fitting.

## Reuse and access

Original copyrighted photographs/rubbings are not included. SVGs and preview PNG contain derived geometry only. Links allow inspection at the source; the evidence package does not grant photo-republication rights. Private working annotations on photographs remain outside this deliverable directory.
