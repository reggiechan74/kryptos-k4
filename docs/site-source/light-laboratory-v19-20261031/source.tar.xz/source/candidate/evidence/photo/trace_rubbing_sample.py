#!/usr/bin/env python3
"""Reproduce an UNCALIBRATED Kryptos rubbing trace, not CAD measurements.
Requires Pillow, NumPy, SciPy. Source rasters remain in a private cache.
Usage: python trace_rubbing_sample.py --source-dir /tmp/kryptos-rubbings --output-dir .
       add --download to retrieve any missing original linked JPEGs.
"""
import argparse, hashlib, json, pathlib, urllib.request
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

SOURCE_INFO={
 'dnq':([649,500],'69daa590b62bd05300b038bd12f31b181f613d44f363257b2cbf31d16ba8178d'),
 'kry':([649,500],'ea1380a61a99aa7a58365ff40afd015511d573c45b74a65b1223bd8e10ad0e69'),
 'pto':([649,500],'d9b2fc03beba806052ff7a42e294429c3a72f47bff651dd52a8a706076b41e1d'),
 'ndy':([644,500],'28e1e79a8861f1d33647749e8101f427239800f17e6bc319b32a90287f5679c6'),
 'ahr':([649,500],'8115b0347c55bdccc272c01f1f18534581d146b110ca4e132ad8ab61daf0c842')}
BASE='https://www.elonka.com/kryptos/rubbings/images/'

def perimeter(mask):
    # Oriented pixel-square boundary. Vertices use source pixel CORNERS.
    # With filled holes and a 4-connected component, selects outer boundary.
    edges=[]
    H,W=mask.shape
    for y,x in zip(*np.where(mask)):
        x,y=int(x),int(y)
        if y==0 or not mask[y-1,x]:edges.append(((x,y),(x+1,y)))
        if x==W-1 or not mask[y,x+1]:edges.append(((x+1,y),(x+1,y+1)))
        if y==H-1 or not mask[y+1,x]:edges.append(((x+1,y+1),(x,y+1)))
        if x==0 or not mask[y,x-1]:edges.append(((x,y+1),(x,y)))
    adjacency={}
    for p,q in edges:adjacency.setdefault(p,[]).append(q)
    loops=[]
    while adjacency:
        start=min(adjacency);p=start;loop=[start]
        while True:
            options=adjacency[p]
            q=options.pop(0)
            if not options:del adjacency[p]
            loop.append(q);p=q
            if p==start:break
        loops.append(loop)
    def area(p):return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]))/2)
    loop=max(loops,key=area)
    # Remove exactly collinear points only; no geometric approximation.
    unique=loop[:-1];out=[]
    for i,b in enumerate(unique):
        a=unique[i-1];c=unique[(i+1)%len(unique)]
        if (b[0]-a[0])*(c[1]-b[1])!=(b[1]-a[1])*(c[0]-b[0]):out.append(b)
    return out+[out[0]],len(loops)

def component(f,threshold):
    roi=np.zeros(f.shape,bool);roi[35:197,294:406]=True
    labels,_=ndi.label((f>=threshold)&roi) # default cross = 4-connected
    label=int(labels[80,367]);assert label>0
    selected=labels==label
    filled=ndi.binary_fill_holes(selected)
    ys,xs=np.where(filled)
    return selected,filled,[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]

def norm(points,origin,scale):return [[round((x-origin[0])/scale,8),round((y-origin[1])/scale,8)]for x,y in points]

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--source-dir',required=True);ap.add_argument('--output-dir',default='.');ap.add_argument('--download',action='store_true');a=ap.parse_args()
    cache=pathlib.Path(a.source_dir);cache.mkdir(parents=True,exist_ok=True)
    out=pathlib.Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
    sources=[]
    for name,(dims,expected)in SOURCE_INFO.items():
        path=cache/f'{name}.jpg'
        if not path.exists() and a.download:urllib.request.urlretrieve(BASE+name+'.jpg',path)
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
        if sha!=expected:raise ValueError(f'Source changed: {name}: expected {expected}, received {sha}')
        im=Image.open(path);assert list(im.size)==dims
        sources.append(dict(id=name,url=BASE+name+'.jpg',width_px=dims[0],height_px=dims[1],sha256=sha,bytes=len(raw),jfif_density=list(im.info.get('jfif_density',[])),jfif_unit=im.info.get('jfif_unit'),page_edge_status='Four physical paper edges not identifiable. Do not equate image extent to paper extent.',source_type='author-linked full-size JPEG; no larger raster discovered on gallery page'))
    image_array=np.array(Image.open(cache/'kry.jpg').convert('L'));f=ndi.median_filter(image_array,size=5,mode='reflect')
    selected,filled,bbox=component(f,180);points,loops=perimeter(filled)
    assert loops==1
    origin=[bbox[0],bbox[1]];height=bbox[3]-bbox[1]
    sensitivity=[]
    for t in [160,180,200]:
        sel,mask,b=component(f,t)
        sensitivity.append(dict(threshold=t,filled_pixel_area=int(mask.sum()),bbox_xyxy_half_open=b,raw_component_pixel_area=int(sel.sum())))
    # Reproducible scanline tests across the R's counter support channel.
    scanlines=[]
    for y in [45,48,50,52,55,108,110,112,114,116]:
        tests=[]
        for t in [160,180,200]:
            # Identify last white stem pixel before bridge, first white bowl pixel after it.
            stem=np.where(f[y,275:296]>=t)[0]+275;right=np.where(f[y,300:331]>=t)[0]+300
            se=int(stem.max());bs=int(right.min())
            tests.append(dict(threshold=t,stem_last_white_pixel_x=se,bowl_first_white_pixel_x=bs,dark_intervening_pixel_count=bs-se-1))
        scanlines.append(dict(y_pixel_index=y,tests=tests))
    # Manual photogrammetric landmarks, not extracted ideal CAD boundaries.
    landmarks=[
      dict(id='D_baseline',glyph='D',panel='lower ciphertext',row_one_based=1,column_one_based=3,segment_px=[[200,190],[235,190]],estimated_pick_uncertainty_px=5,feature='bottom of left serif; hand-picked horizontal sample'),
      dict(id='Y_baseline',glyph='Y',panel='lower ciphertext',row_one_based=1,column_one_based=4,segment_px=[[415,160],[470,160]],estimated_pick_uncertainty_px=5,feature='bottom serif; hand-picked horizontal sample'),
      dict(id='T_baseline',glyph='T',panel='lower ciphertext',row_one_based=2,column_one_based=3,segment_px=[[211,399],[271,399]],estimated_pick_uncertainty_px=5,feature='bottom serif; hand-picked horizontal sample'),
      dict(id='N_baseline',glyph='N',panel='lower ciphertext',row_one_based=2,column_one_based=4,segment_px=[[361,401],[412,401]],estimated_pick_uncertainty_px=5,feature='bottom of left serif; hand-picked horizontal sample')]
    for lm in landmarks:lm['segment_image_fraction']= [[round(x/644,8),round(y/500,8)]for x,y in lm['segment_px']]
    D,Y,T,N=[lm['segment_px'][0][1]for lm in landmarks]
    data={
      'schema_version':1,'status':'research evidence only; UNCALIBRATED; partial glyph coverage',
      'generated_by':'trace_rubbing_sample.py','source_checked_utc':'2026-10-22',
      'sources':sources,
      'coordinate_system':{'pixel_origin':'top-left image corner','x_direction':'right','y_direction':'down','pixel_footprint':'integer pixel (x,y) occupies [x,x+1] by [y,y+1]; contours use pixel corners','physical_units_per_pixel':None,'meters_per_normalized_unit':None},
      'calibration':{'reported_paper_inches':[8.5,11],'paper_source':'https://elonka.com/kryptos/','physical_page_edges_verified':False,'status':'uncalibrated','reason':'Author reports paper size, not that image borders are paper borders. Images may be cropped/resized and have no scale bar. Unitless JPEG 300×300 density is not 300 dpi.','reported_3_inch_letter_height_used':False,'assumed_paper_fit_used':False,'alternative_physical_scale_policy':'Any later 3-inch-letter or whole-image-paper fit must remain a separately labeled hypothesis, not a verified calibration.'},
      'traces':[{'id':'kry_R_bowl_leg_candidate','glyph':'R','source_id':'kry','location':'top visible row, middle character; sculpture-wide occurrence not established','coverage':'right-hand bowl and descending leg only; vertical stem not included','kind':'deterministic bright-region contour candidate, NOT surveyed metal boundary','method':{'grayscale':'Pillow convert L','median_filter_px':5,'median_mode':'reflect','threshold_gte':180,'component_connectivity':4,'roi_xyxy_half_open':[294,35,406,197],'seed_pixel_xy':[367,80],'fill_enclosed_holes':True,'simplification':'only exactly collinear raster-edge vertices removed'},'bbox_xyxy_half_open':bbox,'filled_pixel_area':int(filled.sum()),'raw_component_pixel_area':int(selected.sum()),'contour_px':points,'contour_image_fraction':[[round(x/649,8),round(y/500,8)]for x,y in points],'normalization':{'origin_px':origin,'isotropic_scale_px_per_unit':height,'formula':'u=(x-297)/151; v=(y-42)/151','physical_calibration':False},'contour_local_normalized':norm(points,origin,height),'sensitivity':sensitivity,'limits':['White rubbing region approximates aperture, but incomplete rubbing, graphite spread, compression and paper movement alter the edge.','Median filtering and hole filling remove texture, not verified copper.','Do not extrude this noisy trace as a fabrication-accurate mesh or silently generalize to every R.']}],
      'bridge_evidence':{'source_id':'kry','glyph':'R','claim':'Separate bright stem and bowl/leg regions with a dark channel connecting counter toward surrounding metal are consistent with a stencil aperture.','probe_interpretation':'Dark intervening pixels are image-space rubbing evidence, not a measured metal bridge width.','scanlines':scanlines},
      'alignment_sample':{'source_id':'ndy','landmarks':landmarks,'manual_points_not_contours':True,'observations':{'Y_minus_D_baseline_px':Y-D,'N_minus_T_baseline_px':N-T,'double_difference_px':(Y-D)-(N-T),'formula':'(Y baseline - D baseline) - (N baseline - T baseline)','negative_means':'Y appears higher relative to neighboring D than N relative to neighboring T','conservative_manual_pick_range_px':[-52,-12],'physical_shift_cm':None},'limits':['Landmarks are visual estimates at the stated integer pixels, with ±5 px per pick as a working uncertainty, not a calibrated statistical interval.','Double difference compares nearby rows to reduce global tilt, but does not rectify local page deformation or scan shear.','Different glyph baseline profiles and serif curvature add uncertainty.','Do not use a rectangular image-to-paper fit to convert this offset to centimeters.'],'text_identity_source':'https://elonka.com/kryptos/transcript.html'},
      'copyright':'Original source JPEGs excluded from deliverables. Source URLs and hashes support inspection; derived polygons/measurements only.'}
    (out/'rubbing-glyph-sample.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    # Standalone derived SVG: contour + inferred bridge probes, no raster embed.
    path='M '+' L '.join(f'{x},{y}'for x,y in points)+' Z'
    svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="820" height="760" viewBox="205 10 225 210"><title>Uncalibrated rubbing-derived R component</title><desc>Derived from kry.jpg SHA256 {SOURCE_INFO['kry'][1]}. Median 5, threshold 180, seeded white component. Not a surveyed aperture.</desc><rect x="205" y="10" width="225" height="210" fill="#f8fafc"/><path d="{path}" fill="#0e7490"/><line x1="290" y1="50.5" x2="310" y2="50.5" stroke="#f97316" stroke-width="1.4"/><circle cx="367.5" cy="80.5" r="1.5" fill="#f97316"/><text x="213" y="18" font-size="5" font-family="sans-serif">R right component · source pixels · UNCALIBRATED</text><text x="213" y="205" font-size="4.5" font-family="sans-serif">Orange: 20 dark pixels at y=50; stem omitted</text><text x="213" y="213" font-size="4.5" font-family="sans-serif">Rubbing segmentation, not fabrication geometry</text></svg>'''
    (out/'rubbing-R-uncalibrated.svg').write_text(svg+'\n')
    # Derived PNG for inspection, explicitly with no original raster.
    preview=Image.new('RGB',(900,840),'white');draw=ImageDraw.Draw(preview)
    display=lambda p:((p[0]-205)*4,(p[1]-10)*4)
    draw.polygon([display(p)for p in points],fill='#0e7490')
    draw.line([display((290,50.5)),display((310,50.5))],fill='#f97316',width=5)
    draw.text((25,12),'R RIGHT COMPONENT: UNCALIBRATED RUBBING SEGMENTATION',fill='black')
    draw.text((25,800),'Source-space contour only. No verified physical scale; not fabrication geometry.',fill='black')
    preview.save(out/'rubbing-R-derived-preview.png')
    ns=['<svg xmlns="http://www.w3.org/2000/svg" width="644" height="500" viewBox="0 0 644 500"><title>NDY image-space baseline landmarks, uncalibrated</title><rect width="644" height="500" fill="#f8fafc"/><text x="20" y="25" font-size="14">NDY: manual baseline landmarks, not a traced image</text>']
    for lm in landmarks:
        (x1,y1),(x2,y2)=lm['segment_px'];ns.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#0e7490" stroke-width="3"/><text x="{x1}" y="{y1-10}" font-size="14">{lm["glyph"]}: y={y1} ±5 px</text>')
    ns.append('<text x="20" y="450" font-size="13">Y−D: −30 px; N−T: +2 px; double difference: −32 px</text><text x="20" y="475" font-size="13">No physical scale. Local paper deformation remains uncontrolled.</text></svg>')
    (out/'rubbing-NDY-landmarks.svg').write_text(''.join(ns)+'\n')
    print(json.dumps({'output':str(out),'R_bbox':bbox,'R_contour_vertices':len(points),'R_area_px':int(filled.sum()),'threshold_sensitivity':sensitivity,'alignment_double_difference_px':(Y-D)-(N-T)},indent=2))
if __name__=='__main__':main()
