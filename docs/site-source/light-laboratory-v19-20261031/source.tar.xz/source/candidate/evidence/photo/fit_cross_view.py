"""Conditionally back-project shared glyph observations onto the ruled-strip
family, fit a second camera to training landmarks, and test held-out landmarks.
No scalar physical size, true-north yaw, solar time, or K4 crib enters the fit.
"""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from fit_ruled_strip import geometry
D=Path(__file__).parent

def ray_strip(xy, f, pp, Xtop, n):
 r=np.array([(xy[0]-pp[0])/f,(xy[1]-pp[1])/f,1.])
 hits=[]
 for a,b in zip(Xtop[:-1],Xtop[1:]):
  try: lam,s,v=np.linalg.solve(np.column_stack((r,-(b-a),n)),a)
  except np.linalg.LinAlgError: continue
  if lam>0 and -.01<=s<=1.01 and -.05<=v<=1.05:hits.append((lam,lam*r,v))
 if not hits:raise ValueError('Ray misses candidate ruled strip: '+str(xy))
 return min(hits,key=lambda h:h[0])[1]

def project(p,X,fixed_f=None):
 rot=Rotation.from_rotvec(p[:3]).as_matrix();cam=X@rot.T+p[3:6];f=np.exp(p[6]) if fixed_f is None else fixed_f
 return cam[:,:2]/cam[:,2,None]*f+[640.,480.],cam[:,2],f

def fit_camera(X,uv,train, n, fixed_f=None):
 center=X.mean(axis=0);Q=X-center
 def fun(p):
  pred,depth,f=project(p,Q,fixed_f)
  return np.r_[((pred-uv)[train]).ravel()/5.,np.minimum(depth,0)*100]
 best=None
 fstarts=[500,1000,2000,4000] if fixed_f is None else [fixed_f]
 for theta in [-1.5,-1,-.5,0,.5,1,1.5]:
  for fs in fstarts:
   z=fs/1300
   x=(uv[:,0].mean()-640)*z/fs;y=(uv[:,1].mean()-480)*z/fs
   p0=np.r_[n*theta,[x,y,z],np.log(fs)] if fixed_f is None else np.r_[n*theta,[x,y,z]]
   lb=[-3.14]*3+[-10,-10,.05]+([np.log(250)] if fixed_f is None else [])
   ub=[3.14]*3+[10,10,20]+([np.log(6000)] if fixed_f is None else [])
   r=least_squares(fun,p0,bounds=(lb,ub),max_nfev=3000,ftol=1e-10,xtol=1e-10,gtol=1e-10)
   if best is None or sum(r.fun*r.fun)<sum(best.fun*best.fun):best=r
 pred,depth,f=project(best.x,Q,fixed_f);dist=np.linalg.norm(pred-uv,axis=1)
 return {'f2_px':float(f),'principal_point2_assumed':[640,480],'rotation_vector':best.x[:3].tolist(),'centered_translation':best.x[3:6].tolist(),'X_center':center.tolist(),'train_point_count':int(sum(train)),'holdout_point_count':int(sum(~train)),'train_point_rms_px':float(np.sqrt(np.mean(dist[train]**2))),'holdout_point_rms_px':float(np.sqrt(np.mean(dist[~train]**2))),'holdout_max_px':float(max(dist[~train])),'predictions_px':pred.tolist(),'point_errors_px':dist.tolist(),'all_positive_depth':bool(np.all(depth>0))}

if __name__=='__main__':
 model=json.load(open(D/'ruled-strip-fit.json'));src=json.load(open(D/'left-glyph-landmarks.json'));dst=json.load(open(D/'middle-glyph-landmarks.json'))
 # dst normalized by adapter before running: list of id/xy records.
 dest={p['id']:p for p in dst['points']};points=[p for p in src['points'] if p['id'] in dest and p.get('usable_for_fit',True) and p.get('usable_for_cross_view_check',True) and p.get('xy') is not None and not p.get('ambiguous',False) and not dest[p['id']].get('ambiguous',False)]
 uv=np.array([dest[p['id']]['xy'] for p in points]);hold_ids={'cipher_r14_c04_A','cipher_r14_c08_H','cipher_r19_c05_R','cipher_r19_c09_M','cipher_r20_c04_O','cipher_r20_c08_I','cipher_r23_c03_M','cipher_r23_c07_A'};train=np.array([p['id'] not in hold_ids for p in points])
 rows=[]
 for s in model['focal_scenarios']:
  f=s['f_px_assumed'];p=np.array(list(s['parameters'].values()));b,ss,Xtop,n,dist=geometry(p,f,s['principal_point_assumed'])
  X=np.array([ray_strip(x['xy'],f,s['principal_point_assumed'],Xtop,n) for x in points]);r=fit_camera(X,uv,train,n)
  rows.append({'f1_px_assumed':f,'conditional_points_H_units':X.tolist(),**r})
  print(f,'->',r['f2_px'],'training',r['train_point_rms_px'],'holdout',r['holdout_point_rms_px'],'max',r['holdout_max_px'],flush=True)
 out={'status':'conditional_multiview_check_not_metric_calibration','sources':['left-glyph-landmarks.json','middle-glyph-landmarks.json','ruled-strip-fit.json'],'feature_ids':[p['id'] for p in points],'fit_mask':train.tolist(),'assumptions':['The first-view visible ruled strip is the conditional shape, with H=1 dimensionless gauge.','Second view has its own unknown focal length fitted in 250–6000 px; centered principal point, square pixels, no distortion.','Fourteen training glyph centers fit the second camera; seven held-out centers evaluate reprojection. Three ambiguous observations are excluded.','Projected bbox centers are not exact physical fiducials; manual image picks carry additional systematic errors.','The full visible strip endpoints are source top-edge pixels (287,199) to (674,217); this is not necessarily the full cipher-half extent.','Cross-view glyphs cover only rows14,19,20,23 and columns2–13 approximately; curve segments outside their source span are not independently checked.','No original copyrighted image is distributed and Highsmith image is not used.'],'scenarios':rows}
 (D/'cross-view-fit.json').write_text(json.dumps(out,indent=2)+'\n')
