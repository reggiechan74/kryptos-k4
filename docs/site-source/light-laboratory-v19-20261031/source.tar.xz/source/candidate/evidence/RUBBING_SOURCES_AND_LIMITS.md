# Kryptos rubbing evidence: partial, uncalibrated

## What this provides

A reproducible image-space contour of the right-hand bowl/leg of one **R**, plus four manually selected baseline landmarks in **NDY**. This is a research fixture for checking stencil topology and local alignment. It is **not** a surveyed glyph library, a dimensioned panel map, or fabrication-ready geometry.

## Provenance and actual resolution

- Gallery: https://www.elonka.com/kryptos/rubbings/images1.html
- Author's visit report: https://elonka.com/kryptos/
- Identity cross-check: https://elonka.com/kryptos/transcript.html
- Full-size linked files: https://www.elonka.com/kryptos/rubbings/images/kry.jpg and corresponding dnq.jpg, pto.jpg, ndy.jpg, ahr.jpg.

Elonka Dunin dates these rubbings to her October 18, 2002 visit and reports standard 8.5 × 11 inch sheets. She flags uneven rubbing and identifies Y, A and R as misaligned in the lower-left top line. The transcript establishes D/Y in lower-ciphertext row 1, columns 3/4, and T/N immediately below in row 2, columns 3/4. The R sample's exact sculpture-wide occurrence is not established here.

All five author-linked originals were downloaded on 2026-10-22. DNQ, KRY, PTO and AHR are 649 × 500 pixels; NDY is 644 × 500. Exact URLs, byte sizes and SHA-256 hashes are in the JSON. No larger linked versions were discovered on this gallery page. Original JPEGs are deliberately **not** included in the deliverables.

## Calibration is missing

The raster borders do not identify all four physical paper edges. The nearly landscape-letter aspect ratio is compatible with a full-page scan but does not prove one. The images could have been cropped or resized. JPEG JFIF density is (300,300) with **unit 0**, so it is a unitless aspect-density value, not evidence of 300 dpi.

No inches/pixel, meters/pixel, or centimeter displacement is assigned. The author's paper-size statement and any separately reported 3-inch letter height are potential alternative assumptions, not verified calibration. Do not silently fit the raster rectangle to 11 × 8.5 inches or force the measured R height to 3 inches. A ruler, known complete paper boundary, or independent surveyed control would be needed.

## Reproducible R contour

`trace_rubbing_sample.py` verifies every source hash, converts KRY to grayscale, applies a 5 × 5 median filter, thresholds at 180, and selects the 4-connected bright component containing pixel (367,80) inside a documented ROI. It extracts the exact outer boundary of the component's pixel-square union. Only collinear boundary vertices are removed. The ROI does not touch this selected component.

Result: half-open bounding box **[297,42,403,193]**, **5,424 pixel²**, **533 closed-loop vertices**. Coordinates are source pixels with upper-left origin and +y downward. Isotropic local normalization is `(x−297)/151, (y−42)/151`; normalized units have no physical size. The SVG and PNG contain derived geometry only.

At row y=50, the smoothed white stem ends at pixel x=289 and the bowl begins at x=310, leaving 20 dark pixels between. Thresholds 160, 180 and 200 preserve this gap. This supports a stencil-like counter connection rather than a conventional closed-counter font. Other probe lines are included to expose variability. It does **not** measure the actual copper bridge width.

Threshold sensitivity changes area from 5,460 to 5,263 pixel² and bottom extent by one pixel. This tests only brightness threshold sensitivity. Rubbing spread, smudges, paper motion, scan distortion and chosen smoothing can dominate it. Never treat the exact stored pixels as equally exact physical boundaries.

## Local alignment sample

Hand-picked source-image baselines: D y=190, Y y=160, T y=399, N y=401; each has a working ±5 px picking uncertainty. Segment endpoints and glyph identities are recorded. The difference of differences is `(Y−D)−(N−T) = −32 px`, with a conservative ±20 px pick-only envelope. Negative means Y appears higher than its neighbor relative to the lower row. This partially reduces global image tilt but does not rectify local paper deformation, shear or serif-profile differences. It is a candidate local-offset constraint, not a complete measured spacing model.

## Reproduce and import

Run:

    python trace_rubbing_sample.py --source-dir /tmp/kryptos-rubbings --output-dir /tmp/reproduced

Add `--download` to retrieve absent source JPEGs into that private cache. Requires Python, Pillow, NumPy and SciPy. The JSON has pixel and normalized contours, provenance, algorithm settings, threshold sensitivity, bridge probes and landmark uncertainty. Keep all calibration flags and provenance in any importer. Do not use this one R as an authoritative stencil for all occurrences or assign panel coordinates to it without further registration.
