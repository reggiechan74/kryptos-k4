// Opaque geometry is a set. Exact coincident repeats must not add edge coverage.
// No coordinates are rounded; cyclic starts and opposite winding share identity.
export function opaqueFaceKey(points){if(points.length<3)throw Error('Opaque face needs at least three vertices');const a=points.map(p=>Array.from(p).join(','));const first=a.reduce((x,y)=>x<y?x:y);let best=null;for(let i=0;i<a.length;i++){if(a[i]!==first)continue;for(const step of [1,-1]){const key=Array.from({length:a.length},(_,j)=>a[(i+step*j+a.length*2)%a.length]).join(';');if(best===null||key<best)best=key;}}return best;}
export function uniqueOpaqueFaces(faces){const seen=new Set(),result=[];for(const face of faces){const key=opaqueFaceKey(face.p);if(seen.has(key))continue;seen.add(key);result.push(face);}return result;}
