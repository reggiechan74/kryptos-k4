// Bulk-submit projected polygons to Canvas Path2D. This changes only raster
// submission: every opaque world-space polygon remains in the shadow union.
// Coordinates are rounded to 0.001 CSS px, far below a display pixel.
export function svgPolygons(polygons, transform) {
  const paths=[];
  for (const polygon of polygons) {
    const p=polygon.map(transform);
    let area=0;
    for(let i=0;i<p.length;i++) {
      const a=p[i],b=p[(i+1)%p.length];
      area+=a[0]*b[1]-b[0]*a[1];
    }
    if(area<0)p.reverse();
    let data='';
    for(let i=0;i<p.length;i++)data+=(i?'L':'M')+p[i][0].toFixed(3)+','+p[i][1].toFixed(3);
    paths.push(data+'Z');
  }
  return paths.join('');
}
