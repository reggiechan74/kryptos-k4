# Invented cylinder sampler v1

Status: untested artistic hypothesis; synthetic tabletop apparatus. Not a reconstruction of Kryptos or assertion of Sanborn's method. Real copper is not treated as a polished mirror.

The separate screen-perspective illustration calls the SAME `screenGeometry(geometry).at(u,v)` surface used by the existing workbench, with the current assumptions. It changes the pinhole viewpoint, not the surface or sunlight. Wireframe lines represent layout anchors, not measured apertures. Full physical cutouts remain in the original optics mode.

## Coordinates and one global apparatus

Arbitrary tabletop model units, x right, y up, z toward eye/tableau. Cylinder x²+z²=radius², y in (0,3), perfect specular exterior. Eye E=(0,1.5,eyeDistance). A transparent reticle lies at z=2, between eye and cylinder. K4 sample i uses n=i−1+27, row=floor(n/31), column=n mod31: four points at first row's right then 3×31. Point P=((column−15)*reticleWidth/31,1.5+(1.5−row)*0.075,2). Only layout is used; no ciphertext decryption.

Trace d=unit(P−E). Solve lateral cylinder quadratic; nearest positive root is the visible surface. Tangent/parallel/no-root/outside-height are invalid. Normal n=unit(hit.x,0,hit.z). Backward reflected trace r=d−2(d·n)n. Intersect z=tableauDistance; lambda must be positive. Physical light reverses the trace: printed tableau→mirror→eye. This is reflection, not projected illumination.

Printed tableau plane is behind the eye: tableauDistance > eyeDistance+0.2. Cell pitch .25; display33 columns×28rows; x left=shiftX−4.125, y top=5+shiftY. Column=floor((hit.x−left)/.25), row=floor((top−hit.y)/.25). Each canonical unequal-length row is centered with floor((33−length)/2); blanks remain blanks. Points within .01 cell pitch of a cell border invalidate. Original one-based row/source-column and display-column are exported. All97 share radius, eye, tableau and reticle parameters. Default global values merely keep the synthetic samples valid; no plaintext/clue fitting.

Optional opaque card AABB min(−.18,0,2), max(.18,3,2.2) blocks either open segment. It is a synthetic fixture, not a real obstruction. Touching its boundary counts as blocked. No independent per-letter adjustment or missing-key substitution exists. Any invalid sample makes full key/cipher null.

## Parameters, validation and reproducibility

State version1: radius[.25,1.4], eyeDistance[2.5,7], tableauDistance[4,10], shiftX[−4,4], shiftY[−3,3], reticleWidth[.1,.9], selected integer[1,97], obstruction boolean, view mirror/screen, screenYaw[−70,70]. All numbers finite. Additional relative distance constraint above. UI invalid edits retain the last valid state. Current UI fixes eyeDistance=4; exports preserve it. No hidden per-letter offsets, stochastic sampling or search.

`exportModel(state,screenGeometry)` returns schema `ideal-cylinder-reticle/1`, every fixed/global parameter, canonical tableau,97reticle positions, every ray/hit/status/source-cell, generated key or null, assumptions and current screen geometry. `validateState` + `generate` reproduces optical samples. Decorative plot coordinates do not drive the solver.

Synthetic message is97 letters from the keyed alphabet `KRYPTOSABCDEFGHIJLMNQUVWXZ`, independently of K4. Addition/subtraction is modulo26 using that ordering, with one generated key letter per message letter. No repeating/truncating key. Roundtrip proves reversibility only. Canonical K4 remains untouched and no K4 candidate plaintext is generated or submitted.

## Limits

Ideal point eye/reticle; no pupil, blur, diffraction or illumination/reflectance model. Cells, not surveyed aperture contours. No parameter calibration, historical feasibility impossibility claim, inverse search, guaranteed AI result or evidence of artistic intent. Known geometric optics could be explored with mirrors/tracing/photography before modern AI; current tools accelerate simulation and possible future inverse search.

Reference: https://pbr-book.org/4ed/Reflection_Models/Specular_Reflection_and_Transmission . Actual transcript: https://www.elonka.com/kryptos/transcript.html .
