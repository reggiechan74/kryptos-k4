# Systematic physical-optics implementation

Audience: existing PUBLIC Site, project preserved. Current baseline: version5 / commit8a346f329cafc5b91abba34636c3f1440eb3e1ff. No survey accuracy or photographic calibration is implied.

## Milestone1 — actual solids, receiver and light source

Implement selectable0/6.35/12.7mm/custom copper thickness as separate source alternatives, with normal-offset front/back surfaces and aperture walls. All occlusion tests use the whole solid path, including bridges. Preserve ideal-sheet legacy modes and migrate old state explicitly. Add sloped receiver intersections/clipping and a uniformly sampled finite solar disk. All disk samples must use the same copper/tree/seam solids; normalized transmission uses the unobstructed sum of the identical receiver-cosine-weighted samples. The finite-disk numerical quality/sample count is explicit, not hidden precision.

Acceptance: rectangular slab transmission formula; zero/normal/oblique/reverse/grazing fixtures; disconnected/concave aperture bridge crossing; cylindrical offset/tessellation convergence; ray-plane slopes; finite-disk straight-edge symmetry, half-light and penumbra width; all-open1/all-blocked0; complete state roundtrip and migration. Browser rendering must show the same solids, shadows respond, mobile/export remain usable, and performance timings are reported. Publish only a coherent passing milestone to the existing public audience.

Sources:6.35mm comes from reporter narrative in the SPYSCAPE Sheldon interview report, not a displayed direct quotation;12.7mm from the1991 memo remains a conflicting alternative. NASA Sun fact sheet gives apparent diameter1919arcsec at1AU, approximately0.2666° radius; it varies with distance. Uniform disk, fixed angular radius and no limb darkening/refraction are explicit numerical assumptions.

## Milestone2 — reproducible empirical geometry and apertures

Implement versioned imported geometry/aperture data and provenance, including physical contours/bridges, irregular centers, explicit units/frame, image coordinates, camera/scale transform, uncertainty, canonical letter IDs and immutable raw ciphertext. Do not silently substitute a generic glyph when an imported definition is missing or invalid. Imports validate atomically; exports include actual imported data and active physical parameters. Separate measured, documented, photo-derived and assumed records. Parallel research supplies actual constraints; absent evidence remains a blocker to an accuracy claim, not a reason to invent data.

## Milestone3 — calibration and independent validation support

Add referenced-image/landmark/camera records, alignment overlays and residual metrics. Identify letters rather than ambiguous repeated-letter generic features. Keep Highsmith held out; fit with independent images and report failures/degeneracies. Distinguish relative image fit from absolute scale/bearing and timestamp validation. No successful calibration is declared without actual fitted inputs and held-out residuals.

## Milestone4 — relevant surroundings and optional reflection

Add receivers/obstructions only as sourced records or visibly hypothetical fixtures. Use one mesh/solid definition for display and rays. Distinguish bubbling basin and reflecting pond. A window fixture needs position, normal, finite bounds and reflection geometry; never call it a verified courtyard window without evidence. Validate direct and reflected ray paths separately and retain receiver/source bounds. Data availability and measured relevance determine inclusion, not decorative completeness.

## Release discipline

Each milestone records implemented behavior, independent tests, browser observations and remaining data gaps in QA_REPORT.md and GEOMETRY_SPEC.md. State migrations preserve prior controls. Use pushed exact source/archive, save version then generic deploy_site_version for PUBLIC audience. Never use a private deployment operation or create a new Site. Do not change K4 research repositories or bypass a locked Mac.
