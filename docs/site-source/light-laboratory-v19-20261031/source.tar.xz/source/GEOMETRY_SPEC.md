# Physical geometry specification — evidence gate before reconstruction

Status: evidence ledger and implemented v2 specification, 2026-10-22. The full-screen model corrects supported topology but remains **not a measured dimensional reconstruction**. The v1 crop is retained as a control. See the final implemented-v2 section for active defaults; earlier sections preserve the audit trail. No parameter is elevated to surveyed accuracy by visual plausibility.

## Evidence classes

1. **Surveyed:** named measured feature, measurement method, units, datum, uncertainty, date and independently retrievable source. None currently loaded.
2. **Documented:** a credible primary record naming the feature being dimensioned. Record whether a dimension describes sheet stock, developed length, projected span, bounding envelope, or total installation. These quantities cannot substitute for one another.
3. **Inferred:** explicitly fitted from a cited photograph or map. Preserve landmarks, camera assumptions, reprojection residuals, scale anchors and uncertainty. A good-looking image is insufficient.
4. **Hypothesis:** user-adjustable experiment with no measurement support. Current defaults are in this class.
5. **Omitted:** components absent from the geometry, with consequences stated.

Every future geometry field should store value, units, frame/datum, class, source URL/page/figure, quoted feature definition, uncertainty/range, derivation, and revision. Missing evidence stays null rather than silently borrowing a number from another component. An overall 20 ft × 10 ft × 12 ft installation envelope, if documented, must remain an envelope constraint; it is not a copper panel width/height/depth measurement.

## Predecessor v1 isolated-crop implementation and provenance

`dist/math.mjs` defines `defaults` and `surface`. World axes are +X east, +Y up, −Z north, in model metres. For normalized panel coordinates u,v:

```
a = (u − 0.5) × width
b = curvature × sin(2π(u − 0.5))
x = a cos(heading) + b sin(heading)
y = base + v × height
z = −a sin(heading) + b cos(heading)
```

| Input | Default | Class and reason chosen | Physical meaning / limitation |
|---|---:|---|---|
| Width | 6.2 m | Hypothesis, chosen to give 31 legible 0.20 m cells | Chordwise X span before heading, not developed sheet length. No monument source. |
| K4 crop height | 1.5 m | Hypothesis, chosen for four visible rows | Four rows only, not full screen height. No monument source. |
| S-curve amplitude | 0.7 m | Hypothesis, visibly demonstrates curved-stencil projection | Maximum displacement from center plane, not radius of curvature or measured depth. Peak-to-peak depth is 1.4 m. No monument source. |
| Base / bottom clearance | 1.2 m | Hypothesis, separates the crop and its shadow for inspection | Height of crop bottom above model datum. Not actual monument ground clearance, nor the K4 height above paving. |
| Heading | 0° | Hypothesis, axis-aligned baseline for tests | Front normal is south (+Z) for the flat panel at heading 0; heading increases clockwise for that normal. Not a measured geographic bearing. |
| Receiver height | 0 m | Hypothesis / datum convention | Infinite flat horizontal plane. Adjustable 0–0.09 m. Not surveyed courtyard paving. |
| Aperture scale | 0.88 | Hypothesis, leaves visible material between bitmap strokes | Versioned original alphabet, not measured artist lettering. |
| Columns / offset | 31 / 27 | Documented transcription alignment | K4 #1–4 OBKR occupy columns 28–31 of transcript row25; following rows have31 letters. CIA and Dunin transcripts cross-checked. |
| Geographic coordinates | 38°57′6.5″N, 77°8′44″W | User-supplied K2 reference | Observer coordinates for Sun calculation, not surveyed sculpture center. |

Equal cell pitches: width/31 = 0.20 m horizontally, height/4 = 0.375 m vertically. Glyph stroke cells are rectangular, 0.88×0.20/7 = 0.0251429 m wide and 0.88×0.375/9 = 0.0366667 m high. Maximum 5×7 ink/aperture envelope is 0.125714 m × 0.256667 m. Missing bitmap squares form apertures; counters remain copper. There is no plate thickness, bevel or measured kerning. The curved surface uses chordwise spacing, not constant developed-length spacing. Labeling these lengths in metres and drawing a 1 m grid establishes internal units only.

The current four-row crop substitutes blank solid copper for the preceding27 K3 cells. This is an artificial boundary condition that can change the shadow. The full cipher half, reverse-reading tableau, supports, petrified wood, granite, pools, building masses, terrain and vegetation are omitted. Surrounding copper may occlude rays; zero-thickness material cannot reproduce tunnel clipping through a thick aperture. No photo calibration has been performed.

Primary context currently consulted:

- https://www.cia.gov/legacy/headquarters/kryptos-sculpture/ — identifies an S-shaped copper screen and cipher/tableau arrangement; supports context/transcript, not current geometry numbers.
- https://www.elonka.com/kryptos/transcript.html — cross-checks transcription/alignment, not current geometry numbers.
- https://elonka.com/kryptos/ — photograph/source index; a link is not a dimensional calibration.

## Next supported scope and data gaps

Before implementing the full screen, obtain separate evidence for: copper boundaries and developed width; heights of full screen and individual rows; top/bottom contours; screen centerline in a ground datum; fold/curve shape; local panel normals; geographic bearing; location/clearance of the K4 crop; glyph outlines/spacing; thickness; and relative position of cipher versus tableau. Preserve transcript row lengths rather than assuming a regular rectangular mesh if measurements contradict it. Identify the reverse-reading tableau handedness from the CIA description and photographs.

Add supports, stones, pools and buildings only where an image, drawing, survey or scaled plan constrains their position/extent. An unsupported obstruction should remain a visibly generic adjustable hypothesis, off by default. Do not fabricate detailed architecture. Water reflection, refraction and dynamic surfaces are separate optional physics, not an automatic consequence of drawing a pool.

Scott audit input must distinguish code constants, source citations, inferred values and confirmed measurements. Matching Scott's numbers or silhouette is not independent validation. No Scott source has been copied into this project. Await the audit before assigning confidence to its dimensions.

## Photo calibration and falsifiable validation plan

Use independent photographs with provenance, original resolution, crop/orientation and clock metadata recorded. Prefer ground/control distances or official drawings for absolute scale; a single unscaled photograph cannot determine absolute size. Avoid treating image timestamp as verified solar time. For each image store landmark pixel coordinates and uncertainty, camera model, intrinsics/principal point assumptions, extrinsic pose and whether fitted or held out. Do not fit the sculpture, camera and sunlight unconstrained to the same image and call the result verified.

Fit a low-dimensional centerline and row/column surface coordinates with uncertainty first. Retain residual vectors and alternative fits. Use one set of images for fitting, and hold out at least two independent viewpoints with no geometry retuning. Validate back-facing letters and ray interception separately from silhouette. Shadows can constrain light and surfaces only when date/time/location and receiver geometry are sufficiently known.

## Measurable acceptance criteria before claiming a reconstruction

- Every dimension bearing a physical-accuracy claim has a feature-specific provenance record; every unsupported parameter visibly says assumed/inferred. Zero unlabelled guessed dimensions.
- A documented dimension is reproduced within its stated measurement uncertainty. When uncertainty is absent, do not invent a precision target or claim a pass; record the gap.
- At least two independent holdout viewpoints: at least20 distributed recognizable landmarks each, including upper/lower edges and both ends. Report RMS and maximum reprojection error in pixels and as fractions of image width. A provisional engineering target is RMS <=1% of image width and maximum <=2%; it is a proposed threshold, not an achieved result or a survey-accuracy bound.
- Reject degenerate fits: unbounded focal length/distance, incompatible scale between views, or systematic residuals. Report parameter confidence intervals and sensitivity to landmark/time uncertainty. Retain failed fits.
- Ground/receiver intersections and physical aperture handedness remain invariant under camera changes. South light casts north; east light casts west. Flat-panel vertical projection scale agrees with cot(elevation) at30°,45°,60° within numerical tolerance. Horizon cutoff prevents reverse/NaN projections.
- Occlusion checks include omitted-to-included component comparisons, aperture counters, reverse views and curved self-overlap. Plate-thickness clipping must be tested if thickness is claimed.
- State export captures model revision, evidence records, uncertainty parameters, exact active light, camera, aperture geometry and all receiver/obstruction inputs. Roundtrip reproduces numeric results.
- Pass desktop/mobile rendering, modes and console checks. These establish usability, not physical accuracy.

## Decision gate

Integrate authoritative-dimension and Scott-audit evidence into this document before major geometry implementation. Present conflicts and remaining scale/camera ambiguities explicitly. The current attractive rendering must remain marked approximate until the geometric criteria can actually be assessed.

## Incoming audit evidence — provisional, awaiting final provenance matrix

The parent research thread supplied these findings during QA. They are recorded here with attribution and unresolved definitions; this worker has not independently reread the memo image. **No model parameter has been changed from them.**

| Reported source / feature | Incoming value | Treatment before implementation |
|---|---|---|
| Artist public-spaces listing, https://jimsanborn.net/content.html#PUBLIC_SPACES | Courtyard artwork12′×20′×10′ overall | Documented installation envelope, not a panel measurement. Axis order, component bounds and relation to full screen still need definition. Do not map20ft to panel width. |
| NSA `doc_3.pdf`, PDF page4 / printed PAGE4,1991 George C. Dalmas installed-sculpture memo; researcher visually inspected | Tableau side8ft×8ft | Feature-specific reported documented constraint. Await exact stable URL, original excerpt, definition of width (stock/arc/chord/span) and uncertainty/context. Do not infer the cipher side has the same dimensions. |
| Same memo | ½-inch copper thickness, both sides | Reported documented thickness =12.7mm. Await original excerpt/context; a future physically claimed model needs actual thickness and ray clipping, not just material color. |
| Same memo, cipher side first dimension | Degraded numeral, parsers disagree | Unresolved. Preserve competing readings and source crop; do not hard-code8×8 for both sides. |
| Scott v2 source audit | Height2.75m; arc length2.85m per half; radii1.45m; front heading140° | Estimates/hypotheses only; source reportedly explicitly records a failed photographic fit. Different geometric definitions must be reconciled before comparing to our chordwise span. Not copied into this implementation. |

Required next input: final source/provenance matrix including exact memo URL and feature definitions, Scott code references and uncertainty labels, and photograph constraints. Until then, the model remains the unchanged uncalibrated K4 crop.

## Physical lettering: transcription is not aperture metrology

Further incoming primary-source audit distinguishes three separate data layers:

- Canonical ciphertext and one-based row/column indices establish textual identity and order; they do **not** establish physical centers, kerning, outlines, stencil bridges or aperture dimensions.
- Sanborn's2009 Smithsonian oral history reportedly describes stencilization to retain enclosed centers followed by hand jigsaw cutting: https://www.aaa.si.edu/collections/interviews/oral-history-interview-jim-sanborn-15700 . The current mathematical bitmap can leave counter islands disconnected; it is not a manufacturable reconstruction of those stencil bridges.
- A firsthand2005 report reportedly describes individually positioned templates, inconsistent kerning and no complete layout master: https://www.thekryptosproject.com/events/dinners/pdfs/2005/2005_hanson.pdf . Equal columns/rows and a generic alphabet therefore remain hypotheses even when the transcript is exact. Await original page/excerpt confirmation in the final provenance matrix.

Future aperture data should use immutable letter IDs tied to canonical indices and separate local surface coordinates and polygon contours (outer boundary, holes/counters, bridges), units, source-image coordinates, transform/calibration metadata and uncertainty. A traced/imported mode must say **image-traced, uncalibrated** until camera geometry and scale have been established. It should retain the original image, landmark associations and all transformations, with a registration overlay and error vectors. Support observational disagreement and multiple trace sets; do not silently overwrite canonical text or equate a projected image trace with measured3D coordinates. Export the complete aperture dataset/version and assumptions.

Acceptance additions: all enclosed centers in the claimed physical stencil retain verified bridges; surface letter centers/kerning are checked against held-out photographs instead of imposing equal spacing; layout metrics and glyph-outline fit errors are reported separately. A canonical text test can pass while physical lettering remains unsupported.

## Candidate optical holdout reference

Incoming researcher inspected Carol Highsmith, Library of Congress LCCN2011631531: https://commons.wikimedia.org/wiki/File:Art_made_of_%22code%22_named_Kryptos_sits_on_the_grounds_of_the_C.I.A._Headquarters_in_Virginia_LCCN2011631531.tif . Researcher reports visible letter-shaped illumination on courtyard pavers, both curved copper regions, a horizontal seam, apertures and paving joints. This is a promising geometric/occlusion reference, not a calibrated exposure. The source date range is only1980–2006, digitized film; no verified exposure time or camera calibration is available.

A future comparison view should show attribution/catalog ID, original image and crop/processing, identifiable landmarks and paver constraints, camera/light fit degrees of freedom and residual vectors. A fitted light direction may test relative geometry/occlusion; it cannot validate calendar time or prove direct-sun provenance. Reserve independent images before fitting. Never adjust glyphs or physical placement to produce desired K4 plaintext.

## Final incoming Scott v2 audit matrix

The parent supplied the following verified code audit; the values remain **Scott model estimates**, not physical measurements, and are not adopted as defaults here.

| Quantity / behavior | Audited value or finding | Consequence |
|---|---|---|
| Screen height / base | H=2.75m; y0=0.05m | Estimated geometry, not surveyed dimensions. |
| Surface arc per half / radius | L=2.85m; R=1.45m | Circular-half angle112.615842°, chord2.412889m. Arc is not chord. |
| Combined geometry | End-to-end span4.825779m; opposing bulges depth1.291285m | Derived from the model, not independent anchors. |
| Heading |140°; chord axis50°/230° | Estimated true-north orientation; requires independent bearing anchor. |
| Margins / pitch | Top/bottom0.055H; side0.023L; row87.4107mm; nominal31-column arc87.70645mm | Derived assumptions. Default justification changes pitch for rows29–33 letters. |
| Letter size | Font em76.0473mm | CSS em is not measured ink height. The claimed3.45inch pitch is a derived rubbing estimate without recorded pixel picks/calculation. |
| Typography | Arial Black/Helvetica/Arial while rubbings show serifed lettering | Generic sans-serif geometry cannot claim rubbing fidelity. |
| Texture aspect |4096×2048 mapped to2.85×2.75m | Width/height is compressed to0.51818 of font ratio. Do not reproduce this texture distortion. |
| Horizontal ray sample offsets | Uses dx×hg/(πR) instead of dx×hg/L |0.6256436 of intended along-arc displacement at defaults; visual mask and analytical ray samples disagree. |
| Water / tree consistency | Visible pool near+0.005m, analytic reflection planes negative; visible tapered tree differs from analytic cylinder | Render and analysis must share one canonical geometry. |
| “Measured” mode / state | No points loaded; silently falls back to justification. Import has normalized centers only, no contours/sizes/uncertainty. Export omits imported list. | No silent fallback permitted in a claimed measured mode. Serialize the actual aperture data and provenance. |
| Photographic validation | Explicit failed fit | Preserve failure; it prevents a calibrated-model claim. |

Physical-unit glyph masks should preserve their source aspect ratio through mesh placement, rendering and ray tests. Separate ink/aperture bounds from em, advance and cell pitch. Keep stencil bridges and contours, not merely letter centers. The same physical coordinates/contours must drive visible copper, obstruction tests and projections.

Additional photograph family for independently identified-letter/seam/edge/paver landmarks: https://voynich.net/Kryptos/ . Incoming audit reports multiple viewpoints without usable capture EXIF. Repeated generic letter-feature matches are ambiguous; identify canonical letters individually. Fit relative geometry before claiming absolute scale, true-north heading or a real calendar sunlight alignment. Highsmith remains held out.

## Conflicting thickness records

The earlier memo report is not a settled thickness measurement. Parent research additionally found the SPYSCAPE interview report about original letter cutter David Sheldon includes reporter narrative describing three-inch-high letters in0.25-inch copper; these numbers are not displayed as a direct quotation from Sheldon: https://spyscape.com/article/kryptos-the-cryptic-cia-mystery-is-bigger-than-you-think . Preserve0.25in=6.35mm from that account and0.5in=12.7mm from the1991 memo as separate sourced alternatives, not as a statistically measured interval or a single verified default. The stated three-inch letter height also needs a feature definition (ink/aperture extent versus template/em) and context before use.

Current thickness is exactly zero in the mathematical model, distinct from **both** accounts. Oblique rays through a finite-thickness aperture can be clipped by its sidewalls. A future thickness comparison should expose discrete source alternatives plus explicit user hypotheses, retain their citations, and quantify oblique transmission differences without manufacturing confidence bounds.

## Source-based height alternatives and current revision boundary

Incoming researcher visually verified CIA-released Intellipedia C06498615, PDF page1, printed23 September2014, describes the S-shaped screen as8ft high: https://www.cia.gov/readingroom/docs/kryptos%20sculpture%5B15267759%5D.pdf . The researcher separately reports NSA `KRYPTOS_Summary.pdf` page2 says about3m (10ft); an exact stable URL/page excerpt remains needed in the provenance record. These are competing documentary screen-height descriptions, while the artist's12ft describes an overall courtyard artwork envelope. Do not average them, assign invented survey confidence, or use them to scale this four-row crop directly. A future model can expose named source-based alternatives once feature definitions are reconciled.

**This revision's scope:** documentary constraints, exact default audit, coherent projection physics, transparent limitations, and a calibration/holdout protocol. Its only application repair is playback-label synchronization plus a clearer unmeasured-lettering disclaimer. It does not replace the crop with a full screen, change physical dimensions, import Scott geometry, claim calibration or settle conflicting documents. The next geometry implementation requires a reviewed choice of parameterization/evidence records, independent scale/bearing anchors, and separately fitted camera/letter contours where supportable. Remaining survey-data gaps stay explicit.

## Component placement evidence and calibration status

Final incoming photograph audit places the petrified tree at the ciphertext screen outer end, not the central inflection. It distinguishes a bubbling basin from a reflecting pond and highlights seams, fasteners and clearances. These visual constraints are not measured placements. No measured support has been established for equal semicylinders, a particular radius, an exact heading or regular physical pitch. Any future supports/ponds need separate feature records and shared visible/analytic geometry.

**Actually calibrated in this revision: nothing physical.** Solar and projection calculations are benchmarked/tested, and the interface is browser-tested. Current sculpture dimensions, silhouette, letter contours and spacing remain hypotheses; the cited photographs have been proposed for future controlled fitting/holdout, not fitted here. Photographic plausibility and numerical solar correctness do not establish a measured monument reconstruction.


## Implemented v2 physical revision — active defaults and scope

This section supersedes the earlier documentation-only boundary. The user authorized supported physical improvements after the audit; no surveyed blueprint was found. The implementation extends the original K4 crop into the full two-region screen with surrounding ciphertext and reverse-reading tableau, outer-end tree and an assumed horizontal seam. It does not copy Scott's code, circular geometry, fonts, textures, imported data or mismatch-prone ray formulas.

| Active input | Default and definition | Provenance / why chosen |
|---|---|---|
| Extent | Full screen, two connected sine lobes | Two curved parts/S topology is documented in NSA summary and visible in photographs. Exact sine centerline, symmetry and equal split are adjustable-model hypotheses, not fitted. |
| Height | CIA scenario8ft =2.4384m | Exact unit conversion of a documentary description, not claimed0.1mm accuracy. Alternative NSA scenario uses its primary wording **about3m (10ft)** as3.0m, not an averaged consensus or a precise10ft conversion. Height slider makes a custom hypothesis. |
| Total chord span |6.2m | Retained simple experimental span, now across both halves; no panel-width measurement supports it. It is not Scott's arc length and not the artist's overall installation width. |
| Curve amplitude |0.7m per opposing lobe | Preserved illustrative amplitude. Peak-to-peak depth1.4m; equal lobes are a simplifying hypothesis. No specific radius or equal semicylinders claimed. |
| Heading |0° front normal south for flat control | Axis-aligned reproducible baseline, not a geographic estimate. |
| Clearance |0.10m | Round near-ground experiment rather than the old elevated K4 crop. No measured paving clearance is available. |
| Tree |On;2.8m tall,0.15m base radius, top radius0.65×base | Location at cipher outer end supported by photographs. A12-sided tapered closed solid is only an occluding proxy; all size/shape/offset values are hypotheses, separately adjustable/off. Outer offset is0.4×base radius. Rendering and ground-shadow analysis use that exact same mesh. |
| Seam |1mm-wide material strip at half screen height | Photographic seam existence is an observed constraint; its current ratio/width is an explicit assumption. Not a measured joint or fastener model. |
| Lettering |Original5×7 physical square-stroke masks with approximate retaining bridges | Generic geometry, not measured serif contours. Every copper counter connects to the surrounding copper. Nominal ink height0.070m × aperture scale0.88 gives0.0616m effective height,0.0440m width at defaults. These sizes are chosen for inspection, not from CSS em or an uncalibrated rubbing. |
| Physical spacing |Constant developed pitch within each33-cell half-width envelope | Preserves transcript lines of29–33 characters, padded centrally with integer-cell floor offset; not justified to change each row's pitch. Physical spacing and integer padding are hypotheses. Canonical K4 remains31 columns with offset27 in its displayed text/index layer. |

Full geometry uses a512-segment numerical arc-length table to place square stroke cells in physical surface units. The resulting full developed length is about6.92m at defaults, half about3.46m, nominal cell pitch about104.8mm, row pitch about87.1mm. These are **derived from assumed inputs**, not new observations. The camera and renderer do not alter the analytical ground projection. Material polygons, aperture masks, seam and tree all enter the same ground-shadow union; overlapping solid geometry can occlude bright lettering. Render batching changes draw calls, not this geometry. Surface shading remains illustrative and does not calculate self-shadow intensity on copper.

Full transcripts are preserved verbatim from CIA/Dunin source lines rather than rewrapped into a uniform31-column wall. The dataset has869 cipher characters including question marks and867 tableau characters; its count is not forced to match CIA's prose count of1735 alphabetic letters. That discrepancy is a transcription/counting question, not grounds for inventing extra apertures. Source text identity is separate from measured aperture positions.

The original isolated K4 mode preserves v1 surface/mesh geometry, including the artificially blank27 K3 cells and stretched pixel font. v1 JSON is migrated explicitly into that control mode; it cannot silently become a calibrated full screen. v2 JSON captures extent, height scenario, all screen/tree/font inputs, camera target, full raw transcript, immutable aperture mask rows/version, geometry algorithm, actual active light and assumptions. Counter-bridge construction and physical aspect have automated checks. Imported conflicting scenario labels/mask/transcript data are rejected.

Omitted physical components remain pools, granite, fasteners, surrounding architecture, terrain/vegetation, finite copper thickness and exact supports. No landmark/camera/scale fitting has occurred. Highsmith remains an optical holdout, and identified-letter/paving/seam landmarks across Gillogly views are proposed fitting evidence. The updated topology improves physical plausibility; it does not close the independent scale, bearing, profile, contour or thickness gaps.

Primary NSA summary URL independently resolved during implementation: https://www.nsa.gov/portals/75/documents/news-features/declassified-documents/cia-kryptos-sculpture/KRYPTOS_Summary.pdf . Indexed text describes about3metres and two curved copper plates side-by-side forming an S from above; the source is a documentary constraint rather than a survey drawing.

## Optical source revision 3 (pending browser validation)

The sheet can now be an ideal0mm surface or a normal-offset solid with a6.35mm (SPYSCAPE reporter narrative) /12.7mm (1991 memo) source alternative. They remain conflicting reported values; no averaging or probability interval. Generic apertures retain their actual opaque pixel bridges as extruded walls; both skins and walls join the same scene used by display and geometric shadow projection. The two-lobe sine hypothesis, equal pitch and generic aperture shapes remain unchanged and unsurveyed.

A receiver is an explicit plane: y = datum + x tan(eastSlope) − z tan(northSlope), with +X east, +Y up and −Z north. Optional finite bounds are an XZ rectangle centered at the saved east/north coordinates, not a surveyed courtyard polygon; changing slope does not redefine extents as surface distances. Material below the receiver plane is clipped in both display and shadow paths. No cosmetic pond is presented over continuous paving. No basin opening, receiver holes or rim walls have been inferred.

Finite-Sun preview traces each sampled direction through the same projected opaque scene; overlaps are unioned per sample, then accumulated linearly using the identical unobstructed receiver-cosine sum. A fixed nominal0.2666° angular radius is an explicit NASA-fact-sheet approximation, not a date-specific measured disk. Antipodal equal-area disk-plane sampling is deterministic, no limb darkening/refraction; directions below horizon are excluded and center below horizon disables direct light. Final color includes artistic ambient illumination and is not absolute irradiance. Source and spatial convergence for the live preview are not certified. See QA_REPORT.md for numerical fixture outcomes and browser lock blocker.

## Numerical mesh revision4

The512-step table is solely an arc-length inversion approximation. Analytic sine positions/normals feed shared longitudinal knots, including every glyph/cell boundary plus adaptive subdivisions of midplane and both offset skins. Production faces and horizontal walls split at identical knots; vertical edges include shared row/stroke/seam levels. Exported meshing metadata records algorithm, knot counts, declared metre chord budget and estimated maximum deviation. Boundary coverage is closed under the tested numeric vertex tolerance; square-pixel diagonal contacts may be nonmanifold. This numerical correction does not change any documentary dimension into a measurement. See QA_REPORT.md for the independently discovered defect and actual production convergence fixtures.

## Conditional photo workspace scope

The final two-view dataset constrains a15-point visible ruled strip under a dimensionless H=1 gauge. It is not necessarily the full cipher half; silhouette endpoints are not verified joins.21usable non-K4 bbox-center correspondences span only sampled rows14/19/20/23 and columns roughly2–13.14train/7held-out points conditionally fit the second camera; bbox centers have unquantified perspective/picking systematic errors.800/1200px first-focal alternatives both remain compatible at approximately3px holdout RMS while4000px is a poor fit. These held-out results were used for exploratory model selection, so they are not final untouched validation. The UI recomputes residuals from stored 3D points, Rodrigues rotation, centered translation/focal/principal point and the refined raw source picks. The separately viewable strip never mutates complete-screen optical geometry. All selected transforms and raw data export, with physical scale null. Original photographic pixels are not redistributed.
