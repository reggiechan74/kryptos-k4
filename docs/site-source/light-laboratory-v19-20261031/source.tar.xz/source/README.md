# Kryptos · Light Laboratory

Original buildless static workbench, with an explicitly unsurveyed full screen and a retained isolated K4 control. No external runtime dependencies, private data, analytics, fonts or paid services. No Scott code or research repository used.

Run `node --test tests/*.test.mjs` with Node20+; preview `python3 -m http.server 8173 -d dist`. This Mac has `/opt/homebrew/Cellar/node/23.9.0/bin/node`.

Read **GEOMETRY_SPEC.md** for the source ledger, competing height/thickness descriptions, current exact defaults, Scott audit, physical lettering distinctions and independent-photo acceptance criteria. No physical parameter has been calibrated to photographs or surveyed. Documentary height alternatives remain alternatives.

Full-screen mode implements both opposite curves, complete verbatim cipher/tableau lines, reverse-reading tableau, highlighted K4, a provisional mid-height seam and a tapered tree proxy at the cipher outer end. Shape, span, heading, clearance, spacing, seam and tree size remain assumptions. Generic square-stroke glyphs preserve physical aspect and retaining bridges; they are not traced hand-cut serif apertures. True glyph shapes/kerning and finite thickness remain gaps.

World +X east, +Y up, −Z north. Geometric Sun azimuth clockwise from north; refraction off. Ground projection q=p−((p.y−receiverY)/sun.y)×sun. At elevation<=0 direct light is off. Ground shadow is the union of the actual solid material polygons, including full surrounding text, seam and tree. Missing copper stays bright; no ground text overlay is stamped. Camera is independent. Copper shading is illustrative; no self-shadow intensity calculation. No pools/buildings/terrain/penumbra are simulated.

The v2 JSON format includes immutable mask rows, full transcripts, model/glyph algorithms, every adjustable geometric/physical input, scenario, extent, camera/target, active computed light, UTC/local date, sources and assumptions. Atomic validation rejects contradictory scenario/mask/transcript data. v1 states migrate to the original crop. Local input uses historical America/New_York rules: DST gaps reject, repeated times choose the earlier occurrence; UTC import can identify the later occurrence.

Tests cover solar benchmarks, historical DST, mode separation, projection scale/direction, material shadows, counters, full topology/transcript placement, curved inter-panel occlusion, tree aperture blocking, seam shadows, physical glyph aspect, camera independence, v1 migration, v2 scenario roundtrips and versioned download names. QA_REPORT.md distinguishes observed live browser checks from pending checks. Tests establish computational behavior, not monument accuracy.

Site identity is preserved in `.openai/hosting.json`. Owner-private only. Use the supported Sites source helper to push/package exact source before save/deploy; never persist credentials or create a replacement Site for this checkout.
