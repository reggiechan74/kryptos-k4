import test from 'node:test';
import assert from 'node:assert/strict';
import {defaults, project, importState, exportState} from '../candidate/math.mjs';
import {mesh, screenGeometry} from '../candidate/geometry.mjs';
import {bridgedGlyphs} from '../candidate/glyphs.mjs';
import {CIPHER_ROWS, TABLEAU_ROWS} from '../candidate/transcript.mjs';

const sub = (a, b) => a.map((v, i) => v - b[i]);
const dot = (a, b) => a.reduce((sum, v, i) => sum + v * b[i], 0);
const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
const normalize = a => a.map(v => v / Math.hypot(...a));
const near = (a, b) => assert.ok(Math.abs(a-b) < 1e-7, `${a} ≈ ${b}`);

// Independent 3D ray/triangle oracle, rather than using ground projection to
// decide whether an opaque polygon blocks the ray.
function rayTriangle(origin, direction, a, b, c) {
  const e1 = sub(b, a), e2 = sub(c, a), h = cross(direction, e2), det = dot(e1, h);
  if (Math.abs(det) < 1e-10) return false;
  const inv = 1 / det, s = sub(origin, a), u = inv * dot(s, h);
  if (u < -1e-8 || u > 1+1e-8) return false;
  const q = cross(s, e1), v = inv * dot(direction, q);
  if (v < -1e-8 || u+v > 1+1e-8) return false;
  return inv * dot(e2, q) > 1e-7;
}
function rayBlocked(origin, direction, tiles) {
  return tiles.some(({p}) => p.slice(1, -1).some((a, i) => rayTriangle(origin, direction, p[0], a, p[i+2])));
}
function insideGroundPolygon(p, vertices) {
  let inside = false;
  for (let i=0, j=vertices.length-1; i<vertices.length; j=i++) {
    const a=vertices[i], b=vertices[j];
    if ((a[2]>p[2]) !== (b[2]>p[2]) && p[0] < (b[0]-a[0])*(p[2]-a[2])/(b[2]-a[2])+a[0]) inside=!inside;
  }
  return inside;
}
function shadowContains(q, light, tiles, receiver=0) {
  return tiles.some(t => insideGroundPolygon(q, t.p.map(p => project(p, light, receiver))));
}
function toward(p, target) {
  const direction = normalize(sub(target, p));
  return {direction, light: {
    azimuth: (Math.atan2(direction[0], -direction[2])*180/Math.PI+360)%360,
    elevation: Math.asin(direction[1])*180/Math.PI
  }};
}
function fixture() {
  const state=defaults(), model=mesh(state), {at, length}=screenGeometry(state.geometry);
  const unit=model.metrics.physicalSquareStroke;
  // Physical point at the center of a bitmap aperture pixel in a cipher cell.
  const aperturePoint = (column, row, gx, gy) => at(
    (column+.5)/66 + (gx-2)*unit/length,
    1-(row+.5)/28 - (gy-3)*unit/state.geometry.height
  );
  return {state, model, at, aperturePoint};
}

test('curved opposite panel blocks an otherwise clear K4 aperture ray', () => {
  const {state, model, at, aperturePoint}=fixture();
  assert.ok(state.geometry.curvature > 0);
  assert.equal(bridgedGlyphs.O[0][2], '1');
  const p=aperturePoint(28, 24, 2, 0); // K4 #1 O, top-stroke aperture.
  const target=at(.5+20.1/66, 1-10.1/28); // Opaque margin on the tableau half.
  assert.ok(p[2]>0 && target[2]<0, 'uses the two distinct curved lobes');
  const {direction, light}=toward(p, target), q=project(p, light);
  const cipher=model.tiles.filter(t => t.kind==='copper' && t.p.every(v => v[0]<=1e-8));
  const tableau=model.tiles.filter(t => t.kind==='copper' && t.p.every(v => v[0]>=-1e-8));
  const tableauSet=new Set(tableau), withoutTableau=model.tiles.filter(t => !tableauSet.has(t));
  assert.equal(rayBlocked(q, direction, withoutTableau), false, 'no blocker without opposite panel');
  assert.equal(shadowContains(q, light, withoutTableau), false);
  assert.equal(rayBlocked(q, direction, tableau), true, 'independent 3D ray hits tableau material');
  assert.equal(shadowContains(q, light, tableau), true, 'the shared material casts ground shadow there');
  assert.equal(shadowContains(q, light, cipher), false, 'source cipher aperture stays open');
  assert.equal(shadowContains(q, light, model.tiles), true);
});

test('outer-end tree blocks a letter aperture that is clear with tree disabled', () => {
  const {state, model, aperturePoint}=fixture();
  assert.equal(CIPHER_ROWS[25][0], 'U');
  assert.equal(bridgedGlyphs.U[0][0], '1');
  const p=aperturePoint(1, 25, 0, 0);
  const target=[-state.geometry.width/2-state.geometry.treeRadius*.4, 1, 0];
  const {direction, light}=toward(p, target), q=project(p, light);
  const tree=model.tiles.filter(t => t.kind==='tree');
  state.geometry.tree=false;
  const withoutTree=mesh(state).tiles;
  assert.equal(rayBlocked(q, direction, withoutTree), false);
  assert.equal(shadowContains(q, light, withoutTree), false, 'aperture transmits when obstruction is absent');
  assert.equal(rayBlocked(q, direction, tree), true, 'closed tree mesh intercepts the 3D ray');
  assert.equal(shadowContains(q, light, tree), true);
  assert.equal(shadowContains(q, light, model.tiles), true, 'visible tree and blocker use identical geometry');
});

test('provisional seam material projects to its geometric ground shadow', () => {
  const {state, model}=fixture(), light={azimuth:217, elevation:35};
  const seam=model.tiles.filter(t => t.kind==='seam');
  assert.ok(seam.length >=66);
  // Use the actual strip quad's interior: the renderer approximates the
  // continuous curve by chords, so a point on the ideal sine is not exactly
  // on this 1 mm material strip.
  const p=seam[20].p.reduce((sum, v) => sum.map((n,i)=>n+v[i]/seam[20].p.length), [0,0,0]);
  const q=project(p, light, state.geometry.receiver);
  const r=Math.PI/180, direction=[Math.sin(217*r)*Math.cos(35*r), Math.sin(35*r), -Math.cos(217*r)*Math.cos(35*r)];
  near(p[1], state.geometry.base+state.geometry.height/2);
  near(Math.hypot(q[0]-p[0], q[2]-p[2]), (p[1]-state.geometry.receiver)/Math.tan(35*r));
  assert.equal(rayBlocked(q, direction, seam), true);
  assert.equal(shadowContains(q, light, seam), true);
  // The seam overlays existing copper at the row boundary; the test does not
  // invent a unique shadow region that would disappear if the seam is removed.
});

test('all transcript rows retain their exact length and total character count', () => {
  assert.deepEqual(CIPHER_ROWS.map(r => r.length), [32,31,31,30,31,32,31,31,32,31,30,31,31,31,32,30,31,30,32,30,32,31,33,29,31,31,31,31]);
  assert.deepEqual(TABLEAU_ROWS.map(r => r.length), [30,31,31,31,31,31,31,31,31,31,31,31,31,31,32,31,31,31,31,31,31,31,31,31,31,31,31,30]);
  assert.equal(CIPHER_ROWS.length, 28);
  assert.equal(CIPHER_ROWS.join('').length, 869);
  assert.equal(Math.min(...CIPHER_ROWS.map(r=>r.length)), 29);
  assert.equal(Math.max(...CIPHER_ROWS.map(r=>r.length)), 33);
  assert.equal(TABLEAU_ROWS.length, 28);
  assert.equal(TABLEAU_ROWS.join('').length, 867);
  assert.equal(Math.min(...TABLEAU_ROWS.map(r=>r.length)), 30);
  assert.equal(Math.max(...TABLEAU_ROWS.map(r=>r.length)), 32);
});

test('CIA, NSA and custom states roundtrip changed physical inputs and disabled tree', () => {
  const cases=[
    {scenario:'cia8', height:2.4384, letterHeight:.083, treeHeight:3.4, tree:true},
    {scenario:'nsa10', height:3, letterHeight:.095, treeHeight:4.1, tree:false},
    {scenario:'custom', height:2.72, letterHeight:.055, treeHeight:1.9, tree:true},
    {scenario:'custom', height:3.35, letterHeight:.11, treeHeight:3.8, tree:false}
  ];
  for (const c of cases) {
    const s=defaults();
    s.heightScenario=c.scenario;
    Object.assign(s.geometry, {height:c.height, letterHeight:c.letterHeight, treeHeight:c.treeHeight, tree:c.tree, treeRadius:.24, heading:137, width:5.8, curvature:1.1, base:.18, receiver:.004});
    s.mode='manual'; s.manual={azimuth:232.5, elevation:12.4};
    s.camera={yaw:1.2, pitch:.9, zoom:2.1, target:[-1,.4,.2]};
    const raw=exportState(s), restored=importState(raw), payload=JSON.parse(raw);
    assert.deepEqual(restored, s, c.scenario);
    assert.deepEqual(payload.actualLight, s.manual);
    assert.deepEqual(mesh(restored).centers, mesh(s).centers, 'physical letter locations reproduce');
    assert.equal(mesh(restored).tiles.some(t=>t.kind==='tree'), c.tree);
    assert.equal(restored.geometry.letterHeight, c.letterHeight);
    assert.equal(restored.geometry.treeHeight, c.treeHeight);
  }
});
