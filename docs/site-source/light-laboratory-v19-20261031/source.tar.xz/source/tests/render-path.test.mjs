import test from 'node:test';
import assert from 'node:assert/strict';
import {svgPolygons} from '../candidate/render-path.mjs';

test('bulk raster path keeps each contour, winding and subpixel coordinates', () => {
  const polygons=[[[0,0],[2,0],[2,1],[0,1]],[[1,0],[1,1],[3,1],[3,0]]];
  const transform=([x,y])=>[x*1.23456+.22222,y*.87654-.33333];
  const data=svgPolygons(polygons,transform);
  const contours=[...data.matchAll(/M([^Z]+)Z/g)].map(m=>m[1].split('L').map(p=>p.split(',').map(Number)));
  assert.equal(contours.length,polygons.length);
  for(let n=0;n<contours.length;n++){
    const points=contours[n];
    assert.equal(points.length,polygons[n].length);
    const area=points.reduce((sum,p,i)=>{const q=points[(i+1)%points.length];return sum+p[0]*q[1]-q[0]*p[1]},0);
    assert.ok(area>0,'opposing contours use the same positive winding for opaque union');
    for(const p of points)assert.ok(polygons[n].map(transform).some(q=>Math.abs(p[0]-q[0])<=.000501&&Math.abs(p[1]-q[1])<=.000501),'raster vertex remains within half of the declared0.001 CSS px precision');
  }
});
