#!/usr/bin/env python3
"""Assemble isolated candidate; verify original main bytes against exact live-v5 commit."""
from pathlib import Path
import shutil,subprocess,json,hashlib,sys,re
root=Path(__file__).resolve().parent.parent
baseline='8a346f329cafc5b91abba34636c3f1440eb3e1ff'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',baseline,'dist'],cwd=root,text=True).splitlines()
for name in files:
 expected=subprocess.check_output(['git','show',baseline+':'+name],cwd=root)
 if name=='dist/index.html':
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()=='0183352693b16cd977dc53e882f54c0d0cf375610aecd966a6fd0102199622c2','Main introduction changed unexpectedly'
 else:
  assert (root/name).read_bytes()==expected,'Main physics/static asset changed: '+name
frozen_sets=[('4ee1842d260f7c6b08a97b8f38e23956389fb412','dist/validation/v4'),('6a1235d8b755bcaf4ff0420c1d37ead5871d280b','dist/validation/v4-async-photo'),('6ec1751e0c104734da45e792d76626e57619bd9f','dist/validation/v4-read-safe'),('696b847ba048f51f895cf5afaa244b13104c0478','dist/validation/v4-accepted-worker')]
frozen_files=[]
for frozen,folder in frozen_sets:
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',frozen,folder],cwd=root,text=True).splitlines()
 for name in names:
  assert (root/name).read_bytes()==subprocess.check_output(['git','show',frozen+':'+name],cwd=root),'Frozen candidate changed: '+name
 frozen_files.extend(names)
route=sys.argv[1] if len(sys.argv)>1 else 'v4-opaque-set'
assert re.fullmatch(r'v4-[a-z0-9-]+',route) and route not in ['v4-async-photo','v4-read-safe','v4-accepted-worker'],'Use a new isolated named route; reviewed routes are frozen'
candidate=root/'candidate';target=root/('dist/validation/'+route)
if target.exists():shutil.rmtree(target)
shutil.copytree(candidate,target)
qa=target/'qa';qa.mkdir();h=(root/'qa/browser-pixels.html').read_text().replace('../candidate/','../')
(qa/'browser-pixels.html').write_text(h)
(qa/'narrow-layout.html').write_text((root/'qa/narrow-layout.html').read_text())
(qa/'scene-worker-pixels.html').write_text((root/'qa/scene-worker-pixels.html').read_text().replace('../candidate/','../'))
manifest={'candidate':'shared-knot-physics-v4-opaque-set-r2','frozen_candidates':frozen_sets,'frozen_candidate_files_verified_identical':len(frozen_files),'status':'unpromoted validation route; not calibrated monument','main_baseline_commit':baseline,'main_baseline_assets_verified':len(files),'main_intro_sha256':hashlib.sha256((root/'dist/index.html').read_bytes()).hexdigest(),'source_files':[{'path':str(p.relative_to(candidate)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(candidate.rglob('*'))if p.is_file()]}
(target/'BUILD_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'main_files_identical':len(files),'candidate_files':len(manifest['source_files']),'route':'/validation/'+route+'/','pixel_harness':'/validation/'+route+'/qa/browser-pixels.html','frozen_candidate_files_identical':len(frozen_files)}))
