#!/usr/bin/env python3
"""Promote independently accepted c3c294d assets; do not change any solver code."""
from pathlib import Path
import subprocess,hashlib,json,re,shutil
r=Path(__file__).resolve().parent.parent
accepted='c3c294daaa2dec6262a890fe691dc0f7b168c449'
def original(name):return subprocess.check_output(['git','show',accepted+':'+name],cwd=r)
# All already published snapshots, including the last accepted one, are immutable.
frozen=subprocess.check_output(['git','ls-tree','-r','--name-only',accepted,'dist/validation'],cwd=r,text=True).splitlines()
for name in frozen:assert (r/name).read_bytes()==original(name),'Frozen snapshot changed: '+name
sources=subprocess.check_output(['git','ls-tree','-r','--name-only',accepted,'candidate'],cwd=r,text=True).splitlines()
changes=[]
for name in sources:
 data=original(name);assert (r/name).read_bytes()==data,'Candidate changed since acceptance: '+name
 relative=Path(name).relative_to('candidate');target=r/'dist'/relative
 if str(relative)=='index.html':
  s=data.decode();s,n=re.subn(r'<div role="status" style="padding:12px;.*?</div>','',s,count=1);assert n==1
  s=s.replace('Measured diagnostics · validation candidate','Measured diagnostics')
  data=s.encode();changes.append('index.html: remove unpromoted banner and validation diagnostics label')
 if str(relative)=='app.mjs':
  s=data.decode();assert s.count('opaque-set-r2 (unpromoted)')==1
  data=s.replace('opaque-set-r2 (unpromoted)','opaque-set-r2 · accepted release').encode();changes.append('app.mjs: diagnostic release label only')
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
# Validate every local HTML/module dependency resolves within this published package.
checked=0
for name in sources:
 p=r/'dist'/Path(name).relative_to('candidate')
 if p.suffix not in ['.mjs','.html']:continue
 text=p.read_text()
 refs=re.findall(r'''(?:from\s*|import\s*|new URL\()\s*['"](\.[^'"]+)['"]''',text)
 if p.suffix=='.html':refs+=re.findall(r'''(?:src|href)=["']([^"']+)["']''',text)
 for ref in refs:
  if ref.startswith(('https:','http:','#','/')):continue
  path=(p.parent/ref.split('?')[0].split('#')[0]).resolve()
  assert path.is_file(),'Unresolved dependency: '+str(p)+' -> '+ref
  checked+=1
for name in frozen:assert (r/name).read_bytes()==original(name)
manifest={'acceptedCandidateCommit':accepted,'status':'promoted accepted combined release; unsurveyed model','releaseOnlyChanges':changes,'frozenFilesVerified':len(frozen),'localDependenciesVerified':checked,'files':[{'path':str(Path(n).relative_to('candidate')),'sha256':hashlib.sha256((r/'dist'/Path(n).relative_to('candidate')).read_bytes()).hexdigest()}for n in sources]}
(r/'dist/RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'sourceFiles':len(sources),'frozenFilesUnchanged':len(frozen),'dependenciesVerified':checked,'changes':changes}))
